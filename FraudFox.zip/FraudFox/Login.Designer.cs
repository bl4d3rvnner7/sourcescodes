﻿namespace FraudFox
{
	// Token: 0x0200002E RID: 46
	public partial class Login : global::System.Windows.Forms.Form
	{
		// Token: 0x060002D8 RID: 728 RVA: 0x0000D3B4 File Offset: 0x0000B5B4
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				global::FraudFox.Login.smethod_27(this.components);
			}
			base.Dispose(disposing);
		}

		// Token: 0x060002D9 RID: 729 RVA: 0x0002832C File Offset: 0x0002652C
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = global::FraudFox.Login.smethod_29(global::FraudFox.Login.smethod_28(typeof(global::FraudFox.Login).TypeHandle));
			this.label1 = global::FraudFox.Login.smethod_30();
			this.txtUsername = global::FraudFox.Login.smethod_31();
			this.txtPassword = global::FraudFox.Login.smethod_31();
			this.label2 = global::FraudFox.Login.smethod_30();
			this.btnLogin = global::FraudFox.Login.smethod_32();
			this.pictureBox1 = global::FraudFox.Login.smethod_33();
			this.bwTorLogin = global::FraudFox.Login.smethod_34();
			this.pictureBox2 = global::FraudFox.Login.smethod_33();
			this.statusLabel = global::FraudFox.Login.smethod_30();
			this.cbConnection = global::FraudFox.Login.smethod_35();
			this.label4 = global::FraudFox.Login.smethod_30();
			this.bwDirectLogin = global::FraudFox.Login.smethod_34();
			global::FraudFox.Login.smethod_36(this.pictureBox1);
			global::FraudFox.Login.smethod_36(this.pictureBox2);
			global::FraudFox.Login.smethod_37(this);
			global::FraudFox.Login.smethod_38(this.label1, true);
			this.label1.Location = new global::System.Drawing.Point(157, 21);
			this.label1.Name = global::<Module>.smethod_26<string>(1550251231U);
			this.label1.Size = new global::System.Drawing.Size(58, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = global::<Module>.smethod_26<string>(2718571299U);
			this.txtUsername.Location = new global::System.Drawing.Point(225, 17);
			this.txtUsername.Name = global::<Module>.smethod_26<string>(4156611327U);
			this.txtUsername.Size = new global::System.Drawing.Size(297, 20);
			this.txtUsername.TabIndex = 1;
			this.txtPassword.Location = new global::System.Drawing.Point(225, 43);
			this.txtPassword.Name = global::<Module>.smethod_24<string>(1065936036U);
			this.txtPassword.Size = new global::System.Drawing.Size(297, 20);
			this.txtPassword.TabIndex = 3;
			this.txtPassword.UseSystemPasswordChar = true;
			this.label2.AutoSize = true;
			this.label2.Location = new global::System.Drawing.Point(157, 47);
			this.label2.Name = global::<Module>.smethod_25<string>(1843430639U);
			this.label2.Size = new global::System.Drawing.Size(56, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = global::<Module>.smethod_24<string>(2569403216U);
			this.btnLogin.Location = new global::System.Drawing.Point(160, 101);
			this.btnLogin.Name = global::<Module>.smethod_27<string>(2883712457U);
			this.btnLogin.Size = new global::System.Drawing.Size(362, 23);
			this.btnLogin.TabIndex = 4;
			this.btnLogin.Text = global::<Module>.smethod_23<string>(2014488804U);
			this.btnLogin.UseVisualStyleBackColor = true;
			this.btnLogin.Click += new global::System.EventHandler(this.btnLogin_Click);
			this.pictureBox1.BackColor = global::System.Drawing.Color.White;
			this.pictureBox1.Image = global::FraudFox.Properties.Resources._1421437996_firefox_grey;
			this.pictureBox1.Location = new global::System.Drawing.Point(12, 17);
			this.pictureBox1.Name = global::<Module>.smethod_25<string>(3025258716U);
			this.pictureBox1.Size = new global::System.Drawing.Size(110, 121);
			this.pictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			this.bwTorLogin.DoWork += new global::System.ComponentModel.DoWorkEventHandler(this.bwTorLogin_DoWork);
			this.pictureBox2.BackColor = global::System.Drawing.Color.White;
			this.pictureBox2.Location = new global::System.Drawing.Point(-8, -6);
			this.pictureBox2.Name = global::<Module>.smethod_24<string>(1173653158U);
			this.pictureBox2.Size = new global::System.Drawing.Size(144, 191);
			this.pictureBox2.TabIndex = 10;
			this.pictureBox2.TabStop = false;
			this.statusLabel.Location = new global::System.Drawing.Point(160, 132);
			this.statusLabel.Name = global::<Module>.smethod_25<string>(3582038340U);
			this.statusLabel.Size = new global::System.Drawing.Size(362, 17);
			this.statusLabel.TabIndex = 11;
			this.statusLabel.Text = global::<Module>.smethod_27<string>(3658067872U);
			this.statusLabel.TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.statusLabel.DoubleClick += new global::System.EventHandler(this.statusLabel_DoubleClick);
			this.cbConnection.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbConnection.FormattingEnabled = true;
			this.cbConnection.Items.AddRange(new object[]
			{
				global::<Module>.smethod_26<string>(120206669U),
				global::<Module>.smethod_26<string>(844014880U)
			});
			this.cbConnection.Location = new global::System.Drawing.Point(225, 69);
			this.cbConnection.Name = global::<Module>.smethod_25<string>(470227745U);
			this.cbConnection.Size = new global::System.Drawing.Size(297, 21);
			this.cbConnection.TabIndex = 12;
			this.label4.AutoSize = true;
			this.label4.Location = new global::System.Drawing.Point(157, 72);
			this.label4.Name = global::<Module>.smethod_27<string>(3163891988U);
			this.label4.Size = new global::System.Drawing.Size(64, 13);
			this.label4.TabIndex = 13;
			this.label4.Text = global::<Module>.smethod_26<string>(853591274U);
			this.bwDirectLogin.DoWork += new global::System.ComponentModel.DoWorkEventHandler(this.bwDirectLogin_DoWork);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(544, 157);
			base.Controls.Add(this.label4);
			base.Controls.Add(this.cbConnection);
			base.Controls.Add(this.statusLabel);
			base.Controls.Add(this.pictureBox1);
			base.Controls.Add(this.btnLogin);
			base.Controls.Add(this.txtPassword);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.txtUsername);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.pictureBox2);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject(global::<Module>.smethod_27<string>(2527604160U));
			base.KeyPreview = true;
			base.Name = global::<Module>.smethod_23<string>(2363424058U);
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = global::<Module>.smethod_26<string>(148935851U);
			base.FormClosed += new global::System.Windows.Forms.FormClosedEventHandler(this.Login_FormClosed);
			base.Load += new global::System.EventHandler(this.Login_Load);
			base.KeyDown += new global::System.Windows.Forms.KeyEventHandler(this.Login_KeyDown);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox2).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040000B0 RID: 176
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040000B1 RID: 177
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040000B2 RID: 178
		private global::System.Windows.Forms.TextBox txtUsername;

		// Token: 0x040000B3 RID: 179
		private global::System.Windows.Forms.TextBox txtPassword;

		// Token: 0x040000B4 RID: 180
		private global::System.Windows.Forms.Label label2;

		// Token: 0x040000B5 RID: 181
		private global::System.Windows.Forms.Button btnLogin;

		// Token: 0x040000B6 RID: 182
		private global::System.Windows.Forms.PictureBox pictureBox1;

		// Token: 0x040000B7 RID: 183
		private global::System.ComponentModel.BackgroundWorker bwTorLogin;

		// Token: 0x040000B8 RID: 184
		private global::System.Windows.Forms.PictureBox pictureBox2;

		// Token: 0x040000B9 RID: 185
		private global::System.Windows.Forms.Label statusLabel;

		// Token: 0x040000BA RID: 186
		private global::System.Windows.Forms.ComboBox cbConnection;

		// Token: 0x040000BB RID: 187
		private global::System.Windows.Forms.Label label4;

		// Token: 0x040000BC RID: 188
		private global::System.ComponentModel.BackgroundWorker bwDirectLogin;
	}
}
