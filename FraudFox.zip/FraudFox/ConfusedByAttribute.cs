﻿using System;

// Token: 0x020002FB RID: 763
internal class ConfusedByAttribute : Attribute
{
	// Token: 0x06002AA4 RID: 10916 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
	public ConfusedByAttribute(string string_0)
	{
	}
}
