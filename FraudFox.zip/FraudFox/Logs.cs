﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace FraudFox
{
	// Token: 0x02000027 RID: 39
	public partial class Logs : Form
	{
		// Token: 0x06000284 RID: 644 RVA: 0x0000D1E9 File Offset: 0x0000B3E9
		public Logs()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000285 RID: 645 RVA: 0x000270BC File Offset: 0x000252BC
		public void ShowForm(IEnumerable<string> logList)
		{
			IEnumerator<string> enumerator = logList.GetEnumerator();
			try
			{
				while (Logs.smethod_2(enumerator))
				{
					string text = enumerator.Current;
					Logs.smethod_1(this.txtLog, Logs.smethod_0(<Module>.smethod_27<string>(646320566U), text));
				}
			}
			finally
			{
				if (enumerator != null)
				{
					Logs.smethod_3(enumerator);
				}
			}
			Logs.smethod_4(this);
		}

		// Token: 0x06000286 RID: 646 RVA: 0x0000D1F7 File Offset: 0x0000B3F7
		public void AppendText(string msg)
		{
			Logs.smethod_1(this.txtLog, Logs.smethod_0(<Module>.smethod_26<string>(2159142714U), msg));
		}

		// Token: 0x06000287 RID: 647 RVA: 0x0000D214 File Offset: 0x0000B414
		private void Logs_FormClosing(object sender, FormClosingEventArgs e)
		{
			Logs.smethod_5(e, true);
			Logs.smethod_6(this);
		}

		// Token: 0x0600028A RID: 650 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_0(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x0600028B RID: 651 RVA: 0x0000D242 File Offset: 0x0000B442
		static void smethod_1(TextBoxBase textBoxBase_0, string string_0)
		{
			textBoxBase_0.AppendText(string_0);
		}

		// Token: 0x0600028C RID: 652 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_2(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x0600028D RID: 653 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_3(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x0600028E RID: 654 RVA: 0x0000D092 File Offset: 0x0000B292
		static void smethod_4(Control control_0)
		{
			control_0.Show();
		}

		// Token: 0x0600028F RID: 655 RVA: 0x0000D0B6 File Offset: 0x0000B2B6
		static void smethod_5(CancelEventArgs cancelEventArgs_0, bool bool_0)
		{
			cancelEventArgs_0.Cancel = bool_0;
		}

		// Token: 0x06000290 RID: 656 RVA: 0x0000D0BF File Offset: 0x0000B2BF
		static void smethod_6(Control control_0)
		{
			control_0.Hide();
		}

		// Token: 0x06000291 RID: 657 RVA: 0x0000D0C7 File Offset: 0x0000B2C7
		static TextBox smethod_7()
		{
			return new TextBox();
		}

		// Token: 0x06000292 RID: 658 RVA: 0x0000C907 File Offset: 0x0000AB07
		static void smethod_8(Control control_0)
		{
			control_0.SuspendLayout();
		}
	}
}
