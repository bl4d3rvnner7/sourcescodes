﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x0200005C RID: 92
	[MeansImplicitUse]
	public sealed class PublicAPIAttribute : Attribute
	{
		// Token: 0x0600054D RID: 1357 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		public PublicAPIAttribute()
		{
		}

		// Token: 0x0600054E RID: 1358 RVA: 0x0000E234 File Offset: 0x0000C434
		public PublicAPIAttribute([NotNull] string comment)
		{
			this.Comment = comment;
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x0600054F RID: 1359 RVA: 0x0000E243 File Offset: 0x0000C443
		// (set) Token: 0x06000550 RID: 1360 RVA: 0x0000E24B File Offset: 0x0000C44B
		[NotNull]
		public string Comment { get; private set; }
	}
}
