﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x0200006C RID: 108
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
	public sealed class AspMvcSupressViewErrorAttribute : Attribute
	{
	}
}
