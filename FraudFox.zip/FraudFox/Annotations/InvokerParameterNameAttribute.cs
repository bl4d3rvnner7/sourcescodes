﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000052 RID: 82
	[AttributeUsage(AttributeTargets.Parameter, AllowMultiple = false, Inherited = true)]
	public sealed class InvokerParameterNameAttribute : Attribute
	{
	}
}
