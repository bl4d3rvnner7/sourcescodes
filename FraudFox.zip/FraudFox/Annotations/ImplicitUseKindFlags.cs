﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x0200005A RID: 90
	[Flags]
	public enum ImplicitUseKindFlags
	{
		// Token: 0x040001E9 RID: 489
		Default = 7,
		// Token: 0x040001EA RID: 490
		Access = 1,
		// Token: 0x040001EB RID: 491
		Assign = 2,
		// Token: 0x040001EC RID: 492
		InstantiatedWithFixedConstructorSignature = 4,
		// Token: 0x040001ED RID: 493
		InstantiatedNoFixedConstructorSignature = 8
	}
}
