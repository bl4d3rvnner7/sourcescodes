﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000057 RID: 87
	[BaseTypeRequired(typeof(Attribute))]
	[AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
	public sealed class BaseTypeRequiredAttribute : Attribute
	{
		// Token: 0x0600053A RID: 1338 RVA: 0x0000E168 File Offset: 0x0000C368
		public BaseTypeRequiredAttribute([NotNull] Type baseType)
		{
			this.BaseType = baseType;
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x0600053B RID: 1339 RVA: 0x0000E177 File Offset: 0x0000C377
		// (set) Token: 0x0600053C RID: 1340 RVA: 0x0000E17F File Offset: 0x0000C37F
		[NotNull]
		public Type BaseType { get; private set; }
	}
}
