﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000060 RID: 96
	[AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
	public sealed class AspMvcAreaMasterLocationFormatAttribute : Attribute
	{
		// Token: 0x06000557 RID: 1367 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		public AspMvcAreaMasterLocationFormatAttribute(string format)
		{
		}
	}
}
