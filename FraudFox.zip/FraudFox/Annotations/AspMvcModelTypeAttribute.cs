﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x0200006A RID: 106
	[AttributeUsage(AttributeTargets.Parameter)]
	public sealed class AspMvcModelTypeAttribute : Attribute
	{
	}
}
