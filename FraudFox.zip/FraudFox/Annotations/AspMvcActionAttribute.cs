﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000066 RID: 102
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Parameter)]
	public sealed class AspMvcActionAttribute : Attribute
	{
		// Token: 0x0600055D RID: 1373 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		public AspMvcActionAttribute()
		{
		}

		// Token: 0x0600055E RID: 1374 RVA: 0x0000E274 File Offset: 0x0000C474
		public AspMvcActionAttribute([NotNull] string anonymousProperty)
		{
			this.AnonymousProperty = anonymousProperty;
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x0600055F RID: 1375 RVA: 0x0000E283 File Offset: 0x0000C483
		// (set) Token: 0x06000560 RID: 1376 RVA: 0x0000E28B File Offset: 0x0000C48B
		[NotNull]
		public string AnonymousProperty { get; private set; }
	}
}
