﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000054 RID: 84
	[AttributeUsage(AttributeTargets.Method, AllowMultiple = true, Inherited = true)]
	public sealed class ContractAnnotationAttribute : Attribute
	{
		// Token: 0x0600052F RID: 1327 RVA: 0x0000E0FD File Offset: 0x0000C2FD
		public ContractAnnotationAttribute([NotNull] string contract)
			: this(contract, false)
		{
		}

		// Token: 0x06000530 RID: 1328 RVA: 0x0000E107 File Offset: 0x0000C307
		public ContractAnnotationAttribute([NotNull] string contract, bool forceFullStates)
		{
			this.Contract = contract;
			this.ForceFullStates = forceFullStates;
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x06000531 RID: 1329 RVA: 0x0000E11D File Offset: 0x0000C31D
		// (set) Token: 0x06000532 RID: 1330 RVA: 0x0000E125 File Offset: 0x0000C325
		public string Contract { get; private set; }

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x06000533 RID: 1331 RVA: 0x0000E12E File Offset: 0x0000C32E
		// (set) Token: 0x06000534 RID: 1332 RVA: 0x0000E136 File Offset: 0x0000C336
		public bool ForceFullStates { get; private set; }
	}
}
