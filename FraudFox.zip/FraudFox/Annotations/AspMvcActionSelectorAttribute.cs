﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000071 RID: 113
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter)]
	public sealed class AspMvcActionSelectorAttribute : Attribute
	{
	}
}
