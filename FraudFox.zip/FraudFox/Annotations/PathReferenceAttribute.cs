﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x0200005F RID: 95
	[AttributeUsage(AttributeTargets.Parameter)]
	public class PathReferenceAttribute : Attribute
	{
		// Token: 0x06000553 RID: 1363 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		public PathReferenceAttribute()
		{
		}

		// Token: 0x06000554 RID: 1364 RVA: 0x0000E254 File Offset: 0x0000C454
		public PathReferenceAttribute([PathReference] string basePath)
		{
			this.BasePath = basePath;
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x06000555 RID: 1365 RVA: 0x0000E263 File Offset: 0x0000C463
		// (set) Token: 0x06000556 RID: 1366 RVA: 0x0000E26B File Offset: 0x0000C46B
		[NotNull]
		public string BasePath { get; private set; }
	}
}
