﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000069 RID: 105
	[AttributeUsage(AttributeTargets.Parameter)]
	public sealed class AspMvcMasterAttribute : Attribute
	{
	}
}
