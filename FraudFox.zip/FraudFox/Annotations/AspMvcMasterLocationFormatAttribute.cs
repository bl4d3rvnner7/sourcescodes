﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000063 RID: 99
	[AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
	public sealed class AspMvcMasterLocationFormatAttribute : Attribute
	{
		// Token: 0x0600055A RID: 1370 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		public AspMvcMasterLocationFormatAttribute(string format)
		{
		}
	}
}
