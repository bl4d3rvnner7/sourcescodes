﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x0200005B RID: 91
	[Flags]
	public enum ImplicitUseTargetFlags
	{
		// Token: 0x040001EF RID: 495
		Default = 1,
		// Token: 0x040001F0 RID: 496
		Itself = 1,
		// Token: 0x040001F1 RID: 497
		Members = 2,
		// Token: 0x040001F2 RID: 498
		WithMembers = 3
	}
}
