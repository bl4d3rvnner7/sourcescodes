﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000070 RID: 112
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Parameter)]
	public sealed class AspMvcViewAttribute : PathReferenceAttribute
	{
	}
}
