﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000062 RID: 98
	[AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
	public sealed class AspMvcAreaViewLocationFormatAttribute : Attribute
	{
		// Token: 0x06000559 RID: 1369 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		public AspMvcAreaViewLocationFormatAttribute(string format)
		{
		}
	}
}
