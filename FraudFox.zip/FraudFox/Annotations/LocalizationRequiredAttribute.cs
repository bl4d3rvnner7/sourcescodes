﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000055 RID: 85
	[AttributeUsage(AttributeTargets.All, AllowMultiple = false, Inherited = true)]
	public sealed class LocalizationRequiredAttribute : Attribute
	{
		// Token: 0x06000535 RID: 1333 RVA: 0x0000E13F File Offset: 0x0000C33F
		public LocalizationRequiredAttribute()
			: this(true)
		{
		}

		// Token: 0x06000536 RID: 1334 RVA: 0x0000E148 File Offset: 0x0000C348
		public LocalizationRequiredAttribute(bool required)
		{
			this.Required = required;
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x06000537 RID: 1335 RVA: 0x0000E157 File Offset: 0x0000C357
		// (set) Token: 0x06000538 RID: 1336 RVA: 0x0000E15F File Offset: 0x0000C35F
		public bool Required { get; private set; }
	}
}
