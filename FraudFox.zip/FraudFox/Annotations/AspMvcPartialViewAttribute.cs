﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x0200006B RID: 107
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Parameter)]
	public sealed class AspMvcPartialViewAttribute : PathReferenceAttribute
	{
	}
}
