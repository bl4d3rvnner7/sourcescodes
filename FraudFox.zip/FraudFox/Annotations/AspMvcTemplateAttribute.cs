﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x0200006F RID: 111
	[AttributeUsage(AttributeTargets.Parameter)]
	public sealed class AspMvcTemplateAttribute : Attribute
	{
	}
}
