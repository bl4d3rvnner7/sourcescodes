﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000058 RID: 88
	[AttributeUsage(AttributeTargets.All, AllowMultiple = false, Inherited = true)]
	public sealed class UsedImplicitlyAttribute : Attribute
	{
		// Token: 0x0600053D RID: 1341 RVA: 0x0000E188 File Offset: 0x0000C388
		public UsedImplicitlyAttribute()
			: this(ImplicitUseKindFlags.Default, ImplicitUseTargetFlags.Default)
		{
		}

		// Token: 0x0600053E RID: 1342 RVA: 0x0000E192 File Offset: 0x0000C392
		public UsedImplicitlyAttribute(ImplicitUseKindFlags useKindFlags)
			: this(useKindFlags, ImplicitUseTargetFlags.Default)
		{
		}

		// Token: 0x0600053F RID: 1343 RVA: 0x0000E19C File Offset: 0x0000C39C
		public UsedImplicitlyAttribute(ImplicitUseTargetFlags targetFlags)
			: this(ImplicitUseKindFlags.Default, targetFlags)
		{
		}

		// Token: 0x06000540 RID: 1344 RVA: 0x0000E1A6 File Offset: 0x0000C3A6
		public UsedImplicitlyAttribute(ImplicitUseKindFlags useKindFlags, ImplicitUseTargetFlags targetFlags)
		{
			this.UseKindFlags = useKindFlags;
			this.TargetFlags = targetFlags;
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x06000541 RID: 1345 RVA: 0x0000E1BC File Offset: 0x0000C3BC
		// (set) Token: 0x06000542 RID: 1346 RVA: 0x0000E1C4 File Offset: 0x0000C3C4
		public ImplicitUseKindFlags UseKindFlags { get; private set; }

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x06000543 RID: 1347 RVA: 0x0000E1CD File Offset: 0x0000C3CD
		// (set) Token: 0x06000544 RID: 1348 RVA: 0x0000E1D5 File Offset: 0x0000C3D5
		public ImplicitUseTargetFlags TargetFlags { get; private set; }
	}
}
