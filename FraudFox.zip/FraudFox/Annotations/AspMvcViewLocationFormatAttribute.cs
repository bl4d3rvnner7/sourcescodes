﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000065 RID: 101
	[AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
	public sealed class AspMvcViewLocationFormatAttribute : Attribute
	{
		// Token: 0x0600055C RID: 1372 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		public AspMvcViewLocationFormatAttribute(string format)
		{
		}
	}
}
