﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000051 RID: 81
	[AttributeUsage(AttributeTargets.Constructor | AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
	public sealed class StringFormatMethodAttribute : Attribute
	{
		// Token: 0x06000527 RID: 1319 RVA: 0x0000E0BD File Offset: 0x0000C2BD
		public StringFormatMethodAttribute(string formatParameterName)
		{
			this.FormatParameterName = formatParameterName;
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x06000528 RID: 1320 RVA: 0x0000E0CC File Offset: 0x0000C2CC
		// (set) Token: 0x06000529 RID: 1321 RVA: 0x0000E0D4 File Offset: 0x0000C2D4
		public string FormatParameterName { get; private set; }
	}
}
