﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x0200006E RID: 110
	[AttributeUsage(AttributeTargets.Parameter)]
	public sealed class AspMvcEditorTemplateAttribute : Attribute
	{
	}
}
