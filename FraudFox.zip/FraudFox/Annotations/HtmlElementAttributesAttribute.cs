﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000072 RID: 114
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter, Inherited = true)]
	public sealed class HtmlElementAttributesAttribute : Attribute
	{
		// Token: 0x06000572 RID: 1394 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		public HtmlElementAttributesAttribute()
		{
		}

		// Token: 0x06000573 RID: 1395 RVA: 0x0000E2DC File Offset: 0x0000C4DC
		public HtmlElementAttributesAttribute([NotNull] string name)
		{
			this.Name = name;
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x06000574 RID: 1396 RVA: 0x0000E2EB File Offset: 0x0000C4EB
		// (set) Token: 0x06000575 RID: 1397 RVA: 0x0000E2F3 File Offset: 0x0000C4F3
		[NotNull]
		public string Name { get; private set; }
	}
}
