﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000068 RID: 104
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Parameter)]
	public sealed class AspMvcControllerAttribute : Attribute
	{
		// Token: 0x06000565 RID: 1381 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		public AspMvcControllerAttribute()
		{
		}

		// Token: 0x06000566 RID: 1382 RVA: 0x0000E2BC File Offset: 0x0000C4BC
		public AspMvcControllerAttribute([NotNull] string anonymousProperty)
		{
			this.AnonymousProperty = anonymousProperty;
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x06000567 RID: 1383 RVA: 0x0000E2CB File Offset: 0x0000C4CB
		// (set) Token: 0x06000568 RID: 1384 RVA: 0x0000E2D3 File Offset: 0x0000C4D3
		[NotNull]
		public string AnonymousProperty { get; private set; }
	}
}
