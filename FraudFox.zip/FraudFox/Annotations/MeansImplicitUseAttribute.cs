﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000059 RID: 89
	[AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = true)]
	public sealed class MeansImplicitUseAttribute : Attribute
	{
		// Token: 0x06000545 RID: 1349 RVA: 0x0000E1DE File Offset: 0x0000C3DE
		public MeansImplicitUseAttribute()
			: this(ImplicitUseKindFlags.Default, ImplicitUseTargetFlags.Default)
		{
		}

		// Token: 0x06000546 RID: 1350 RVA: 0x0000E1E8 File Offset: 0x0000C3E8
		public MeansImplicitUseAttribute(ImplicitUseKindFlags useKindFlags)
			: this(useKindFlags, ImplicitUseTargetFlags.Default)
		{
		}

		// Token: 0x06000547 RID: 1351 RVA: 0x0000E1F2 File Offset: 0x0000C3F2
		public MeansImplicitUseAttribute(ImplicitUseTargetFlags targetFlags)
			: this(ImplicitUseKindFlags.Default, targetFlags)
		{
		}

		// Token: 0x06000548 RID: 1352 RVA: 0x0000E1FC File Offset: 0x0000C3FC
		public MeansImplicitUseAttribute(ImplicitUseKindFlags useKindFlags, ImplicitUseTargetFlags targetFlags)
		{
			this.UseKindFlags = useKindFlags;
			this.TargetFlags = targetFlags;
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x06000549 RID: 1353 RVA: 0x0000E212 File Offset: 0x0000C412
		// (set) Token: 0x0600054A RID: 1354 RVA: 0x0000E21A File Offset: 0x0000C41A
		[UsedImplicitly]
		public ImplicitUseKindFlags UseKindFlags { get; private set; }

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x0600054B RID: 1355 RVA: 0x0000E223 File Offset: 0x0000C423
		// (set) Token: 0x0600054C RID: 1356 RVA: 0x0000E22B File Offset: 0x0000C42B
		[UsedImplicitly]
		public ImplicitUseTargetFlags TargetFlags { get; private set; }
	}
}
