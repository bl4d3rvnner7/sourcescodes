﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000067 RID: 103
	[AttributeUsage(AttributeTargets.Parameter)]
	public sealed class AspMvcAreaAttribute : PathReferenceAttribute
	{
		// Token: 0x06000561 RID: 1377 RVA: 0x0000E294 File Offset: 0x0000C494
		public AspMvcAreaAttribute()
		{
		}

		// Token: 0x06000562 RID: 1378 RVA: 0x0000E29C File Offset: 0x0000C49C
		public AspMvcAreaAttribute([NotNull] string anonymousProperty)
		{
			this.AnonymousProperty = anonymousProperty;
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x06000563 RID: 1379 RVA: 0x0000E2AB File Offset: 0x0000C4AB
		// (set) Token: 0x06000564 RID: 1380 RVA: 0x0000E2B3 File Offset: 0x0000C4B3
		[NotNull]
		public string AnonymousProperty { get; private set; }
	}
}
