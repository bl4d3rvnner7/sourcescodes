﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000053 RID: 83
	[AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
	public sealed class NotifyPropertyChangedInvocatorAttribute : Attribute
	{
		// Token: 0x0600052B RID: 1323 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		public NotifyPropertyChangedInvocatorAttribute()
		{
		}

		// Token: 0x0600052C RID: 1324 RVA: 0x0000E0DD File Offset: 0x0000C2DD
		public NotifyPropertyChangedInvocatorAttribute(string parameterName)
		{
			this.ParameterName = parameterName;
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x0600052D RID: 1325 RVA: 0x0000E0EC File Offset: 0x0000C2EC
		// (set) Token: 0x0600052E RID: 1326 RVA: 0x0000E0F4 File Offset: 0x0000C2F4
		public string ParameterName { get; private set; }
	}
}
