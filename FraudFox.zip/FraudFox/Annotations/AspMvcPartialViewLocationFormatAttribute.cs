﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000064 RID: 100
	[AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
	public sealed class AspMvcPartialViewLocationFormatAttribute : Attribute
	{
		// Token: 0x0600055B RID: 1371 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		public AspMvcPartialViewLocationFormatAttribute(string format)
		{
		}
	}
}
