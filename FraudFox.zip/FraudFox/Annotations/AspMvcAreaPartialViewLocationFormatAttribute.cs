﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000061 RID: 97
	[AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
	public sealed class AspMvcAreaPartialViewLocationFormatAttribute : Attribute
	{
		// Token: 0x06000558 RID: 1368 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		public AspMvcAreaPartialViewLocationFormatAttribute(string format)
		{
		}
	}
}
