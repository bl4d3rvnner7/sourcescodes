﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x0200005E RID: 94
	[AttributeUsage(AttributeTargets.Method, Inherited = true)]
	public sealed class PureAttribute : Attribute
	{
	}
}
