﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000073 RID: 115
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter, Inherited = true)]
	public sealed class HtmlAttributeValueAttribute : Attribute
	{
		// Token: 0x06000576 RID: 1398 RVA: 0x0000E2FC File Offset: 0x0000C4FC
		public HtmlAttributeValueAttribute([NotNull] string name)
		{
			this.Name = name;
		}

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x06000577 RID: 1399 RVA: 0x0000E30B File Offset: 0x0000C50B
		// (set) Token: 0x06000578 RID: 1400 RVA: 0x0000E313 File Offset: 0x0000C513
		[NotNull]
		public string Name { get; private set; }
	}
}
