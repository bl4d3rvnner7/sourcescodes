﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x0200006D RID: 109
	[AttributeUsage(AttributeTargets.Parameter)]
	public sealed class AspMvcDisplayTemplateAttribute : Attribute
	{
	}
}
