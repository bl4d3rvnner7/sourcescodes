﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x0200005D RID: 93
	[AttributeUsage(AttributeTargets.Parameter, Inherited = true)]
	public sealed class InstantHandleAttribute : Attribute
	{
	}
}
