﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000056 RID: 86
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Interface, AllowMultiple = false, Inherited = true)]
	public sealed class CannotApplyEqualityOperatorAttribute : Attribute
	{
	}
}
