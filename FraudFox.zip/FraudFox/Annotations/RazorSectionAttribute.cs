﻿using System;

namespace FraudFox.Annotations
{
	// Token: 0x02000074 RID: 116
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Parameter, Inherited = true)]
	public sealed class RazorSectionAttribute : Attribute
	{
	}
}
