﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using Ionic.Zip;
using Ionic.Zlib;
using Microsoft.CSharp.RuntimeBinder;
using Newtonsoft.Json;
using UAParser;

namespace FraudFox
{
	// Token: 0x0200003A RID: 58
	public class ProfileManager
	{
		// Token: 0x06000438 RID: 1080 RVA: 0x0002EFFC File Offset: 0x0002D1FC
		public ProfileManager()
		{
			this.extractPaths.Add(<Module>.smethod_25<string>(1416545553U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_23<string>(2330936310U), <Module>.smethod_27<string>(22474564U)));
			this.extractPaths.Add(<Module>.smethod_23<string>(2106708399U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_27<string>(488691494U), <Module>.smethod_23<string>(3646280324U)));
			this.extractPaths.Add(<Module>.smethod_26<string>(3296316795U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_27<string>(488691494U), <Module>.smethod_26<string>(3317886388U)));
			this.extractPaths.Add(<Module>.smethod_23<string>(1314767266U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_26<string>(3308309994U), <Module>.smethod_27<string>(22474564U)));
			this.extractPaths.Add(<Module>.smethod_26<string>(1172774132U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_25<string>(3849726445U), <Module>.smethod_25<string>(529123491U)));
			this.extractPaths.Add(<Module>.smethod_26<string>(4039277794U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_23<string>(2330936310U), <Module>.smethod_25<string>(529123491U)));
			this.extractPaths.Add(<Module>.smethod_23<string>(2630111280U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_23<string>(2330936310U), <Module>.smethod_23<string>(3646280324U)));
			this.extractPaths.Add(<Module>.smethod_25<string>(4200443673U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_25<string>(3849726445U), <Module>.smethod_24<string>(3602878289U)));
			this.extractPaths.Add(<Module>.smethod_24<string>(2169530649U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_27<string>(488691494U), <Module>.smethod_26<string>(3317886388U)));
			this.extractPaths.Add(<Module>.smethod_23<string>(3700871669U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_26<string>(3308309994U), <Module>.smethod_24<string>(3602878289U)));
			this.extractPaths.Add(<Module>.smethod_24<string>(2752321085U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_23<string>(2330936310U), <Module>.smethod_25<string>(529123491U)));
			this.extractPaths.Add(<Module>.smethod_26<string>(355618786U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_26<string>(3308309994U), <Module>.smethod_26<string>(3317886388U)));
			this.extractPaths.Add(<Module>.smethod_23<string>(629028792U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_23<string>(2330936310U), <Module>.smethod_23<string>(3646280324U)));
			this.extractPaths.Add(<Module>.smethod_25<string>(320331132U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_25<string>(3849726445U), <Module>.smethod_23<string>(3646280324U)));
			this.extractPaths.Add(<Module>.smethod_23<string>(2934736193U), ProfileManager.smethod_3(ProfileManager.smethod_4(), <Module>.smethod_24<string>(2275721734U), <Module>.smethod_23<string>(322862290U)));
			this.extractPaths.Add(<Module>.smethod_23<string>(1263465393U), ProfileManager.smethod_3(this.CurrentPath, <Module>.smethod_26<string>(3308309994U), <Module>.smethod_26<string>(3317886388U)));
		}

		// Token: 0x06000439 RID: 1081 RVA: 0x0002F370 File Offset: 0x0002D570
		public void ImportProfile(string filePath, FFGenerator ffGen)
		{
			ZipFile zipFile = ZipFile.Read(filePath);
			try
			{
				zipFile.ParallelDeflateThreshold = -1L;
				zipFile.Password = <Module>.smethod_23<string>(3578015356U);
				IEnumerator<ZipEntry> enumerator = zipFile.Entries.Where((ZipEntry entry) => this.extractPaths.ContainsKey(entry.FileName)).GetEnumerator();
				try
				{
					while (ProfileManager.smethod_5(enumerator))
					{
						ZipEntry zipEntry = enumerator.Current;
						zipEntry.Extract(this.extractPaths[zipEntry.FileName], ExtractExistingFileAction.OverwriteSilently);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						ProfileManager.smethod_6(enumerator);
					}
				}
				zipFile.FlattenFoldersOnExtract = true;
				enumerator = zipFile.Entries.Where((ZipEntry entry) => ProfileManager.<>c.smethod_0(entry.FileName, <Module>.smethod_25<string>(1183692532U))).GetEnumerator();
				try
				{
					while (ProfileManager.smethod_5(enumerator))
					{
						enumerator.Current.Extract(ProfileManager.smethod_7(this.CurrentPath, <Module>.smethod_24<string>(1159426895U)), ExtractExistingFileAction.DoNotOverwrite);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						ProfileManager.smethod_6(enumerator);
					}
				}
				zipFile.FlattenFoldersOnExtract = false;
				enumerator = zipFile.Entries.Where((ZipEntry entry) => ProfileManager.<>c.smethod_0(entry.FileName, <Module>.smethod_26<string>(4082326154U)) || ProfileManager.<>c.smethod_0(entry.FileName, <Module>.smethod_26<string>(1949207097U))).GetEnumerator();
				try
				{
					while (ProfileManager.smethod_5(enumerator))
					{
						enumerator.Current.Extract(ProfileManager.smethod_3(ProfileManager.smethod_8(Environment.SpecialFolder.ApplicationData), <Module>.smethod_24<string>(2806179646U), <Module>.smethod_27<string>(2500094579U)), ExtractExistingFileAction.OverwriteSilently);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						ProfileManager.smethod_6(enumerator);
					}
				}
				zipFile.FlattenFoldersOnExtract = false;
				enumerator = zipFile.Entries.Where((ZipEntry entry) => ProfileManager.<>c.smethod_0(entry.FileName, <Module>.smethod_25<string>(2506044139U))).GetEnumerator();
				try
				{
					while (ProfileManager.smethod_5(enumerator))
					{
						enumerator.Current.Extract(ProfileManager.smethod_3(ProfileManager.smethod_8(Environment.SpecialFolder.ApplicationData), <Module>.smethod_26<string>(2055383308U), <Module>.smethod_26<string>(4207655153U)), ExtractExistingFileAction.OverwriteSilently);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						ProfileManager.smethod_6(enumerator);
					}
				}
			}
			finally
			{
				if (zipFile != null)
				{
					ProfileManager.smethod_6(zipFile);
				}
			}
			ffGen.Load(ProfileManager.smethod_7(this.extractPaths[<Module>.smethod_24<string>(2576010460U)], <Module>.smethod_25<string>(4229891546U)));
			ffGen.ImportedProfilePath = filePath;
			ffGen.CurrentStatus = string.Empty;
			foreach (string text in ProfileManager.smethod_9(ProfileManager.smethod_7(this.CurrentPath, <Module>.smethod_25<string>(3848397821U)), <Module>.smethod_27<string>(3828138770U)))
			{
				if (!ffGen.FontList.Contains(ProfileManager.smethod_10(text)))
				{
					ProfileManager.smethod_11(text);
				}
			}
		}

		// Token: 0x0600043A RID: 1082 RVA: 0x0002F678 File Offset: 0x0002D878
		public void ExportProfile(string filePath, FFGenerator ffGen)
		{
			ffGen.GenerateFlashConfig(ProfileManager.smethod_12(ProfileManager.smethod_4(), <Module>.smethod_26<string>(2306786357U), <Module>.smethod_24<string>(1869241923U), <Module>.smethod_26<string>(878322723U)));
			ffGen.GenerateFlashMmsConfig(ProfileManager.smethod_12(ProfileManager.smethod_4(), <Module>.smethod_23<string>(4056798455U), <Module>.smethod_26<string>(3021018174U), <Module>.smethod_25<string>(3014557009U)));
			ffGen.GenerateCanvasConfig(ProfileManager.smethod_12(this.CurrentPath, <Module>.smethod_25<string>(3849726445U), <Module>.smethod_26<string>(3317886388U), <Module>.smethod_24<string>(527350426U)));
			ffGen.GenerateHeadersConfig(ProfileManager.smethod_12(this.CurrentPath, <Module>.smethod_25<string>(3849726445U), <Module>.smethod_23<string>(3646280324U), <Module>.smethod_26<string>(307736816U)));
			ffGen.GenerateJsOverrideConfig(ProfileManager.smethod_12(this.CurrentPath, <Module>.smethod_26<string>(3308309994U), <Module>.smethod_27<string>(22474564U), <Module>.smethod_25<string>(4247236373U)));
			ffGen.Save(ProfileManager.smethod_12(this.CurrentPath, <Module>.smethod_27<string>(488691494U), <Module>.smethod_27<string>(22474564U), <Module>.smethod_23<string>(1263465393U)));
			ZipFile zipFile = new ZipFile();
			try
			{
				zipFile.ParallelDeflateThreshold = -1L;
				zipFile.CompressionLevel = CompressionLevel.None;
				zipFile.Password = <Module>.smethod_27<string>(2864150972U);
				foreach (KeyValuePair<string, string> keyValuePair in this.extractPaths)
				{
					if (ProfileManager.smethod_13(ProfileManager.smethod_7(keyValuePair.Value, keyValuePair.Key)))
					{
						zipFile.UpdateFile(ProfileManager.smethod_7(keyValuePair.Value, keyValuePair.Key), "");
					}
				}
				foreach (string text in ProfileManager.smethod_14(ProfileManager.smethod_7(this.CurrentPath, <Module>.smethod_23<string>(829095782U)), <Module>.smethod_27<string>(3828138770U), SearchOption.TopDirectoryOnly))
				{
					if (!zipFile.EntryFileNames.Contains(ProfileManager.smethod_7(<Module>.smethod_23<string>(1333890832U), ProfileManager.smethod_15(text))))
					{
						zipFile.AddFile(text, <Module>.smethod_23<string>(1333890832U));
					}
				}
				zipFile.AddDirectory(ProfileManager.smethod_3(ProfileManager.smethod_8(Environment.SpecialFolder.ApplicationData), <Module>.smethod_26<string>(2055383308U), <Module>.smethod_27<string>(2500094579U)), "");
				zipFile.AddDirectory(ProfileManager.smethod_3(ProfileManager.smethod_8(Environment.SpecialFolder.ApplicationData), <Module>.smethod_26<string>(1350727885U), <Module>.smethod_25<string>(1187678404U)), "");
				zipFile.Save(filePath);
			}
			finally
			{
				if (zipFile != null)
				{
					ProfileManager.smethod_6(zipFile);
				}
			}
		}

		// Token: 0x0600043B RID: 1083 RVA: 0x0002F94C File Offset: 0x0002DB4C
		public void ImportTextProfile(string input, FFGenerator ffGen)
		{
			ProfileManager.<>c__DisplayClass6_0 CS$<>8__locals1 = new ProfileManager.<>c__DisplayClass6_0();
			if (!this.ValidateTextProfile(input))
			{
				throw ProfileManager.smethod_16(<Module>.smethod_23<string>(37360943U));
			}
			object textProfile = this.GetTextProfile(input);
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			if (ProfileManager.<>o__6.<>p__2 == null)
			{
				ProfileManager.<>o__6.<>p__2 = CallSite<Func<CallSite, object, bool>>.Create(ProfileManager.smethod_19(CSharpBinderFlags.None, ExpressionType.IsTrue, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[] { ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null) }));
			}
			Func<CallSite, object, bool> target = ProfileManager.<>o__6.<>p__2.Target;
			CallSite <>p__ = ProfileManager.<>o__6.<>p__2;
			if (ProfileManager.<>o__6.<>p__1 == null)
			{
				ProfileManager.<>o__6.<>p__1 = CallSite<Func<CallSite, object, object, object>>.Create(ProfileManager.smethod_20(CSharpBinderFlags.None, ExpressionType.NotEqual, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			Func<CallSite, object, object, object> target2 = ProfileManager.<>o__6.<>p__1.Target;
			CallSite <>p__2 = ProfileManager.<>o__6.<>p__1;
			if (ProfileManager.<>o__6.<>p__0 == null)
			{
				ProfileManager.<>o__6.<>p__0 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			if (target(<>p__, target2(<>p__2, ProfileManager.<>o__6.<>p__0.Target(ProfileManager.<>o__6.<>p__0, textProfile, <Module>.smethod_27<string>(2071582191U)), null)))
			{
				if (ProfileManager.<>o__6.<>p__11 == null)
				{
					ProfileManager.<>o__6.<>p__11 = CallSite<Func<CallSite, object, IEnumerable>>.Create(ProfileManager.smethod_22(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(IEnumerable).TypeHandle), ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle)));
				}
				Func<CallSite, object, IEnumerable> target3 = ProfileManager.<>o__6.<>p__11.Target;
				CallSite <>p__3 = ProfileManager.<>o__6.<>p__11;
				if (ProfileManager.<>o__6.<>p__6 == null)
				{
					ProfileManager.<>o__6.<>p__6 = CallSite<Func<CallSite, object, char, object>>.Create(ProfileManager.smethod_23(CSharpBinderFlags.None, <Module>.smethod_26<string>(3522897569U), null, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
					{
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
					}));
				}
				Func<CallSite, object, char, object> target4 = ProfileManager.<>o__6.<>p__6.Target;
				CallSite <>p__4 = ProfileManager.<>o__6.<>p__6;
				if (ProfileManager.<>o__6.<>p__5 == null)
				{
					ProfileManager.<>o__6.<>p__5 = CallSite<Func<CallSite, Type, object, object>>.Create(ProfileManager.smethod_23(CSharpBinderFlags.None, <Module>.smethod_24<string>(955675519U), null, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
					{
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, null),
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null)
					}));
				}
				Func<CallSite, Type, object, object> target5 = ProfileManager.<>o__6.<>p__5.Target;
				CallSite <>p__5 = ProfileManager.<>o__6.<>p__5;
				Type type = ProfileManager.smethod_17(typeof(Uri).TypeHandle);
				if (ProfileManager.<>o__6.<>p__4 == null)
				{
					ProfileManager.<>o__6.<>p__4 = CallSite<Func<CallSite, object, object>>.Create(ProfileManager.smethod_23(CSharpBinderFlags.None, <Module>.smethod_23<string>(367482072U), null, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[] { ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null) }));
				}
				Func<CallSite, object, object> target6 = ProfileManager.<>o__6.<>p__4.Target;
				CallSite <>p__6 = ProfileManager.<>o__6.<>p__4;
				if (ProfileManager.<>o__6.<>p__3 == null)
				{
					ProfileManager.<>o__6.<>p__3 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
					{
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
					}));
				}
				IEnumerator enumerator = ProfileManager.smethod_24(target3(<>p__3, target4(<>p__4, target5(<>p__5, type, target6(<>p__6, ProfileManager.<>o__6.<>p__3.Target(ProfileManager.<>o__6.<>p__3, textProfile, <Module>.smethod_25<string>(4167009928U)))), '&')));
				try
				{
					while (ProfileManager.smethod_5(enumerator))
					{
						object obj = ProfileManager.smethod_25(enumerator);
						if (ProfileManager.<>o__6.<>p__7 == null)
						{
							ProfileManager.<>o__6.<>p__7 = CallSite<Func<CallSite, object, char, object>>.Create(ProfileManager.smethod_23(CSharpBinderFlags.None, <Module>.smethod_23<string>(735231451U), null, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
							{
								ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
								ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						object obj2 = ProfileManager.<>o__6.<>p__7.Target(ProfileManager.<>o__6.<>p__7, obj, '=');
						if (ProfileManager.<>o__6.<>p__10 == null)
						{
							ProfileManager.<>o__6.<>p__10 = CallSite<Action<CallSite, Dictionary<string, string>, object, object>>.Create(ProfileManager.smethod_23(CSharpBinderFlags.ResultDiscarded, <Module>.smethod_27<string>(4288584160U), null, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
							{
								ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType, null),
								ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
								ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null)
							}));
						}
						Action<CallSite, Dictionary<string, string>, object, object> target7 = ProfileManager.<>o__6.<>p__10.Target;
						CallSite <>p__7 = ProfileManager.<>o__6.<>p__10;
						Dictionary<string, string> dictionary2 = dictionary;
						if (ProfileManager.<>o__6.<>p__8 == null)
						{
							ProfileManager.<>o__6.<>p__8 = CallSite<Func<CallSite, object, int, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
							{
								ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
								ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						object obj3 = ProfileManager.<>o__6.<>p__8.Target(ProfileManager.<>o__6.<>p__8, obj2, 0);
						if (ProfileManager.<>o__6.<>p__9 == null)
						{
							ProfileManager.<>o__6.<>p__9 = CallSite<Func<CallSite, object, int, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
							{
								ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
								ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						target7(<>p__7, dictionary2, obj3, ProfileManager.<>o__6.<>p__9.Target(ProfileManager.<>o__6.<>p__9, obj2, 1));
					}
				}
				finally
				{
					IDisposable disposable = enumerator as IDisposable;
					if (disposable != null)
					{
						ProfileManager.smethod_6(disposable);
					}
				}
			}
			string[] array = new string[2];
			string text = string.Empty;
			if (dictionary.ContainsKey(<Module>.smethod_26<string>(3542050357U)))
			{
				array = ProfileManager.smethod_26(dictionary[<Module>.smethod_24<string>(1822493702U)], new char[] { 'x' });
				text = dictionary[<Module>.smethod_25<string>(985601880U)];
			}
			else
			{
				string[] array2 = array;
				int num = 0;
				if (ProfileManager.<>o__6.<>p__14 == null)
				{
					ProfileManager.<>o__6.<>p__14 = CallSite<Func<CallSite, object, string>>.Create(ProfileManager.smethod_22(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(string).TypeHandle), ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle)));
				}
				Func<CallSite, object, string> target8 = ProfileManager.<>o__6.<>p__14.Target;
				CallSite <>p__8 = ProfileManager.<>o__6.<>p__14;
				if (ProfileManager.<>o__6.<>p__13 == null)
				{
					ProfileManager.<>o__6.<>p__13 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
					{
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
					}));
				}
				Func<CallSite, object, string, object> target9 = ProfileManager.<>o__6.<>p__13.Target;
				CallSite <>p__9 = ProfileManager.<>o__6.<>p__13;
				if (ProfileManager.<>o__6.<>p__12 == null)
				{
					ProfileManager.<>o__6.<>p__12 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
					{
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
					}));
				}
				array2[num] = target8(<>p__8, target9(<>p__9, ProfileManager.<>o__6.<>p__12.Target(ProfileManager.<>o__6.<>p__12, textProfile, <Module>.smethod_27<string>(552178434U)), <Module>.smethod_24<string>(1009534080U)));
				string[] array3 = array;
				int num2 = 1;
				if (ProfileManager.<>o__6.<>p__17 == null)
				{
					ProfileManager.<>o__6.<>p__17 = CallSite<Func<CallSite, object, string>>.Create(ProfileManager.smethod_22(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(string).TypeHandle), ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle)));
				}
				Func<CallSite, object, string> target10 = ProfileManager.<>o__6.<>p__17.Target;
				CallSite <>p__10 = ProfileManager.<>o__6.<>p__17;
				if (ProfileManager.<>o__6.<>p__16 == null)
				{
					ProfileManager.<>o__6.<>p__16 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
					{
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
					}));
				}
				Func<CallSite, object, string, object> target11 = ProfileManager.<>o__6.<>p__16.Target;
				CallSite <>p__11 = ProfileManager.<>o__6.<>p__16;
				if (ProfileManager.<>o__6.<>p__15 == null)
				{
					ProfileManager.<>o__6.<>p__15 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
					{
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
					}));
				}
				array3[num2] = target10(<>p__10, target11(<>p__11, ProfileManager.<>o__6.<>p__15.Target(ProfileManager.<>o__6.<>p__15, textProfile, <Module>.smethod_23<string>(410044530U)), <Module>.smethod_27<string>(1558743568U)));
				text = ProfileManager.smethod_27(<Module>.smethod_25<string>(561228612U), array[0], array[1]);
			}
			string text2 = string.Empty;
			string text3 = string.Empty;
			if (dictionary.ContainsKey(<Module>.smethod_27<string>(952661559U)))
			{
				text2 = ProfileManager.smethod_28(dictionary[<Module>.smethod_23<string>(3559201231U)], <Module>.smethod_27<string>(859418173U), <Module>.smethod_26<string>(3561203145U));
				text3 = dictionary[<Module>.smethod_24<string>(779364894U)];
			}
			else
			{
				foreach (KeyValuePair<string, string> keyValuePair in ffGen.StaticData.OsVersion)
				{
					if (ProfileManager.<>o__6.<>p__21 == null)
					{
						ProfileManager.<>o__6.<>p__21 = CallSite<Func<CallSite, object, string>>.Create(ProfileManager.smethod_22(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(string).TypeHandle), ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle)));
					}
					Func<CallSite, object, string> target12 = ProfileManager.<>o__6.<>p__21.Target;
					CallSite <>p__12 = ProfileManager.<>o__6.<>p__21;
					if (ProfileManager.<>o__6.<>p__20 == null)
					{
						ProfileManager.<>o__6.<>p__20 = CallSite<Func<CallSite, object, object>>.Create(ProfileManager.smethod_23(CSharpBinderFlags.None, <Module>.smethod_27<string>(1045904945U), new Type[] { ProfileManager.smethod_17(typeof(string).TypeHandle) }, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[] { ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null) }));
					}
					Func<CallSite, object, object> target13 = ProfileManager.<>o__6.<>p__20.Target;
					CallSite <>p__13 = ProfileManager.<>o__6.<>p__20;
					if (ProfileManager.<>o__6.<>p__19 == null)
					{
						ProfileManager.<>o__6.<>p__19 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
						{
							ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
							ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
						}));
					}
					Func<CallSite, object, string, object> target14 = ProfileManager.<>o__6.<>p__19.Target;
					CallSite <>p__14 = ProfileManager.<>o__6.<>p__19;
					if (ProfileManager.<>o__6.<>p__18 == null)
					{
						ProfileManager.<>o__6.<>p__18 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
						{
							ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
							ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
						}));
					}
					if (ProfileManager.smethod_29(target12(<>p__12, target13(<>p__13, target14(<>p__14, ProfileManager.<>o__6.<>p__18.Target(ProfileManager.<>o__6.<>p__18, textProfile, <Module>.smethod_24<string>(733639614U)), <Module>.smethod_24<string>(20263833U)))), keyValuePair.Value))
					{
						text2 = keyValuePair.Value;
						text3 = keyValuePair.Key;
						break;
					}
				}
			}
			if (ProfileManager.smethod_30(text2))
			{
				throw ProfileManager.smethod_16(<Module>.smethod_26<string>(200724728U));
			}
			if (ProfileManager.<>o__6.<>p__26 == null)
			{
				ProfileManager.<>o__6.<>p__26 = CallSite<Func<CallSite, object, int>>.Create(ProfileManager.smethod_22(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(int).TypeHandle), ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle)));
			}
			Func<CallSite, object, int> target15 = ProfileManager.<>o__6.<>p__26.Target;
			CallSite <>p__15 = ProfileManager.<>o__6.<>p__26;
			if (ProfileManager.<>o__6.<>p__25 == null)
			{
				ProfileManager.<>o__6.<>p__25 = CallSite<Func<CallSite, object, int, object>>.Create(ProfileManager.smethod_20(CSharpBinderFlags.None, ExpressionType.Multiply, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			Func<CallSite, object, int, object> target16 = ProfileManager.<>o__6.<>p__25.Target;
			CallSite <>p__16 = ProfileManager.<>o__6.<>p__25;
			if (ProfileManager.<>o__6.<>p__24 == null)
			{
				ProfileManager.<>o__6.<>p__24 = CallSite<Func<CallSite, object, int, object>>.Create(ProfileManager.smethod_20(CSharpBinderFlags.None, ExpressionType.Divide, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			Func<CallSite, object, int, object> target17 = ProfileManager.<>o__6.<>p__24.Target;
			CallSite <>p__17 = ProfileManager.<>o__6.<>p__24;
			if (ProfileManager.<>o__6.<>p__23 == null)
			{
				ProfileManager.<>o__6.<>p__23 = CallSite<Func<CallSite, Type, object, object>>.Create(ProfileManager.smethod_23(CSharpBinderFlags.None, <Module>.smethod_23<string>(3167497225U), null, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null)
				}));
			}
			Func<CallSite, Type, object, object> target18 = ProfileManager.<>o__6.<>p__23.Target;
			CallSite <>p__18 = ProfileManager.<>o__6.<>p__23;
			Type type2 = ProfileManager.smethod_17(typeof(Convert).TypeHandle);
			if (ProfileManager.<>o__6.<>p__22 == null)
			{
				ProfileManager.<>o__6.<>p__22 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			int num3 = target15(<>p__15, target16(<>p__16, target17(<>p__17, target18(<>p__18, type2, ProfileManager.<>o__6.<>p__22.Target(ProfileManager.<>o__6.<>p__22, textProfile, <Module>.smethod_25<string>(2824583531U))), 60), -1));
			if (ProfileManager.<>o__6.<>p__31 == null)
			{
				ProfileManager.<>o__6.<>p__31 = CallSite<Func<CallSite, object, float>>.Create(ProfileManager.smethod_22(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(float).TypeHandle), ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle)));
			}
			Func<CallSite, object, float> target19 = ProfileManager.<>o__6.<>p__31.Target;
			CallSite <>p__19 = ProfileManager.<>o__6.<>p__31;
			if (ProfileManager.<>o__6.<>p__30 == null)
			{
				ProfileManager.<>o__6.<>p__30 = CallSite<Func<CallSite, object, int, object>>.Create(ProfileManager.smethod_20(CSharpBinderFlags.None, ExpressionType.Modulo, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			Func<CallSite, object, int, object> target20 = ProfileManager.<>o__6.<>p__30.Target;
			CallSite <>p__20 = ProfileManager.<>o__6.<>p__30;
			if (ProfileManager.<>o__6.<>p__29 == null)
			{
				ProfileManager.<>o__6.<>p__29 = CallSite<Func<CallSite, object, int, object>>.Create(ProfileManager.smethod_20(CSharpBinderFlags.None, ExpressionType.Multiply, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			Func<CallSite, object, int, object> target21 = ProfileManager.<>o__6.<>p__29.Target;
			CallSite <>p__21 = ProfileManager.<>o__6.<>p__29;
			if (ProfileManager.<>o__6.<>p__28 == null)
			{
				ProfileManager.<>o__6.<>p__28 = CallSite<Func<CallSite, Type, object, object>>.Create(ProfileManager.smethod_23(CSharpBinderFlags.None, <Module>.smethod_27<string>(1972567265U), null, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null)
				}));
			}
			Func<CallSite, Type, object, object> target22 = ProfileManager.<>o__6.<>p__28.Target;
			CallSite <>p__22 = ProfileManager.<>o__6.<>p__28;
			Type type3 = ProfileManager.smethod_17(typeof(Convert).TypeHandle);
			if (ProfileManager.<>o__6.<>p__27 == null)
			{
				ProfileManager.<>o__6.<>p__27 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			float num4 = target19(<>p__19, target20(<>p__20, target21(<>p__21, target22(<>p__22, type3, ProfileManager.<>o__6.<>p__27.Target(ProfileManager.<>o__6.<>p__27, textProfile, <Module>.smethod_25<string>(2824583531U))), -1), 60));
			CS$<>8__locals1.timezone = ProfileManager.smethod_32(<Module>.smethod_27<string>(1599593721U), (num3 > 0) ? <Module>.smethod_23<string>(3138402096U) : <Module>.smethod_23<string>(4067182606U), ProfileManager.smethod_31(num3), (num4 > 0f) ? 30 : 0);
			if (num3 == 0 && ProfileManager.smethod_33(num4) < 1f)
			{
				CS$<>8__locals1.timezone = <Module>.smethod_24<string>(2282832074U);
			}
			string text4;
			if (dictionary.ContainsKey(<Module>.smethod_23<string>(2993029598U)))
			{
				text4 = ProfileManager.smethod_36(ProfileManager.smethod_35(ProfileManager.smethod_28(ProfileManager.smethod_28(ProfileManager.smethod_34(dictionary[<Module>.smethod_24<string>(1876352263U)]), <Module>.smethod_27<string>(2195480769U), string.Empty), <Module>.smethod_27<string>(2655926159U), string.Empty), ',', '.'));
			}
			else
			{
				text4 = <Module>.smethod_23<string>(2366816677U);
			}
			Parser @default = Parser.GetDefault();
			if (ProfileManager.<>o__6.<>p__36 == null)
			{
				ProfileManager.<>o__6.<>p__36 = CallSite<Func<CallSite, object, ClientInfo>>.Create(ProfileManager.smethod_22(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ClientInfo).TypeHandle), ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle)));
			}
			Func<CallSite, object, ClientInfo> target23 = ProfileManager.<>o__6.<>p__36.Target;
			CallSite <>p__23 = ProfileManager.<>o__6.<>p__36;
			if (ProfileManager.<>o__6.<>p__35 == null)
			{
				ProfileManager.<>o__6.<>p__35 = CallSite<Func<CallSite, Parser, object, object>>.Create(ProfileManager.smethod_23(CSharpBinderFlags.None, <Module>.smethod_27<string>(807024940U), null, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null)
				}));
			}
			Func<CallSite, Parser, object, object> target24 = ProfileManager.<>o__6.<>p__35.Target;
			CallSite <>p__24 = ProfileManager.<>o__6.<>p__35;
			Parser parser = @default;
			if (ProfileManager.<>o__6.<>p__34 == null)
			{
				ProfileManager.<>o__6.<>p__34 = CallSite<Func<CallSite, object, object>>.Create(ProfileManager.smethod_23(CSharpBinderFlags.None, <Module>.smethod_27<string>(1931717112U), null, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[] { ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null) }));
			}
			Func<CallSite, object, object> target25 = ProfileManager.<>o__6.<>p__34.Target;
			CallSite <>p__25 = ProfileManager.<>o__6.<>p__34;
			if (ProfileManager.<>o__6.<>p__33 == null)
			{
				ProfileManager.<>o__6.<>p__33 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			Func<CallSite, object, string, object> target26 = ProfileManager.<>o__6.<>p__33.Target;
			CallSite <>p__26 = ProfileManager.<>o__6.<>p__33;
			if (ProfileManager.<>o__6.<>p__32 == null)
			{
				ProfileManager.<>o__6.<>p__32 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			ClientInfo clientInfo = target23(<>p__23, target24(<>p__24, parser, target25(<>p__25, target26(<>p__26, ProfileManager.<>o__6.<>p__32.Target(ProfileManager.<>o__6.<>p__32, textProfile, <Module>.smethod_25<string>(1231813856U)), <Module>.smethod_23<string>(3535246604U)))));
			string text5;
			if (ProfileManager.smethod_29(clientInfo.UserAgent.Family, <Module>.smethod_26<string>(3829342177U)))
			{
				text5 = <Module>.smethod_25<string>(2484568010U);
			}
			else if (ProfileManager.smethod_29(clientInfo.UserAgent.Family, <Module>.smethod_27<string>(458935048U)))
			{
				text5 = <Module>.smethod_27<string>(458935048U);
			}
			else if (ProfileManager.smethod_29(clientInfo.UserAgent.Family, <Module>.smethod_27<string>(900268326U)))
			{
				text5 = <Module>.smethod_27<string>(1822507225U);
			}
			else if (!ProfileManager.smethod_29(clientInfo.UserAgent.Family, <Module>.smethod_23<string>(3931884818U)))
			{
				if (!ProfileManager.smethod_29(clientInfo.UserAgent.Family, <Module>.smethod_25<string>(3180542540U)))
				{
					text5 = clientInfo.UserAgent.Family;
				}
				else
				{
					text5 = <Module>.smethod_23<string>(1320010915U);
				}
			}
			else
			{
				text5 = <Module>.smethod_23<string>(3931884818U);
			}
			string[] array4 = new string[]
			{
				clientInfo.UserAgent.Major,
				clientInfo.UserAgent.Minor,
				clientInfo.UserAgent.Patch
			};
			string text6 = ProfileManager.smethod_37(<Module>.smethod_24<string>(4261372568U), array4.Where((string v) => !ProfileManager.<>c.smethod_1(v)).ToArray<string>());
			CS$<>8__locals1.lang = string.Empty;
			if (dictionary.ContainsKey(<Module>.smethod_25<string>(130357654U)))
			{
				CS$<>8__locals1.lang = dictionary[<Module>.smethod_25<string>(130357654U)];
			}
			else
			{
				if (ProfileManager.<>o__6.<>p__40 == null)
				{
					ProfileManager.<>o__6.<>p__40 = CallSite<Func<CallSite, object, bool>>.Create(ProfileManager.smethod_19(CSharpBinderFlags.None, ExpressionType.IsTrue, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[] { ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null) }));
				}
				Func<CallSite, object, bool> target27 = ProfileManager.<>o__6.<>p__40.Target;
				CallSite <>p__27 = ProfileManager.<>o__6.<>p__40;
				if (ProfileManager.<>o__6.<>p__39 == null)
				{
					ProfileManager.<>o__6.<>p__39 = CallSite<Func<CallSite, object, object, object>>.Create(ProfileManager.smethod_20(CSharpBinderFlags.None, ExpressionType.NotEqual, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
					{
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.Constant, null)
					}));
				}
				Func<CallSite, object, object, object> target28 = ProfileManager.<>o__6.<>p__39.Target;
				CallSite <>p__28 = ProfileManager.<>o__6.<>p__39;
				if (ProfileManager.<>o__6.<>p__38 == null)
				{
					ProfileManager.<>o__6.<>p__38 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
					{
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
					}));
				}
				Func<CallSite, object, string, object> target29 = ProfileManager.<>o__6.<>p__38.Target;
				CallSite <>p__29 = ProfileManager.<>o__6.<>p__38;
				if (ProfileManager.<>o__6.<>p__37 == null)
				{
					ProfileManager.<>o__6.<>p__37 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
					{
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
						ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
					}));
				}
				if (target27(<>p__27, target28(<>p__28, target29(<>p__29, ProfileManager.<>o__6.<>p__37.Target(ProfileManager.<>o__6.<>p__37, textProfile, <Module>.smethod_26<string>(1345985101U)), <Module>.smethod_24<string>(74122394U)), null)))
				{
					ProfileManager.<>c__DisplayClass6_0 CS$<>8__locals2 = CS$<>8__locals1;
					if (ProfileManager.<>o__6.<>p__43 == null)
					{
						ProfileManager.<>o__6.<>p__43 = CallSite<Func<CallSite, object, string>>.Create(ProfileManager.smethod_22(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(string).TypeHandle), ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle)));
					}
					Func<CallSite, object, string> target30 = ProfileManager.<>o__6.<>p__43.Target;
					CallSite <>p__30 = ProfileManager.<>o__6.<>p__43;
					if (ProfileManager.<>o__6.<>p__42 == null)
					{
						ProfileManager.<>o__6.<>p__42 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
						{
							ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
							ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
						}));
					}
					Func<CallSite, object, string, object> target31 = ProfileManager.<>o__6.<>p__42.Target;
					CallSite <>p__31 = ProfileManager.<>o__6.<>p__42;
					if (ProfileManager.<>o__6.<>p__41 == null)
					{
						ProfileManager.<>o__6.<>p__41 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
						{
							ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
							ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
						}));
					}
					CS$<>8__locals2.lang = target30(<>p__30, target31(<>p__31, ProfileManager.<>o__6.<>p__41.Target(ProfileManager.<>o__6.<>p__41, textProfile, <Module>.smethod_27<string>(225826583U)), <Module>.smethod_24<string>(74122394U)));
				}
			}
			if (ProfileManager.<>o__6.<>p__47 == null)
			{
				ProfileManager.<>o__6.<>p__47 = CallSite<Func<CallSite, object, string>>.Create(ProfileManager.smethod_22(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(string).TypeHandle), ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle)));
			}
			Func<CallSite, object, string> target32 = ProfileManager.<>o__6.<>p__47.Target;
			CallSite <>p__32 = ProfileManager.<>o__6.<>p__47;
			if (ProfileManager.<>o__6.<>p__46 == null)
			{
				ProfileManager.<>o__6.<>p__46 = CallSite<Func<CallSite, object, object>>.Create(ProfileManager.smethod_23(CSharpBinderFlags.None, <Module>.smethod_24<string>(1592324516U), new Type[] { ProfileManager.smethod_17(typeof(string).TypeHandle) }, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[] { ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null) }));
			}
			Func<CallSite, object, object> target33 = ProfileManager.<>o__6.<>p__46.Target;
			CallSite <>p__33 = ProfileManager.<>o__6.<>p__46;
			if (ProfileManager.<>o__6.<>p__45 == null)
			{
				ProfileManager.<>o__6.<>p__45 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			Func<CallSite, object, string, object> target34 = ProfileManager.<>o__6.<>p__45.Target;
			CallSite <>p__34 = ProfileManager.<>o__6.<>p__45;
			if (ProfileManager.<>o__6.<>p__44 == null)
			{
				ProfileManager.<>o__6.<>p__44 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			string text7 = target32(<>p__32, target33(<>p__33, target34(<>p__34, ProfileManager.<>o__6.<>p__44.Target(ProfileManager.<>o__6.<>p__44, textProfile, <Module>.smethod_27<string>(225826583U)), <Module>.smethod_23<string>(3535246604U))));
			if (ProfileManager.<>o__6.<>p__51 == null)
			{
				ProfileManager.<>o__6.<>p__51 = CallSite<Func<CallSite, object, string>>.Create(ProfileManager.smethod_22(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(string).TypeHandle), ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle)));
			}
			Func<CallSite, object, string> target35 = ProfileManager.<>o__6.<>p__51.Target;
			CallSite <>p__35 = ProfileManager.<>o__6.<>p__51;
			if (ProfileManager.<>o__6.<>p__50 == null)
			{
				ProfileManager.<>o__6.<>p__50 = CallSite<Func<CallSite, object, object>>.Create(ProfileManager.smethod_23(CSharpBinderFlags.None, <Module>.smethod_26<string>(694699483U), new Type[] { ProfileManager.smethod_17(typeof(string).TypeHandle) }, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[] { ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null) }));
			}
			Func<CallSite, object, object> target36 = ProfileManager.<>o__6.<>p__50.Target;
			CallSite <>p__36 = ProfileManager.<>o__6.<>p__50;
			if (ProfileManager.<>o__6.<>p__49 == null)
			{
				ProfileManager.<>o__6.<>p__49 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			Func<CallSite, object, string, object> target37 = ProfileManager.<>o__6.<>p__49.Target;
			CallSite <>p__37 = ProfileManager.<>o__6.<>p__49;
			if (ProfileManager.<>o__6.<>p__48 == null)
			{
				ProfileManager.<>o__6.<>p__48 = CallSite<Func<CallSite, object, string, object>>.Create(ProfileManager.smethod_21(CSharpBinderFlags.None, ProfileManager.smethod_17(typeof(ProfileManager).TypeHandle), new CSharpArgumentInfo[]
				{
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.None, null),
					ProfileManager.smethod_18(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			string text8 = target35(<>p__35, target36(<>p__36, target37(<>p__37, ProfileManager.<>o__6.<>p__48.Target(ProfileManager.<>o__6.<>p__48, textProfile, <Module>.smethod_24<string>(733639614U)), <Module>.smethod_26<string>(3124686754U))));
			int num5 = 32;
			if (ProfileManager.smethod_29(text7, <Module>.smethod_27<string>(4216180069U)) || ProfileManager.smethod_29(text8, <Module>.smethod_23<string>(904558576U)))
			{
				num5 = 64;
			}
			if (!ffGen.StaticData.OsVersion.ContainsKey(text3))
			{
				ffGen.StaticData.OsVersion.Add(text3, text2);
				ProfileManager.smethod_38(ffGen.StaticData.OsVersionBindingSource, new KeyValuePair<string, string>(text3, text2));
			}
			if (!ffGen.StaticData.OsLanguage.ContainsValue(CS$<>8__locals1.lang))
			{
				ffGen.StaticData.OsLanguage.Add(CS$<>8__locals1.lang, CS$<>8__locals1.lang);
				ProfileManager.smethod_38(ffGen.StaticData.OsLanguageBindingSource, new KeyValuePair<string, string>(CS$<>8__locals1.lang, CS$<>8__locals1.lang));
			}
			KeyValuePair<string, string> keyValuePair2 = ffGen.StaticData.OsTimezone.FirstOrDefault((KeyValuePair<string, string> x) => ProfileManager.<>c__DisplayClass6_0.smethod_0(x.Key, CS$<>8__locals1.timezone));
			if (keyValuePair2.Equals(null))
			{
				ffGen.StaticData.OsTimezone.Add(CS$<>8__locals1.timezone, CS$<>8__locals1.timezone);
				ProfileManager.smethod_38(ffGen.StaticData.OsTimezoneBindingSource, new KeyValuePair<string, string>(CS$<>8__locals1.timezone, CS$<>8__locals1.timezone));
			}
			else
			{
				CS$<>8__locals1.timezone = keyValuePair2.Value;
			}
			if (!ffGen.StaticData.OsResolution.ContainsKey(text))
			{
				ffGen.StaticData.OsResolution.Add(text, new Size(ProfileManager.smethod_39(array[0]), ProfileManager.smethod_39(array[1])));
				ffGen.StaticData.OsResolutionBindingSource.Add(new KeyValuePair<string, Size>(text, new Size(Convert.ToInt32(array[0]), Convert.ToInt32(array[1]))));
			}
			if (!ffGen.StaticData.BrowserProduct.Contains(text5))
			{
				ffGen.StaticData.BrowserProduct.Add(text5);
				ffGen.StaticData.BrowserProductBindingSource.Add(text5);
			}
			if (!ffGen.StaticData.BrowserVersion.ContainsKey(text5))
			{
				ffGen.StaticData.BrowserVersion.Add(text5, new List<string>());
				ffGen.StaticData.BrowserVersionBindingSource.Add(new KeyValuePair<string, List<string>>(text5, ffGen.StaticData.BrowserVersion[text5]));
			}
			if (!ffGen.StaticData.BrowserVersion[text5].Contains(text6))
			{
				ffGen.StaticData.BrowserVersion[text5].Add(text6);
			}
			if (!ffGen.StaticData.BrowserFlash.Contains(text4))
			{
				ffGen.StaticData.BrowserFlash.Add(text4);
				ffGen.StaticData.BrowserFlashBindingSource.Add(text4);
			}
			ffGen.OsVersion = ffGen.StaticData.OsVersion[text3];
			ffGen.OsPlatform = num5;
			ffGen.OsLanguage = ffGen.StaticData.OsLanguage.FirstOrDefault((KeyValuePair<string, string> x) => ProfileManager.<>c__DisplayClass6_0.smethod_1(x.Value, CS$<>8__locals1.lang)).Value;
			ffGen.OsTimezone = CS$<>8__locals1.timezone;
			ffGen.OsResolution = new Size(Convert.ToInt32(array[0]), Convert.ToInt32(array[1]));
			ffGen.BrowserProduct = text5;
			ffGen.BrowserVersion = text6;
			ffGen.BrowserFlash = text4;
			if (ProfileManager.<>o__6.<>p__54 == null)
			{
				ProfileManager.<>o__6.<>p__54 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(ProfileManager), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
			}
			Func<CallSite, object, bool> target38 = ProfileManager.<>o__6.<>p__54.Target;
			CallSite <>p__38 = ProfileManager.<>o__6.<>p__54;
			if (ProfileManager.<>o__6.<>p__53 == null)
			{
				ProfileManager.<>o__6.<>p__53 = CallSite<Func<CallSite, object, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof(ProfileManager), new CSharpArgumentInfo[]
				{
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			Func<CallSite, object, object, object> target39 = ProfileManager.<>o__6.<>p__53.Target;
			CallSite <>p__39 = ProfileManager.<>o__6.<>p__53;
			if (ProfileManager.<>o__6.<>p__52 == null)
			{
				ProfileManager.<>o__6.<>p__52 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
				{
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			if (target38(<>p__38, target39(<>p__39, ProfileManager.<>o__6.<>p__52.Target(ProfileManager.<>o__6.<>p__52, textProfile, <Module>.smethod_25<string>(339150013U)), null)))
			{
				if (ProfileManager.<>o__6.<>p__57 == null)
				{
					ProfileManager.<>o__6.<>p__57 = CallSite<Func<CallSite, object, List<string>>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.None, typeof(List<string>), typeof(ProfileManager)));
				}
				Func<CallSite, object, List<string>> target40 = ProfileManager.<>o__6.<>p__57.Target;
				CallSite <>p__40 = ProfileManager.<>o__6.<>p__57;
				if (ProfileManager.<>o__6.<>p__56 == null)
				{
					ProfileManager.<>o__6.<>p__56 = CallSite<Func<CallSite, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(CSharpBinderFlags.None, <Module>.smethod_26<string>(694699483U), new Type[] { typeof(List<string>) }, typeof(ProfileManager), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
				}
				Func<CallSite, object, object> target41 = ProfileManager.<>o__6.<>p__56.Target;
				CallSite <>p__41 = ProfileManager.<>o__6.<>p__56;
				if (ProfileManager.<>o__6.<>p__55 == null)
				{
					ProfileManager.<>o__6.<>p__55 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
					}));
				}
				ffGen.FontList = target40(<>p__40, target41(<>p__41, ProfileManager.<>o__6.<>p__55.Target(ProfileManager.<>o__6.<>p__55, textProfile, <Module>.smethod_23<string>(2026620838U))));
			}
			if (ProfileManager.<>o__6.<>p__61 == null)
			{
				ProfileManager.<>o__6.<>p__61 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(ProfileManager), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
			}
			Func<CallSite, object, bool> target42 = ProfileManager.<>o__6.<>p__61.Target;
			CallSite <>p__42 = ProfileManager.<>o__6.<>p__61;
			if (ProfileManager.<>o__6.<>p__60 == null)
			{
				ProfileManager.<>o__6.<>p__60 = CallSite<Func<CallSite, object, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof(ProfileManager), new CSharpArgumentInfo[]
				{
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			Func<CallSite, object, object, object> target43 = ProfileManager.<>o__6.<>p__60.Target;
			CallSite <>p__43 = ProfileManager.<>o__6.<>p__60;
			if (ProfileManager.<>o__6.<>p__59 == null)
			{
				ProfileManager.<>o__6.<>p__59 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
				{
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			Func<CallSite, object, string, object> target44 = ProfileManager.<>o__6.<>p__59.Target;
			CallSite <>p__44 = ProfileManager.<>o__6.<>p__59;
			if (ProfileManager.<>o__6.<>p__58 == null)
			{
				ProfileManager.<>o__6.<>p__58 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
				{
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			if (target42(<>p__42, target43(<>p__43, target44(<>p__44, ProfileManager.<>o__6.<>p__58.Target(ProfileManager.<>o__6.<>p__58, textProfile, <Module>.smethod_27<string>(225826583U)), <Module>.smethod_27<string>(3889828218U)), null)))
			{
				List<BrowserPluginInfo> list = new List<BrowserPluginInfo>();
				for (int i = 0; i < 25; i++)
				{
					string text9 = i.ToString();
					BrowserPluginInfo browserPluginInfo = default(BrowserPluginInfo);
					try
					{
						if (ProfileManager.<>o__6.<>p__66 == null)
						{
							ProfileManager.<>o__6.<>p__66 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(ProfileManager), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
						}
						Func<CallSite, object, bool> target45 = ProfileManager.<>o__6.<>p__66.Target;
						CallSite <>p__45 = ProfileManager.<>o__6.<>p__66;
						if (ProfileManager.<>o__6.<>p__65 == null)
						{
							ProfileManager.<>o__6.<>p__65 = CallSite<Func<CallSite, object, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						Func<CallSite, object, object, object> target46 = ProfileManager.<>o__6.<>p__65.Target;
						CallSite <>p__46 = ProfileManager.<>o__6.<>p__65;
						if (ProfileManager.<>o__6.<>p__64 == null)
						{
							ProfileManager.<>o__6.<>p__64 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null)
							}));
						}
						Func<CallSite, object, string, object> target47 = ProfileManager.<>o__6.<>p__64.Target;
						CallSite <>p__47 = ProfileManager.<>o__6.<>p__64;
						if (ProfileManager.<>o__6.<>p__63 == null)
						{
							ProfileManager.<>o__6.<>p__63 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						Func<CallSite, object, string, object> target48 = ProfileManager.<>o__6.<>p__63.Target;
						CallSite <>p__48 = ProfileManager.<>o__6.<>p__63;
						if (ProfileManager.<>o__6.<>p__62 == null)
						{
							ProfileManager.<>o__6.<>p__62 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						if (target45(<>p__45, target46(<>p__46, target47(<>p__47, target48(<>p__48, ProfileManager.<>o__6.<>p__62.Target(ProfileManager.<>o__6.<>p__62, textProfile, <Module>.smethod_24<string>(733639614U)), <Module>.smethod_27<string>(3889828218U)), text9), null)))
						{
							break;
						}
						if (ProfileManager.<>o__6.<>p__71 == null)
						{
							ProfileManager.<>o__6.<>p__71 = CallSite<Func<CallSite, object, string>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.None, typeof(string), typeof(ProfileManager)));
						}
						Func<CallSite, object, string> target49 = ProfileManager.<>o__6.<>p__71.Target;
						CallSite <>p__49 = ProfileManager.<>o__6.<>p__71;
						if (ProfileManager.<>o__6.<>p__70 == null)
						{
							ProfileManager.<>o__6.<>p__70 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						Func<CallSite, object, string, object> target50 = ProfileManager.<>o__6.<>p__70.Target;
						CallSite <>p__50 = ProfileManager.<>o__6.<>p__70;
						if (ProfileManager.<>o__6.<>p__69 == null)
						{
							ProfileManager.<>o__6.<>p__69 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null)
							}));
						}
						Func<CallSite, object, string, object> target51 = ProfileManager.<>o__6.<>p__69.Target;
						CallSite <>p__51 = ProfileManager.<>o__6.<>p__69;
						if (ProfileManager.<>o__6.<>p__68 == null)
						{
							ProfileManager.<>o__6.<>p__68 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						Func<CallSite, object, string, object> target52 = ProfileManager.<>o__6.<>p__68.Target;
						CallSite <>p__52 = ProfileManager.<>o__6.<>p__68;
						if (ProfileManager.<>o__6.<>p__67 == null)
						{
							ProfileManager.<>o__6.<>p__67 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						browserPluginInfo.Description = target49(<>p__49, target50(<>p__50, target51(<>p__51, target52(<>p__52, ProfileManager.<>o__6.<>p__67.Target(ProfileManager.<>o__6.<>p__67, textProfile, <Module>.smethod_27<string>(225826583U)), <Module>.smethod_25<string>(1174319449U)), text9), <Module>.smethod_26<string>(10868602U)));
						if (ProfileManager.<>o__6.<>p__76 == null)
						{
							ProfileManager.<>o__6.<>p__76 = CallSite<Func<CallSite, object, string>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.None, typeof(string), typeof(ProfileManager)));
						}
						Func<CallSite, object, string> target53 = ProfileManager.<>o__6.<>p__76.Target;
						CallSite <>p__53 = ProfileManager.<>o__6.<>p__76;
						if (ProfileManager.<>o__6.<>p__75 == null)
						{
							ProfileManager.<>o__6.<>p__75 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						Func<CallSite, object, string, object> target54 = ProfileManager.<>o__6.<>p__75.Target;
						CallSite <>p__54 = ProfileManager.<>o__6.<>p__75;
						if (ProfileManager.<>o__6.<>p__74 == null)
						{
							ProfileManager.<>o__6.<>p__74 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null)
							}));
						}
						Func<CallSite, object, string, object> target55 = ProfileManager.<>o__6.<>p__74.Target;
						CallSite <>p__55 = ProfileManager.<>o__6.<>p__74;
						if (ProfileManager.<>o__6.<>p__73 == null)
						{
							ProfileManager.<>o__6.<>p__73 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						Func<CallSite, object, string, object> target56 = ProfileManager.<>o__6.<>p__73.Target;
						CallSite <>p__56 = ProfileManager.<>o__6.<>p__73;
						if (ProfileManager.<>o__6.<>p__72 == null)
						{
							ProfileManager.<>o__6.<>p__72 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						browserPluginInfo.Filename = target53(<>p__53, target54(<>p__54, target55(<>p__55, target56(<>p__56, ProfileManager.<>o__6.<>p__72.Target(ProfileManager.<>o__6.<>p__72, textProfile, <Module>.smethod_24<string>(733639614U)), <Module>.smethod_25<string>(1174319449U)), text9), <Module>.smethod_27<string>(4020397082U)));
						if (ProfileManager.<>o__6.<>p__81 == null)
						{
							ProfileManager.<>o__6.<>p__81 = CallSite<Func<CallSite, object, string>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.None, typeof(string), typeof(ProfileManager)));
						}
						Func<CallSite, object, string> target57 = ProfileManager.<>o__6.<>p__81.Target;
						CallSite <>p__57 = ProfileManager.<>o__6.<>p__81;
						if (ProfileManager.<>o__6.<>p__80 == null)
						{
							ProfileManager.<>o__6.<>p__80 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						Func<CallSite, object, string, object> target58 = ProfileManager.<>o__6.<>p__80.Target;
						CallSite <>p__58 = ProfileManager.<>o__6.<>p__80;
						if (ProfileManager.<>o__6.<>p__79 == null)
						{
							ProfileManager.<>o__6.<>p__79 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null)
							}));
						}
						Func<CallSite, object, string, object> target59 = ProfileManager.<>o__6.<>p__79.Target;
						CallSite <>p__59 = ProfileManager.<>o__6.<>p__79;
						if (ProfileManager.<>o__6.<>p__78 == null)
						{
							ProfileManager.<>o__6.<>p__78 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						Func<CallSite, object, string, object> target60 = ProfileManager.<>o__6.<>p__78.Target;
						CallSite <>p__60 = ProfileManager.<>o__6.<>p__78;
						if (ProfileManager.<>o__6.<>p__77 == null)
						{
							ProfileManager.<>o__6.<>p__77 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						browserPluginInfo.Name = target57(<>p__57, target58(<>p__58, target59(<>p__59, target60(<>p__60, ProfileManager.<>o__6.<>p__77.Target(ProfileManager.<>o__6.<>p__77, textProfile, <Module>.smethod_27<string>(225826583U)), <Module>.smethod_23<string>(169059818U)), text9), <Module>.smethod_27<string>(4160262161U)));
						browserPluginInfo.MimeType = new List<string>();
						for (int j = 0; j < 5; j++)
						{
							string text10 = j.ToString();
							if (ProfileManager.<>o__6.<>p__95 == null)
							{
								ProfileManager.<>o__6.<>p__95 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(ProfileManager), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
							}
							Func<CallSite, object, bool> target61 = ProfileManager.<>o__6.<>p__95.Target;
							CallSite <>p__61 = ProfileManager.<>o__6.<>p__95;
							if (ProfileManager.<>o__6.<>p__86 == null)
							{
								ProfileManager.<>o__6.<>p__86 = CallSite<Func<CallSite, object, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof(ProfileManager), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, null)
								}));
							}
							Func<CallSite, object, object, object> target62 = ProfileManager.<>o__6.<>p__86.Target;
							CallSite <>p__62 = ProfileManager.<>o__6.<>p__86;
							if (ProfileManager.<>o__6.<>p__85 == null)
							{
								ProfileManager.<>o__6.<>p__85 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null)
								}));
							}
							Func<CallSite, object, string, object> target63 = ProfileManager.<>o__6.<>p__85.Target;
							CallSite <>p__63 = ProfileManager.<>o__6.<>p__85;
							if (ProfileManager.<>o__6.<>p__84 == null)
							{
								ProfileManager.<>o__6.<>p__84 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null)
								}));
							}
							Func<CallSite, object, string, object> target64 = ProfileManager.<>o__6.<>p__84.Target;
							CallSite <>p__64 = ProfileManager.<>o__6.<>p__84;
							if (ProfileManager.<>o__6.<>p__83 == null)
							{
								ProfileManager.<>o__6.<>p__83 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
								}));
							}
							Func<CallSite, object, string, object> target65 = ProfileManager.<>o__6.<>p__83.Target;
							CallSite <>p__65 = ProfileManager.<>o__6.<>p__83;
							if (ProfileManager.<>o__6.<>p__82 == null)
							{
								ProfileManager.<>o__6.<>p__82 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
								}));
							}
							object obj4 = target62(<>p__62, target63(<>p__63, target64(<>p__64, target65(<>p__65, ProfileManager.<>o__6.<>p__82.Target(ProfileManager.<>o__6.<>p__82, textProfile, <Module>.smethod_25<string>(1231813856U)), <Module>.smethod_24<string>(127980955U)), text9), text10), null);
							if (ProfileManager.<>o__6.<>p__94 == null)
							{
								ProfileManager.<>o__6.<>p__94 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsFalse, typeof(ProfileManager), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
							}
							object obj6;
							if (!ProfileManager.<>o__6.<>p__94.Target(ProfileManager.<>o__6.<>p__94, obj4))
							{
								if (ProfileManager.<>o__6.<>p__93 == null)
								{
									ProfileManager.<>o__6.<>p__93 = CallSite<Func<CallSite, object, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.BinaryOperationLogical, ExpressionType.And, typeof(ProfileManager), new CSharpArgumentInfo[]
									{
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
									}));
								}
								Func<CallSite, object, object, object> target66 = ProfileManager.<>o__6.<>p__93.Target;
								CallSite <>p__66 = ProfileManager.<>o__6.<>p__93;
								object obj5 = obj4;
								if (ProfileManager.<>o__6.<>p__92 == null)
								{
									ProfileManager.<>o__6.<>p__92 = CallSite<Func<CallSite, object, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof(ProfileManager), new CSharpArgumentInfo[]
									{
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, null)
									}));
								}
								Func<CallSite, object, object, object> target67 = ProfileManager.<>o__6.<>p__92.Target;
								CallSite <>p__67 = ProfileManager.<>o__6.<>p__92;
								if (ProfileManager.<>o__6.<>p__91 == null)
								{
									ProfileManager.<>o__6.<>p__91 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
									{
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
									}));
								}
								Func<CallSite, object, string, object> target68 = ProfileManager.<>o__6.<>p__91.Target;
								CallSite <>p__68 = ProfileManager.<>o__6.<>p__91;
								if (ProfileManager.<>o__6.<>p__90 == null)
								{
									ProfileManager.<>o__6.<>p__90 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
									{
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null)
									}));
								}
								Func<CallSite, object, string, object> target69 = ProfileManager.<>o__6.<>p__90.Target;
								CallSite <>p__69 = ProfileManager.<>o__6.<>p__90;
								if (ProfileManager.<>o__6.<>p__89 == null)
								{
									ProfileManager.<>o__6.<>p__89 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
									{
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null)
									}));
								}
								Func<CallSite, object, string, object> target70 = ProfileManager.<>o__6.<>p__89.Target;
								CallSite <>p__70 = ProfileManager.<>o__6.<>p__89;
								if (ProfileManager.<>o__6.<>p__88 == null)
								{
									ProfileManager.<>o__6.<>p__88 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
									{
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
									}));
								}
								Func<CallSite, object, string, object> target71 = ProfileManager.<>o__6.<>p__88.Target;
								CallSite <>p__71 = ProfileManager.<>o__6.<>p__88;
								if (ProfileManager.<>o__6.<>p__87 == null)
								{
									ProfileManager.<>o__6.<>p__87 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
									{
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
									}));
								}
								obj6 = target66(<>p__66, obj5, target67(<>p__67, target68(<>p__68, target69(<>p__69, target70(<>p__70, target71(<>p__71, ProfileManager.<>o__6.<>p__87.Target(ProfileManager.<>o__6.<>p__87, textProfile, <Module>.smethod_25<string>(1231813856U)), <Module>.smethod_26<string>(3143839542U)), text9), text10), <Module>.smethod_26<string>(1001144091U)), null));
							}
							else
							{
								obj6 = obj4;
							}
							if (!target61(<>p__61, obj6))
							{
								break;
							}
							if (ProfileManager.<>o__6.<>p__102 == null)
							{
								ProfileManager.<>o__6.<>p__102 = CallSite<Action<CallSite, List<string>, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, <Module>.smethod_24<string>(262630149U), null, typeof(ProfileManager), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null),
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
								}));
							}
							Action<CallSite, List<string>, object> target72 = ProfileManager.<>o__6.<>p__102.Target;
							CallSite <>p__72 = ProfileManager.<>o__6.<>p__102;
							List<string> mimeType = browserPluginInfo.MimeType;
							if (ProfileManager.<>o__6.<>p__101 == null)
							{
								ProfileManager.<>o__6.<>p__101 = CallSite<Func<CallSite, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(CSharpBinderFlags.None, <Module>.smethod_23<string>(2437138969U), new Type[] { typeof(string) }, typeof(ProfileManager), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
							}
							Func<CallSite, object, object> target73 = ProfileManager.<>o__6.<>p__101.Target;
							CallSite <>p__73 = ProfileManager.<>o__6.<>p__101;
							if (ProfileManager.<>o__6.<>p__100 == null)
							{
								ProfileManager.<>o__6.<>p__100 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
								}));
							}
							Func<CallSite, object, string, object> target74 = ProfileManager.<>o__6.<>p__100.Target;
							CallSite <>p__74 = ProfileManager.<>o__6.<>p__100;
							if (ProfileManager.<>o__6.<>p__99 == null)
							{
								ProfileManager.<>o__6.<>p__99 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null)
								}));
							}
							Func<CallSite, object, string, object> target75 = ProfileManager.<>o__6.<>p__99.Target;
							CallSite <>p__75 = ProfileManager.<>o__6.<>p__99;
							if (ProfileManager.<>o__6.<>p__98 == null)
							{
								ProfileManager.<>o__6.<>p__98 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null)
								}));
							}
							Func<CallSite, object, string, object> target76 = ProfileManager.<>o__6.<>p__98.Target;
							CallSite <>p__76 = ProfileManager.<>o__6.<>p__98;
							if (ProfileManager.<>o__6.<>p__97 == null)
							{
								ProfileManager.<>o__6.<>p__97 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
								}));
							}
							Func<CallSite, object, string, object> target77 = ProfileManager.<>o__6.<>p__97.Target;
							CallSite <>p__77 = ProfileManager.<>o__6.<>p__97;
							if (ProfileManager.<>o__6.<>p__96 == null)
							{
								ProfileManager.<>o__6.<>p__96 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
								}));
							}
							target72(<>p__72, mimeType, target73(<>p__73, target74(<>p__74, target75(<>p__75, target76(<>p__76, target77(<>p__77, ProfileManager.<>o__6.<>p__96.Target(ProfileManager.<>o__6.<>p__96, textProfile, <Module>.smethod_24<string>(733639614U)), <Module>.smethod_26<string>(3143839542U)), text9), text10), <Module>.smethod_27<string>(4029693297U))));
						}
					}
					catch
					{
					}
					list.Add(browserPluginInfo);
				}
				ffGen.PluginList = list;
			}
			Random random = new Random();
			string text11 = string.Format(<Module>.smethod_24<string>(2398173798U), random.Next(16777216));
			string text12 = string.Format(<Module>.smethod_25<string>(3382619064U), random.Next(16777216));
			int num6 = random.Next(5, 25);
			string text13;
			if (ffGen.FontList.Count > 0)
			{
				text13 = ffGen.FontList[random.Next(0, ffGen.FontList.Count)];
			}
			else
			{
				string[] array5 = new string[]
				{
					<Module>.smethod_23<string>(2550023719U),
					<Module>.smethod_24<string>(3230440890U),
					<Module>.smethod_23<string>(3111054850U),
					<Module>.smethod_23<string>(1427961457U),
					<Module>.smethod_27<string>(521523242U)
				};
				text13 = array5[random.Next(0, array5.Length)];
			}
			ffGen.BrowserCanvasStroke = text11;
			ffGen.BrowserCanvasFill = text12;
			ffGen.BrowserCanvasFontSize = num6;
			ffGen.BrowserCanvasFont = text13;
			ffGen.GenerateFlashConfig(Path.Combine(Environment.SystemDirectory, <Module>.smethod_25<string>(1314770264U), <Module>.smethod_23<string>(322862290U), <Module>.smethod_23<string>(2934736193U)));
			ffGen.GenerateFlashMmsConfig(Path.Combine(Environment.SystemDirectory, <Module>.smethod_23<string>(4056798455U), <Module>.smethod_26<string>(3021018174U), <Module>.smethod_25<string>(3014557009U)));
			ffGen.GenerateCanvasConfig(Path.Combine(this.CurrentPath, <Module>.smethod_25<string>(3849726445U), <Module>.smethod_23<string>(3646280324U), <Module>.smethod_27<string>(162339643U)));
			if (ProfileManager.<>o__6.<>p__105 == null)
			{
				ProfileManager.<>o__6.<>p__105 = CallSite<Action<CallSite, Type, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, <Module>.smethod_25<string>(1690949493U), null, typeof(ProfileManager), new CSharpArgumentInfo[]
				{
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.IsStaticType, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
				}));
			}
			Action<CallSite, Type, string, object> target78 = ProfileManager.<>o__6.<>p__105.Target;
			CallSite <>p__78 = ProfileManager.<>o__6.<>p__105;
			Type typeFromHandle = typeof(File);
			string text14 = Path.Combine(this.CurrentPath, <Module>.smethod_23<string>(2330936310U), <Module>.smethod_23<string>(3646280324U), <Module>.smethod_23<string>(629028792U));
			if (ProfileManager.<>o__6.<>p__104 == null)
			{
				ProfileManager.<>o__6.<>p__104 = CallSite<Func<CallSite, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(CSharpBinderFlags.None, <Module>.smethod_24<string>(725506333U), null, typeof(ProfileManager), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
			}
			Func<CallSite, object, object> target79 = ProfileManager.<>o__6.<>p__104.Target;
			CallSite <>p__79 = ProfileManager.<>o__6.<>p__104;
			if (ProfileManager.<>o__6.<>p__103 == null)
			{
				ProfileManager.<>o__6.<>p__103 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
				{
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			target78(<>p__78, typeFromHandle, text14, target79(<>p__79, ProfileManager.<>o__6.<>p__103.Target(ProfileManager.<>o__6.<>p__103, textProfile, <Module>.smethod_26<string>(114537182U))));
			Dictionary<string, object> dictionary3 = new Dictionary<string, object>();
			if (ProfileManager.<>o__6.<>p__107 == null)
			{
				ProfileManager.<>o__6.<>p__107 = CallSite<Action<CallSite, Dictionary<string, object>, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, <Module>.smethod_25<string>(1127381319U), null, typeof(ProfileManager), new CSharpArgumentInfo[]
				{
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
				}));
			}
			Action<CallSite, Dictionary<string, object>, string, object> target80 = ProfileManager.<>o__6.<>p__107.Target;
			CallSite <>p__80 = ProfileManager.<>o__6.<>p__107;
			Dictionary<string, object> dictionary4 = dictionary3;
			string text15 = <Module>.smethod_25<string>(466241873U);
			if (ProfileManager.<>o__6.<>p__106 == null)
			{
				ProfileManager.<>o__6.<>p__106 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
				{
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			target80(<>p__80, dictionary4, text15, ProfileManager.<>o__6.<>p__106.Target(ProfileManager.<>o__6.<>p__106, textProfile, <Module>.smethod_24<string>(1370288611U)));
			if (ProfileManager.<>o__6.<>p__109 == null)
			{
				ProfileManager.<>o__6.<>p__109 = CallSite<Action<CallSite, Dictionary<string, object>, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, <Module>.smethod_25<string>(1127381319U), null, typeof(ProfileManager), new CSharpArgumentInfo[]
				{
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
				}));
			}
			Action<CallSite, Dictionary<string, object>, string, object> target81 = ProfileManager.<>o__6.<>p__109.Target;
			CallSite <>p__81 = ProfileManager.<>o__6.<>p__109;
			Dictionary<string, object> dictionary5 = dictionary3;
			string text16 = <Module>.smethod_27<string>(225826583U);
			if (ProfileManager.<>o__6.<>p__108 == null)
			{
				ProfileManager.<>o__6.<>p__108 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
				{
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
					CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
				}));
			}
			target81(<>p__81, dictionary5, text16, ProfileManager.<>o__6.<>p__108.Target(ProfileManager.<>o__6.<>p__108, textProfile, <Module>.smethod_25<string>(1231813856U)));
			Dictionary<string, object> dictionary6 = dictionary3;
			foreach (string text17 in new List<string>
			{
				<Module>.smethod_27<string>(4117165143U),
				<Module>.smethod_24<string>(5528891U),
				<Module>.smethod_24<string>(1631448135U),
				<Module>.smethod_24<string>(2728435504U),
				<Module>.smethod_23<string>(654834449U)
			})
			{
				if (ProfileManager.<>o__6.<>p__112 == null)
				{
					ProfileManager.<>o__6.<>p__112 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(ProfileManager), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
				}
				Func<CallSite, object, bool> target82 = ProfileManager.<>o__6.<>p__112.Target;
				CallSite <>p__82 = ProfileManager.<>o__6.<>p__112;
				if (ProfileManager.<>o__6.<>p__111 == null)
				{
					ProfileManager.<>o__6.<>p__111 = CallSite<Func<CallSite, object, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof(ProfileManager), new CSharpArgumentInfo[]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, null)
					}));
				}
				Func<CallSite, object, object, object> target83 = ProfileManager.<>o__6.<>p__111.Target;
				CallSite <>p__83 = ProfileManager.<>o__6.<>p__111;
				if (ProfileManager.<>o__6.<>p__110 == null)
				{
					ProfileManager.<>o__6.<>p__110 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null)
					}));
				}
				if (target82(<>p__82, target83(<>p__83, ProfileManager.<>o__6.<>p__110.Target(ProfileManager.<>o__6.<>p__110, dictionary6[<Module>.smethod_27<string>(225826583U)], text17), null)))
				{
					if (ProfileManager.<>o__6.<>p__113 == null)
					{
						ProfileManager.<>o__6.<>p__113 = CallSite<Func<CallSite, object, string, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.SetIndex(CSharpBinderFlags.None, typeof(ProfileManager), new CSharpArgumentInfo[]
						{
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, null),
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
						}));
					}
					ProfileManager.<>o__6.<>p__113.Target(ProfileManager.<>o__6.<>p__113, dictionary6[<Module>.smethod_24<string>(733639614U)], text17, <Module>.smethod_24<string>(2904746129U));
				}
			}
			File.WriteAllText(Path.Combine(this.CurrentPath, <Module>.smethod_26<string>(3308309994U), <Module>.smethod_23<string>(3646280324U), <Module>.smethod_27<string>(3099506302U)), JsonConvert.SerializeObject(dictionary6));
			ffGen.IsProfileImported = true;
		}

		// Token: 0x0600043C RID: 1084 RVA: 0x00032A8C File Offset: 0x00030C8C
		private bool ValidateTextProfile(string input)
		{
			string[] array = ProfileManager.smethod_40(ProfileManager.smethod_36(input), new string[]
			{
				<Module>.smethod_27<string>(3604326520U),
				<Module>.smethod_24<string>(3717705751U)
			}, StringSplitOptions.None);
			if (!ProfileManager.smethod_29(array[0], <Module>.smethod_23<string>(1602429084U)))
			{
				return false;
			}
			string[] array2 = array;
			if (ProfileManager.smethod_29(array2[array2.Length - 1], <Module>.smethod_26<string>(895803757U)))
			{
				string text = null;
				StringBuilder stringBuilder = ProfileManager.smethod_41();
				for (int i = 1; i < array.Length - 1; i++)
				{
					if (!ProfileManager.smethod_29(array[i], <Module>.smethod_26<string>(3762307419U)))
					{
						ProfileManager.smethod_43(stringBuilder, array[i]);
					}
					else
					{
						string[] array3 = ProfileManager.smethod_40(array[i], new string[] { <Module>.smethod_24<string>(1102516260U) }, StringSplitOptions.None);
						if (ProfileManager.smethod_42(ProfileManager.smethod_34(array3[0]), <Module>.smethod_26<string>(1930054309U)))
						{
							text = ProfileManager.smethod_36(array3[1]);
						}
					}
				}
				return !ProfileManager.smethod_45(ProfileManager.CalculateMd5Hash(ProfileManager.RemoveLineEndings(ProfileManager.smethod_44(stringBuilder))), text);
			}
			return false;
		}

		// Token: 0x0600043D RID: 1085 RVA: 0x00032BAC File Offset: 0x00030DAC
		[return: Dynamic]
		private dynamic GetTextProfile(string input)
		{
			string[] array = ProfileManager.smethod_40(ProfileManager.smethod_36(input), new string[]
			{
				<Module>.smethod_27<string>(3604326520U),
				<Module>.smethod_27<string>(3511083134U)
			}, StringSplitOptions.None);
			StringBuilder stringBuilder = ProfileManager.smethod_41();
			for (int i = 1; i < array.Length - 1; i++)
			{
				if (!ProfileManager.smethod_29(array[i], <Module>.smethod_25<string>(806257394U)))
				{
					ProfileManager.smethod_43(stringBuilder, array[i]);
				}
			}
			byte[] array2 = ProfileManager.smethod_46(ProfileManager.RemoveLineEndings(ProfileManager.smethod_44(stringBuilder)));
			return JsonConvert.DeserializeObject(ProfileManager.smethod_48(ProfileManager.smethod_47(), array2));
		}

		// Token: 0x0600043E RID: 1086 RVA: 0x00032C44 File Offset: 0x00030E44
		private static string CalculateMd5Hash(string input)
		{
			HashAlgorithm hashAlgorithm = ProfileManager.smethod_49();
			byte[] array = ProfileManager.smethod_51(ProfileManager.smethod_50(), input);
			byte[] array2 = ProfileManager.smethod_52(hashAlgorithm, array);
			StringBuilder stringBuilder = ProfileManager.smethod_41();
			for (int i = 0; i < array2.Length; i++)
			{
				stringBuilder.Append(array2[i].ToString(<Module>.smethod_27<string>(3330367902U)));
			}
			return stringBuilder.ToString();
		}

		// Token: 0x0600043F RID: 1087 RVA: 0x00032CA0 File Offset: 0x00030EA0
		private static string RemoveLineEndings(string value)
		{
			if (!ProfileManager.smethod_30(value))
			{
				string text = '\u2028'.ToString();
				string text2 = '\u2029'.ToString();
				return value.Replace(<Module>.smethod_26<string>(2342675128U), string.Empty).Replace(<Module>.smethod_26<string>(162419152U), string.Empty).Replace(<Module>.smethod_26<string>(1590882786U), string.Empty)
					.Replace(<Module>.smethod_26<string>(3358517943U), string.Empty)
					.Replace(text, string.Empty)
					.Replace(text2, string.Empty);
			}
			return value;
		}

		// Token: 0x06000441 RID: 1089 RVA: 0x0000C65F File Offset: 0x0000A85F
		static Assembly smethod_0()
		{
			return Assembly.GetExecutingAssembly();
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x0000C666 File Offset: 0x0000A866
		static string smethod_1(Assembly assembly_0)
		{
			return assembly_0.Location;
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x0000C66E File Offset: 0x0000A86E
		static string smethod_2(string string_0)
		{
			return Path.GetDirectoryName(string_0);
		}

		// Token: 0x06000444 RID: 1092 RVA: 0x0000C784 File Offset: 0x0000A984
		static string smethod_3(string string_0, string string_1, string string_2)
		{
			return Path.Combine(string_0, string_1, string_2);
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x0000CFDC File Offset: 0x0000B1DC
		static string smethod_4()
		{
			return Environment.SystemDirectory;
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_5(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06000447 RID: 1095 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_6(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06000448 RID: 1096 RVA: 0x0000C656 File Offset: 0x0000A856
		static string smethod_7(string string_0, string string_1)
		{
			return Path.Combine(string_0, string_1);
		}

		// Token: 0x06000449 RID: 1097 RVA: 0x0000D8A9 File Offset: 0x0000BAA9
		static string smethod_8(Environment.SpecialFolder specialFolder_0)
		{
			return Environment.GetFolderPath(specialFolder_0);
		}

		// Token: 0x0600044A RID: 1098 RVA: 0x0000CD4E File Offset: 0x0000AF4E
		static string[] smethod_9(string string_0, string string_1)
		{
			return Directory.GetFiles(string_0, string_1);
		}

		// Token: 0x0600044B RID: 1099 RVA: 0x0000DA84 File Offset: 0x0000BC84
		static string smethod_10(string string_0)
		{
			return Path.GetFileNameWithoutExtension(string_0);
		}

		// Token: 0x0600044C RID: 1100 RVA: 0x0000C7ED File Offset: 0x0000A9ED
		static void smethod_11(string string_0)
		{
			File.Delete(string_0);
		}

		// Token: 0x0600044D RID: 1101 RVA: 0x0000C676 File Offset: 0x0000A876
		static string smethod_12(string string_0, string string_1, string string_2, string string_3)
		{
			return Path.Combine(string_0, string_1, string_2, string_3);
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x0000C681 File Offset: 0x0000A881
		static bool smethod_13(string string_0)
		{
			return File.Exists(string_0);
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x0000DA8C File Offset: 0x0000BC8C
		static string[] smethod_14(string string_0, string string_1, SearchOption searchOption_0)
		{
			return Directory.GetFiles(string_0, string_1, searchOption_0);
		}

		// Token: 0x06000450 RID: 1104 RVA: 0x0000CFF4 File Offset: 0x0000B1F4
		static string smethod_15(string string_0)
		{
			return Path.GetFileName(string_0);
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_16(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_17(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x0000DA96 File Offset: 0x0000BC96
		static CSharpArgumentInfo smethod_18(CSharpArgumentInfoFlags csharpArgumentInfoFlags_0, string string_0)
		{
			return CSharpArgumentInfo.Create(csharpArgumentInfoFlags_0, string_0);
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x0000DA9F File Offset: 0x0000BC9F
		static CallSiteBinder smethod_19(CSharpBinderFlags csharpBinderFlags_0, ExpressionType expressionType_0, Type type_0, IEnumerable<CSharpArgumentInfo> ienumerable_0)
		{
			return Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(csharpBinderFlags_0, expressionType_0, type_0, ienumerable_0);
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x0000DAAA File Offset: 0x0000BCAA
		static CallSiteBinder smethod_20(CSharpBinderFlags csharpBinderFlags_0, ExpressionType expressionType_0, Type type_0, IEnumerable<CSharpArgumentInfo> ienumerable_0)
		{
			return Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(csharpBinderFlags_0, expressionType_0, type_0, ienumerable_0);
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x0000DAB5 File Offset: 0x0000BCB5
		static CallSiteBinder smethod_21(CSharpBinderFlags csharpBinderFlags_0, Type type_0, IEnumerable<CSharpArgumentInfo> ienumerable_0)
		{
			return Microsoft.CSharp.RuntimeBinder.Binder.GetIndex(csharpBinderFlags_0, type_0, ienumerable_0);
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x0000DABF File Offset: 0x0000BCBF
		static CallSiteBinder smethod_22(CSharpBinderFlags csharpBinderFlags_0, Type type_0, Type type_1)
		{
			return Microsoft.CSharp.RuntimeBinder.Binder.Convert(csharpBinderFlags_0, type_0, type_1);
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x0000DAC9 File Offset: 0x0000BCC9
		static CallSiteBinder smethod_23(CSharpBinderFlags csharpBinderFlags_0, string string_0, IEnumerable<Type> ienumerable_0, Type type_0, IEnumerable<CSharpArgumentInfo> ienumerable_1)
		{
			return Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(csharpBinderFlags_0, string_0, ienumerable_0, type_0, ienumerable_1);
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x0000DAD6 File Offset: 0x0000BCD6
		static IEnumerator smethod_24(IEnumerable ienumerable_0)
		{
			return ienumerable_0.GetEnumerator();
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x0000D8E2 File Offset: 0x0000BAE2
		static object smethod_25(IEnumerator ienumerator_0)
		{
			return ienumerator_0.Current;
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x0000C693 File Offset: 0x0000A893
		static string[] smethod_26(string string_0, char[] char_0)
		{
			return string_0.Split(char_0);
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_27(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_28(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x0000CD7D File Offset: 0x0000AF7D
		static bool smethod_29(string string_0, string string_1)
		{
			return string_0.Contains(string_1);
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_30(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x0000DADE File Offset: 0x0000BCDE
		static int smethod_31(int int_0)
		{
			return Math.Abs(int_0);
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x0000CD96 File Offset: 0x0000AF96
		static string smethod_32(string string_0, object object_0, object object_1, object object_2)
		{
			return string.Format(string_0, object_0, object_1, object_2);
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x0000DAE6 File Offset: 0x0000BCE6
		static float smethod_33(float float_0)
		{
			return Math.Abs(float_0);
		}

		// Token: 0x06000463 RID: 1123 RVA: 0x0000DAEE File Offset: 0x0000BCEE
		static string smethod_34(string string_0)
		{
			return string_0.ToUpper();
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x0000CD69 File Offset: 0x0000AF69
		static string smethod_35(string string_0, char char_0, char char_1)
		{
			return string_0.Replace(char_0, char_1);
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x0000C6B8 File Offset: 0x0000A8B8
		static string smethod_36(string string_0)
		{
			return string_0.Trim();
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x0000DAF6 File Offset: 0x0000BCF6
		static string smethod_37(string string_0, string[] string_1)
		{
			return string.Join(string_0, string_1);
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x0000CDED File Offset: 0x0000AFED
		static int smethod_38(BindingSource bindingSource_0, object object_0)
		{
			return bindingSource_0.Add(object_0);
		}

		// Token: 0x06000468 RID: 1128 RVA: 0x0000DAFF File Offset: 0x0000BCFF
		static int smethod_39(string string_0)
		{
			return Convert.ToInt32(string_0);
		}

		// Token: 0x06000469 RID: 1129 RVA: 0x0000DB07 File Offset: 0x0000BD07
		static string[] smethod_40(string string_0, string[] string_1, StringSplitOptions stringSplitOptions_0)
		{
			return string_0.Split(string_1, stringSplitOptions_0);
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_41()
		{
			return new StringBuilder();
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_42(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x0600046C RID: 1132 RVA: 0x0000DB11 File Offset: 0x0000BD11
		static StringBuilder smethod_43(StringBuilder stringBuilder_0, string string_0)
		{
			return stringBuilder_0.Append(string_0);
		}

		// Token: 0x0600046D RID: 1133 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_44(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x0600046E RID: 1134 RVA: 0x0000CDA1 File Offset: 0x0000AFA1
		static bool smethod_45(string string_0, string string_1)
		{
			return string_0 != string_1;
		}

		// Token: 0x0600046F RID: 1135 RVA: 0x0000C86F File Offset: 0x0000AA6F
		static byte[] smethod_46(string string_0)
		{
			return Convert.FromBase64String(string_0);
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x0000DB1A File Offset: 0x0000BD1A
		static Encoding smethod_47()
		{
			return Encoding.UTF8;
		}

		// Token: 0x06000471 RID: 1137 RVA: 0x0000C894 File Offset: 0x0000AA94
		static string smethod_48(Encoding encoding_0, byte[] byte_0)
		{
			return encoding_0.GetString(byte_0);
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x0000DA38 File Offset: 0x0000BC38
		static MD5 smethod_49()
		{
			return MD5.Create();
		}

		// Token: 0x06000473 RID: 1139 RVA: 0x0000C3FB File Offset: 0x0000A5FB
		static Encoding smethod_50()
		{
			return Encoding.ASCII;
		}

		// Token: 0x06000474 RID: 1140 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_51(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x06000475 RID: 1141 RVA: 0x0000DA3F File Offset: 0x0000BC3F
		static byte[] smethod_52(HashAlgorithm hashAlgorithm_0, byte[] byte_0)
		{
			return hashAlgorithm_0.ComputeHash(byte_0);
		}

		// Token: 0x0400011E RID: 286
		private const string ProfilePw = "ffox20141226";

		// Token: 0x0400011F RID: 287
		private readonly string CurrentPath = ProfileManager.smethod_2(ProfileManager.smethod_1(ProfileManager.smethod_0()));

		// Token: 0x04000120 RID: 288
		private Dictionary<string, string> extractPaths = new Dictionary<string, string>();
	}
}
