﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using FraudFox.Annotations;

namespace FraudFox
{
	// Token: 0x02000018 RID: 24
	[Obfuscation(Exclude = true, ApplyToMembers = true)]
	public class FFGenerator : INotifyPropertyChanged
	{
		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000178 RID: 376 RVA: 0x0000C920 File Offset: 0x0000AB20
		// (set) Token: 0x06000179 RID: 377 RVA: 0x0000C928 File Offset: 0x0000AB28
		public string OsVersion
		{
			get
			{
				return this._osVersion;
			}
			set
			{
				this._osVersion = value;
				this.OnPropertyChanged(<Module>.smethod_25<string>(824930845U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x0600017A RID: 378 RVA: 0x0000C948 File Offset: 0x0000AB48
		// (set) Token: 0x0600017B RID: 379 RVA: 0x0000C950 File Offset: 0x0000AB50
		public int OsPlatform
		{
			get
			{
				return this._osPlatform;
			}
			set
			{
				this._osPlatform = value;
				this.OnPropertyChanged(<Module>.smethod_27<string>(1128953370U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x0600017C RID: 380 RVA: 0x0000C970 File Offset: 0x0000AB70
		// (set) Token: 0x0600017D RID: 381 RVA: 0x0000C978 File Offset: 0x0000AB78
		public string OsLanguage
		{
			get
			{
				return this._osLanguage;
			}
			set
			{
				this._osLanguage = value;
				this.OnPropertyChanged(<Module>.smethod_26<string>(1043538226U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x0600017E RID: 382 RVA: 0x0000C998 File Offset: 0x0000AB98
		// (set) Token: 0x0600017F RID: 383 RVA: 0x0000C9A0 File Offset: 0x0000ABA0
		public string OsTimezone
		{
			get
			{
				return this._osTimezone;
			}
			set
			{
				this._osTimezone = value;
				this.OnPropertyChanged(<Module>.smethod_27<string>(755979826U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000180 RID: 384 RVA: 0x0000C9C0 File Offset: 0x0000ABC0
		// (set) Token: 0x06000181 RID: 385 RVA: 0x0000C9C8 File Offset: 0x0000ABC8
		public Size OsResolution
		{
			get
			{
				return this._osResolution;
			}
			set
			{
				this._osResolution = value;
				this.OnPropertyChanged(<Module>.smethod_26<string>(2462425466U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000182 RID: 386 RVA: 0x0000C9E8 File Offset: 0x0000ABE8
		// (set) Token: 0x06000183 RID: 387 RVA: 0x0000C9F0 File Offset: 0x0000ABF0
		public bool OsChangeResolution
		{
			get
			{
				return this._osChangeResolution;
			}
			set
			{
				this._osChangeResolution = value;
				this.OnPropertyChanged(<Module>.smethod_25<string>(1938490093U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000184 RID: 388 RVA: 0x0000CA10 File Offset: 0x0000AC10
		// (set) Token: 0x06000185 RID: 389 RVA: 0x0000CA18 File Offset: 0x0000AC18
		public string BrowserProduct
		{
			get
			{
				return this._browserProduct;
			}
			set
			{
				this._browserProduct = value;
				this.OnPropertyChanged(<Module>.smethod_27<string>(383006282U));
				this.OnPropertyChanged(<Module>.smethod_25<string>(3539231512U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000186 RID: 390 RVA: 0x0000CA48 File Offset: 0x0000AC48
		// (set) Token: 0x06000187 RID: 391 RVA: 0x0000CA50 File Offset: 0x0000AC50
		public string BrowserVersion
		{
			get
			{
				return this._browserVersion;
			}
			set
			{
				this._browserVersion = value;
				this.OnPropertyChanged(<Module>.smethod_27<string>(56654431U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000188 RID: 392 RVA: 0x0000CA70 File Offset: 0x0000AC70
		// (set) Token: 0x06000189 RID: 393 RVA: 0x0000CA78 File Offset: 0x0000AC78
		public string BrowserFlash
		{
			get
			{
				return this._browserFlash;
			}
			set
			{
				this._browserFlash = value;
				this.OnPropertyChanged(<Module>.smethod_26<string>(3948347464U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x0600018A RID: 394 RVA: 0x0000CA98 File Offset: 0x0000AC98
		// (set) Token: 0x0600018B RID: 395 RVA: 0x0000CAA0 File Offset: 0x0000ACA0
		public string BrowserCanvasStroke
		{
			get
			{
				return this._browserCanvasStroke;
			}
			set
			{
				this._browserCanvasStroke = value;
				this.OnPropertyChanged(<Module>.smethod_26<string>(1091420196U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x0600018C RID: 396 RVA: 0x0000CAC0 File Offset: 0x0000ACC0
		// (set) Token: 0x0600018D RID: 397 RVA: 0x0000CAC8 File Offset: 0x0000ACC8
		public string BrowserCanvasFill
		{
			get
			{
				return this._browserCanvasFill;
			}
			set
			{
				this._browserCanvasFill = value;
				this.OnPropertyChanged(<Module>.smethod_26<string>(3957923858U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x0600018E RID: 398 RVA: 0x0000CAE8 File Offset: 0x0000ACE8
		// (set) Token: 0x0600018F RID: 399 RVA: 0x0000CAF0 File Offset: 0x0000ACF0
		public string BrowserCanvasFont
		{
			get
			{
				return this._browserCanvasFont;
			}
			set
			{
				this._browserCanvasFont = value;
				this.OnPropertyChanged(<Module>.smethod_23<string>(1296056288U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x06000190 RID: 400 RVA: 0x0000CB10 File Offset: 0x0000AD10
		// (set) Token: 0x06000191 RID: 401 RVA: 0x0000CB24 File Offset: 0x0000AD24
		public int BrowserCanvasFontSize
		{
			get
			{
				if (this._browserCanvasFontSize <= 0)
				{
					return 14;
				}
				return this._browserCanvasFontSize;
			}
			set
			{
				if (value > 0)
				{
					this._browserCanvasFontSize = value;
					this.OnPropertyChanged(<Module>.smethod_26<string>(909468710U));
					this.IsProfileImported = false;
				}
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x06000192 RID: 402 RVA: 0x0000CB48 File Offset: 0x0000AD48
		// (set) Token: 0x06000193 RID: 403 RVA: 0x0000CB50 File Offset: 0x0000AD50
		public string CurrentStatus
		{
			get
			{
				return this._currentStatus;
			}
			set
			{
				this._currentStatus = value;
				this.OnPropertyChanged(<Module>.smethod_23<string>(1314870413U));
			}
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x06000194 RID: 404 RVA: 0x0000CB69 File Offset: 0x0000AD69
		// (set) Token: 0x06000195 RID: 405 RVA: 0x0000CB71 File Offset: 0x0000AD71
		public string UserAgent
		{
			get
			{
				return this._userAgent;
			}
			set
			{
				this._userAgent = value;
				this.OnPropertyChanged(<Module>.smethod_23<string>(2804682054U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06000196 RID: 406 RVA: 0x0000CB91 File Offset: 0x0000AD91
		// (set) Token: 0x06000197 RID: 407 RVA: 0x0000CB99 File Offset: 0x0000AD99
		public string AdvancedUserAgent
		{
			get
			{
				return this._advancedUserAgent;
			}
			set
			{
				this._advancedUserAgent = value;
				this.OnPropertyChanged(<Module>.smethod_25<string>(1500830585U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06000198 RID: 408 RVA: 0x0000CBB9 File Offset: 0x0000ADB9
		// (set) Token: 0x06000199 RID: 409 RVA: 0x0000CBC1 File Offset: 0x0000ADC1
		public string StartPage
		{
			get
			{
				return this._startPage;
			}
			set
			{
				this._startPage = value;
				this.OnPropertyChanged(<Module>.smethod_26<string>(3814277948U));
				this.IsProfileImported = false;
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x0600019A RID: 410 RVA: 0x0000CBE1 File Offset: 0x0000ADE1
		// (set) Token: 0x0600019B RID: 411 RVA: 0x0000CBE9 File Offset: 0x0000ADE9
		public List<BrowserPluginInfo> PluginList
		{
			get
			{
				return this._pluginList;
			}
			set
			{
				this._pluginList = value;
				this.OnPropertyChanged(<Module>.smethod_23<string>(522929280U));
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x0600019C RID: 412 RVA: 0x0000CC02 File Offset: 0x0000AE02
		// (set) Token: 0x0600019D RID: 413 RVA: 0x0000CC0A File Offset: 0x0000AE0A
		public bool EnableFontSpoofing
		{
			get
			{
				return this._enableFontSpoofing;
			}
			set
			{
				this._enableFontSpoofing = value;
				this.OnPropertyChanged(<Module>.smethod_26<string>(2395390708U));
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x0600019E RID: 414 RVA: 0x0000CC23 File Offset: 0x0000AE23
		// (set) Token: 0x0600019F RID: 415 RVA: 0x0000CC2B File Offset: 0x0000AE2B
		public bool FlashDisableDeviceFontEnumeration
		{
			get
			{
				return this._flashDisableDeviceFontEnumeration;
			}
			set
			{
				this._flashDisableDeviceFontEnumeration = value;
				this.OnPropertyChanged(<Module>.smethod_25<string>(2336000021U));
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x060001A0 RID: 416 RVA: 0x0000CC44 File Offset: 0x0000AE44
		// (set) Token: 0x060001A1 RID: 417 RVA: 0x0000CC4C File Offset: 0x0000AE4C
		public bool FlashAvHardwareDisable
		{
			get
			{
				return this._flashAvHardwareDisable;
			}
			set
			{
				this._flashAvHardwareDisable = value;
				this.OnPropertyChanged(<Module>.smethod_23<string>(3346899060U));
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x060001A2 RID: 418 RVA: 0x0000CC65 File Offset: 0x0000AE65
		// (set) Token: 0x060001A3 RID: 419 RVA: 0x0000CC6D File Offset: 0x0000AE6D
		public List<string> FontList
		{
			get
			{
				return this._fontList;
			}
			set
			{
				this._fontList = value;
				this.OnPropertyChanged(<Module>.smethod_27<string>(3967105103U));
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x060001A4 RID: 420 RVA: 0x0000CC86 File Offset: 0x0000AE86
		// (set) Token: 0x060001A5 RID: 421 RVA: 0x0000CC8E File Offset: 0x0000AE8E
		public string ProfileNotes
		{
			get
			{
				return this._profileNotes;
			}
			set
			{
				this._profileNotes = value;
				this.OnPropertyChanged(<Module>.smethod_24<string>(4068806547U));
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x060001A6 RID: 422 RVA: 0x0000CCA7 File Offset: 0x0000AEA7
		// (set) Token: 0x060001A7 RID: 423 RVA: 0x0000CCAF File Offset: 0x0000AEAF
		[XmlIgnore]
		public string ImportedProfilePath
		{
			get
			{
				return this._importedProfilePath;
			}
			set
			{
				this._importedProfilePath = value;
				this._isProfileImported = !FFGenerator.smethod_0(value);
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x060001A8 RID: 424 RVA: 0x0000CCC7 File Offset: 0x0000AEC7
		// (set) Token: 0x060001A9 RID: 425 RVA: 0x0000CCCF File Offset: 0x0000AECF
		[XmlIgnore]
		public bool IsProfileImported
		{
			get
			{
				return this._isProfileImported;
			}
			set
			{
				this._isProfileImported = value;
			}
		}

		// Token: 0x14000001 RID: 1
		// (add) Token: 0x060001AA RID: 426 RVA: 0x000247E0 File Offset: 0x000229E0
		// (remove) Token: 0x060001AB RID: 427 RVA: 0x00024818 File Offset: 0x00022A18
		public event PropertyChangedEventHandler PropertyChanged
		{
			[CompilerGenerated]
			add
			{
				PropertyChangedEventHandler propertyChangedEventHandler = this.PropertyChanged;
				PropertyChangedEventHandler propertyChangedEventHandler2;
				do
				{
					propertyChangedEventHandler2 = propertyChangedEventHandler;
					PropertyChangedEventHandler propertyChangedEventHandler3 = (PropertyChangedEventHandler)FFGenerator.smethod_1(propertyChangedEventHandler2, value);
					propertyChangedEventHandler = Interlocked.CompareExchange<PropertyChangedEventHandler>(ref this.PropertyChanged, propertyChangedEventHandler3, propertyChangedEventHandler2);
				}
				while (propertyChangedEventHandler != propertyChangedEventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				PropertyChangedEventHandler propertyChangedEventHandler = this.PropertyChanged;
				PropertyChangedEventHandler propertyChangedEventHandler2;
				do
				{
					propertyChangedEventHandler2 = propertyChangedEventHandler;
					PropertyChangedEventHandler propertyChangedEventHandler3 = (PropertyChangedEventHandler)FFGenerator.smethod_2(propertyChangedEventHandler2, value);
					propertyChangedEventHandler = Interlocked.CompareExchange<PropertyChangedEventHandler>(ref this.PropertyChanged, propertyChangedEventHandler3, propertyChangedEventHandler2);
				}
				while (propertyChangedEventHandler != propertyChangedEventHandler2);
			}
		}

		// Token: 0x060001AC RID: 428 RVA: 0x00024854 File Offset: 0x00022A54
		[NotifyPropertyChangedInvocator]
		protected virtual void OnPropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, FFGenerator.smethod_3(propertyName));
			}
		}

		// Token: 0x060001AD RID: 429 RVA: 0x00024878 File Offset: 0x00022A78
		public bool CheckProperties()
		{
			int num;
			if (!FFGenerator.smethod_0(this.OsLanguage) && !FFGenerator.smethod_0(this.OsTimezone) && !FFGenerator.smethod_0(this.OsVersion) && this.OsPlatform > 0 && this.OsResolution.Height > 0 && this.OsResolution.Width > 0 && !string.IsNullOrEmpty(this.BrowserProduct) && !string.IsNullOrEmpty(this.BrowserVersion) && !string.IsNullOrEmpty(this.BrowserCanvasStroke) && !string.IsNullOrEmpty(this.BrowserCanvasFill))
			{
				if ((num = ((!string.IsNullOrEmpty(this.BrowserCanvasFont)) ? 1 : 0)) != 0)
				{
					bool isProfileImported = this.IsProfileImported;
					this.UserAgent = this.AdvancedUserAgent ?? this.GenerateUserAgent();
					this.IsProfileImported = isProfileImported;
				}
			}
			else
			{
				num = 0;
			}
			return num != 0;
		}

		// Token: 0x060001AE RID: 430 RVA: 0x00024950 File Offset: 0x00022B50
		public void GenerateCanvasConfig(string filePath)
		{
			if (!this.IsProfileImported && !FFGenerator.smethod_0(this.BrowserCanvasFont) && !FFGenerator.smethod_0(this.BrowserCanvasFill) && !FFGenerator.smethod_0(this.BrowserCanvasStroke))
			{
				FFGenerator.smethod_5(filePath, FFGenerator.smethod_4(<Module>.smethod_24<string>(1399758495U), new object[] { this.BrowserCanvasStroke, this.BrowserCanvasFill, this.BrowserCanvasFont, this.BrowserCanvasFontSize }));
			}
		}

		// Token: 0x060001AF RID: 431 RVA: 0x000249D0 File Offset: 0x00022BD0
		public void GenerateFlashConfig(string filePath)
		{
			if (FFGenerator.smethod_6(this.BrowserFlash, <Module>.smethod_24<string>(410488248U)))
			{
				foreach (string text in FFGenerator.smethod_8(FFGenerator.smethod_7(filePath), <Module>.smethod_23<string>(2734566056U)))
				{
					FFGenerator.smethod_10(text, FFGenerator.smethod_9(<Module>.smethod_27<string>(2475210927U), text));
				}
			}
			else
			{
				foreach (string text2 in FFGenerator.smethod_8(FFGenerator.smethod_7(filePath), <Module>.smethod_26<string>(2592497249U)))
				{
					FFGenerator.smethod_10(text2, FFGenerator.smethod_11(text2, <Module>.smethod_24<string>(3309705486U), ""));
				}
			}
			if (!this.IsProfileImported)
			{
				string text3 = FFGenerator.smethod_12(this.BrowserFlash, '.', ',');
				string key = this.StaticData.OsVersion.FirstOrDefault((KeyValuePair<string, string> x) => FFGenerator.smethod_6(x.Value, this.OsVersion)).Key;
				string text4 = FFGenerator.smethod_13(this.OsLanguage, 0, 2);
				string text5;
				string text6;
				if (FFGenerator.smethod_14(this.OsVersion, <Module>.smethod_24<string>(640657434U)))
				{
					text5 = <Module>.smethod_27<string>(2195480769U);
					text6 = <Module>.smethod_25<string>(3220692120U);
					if (FFGenerator.smethod_6(this.BrowserProduct, <Module>.smethod_24<string>(2957084236U)))
					{
						text6 = <Module>.smethod_25<string>(3568679385U);
					}
				}
				else
				{
					text5 = <Module>.smethod_27<string>(2655926159U);
					text6 = <Module>.smethod_23<string>(240717405U);
					if (FFGenerator.smethod_6(this.BrowserProduct, <Module>.smethod_26<string>(1183186403U)))
					{
						text6 = <Module>.smethod_25<string>(3568679385U);
					}
				}
				File.WriteAllText(filePath, string.Format(<Module>.smethod_26<string>(3877314973U), new object[]
				{
					this.OsResolution.Width,
					this.OsResolution.Height,
					text3,
					key,
					text4,
					text5,
					text6
				}));
			}
		}

		// Token: 0x060001B0 RID: 432 RVA: 0x00024BC0 File Offset: 0x00022DC0
		public void GenerateFlashMmsConfig(string filePath)
		{
			List<string> list = new List<string>
			{
				<Module>.smethod_26<string>(3210965126U),
				<Module>.smethod_27<string>(324841509U)
			};
			if (this.FlashDisableDeviceFontEnumeration)
			{
				list.Add(<Module>.smethod_25<string>(3618202048U));
			}
			if (this.FlashAvHardwareDisable)
			{
				list.Add(<Module>.smethod_23<string>(3196386060U));
			}
			FFGenerator.smethod_5(filePath, FFGenerator.smethod_16(FFGenerator.smethod_15(), list));
		}

		// Token: 0x060001B1 RID: 433 RVA: 0x00024C34 File Offset: 0x00022E34
		public void GenerateHeadersConfig(string filePath)
		{
			if (this.IsProfileImported)
			{
				return;
			}
			var <>f__AnonymousType = new
			{
				headers = new List<object>
				{
					new
					{
						action = <Module>.smethod_23<string>(2074323798U),
						name = <Module>.smethod_25<string>(4274026998U),
						value = this.UserAgent,
						comment = "",
						enabled = true
					},
					new
					{
						action = <Module>.smethod_25<string>(3369260109U),
						name = <Module>.smethod_23<string>(2828636681U),
						value = this.OsLanguage,
						comment = "",
						enabled = true
					}
				}
			};
			FFGenerator.smethod_5(filePath, <>f__AnonymousType.ToJson());
		}

		// Token: 0x060001B2 RID: 434 RVA: 0x00024CB8 File Offset: 0x00022EB8
		public void GenerateJsOverrideConfig(string filePath)
		{
			if (this.IsProfileImported)
			{
				return;
			}
			Dictionary<string, object> dictionary = new Dictionary<string, object>
			{
				{
					<Module>.smethod_26<string>(3479104158U),
					new
					{
						availHeight = (FFGenerator.smethod_14(this.OsVersion, <Module>.smethod_26<string>(1173610009U)) ? (this.OsResolution.Height - 23) : (this.OsResolution.Height - 40)),
						availWidth = this.OsResolution.Width,
						availLeft = 0,
						availTop = (this.OsVersion.Contains(<Module>.smethod_24<string>(640657434U)) ? 23 : 0),
						height = this.OsResolution.Height,
						width = this.OsResolution.Width,
						colorDepth = 24,
						left = 0,
						pixelDepth = 24,
						top = 0
					}
				},
				{
					<Module>.smethod_25<string>(1231813856U),
					new
					{
						productSub = (this.BrowserProduct.Contains(<Module>.smethod_27<string>(458935048U)) ? <Module>.smethod_26<string>(641329678U) : <Module>.smethod_27<string>(4147820335U)),
						onLine = true,
						userAgent = this.UserAgent,
						vendorSub = "",
						platform = (this.OsVersion.Contains(<Module>.smethod_23<string>(2135906675U)) ? <Module>.smethod_27<string>(3961333563U) : ((this.OsPlatform == 64) ? <Module>.smethod_23<string>(2616540804U) : <Module>.smethod_25<string>(1371008762U))),
						language = this.OsLanguage.Substring(0, 2),
						languages = new string[]
						{
							this.OsLanguage.Substring(0, 2),
							this.OsLanguage
						},
						appVersion = <Module>.smethod_24<string>(4039336663U) + this.UserAgent.Substring(this.UserAgent.IndexOf(<Module>.smethod_24<string>(2060796169U), StringComparison.Ordinal)),
						oscpu = (this.OsVersion.Contains(<Module>.smethod_23<string>(2135906675U)) ? this.OsVersion.Replace('_', '.') : this.OsVersion),
						buildID = "",
						plugins = this.GetPluginList(),
						mimeTypes = this.GetMimeTypes()
					}
				}
			};
			File.WriteAllText(filePath, dictionary.ToJson());
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x00024EAC File Offset: 0x000230AC
		private string GenerateUserAgent()
		{
			string text = this.BrowserProduct;
			if (FFGenerator.smethod_6(text, <Module>.smethod_26<string>(1183186403U)))
			{
				return FFGenerator.smethod_4(<Module>.smethod_27<string>(3168764782U), new object[]
				{
					FFGenerator.smethod_14(this.OsVersion, <Module>.smethod_24<string>(640657434U)) ? <Module>.smethod_23<string>(1475664417U) : "",
					this.OsVersion,
					(this.OsPlatform != 64 || FFGenerator.smethod_14(this.OsVersion, <Module>.smethod_26<string>(1173610009U))) ? "" : <Module>.smethod_27<string>(3116371549U),
					this.BrowserVersion
				});
			}
			if (FFGenerator.smethod_6(text, <Module>.smethod_25<string>(883826591U)))
			{
				return FFGenerator.smethod_4(<Module>.smethod_26<string>(535989344U), new object[]
				{
					FFGenerator.smethod_14(this.OsVersion, <Module>.smethod_25<string>(2385522684U)) ? <Module>.smethod_26<string>(4097572035U) : "",
					FFGenerator.smethod_14(this.OsVersion, <Module>.smethod_25<string>(2385522684U)) ? FFGenerator.smethod_12(this.OsVersion, '_', '.') : this.OsVersion,
					(this.OsPlatform != 64 || FFGenerator.smethod_14(this.OsVersion, <Module>.smethod_27<string>(2288724155U))) ? "" : <Module>.smethod_27<string>(2696776312U),
					this.BrowserVersion
				});
			}
			if (FFGenerator.smethod_6(text, <Module>.smethod_26<string>(2098522494U)))
			{
				return FFGenerator.smethod_4(<Module>.smethod_23<string>(1263568540U), new object[]
				{
					FFGenerator.smethod_14(this.OsVersion, <Module>.smethod_24<string>(640657434U)) ? <Module>.smethod_27<string>(3675831865U) : "",
					FFGenerator.smethod_14(this.OsVersion, <Module>.smethod_27<string>(2288724155U)) ? FFGenerator.smethod_12(this.OsVersion, '_', '.') : this.OsVersion,
					(this.OsPlatform != 64 || FFGenerator.smethod_14(this.OsVersion, <Module>.smethod_27<string>(2288724155U))) ? "" : <Module>.smethod_26<string>(1240644767U),
					this.OsLanguage,
					this.BrowserVersion
				});
			}
			if (FFGenerator.smethod_6(text, <Module>.smethod_24<string>(2467275980U)))
			{
				text = this.BrowserVersion;
				string text2;
				if (FFGenerator.smethod_6(text, <Module>.smethod_23<string>(2508796556U)))
				{
					text2 = string.Empty;
				}
				else if (FFGenerator.smethod_6(text, <Module>.smethod_25<string>(4130773505U)))
				{
					text2 = <Module>.smethod_27<string>(3373464920U);
				}
				else if (!FFGenerator.smethod_6(text, <Module>.smethod_25<string>(3991578599U)))
				{
					if (!FFGenerator.smethod_6(text, <Module>.smethod_23<string>(1386734294U)))
					{
						if (!FFGenerator.smethod_6(text, <Module>.smethod_23<string>(2702078308U)))
						{
							if (!FFGenerator.smethod_6(text, <Module>.smethod_24<string>(463329451U)))
							{
								text2 = string.Empty;
							}
							else
							{
								text2 = <Module>.smethod_24<string>(2319417881U);
							}
						}
						else
						{
							text2 = <Module>.smethod_24<string>(110708201U);
						}
					}
					else
					{
						text2 = <Module>.smethod_23<string>(2895360060U);
					}
				}
				else
				{
					text2 = <Module>.smethod_26<string>(2657115202U);
				}
				return FFGenerator.smethod_4(<Module>.smethod_23<string>(4017422322U), new object[]
				{
					this.BrowserVersion,
					this.OsVersion,
					(this.OsPlatform != 64 || FFGenerator.smethod_14(this.OsVersion, <Module>.smethod_27<string>(2288724155U))) ? "" : <Module>.smethod_25<string>(2271717064U),
					FFGenerator.smethod_0(text2) ? FFGenerator.smethod_9(<Module>.smethod_27<string>(1974814130U), text2) : ""
				});
			}
			if (!FFGenerator.smethod_6(text, <Module>.smethod_24<string>(2237106794U)))
			{
				return "";
			}
			if (FFGenerator.smethod_14(this.OsVersion, <Module>.smethod_27<string>(2288724155U)))
			{
				return FFGenerator.smethod_17(<Module>.smethod_25<string>(1784534893U), this.OsVersion, this.BrowserVersion, FFGenerator.smethod_13(this.BrowserVersion, 0, 1));
			}
			return FFGenerator.smethod_4(<Module>.smethod_27<string>(2248772748U), new object[]
			{
				this.OsVersion,
				this.OsLanguage,
				this.BrowserVersion,
				FFGenerator.smethod_13(this.BrowserVersion, 0, 1)
			});
		}

		// Token: 0x060001B4 RID: 436 RVA: 0x000252E4 File Offset: 0x000234E4
		private Dictionary<string, object> GetPluginList()
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			int num = 0;
			if (FFGenerator.smethod_18(this.BrowserFlash, <Module>.smethod_25<string>(1411158342U)))
			{
				if (FFGenerator.smethod_14(this.OsVersion, <Module>.smethod_26<string>(1173610009U)))
				{
					if (FFGenerator.smethod_6(this.BrowserProduct, <Module>.smethod_24<string>(2957084236U)))
					{
						this.PluginList.Add(new BrowserPluginInfo
						{
							Name = <Module>.smethod_26<string>(1152040416U),
							Description = FFGenerator.smethod_9(<Module>.smethod_23<string>(1872508925U), FFGenerator.smethod_13(this.BrowserFlash, 0, 2)),
							Filename = <Module>.smethod_24<string>(3049049058U),
							MimeType = new List<string>
							{
								<Module>.smethod_24<string>(1721892503U),
								<Module>.smethod_24<string>(2588710686U)
							}
						});
					}
					else
					{
						this.PluginList.Add(new BrowserPluginInfo
						{
							Name = <Module>.smethod_25<string>(1207680479U),
							Description = FFGenerator.smethod_9(<Module>.smethod_26<string>(437808599U), FFGenerator.smethod_13(this.BrowserFlash, 0, 2)),
							Filename = <Module>.smethod_27<string>(471376874U),
							MimeType = new List<string>
							{
								<Module>.smethod_26<string>(4037696866U),
								<Module>.smethod_26<string>(3342617837U)
							}
						});
					}
				}
				else if (FFGenerator.smethod_6(this.BrowserProduct, <Module>.smethod_27<string>(1822507225U)))
				{
					this.PluginList.Add(new BrowserPluginInfo
					{
						Name = <Module>.smethod_25<string>(1207680479U),
						Description = FFGenerator.smethod_9(<Module>.smethod_26<string>(437808599U), FFGenerator.smethod_13(this.BrowserFlash, 0, 2)),
						Filename = <Module>.smethod_24<string>(908932881U),
						MimeType = new List<string>
						{
							<Module>.smethod_26<string>(4037696866U),
							<Module>.smethod_27<string>(3886303543U)
						}
					});
				}
				else
				{
					this.PluginList.Add(new BrowserPluginInfo
					{
						Name = <Module>.smethod_23<string>(3593230568U),
						Description = FFGenerator.smethod_9(<Module>.smethod_26<string>(437808599U), FFGenerator.smethod_13(this.BrowserFlash, 0, 2)),
						Filename = FFGenerator.smethod_9(<Module>.smethod_25<string>(3295604069U), FFGenerator.smethod_12(this.BrowserFlash, '.', '_')),
						MimeType = new List<string>
						{
							<Module>.smethod_23<string>(3555602318U),
							<Module>.smethod_23<string>(1330291919U)
						}
					});
				}
			}
			foreach (BrowserPluginInfo browserPluginInfo in this.PluginList)
			{
				if (!dictionary.ContainsKey(browserPluginInfo.Name))
				{
					Dictionary<string, object> plugin = this.GetPlugin(browserPluginInfo.Name, browserPluginInfo.Description, browserPluginInfo.Filename, browserPluginInfo.MimeType);
					dictionary.Add(browserPluginInfo.Name, plugin);
					dictionary.Add(num.ToString(FFGenerator.smethod_19()), plugin);
					num++;
				}
			}
			dictionary.Add(<Module>.smethod_24<string>(3915867241U), num);
			return dictionary;
		}

		// Token: 0x060001B5 RID: 437 RVA: 0x0002564C File Offset: 0x0002384C
		public void Save(string filePath)
		{
			XmlWriterSettings xmlWriterSettings = FFGenerator.smethod_20();
			FFGenerator.smethod_21(xmlWriterSettings, NewLineHandling.Entitize);
			XmlWriterSettings xmlWriterSettings2 = xmlWriterSettings;
			XmlSerializer xmlSerializer = FFGenerator.smethod_23(FFGenerator.smethod_22(typeof(FFGenerator).TypeHandle));
			XmlWriter xmlWriter = FFGenerator.smethod_24(filePath, xmlWriterSettings2);
			try
			{
				FFGenerator.smethod_25(xmlSerializer, xmlWriter, this);
			}
			finally
			{
				if (xmlWriter != null)
				{
					FFGenerator.smethod_26(xmlWriter);
				}
			}
		}

		// Token: 0x060001B6 RID: 438 RVA: 0x000256A4 File Offset: 0x000238A4
		public void Load(string filePath)
		{
			try
			{
				XmlSerializer xmlSerializer = FFGenerator.smethod_23(FFGenerator.smethod_22(typeof(FFGenerator).TypeHandle));
				using (TextReader textReader = FFGenerator.smethod_27(filePath))
				{
					FFGenerator result = (FFGenerator)FFGenerator.smethod_28(xmlSerializer, textReader);
					if (!this.StaticData.OsVersion.ContainsKey(result.OsVersion))
					{
						this.StaticData.OsVersion.Add(result.OsVersion, result.OsVersion);
						FFGenerator.smethod_29(this.StaticData.OsVersionBindingSource, new KeyValuePair<string, string>(result.OsVersion, result.OsVersion));
					}
					if (!this.StaticData.OsLanguage.ContainsValue(result.OsLanguage))
					{
						this.StaticData.OsLanguage.Add(result.OsLanguage, result.OsLanguage);
						FFGenerator.smethod_29(this.StaticData.OsLanguageBindingSource, new KeyValuePair<string, string>(result.OsLanguage, result.OsLanguage));
					}
					if (this.StaticData.OsTimezone.FirstOrDefault((KeyValuePair<string, string> x) => FFGenerator.<>c__DisplayClass114_0.smethod_0(x.Key, result.OsTimezone)).Equals(null))
					{
						this.StaticData.OsTimezone.Add(result.OsTimezone, result.OsTimezone);
						FFGenerator.smethod_29(this.StaticData.OsTimezoneBindingSource, new KeyValuePair<string, string>(result.OsTimezone, result.OsTimezone));
					}
					if (!this.StaticData.OsResolution.ContainsValue(result.OsResolution))
					{
						this.StaticData.OsResolution.Add(string.Format(<Module>.smethod_24<string>(840339378U), result.OsResolution.Width, result.OsResolution.Height), result.OsResolution);
						this.StaticData.OsResolutionBindingSource.Add(new KeyValuePair<string, Size>(string.Format(<Module>.smethod_25<string>(561228612U), result.OsResolution.Width, result.OsResolution.Height), result.OsResolution));
					}
					if (!this.StaticData.BrowserProduct.Contains(result.BrowserProduct))
					{
						this.StaticData.BrowserProduct.Add(result.BrowserProduct);
						this.StaticData.BrowserProductBindingSource.Add(result.BrowserProduct);
					}
					if (!this.StaticData.BrowserVersion.ContainsKey(result.BrowserProduct))
					{
						this.StaticData.BrowserVersion.Add(result.BrowserProduct, new List<string>());
						this.StaticData.BrowserVersionBindingSource.Add(new KeyValuePair<string, List<string>>(result.BrowserProduct, this.StaticData.BrowserVersion[result.BrowserProduct]));
					}
					if (!this.StaticData.BrowserVersion[result.BrowserProduct].Contains(result.BrowserVersion))
					{
						this.StaticData.BrowserVersion[result.BrowserProduct].Add(result.BrowserVersion);
					}
					if (!this.StaticData.BrowserFlash.Contains(result.BrowserFlash))
					{
						this.StaticData.BrowserFlash.Add(result.BrowserFlash);
						this.StaticData.BrowserFlashBindingSource.Add(result.BrowserFlash);
					}
					this.CopyValues<FFGenerator>(this, result, false);
					this.PluginList = result.PluginList.Distinct<BrowserPluginInfo>().ToList<BrowserPluginInfo>();
					this.FontList = result.FontList.Distinct<string>().ToList<string>();
				}
			}
			catch
			{
			}
		}

		// Token: 0x060001B7 RID: 439 RVA: 0x0000CCD8 File Offset: 0x0000AED8
		public void Erase()
		{
			this.CopyValues<FFGenerator>(this, new FFGenerator(), true);
			this.PluginList.Clear();
			this.FontList.Clear();
		}

		// Token: 0x060001B8 RID: 440 RVA: 0x00025B38 File Offset: 0x00023D38
		private void CopyValues<T>(T target, T source, bool allowNulls = false)
		{
			IEnumerator<PropertyInfo> enumerator = (from prop in FFGenerator.smethod_30(FFGenerator.smethod_22(typeof(T).TypeHandle))
				where FFGenerator.<>c__116<T>.smethod_0(prop) && FFGenerator.<>c__116<T>.smethod_1(prop)
				select prop).GetEnumerator();
			try
			{
				while (FFGenerator.smethod_33(enumerator))
				{
					PropertyInfo propertyInfo = enumerator.Current;
					object obj = FFGenerator.smethod_31(propertyInfo, source, null);
					if (allowNulls || obj != null)
					{
						FFGenerator.smethod_32(propertyInfo, target, obj, null);
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					FFGenerator.smethod_26(enumerator);
				}
			}
		}

		// Token: 0x060001B9 RID: 441 RVA: 0x00025BD0 File Offset: 0x00023DD0
		private Dictionary<string, object> GetPlugin(string pluginName, string pluginDescription, string fileName, IEnumerable<string> mimeTypes)
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			int num = 0;
			foreach (string text in mimeTypes.Distinct<string>())
			{
				dictionary.Add(num.ToString(FFGenerator.smethod_19()), new
				{
					description = pluginDescription,
					type = text,
					suffixes = ""
				});
				dictionary.Add(text, new
				{
					description = pluginDescription,
					type = text,
					suffixes = ""
				});
				num++;
			}
			dictionary.Add(<Module>.smethod_23<string>(1692900796U), num);
			dictionary.Add(<Module>.smethod_24<string>(433859567U), pluginDescription);
			dictionary.Add(<Module>.smethod_25<string>(1187605689U), fileName);
			dictionary.Add(<Module>.smethod_23<string>(1325151417U), pluginName);
			return dictionary;
		}

		// Token: 0x060001BA RID: 442 RVA: 0x00025CA0 File Offset: 0x00023EA0
		private Dictionary<string, object> GetMimeTypes()
		{
			int num = 0;
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			if (FFGenerator.smethod_18(this.BrowserFlash, <Module>.smethod_25<string>(1411158342U)))
			{
				BrowserPluginInfo browserPluginInfo = this.PluginList.Find((BrowserPluginInfo x) => x.MimeType.Contains(<Module>.smethod_23<string>(3555602318U)));
				dictionary.Add(num.ToString(FFGenerator.smethod_19()), new
				{
					description = <Module>.smethod_27<string>(1316338888U),
					type = <Module>.smethod_25<string>(2182044821U),
					enabledPlugin = this.GetPlugin(browserPluginInfo.Name, browserPluginInfo.Description, browserPluginInfo.Filename, browserPluginInfo.MimeType),
					suffixes = ""
				});
				dictionary.Add(<Module>.smethod_27<string>(477148414U), new
				{
					description = <Module>.smethod_25<string>(1207680479U),
					type = <Module>.smethod_23<string>(3555602318U),
					enabledPlugin = this.GetPlugin(browserPluginInfo.Name, browserPluginInfo.Description, browserPluginInfo.Filename, browserPluginInfo.MimeType),
					suffixes = ""
				});
				num++;
				dictionary.Add(num.ToString(CultureInfo.InvariantCulture), new
				{
					description = <Module>.smethod_23<string>(3593230568U),
					type = <Module>.smethod_23<string>(1330291919U),
					enabledPlugin = this.GetPlugin(browserPluginInfo.Name, browserPluginInfo.Description, browserPluginInfo.Filename, browserPluginInfo.MimeType),
					suffixes = ""
				});
				dictionary.Add(<Module>.smethod_26<string>(3342617837U), new
				{
					description = <Module>.smethod_23<string>(3593230568U),
					type = <Module>.smethod_26<string>(3342617837U),
					enabledPlugin = this.GetPlugin(browserPluginInfo.Name, browserPluginInfo.Description, browserPluginInfo.Filename, browserPluginInfo.MimeType),
					suffixes = ""
				});
				num++;
			}
			foreach (BrowserPluginInfo browserPluginInfo2 in this.PluginList)
			{
				foreach (string text in browserPluginInfo2.MimeType)
				{
					if (!dictionary.ContainsKey(text))
					{
						dictionary.Add(num.ToString(CultureInfo.InvariantCulture), new
						{
							description = browserPluginInfo2.Description,
							type = text,
							enabledPlugin = this.GetPlugin(browserPluginInfo2.Name, browserPluginInfo2.Description, browserPluginInfo2.Filename, browserPluginInfo2.MimeType),
							suffixes = ""
						});
						num++;
						dictionary.Add(text, new
						{
							description = browserPluginInfo2.Description,
							type = text,
							enabledPlugin = this.GetPlugin(browserPluginInfo2.Name, browserPluginInfo2.Description, browserPluginInfo2.Filename, browserPluginInfo2.MimeType),
							suffixes = ""
						});
						num++;
					}
				}
			}
			return dictionary;
		}

		// Token: 0x060001BD RID: 445 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_0(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x060001BE RID: 446 RVA: 0x0000CD19 File Offset: 0x0000AF19
		static Delegate smethod_1(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Combine(delegate_0, delegate_1);
		}

		// Token: 0x060001BF RID: 447 RVA: 0x0000CD22 File Offset: 0x0000AF22
		static Delegate smethod_2(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Remove(delegate_0, delegate_1);
		}

		// Token: 0x060001C0 RID: 448 RVA: 0x0000CD2B File Offset: 0x0000AF2B
		static PropertyChangedEventArgs smethod_3(string string_0)
		{
			return new PropertyChangedEventArgs(string_0);
		}

		// Token: 0x060001C1 RID: 449 RVA: 0x0000CD33 File Offset: 0x0000AF33
		static string smethod_4(string string_0, object[] object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x0000CD3C File Offset: 0x0000AF3C
		static void smethod_5(string string_0, string string_1)
		{
			File.WriteAllText(string_0, string_1);
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_6(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x060001C4 RID: 452 RVA: 0x0000C66E File Offset: 0x0000A86E
		static string smethod_7(string string_0)
		{
			return Path.GetDirectoryName(string_0);
		}

		// Token: 0x060001C5 RID: 453 RVA: 0x0000CD4E File Offset: 0x0000AF4E
		static string[] smethod_8(string string_0, string string_1)
		{
			return Directory.GetFiles(string_0, string_1);
		}

		// Token: 0x060001C6 RID: 454 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_9(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x060001C7 RID: 455 RVA: 0x0000CD60 File Offset: 0x0000AF60
		static void smethod_10(string string_0, string string_1)
		{
			File.Move(string_0, string_1);
		}

		// Token: 0x060001C8 RID: 456 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_11(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x060001C9 RID: 457 RVA: 0x0000CD69 File Offset: 0x0000AF69
		static string smethod_12(string string_0, char char_0, char char_1)
		{
			return string_0.Replace(char_0, char_1);
		}

		// Token: 0x060001CA RID: 458 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_13(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x060001CB RID: 459 RVA: 0x0000CD7D File Offset: 0x0000AF7D
		static bool smethod_14(string string_0, string string_1)
		{
			return string_0.Contains(string_1);
		}

		// Token: 0x060001CC RID: 460 RVA: 0x0000CD86 File Offset: 0x0000AF86
		static string smethod_15()
		{
			return Environment.NewLine;
		}

		// Token: 0x060001CD RID: 461 RVA: 0x0000CD8D File Offset: 0x0000AF8D
		static string smethod_16(string string_0, IEnumerable<string> ienumerable_0)
		{
			return string.Join(string_0, ienumerable_0);
		}

		// Token: 0x060001CE RID: 462 RVA: 0x0000CD96 File Offset: 0x0000AF96
		static string smethod_17(string string_0, object object_0, object object_1, object object_2)
		{
			return string.Format(string_0, object_0, object_1, object_2);
		}

		// Token: 0x060001CF RID: 463 RVA: 0x0000CDA1 File Offset: 0x0000AFA1
		static bool smethod_18(string string_0, string string_1)
		{
			return string_0 != string_1;
		}

		// Token: 0x060001D0 RID: 464 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_19()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x0000CDB1 File Offset: 0x0000AFB1
		static XmlWriterSettings smethod_20()
		{
			return new XmlWriterSettings();
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x0000CDB8 File Offset: 0x0000AFB8
		static void smethod_21(XmlWriterSettings xmlWriterSettings_0, NewLineHandling newLineHandling_0)
		{
			xmlWriterSettings_0.NewLineHandling = newLineHandling_0;
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_22(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060001D4 RID: 468 RVA: 0x0000CDC1 File Offset: 0x0000AFC1
		static XmlSerializer smethod_23(Type type_0)
		{
			return new XmlSerializer(type_0);
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x0000CDC9 File Offset: 0x0000AFC9
		static XmlWriter smethod_24(string string_0, XmlWriterSettings xmlWriterSettings_0)
		{
			return XmlWriter.Create(string_0, xmlWriterSettings_0);
		}

		// Token: 0x060001D6 RID: 470 RVA: 0x0000CDD2 File Offset: 0x0000AFD2
		static void smethod_25(XmlSerializer xmlSerializer_0, XmlWriter xmlWriter_0, object object_0)
		{
			xmlSerializer_0.Serialize(xmlWriter_0, object_0);
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_26(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060001D8 RID: 472 RVA: 0x0000CDDC File Offset: 0x0000AFDC
		static StreamReader smethod_27(string string_0)
		{
			return new StreamReader(string_0);
		}

		// Token: 0x060001D9 RID: 473 RVA: 0x0000CDE4 File Offset: 0x0000AFE4
		static object smethod_28(XmlSerializer xmlSerializer_0, TextReader textReader_0)
		{
			return xmlSerializer_0.Deserialize(textReader_0);
		}

		// Token: 0x060001DA RID: 474 RVA: 0x0000CDED File Offset: 0x0000AFED
		static int smethod_29(BindingSource bindingSource_0, object object_0)
		{
			return bindingSource_0.Add(object_0);
		}

		// Token: 0x060001DB RID: 475 RVA: 0x0000CDF6 File Offset: 0x0000AFF6
		static PropertyInfo[] smethod_30(Type type_0)
		{
			return type_0.GetProperties();
		}

		// Token: 0x060001DC RID: 476 RVA: 0x0000CDFE File Offset: 0x0000AFFE
		static object smethod_31(PropertyInfo propertyInfo_0, object object_0, object[] object_1)
		{
			return propertyInfo_0.GetValue(object_0, object_1);
		}

		// Token: 0x060001DD RID: 477 RVA: 0x0000CE08 File Offset: 0x0000B008
		static void smethod_32(PropertyInfo propertyInfo_0, object object_0, object object_1, object[] object_2)
		{
			propertyInfo_0.SetValue(object_0, object_1, object_2);
		}

		// Token: 0x060001DE RID: 478 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_33(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x0400005E RID: 94
		private string _osVersion;

		// Token: 0x0400005F RID: 95
		private int _osPlatform;

		// Token: 0x04000060 RID: 96
		private string _osLanguage;

		// Token: 0x04000061 RID: 97
		private string _osTimezone;

		// Token: 0x04000062 RID: 98
		private Size _osResolution;

		// Token: 0x04000063 RID: 99
		private bool _osChangeResolution;

		// Token: 0x04000064 RID: 100
		private string _browserProduct;

		// Token: 0x04000065 RID: 101
		private string _browserVersion;

		// Token: 0x04000066 RID: 102
		private string _browserFlash;

		// Token: 0x04000067 RID: 103
		private string _browserCanvasStroke;

		// Token: 0x04000068 RID: 104
		private string _browserCanvasFill;

		// Token: 0x04000069 RID: 105
		private string _browserCanvasFont;

		// Token: 0x0400006A RID: 106
		private int _browserCanvasFontSize = 14;

		// Token: 0x0400006B RID: 107
		private string _currentStatus;

		// Token: 0x0400006C RID: 108
		private string _userAgent;

		// Token: 0x0400006D RID: 109
		private string _advancedUserAgent;

		// Token: 0x0400006E RID: 110
		private string _startPage = <Module>.smethod_27<string>(3694045231U);

		// Token: 0x0400006F RID: 111
		private List<BrowserPluginInfo> _pluginList = new List<BrowserPluginInfo>();

		// Token: 0x04000070 RID: 112
		private bool _enableFontSpoofing = true;

		// Token: 0x04000071 RID: 113
		private bool _flashDisableDeviceFontEnumeration;

		// Token: 0x04000072 RID: 114
		private bool _flashAvHardwareDisable;

		// Token: 0x04000073 RID: 115
		private List<string> _fontList = new List<string>();

		// Token: 0x04000074 RID: 116
		private string _profileNotes;

		// Token: 0x04000075 RID: 117
		private string _importedProfilePath;

		// Token: 0x04000076 RID: 118
		private bool _isProfileImported;

		// Token: 0x04000077 RID: 119
		[XmlIgnore]
		public StaticData StaticData = new StaticData();
	}
}
