﻿namespace FraudFox
{
	// Token: 0x02000027 RID: 39
	public partial class Logs : global::System.Windows.Forms.Form
	{
		// Token: 0x06000288 RID: 648 RVA: 0x0000D223 File Offset: 0x0000B423
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				global::FraudFox.Logs.smethod_3(this.components);
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000289 RID: 649 RVA: 0x00027120 File Offset: 0x00025320
		private void InitializeComponent()
		{
			this.txtLog = global::FraudFox.Logs.smethod_7();
			global::FraudFox.Logs.smethod_8(this);
			this.txtLog.Location = new global::System.Drawing.Point(12, 12);
			this.txtLog.Multiline = true;
			this.txtLog.Name = global::<Module>.smethod_27<string>(40238557U);
			this.txtLog.ReadOnly = true;
			this.txtLog.ScrollBars = global::System.Windows.Forms.ScrollBars.Vertical;
			this.txtLog.Size = new global::System.Drawing.Size(668, 384);
			this.txtLog.TabIndex = 0;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(692, 408);
			base.Controls.Add(this.txtLog);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			base.Name = global::<Module>.smethod_24<string>(1428211021U);
			base.ShowInTaskbar = false;
			this.Text = global::<Module>.smethod_27<string>(2242551835U);
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.Logs_FormClosing);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400009A RID: 154
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400009B RID: 155
		private global::System.Windows.Forms.TextBox txtLog;
	}
}
