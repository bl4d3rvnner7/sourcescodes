﻿using System;
using System.Threading;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x02000009 RID: 9
	internal class IAsyncProxyResult : IAsyncResult
	{
		// Token: 0x06000058 RID: 88 RVA: 0x0000C12A File Offset: 0x0000A32A
		internal void Init(object stateObject)
		{
			this.m_StateObject = stateObject;
			this.m_Completed = false;
			if (this.m_WaitHandle != null)
			{
				IAsyncProxyResult.smethod_0(this.m_WaitHandle);
			}
		}

		// Token: 0x06000059 RID: 89 RVA: 0x0000C14E File Offset: 0x0000A34E
		internal void Reset()
		{
			this.m_StateObject = null;
			this.m_Completed = true;
			if (this.m_WaitHandle != null)
			{
				IAsyncProxyResult.smethod_1(this.m_WaitHandle);
			}
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x0600005A RID: 90 RVA: 0x0000C172 File Offset: 0x0000A372
		public bool IsCompleted
		{
			get
			{
				return this.m_Completed;
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x0600005B RID: 91 RVA: 0x0000C17A File Offset: 0x0000A37A
		public bool CompletedSynchronously
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x0600005C RID: 92 RVA: 0x0000C17D File Offset: 0x0000A37D
		public object AsyncState
		{
			get
			{
				return this.m_StateObject;
			}
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x0600005D RID: 93 RVA: 0x0000C185 File Offset: 0x0000A385
		public WaitHandle AsyncWaitHandle
		{
			get
			{
				if (this.m_WaitHandle == null)
				{
					this.m_WaitHandle = IAsyncProxyResult.smethod_2(false);
				}
				return this.m_WaitHandle;
			}
		}

		// Token: 0x0600005F RID: 95 RVA: 0x0000C1B0 File Offset: 0x0000A3B0
		static bool smethod_0(EventWaitHandle eventWaitHandle_0)
		{
			return eventWaitHandle_0.Reset();
		}

		// Token: 0x06000060 RID: 96 RVA: 0x0000C1B8 File Offset: 0x0000A3B8
		static bool smethod_1(EventWaitHandle eventWaitHandle_0)
		{
			return eventWaitHandle_0.Set();
		}

		// Token: 0x06000061 RID: 97 RVA: 0x0000C1C0 File Offset: 0x0000A3C0
		static ManualResetEvent smethod_2(bool bool_0)
		{
			return new ManualResetEvent(bool_0);
		}

		// Token: 0x04000026 RID: 38
		internal bool m_Completed = true;

		// Token: 0x04000027 RID: 39
		private object m_StateObject;

		// Token: 0x04000028 RID: 40
		private ManualResetEvent m_WaitHandle;
	}
}
