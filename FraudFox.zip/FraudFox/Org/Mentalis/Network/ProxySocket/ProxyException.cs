﻿using System;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x0200000A RID: 10
	public class ProxyException : Exception
	{
		// Token: 0x06000062 RID: 98 RVA: 0x0000C1C8 File Offset: 0x0000A3C8
		public ProxyException()
			: this(<Module>.smethod_27<string>(3151450162U))
		{
		}

		// Token: 0x06000063 RID: 99 RVA: 0x0000C1DA File Offset: 0x0000A3DA
		public ProxyException(string message)
			: base(message)
		{
		}

		// Token: 0x06000064 RID: 100 RVA: 0x0000C1E3 File Offset: 0x0000A3E3
		public ProxyException(int socks5Error)
			: this(ProxyException.Socks5ToString(socks5Error))
		{
		}

		// Token: 0x06000065 RID: 101 RVA: 0x00021D30 File Offset: 0x0001FF30
		public static string Socks5ToString(int socks5Error)
		{
			switch (socks5Error)
			{
			case 0:
				return <Module>.smethod_26<string>(3124777580U);
			case 1:
				return <Module>.smethod_27<string>(2079151223U);
			case 2:
				return <Module>.smethod_26<string>(1514362460U);
			case 3:
				return <Module>.smethod_23<string>(45687770U);
			case 4:
				return <Module>.smethod_27<string>(2679461692U);
			case 5:
				return <Module>.smethod_27<string>(2772705078U);
			case 6:
				return <Module>.smethod_23<string>(1361031784U);
			case 7:
				return <Module>.smethod_24<string>(1085752185U);
			case 8:
				return <Module>.smethod_23<string>(3006496927U);
			default:
				return <Module>.smethod_25<string>(359152088U);
			}
		}
	}
}
