﻿using System;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x0200000B RID: 11
	public enum ProxyTypes
	{
		// Token: 0x0400002A RID: 42
		None,
		// Token: 0x0400002B RID: 43
		Socks4,
		// Token: 0x0400002C RID: 44
		Socks5
	}
}
