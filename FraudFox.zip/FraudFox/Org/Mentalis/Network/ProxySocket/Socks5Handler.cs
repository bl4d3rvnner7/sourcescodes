﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using Org.Mentalis.Network.ProxySocket.Authentication;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x0200000E RID: 14
	internal sealed class Socks5Handler : SocksHandler
	{
		// Token: 0x060000B0 RID: 176 RVA: 0x0000C47C File Offset: 0x0000A67C
		public Socks5Handler(Socket server)
			: this(server, "")
		{
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x0000C48A File Offset: 0x0000A68A
		public Socks5Handler(Socket server, string user)
			: this(server, user, "")
		{
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x0000C499 File Offset: 0x0000A699
		public Socks5Handler(Socket server, string user, string pass)
			: base(server, user)
		{
			this.Password = pass;
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x00022708 File Offset: 0x00020908
		private void Authenticate()
		{
			Socket server = base.Server;
			byte[] array = new byte[4];
			Socks5Handler.smethod_3(array, fieldof(<PrivateImplementationDetails>.BB32F1DA18A347847825FCB7B9096876CBFA36F8).FieldHandle);
			Socks5Handler.smethod_4(server, array);
			byte[] array2 = base.ReadBytes(2);
			if (array2[1] == 255)
			{
				throw new ProxyException(<Module>.smethod_26<string>(3892470028U));
			}
			byte b = array2[1];
			AuthMethod authMethod;
			if (b != 0)
			{
				if (b != 2)
				{
					throw Socks5Handler.smethod_5();
				}
				authMethod = new AuthUserPass(base.Server, base.Username, this.Password);
			}
			else
			{
				authMethod = new AuthNone(base.Server);
			}
			authMethod.Authenticate();
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x00022790 File Offset: 0x00020990
		private byte[] GetHostPortBytes(string host, int port)
		{
			if (host == null)
			{
				throw Socks5Handler.smethod_6();
			}
			if (port <= 0 || port > 65535 || Socks5Handler.smethod_7(host) > 255)
			{
				throw Socks5Handler.smethod_8();
			}
			byte[] array = new byte[7 + Socks5Handler.smethod_7(host)];
			array[0] = 5;
			array[1] = 1;
			array[2] = 0;
			array[3] = 3;
			array[4] = (byte)Socks5Handler.smethod_7(host);
			Socks5Handler.smethod_11(Socks5Handler.smethod_10(Socks5Handler.smethod_9(), host), 0, array, 5, Socks5Handler.smethod_7(host));
			Socks5Handler.smethod_11(base.PortToBytes(port), 0, array, Socks5Handler.smethod_7(host) + 5, 2);
			return array;
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x00022820 File Offset: 0x00020A20
		private byte[] GetEndPointBytes(IPEndPoint remoteEP)
		{
			if (remoteEP == null)
			{
				throw Socks5Handler.smethod_6();
			}
			byte[] array = new byte[10];
			array[0] = 5;
			array[1] = 1;
			array[2] = 0;
			array[3] = 1;
			Socks5Handler.smethod_11(base.AddressToBytes(Socks5Handler.smethod_13(Socks5Handler.smethod_12(remoteEP))), 0, array, 4, 4);
			Socks5Handler.smethod_11(base.PortToBytes(Socks5Handler.smethod_14(remoteEP)), 0, array, 8, 2);
			return array;
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x0000C4AA File Offset: 0x0000A6AA
		public override void Negotiate(string host, int port)
		{
			this.Negotiate(this.GetHostPortBytes(host, port));
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x0000C4BA File Offset: 0x0000A6BA
		public override void Negotiate(IPEndPoint remoteEP)
		{
			this.Negotiate(this.GetEndPointBytes(remoteEP));
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x00022880 File Offset: 0x00020A80
		private void Negotiate(byte[] connect)
		{
			this.Authenticate();
			Socks5Handler.smethod_4(base.Server, connect);
			byte[] array = base.ReadBytes(4);
			if (array[1] != 0)
			{
				Socks5Handler.smethod_15(base.Server);
				throw new ProxyException((int)array[1]);
			}
			switch (array[3])
			{
			case 1:
				array = base.ReadBytes(6);
				return;
			case 3:
				array = base.ReadBytes(1);
				array = base.ReadBytes((int)(array[0] + 2));
				return;
			case 4:
				array = base.ReadBytes(18);
				return;
			}
			Socks5Handler.smethod_15(base.Server);
			throw Socks5Handler.smethod_5();
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x00022918 File Offset: 0x00020B18
		public override IAsyncProxyResult BeginNegotiate(string host, int port, HandShakeComplete callback, IPEndPoint proxyEndPoint)
		{
			this.ProtocolComplete = callback;
			this.HandShake = this.GetHostPortBytes(host, port);
			Socks5Handler.smethod_16(base.Server, proxyEndPoint, new AsyncCallback(this.OnConnect), base.Server);
			base.AsyncResult = new IAsyncProxyResult();
			return base.AsyncResult;
		}

		// Token: 0x060000BA RID: 186 RVA: 0x0002296C File Offset: 0x00020B6C
		public override IAsyncProxyResult BeginNegotiate(IPEndPoint remoteEP, HandShakeComplete callback, IPEndPoint proxyEndPoint)
		{
			this.ProtocolComplete = callback;
			this.HandShake = this.GetEndPointBytes(remoteEP);
			Socks5Handler.smethod_16(base.Server, proxyEndPoint, new AsyncCallback(this.OnConnect), base.Server);
			base.AsyncResult = new IAsyncProxyResult();
			return base.AsyncResult;
		}

		// Token: 0x060000BB RID: 187 RVA: 0x000229C0 File Offset: 0x00020BC0
		private void OnConnect(IAsyncResult ar)
		{
			try
			{
				Socks5Handler.smethod_17(base.Server, ar);
			}
			catch (Exception ex)
			{
				this.ProtocolComplete(ex);
				return;
			}
			try
			{
				Socket server = base.Server;
				byte[] array = new byte[4];
				Socks5Handler.smethod_3(array, fieldof(<PrivateImplementationDetails>.BB32F1DA18A347847825FCB7B9096876CBFA36F8).FieldHandle);
				Socks5Handler.smethod_18(server, array, 0, 4, SocketFlags.None, new AsyncCallback(this.OnAuthSent), base.Server);
			}
			catch (Exception ex2)
			{
				this.ProtocolComplete(ex2);
			}
		}

		// Token: 0x060000BC RID: 188 RVA: 0x00022A4C File Offset: 0x00020C4C
		private void OnAuthSent(IAsyncResult ar)
		{
			try
			{
				Socks5Handler.smethod_19(base.Server, ar);
			}
			catch (Exception ex)
			{
				this.ProtocolComplete(ex);
				return;
			}
			try
			{
				base.Buffer = new byte[1024];
				base.Received = 0;
				Socks5Handler.smethod_20(base.Server, base.Buffer, 0, base.Buffer.Length, SocketFlags.None, new AsyncCallback(this.OnAuthReceive), base.Server);
			}
			catch (Exception ex2)
			{
				this.ProtocolComplete(ex2);
			}
		}

		// Token: 0x060000BD RID: 189 RVA: 0x00022AEC File Offset: 0x00020CEC
		private void OnAuthReceive(IAsyncResult ar)
		{
			try
			{
				base.Received += Socks5Handler.smethod_21(base.Server, ar);
				if (base.Received <= 0)
				{
					throw Socks5Handler.smethod_22();
				}
			}
			catch (Exception ex)
			{
				this.ProtocolComplete(ex);
				return;
			}
			try
			{
				if (base.Received < 2)
				{
					Socks5Handler.smethod_20(base.Server, base.Buffer, base.Received, base.Buffer.Length - base.Received, SocketFlags.None, new AsyncCallback(this.OnAuthReceive), base.Server);
				}
				else
				{
					byte b = base.Buffer[1];
					AuthMethod authMethod;
					if (b != 0)
					{
						if (b != 2)
						{
							this.ProtocolComplete(Socks5Handler.smethod_22());
							return;
						}
						authMethod = new AuthUserPass(base.Server, base.Username, this.Password);
					}
					else
					{
						authMethod = new AuthNone(base.Server);
					}
					authMethod.BeginAuthenticate(new HandShakeComplete(this.OnAuthenticated));
				}
			}
			catch (Exception ex2)
			{
				for (;;)
				{
					IL_010D:
					int num = -25036307;
					for (;;)
					{
						switch (num ^ -25036305)
						{
						case 0:
							goto IL_010D;
						case 2:
							this.ProtocolComplete(ex2);
							num = -25036306;
							continue;
						}
						goto Block_10;
					}
				}
				Block_10:;
			}
		}

		// Token: 0x060000BE RID: 190 RVA: 0x00022C2C File Offset: 0x00020E2C
		private void OnAuthenticated(Exception e)
		{
			if (e != null)
			{
				this.ProtocolComplete(e);
				return;
			}
			try
			{
				Socks5Handler.smethod_18(base.Server, this.HandShake, 0, this.HandShake.Length, SocketFlags.None, new AsyncCallback(this.OnSent), base.Server);
			}
			catch (Exception ex)
			{
				this.ProtocolComplete(ex);
			}
		}

		// Token: 0x060000BF RID: 191 RVA: 0x00022C9C File Offset: 0x00020E9C
		private void OnSent(IAsyncResult ar)
		{
			try
			{
				Socks5Handler.smethod_19(base.Server, ar);
			}
			catch (Exception ex)
			{
				this.ProtocolComplete(ex);
				return;
			}
			try
			{
				base.Buffer = new byte[5];
				base.Received = 0;
				Socks5Handler.smethod_20(base.Server, base.Buffer, 0, base.Buffer.Length, SocketFlags.None, new AsyncCallback(this.OnReceive), base.Server);
			}
			catch (Exception ex2)
			{
				for (;;)
				{
					IL_0091:
					int num = 357991860;
					for (;;)
					{
						switch (num ^ 357991861)
						{
						case 0:
							goto IL_0091;
						case 1:
							this.ProtocolComplete(ex2);
							num = 357991863;
							continue;
						}
						goto Block_6;
					}
				}
				Block_6:;
			}
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x00022D60 File Offset: 0x00020F60
		private void OnReceive(IAsyncResult ar)
		{
			try
			{
				base.Received += Socks5Handler.smethod_21(base.Server, ar);
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_004A:
					int num = -1037909478;
					for (;;)
					{
						switch (num ^ -1037909477)
						{
						case 0:
							goto IL_004A;
						case 1:
							this.ProtocolComplete(ex);
							num = -1037909479;
							continue;
						}
						goto Block_4;
					}
				}
				Block_4:
				return;
			}
			try
			{
				if (base.Received == base.Buffer.Length)
				{
					this.ProcessReply(base.Buffer);
				}
				else
				{
					Socks5Handler.smethod_20(base.Server, base.Buffer, base.Received, base.Buffer.Length - base.Received, SocketFlags.None, new AsyncCallback(this.OnReceive), base.Server);
				}
			}
			catch (Exception ex2)
			{
				this.ProtocolComplete(ex2);
			}
		}

		// Token: 0x060000C1 RID: 193 RVA: 0x00022E48 File Offset: 0x00021048
		private void ProcessReply(byte[] buffer)
		{
			switch (buffer[3])
			{
			case 1:
				base.Buffer = new byte[5];
				goto IL_004D;
			case 3:
				base.Buffer = new byte[(int)(buffer[4] + 2)];
				goto IL_004D;
			case 4:
				buffer = new byte[17];
				goto IL_004D;
			}
			throw Socks5Handler.smethod_5();
			IL_004D:
			base.Received = 0;
			Socks5Handler.smethod_20(base.Server, base.Buffer, 0, base.Buffer.Length, SocketFlags.None, new AsyncCallback(this.OnReadLast), base.Server);
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x00022ED8 File Offset: 0x000210D8
		private void OnReadLast(IAsyncResult ar)
		{
			try
			{
				base.Received += Socks5Handler.smethod_21(base.Server, ar);
			}
			catch (Exception ex)
			{
				this.ProtocolComplete(ex);
				return;
			}
			try
			{
				if (base.Received == base.Buffer.Length)
				{
					this.ProtocolComplete(null);
				}
				else
				{
					Socks5Handler.smethod_20(base.Server, base.Buffer, base.Received, base.Buffer.Length - base.Received, SocketFlags.None, new AsyncCallback(this.OnReadLast), base.Server);
				}
			}
			catch (Exception ex2)
			{
				this.ProtocolComplete(ex2);
			}
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x060000C3 RID: 195 RVA: 0x0000C4C9 File Offset: 0x0000A6C9
		// (set) Token: 0x060000C4 RID: 196 RVA: 0x0000C4D1 File Offset: 0x0000A6D1
		private string Password
		{
			get
			{
				return this.m_Password;
			}
			set
			{
				if (value == null)
				{
					throw Socks5Handler.smethod_6();
				}
				this.m_Password = value;
			}
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x060000C5 RID: 197 RVA: 0x0000C4E3 File Offset: 0x0000A6E3
		// (set) Token: 0x060000C6 RID: 198 RVA: 0x0000C4EB File Offset: 0x0000A6EB
		private byte[] HandShake
		{
			get
			{
				return this.m_HandShake;
			}
			set
			{
				this.m_HandShake = value;
			}
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_3(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x0000C423 File Offset: 0x0000A623
		static int smethod_4(Socket socket_0, byte[] byte_0)
		{
			return socket_0.Send(byte_0);
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x0000C4FD File Offset: 0x0000A6FD
		static ProtocolViolationException smethod_5()
		{
			return new ProtocolViolationException();
		}

		// Token: 0x060000CA RID: 202 RVA: 0x0000C372 File Offset: 0x0000A572
		static ArgumentNullException smethod_6()
		{
			return new ArgumentNullException();
		}

		// Token: 0x060000CB RID: 203 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_7(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x060000CC RID: 204 RVA: 0x0000C384 File Offset: 0x0000A584
		static ArgumentException smethod_8()
		{
			return new ArgumentException();
		}

		// Token: 0x060000CD RID: 205 RVA: 0x0000C3FB File Offset: 0x0000A5FB
		static Encoding smethod_9()
		{
			return Encoding.ASCII;
		}

		// Token: 0x060000CE RID: 206 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_10(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x060000CF RID: 207 RVA: 0x0000C3EE File Offset: 0x0000A5EE
		static void smethod_11(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Array.Copy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x0000C413 File Offset: 0x0000A613
		static IPAddress smethod_12(IPEndPoint ipendPoint_0)
		{
			return ipendPoint_0.Address;
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x0000C41B File Offset: 0x0000A61B
		static long smethod_13(IPAddress ipaddress_0)
		{
			return ipaddress_0.Address;
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x0000C40B File Offset: 0x0000A60B
		static int smethod_14(IPEndPoint ipendPoint_0)
		{
			return ipendPoint_0.Port;
		}

		// Token: 0x060000D3 RID: 211 RVA: 0x0000C42C File Offset: 0x0000A62C
		static void smethod_15(Socket socket_0)
		{
			socket_0.Close();
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x0000C434 File Offset: 0x0000A634
		static IAsyncResult smethod_16(Socket socket_0, EndPoint endPoint_0, AsyncCallback asyncCallback_0, object object_0)
		{
			return socket_0.BeginConnect(endPoint_0, asyncCallback_0, object_0);
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x0000C43F File Offset: 0x0000A63F
		static void smethod_17(Socket socket_0, IAsyncResult iasyncResult_0)
		{
			socket_0.EndConnect(iasyncResult_0);
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x0000C448 File Offset: 0x0000A648
		static IAsyncResult smethod_18(Socket socket_0, byte[] byte_0, int int_0, int int_1, SocketFlags socketFlags_0, AsyncCallback asyncCallback_0, object object_0)
		{
			return socket_0.BeginSend(byte_0, int_0, int_1, socketFlags_0, asyncCallback_0, object_0);
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x0000C459 File Offset: 0x0000A659
		static int smethod_19(Socket socket_0, IAsyncResult iasyncResult_0)
		{
			return socket_0.EndSend(iasyncResult_0);
		}

		// Token: 0x060000D8 RID: 216 RVA: 0x0000C462 File Offset: 0x0000A662
		static IAsyncResult smethod_20(Socket socket_0, byte[] byte_0, int int_0, int int_1, SocketFlags socketFlags_0, AsyncCallback asyncCallback_0, object object_0)
		{
			return socket_0.BeginReceive(byte_0, int_0, int_1, socketFlags_0, asyncCallback_0, object_0);
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x0000C473 File Offset: 0x0000A673
		static int smethod_21(Socket socket_0, IAsyncResult iasyncResult_0)
		{
			return socket_0.EndReceive(iasyncResult_0);
		}

		// Token: 0x060000DA RID: 218 RVA: 0x0000C39D File Offset: 0x0000A59D
		static SocketException smethod_22()
		{
			return new SocketException();
		}

		// Token: 0x04000036 RID: 54
		private string m_Password;

		// Token: 0x04000037 RID: 55
		private byte[] m_HandShake;
	}
}
