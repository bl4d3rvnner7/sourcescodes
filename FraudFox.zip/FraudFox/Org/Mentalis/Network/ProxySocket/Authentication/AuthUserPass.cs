﻿using System;
using System.Net.Sockets;
using System.Text;

namespace Org.Mentalis.Network.ProxySocket.Authentication
{
	// Token: 0x02000013 RID: 19
	internal sealed class AuthUserPass : AuthMethod
	{
		// Token: 0x06000101 RID: 257 RVA: 0x0000C60B File Offset: 0x0000A80B
		public AuthUserPass(Socket server, string user, string pass)
			: base(server)
		{
			this.Username = user;
			this.Password = pass;
		}

		// Token: 0x06000102 RID: 258 RVA: 0x00023038 File Offset: 0x00021238
		private byte[] GetAuthenticationBytes()
		{
			byte[] array = new byte[3 + AuthUserPass.smethod_1(this.Username) + AuthUserPass.smethod_1(this.Password)];
			array[0] = 1;
			array[1] = (byte)AuthUserPass.smethod_1(this.Username);
			AuthUserPass.smethod_4(AuthUserPass.smethod_3(AuthUserPass.smethod_2(), this.Username), 0, array, 2, AuthUserPass.smethod_1(this.Username));
			array[AuthUserPass.smethod_1(this.Username) + 2] = (byte)AuthUserPass.smethod_1(this.Password);
			AuthUserPass.smethod_4(AuthUserPass.smethod_3(AuthUserPass.smethod_2(), this.Password), 0, array, AuthUserPass.smethod_1(this.Username) + 3, AuthUserPass.smethod_1(this.Password));
			return array;
		}

		// Token: 0x06000103 RID: 259 RVA: 0x000230E8 File Offset: 0x000212E8
		public override void Authenticate()
		{
			AuthUserPass.smethod_5(base.Server, this.GetAuthenticationBytes());
			byte[] array = new byte[2];
			for (int num = 0; num != 2; num += AuthUserPass.smethod_6(base.Server, array, num, 2 - num, SocketFlags.None))
			{
			}
			if (array[1] != 0)
			{
				AuthUserPass.smethod_7(base.Server);
				throw new ProxyException(<Module>.smethod_26<string>(3902046422U));
			}
		}

		// Token: 0x06000104 RID: 260 RVA: 0x0002314C File Offset: 0x0002134C
		public override void BeginAuthenticate(HandShakeComplete callback)
		{
			this.CallBack = callback;
			AuthUserPass.smethod_8(base.Server, this.GetAuthenticationBytes(), 0, 3 + AuthUserPass.smethod_1(this.Username) + AuthUserPass.smethod_1(this.Password), SocketFlags.None, new AsyncCallback(this.OnSent), base.Server);
		}

		// Token: 0x06000105 RID: 261 RVA: 0x000231A0 File Offset: 0x000213A0
		private void OnSent(IAsyncResult ar)
		{
			try
			{
				AuthUserPass.smethod_9(base.Server, ar);
				base.Buffer = new byte[2];
				AuthUserPass.smethod_10(base.Server, base.Buffer, 0, 2, SocketFlags.None, new AsyncCallback(this.OnReceive), base.Server);
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_0071:
					int num = -684965291;
					for (;;)
					{
						switch (num ^ -684965289)
						{
						case 0:
							goto IL_0071;
						case 2:
							this.CallBack(ex);
							num = -684965290;
							continue;
						}
						goto Block_3;
					}
				}
				Block_3:;
			}
		}

		// Token: 0x06000106 RID: 262 RVA: 0x00023238 File Offset: 0x00021438
		private void OnReceive(IAsyncResult ar)
		{
			try
			{
				base.Received += AuthUserPass.smethod_11(base.Server, ar);
				if (base.Received == base.Buffer.Length)
				{
					if (base.Buffer[1] != 0)
					{
						throw new ProxyException(<Module>.smethod_23<string>(2549817425U));
					}
					this.CallBack(null);
				}
				else
				{
					AuthUserPass.smethod_10(base.Server, base.Buffer, base.Received, base.Buffer.Length - base.Received, SocketFlags.None, new AsyncCallback(this.OnReceive), base.Server);
				}
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_00BC:
					int num = 333031468;
					for (;;)
					{
						switch (num ^ 333031469)
						{
						case 1:
							this.CallBack(ex);
							num = 333031469;
							continue;
						case 2:
							goto IL_00BC;
						}
						goto Block_5;
					}
				}
				Block_5:;
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x06000107 RID: 263 RVA: 0x0000C622 File Offset: 0x0000A822
		// (set) Token: 0x06000108 RID: 264 RVA: 0x0000C62A File Offset: 0x0000A82A
		private string Username
		{
			get
			{
				return this.m_Username;
			}
			set
			{
				if (value == null)
				{
					throw AuthUserPass.smethod_12();
				}
				this.m_Username = value;
			}
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x06000109 RID: 265 RVA: 0x0000C63C File Offset: 0x0000A83C
		// (set) Token: 0x0600010A RID: 266 RVA: 0x0000C644 File Offset: 0x0000A844
		private string Password
		{
			get
			{
				return this.m_Password;
			}
			set
			{
				if (value == null)
				{
					throw AuthUserPass.smethod_12();
				}
				this.m_Password = value;
			}
		}

		// Token: 0x0600010B RID: 267 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_1(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x0600010C RID: 268 RVA: 0x0000C3FB File Offset: 0x0000A5FB
		static Encoding smethod_2()
		{
			return Encoding.ASCII;
		}

		// Token: 0x0600010D RID: 269 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_3(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x0600010E RID: 270 RVA: 0x0000C3EE File Offset: 0x0000A5EE
		static void smethod_4(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Array.Copy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x0600010F RID: 271 RVA: 0x0000C423 File Offset: 0x0000A623
		static int smethod_5(Socket socket_0, byte[] byte_0)
		{
			return socket_0.Send(byte_0);
		}

		// Token: 0x06000110 RID: 272 RVA: 0x0000C59F File Offset: 0x0000A79F
		static int smethod_6(Socket socket_0, byte[] byte_0, int int_0, int int_1, SocketFlags socketFlags_0)
		{
			return socket_0.Receive(byte_0, int_0, int_1, socketFlags_0);
		}

		// Token: 0x06000111 RID: 273 RVA: 0x0000C42C File Offset: 0x0000A62C
		static void smethod_7(Socket socket_0)
		{
			socket_0.Close();
		}

		// Token: 0x06000112 RID: 274 RVA: 0x0000C448 File Offset: 0x0000A648
		static IAsyncResult smethod_8(Socket socket_0, byte[] byte_0, int int_0, int int_1, SocketFlags socketFlags_0, AsyncCallback asyncCallback_0, object object_0)
		{
			return socket_0.BeginSend(byte_0, int_0, int_1, socketFlags_0, asyncCallback_0, object_0);
		}

		// Token: 0x06000113 RID: 275 RVA: 0x0000C459 File Offset: 0x0000A659
		static int smethod_9(Socket socket_0, IAsyncResult iasyncResult_0)
		{
			return socket_0.EndSend(iasyncResult_0);
		}

		// Token: 0x06000114 RID: 276 RVA: 0x0000C462 File Offset: 0x0000A662
		static IAsyncResult smethod_10(Socket socket_0, byte[] byte_0, int int_0, int int_1, SocketFlags socketFlags_0, AsyncCallback asyncCallback_0, object object_0)
		{
			return socket_0.BeginReceive(byte_0, int_0, int_1, socketFlags_0, asyncCallback_0, object_0);
		}

		// Token: 0x06000115 RID: 277 RVA: 0x0000C473 File Offset: 0x0000A673
		static int smethod_11(Socket socket_0, IAsyncResult iasyncResult_0)
		{
			return socket_0.EndReceive(iasyncResult_0);
		}

		// Token: 0x06000116 RID: 278 RVA: 0x0000C372 File Offset: 0x0000A572
		static ArgumentNullException smethod_12()
		{
			return new ArgumentNullException();
		}

		// Token: 0x04000042 RID: 66
		private string m_Username;

		// Token: 0x04000043 RID: 67
		private string m_Password;
	}
}
