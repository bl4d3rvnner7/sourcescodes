﻿using System;
using System.Net.Sockets;

namespace Org.Mentalis.Network.ProxySocket.Authentication
{
	// Token: 0x02000011 RID: 17
	internal abstract class AuthMethod
	{
		// Token: 0x060000F4 RID: 244 RVA: 0x0000C5AC File Offset: 0x0000A7AC
		public AuthMethod(Socket server)
		{
			this.Server = server;
		}

		// Token: 0x060000F5 RID: 245
		public abstract void Authenticate();

		// Token: 0x060000F6 RID: 246
		public abstract void BeginAuthenticate(HandShakeComplete callback);

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x060000F7 RID: 247 RVA: 0x0000C5BB File Offset: 0x0000A7BB
		// (set) Token: 0x060000F8 RID: 248 RVA: 0x0000C5C3 File Offset: 0x0000A7C3
		protected Socket Server
		{
			get
			{
				return this.m_Server;
			}
			set
			{
				if (value == null)
				{
					throw AuthMethod.smethod_0();
				}
				this.m_Server = value;
			}
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x060000F9 RID: 249 RVA: 0x0000C5D5 File Offset: 0x0000A7D5
		// (set) Token: 0x060000FA RID: 250 RVA: 0x0000C5DD File Offset: 0x0000A7DD
		protected byte[] Buffer
		{
			get
			{
				return this.m_Buffer;
			}
			set
			{
				this.m_Buffer = value;
			}
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x060000FB RID: 251 RVA: 0x0000C5E6 File Offset: 0x0000A7E6
		// (set) Token: 0x060000FC RID: 252 RVA: 0x0000C5EE File Offset: 0x0000A7EE
		protected int Received
		{
			get
			{
				return this.m_Received;
			}
			set
			{
				this.m_Received = value;
			}
		}

		// Token: 0x060000FD RID: 253 RVA: 0x0000C372 File Offset: 0x0000A572
		static ArgumentNullException smethod_0()
		{
			return new ArgumentNullException();
		}

		// Token: 0x0400003E RID: 62
		private byte[] m_Buffer;

		// Token: 0x0400003F RID: 63
		private Socket m_Server;

		// Token: 0x04000040 RID: 64
		protected HandShakeComplete CallBack;

		// Token: 0x04000041 RID: 65
		private int m_Received;
	}
}
