﻿using System;
using System.Net.Sockets;

namespace Org.Mentalis.Network.ProxySocket.Authentication
{
	// Token: 0x02000012 RID: 18
	internal sealed class AuthNone : AuthMethod
	{
		// Token: 0x060000FE RID: 254 RVA: 0x0000C5F7 File Offset: 0x0000A7F7
		public AuthNone(Socket server)
			: base(server)
		{
		}

		// Token: 0x060000FF RID: 255 RVA: 0x0000C600 File Offset: 0x0000A800
		public override void Authenticate()
		{
		}

		// Token: 0x06000100 RID: 256 RVA: 0x0000C602 File Offset: 0x0000A802
		public override void BeginAuthenticate(HandShakeComplete callback)
		{
			callback(null);
		}
	}
}
