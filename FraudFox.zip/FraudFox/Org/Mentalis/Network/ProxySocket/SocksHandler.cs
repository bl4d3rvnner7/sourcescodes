﻿using System;
using System.Net;
using System.Net.Sockets;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x02000010 RID: 16
	internal abstract class SocksHandler
	{
		// Token: 0x060000DF RID: 223 RVA: 0x0000C504 File Offset: 0x0000A704
		public SocksHandler(Socket server, string user)
		{
			this.Server = server;
			this.Username = user;
		}

		// Token: 0x060000E0 RID: 224 RVA: 0x0000C51A File Offset: 0x0000A71A
		protected byte[] PortToBytes(int port)
		{
			return new byte[]
			{
				(byte)(port / 256),
				(byte)(port % 256)
			};
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x00022F98 File Offset: 0x00021198
		protected byte[] AddressToBytes(long address)
		{
			return new byte[]
			{
				(byte)(address % 256L),
				(byte)(address / 256L % 256L),
				(byte)(address / 65536L % 256L),
				(byte)(address / 16777216L)
			};
		}

		// Token: 0x060000E2 RID: 226 RVA: 0x00022FFC File Offset: 0x000211FC
		protected byte[] ReadBytes(int count)
		{
			if (count <= 0)
			{
				throw SocksHandler.smethod_0();
			}
			byte[] array = new byte[count];
			for (int num = 0; num != count; num += SocksHandler.smethod_1(this.Server, array, num, count - num, SocketFlags.None))
			{
			}
			return array;
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x060000E3 RID: 227 RVA: 0x0000C538 File Offset: 0x0000A738
		// (set) Token: 0x060000E4 RID: 228 RVA: 0x0000C540 File Offset: 0x0000A740
		protected Socket Server
		{
			get
			{
				return this.m_Server;
			}
			set
			{
				if (value == null)
				{
					throw SocksHandler.smethod_2();
				}
				this.m_Server = value;
			}
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x060000E5 RID: 229 RVA: 0x0000C552 File Offset: 0x0000A752
		// (set) Token: 0x060000E6 RID: 230 RVA: 0x0000C55A File Offset: 0x0000A75A
		protected string Username
		{
			get
			{
				return this.m_Username;
			}
			set
			{
				if (value == null)
				{
					throw SocksHandler.smethod_2();
				}
				this.m_Username = value;
			}
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x060000E7 RID: 231 RVA: 0x0000C56C File Offset: 0x0000A76C
		// (set) Token: 0x060000E8 RID: 232 RVA: 0x0000C574 File Offset: 0x0000A774
		protected IAsyncProxyResult AsyncResult
		{
			get
			{
				return this.m_AsyncResult;
			}
			set
			{
				this.m_AsyncResult = value;
			}
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x060000E9 RID: 233 RVA: 0x0000C57D File Offset: 0x0000A77D
		// (set) Token: 0x060000EA RID: 234 RVA: 0x0000C585 File Offset: 0x0000A785
		protected byte[] Buffer
		{
			get
			{
				return this.m_Buffer;
			}
			set
			{
				this.m_Buffer = value;
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x060000EB RID: 235 RVA: 0x0000C58E File Offset: 0x0000A78E
		// (set) Token: 0x060000EC RID: 236 RVA: 0x0000C596 File Offset: 0x0000A796
		protected int Received
		{
			get
			{
				return this.m_Received;
			}
			set
			{
				this.m_Received = value;
			}
		}

		// Token: 0x060000ED RID: 237
		public abstract void Negotiate(string host, int port);

		// Token: 0x060000EE RID: 238
		public abstract void Negotiate(IPEndPoint remoteEP);

		// Token: 0x060000EF RID: 239
		public abstract IAsyncProxyResult BeginNegotiate(IPEndPoint remoteEP, HandShakeComplete callback, IPEndPoint proxyEndPoint);

		// Token: 0x060000F0 RID: 240
		public abstract IAsyncProxyResult BeginNegotiate(string host, int port, HandShakeComplete callback, IPEndPoint proxyEndPoint);

		// Token: 0x060000F1 RID: 241 RVA: 0x0000C384 File Offset: 0x0000A584
		static ArgumentException smethod_0()
		{
			return new ArgumentException();
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x0000C59F File Offset: 0x0000A79F
		static int smethod_1(Socket socket_0, byte[] byte_0, int int_0, int int_1, SocketFlags socketFlags_0)
		{
			return socket_0.Receive(byte_0, int_0, int_1, socketFlags_0);
		}

		// Token: 0x060000F3 RID: 243 RVA: 0x0000C372 File Offset: 0x0000A572
		static ArgumentNullException smethod_2()
		{
			return new ArgumentNullException();
		}

		// Token: 0x04000038 RID: 56
		private Socket m_Server;

		// Token: 0x04000039 RID: 57
		private string m_Username;

		// Token: 0x0400003A RID: 58
		private IAsyncProxyResult m_AsyncResult;

		// Token: 0x0400003B RID: 59
		private byte[] m_Buffer;

		// Token: 0x0400003C RID: 60
		private int m_Received;

		// Token: 0x0400003D RID: 61
		protected HandShakeComplete ProtocolComplete;
	}
}
