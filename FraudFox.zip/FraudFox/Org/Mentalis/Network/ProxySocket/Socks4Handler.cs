﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x0200000D RID: 13
	internal sealed class Socks4Handler : SocksHandler
	{
		// Token: 0x06000093 RID: 147 RVA: 0x0000C3BD File Offset: 0x0000A5BD
		public Socks4Handler(Socket server, string user)
			: base(server, user)
		{
		}

		// Token: 0x06000094 RID: 148 RVA: 0x00022214 File Offset: 0x00020414
		private byte[] GetHostPortBytes(string host, int port)
		{
			if (host == null)
			{
				throw Socks4Handler.smethod_3();
			}
			if (port <= 0 || port > 65535)
			{
				throw Socks4Handler.smethod_4();
			}
			byte[] array = new byte[10 + Socks4Handler.smethod_5(base.Username) + Socks4Handler.smethod_5(host)];
			array[0] = 4;
			array[1] = 1;
			Socks4Handler.smethod_6(base.PortToBytes(port), 0, array, 2, 2);
			byte[] array2 = array;
			int num = 4;
			byte[] array3 = array;
			int num2 = 5;
			array[6] = 0;
			array3[num2] = 0;
			array2[num] = 0;
			array[7] = 1;
			Socks4Handler.smethod_6(Socks4Handler.smethod_8(Socks4Handler.smethod_7(), base.Username), 0, array, 8, Socks4Handler.smethod_5(base.Username));
			array[8 + Socks4Handler.smethod_5(base.Username)] = 0;
			Socks4Handler.smethod_6(Socks4Handler.smethod_8(Socks4Handler.smethod_7(), host), 0, array, 9 + Socks4Handler.smethod_5(base.Username), Socks4Handler.smethod_5(host));
			array[9 + Socks4Handler.smethod_5(base.Username) + Socks4Handler.smethod_5(host)] = 0;
			return array;
		}

		// Token: 0x06000095 RID: 149 RVA: 0x000222F4 File Offset: 0x000204F4
		private byte[] GetEndPointBytes(IPEndPoint remoteEP)
		{
			if (remoteEP == null)
			{
				throw Socks4Handler.smethod_3();
			}
			byte[] array = new byte[9 + Socks4Handler.smethod_5(base.Username)];
			array[0] = 4;
			array[1] = 1;
			Socks4Handler.smethod_6(base.PortToBytes(Socks4Handler.smethod_9(remoteEP)), 0, array, 2, 2);
			Socks4Handler.smethod_6(base.AddressToBytes(Socks4Handler.smethod_11(Socks4Handler.smethod_10(remoteEP))), 0, array, 4, 4);
			Socks4Handler.smethod_6(Socks4Handler.smethod_8(Socks4Handler.smethod_7(), base.Username), 0, array, 8, Socks4Handler.smethod_5(base.Username));
			array[8 + Socks4Handler.smethod_5(base.Username)] = 0;
			return array;
		}

		// Token: 0x06000096 RID: 150 RVA: 0x0000C3C7 File Offset: 0x0000A5C7
		public override void Negotiate(string host, int port)
		{
			this.Negotiate(this.GetHostPortBytes(host, port));
		}

		// Token: 0x06000097 RID: 151 RVA: 0x0000C3D7 File Offset: 0x0000A5D7
		public override void Negotiate(IPEndPoint remoteEP)
		{
			this.Negotiate(this.GetEndPointBytes(remoteEP));
		}

		// Token: 0x06000098 RID: 152 RVA: 0x0002238C File Offset: 0x0002058C
		private void Negotiate(byte[] connect)
		{
			if (connect == null)
			{
				throw Socks4Handler.smethod_3();
			}
			if (connect.Length < 2)
			{
				throw Socks4Handler.smethod_4();
			}
			Socks4Handler.smethod_12(base.Server, connect);
			if (base.ReadBytes(8)[1] != 90)
			{
				Socks4Handler.smethod_13(base.Server);
				throw new ProxyException(<Module>.smethod_26<string>(2444853606U));
			}
		}

		// Token: 0x06000099 RID: 153 RVA: 0x000223E4 File Offset: 0x000205E4
		public override IAsyncProxyResult BeginNegotiate(string host, int port, HandShakeComplete callback, IPEndPoint proxyEndPoint)
		{
			this.ProtocolComplete = callback;
			base.Buffer = this.GetHostPortBytes(host, port);
			Socks4Handler.smethod_14(base.Server, proxyEndPoint, new AsyncCallback(this.OnConnect), base.Server);
			base.AsyncResult = new IAsyncProxyResult();
			return base.AsyncResult;
		}

		// Token: 0x0600009A RID: 154 RVA: 0x00022438 File Offset: 0x00020638
		public override IAsyncProxyResult BeginNegotiate(IPEndPoint remoteEP, HandShakeComplete callback, IPEndPoint proxyEndPoint)
		{
			this.ProtocolComplete = callback;
			base.Buffer = this.GetEndPointBytes(remoteEP);
			Socks4Handler.smethod_14(base.Server, proxyEndPoint, new AsyncCallback(this.OnConnect), base.Server);
			base.AsyncResult = new IAsyncProxyResult();
			return base.AsyncResult;
		}

		// Token: 0x0600009B RID: 155 RVA: 0x0002248C File Offset: 0x0002068C
		private void OnConnect(IAsyncResult ar)
		{
			try
			{
				Socks4Handler.smethod_15(base.Server, ar);
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_003D:
					int num = 959594705;
					for (;;)
					{
						switch (num ^ 959594704)
						{
						case 0:
							goto IL_003D;
						case 1:
							this.ProtocolComplete(ex);
							num = 959594706;
							continue;
						}
						goto Block_4;
					}
				}
				Block_4:
				return;
			}
			try
			{
				Socks4Handler.smethod_16(base.Server, base.Buffer, 0, base.Buffer.Length, SocketFlags.None, new AsyncCallback(this.OnSent), base.Server);
			}
			catch (Exception ex2)
			{
				this.ProtocolComplete(ex2);
			}
		}

		// Token: 0x0600009C RID: 156 RVA: 0x0002253C File Offset: 0x0002073C
		private void OnSent(IAsyncResult ar)
		{
			try
			{
				if (Socks4Handler.smethod_17(base.Server, ar) < base.Buffer.Length)
				{
					this.ProtocolComplete(Socks4Handler.smethod_18());
					return;
				}
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_005C:
					int num = -733640363;
					for (;;)
					{
						switch (num ^ -733640361)
						{
						case 0:
							goto IL_005C;
						case 2:
							this.ProtocolComplete(ex);
							num = -733640362;
							continue;
						}
						goto Block_5;
					}
				}
				Block_5:
				return;
			}
			try
			{
				base.Buffer = new byte[8];
				base.Received = 0;
				Socks4Handler.smethod_19(base.Server, base.Buffer, 0, base.Buffer.Length, SocketFlags.None, new AsyncCallback(this.OnReceive), base.Server);
			}
			catch (Exception ex2)
			{
				this.ProtocolComplete(ex2);
			}
		}

		// Token: 0x0600009D RID: 157 RVA: 0x00022620 File Offset: 0x00020820
		private void OnReceive(IAsyncResult ar)
		{
			try
			{
				int num = Socks4Handler.smethod_20(base.Server, ar);
				if (num <= 0)
				{
					this.ProtocolComplete(Socks4Handler.smethod_18());
				}
				else
				{
					base.Received += num;
					if (base.Received == 8)
					{
						if (base.Buffer[1] == 90)
						{
							this.ProtocolComplete(null);
						}
						else
						{
							Socks4Handler.smethod_13(base.Server);
							this.ProtocolComplete(new ProxyException(<Module>.smethod_25<string>(1502159209U)));
						}
					}
					else
					{
						Socks4Handler.smethod_19(base.Server, base.Buffer, base.Received, base.Buffer.Length - base.Received, SocketFlags.None, new AsyncCallback(this.OnReceive), base.Server);
					}
				}
			}
			catch (Exception ex)
			{
				this.ProtocolComplete(ex);
			}
		}

		// Token: 0x0600009E RID: 158 RVA: 0x0000C372 File Offset: 0x0000A572
		static ArgumentNullException smethod_3()
		{
			return new ArgumentNullException();
		}

		// Token: 0x0600009F RID: 159 RVA: 0x0000C384 File Offset: 0x0000A584
		static ArgumentException smethod_4()
		{
			return new ArgumentException();
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_5(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x0000C3EE File Offset: 0x0000A5EE
		static void smethod_6(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Array.Copy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x0000C3FB File Offset: 0x0000A5FB
		static Encoding smethod_7()
		{
			return Encoding.ASCII;
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_8(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x0000C40B File Offset: 0x0000A60B
		static int smethod_9(IPEndPoint ipendPoint_0)
		{
			return ipendPoint_0.Port;
		}

		// Token: 0x060000A5 RID: 165 RVA: 0x0000C413 File Offset: 0x0000A613
		static IPAddress smethod_10(IPEndPoint ipendPoint_0)
		{
			return ipendPoint_0.Address;
		}

		// Token: 0x060000A6 RID: 166 RVA: 0x0000C41B File Offset: 0x0000A61B
		static long smethod_11(IPAddress ipaddress_0)
		{
			return ipaddress_0.Address;
		}

		// Token: 0x060000A7 RID: 167 RVA: 0x0000C423 File Offset: 0x0000A623
		static int smethod_12(Socket socket_0, byte[] byte_0)
		{
			return socket_0.Send(byte_0);
		}

		// Token: 0x060000A8 RID: 168 RVA: 0x0000C42C File Offset: 0x0000A62C
		static void smethod_13(Socket socket_0)
		{
			socket_0.Close();
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x0000C434 File Offset: 0x0000A634
		static IAsyncResult smethod_14(Socket socket_0, EndPoint endPoint_0, AsyncCallback asyncCallback_0, object object_0)
		{
			return socket_0.BeginConnect(endPoint_0, asyncCallback_0, object_0);
		}

		// Token: 0x060000AA RID: 170 RVA: 0x0000C43F File Offset: 0x0000A63F
		static void smethod_15(Socket socket_0, IAsyncResult iasyncResult_0)
		{
			socket_0.EndConnect(iasyncResult_0);
		}

		// Token: 0x060000AB RID: 171 RVA: 0x0000C448 File Offset: 0x0000A648
		static IAsyncResult smethod_16(Socket socket_0, byte[] byte_0, int int_0, int int_1, SocketFlags socketFlags_0, AsyncCallback asyncCallback_0, object object_0)
		{
			return socket_0.BeginSend(byte_0, int_0, int_1, socketFlags_0, asyncCallback_0, object_0);
		}

		// Token: 0x060000AC RID: 172 RVA: 0x0000C459 File Offset: 0x0000A659
		static int smethod_17(Socket socket_0, IAsyncResult iasyncResult_0)
		{
			return socket_0.EndSend(iasyncResult_0);
		}

		// Token: 0x060000AD RID: 173 RVA: 0x0000C39D File Offset: 0x0000A59D
		static SocketException smethod_18()
		{
			return new SocketException();
		}

		// Token: 0x060000AE RID: 174 RVA: 0x0000C462 File Offset: 0x0000A662
		static IAsyncResult smethod_19(Socket socket_0, byte[] byte_0, int int_0, int int_1, SocketFlags socketFlags_0, AsyncCallback asyncCallback_0, object object_0)
		{
			return socket_0.BeginReceive(byte_0, int_0, int_1, socketFlags_0, asyncCallback_0, object_0);
		}

		// Token: 0x060000AF RID: 175 RVA: 0x0000C473 File Offset: 0x0000A673
		static int smethod_20(Socket socket_0, IAsyncResult iasyncResult_0)
		{
			return socket_0.EndReceive(iasyncResult_0);
		}
	}
}
