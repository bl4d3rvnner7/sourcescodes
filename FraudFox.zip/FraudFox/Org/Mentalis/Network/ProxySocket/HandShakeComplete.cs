﻿using System;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x0200000F RID: 15
	// (Invoke) Token: 0x060000DC RID: 220
	internal delegate void HandShakeComplete(Exception error);
}
