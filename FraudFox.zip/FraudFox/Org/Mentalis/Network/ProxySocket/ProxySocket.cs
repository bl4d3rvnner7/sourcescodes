﻿using System;
using System.Net;
using System.Net.Sockets;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x0200000C RID: 12
	public class ProxySocket : Socket
	{
		// Token: 0x06000066 RID: 102 RVA: 0x0000C1F1 File Offset: 0x0000A3F1
		public ProxySocket(AddressFamily addressFamily, SocketType socketType, ProtocolType protocolType)
			: this(addressFamily, socketType, protocolType, "")
		{
		}

		// Token: 0x06000067 RID: 103 RVA: 0x0000C201 File Offset: 0x0000A401
		public ProxySocket(AddressFamily addressFamily, SocketType socketType, ProtocolType protocolType, string proxyUsername)
			: this(addressFamily, socketType, protocolType, proxyUsername, "")
		{
		}

		// Token: 0x06000068 RID: 104 RVA: 0x0000C213 File Offset: 0x0000A413
		public ProxySocket(AddressFamily addressFamily, SocketType socketType, ProtocolType protocolType, string proxyUsername, string proxyPassword)
			: base(addressFamily, socketType, protocolType)
		{
			this.ProxyUser = proxyUsername;
			this.ProxyPass = proxyPassword;
			this.ToThrow = ProxySocket.smethod_0();
		}

		// Token: 0x06000069 RID: 105 RVA: 0x00021DD4 File Offset: 0x0001FFD4
		public new void Connect(EndPoint remoteEP)
		{
			if (remoteEP == null)
			{
				throw ProxySocket.smethod_1(<Module>.smethod_25<string>(4166937213U));
			}
			if (ProxySocket.smethod_2(this) == ProtocolType.Tcp)
			{
				if (this.ProxyType != ProxyTypes.None && this.ProxyEndPoint != null)
				{
					ProxySocket.smethod_3(this, this.ProxyEndPoint);
					if (this.ProxyType != ProxyTypes.Socks4)
					{
						if (this.ProxyType == ProxyTypes.Socks5)
						{
							new Socks5Handler(this, this.ProxyUser, this.ProxyPass).Negotiate((IPEndPoint)remoteEP);
						}
						return;
					}
					new Socks4Handler(this, this.ProxyUser).Negotiate((IPEndPoint)remoteEP);
					return;
				}
			}
			ProxySocket.smethod_3(this, remoteEP);
		}

		// Token: 0x0600006A RID: 106 RVA: 0x00021E6C File Offset: 0x0002006C
		public new void Connect(string host, int port)
		{
			if (host == null)
			{
				throw ProxySocket.smethod_1(<Module>.smethod_27<string>(907837358U));
			}
			if (port <= 0 || port > 65535)
			{
				throw ProxySocket.smethod_4(<Module>.smethod_26<string>(1721045395U));
			}
			if (ProxySocket.smethod_2(this) != ProtocolType.Tcp || this.ProxyType == ProxyTypes.None || this.ProxyEndPoint == null)
			{
				ProxySocket.smethod_3(this, ProxySocket.smethod_7(ProxySocket.smethod_6(ProxySocket.smethod_5(host))[0], port));
				return;
			}
			ProxySocket.smethod_3(this, this.ProxyEndPoint);
			if (this.ProxyType == ProxyTypes.Socks4)
			{
				new Socks4Handler(this, this.ProxyUser).Negotiate(host, port);
				return;
			}
			if (this.ProxyType == ProxyTypes.Socks5)
			{
				new Socks5Handler(this, this.ProxyUser, this.ProxyPass).Negotiate(host, port);
			}
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00021F2C File Offset: 0x0002012C
		public new IAsyncResult BeginConnect(EndPoint remoteEP, AsyncCallback callback, object state)
		{
			if (remoteEP == null || callback == null)
			{
				throw ProxySocket.smethod_8();
			}
			if (ProxySocket.smethod_2(this) != ProtocolType.Tcp || this.ProxyType == ProxyTypes.None || this.ProxyEndPoint == null)
			{
				return ProxySocket.smethod_9(this, remoteEP, callback, state);
			}
			this.CallBack = callback;
			if (this.ProxyType == ProxyTypes.Socks4)
			{
				this.AsyncResult = new Socks4Handler(this, this.ProxyUser).BeginNegotiate((IPEndPoint)remoteEP, new HandShakeComplete(this.OnHandShakeComplete), this.ProxyEndPoint);
				return this.AsyncResult;
			}
			if (this.ProxyType == ProxyTypes.Socks5)
			{
				this.AsyncResult = new Socks5Handler(this, this.ProxyUser, this.ProxyPass).BeginNegotiate((IPEndPoint)remoteEP, new HandShakeComplete(this.OnHandShakeComplete), this.ProxyEndPoint);
				return this.AsyncResult;
			}
			return null;
		}

		// Token: 0x0600006C RID: 108 RVA: 0x00022004 File Offset: 0x00020204
		public new IAsyncResult BeginConnect(string host, int port, AsyncCallback callback, object state)
		{
			if (host == null || callback == null)
			{
				throw ProxySocket.smethod_8();
			}
			if (port > 0 && port <= 65535)
			{
				this.CallBack = callback;
				if (ProxySocket.smethod_2(this) == ProtocolType.Tcp)
				{
					if (this.ProxyType != ProxyTypes.None && this.ProxyEndPoint != null)
					{
						if (this.ProxyType == ProxyTypes.Socks4)
						{
							this.AsyncResult = new Socks4Handler(this, this.ProxyUser).BeginNegotiate(host, port, new HandShakeComplete(this.OnHandShakeComplete), this.ProxyEndPoint);
							return this.AsyncResult;
						}
						if (this.ProxyType == ProxyTypes.Socks5)
						{
							this.AsyncResult = new Socks5Handler(this, this.ProxyUser, this.ProxyPass).BeginNegotiate(host, port, new HandShakeComplete(this.OnHandShakeComplete), this.ProxyEndPoint);
							return this.AsyncResult;
						}
						return null;
					}
				}
				this.RemotePort = port;
				this.AsyncResult = this.BeginDns(host, new HandShakeComplete(this.OnHandShakeComplete));
				return this.AsyncResult;
			}
			throw ProxySocket.smethod_10();
		}

		// Token: 0x0600006D RID: 109 RVA: 0x0000C239 File Offset: 0x0000A439
		public new void EndConnect(IAsyncResult asyncResult)
		{
			if (asyncResult == null)
			{
				throw ProxySocket.smethod_8();
			}
			if (!ProxySocket.smethod_11(asyncResult))
			{
				throw ProxySocket.smethod_10();
			}
			if (this.ToThrow != null)
			{
				throw this.ToThrow;
			}
		}

		// Token: 0x0600006E RID: 110 RVA: 0x0002210C File Offset: 0x0002030C
		internal IAsyncProxyResult BeginDns(string host, HandShakeComplete callback)
		{
			IAsyncProxyResult asyncProxyResult;
			try
			{
				ProxySocket.smethod_12(host, new AsyncCallback(this.OnResolved), this);
				asyncProxyResult = new IAsyncProxyResult();
			}
			catch
			{
				throw ProxySocket.smethod_13();
			}
			return asyncProxyResult;
		}

		// Token: 0x0600006F RID: 111 RVA: 0x00022150 File Offset: 0x00020350
		private void OnResolved(IAsyncResult asyncResult)
		{
			try
			{
				IPHostEntry iphostEntry = ProxySocket.smethod_14(asyncResult);
				ProxySocket.smethod_9(this, ProxySocket.smethod_7(ProxySocket.smethod_6(iphostEntry)[0], this.RemotePort), new AsyncCallback(this.OnConnect), this.State);
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_0063:
					int num = 808064030;
					for (;;)
					{
						switch (num ^ 808064028)
						{
						case 0:
							goto IL_0063;
						case 2:
							this.OnHandShakeComplete(ex);
							num = 808064029;
							continue;
						}
						goto Block_3;
					}
				}
				Block_3:;
			}
		}

		// Token: 0x06000070 RID: 112 RVA: 0x000221DC File Offset: 0x000203DC
		private void OnConnect(IAsyncResult asyncResult)
		{
			try
			{
				ProxySocket.smethod_15(this, asyncResult);
				this.OnHandShakeComplete(null);
			}
			catch (Exception ex)
			{
				this.OnHandShakeComplete(ex);
			}
		}

		// Token: 0x06000071 RID: 113 RVA: 0x0000C261 File Offset: 0x0000A461
		private void OnHandShakeComplete(Exception error)
		{
			if (error != null)
			{
				ProxySocket.smethod_16(this);
			}
			this.ToThrow = error;
			this.AsyncResult.Reset();
			if (this.CallBack != null)
			{
				this.CallBack(this.AsyncResult);
			}
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x06000072 RID: 114 RVA: 0x0000C297 File Offset: 0x0000A497
		// (set) Token: 0x06000073 RID: 115 RVA: 0x0000C29F File Offset: 0x0000A49F
		public IPEndPoint ProxyEndPoint
		{
			get
			{
				return this.m_ProxyEndPoint;
			}
			set
			{
				this.m_ProxyEndPoint = value;
			}
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x06000074 RID: 116 RVA: 0x0000C2A8 File Offset: 0x0000A4A8
		// (set) Token: 0x06000075 RID: 117 RVA: 0x0000C2B0 File Offset: 0x0000A4B0
		public ProxyTypes ProxyType
		{
			get
			{
				return this.m_ProxyType;
			}
			set
			{
				this.m_ProxyType = value;
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x06000076 RID: 118 RVA: 0x0000C2B9 File Offset: 0x0000A4B9
		// (set) Token: 0x06000077 RID: 119 RVA: 0x0000C2C1 File Offset: 0x0000A4C1
		private object State
		{
			get
			{
				return this.m_State;
			}
			set
			{
				this.m_State = value;
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x06000078 RID: 120 RVA: 0x0000C2CA File Offset: 0x0000A4CA
		// (set) Token: 0x06000079 RID: 121 RVA: 0x0000C2D2 File Offset: 0x0000A4D2
		public string ProxyUser
		{
			get
			{
				return this.m_ProxyUser;
			}
			set
			{
				if (value == null)
				{
					throw ProxySocket.smethod_8();
				}
				this.m_ProxyUser = value;
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x0600007A RID: 122 RVA: 0x0000C2E4 File Offset: 0x0000A4E4
		// (set) Token: 0x0600007B RID: 123 RVA: 0x0000C2EC File Offset: 0x0000A4EC
		public string ProxyPass
		{
			get
			{
				return this.m_ProxyPass;
			}
			set
			{
				if (value == null)
				{
					throw ProxySocket.smethod_8();
				}
				this.m_ProxyPass = value;
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x0600007C RID: 124 RVA: 0x0000C2FE File Offset: 0x0000A4FE
		// (set) Token: 0x0600007D RID: 125 RVA: 0x0000C306 File Offset: 0x0000A506
		private IAsyncProxyResult AsyncResult
		{
			get
			{
				return this.m_AsyncResult;
			}
			set
			{
				this.m_AsyncResult = value;
			}
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x0600007E RID: 126 RVA: 0x0000C30F File Offset: 0x0000A50F
		// (set) Token: 0x0600007F RID: 127 RVA: 0x0000C317 File Offset: 0x0000A517
		private Exception ToThrow
		{
			get
			{
				return this.m_ToThrow;
			}
			set
			{
				this.m_ToThrow = value;
			}
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x06000080 RID: 128 RVA: 0x0000C320 File Offset: 0x0000A520
		// (set) Token: 0x06000081 RID: 129 RVA: 0x0000C328 File Offset: 0x0000A528
		private int RemotePort
		{
			get
			{
				return this.m_RemotePort;
			}
			set
			{
				this.m_RemotePort = value;
			}
		}

		// Token: 0x06000082 RID: 130 RVA: 0x0000C331 File Offset: 0x0000A531
		static InvalidOperationException smethod_0()
		{
			return new InvalidOperationException();
		}

		// Token: 0x06000083 RID: 131 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_1(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x06000084 RID: 132 RVA: 0x0000C340 File Offset: 0x0000A540
		static ProtocolType smethod_2(Socket socket_0)
		{
			return socket_0.ProtocolType;
		}

		// Token: 0x06000085 RID: 133 RVA: 0x0000C348 File Offset: 0x0000A548
		static void smethod_3(Socket socket_0, EndPoint endPoint_0)
		{
			socket_0.Connect(endPoint_0);
		}

		// Token: 0x06000086 RID: 134 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_4(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x06000087 RID: 135 RVA: 0x0000C359 File Offset: 0x0000A559
		static IPHostEntry smethod_5(string string_0)
		{
			return Dns.Resolve(string_0);
		}

		// Token: 0x06000088 RID: 136 RVA: 0x0000C361 File Offset: 0x0000A561
		static IPAddress[] smethod_6(IPHostEntry iphostEntry_0)
		{
			return iphostEntry_0.AddressList;
		}

		// Token: 0x06000089 RID: 137 RVA: 0x0000C369 File Offset: 0x0000A569
		static IPEndPoint smethod_7(IPAddress ipaddress_0, int int_0)
		{
			return new IPEndPoint(ipaddress_0, int_0);
		}

		// Token: 0x0600008A RID: 138 RVA: 0x0000C372 File Offset: 0x0000A572
		static ArgumentNullException smethod_8()
		{
			return new ArgumentNullException();
		}

		// Token: 0x0600008B RID: 139 RVA: 0x0000C379 File Offset: 0x0000A579
		static IAsyncResult smethod_9(Socket socket_0, EndPoint endPoint_0, AsyncCallback asyncCallback_0, object object_0)
		{
			return socket_0.BeginConnect(endPoint_0, asyncCallback_0, object_0);
		}

		// Token: 0x0600008C RID: 140 RVA: 0x0000C384 File Offset: 0x0000A584
		static ArgumentException smethod_10()
		{
			return new ArgumentException();
		}

		// Token: 0x0600008D RID: 141 RVA: 0x0000C38B File Offset: 0x0000A58B
		static bool smethod_11(IAsyncResult iasyncResult_0)
		{
			return iasyncResult_0.IsCompleted;
		}

		// Token: 0x0600008E RID: 142 RVA: 0x0000C393 File Offset: 0x0000A593
		static IAsyncResult smethod_12(string string_0, AsyncCallback asyncCallback_0, object object_0)
		{
			return Dns.BeginResolve(string_0, asyncCallback_0, object_0);
		}

		// Token: 0x0600008F RID: 143 RVA: 0x0000C39D File Offset: 0x0000A59D
		static SocketException smethod_13()
		{
			return new SocketException();
		}

		// Token: 0x06000090 RID: 144 RVA: 0x0000C3A4 File Offset: 0x0000A5A4
		static IPHostEntry smethod_14(IAsyncResult iasyncResult_0)
		{
			return Dns.EndResolve(iasyncResult_0);
		}

		// Token: 0x06000091 RID: 145 RVA: 0x0000C3AC File Offset: 0x0000A5AC
		static void smethod_15(Socket socket_0, IAsyncResult iasyncResult_0)
		{
			socket_0.EndConnect(iasyncResult_0);
		}

		// Token: 0x06000092 RID: 146 RVA: 0x0000C3B5 File Offset: 0x0000A5B5
		static void smethod_16(Socket socket_0)
		{
			socket_0.Close();
		}

		// Token: 0x0400002D RID: 45
		private object m_State;

		// Token: 0x0400002E RID: 46
		private IPEndPoint m_ProxyEndPoint;

		// Token: 0x0400002F RID: 47
		private ProxyTypes m_ProxyType;

		// Token: 0x04000030 RID: 48
		private string m_ProxyUser;

		// Token: 0x04000031 RID: 49
		private string m_ProxyPass;

		// Token: 0x04000032 RID: 50
		private AsyncCallback CallBack;

		// Token: 0x04000033 RID: 51
		private IAsyncProxyResult m_AsyncResult;

		// Token: 0x04000034 RID: 52
		private Exception m_ToThrow;

		// Token: 0x04000035 RID: 53
		private int m_RemotePort;
	}
}
