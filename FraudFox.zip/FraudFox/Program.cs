﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace FraudFox
{
	// Token: 0x0200003E RID: 62
	internal static class Program
	{
		// Token: 0x06000483 RID: 1155
		[DllImport("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool SetForegroundWindow(IntPtr hWnd);

		// Token: 0x06000484 RID: 1156 RVA: 0x00032D40 File Offset: 0x00030F40
		[STAThread]
		private static void Main()
		{
			bool flag = true;
			using (new Mutex(true, <Module>.smethod_24<string>(2364131386U), out flag))
			{
				if (flag)
				{
					Application.EnableVisualStyles();
					Application.SetCompatibleTextRenderingDefault(false);
					Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) == <Module>.smethod_24<string>(906898165U);
					Application.Run(new Login());
				}
				else
				{
					Process currentProcess = Process.GetCurrentProcess();
					foreach (Process process in Process.GetProcessesByName(currentProcess.ProcessName))
					{
						if (process.Id != currentProcess.Id)
						{
							Program.SetForegroundWindow(process.MainWindowHandle);
							break;
						}
					}
				}
			}
		}
	}
}
