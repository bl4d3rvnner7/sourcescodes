﻿namespace FraudFox
{
	// Token: 0x02000033 RID: 51
	public partial class Main : global::System.Windows.Forms.Form
	{
		// Token: 0x0600034B RID: 843 RVA: 0x0000D696 File Offset: 0x0000B896
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				global::FraudFox.Main.smethod_82(this.components);
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600034C RID: 844 RVA: 0x0002B300 File Offset: 0x00029500
		private void InitializeComponent()
		{
			this.components = global::FraudFox.Main.smethod_112();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = global::FraudFox.Main.smethod_113(global::FraudFox.Main.smethod_85(typeof(global::FraudFox.Main).TypeHandle));
			this.btnStart = global::FraudFox.Main.smethod_114();
			this.groupBox1 = global::FraudFox.Main.smethod_115();
			this.OSTimezone = global::FraudFox.Main.smethod_116();
			this.label14 = global::FraudFox.Main.smethod_117();
			this.OSRandomize = global::FraudFox.Main.smethod_114();
			this.OSResolution = global::FraudFox.Main.smethod_116();
			this.label4 = global::FraudFox.Main.smethod_117();
			this.OSLanguage = global::FraudFox.Main.smethod_116();
			this.label3 = global::FraudFox.Main.smethod_117();
			this.OSPlatform = global::FraudFox.Main.smethod_116();
			this.label2 = global::FraudFox.Main.smethod_117();
			this.OSVersion = global::FraudFox.Main.smethod_116();
			this.label1 = global::FraudFox.Main.smethod_117();
			this.groupBox2 = global::FraudFox.Main.smethod_115();
			this.fillDemo = global::FraudFox.Main.smethod_118();
			this.strokeDemo = global::FraudFox.Main.smethod_118();
			this.BrowserCanvasFill = global::FraudFox.Main.smethod_119();
			this.BrowserCanvasStroke = global::FraudFox.Main.smethod_119();
			this.BrowserCanvasFontSize = global::FraudFox.Main.smethod_120();
			this.BrowserCanvasFont = global::FraudFox.Main.smethod_116();
			this.label16 = global::FraudFox.Main.smethod_117();
			this.label11 = global::FraudFox.Main.smethod_117();
			this.label10 = global::FraudFox.Main.smethod_117();
			this.BrowserFlash = global::FraudFox.Main.smethod_116();
			this.label15 = global::FraudFox.Main.smethod_117();
			this.BrowserRandomize = global::FraudFox.Main.smethod_114();
			this.BrowserVersion = global::FraudFox.Main.smethod_116();
			this.label7 = global::FraudFox.Main.smethod_117();
			this.BrowserProduct = global::FraudFox.Main.smethod_116();
			this.label8 = global::FraudFox.Main.smethod_117();
			this.groupBox3 = global::FraudFox.Main.smethod_115();
			this.AdvancedStartpage = global::FraudFox.Main.smethod_116();
			this.AdvancedUseragent = global::FraudFox.Main.smethod_116();
			this.label5 = global::FraudFox.Main.smethod_117();
			this.label6 = global::FraudFox.Main.smethod_117();
			this.groupBox4 = global::FraudFox.Main.smethod_115();
			this.cbEnableFont = global::FraudFox.Main.smethod_121();
			this.btnFontAll = global::FraudFox.Main.smethod_114();
			this.btnFontDelete = global::FraudFox.Main.smethod_114();
			this.btnFontAdd = global::FraudFox.Main.smethod_114();
			this.FontRandomize = global::FraudFox.Main.smethod_114();
			this.FontList = global::FraudFox.Main.smethod_122();
			this.groupBox6 = global::FraudFox.Main.smethod_115();
			this.btnPluginAll = global::FraudFox.Main.smethod_114();
			this.btnPluginDelete = global::FraudFox.Main.smethod_114();
			this.btnPluginAdd = global::FraudFox.Main.smethod_114();
			this.PluginRandomize = global::FraudFox.Main.smethod_114();
			this.PluginList = global::FraudFox.Main.smethod_122();
			this.grpHelp = global::FraudFox.Main.smethod_115();
			this.lblHelp = global::FraudFox.Main.smethod_117();
			this.label12 = global::FraudFox.Main.smethod_117();
			this.lblStatus = global::FraudFox.Main.smethod_117();
			this.lblStatusStatic = global::FraudFox.Main.smethod_117();
			this.ofd = global::FraudFox.Main.smethod_123();
			this.sfd = global::FraudFox.Main.smethod_124();
			this.bgwBrowser = global::FraudFox.Main.smethod_125();
			this.toolTip = global::FraudFox.Main.smethod_126(this.components);
			this.btnNotes = global::FraudFox.Main.smethod_114();
			this.btnClean = global::FraudFox.Main.smethod_114();
			this.label9 = global::FraudFox.Main.smethod_117();
			this.AdvancedDisableDeviceFontEnumeration = global::FraudFox.Main.smethod_121();
			this.AdvancedAVHardwareDisable = global::FraudFox.Main.smethod_121();
			global::FraudFox.Main.smethod_127(this.groupBox1);
			global::FraudFox.Main.smethod_127(this.groupBox2);
			global::FraudFox.Main.smethod_128(this.fillDemo);
			global::FraudFox.Main.smethod_128(this.strokeDemo);
			global::FraudFox.Main.smethod_128(this.BrowserCanvasFontSize);
			global::FraudFox.Main.smethod_127(this.groupBox3);
			global::FraudFox.Main.smethod_127(this.groupBox4);
			global::FraudFox.Main.smethod_127(this.groupBox6);
			global::FraudFox.Main.smethod_127(this.grpHelp);
			global::FraudFox.Main.smethod_129(this);
			this.btnStart.Location = new global::System.Drawing.Point(538, 491);
			this.btnStart.Name = global::<Module>.smethod_25<string>(3901979071U);
			this.btnStart.Size = new global::System.Drawing.Size(125, 23);
			this.btnStart.TabIndex = 2;
			this.btnStart.Text = global::<Module>.smethod_24<string>(1518146710U);
			this.btnStart.UseVisualStyleBackColor = true;
			this.btnStart.Click += new global::System.EventHandler(this.btnStart_Click);
			this.groupBox1.Controls.Add(this.OSTimezone);
			this.groupBox1.Controls.Add(this.label14);
			this.groupBox1.Controls.Add(this.OSRandomize);
			this.groupBox1.Controls.Add(this.OSResolution);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.OSLanguage);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.OSPlatform);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.OSVersion);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Location = new global::System.Drawing.Point(13, 13);
			this.groupBox1.Name = global::<Module>.smethod_24<string>(650311169U);
			this.groupBox1.Size = new global::System.Drawing.Size(212, 233);
			this.groupBox1.TabIndex = 3;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = global::<Module>.smethod_27<string>(1981484416U);
			this.OSTimezone.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.OSTimezone.DropDownWidth = 290;
			this.OSTimezone.FormattingEnabled = true;
			this.OSTimezone.Location = new global::System.Drawing.Point(75, 101);
			this.OSTimezone.Name = global::<Module>.smethod_26<string>(1940466580U);
			this.OSTimezone.Size = new global::System.Drawing.Size(121, 21);
			this.OSTimezone.TabIndex = 11;
			this.OSTimezone.Tag = global::<Module>.smethod_26<string>(3378506608U);
			this.OSTimezone.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.OSTimezone.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.label14.AutoSize = true;
			this.label14.Location = new global::System.Drawing.Point(6, 104);
			this.label14.Name = global::<Module>.smethod_24<string>(4187194762U);
			this.label14.Size = new global::System.Drawing.Size(56, 13);
			this.label14.TabIndex = 10;
			this.label14.Text = global::<Module>.smethod_23<string>(4030992798U);
			this.OSRandomize.Location = new global::System.Drawing.Point(100, 204);
			this.OSRandomize.Name = global::<Module>.smethod_27<string>(209860082U);
			this.OSRandomize.Size = new global::System.Drawing.Size(96, 23);
			this.OSRandomize.TabIndex = 8;
			this.OSRandomize.Text = global::<Module>.smethod_24<string>(2615134079U);
			this.OSRandomize.UseVisualStyleBackColor = true;
			this.OSRandomize.Click += new global::System.EventHandler(this.OSRandomize_Click);
			this.OSResolution.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.OSResolution.FormattingEnabled = true;
			this.OSResolution.Location = new global::System.Drawing.Point(75, 129);
			this.OSResolution.Name = global::<Module>.smethod_23<string>(820459514U);
			this.OSResolution.Size = new global::System.Drawing.Size(121, 21);
			this.OSResolution.TabIndex = 7;
			this.OSResolution.Tag = global::<Module>.smethod_24<string>(1572005271U);
			this.OSResolution.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.OSResolution.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.label4.AutoSize = true;
			this.label4.Location = new global::System.Drawing.Point(6, 132);
			this.label4.Name = global::<Module>.smethod_27<string>(3163891988U);
			this.label4.Size = new global::System.Drawing.Size(61, 13);
			this.label4.TabIndex = 6;
			this.label4.Text = global::<Module>.smethod_26<string>(3455117760U);
			this.OSLanguage.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.OSLanguage.FormattingEnabled = true;
			this.OSLanguage.Location = new global::System.Drawing.Point(75, 74);
			this.OSLanguage.Name = global::<Module>.smethod_24<string>(1679722393U);
			this.OSLanguage.Size = new global::System.Drawing.Size(121, 21);
			this.OSLanguage.TabIndex = 5;
			this.OSLanguage.Tag = global::<Module>.smethod_25<string>(3980949607U);
			this.OSLanguage.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.OSLanguage.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.label3.AutoSize = true;
			this.label3.Location = new global::System.Drawing.Point(6, 77);
			this.label3.Name = global::<Module>.smethod_25<string>(3453545141U);
			this.label3.Size = new global::System.Drawing.Size(58, 13);
			this.label3.TabIndex = 4;
			this.label3.Text = global::<Module>.smethod_23<string>(3620474667U);
			this.OSPlatform.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.OSPlatform.FormattingEnabled = true;
			this.OSPlatform.Location = new global::System.Drawing.Point(75, 47);
			this.OSPlatform.Name = global::<Module>.smethod_26<string>(123368525U);
			this.OSPlatform.Size = new global::System.Drawing.Size(121, 21);
			this.OSPlatform.TabIndex = 3;
			this.OSPlatform.Tag = global::<Module>.smethod_23<string>(3813756419U);
			this.OSPlatform.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.OSPlatform.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.label2.AutoSize = true;
			this.label2.Location = new global::System.Drawing.Point(6, 50);
			this.label2.Name = global::<Module>.smethod_24<string>(3759372765U);
			this.label2.Size = new global::System.Drawing.Size(51, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = global::<Module>.smethod_27<string>(3426756899U);
			this.OSVersion.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.OSVersion.DropDownWidth = 140;
			this.OSVersion.FormattingEnabled = true;
			this.OSVersion.Location = new global::System.Drawing.Point(75, 20);
			this.OSVersion.Name = global::<Module>.smethod_26<string>(1580561341U);
			this.OSVersion.Size = new global::System.Drawing.Size(121, 21);
			this.OSVersion.TabIndex = 1;
			this.OSVersion.Tag = global::<Module>.smethod_26<string>(3018601369U);
			this.OSVersion.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.OSVersion.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(6, 23);
			this.label1.Name = global::<Module>.smethod_27<string>(1351417501U);
			this.label1.Size = new global::System.Drawing.Size(46, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = global::<Module>.smethod_23<string>(2286316528U);
			this.groupBox2.Controls.Add(this.fillDemo);
			this.groupBox2.Controls.Add(this.strokeDemo);
			this.groupBox2.Controls.Add(this.BrowserCanvasFill);
			this.groupBox2.Controls.Add(this.BrowserCanvasStroke);
			this.groupBox2.Controls.Add(this.BrowserCanvasFontSize);
			this.groupBox2.Controls.Add(this.BrowserCanvasFont);
			this.groupBox2.Controls.Add(this.label16);
			this.groupBox2.Controls.Add(this.label11);
			this.groupBox2.Controls.Add(this.label10);
			this.groupBox2.Controls.Add(this.BrowserFlash);
			this.groupBox2.Controls.Add(this.label15);
			this.groupBox2.Controls.Add(this.BrowserRandomize);
			this.groupBox2.Controls.Add(this.BrowserVersion);
			this.groupBox2.Controls.Add(this.label7);
			this.groupBox2.Controls.Add(this.BrowserProduct);
			this.groupBox2.Controls.Add(this.label8);
			this.groupBox2.Location = new global::System.Drawing.Point(231, 13);
			this.groupBox2.Name = global::<Module>.smethod_24<string>(2736568785U);
			this.groupBox2.Size = new global::System.Drawing.Size(212, 233);
			this.groupBox2.TabIndex = 9;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = global::<Module>.smethod_24<string>(2193919326U);
			this.fillDemo.Location = new global::System.Drawing.Point(170, 131);
			this.fillDemo.Name = global::<Module>.smethod_27<string>(2354457960U);
			this.fillDemo.Size = new global::System.Drawing.Size(28, 21);
			this.fillDemo.TabIndex = 21;
			this.fillDemo.TabStop = false;
			this.strokeDemo.Location = new global::System.Drawing.Point(170, 104);
			this.strokeDemo.Name = global::<Module>.smethod_23<string>(3931781671U);
			this.strokeDemo.Size = new global::System.Drawing.Size(28, 21);
			this.strokeDemo.TabIndex = 20;
			this.strokeDemo.TabStop = false;
			this.BrowserCanvasFill.Location = new global::System.Drawing.Point(82, 131);
			this.BrowserCanvasFill.Mask = global::<Module>.smethod_27<string>(3607472131U);
			this.BrowserCanvasFill.Name = global::<Module>.smethod_23<string>(3771090814U);
			this.BrowserCanvasFill.Size = new global::System.Drawing.Size(82, 21);
			this.BrowserCanvasFill.TabIndex = 19;
			this.BrowserCanvasFill.TextChanged += new global::System.EventHandler(this.BrowserCanvasFill_TextChanged);
			this.BrowserCanvasStroke.Location = new global::System.Drawing.Point(82, 104);
			this.BrowserCanvasStroke.Mask = global::<Module>.smethod_25<string>(3891277364U);
			this.BrowserCanvasStroke.Name = global::<Module>.smethod_27<string>(4025269876U);
			this.BrowserCanvasStroke.Size = new global::System.Drawing.Size(82, 21);
			this.BrowserCanvasStroke.TabIndex = 18;
			this.BrowserCanvasStroke.TextChanged += new global::System.EventHandler(this.BrowserCanvasStroke_TextChanged);
			this.BrowserCanvasFontSize.Location = new global::System.Drawing.Point(162, 159);
			this.BrowserCanvasFontSize.Name = global::<Module>.smethod_26<string>(909468710U);
			this.BrowserCanvasFontSize.Size = new global::System.Drawing.Size(36, 21);
			this.BrowserCanvasFontSize.TabIndex = 17;
			global::System.Windows.Forms.NumericUpDown browserCanvasFontSize = this.BrowserCanvasFontSize;
			int[] array = new int[4];
			array[0] = 14;
			browserCanvasFontSize.Value = new decimal(array);
			this.BrowserCanvasFont.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.BrowserCanvasFont.DropDownWidth = 200;
			this.BrowserCanvasFont.FormattingEnabled = true;
			this.BrowserCanvasFont.Location = new global::System.Drawing.Point(82, 159);
			this.BrowserCanvasFont.Name = global::<Module>.smethod_24<string>(498389221U);
			this.BrowserCanvasFont.Size = new global::System.Drawing.Size(75, 21);
			this.BrowserCanvasFont.TabIndex = 16;
			this.BrowserCanvasFont.Tag = global::<Module>.smethod_27<string>(3560850438U);
			this.label16.AutoSize = true;
			this.label16.Location = new global::System.Drawing.Point(4, 162);
			this.label16.Name = global::<Module>.smethod_25<string>(1336246393U);
			this.label16.Size = new global::System.Drawing.Size(70, 13);
			this.label16.TabIndex = 15;
			this.label16.Text = global::<Module>.smethod_25<string>(1127454034U);
			this.label11.AutoSize = true;
			this.label11.Location = new global::System.Drawing.Point(4, 135);
			this.label11.Name = global::<Module>.smethod_24<string>(92926768U);
			this.label11.Size = new global::System.Drawing.Size(60, 13);
			this.label11.TabIndex = 13;
			this.label11.Text = global::<Module>.smethod_25<string>(1753831111U);
			this.label10.AutoSize = true;
			this.label10.Location = new global::System.Drawing.Point(4, 107);
			this.label10.Name = global::<Module>.smethod_23<string>(2790905284U);
			this.label10.Size = new global::System.Drawing.Size(80, 13);
			this.label10.TabIndex = 11;
			this.label10.Text = global::<Module>.smethod_23<string>(1107811891U);
			this.BrowserFlash.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.BrowserFlash.FormattingEnabled = true;
			this.BrowserFlash.Location = new global::System.Drawing.Point(82, 75);
			this.BrowserFlash.Name = global::<Module>.smethod_26<string>(3948347464U);
			this.BrowserFlash.Size = new global::System.Drawing.Size(116, 21);
			this.BrowserFlash.TabIndex = 10;
			this.BrowserFlash.Tag = global::<Module>.smethod_26<string>(703530826U);
			this.BrowserFlash.SelectedIndexChanged += new global::System.EventHandler(this.BrowserFlash_SelectedIndexChanged);
			this.BrowserFlash.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.BrowserFlash.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.label15.AutoSize = true;
			this.label15.Location = new global::System.Drawing.Point(4, 78);
			this.label15.Name = global::<Module>.smethod_26<string>(2208605612U);
			this.label15.Size = new global::System.Drawing.Size(67, 13);
			this.label15.TabIndex = 9;
			this.label15.Text = global::<Module>.smethod_27<string>(1369630867U);
			this.BrowserRandomize.Location = new global::System.Drawing.Point(102, 204);
			this.BrowserRandomize.Name = global::<Module>.smethod_26<string>(789718372U);
			this.BrowserRandomize.Size = new global::System.Drawing.Size(96, 23);
			this.BrowserRandomize.TabIndex = 8;
			this.BrowserRandomize.Text = global::<Module>.smethod_26<string>(550308522U);
			this.BrowserRandomize.UseVisualStyleBackColor = true;
			this.BrowserRandomize.Click += new global::System.EventHandler(this.BrowserRandomize_Click);
			this.BrowserVersion.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.BrowserVersion.FormattingEnabled = true;
			this.BrowserVersion.Location = new global::System.Drawing.Point(82, 47);
			this.BrowserVersion.Name = global::<Module>.smethod_26<string>(3224539253U);
			this.BrowserVersion.Size = new global::System.Drawing.Size(116, 21);
			this.BrowserVersion.TabIndex = 3;
			this.BrowserVersion.Tag = global::<Module>.smethod_23<string>(2616437657U);
			this.BrowserVersion.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.BrowserVersion.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.label7.AutoSize = true;
			this.label7.Location = new global::System.Drawing.Point(4, 50);
			this.label7.Name = global::<Module>.smethod_24<string>(3555626972U);
			this.label7.Size = new global::System.Drawing.Size(46, 13);
			this.label7.TabIndex = 2;
			this.label7.Text = global::<Module>.smethod_23<string>(2286316528U);
			this.BrowserProduct.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.BrowserProduct.FormattingEnabled = true;
			this.BrowserProduct.Location = new global::System.Drawing.Point(82, 20);
			this.BrowserProduct.Name = global::<Module>.smethod_23<string>(1333684538U);
			this.BrowserProduct.Size = new global::System.Drawing.Size(116, 21);
			this.BrowserProduct.TabIndex = 1;
			this.BrowserProduct.Tag = global::<Module>.smethod_26<string>(405081684U);
			this.BrowserProduct.SelectedValueChanged += new global::System.EventHandler(this.BrowserProduct_SelectedValueChanged);
			this.BrowserProduct.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.BrowserProduct.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.label8.AutoSize = true;
			this.label8.Location = new global::System.Drawing.Point(4, 23);
			this.label8.Name = global::<Module>.smethod_27<string>(914507644U);
			this.label8.Size = new global::System.Drawing.Size(48, 13);
			this.label8.TabIndex = 0;
			this.label8.Text = global::<Module>.smethod_26<string>(1138466289U);
			this.groupBox3.Controls.Add(this.AdvancedAVHardwareDisable);
			this.groupBox3.Controls.Add(this.AdvancedDisableDeviceFontEnumeration);
			this.groupBox3.Controls.Add(this.label9);
			this.groupBox3.Controls.Add(this.AdvancedStartpage);
			this.groupBox3.Controls.Add(this.AdvancedUseragent);
			this.groupBox3.Controls.Add(this.label5);
			this.groupBox3.Controls.Add(this.label6);
			this.groupBox3.Location = new global::System.Drawing.Point(449, 13);
			this.groupBox3.Name = global::<Module>.smethod_24<string>(934338916U);
			this.groupBox3.Size = new global::System.Drawing.Size(212, 233);
			this.groupBox3.TabIndex = 10;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = global::<Module>.smethod_27<string>(1007751030U);
			this.AdvancedStartpage.FormattingEnabled = true;
			this.AdvancedStartpage.Items.AddRange(new object[]
			{
				global::<Module>.smethod_23<string>(1094241415U),
				global::<Module>.smethod_25<string>(1037781791U),
				global::<Module>.smethod_23<string>(283383010U)
			});
			this.AdvancedStartpage.Location = new global::System.Drawing.Point(14, 85);
			this.AdvancedStartpage.Name = global::<Module>.smethod_23<string>(4210600927U);
			this.AdvancedStartpage.Size = new global::System.Drawing.Size(182, 21);
			this.AdvancedStartpage.TabIndex = 15;
			this.AdvancedStartpage.TextChanged += new global::System.EventHandler(this.AdvancedStartpage_TextChanged);
			this.AdvancedUseragent.FormattingEnabled = true;
			this.AdvancedUseragent.Items.AddRange(new object[]
			{
				global::<Module>.smethod_26<string>(2605235499U),
				global::<Module>.smethod_24<string>(3080553658U),
				global::<Module>.smethod_23<string>(2664346911U),
				global::<Module>.smethod_25<string>(3244825497U),
				global::<Module>.smethod_24<string>(3295987902U),
				global::<Module>.smethod_23<string>(1518330022U),
				global::<Module>.smethod_26<string>(3376925680U),
				global::<Module>.smethod_27<string>(157017476U),
				global::<Module>.smethod_24<string>(240276188U),
				global::<Module>.smethod_27<string>(3840131223U),
				global::<Module>.smethod_24<string>(347993310U),
				global::<Module>.smethod_23<string>(3598267923U),
				global::<Module>.smethod_23<string>(250895262U),
				global::<Module>.smethod_25<string>(2607746713U),
				global::<Module>.smethod_23<string>(208126510U),
				global::<Module>.smethod_23<string>(3168935667U),
				global::<Module>.smethod_25<string>(3243496873U),
				global::<Module>.smethod_27<string>(3455614599U),
				global::<Module>.smethod_25<string>(3050720717U),
				global::<Module>.smethod_27<string>(3199869347U),
				global::<Module>.smethod_25<string>(3100243380U),
				global::<Module>.smethod_23<string>(2655813790U),
				global::<Module>.smethod_26<string>(77067483U),
				global::<Module>.smethod_25<string>(455540166U),
				global::<Module>.smethod_26<string>(1792822937U),
				global::<Module>.smethod_24<string>(1644662623U),
				global::<Module>.smethod_24<string>(3784778800U),
				global::<Module>.smethod_23<string>(1241258649U),
				global::<Module>.smethod_25<string>(832975304U),
				global::<Module>.smethod_23<string>(977860899U),
				global::<Module>.smethod_26<string>(1760096022U),
				global::<Module>.smethod_25<string>(2344044480U),
				global::<Module>.smethod_26<string>(628500602U),
				global::<Module>.smethod_24<string>(890642769U),
				global::<Module>.smethod_25<string>(1697592613U),
				global::<Module>.smethod_25<string>(3675769170U),
				global::<Module>.smethod_26<string>(590195026U),
				global::<Module>.smethod_23<string>(983001401U),
				global::<Module>.smethod_25<string>(1587845580U),
				global::<Module>.smethod_25<string>(2243670530U),
				global::<Module>.smethod_23<string>(2572024169U),
				global::<Module>.smethod_24<string>(1992711345U),
				global::<Module>.smethod_23<string>(4037881183U),
				global::<Module>.smethod_24<string>(3143557275U),
				global::<Module>.smethod_24<string>(2614625400U),
				global::<Module>.smethod_27<string>(839477624U),
				global::<Module>.smethod_26<string>(3384085269U),
				global::<Module>.smethod_25<string>(3784187579U),
				global::<Module>.smethod_25<string>(463584625U),
				global::<Module>.smethod_24<string>(371873308U),
				global::<Module>.smethod_25<string>(3068138259U),
				global::<Module>.smethod_26<string>(3336203299U),
				global::<Module>.smethod_25<string>(2143296580U),
				global::<Module>.smethod_25<string>(353837592U),
				global::<Module>.smethod_24<string>(3133903540U),
				global::<Module>.smethod_23<string>(3774483433U),
				global::<Module>.smethod_26<string>(1325160559U),
				global::<Module>.smethod_25<string>(2067056007U),
				global::<Module>.smethod_26<string>(1219820225U),
				global::<Module>.smethod_25<string>(655032157U),
				global::<Module>.smethod_25<string>(2534163388U),
				global::<Module>.smethod_26<string>(3678536678U),
				global::<Module>.smethod_24<string>(520234503U),
				global::<Module>.smethod_23<string>(3080211838U),
				global::<Module>.smethod_25<string>(1102064748U),
				global::<Module>.smethod_25<string>(3259585791U),
				global::<Module>.smethod_26<string>(2360992039U),
				global::<Module>.smethod_24<string>(1284416771U),
				global::<Module>.smethod_23<string>(4231369229U),
				global::<Module>.smethod_23<string>(2336179959U),
				global::<Module>.smethod_27<string>(1942810819U),
				global::<Module>.smethod_27<string>(450916643U),
				global::<Module>.smethod_23<string>(2642346461U),
				global::<Module>.smethod_25<string>(1230557947U),
				global::<Module>.smethod_27<string>(2932960079U),
				global::<Module>.smethod_24<string>(1343356539U),
				global::<Module>.smethod_26<string>(2920420624U),
				global::<Module>.smethod_23<string>(502573566U),
				global::<Module>.smethod_25<string>(3815036791U),
				global::<Module>.smethod_27<string>(3865393939U),
				global::<Module>.smethod_25<string>(3794962001U),
				global::<Module>.smethod_27<string>(2321106530U),
				global::<Module>.smethod_25<string>(2243743245U),
				global::<Module>.smethod_26<string>(2997031776U),
				global::<Module>.smethod_24<string>(2518591146U),
				global::<Module>.smethod_27<string>(910912660U),
				global::<Module>.smethod_23<string>(1592148080U),
				global::<Module>.smethod_26<string>(1641181561U),
				global::<Module>.smethod_25<string>(3595542725U),
				global::<Module>.smethod_24<string>(1142657237U),
				global::<Module>.smethod_24<string>(2876293603U)
			});
			this.AdvancedUseragent.Location = new global::System.Drawing.Point(14, 42);
			this.AdvancedUseragent.Name = global::<Module>.smethod_27<string>(1464601436U);
			this.AdvancedUseragent.Size = new global::System.Drawing.Size(182, 21);
			this.AdvancedUseragent.TabIndex = 14;
			this.AdvancedUseragent.TextChanged += new global::System.EventHandler(this.AdvancedUseragent_TextChanged);
			this.label5.AutoSize = true;
			this.label5.Location = new global::System.Drawing.Point(11, 69);
			this.label5.Name = global::<Module>.smethod_25<string>(811644605U);
			this.label5.Size = new global::System.Drawing.Size(62, 13);
			this.label5.TabIndex = 10;
			this.label5.Text = global::<Module>.smethod_24<string>(1304232920U);
			this.label6.AutoSize = true;
			this.label6.Location = new global::System.Drawing.Point(11, 24);
			this.label6.Name = global::<Module>.smethod_25<string>(1438021682U);
			this.label6.Size = new global::System.Drawing.Size(105, 13);
			this.label6.TabIndex = 0;
			this.label6.Text = global::<Module>.smethod_25<string>(2024249179U);
			this.groupBox4.Controls.Add(this.cbEnableFont);
			this.groupBox4.Controls.Add(this.btnFontAll);
			this.groupBox4.Controls.Add(this.btnFontDelete);
			this.groupBox4.Controls.Add(this.btnFontAdd);
			this.groupBox4.Controls.Add(this.FontRandomize);
			this.groupBox4.Controls.Add(this.FontList);
			this.groupBox4.Location = new global::System.Drawing.Point(13, 252);
			this.groupBox4.Name = global::<Module>.smethod_23<string>(79923401U);
			this.groupBox4.Size = new global::System.Drawing.Size(212, 233);
			this.groupBox4.TabIndex = 11;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = global::<Module>.smethod_25<string>(1606664461U);
			this.cbEnableFont.AutoSize = true;
			this.cbEnableFont.Checked = true;
			this.cbEnableFont.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.cbEnableFont.Location = new global::System.Drawing.Point(142, 0);
			this.cbEnableFont.Name = global::<Module>.smethod_25<string>(2372236444U);
			this.cbEnableFont.Size = new global::System.Drawing.Size(58, 17);
			this.cbEnableFont.TabIndex = 15;
			this.cbEnableFont.Text = global::<Module>.smethod_23<string>(2421717463U);
			this.cbEnableFont.UseVisualStyleBackColor = true;
			this.btnFontAll.Location = new global::System.Drawing.Point(53, 206);
			this.btnFontAll.Name = global::<Module>.smethod_25<string>(2998613521U);
			this.btnFontAll.Size = new global::System.Drawing.Size(18, 23);
			this.btnFontAll.TabIndex = 12;
			this.btnFontAll.Tag = global::<Module>.smethod_24<string>(4257308719U);
			this.btnFontAll.Text = global::<Module>.smethod_23<string>(4104810856U);
			this.btnFontAll.UseVisualStyleBackColor = true;
			this.btnFontAll.Click += new global::System.EventHandler(this.btnFontAll_Click);
			this.btnFontAll.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.btnFontAll.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.btnFontDelete.Location = new global::System.Drawing.Point(33, 206);
			this.btnFontDelete.Name = global::<Module>.smethod_25<string>(3277003333U);
			this.btnFontDelete.Size = new global::System.Drawing.Size(18, 23);
			this.btnFontDelete.TabIndex = 11;
			this.btnFontDelete.Tag = global::<Module>.smethod_23<string>(3312869723U);
			this.btnFontDelete.Text = global::<Module>.smethod_26<string>(4042439650U);
			this.btnFontDelete.UseVisualStyleBackColor = true;
			this.btnFontDelete.Click += new global::System.EventHandler(this.btnFontDelete_Click);
			this.btnFontDelete.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.btnFontDelete.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.btnFontAdd.Location = new global::System.Drawing.Point(14, 206);
			this.btnFontAdd.Name = global::<Module>.smethod_24<string>(3321897033U);
			this.btnFontAdd.Size = new global::System.Drawing.Size(18, 23);
			this.btnFontAdd.TabIndex = 10;
			this.btnFontAdd.Tag = global::<Module>.smethod_23<string>(1665553550U);
			this.btnFontAdd.Text = global::<Module>.smethod_25<string>(791569815U);
			this.btnFontAdd.UseVisualStyleBackColor = true;
			this.btnFontAdd.Click += new global::System.EventHandler(this.btnFontAdd_Click);
			this.btnFontAdd.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.btnFontAdd.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.FontRandomize.Location = new global::System.Drawing.Point(100, 206);
			this.FontRandomize.Name = global::<Module>.smethod_26<string>(2623552410U);
			this.FontRandomize.Size = new global::System.Drawing.Size(96, 23);
			this.FontRandomize.TabIndex = 9;
			this.FontRandomize.Text = global::<Module>.smethod_24<string>(2615134079U);
			this.FontRandomize.UseVisualStyleBackColor = true;
			this.FontRandomize.Click += new global::System.EventHandler(this.FontRandomize_Click);
			this.FontList.FormattingEnabled = true;
			this.FontList.Location = new global::System.Drawing.Point(14, 19);
			this.FontList.Name = global::<Module>.smethod_25<string>(4174981672U);
			this.FontList.Size = new global::System.Drawing.Size(182, 180);
			this.FontList.TabIndex = 0;
			this.FontList.Tag = global::<Module>.smethod_26<string>(490433353U);
			this.FontList.ItemCheck += new global::System.Windows.Forms.ItemCheckEventHandler(this.FontList_ItemCheck);
			this.FontList.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.FontList.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.groupBox6.Controls.Add(this.btnPluginAll);
			this.groupBox6.Controls.Add(this.btnPluginDelete);
			this.groupBox6.Controls.Add(this.btnPluginAdd);
			this.groupBox6.Controls.Add(this.PluginRandomize);
			this.groupBox6.Controls.Add(this.PluginList);
			this.groupBox6.Location = new global::System.Drawing.Point(231, 252);
			this.groupBox6.Name = global::<Module>.smethod_24<string>(803753571U);
			this.groupBox6.Size = new global::System.Drawing.Size(212, 233);
			this.groupBox6.TabIndex = 15;
			this.groupBox6.TabStop = false;
			this.groupBox6.Text = global::<Module>.smethod_24<string>(2429672815U);
			this.btnPluginAll.Location = new global::System.Drawing.Point(52, 206);
			this.btnPluginAll.Name = global::<Module>.smethod_26<string>(3306638240U);
			this.btnPluginAll.Size = new global::System.Drawing.Size(18, 23);
			this.btnPluginAll.TabIndex = 13;
			this.btnPluginAll.Tag = global::<Module>.smethod_23<string>(1559660332U);
			this.btnPluginAll.Text = global::<Module>.smethod_26<string>(1156783200U);
			this.btnPluginAll.UseVisualStyleBackColor = true;
			this.btnPluginAll.Click += new global::System.EventHandler(this.btnPluginAll_Click);
			this.btnPluginAll.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.btnPluginAll.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.btnPluginDelete.Location = new global::System.Drawing.Point(33, 206);
			this.btnPluginDelete.Name = global::<Module>.smethod_24<string>(2253362190U);
			this.btnPluginDelete.Size = new global::System.Drawing.Size(18, 23);
			this.btnPluginDelete.TabIndex = 13;
			this.btnPluginDelete.Tag = global::<Module>.smethod_23<string>(3803784856U);
			this.btnPluginDelete.Text = global::<Module>.smethod_24<string>(1005470231U);
			this.btnPluginDelete.UseVisualStyleBackColor = true;
			this.btnPluginDelete.Click += new global::System.EventHandler(this.btnPluginDelete_Click);
			this.btnPluginDelete.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.btnPluginDelete.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.btnPluginAdd.Location = new global::System.Drawing.Point(13, 206);
			this.btnPluginAdd.Name = global::<Module>.smethod_25<string>(2338729984U);
			this.btnPluginAdd.Size = new global::System.Drawing.Size(18, 23);
			this.btnPluginAdd.TabIndex = 12;
			this.btnPluginAdd.Tag = global::<Module>.smethod_23<string>(1255035419U);
			this.btnPluginAdd.Text = global::<Module>.smethod_24<string>(652848981U);
			this.btnPluginAdd.UseVisualStyleBackColor = true;
			this.btnPluginAdd.Click += new global::System.EventHandler(this.btnPluginAdd_Click);
			this.btnPluginAdd.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.btnPluginAdd.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.PluginRandomize.Location = new global::System.Drawing.Point(102, 206);
			this.PluginRandomize.Name = global::<Module>.smethod_25<string>(2060340172U);
			this.PluginRandomize.Size = new global::System.Drawing.Size(96, 23);
			this.PluginRandomize.TabIndex = 10;
			this.PluginRandomize.Text = global::<Module>.smethod_26<string>(550308522U);
			this.PluginRandomize.UseVisualStyleBackColor = true;
			this.PluginRandomize.Click += new global::System.EventHandler(this.PluginRandomize_Click);
			this.PluginList.FormattingEnabled = true;
			this.PluginList.Location = new global::System.Drawing.Point(14, 19);
			this.PluginList.Name = global::<Module>.smethod_25<string>(1918415303U);
			this.PluginList.Size = new global::System.Drawing.Size(182, 180);
			this.PluginList.TabIndex = 0;
			this.PluginList.Tag = global::<Module>.smethod_27<string>(264879244U);
			this.PluginList.ItemCheck += new global::System.Windows.Forms.ItemCheckEventHandler(this.PluginList_ItemCheck);
			this.PluginList.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.PluginList.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.PluginList.MouseMove += new global::System.Windows.Forms.MouseEventHandler(this.PluginList_MouseMove);
			this.grpHelp.Controls.Add(this.lblHelp);
			this.grpHelp.Controls.Add(this.label12);
			this.grpHelp.Controls.Add(this.lblStatus);
			this.grpHelp.Controls.Add(this.lblStatusStatic);
			this.grpHelp.Location = new global::System.Drawing.Point(451, 252);
			this.grpHelp.Name = global::<Module>.smethod_23<string>(315870758U);
			this.grpHelp.Size = new global::System.Drawing.Size(212, 233);
			this.grpHelp.TabIndex = 13;
			this.grpHelp.TabStop = false;
			this.lblHelp.Font = new global::System.Drawing.Font(global::<Module>.smethod_26<string>(3737666796U), 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.lblHelp.Location = new global::System.Drawing.Point(6, 78);
			this.lblHelp.Name = global::<Module>.smethod_25<string>(300329057U);
			this.lblHelp.Size = new global::System.Drawing.Size(200, 125);
			this.lblHelp.TabIndex = 6;
			this.label12.AutoSize = true;
			this.label12.Font = new global::System.Drawing.Font(global::<Module>.smethod_26<string>(3737666796U), 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label12.Location = new global::System.Drawing.Point(6, 63);
			this.label12.Name = global::<Module>.smethod_24<string>(3864546492U);
			this.label12.Size = new global::System.Drawing.Size(37, 13);
			this.label12.TabIndex = 5;
			this.label12.Text = global::<Module>.smethod_24<string>(2414937873U);
			this.lblStatus.AutoSize = true;
			this.lblStatus.Font = new global::System.Drawing.Font(global::<Module>.smethod_25<string>(3788173451U), 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.lblStatus.Location = new global::System.Drawing.Point(6, 34);
			this.lblStatus.Name = global::<Module>.smethod_26<string>(1379457067U);
			this.lblStatus.Size = new global::System.Drawing.Size(0, 15);
			this.lblStatus.TabIndex = 4;
			this.lblStatusStatic.AutoSize = true;
			this.lblStatusStatic.Font = new global::System.Drawing.Font(global::<Module>.smethod_26<string>(3737666796U), 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.lblStatusStatic.Location = new global::System.Drawing.Point(6, 19);
			this.lblStatusStatic.Name = global::<Module>.smethod_24<string>(2913896768U);
			this.lblStatusStatic.Size = new global::System.Drawing.Size(109, 13);
			this.lblStatusStatic.TabIndex = 3;
			this.lblStatusStatic.Text = global::<Module>.smethod_25<string>(787511228U);
			this.ofd.DefaultExt = global::<Module>.smethod_25<string>(1483485758U);
			this.ofd.Filter = global::<Module>.smethod_24<string>(2468796434U);
			this.ofd.Title = global::<Module>.smethod_24<string>(3960072067U);
			this.sfd.Filter = global::<Module>.smethod_27<string>(2461870355U);
			this.sfd.Title = global::<Module>.smethod_26<string>(382676214U);
			this.bgwBrowser.DoWork += new global::System.ComponentModel.DoWorkEventHandler(this.bgw_DoWork);
			this.bgwBrowser.RunWorkerCompleted += new global::System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwBrowser_RunWorkerCompleted);
			this.btnNotes.Location = new global::System.Drawing.Point(431, 491);
			this.btnNotes.Name = global::<Module>.smethod_25<string>(4110771430U);
			this.btnNotes.Size = new global::System.Drawing.Size(101, 23);
			this.btnNotes.TabIndex = 19;
			this.btnNotes.Text = global::<Module>.smethod_26<string>(1317165093U);
			this.btnNotes.UseVisualStyleBackColor = true;
			this.btnNotes.Click += new global::System.EventHandler(this.btnNotes_Click);
			this.btnClean.Location = new global::System.Drawing.Point(13, 493);
			this.btnClean.Name = global::<Module>.smethod_27<string>(3388532675U);
			this.btnClean.Size = new global::System.Drawing.Size(101, 23);
			this.btnClean.TabIndex = 20;
			this.btnClean.Text = global::<Module>.smethod_26<string>(3469436938U);
			this.btnClean.UseVisualStyleBackColor = true;
			this.btnClean.Click += new global::System.EventHandler(this.btnClean_Click);
			this.label9.AutoSize = true;
			this.label9.Location = new global::System.Drawing.Point(11, 115);
			this.label9.Name = global::<Module>.smethod_26<string>(1336317881U);
			this.label9.Size = new global::System.Drawing.Size(161, 13);
			this.label9.TabIndex = 16;
			this.label9.Text = global::<Module>.smethod_23<string>(201547566U);
			this.AdvancedDisableDeviceFontEnumeration.AutoSize = true;
			this.AdvancedDisableDeviceFontEnumeration.Location = new global::System.Drawing.Point(14, 133);
			this.AdvancedDisableDeviceFontEnumeration.Name = global::<Module>.smethod_26<string>(1355470669U);
			this.AdvancedDisableDeviceFontEnumeration.Size = new global::System.Drawing.Size(174, 17);
			this.AdvancedDisableDeviceFontEnumeration.TabIndex = 17;
			this.AdvancedDisableDeviceFontEnumeration.Tag = global::<Module>.smethod_27<string>(1616908341U);
			this.AdvancedDisableDeviceFontEnumeration.Text = global::<Module>.smethod_23<string>(2794607344U);
			this.AdvancedDisableDeviceFontEnumeration.UseVisualStyleBackColor = true;
			this.AdvancedDisableDeviceFontEnumeration.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.AdvancedDisableDeviceFontEnumeration.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			this.AdvancedAVHardwareDisable.AutoSize = true;
			this.AdvancedAVHardwareDisable.Location = new global::System.Drawing.Point(14, 156);
			this.AdvancedAVHardwareDisable.Name = global::<Module>.smethod_23<string>(2987889096U);
			this.AdvancedAVHardwareDisable.Size = new global::System.Drawing.Size(120, 17);
			this.AdvancedAVHardwareDisable.TabIndex = 18;
			this.AdvancedAVHardwareDisable.Tag = global::<Module>.smethod_23<string>(1634916832U);
			this.AdvancedAVHardwareDisable.Text = global::<Module>.smethod_23<string>(3143542598U);
			this.AdvancedAVHardwareDisable.UseVisualStyleBackColor = true;
			this.AdvancedAVHardwareDisable.MouseEnter += new global::System.EventHandler(this.GlobalMouseEnter);
			this.AdvancedAVHardwareDisable.MouseLeave += new global::System.EventHandler(this.GlobalMouseLeave);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(675, 528);
			base.Controls.Add(this.btnClean);
			base.Controls.Add(this.btnNotes);
			base.Controls.Add(this.grpHelp);
			base.Controls.Add(this.groupBox6);
			base.Controls.Add(this.groupBox4);
			base.Controls.Add(this.groupBox3);
			base.Controls.Add(this.groupBox2);
			base.Controls.Add(this.groupBox1);
			base.Controls.Add(this.btnStart);
			this.Font = new global::System.Drawing.Font(global::<Module>.smethod_25<string>(3821607196U), 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject(global::<Module>.smethod_25<string>(4145533799U));
			base.KeyPreview = true;
			base.MaximizeBox = false;
			base.Name = global::<Module>.smethod_24<string>(2223389210U);
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = global::<Module>.smethod_25<string>(954752668U);
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
			base.Load += new global::System.EventHandler(this.Main_Load);
			base.KeyDown += new global::System.Windows.Forms.KeyEventHandler(this.Main_KeyDown);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.fillDemo).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.strokeDemo).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.BrowserCanvasFontSize).EndInit();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.groupBox4.ResumeLayout(false);
			this.groupBox4.PerformLayout();
			this.groupBox6.ResumeLayout(false);
			this.grpHelp.ResumeLayout(false);
			this.grpHelp.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x040000D5 RID: 213
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040000D6 RID: 214
		private global::System.Windows.Forms.Button btnStart;

		// Token: 0x040000D7 RID: 215
		private global::System.Windows.Forms.GroupBox groupBox1;

		// Token: 0x040000D8 RID: 216
		private global::System.Windows.Forms.Button OSRandomize;

		// Token: 0x040000D9 RID: 217
		private global::System.Windows.Forms.ComboBox OSResolution;

		// Token: 0x040000DA RID: 218
		private global::System.Windows.Forms.Label label4;

		// Token: 0x040000DB RID: 219
		private global::System.Windows.Forms.ComboBox OSLanguage;

		// Token: 0x040000DC RID: 220
		private global::System.Windows.Forms.Label label3;

		// Token: 0x040000DD RID: 221
		private global::System.Windows.Forms.ComboBox OSPlatform;

		// Token: 0x040000DE RID: 222
		private global::System.Windows.Forms.Label label2;

		// Token: 0x040000DF RID: 223
		private global::System.Windows.Forms.ComboBox OSVersion;

		// Token: 0x040000E0 RID: 224
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040000E1 RID: 225
		private global::System.Windows.Forms.GroupBox groupBox2;

		// Token: 0x040000E2 RID: 226
		private global::System.Windows.Forms.Button BrowserRandomize;

		// Token: 0x040000E3 RID: 227
		private global::System.Windows.Forms.ComboBox BrowserVersion;

		// Token: 0x040000E4 RID: 228
		private global::System.Windows.Forms.Label label7;

		// Token: 0x040000E5 RID: 229
		private global::System.Windows.Forms.ComboBox BrowserProduct;

		// Token: 0x040000E6 RID: 230
		private global::System.Windows.Forms.Label label8;

		// Token: 0x040000E7 RID: 231
		private global::System.Windows.Forms.GroupBox groupBox3;

		// Token: 0x040000E8 RID: 232
		private global::System.Windows.Forms.Label label5;

		// Token: 0x040000E9 RID: 233
		private global::System.Windows.Forms.Label label6;

		// Token: 0x040000EA RID: 234
		private global::System.Windows.Forms.GroupBox groupBox4;

		// Token: 0x040000EB RID: 235
		private global::System.Windows.Forms.CheckedListBox FontList;

		// Token: 0x040000EC RID: 236
		private global::System.Windows.Forms.GroupBox groupBox6;

		// Token: 0x040000ED RID: 237
		private global::System.Windows.Forms.CheckedListBox PluginList;

		// Token: 0x040000EE RID: 238
		private global::System.Windows.Forms.GroupBox grpHelp;

		// Token: 0x040000EF RID: 239
		private global::System.Windows.Forms.Button FontRandomize;

		// Token: 0x040000F0 RID: 240
		private global::System.Windows.Forms.Button PluginRandomize;

		// Token: 0x040000F1 RID: 241
		private global::System.Windows.Forms.Label lblHelp;

		// Token: 0x040000F2 RID: 242
		private global::System.Windows.Forms.Label label12;

		// Token: 0x040000F3 RID: 243
		private global::System.Windows.Forms.Label lblStatus;

		// Token: 0x040000F4 RID: 244
		private global::System.Windows.Forms.Label lblStatusStatic;

		// Token: 0x040000F5 RID: 245
		private global::System.Windows.Forms.ComboBox OSTimezone;

		// Token: 0x040000F6 RID: 246
		private global::System.Windows.Forms.Label label14;

		// Token: 0x040000F7 RID: 247
		private global::System.Windows.Forms.ComboBox BrowserFlash;

		// Token: 0x040000F8 RID: 248
		private global::System.Windows.Forms.Label label15;

		// Token: 0x040000F9 RID: 249
		private global::System.Windows.Forms.Button btnFontDelete;

		// Token: 0x040000FA RID: 250
		private global::System.Windows.Forms.Button btnFontAdd;

		// Token: 0x040000FB RID: 251
		private global::System.Windows.Forms.Button btnPluginDelete;

		// Token: 0x040000FC RID: 252
		private global::System.Windows.Forms.Button btnPluginAdd;

		// Token: 0x040000FD RID: 253
		private global::System.Windows.Forms.Button btnFontAll;

		// Token: 0x040000FE RID: 254
		private global::System.Windows.Forms.Button btnPluginAll;

		// Token: 0x040000FF RID: 255
		private global::System.Windows.Forms.OpenFileDialog ofd;

		// Token: 0x04000100 RID: 256
		private global::System.Windows.Forms.SaveFileDialog sfd;

		// Token: 0x04000101 RID: 257
		private global::System.ComponentModel.BackgroundWorker bgwBrowser;

		// Token: 0x04000102 RID: 258
		private global::System.Windows.Forms.ToolTip toolTip;

		// Token: 0x04000103 RID: 259
		private global::System.Windows.Forms.PictureBox fillDemo;

		// Token: 0x04000104 RID: 260
		private global::System.Windows.Forms.PictureBox strokeDemo;

		// Token: 0x04000105 RID: 261
		private global::System.Windows.Forms.MaskedTextBox BrowserCanvasFill;

		// Token: 0x04000106 RID: 262
		private global::System.Windows.Forms.MaskedTextBox BrowserCanvasStroke;

		// Token: 0x04000107 RID: 263
		private global::System.Windows.Forms.NumericUpDown BrowserCanvasFontSize;

		// Token: 0x04000108 RID: 264
		private global::System.Windows.Forms.ComboBox BrowserCanvasFont;

		// Token: 0x04000109 RID: 265
		private global::System.Windows.Forms.Label label16;

		// Token: 0x0400010A RID: 266
		private global::System.Windows.Forms.Label label11;

		// Token: 0x0400010B RID: 267
		private global::System.Windows.Forms.Label label10;

		// Token: 0x0400010C RID: 268
		private global::System.Windows.Forms.ComboBox AdvancedUseragent;

		// Token: 0x0400010D RID: 269
		private global::System.Windows.Forms.CheckBox cbEnableFont;

		// Token: 0x0400010E RID: 270
		private global::System.Windows.Forms.ComboBox AdvancedStartpage;

		// Token: 0x0400010F RID: 271
		private global::System.Windows.Forms.Button btnNotes;

		// Token: 0x04000110 RID: 272
		private global::System.Windows.Forms.CheckBox AdvancedAVHardwareDisable;

		// Token: 0x04000111 RID: 273
		private global::System.Windows.Forms.CheckBox AdvancedDisableDeviceFontEnumeration;

		// Token: 0x04000112 RID: 274
		private global::System.Windows.Forms.Label label9;

		// Token: 0x04000113 RID: 275
		private global::System.Windows.Forms.Button btnClean;
	}
}
