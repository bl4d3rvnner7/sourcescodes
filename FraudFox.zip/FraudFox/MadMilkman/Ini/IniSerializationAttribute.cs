﻿using System;

namespace MadMilkman.Ini
{
	// Token: 0x0200017F RID: 383
	[AttributeUsage(AttributeTargets.Property, Inherited = false, AllowMultiple = false)]
	public sealed class IniSerializationAttribute : Attribute
	{
		// Token: 0x17000359 RID: 857
		// (get) Token: 0x060016B4 RID: 5812 RVA: 0x0001627B File Offset: 0x0001447B
		// (set) Token: 0x060016B5 RID: 5813 RVA: 0x00016283 File Offset: 0x00014483
		public string Alias { get; private set; }

		// Token: 0x1700035A RID: 858
		// (get) Token: 0x060016B6 RID: 5814 RVA: 0x0001628C File Offset: 0x0001448C
		// (set) Token: 0x060016B7 RID: 5815 RVA: 0x00016294 File Offset: 0x00014494
		public bool Ignore { get; private set; }

		// Token: 0x060016B8 RID: 5816 RVA: 0x0001629D File Offset: 0x0001449D
		public IniSerializationAttribute(string alias)
		{
			this.Alias = alias;
		}

		// Token: 0x060016B9 RID: 5817 RVA: 0x000162AC File Offset: 0x000144AC
		public IniSerializationAttribute(bool ignore)
		{
			this.Ignore = ignore;
		}
	}
}
