﻿using System;

namespace MadMilkman.Ini
{
	// Token: 0x0200016B RID: 363
	internal enum IniCommentType
	{
		// Token: 0x0400089F RID: 2207
		Leading,
		// Token: 0x040008A0 RID: 2208
		Trailing
	}
}
