﻿using System;
using System.Diagnostics;
using System.Text;

namespace MadMilkman.Ini
{
	// Token: 0x02000179 RID: 377
	public sealed class IniOptions
	{
		// Token: 0x1700034E RID: 846
		// (get) Token: 0x06001639 RID: 5689 RVA: 0x00016045 File Offset: 0x00014245
		// (set) Token: 0x0600163A RID: 5690 RVA: 0x0001604D File Offset: 0x0001424D
		public Encoding Encoding
		{
			get
			{
				return this.encoding;
			}
			set
			{
				if (value == null)
				{
					this.encoding = IniOptions.smethod_0();
				}
				this.encoding = value;
			}
		}

		// Token: 0x1700034F RID: 847
		// (get) Token: 0x0600163B RID: 5691 RVA: 0x00016064 File Offset: 0x00014264
		// (set) Token: 0x0600163C RID: 5692 RVA: 0x0001606C File Offset: 0x0001426C
		public IniCommentStarter CommentStarter { get; set; }

		// Token: 0x17000350 RID: 848
		// (get) Token: 0x0600163D RID: 5693 RVA: 0x00016075 File Offset: 0x00014275
		// (set) Token: 0x0600163E RID: 5694 RVA: 0x0001607D File Offset: 0x0001427D
		public bool Compression { get; set; }

		// Token: 0x17000351 RID: 849
		// (get) Token: 0x0600163F RID: 5695 RVA: 0x00016086 File Offset: 0x00014286
		// (set) Token: 0x06001640 RID: 5696 RVA: 0x0001608E File Offset: 0x0001428E
		public string EncryptionPassword { get; set; }

		// Token: 0x17000352 RID: 850
		// (get) Token: 0x06001641 RID: 5697 RVA: 0x00016097 File Offset: 0x00014297
		// (set) Token: 0x06001642 RID: 5698 RVA: 0x0001609F File Offset: 0x0001429F
		public IniKeyDelimiter KeyDelimiter { get; set; }

		// Token: 0x17000353 RID: 851
		// (get) Token: 0x06001643 RID: 5699 RVA: 0x000160A8 File Offset: 0x000142A8
		// (set) Token: 0x06001644 RID: 5700 RVA: 0x000160B0 File Offset: 0x000142B0
		public IniDuplication KeyDuplicate { get; set; }

		// Token: 0x17000354 RID: 852
		// (get) Token: 0x06001645 RID: 5701 RVA: 0x000160B9 File Offset: 0x000142B9
		// (set) Token: 0x06001646 RID: 5702 RVA: 0x000160C1 File Offset: 0x000142C1
		public bool KeyNameCaseSensitive { get; set; }

		// Token: 0x17000355 RID: 853
		// (get) Token: 0x06001647 RID: 5703 RVA: 0x000160CA File Offset: 0x000142CA
		// (set) Token: 0x06001648 RID: 5704 RVA: 0x000160D2 File Offset: 0x000142D2
		public bool KeySpaceAroundDelimiter { get; set; }

		// Token: 0x17000356 RID: 854
		// (get) Token: 0x06001649 RID: 5705 RVA: 0x000160DB File Offset: 0x000142DB
		// (set) Token: 0x0600164A RID: 5706 RVA: 0x000160E3 File Offset: 0x000142E3
		public IniDuplication SectionDuplicate { get; set; }

		// Token: 0x17000357 RID: 855
		// (get) Token: 0x0600164B RID: 5707 RVA: 0x000160EC File Offset: 0x000142EC
		// (set) Token: 0x0600164C RID: 5708 RVA: 0x000160F4 File Offset: 0x000142F4
		public bool SectionNameCaseSensitive { get; set; }

		// Token: 0x17000358 RID: 856
		// (get) Token: 0x0600164D RID: 5709 RVA: 0x000160FD File Offset: 0x000142FD
		// (set) Token: 0x0600164E RID: 5710 RVA: 0x00016105 File Offset: 0x00014305
		public IniSectionWrapper SectionWrapper
		{
			get
			{
				return this.sectionWrapper;
			}
			set
			{
				this.sectionWrapper = value;
				this.SectionWrapperToCharacters(out this.sectionWrapperStart, out this.sectionWrapperEnd);
			}
		}

		// Token: 0x0600164F RID: 5711 RVA: 0x00070B14 File Offset: 0x0006ED14
		public IniOptions()
		{
			this.encoding = IniOptions.smethod_0();
			this.CommentStarter = IniCommentStarter.Semicolon;
			this.Compression = false;
			this.EncryptionPassword = null;
			this.KeyDelimiter = IniKeyDelimiter.Equal;
			this.KeyDuplicate = IniDuplication.Allowed;
			this.KeyNameCaseSensitive = false;
			this.KeySpaceAroundDelimiter = false;
			this.SectionDuplicate = IniDuplication.Allowed;
			this.SectionNameCaseSensitive = false;
			this.SectionWrapper = IniSectionWrapper.SquareBrackets;
		}

		// Token: 0x06001650 RID: 5712 RVA: 0x00070B7C File Offset: 0x0006ED7C
		internal IniOptions(IniOptions options)
		{
			this.encoding = options.encoding;
			this.CommentStarter = options.CommentStarter;
			this.Compression = options.Compression;
			this.EncryptionPassword = options.EncryptionPassword;
			this.KeyDelimiter = options.KeyDelimiter;
			this.KeyDuplicate = options.KeyDuplicate;
			this.KeyNameCaseSensitive = options.KeyNameCaseSensitive;
			this.KeySpaceAroundDelimiter = options.KeySpaceAroundDelimiter;
			this.SectionDuplicate = options.SectionDuplicate;
			this.SectionNameCaseSensitive = options.SectionNameCaseSensitive;
			this.SectionWrapper = options.SectionWrapper;
		}

		// Token: 0x06001651 RID: 5713 RVA: 0x00070C14 File Offset: 0x0006EE14
		private void SectionWrapperToCharacters(out char startCharacter, out char endCharacte)
		{
			switch (this.sectionWrapper)
			{
			case IniSectionWrapper.AngleBrackets:
				startCharacter = '<';
				endCharacte = '>';
				return;
			case IniSectionWrapper.CurlyBrackets:
				startCharacter = '{';
				endCharacte = '}';
				return;
			case IniSectionWrapper.Parentheses:
				startCharacter = '(';
				endCharacte = ')';
				return;
			default:
				startCharacter = '[';
				endCharacte = ']';
				return;
			}
		}

		// Token: 0x06001652 RID: 5714 RVA: 0x0000C3FB File Offset: 0x0000A5FB
		static Encoding smethod_0()
		{
			return Encoding.ASCII;
		}

		// Token: 0x040008D6 RID: 2262
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private Encoding encoding;

		// Token: 0x040008D7 RID: 2263
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private IniSectionWrapper sectionWrapper;

		// Token: 0x040008D8 RID: 2264
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal char sectionWrapperStart;

		// Token: 0x040008D9 RID: 2265
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal char sectionWrapperEnd;
	}
}
