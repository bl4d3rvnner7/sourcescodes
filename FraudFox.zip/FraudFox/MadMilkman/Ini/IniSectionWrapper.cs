﻿using System;

namespace MadMilkman.Ini
{
	// Token: 0x0200016E RID: 366
	public enum IniSectionWrapper
	{
		// Token: 0x040008A9 RID: 2217
		SquareBrackets,
		// Token: 0x040008AA RID: 2218
		AngleBrackets,
		// Token: 0x040008AB RID: 2219
		CurlyBrackets,
		// Token: 0x040008AC RID: 2220
		Parentheses
	}
}
