﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Threading;

namespace MadMilkman.Ini
{
	// Token: 0x02000182 RID: 386
	public sealed class IniValueBinding
	{
		// Token: 0x14000025 RID: 37
		// (add) Token: 0x060016E6 RID: 5862 RVA: 0x00071C7C File Offset: 0x0006FE7C
		// (remove) Token: 0x060016E7 RID: 5863 RVA: 0x00071CDC File Offset: 0x0006FEDC
		public event EventHandler<IniValueBindingEventArgs> Binding
		{
			add
			{
				EventHandler<IniValueBindingEventArgs> eventHandler = this.Binding;
				for (;;)
				{
					IL_004C:
					int num = 459216082;
					for (;;)
					{
						switch (num ^ 459216083)
						{
						case 0:
							goto IL_0012;
						case 1:
							break;
						case 2:
							goto IL_004C;
						default:
							goto IL_0012;
						}
						IL_0009:
						EventHandler<IniValueBindingEventArgs> eventHandler2 = eventHandler;
						num = 459216083;
						continue;
						IL_0012:
						EventHandler<IniValueBindingEventArgs> eventHandler3 = (EventHandler<IniValueBindingEventArgs>)IniValueBinding.smethod_0(eventHandler2, value);
						eventHandler = Interlocked.CompareExchange<EventHandler<IniValueBindingEventArgs>>(ref this.Binding, eventHandler3, eventHandler2);
						if (eventHandler == eventHandler2)
						{
							return;
						}
						goto IL_0009;
					}
				}
			}
			remove
			{
				EventHandler<IniValueBindingEventArgs> eventHandler = this.Binding;
				for (;;)
				{
					IL_0057:
					int num = 1222806237;
					for (;;)
					{
						EventHandler<IniValueBindingEventArgs> eventHandler3;
						EventHandler<IniValueBindingEventArgs> eventHandler2;
						switch (num ^ 1222806236)
						{
						case 0:
							goto IL_0026;
						case 1:
							break;
						case 2:
							goto IL_0057;
						case 3:
							eventHandler2 = (EventHandler<IniValueBindingEventArgs>)IniValueBinding.smethod_1(eventHandler3, value);
							num = 1222806236;
							continue;
						default:
							goto IL_0026;
						}
						IL_001D:
						eventHandler3 = eventHandler;
						num = 1222806239;
						continue;
						IL_0026:
						eventHandler = Interlocked.CompareExchange<EventHandler<IniValueBindingEventArgs>>(ref this.Binding, eventHandler2, eventHandler3);
						if (eventHandler == eventHandler3)
						{
							return;
						}
						goto IL_001D;
					}
				}
			}
		}

		// Token: 0x060016E8 RID: 5864 RVA: 0x00016372 File Offset: 0x00014572
		internal IniValueBinding(IniFile iniFile)
		{
			if (iniFile == null)
			{
				throw IniValueBinding.smethod_2(<Module>.smethod_27<string>(3450601187U));
			}
			this.iniFile = iniFile;
			this.args = new IniValueBindingEventArgs();
		}

		// Token: 0x060016E9 RID: 5865 RVA: 0x00071D48 File Offset: 0x0006FF48
		public void Bind()
		{
			IEnumerator<KeyValuePair<IniKey, string>> enumerator = this.GetPlaceholderPairs(null).GetEnumerator();
			try
			{
				while (IniValueBinding.smethod_6(enumerator))
				{
					KeyValuePair<IniKey, string> keyValuePair = enumerator.Current;
					IniKey key = keyValuePair.Key;
					string value = keyValuePair.Value;
					string text = IniValueBinding.smethod_4(value, 2, IniValueBinding.smethod_3(value) - 3);
					int num = IniValueBinding.smethod_5(value, '|');
					string text2;
					if (num != -1)
					{
						IniSection iniSection = this.iniFile.Sections[IniValueBinding.smethod_4(value, 2, num - 2)];
						if (iniSection == null)
						{
							continue;
						}
						text2 = IniValueBinding.GetTargetedValue(iniSection, IniValueBinding.smethod_4(value, num + 1, IniValueBinding.smethod_3(value) - num - 2));
					}
					else
					{
						text2 = IniValueBinding.GetTargetedValue(key.ParentSection, text);
					}
					this.ExecuteBinding(value, text, key, text2);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					IniValueBinding.smethod_7(enumerator);
				}
			}
		}

		// Token: 0x060016EA RID: 5866 RVA: 0x0001639F File Offset: 0x0001459F
		public void Bind(object dataSource)
		{
			this.Bind(dataSource, null);
		}

		// Token: 0x060016EB RID: 5867 RVA: 0x00071E24 File Offset: 0x00070024
		public void Bind(object dataSource, string sectionName)
		{
			if (dataSource == null)
			{
				throw IniValueBinding.smethod_2(<Module>.smethod_25<string>(2527738413U));
			}
			IDictionary<string, string> dictionary = IniValueBinding.CreateDataSourceDictionary(dataSource);
			if (dictionary != null)
			{
				IEnumerator<KeyValuePair<IniKey, string>> enumerator = this.GetPlaceholderPairs(this.iniFile.Sections[sectionName]).GetEnumerator();
				try
				{
					while (IniValueBinding.smethod_6(enumerator))
					{
						KeyValuePair<IniKey, string> keyValuePair = enumerator.Current;
						IniKey key = keyValuePair.Key;
						string value = keyValuePair.Value;
						string text = IniValueBinding.smethod_4(value, 2, IniValueBinding.smethod_3(value) - 3);
						string text2;
						dictionary.TryGetValue(text, out text2);
						this.ExecuteBinding(value, text, key, text2);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						IniValueBinding.smethod_7(enumerator);
					}
				}
				return;
			}
		}

		// Token: 0x060016EC RID: 5868 RVA: 0x00071ED8 File Offset: 0x000700D8
		private void ExecuteBinding(string placeholder, string placeholderName, IniKey placeholderKey, string targetedValue)
		{
			this.args.Initialize(placeholderName, placeholderKey, targetedValue, targetedValue != null);
			if (this.Binding != null)
			{
				this.Binding(this, this.args);
			}
			if (this.args.Value != null)
			{
				placeholderKey.Value = IniValueBinding.smethod_8(placeholderKey.Value, placeholder, this.args.Value);
			}
			this.args.Reset();
		}

		// Token: 0x060016ED RID: 5869 RVA: 0x00071F4C File Offset: 0x0007014C
		private IEnumerable<KeyValuePair<IniKey, string>> GetPlaceholderPairs(IniSection section)
		{
			if (section == null)
			{
				goto IL_003C;
			}
			IEnumerator<IniKey> enumerator = section.Keys.GetEnumerator();
			try
			{
				IEnumerator<IniSection> enumerator3;
				while (IniValueBinding.<GetPlaceholderPairs>d__0.smethod_7(enumerator))
				{
					IniKey key = enumerator.Current;
					if (key.Value != null)
					{
						int matchStartat = IniValueBinding.<GetPlaceholderPairs>d__0.smethod_2(key.Value, <Module>.smethod_23<string>(2355916791U));
						if (matchStartat != -1)
						{
							IEnumerator enumerator2 = IniValueBinding.<GetPlaceholderPairs>d__0.smethod_4(IniValueBinding.<GetPlaceholderPairs>d__0.smethod_3(IniValueBinding.placeholderPattern, key.Value, matchStartat));
							for (;;)
							{
								if (!IniValueBinding.<GetPlaceholderPairs>d__0.smethod_7(enumerator2))
								{
									goto IL_010F;
								}
								Match match = (Match)IniValueBinding.<GetPlaceholderPairs>d__0.smethod_5(enumerator2);
								yield return new KeyValuePair<IniKey, string>(key, IniValueBinding.<GetPlaceholderPairs>d__0.smethod_6(match));
								goto IL_0060;
								for (;;)
								{
									Block_4:
									IEnumerator<KeyValuePair<IniKey, string>> enumerator4;
									try
									{
										while (IniValueBinding.<GetPlaceholderPairs>d__0.smethod_7(enumerator3))
										{
											IniSection iniSection = enumerator3.Current;
											enumerator4 = this.GetPlaceholderPairs(iniSection).GetEnumerator();
											while (!IniValueBinding.<GetPlaceholderPairs>d__0.smethod_7(enumerator4))
											{
												goto IL_0077;
												Block_12:
												try
												{
													continue;
													IL_0077:;
												}
												finally
												{
													if (enumerator4 != null)
													{
														IniValueBinding.<GetPlaceholderPairs>d__0.smethod_9(enumerator4);
													}
												}
												goto JumpOutOfTryFinally5;
											}
											goto IL_00D8;
											JumpOutOfTryFinally5:;
										}
										goto JumpOutOfTryFinally4;
										IL_0060:
										int num;
										if (num == 3)
										{
											goto IL_0103;
										}
										if (num != 6)
										{
											goto IL_01EF;
										}
										goto Block_12;
									}
									finally
									{
										if (enumerator3 != null)
										{
											IniValueBinding.<GetPlaceholderPairs>d__0.smethod_9(enumerator3);
										}
									}
									goto JumpOutOfTryFinally4;
									IL_00D8:
									KeyValuePair<IniKey, string> placeholderPair = enumerator4.Current;
									yield return placeholderPair;
									goto IL_0060;
								}
								IL_0103:
								try
								{
									continue;
									IL_010F:;
								}
								finally
								{
									IDisposable disposable = enumerator2 as IDisposable;
									if (disposable != null)
									{
										IniValueBinding.<GetPlaceholderPairs>d__0.smethod_9(disposable);
									}
								}
								break;
							}
							continue;
							JumpOutOfTryFinally4:
							break;
						}
					}
				}
				goto JumpOutOfTryFinally1;
				IL_003C:
				enumerator3 = this.iniFile.Sections.GetEnumerator();
				goto Block_4;
			}
			finally
			{
				if (enumerator != null)
				{
					IniValueBinding.<GetPlaceholderPairs>d__0.smethod_9(enumerator);
				}
			}
			JumpOutOfTryFinally1:
			IL_01EF:
			yield break;
		}

		// Token: 0x060016EE RID: 5870 RVA: 0x00071F70 File Offset: 0x00070170
		private static string GetTargetedValue(IniSection targetedSection, string targetedKeyName)
		{
			IniKey iniKey = targetedSection.Keys[targetedKeyName];
			if (iniKey == null)
			{
				return null;
			}
			return iniKey.Value;
		}

		// Token: 0x060016EF RID: 5871 RVA: 0x00071F98 File Offset: 0x00070198
		private static IDictionary<string, string> CreateDataSourceDictionary(object dataSource)
		{
			IDictionary<string, string> dictionary = dataSource as IDictionary<string, string>;
			if (dictionary != null)
			{
				return dictionary;
			}
			ICollection<KeyValuePair<string, string>> collection = dataSource as ICollection<KeyValuePair<string, string>>;
			if (collection != null)
			{
				dictionary = new Dictionary<string, string>(collection.Count);
				IEnumerator<KeyValuePair<string, string>> enumerator = collection.GetEnumerator();
				try
				{
					while (IniValueBinding.smethod_6(enumerator))
					{
						KeyValuePair<string, string> keyValuePair = enumerator.Current;
						if (!dictionary.ContainsKey(keyValuePair.Key))
						{
							dictionary.Add(keyValuePair);
						}
					}
				}
				finally
				{
					if (enumerator != null)
					{
						IniValueBinding.smethod_7(enumerator);
					}
				}
				return dictionary;
			}
			IEnumerable<KeyValuePair<string, string>> enumerable = dataSource as IEnumerable<KeyValuePair<string, string>>;
			if (enumerable != null)
			{
				dictionary = new Dictionary<string, string>();
				IEnumerator<KeyValuePair<string, string>> enumerator2 = enumerable.GetEnumerator();
				try
				{
					while (IniValueBinding.smethod_6(enumerator2))
					{
						KeyValuePair<string, string> keyValuePair2 = enumerator2.Current;
						if (!dictionary.ContainsKey(keyValuePair2.Key))
						{
							dictionary.Add(keyValuePair2);
						}
					}
				}
				finally
				{
					if (enumerator2 != null)
					{
						IniValueBinding.smethod_7(enumerator2);
					}
				}
				return dictionary;
			}
			if (dataSource is KeyValuePair<string, string>)
			{
				dictionary = new Dictionary<string, string>(1);
				dictionary.Add((KeyValuePair<string, string>)dataSource);
				return dictionary;
			}
			return null;
		}

		// Token: 0x060016F1 RID: 5873 RVA: 0x0000CD19 File Offset: 0x0000AF19
		static Delegate smethod_0(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Combine(delegate_0, delegate_1);
		}

		// Token: 0x060016F2 RID: 5874 RVA: 0x0000CD22 File Offset: 0x0000AF22
		static Delegate smethod_1(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Remove(delegate_0, delegate_1);
		}

		// Token: 0x060016F3 RID: 5875 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_2(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x060016F4 RID: 5876 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_3(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x060016F5 RID: 5877 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_4(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x060016F6 RID: 5878 RVA: 0x0000FABD File Offset: 0x0000DCBD
		static int smethod_5(string string_0, char char_0)
		{
			return string_0.IndexOf(char_0);
		}

		// Token: 0x060016F7 RID: 5879 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_6(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060016F8 RID: 5880 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_7(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060016F9 RID: 5881 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_8(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x060016FA RID: 5882 RVA: 0x0000FE6E File Offset: 0x0000E06E
		static Regex smethod_9(string string_0, RegexOptions regexOptions_0)
		{
			return new Regex(string_0, regexOptions_0);
		}

		// Token: 0x040008FC RID: 2300
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly IniValueBindingEventArgs args;

		// Token: 0x040008FD RID: 2301
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly IniFile iniFile;

		// Token: 0x040008FE RID: 2302
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private static readonly Regex placeholderPattern = IniValueBinding.smethod_9(<Module>.smethod_27<string>(2844519178U), RegexOptions.Compiled | RegexOptions.CultureInvariant);
	}
}
