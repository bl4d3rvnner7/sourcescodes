﻿using System;
using System.Diagnostics;

namespace MadMilkman.Ini
{
	// Token: 0x02000175 RID: 373
	[DebuggerDisplay("Name = {Name}")]
	public abstract class IniItem
	{
		// Token: 0x1700033D RID: 829
		// (get) Token: 0x060015EB RID: 5611 RVA: 0x00015D20 File Offset: 0x00013F20
		// (set) Token: 0x060015EC RID: 5612 RVA: 0x00015D28 File Offset: 0x00013F28
		public string Name
		{
			get
			{
				return this.name;
			}
			set
			{
				if (this.ParentCollectionCore == null || ((IItemNameVerifier)this.ParentCollectionCore).VerifyItemName(value))
				{
					this.name = value;
				}
			}
		}

		// Token: 0x1700033E RID: 830
		// (get) Token: 0x060015ED RID: 5613 RVA: 0x00015D4C File Offset: 0x00013F4C
		// (set) Token: 0x060015EE RID: 5614 RVA: 0x00015D54 File Offset: 0x00013F54
		public int LeftIndentation { get; set; }

		// Token: 0x1700033F RID: 831
		// (get) Token: 0x060015EF RID: 5615 RVA: 0x00015D5D File Offset: 0x00013F5D
		public IniComment LeadingComment
		{
			get
			{
				if (this.leadingComment == null)
				{
					this.leadingComment = new IniComment(IniCommentType.Leading);
				}
				return this.leadingComment;
			}
		}

		// Token: 0x17000340 RID: 832
		// (get) Token: 0x060015F0 RID: 5616 RVA: 0x00015D79 File Offset: 0x00013F79
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal bool HasLeadingComment
		{
			get
			{
				return this.leadingComment != null;
			}
		}

		// Token: 0x17000341 RID: 833
		// (get) Token: 0x060015F1 RID: 5617 RVA: 0x00015D87 File Offset: 0x00013F87
		public IniComment TrailingComment
		{
			get
			{
				if (this.trailingComment == null)
				{
					this.trailingComment = new IniComment(IniCommentType.Trailing);
				}
				return this.trailingComment;
			}
		}

		// Token: 0x17000342 RID: 834
		// (get) Token: 0x060015F2 RID: 5618 RVA: 0x00015DA3 File Offset: 0x00013FA3
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal bool HasTrailingComment
		{
			get
			{
				return this.trailingComment != null;
			}
		}

		// Token: 0x17000343 RID: 835
		// (get) Token: 0x060015F3 RID: 5619 RVA: 0x00015DB1 File Offset: 0x00013FB1
		public IniFile ParentFile
		{
			get
			{
				return this.parentFile;
			}
		}

		// Token: 0x17000344 RID: 836
		// (get) Token: 0x060015F4 RID: 5620 RVA: 0x00015DB9 File Offset: 0x00013FB9
		// (set) Token: 0x060015F5 RID: 5621 RVA: 0x00015DC1 File Offset: 0x00013FC1
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal object ParentCollectionCore { get; set; }

		// Token: 0x060015F6 RID: 5622 RVA: 0x000705F4 File Offset: 0x0006E7F4
		internal IniItem(IniFile parentFile, string name, IniComment trailingComment = null)
		{
			if (name == null)
			{
				throw IniItem.smethod_0(<Module>.smethod_25<string>(978813330U));
			}
			if (parentFile == null)
			{
				throw IniItem.smethod_0(<Module>.smethod_27<string>(4103304889U));
			}
			this.name = name;
			this.parentFile = parentFile;
			this.trailingComment = trailingComment;
		}

		// Token: 0x060015F7 RID: 5623 RVA: 0x00070644 File Offset: 0x0006E844
		internal IniItem(IniFile parentFile, IniItem sourceItem)
		{
			if (parentFile == null)
			{
				throw IniItem.smethod_0(<Module>.smethod_24<string>(3960569580U));
			}
			this.name = sourceItem.name;
			this.parentFile = parentFile;
			if (sourceItem.HasLeadingComment)
			{
				this.leadingComment = new IniComment(sourceItem.leadingComment);
			}
			if (sourceItem.HasTrailingComment)
			{
				this.trailingComment = new IniComment(sourceItem.trailingComment);
			}
		}

		// Token: 0x060015F8 RID: 5624 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_0(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x040008C4 RID: 2244
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string name;

		// Token: 0x040008C5 RID: 2245
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly IniFile parentFile;

		// Token: 0x040008C6 RID: 2246
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private IniComment leadingComment;

		// Token: 0x040008C7 RID: 2247
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private IniComment trailingComment;
	}
}
