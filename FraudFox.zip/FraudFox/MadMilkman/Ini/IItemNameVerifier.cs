﻿using System;

namespace MadMilkman.Ini
{
	// Token: 0x02000170 RID: 368
	internal interface IItemNameVerifier
	{
		// Token: 0x060015B8 RID: 5560
		bool VerifyItemName(string name);
	}
}
