﻿using System;

namespace MadMilkman.Ini
{
	// Token: 0x02000187 RID: 391
	internal static class IniValueParser<T>
	{
		// Token: 0x06001729 RID: 5929 RVA: 0x0001652D File Offset: 0x0001472D
		static IniValueParser()
		{
			IniValueParser<T>.InitializeParser(IniValueParser<T>.smethod_0(typeof(T).TypeHandle));
		}

		// Token: 0x0600172A RID: 5930 RVA: 0x0007248C File Offset: 0x0007068C
		private static void InitializeParser(Type type)
		{
			if (IniValueParser<T>.smethod_1(type))
			{
				IniValueParser<T>.SetParser<T>(new TryParseDelegate<T>(IniValueParser<T>.EnumTryParse<T>));
				return;
			}
			if (type == IniValueParser<T>.smethod_0(typeof(TimeSpan).TypeHandle))
			{
				IniValueParser<T>.SetParser<TimeSpan>(new TryParseDelegate<TimeSpan>(TimeSpan.TryParse));
				return;
			}
			switch (IniValueParser<T>.smethod_2(type))
			{
			case TypeCode.Boolean:
				IniValueParser<T>.SetParser<bool>(new TryParseDelegate<bool>(bool.TryParse));
				return;
			case TypeCode.Char:
				IniValueParser<T>.SetParser<char>(new TryParseDelegate<char>(char.TryParse));
				return;
			case TypeCode.SByte:
				IniValueParser<T>.SetParser<sbyte>(new TryParseDelegate<sbyte>(sbyte.TryParse));
				return;
			case TypeCode.Byte:
				IniValueParser<T>.SetParser<byte>(new TryParseDelegate<byte>(byte.TryParse));
				return;
			case TypeCode.Int16:
				IniValueParser<T>.SetParser<short>(new TryParseDelegate<short>(short.TryParse));
				return;
			case TypeCode.UInt16:
				IniValueParser<T>.SetParser<ushort>(new TryParseDelegate<ushort>(ushort.TryParse));
				return;
			case TypeCode.Int32:
				IniValueParser<T>.SetParser<int>(new TryParseDelegate<int>(int.TryParse));
				return;
			case TypeCode.UInt32:
				IniValueParser<T>.SetParser<uint>(new TryParseDelegate<uint>(uint.TryParse));
				return;
			case TypeCode.Int64:
				IniValueParser<T>.SetParser<long>(new TryParseDelegate<long>(long.TryParse));
				return;
			case TypeCode.UInt64:
				IniValueParser<T>.SetParser<ulong>(new TryParseDelegate<ulong>(ulong.TryParse));
				return;
			case TypeCode.Single:
				IniValueParser<T>.SetParser<float>(new TryParseDelegate<float>(float.TryParse));
				return;
			case TypeCode.Double:
				IniValueParser<T>.SetParser<double>(new TryParseDelegate<double>(double.TryParse));
				return;
			case TypeCode.Decimal:
				IniValueParser<T>.SetParser<decimal>(new TryParseDelegate<decimal>(decimal.TryParse));
				return;
			case TypeCode.DateTime:
				IniValueParser<T>.SetParser<DateTime>(new TryParseDelegate<DateTime>(DateTime.TryParse));
				return;
			case (TypeCode)17:
				break;
			case TypeCode.String:
				IniValueParser<T>.SetParser<string>(delegate(string value, out string result)
				{
					result = value;
					return true;
				});
				break;
			default:
				return;
			}
		}

		// Token: 0x0600172B RID: 5931 RVA: 0x0001653E File Offset: 0x0001473E
		private static void SetParser<TParser>(TryParseDelegate<TParser> parser)
		{
			IniValueParser<TParser>.parser = parser;
		}

		// Token: 0x0600172C RID: 5932 RVA: 0x00072640 File Offset: 0x00070840
		private static bool EnumTryParse<TEnum>(string value, out TEnum result)
		{
			Type type = IniValueParser<T>.smethod_0(typeof(TEnum).TypeHandle);
			if (!IniValueParser<T>.smethod_3(type, value))
			{
				result = default(TEnum);
				return false;
			}
			result = (TEnum)((object)IniValueParser<T>.smethod_4(type, value));
			return true;
		}

		// Token: 0x0600172D RID: 5933 RVA: 0x00016546 File Offset: 0x00014746
		public static bool TryParse(string value, out T result)
		{
			if (IniValueParser<T>.parser == null)
			{
				throw IniValueParser<T>.smethod_5();
			}
			return IniValueParser<T>.parser(value, out result);
		}

		// Token: 0x04000916 RID: 2326
		private static TryParseDelegate<T> parser;
	}
}
