﻿using System;
using System.Collections.Generic;

namespace MadMilkman.Ini
{
	// Token: 0x0200017A RID: 378
	public sealed class IniSectionCollection : IniItemCollection<IniSection>
	{
		// Token: 0x06001653 RID: 5715 RVA: 0x00016120 File Offset: 0x00014320
		internal IniSectionCollection(IniFile parentFile, IniDuplication duplication, bool caseSensitive)
			: base(parentFile, null, duplication, caseSensitive)
		{
		}

		// Token: 0x06001654 RID: 5716 RVA: 0x0001612C File Offset: 0x0001432C
		public IniSection Add(string name)
		{
			return this.Add(name, null);
		}

		// Token: 0x06001655 RID: 5717 RVA: 0x00070C60 File Offset: 0x0006EE60
		public IniSection Add(string name, IEnumerable<KeyValuePair<string, string>> nameValuePairs)
		{
			IniSection iniSection = new IniSection(base.ParentFile, name, nameValuePairs);
			base.Add(iniSection);
			return iniSection;
		}

		// Token: 0x06001656 RID: 5718 RVA: 0x00016136 File Offset: 0x00014336
		public IniSection Insert(int index, string name)
		{
			return this.Insert(index, name, null);
		}

		// Token: 0x06001657 RID: 5719 RVA: 0x00070C84 File Offset: 0x0006EE84
		public IniSection Insert(int index, string name, IEnumerable<KeyValuePair<string, string>> nameValuePairs)
		{
			IniSection iniSection = new IniSection(base.ParentFile, name, nameValuePairs);
			base.Insert(index, iniSection);
			return iniSection;
		}
	}
}
