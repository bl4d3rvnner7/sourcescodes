﻿using System;

namespace MadMilkman.Ini
{
	// Token: 0x0200016C RID: 364
	public enum IniDuplication
	{
		// Token: 0x040008A2 RID: 2210
		Allowed,
		// Token: 0x040008A3 RID: 2211
		Disallowed,
		// Token: 0x040008A4 RID: 2212
		Ignored
	}
}
