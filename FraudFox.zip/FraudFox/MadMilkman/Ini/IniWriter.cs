﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace MadMilkman.Ini
{
	// Token: 0x0200017E RID: 382
	internal sealed class IniWriter
	{
		// Token: 0x06001699 RID: 5785 RVA: 0x000161EA File Offset: 0x000143EA
		public IniWriter(IniOptions options)
		{
			this.options = options;
		}

		// Token: 0x0600169A RID: 5786 RVA: 0x000161F9 File Offset: 0x000143F9
		public void Write(IniFile iniFile, TextWriter textWriter)
		{
			this.writer = IniWriter.smethod_1(IniWriter.smethod_0());
			this.WriteSections(iniFile.Sections);
			IniWriter.smethod_3(textWriter, this.EncryptAndCompressText(IniWriter.smethod_2(this.writer)));
			IniWriter.smethod_4(textWriter);
		}

		// Token: 0x0600169B RID: 5787 RVA: 0x000713A8 File Offset: 0x0006F5A8
		private string EncryptAndCompressText(string fileContent)
		{
			if (!IniWriter.smethod_5(this.options.EncryptionPassword))
			{
				fileContent = IniEncryptor.Encrypt(fileContent, this.options.EncryptionPassword, this.options.Encoding);
			}
			if (this.options.Compression)
			{
				fileContent = IniCompressor.Compress(fileContent, this.options.Encoding);
			}
			return fileContent;
		}

		// Token: 0x0600169C RID: 5788 RVA: 0x00071408 File Offset: 0x0006F608
		private void WriteSections(IniSectionCollection sections)
		{
			if (sections.Count == 0)
			{
				return;
			}
			this.WriteFirstSection(sections[0]);
			for (int i = 1; i < sections.Count; i++)
			{
				this.WriteSection(sections[i]);
			}
		}

		// Token: 0x0600169D RID: 5789 RVA: 0x00016234 File Offset: 0x00014434
		private void WriteFirstSection(IniSection section)
		{
			if (IniWriter.smethod_6(section.Name, <Module>.smethod_23<string>(149420517U)))
			{
				this.WriteKeys(section.Keys);
				return;
			}
			this.WriteSection(section);
		}

		// Token: 0x0600169E RID: 5790 RVA: 0x0007144C File Offset: 0x0006F64C
		private void WriteSection(IniSection section)
		{
			this.WriteItem(section, IniWriter.smethod_8(new object[]
			{
				IniWriter.smethod_7(' ', section.LeftIndentation),
				this.options.sectionWrapperStart,
				section.Name,
				this.options.sectionWrapperEnd
			}));
			this.WriteKeys(section.Keys);
		}

		// Token: 0x0600169F RID: 5791 RVA: 0x000714B8 File Offset: 0x0006F6B8
		private void WriteKeys(IniKeyCollection keys)
		{
			IEnumerator<IniKey> enumerator = keys.GetEnumerator();
			try
			{
				while (IniWriter.smethod_9(enumerator))
				{
					IniKey iniKey = enumerator.Current;
					this.WriteItem(iniKey, IniWriter.smethod_8(new object[]
					{
						IniWriter.smethod_7(' ', iniKey.LeftIndentation),
						iniKey.Name,
						this.options.KeySpaceAroundDelimiter ? <Module>.smethod_25<string>(482330791U) : string.Empty,
						(char)this.options.KeyDelimiter,
						this.options.KeySpaceAroundDelimiter ? <Module>.smethod_25<string>(482330791U) : string.Empty,
						iniKey.Value
					}));
				}
			}
			finally
			{
				if (enumerator != null)
				{
					IniWriter.smethod_10(enumerator);
				}
			}
		}

		// Token: 0x060016A0 RID: 5792 RVA: 0x0007158C File Offset: 0x0006F78C
		private void WriteItem(IniItem item, string itemContent)
		{
			if (item.HasTrailingComment)
			{
				this.WriteTrailingComment(item.TrailingComment);
				goto IL_004A;
			}
			goto IL_009E;
			int num;
			for (;;)
			{
				IL_006E:
				switch (num ^ 44036739)
				{
				case 0:
					if (item.HasLeadingComment)
					{
						goto Block_2;
					}
					goto IL_0038;
				case 1:
					goto IL_009E;
				case 3:
					IniWriter.smethod_3(this.writer, itemContent);
					num = 44036739;
					continue;
				case 4:
					goto IL_004A;
				case 5:
					goto IL_0038;
				case 6:
					this.WriteEmptyLines(item.LeadingComment.EmptyLinesBefore);
					num = 44036736;
					continue;
				}
				return;
				IL_0038:
				IniWriter.smethod_11(this.writer);
				num = 44036737;
			}
			Block_2:
			this.WriteLeadingComment(item.LeadingComment);
			return;
			IL_004A:
			num = 44036738;
			goto IL_006E;
			IL_009E:
			num = ((!item.HasLeadingComment) ? 44036736 : 44036741);
			goto IL_006E;
		}

		// Token: 0x060016A1 RID: 5793 RVA: 0x00071654 File Offset: 0x0006F854
		private void WriteTrailingComment(IniComment trailingComment)
		{
			this.WriteEmptyLines(trailingComment.EmptyLinesBefore);
			if (trailingComment.Text != null)
			{
				foreach (string text in IniWriter.smethod_12(trailingComment.Text, IniWriter.NewLines, StringSplitOptions.None))
				{
					IniWriter.smethod_14(this.writer, IniWriter.smethod_13(IniWriter.smethod_7(' ', trailingComment.LeftIndentation), (char)this.options.CommentStarter, text));
				}
			}
		}

		// Token: 0x060016A2 RID: 5794 RVA: 0x000716CC File Offset: 0x0006F8CC
		private void WriteLeadingComment(IniComment leadingComment)
		{
			if (leadingComment.Text != null)
			{
				IniWriter.smethod_14(this.writer, IniWriter.smethod_13(IniWriter.smethod_7(' ', leadingComment.LeftIndentation), (char)this.options.CommentStarter, leadingComment.Text));
				return;
			}
			IniWriter.smethod_11(this.writer);
		}

		// Token: 0x060016A3 RID: 5795 RVA: 0x00071724 File Offset: 0x0006F924
		private void WriteEmptyLines(int count)
		{
			for (int i = 0; i < count; i++)
			{
				IniWriter.smethod_11(this.writer);
			}
		}

		// Token: 0x060016A5 RID: 5797 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_0()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060016A6 RID: 5798 RVA: 0x00016261 File Offset: 0x00014461
		static StringWriter smethod_1(IFormatProvider iformatProvider_0)
		{
			return new StringWriter(iformatProvider_0);
		}

		// Token: 0x060016A7 RID: 5799 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_2(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x060016A8 RID: 5800 RVA: 0x000146E8 File Offset: 0x000128E8
		static void smethod_3(TextWriter textWriter_0, string string_0)
		{
			textWriter_0.Write(string_0);
		}

		// Token: 0x060016A9 RID: 5801 RVA: 0x000146F1 File Offset: 0x000128F1
		static void smethod_4(TextWriter textWriter_0)
		{
			textWriter_0.Flush();
		}

		// Token: 0x060016AA RID: 5802 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_5(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x060016AB RID: 5803 RVA: 0x0000DBC7 File Offset: 0x0000BDC7
		static bool smethod_6(string string_0, string string_1)
		{
			return string_0.Equals(string_1);
		}

		// Token: 0x060016AC RID: 5804 RVA: 0x000100A6 File Offset: 0x0000E2A6
		static string smethod_7(char char_0, int int_0)
		{
			return new string(char_0, int_0);
		}

		// Token: 0x060016AD RID: 5805 RVA: 0x00010764 File Offset: 0x0000E964
		static string smethod_8(object[] object_0)
		{
			return string.Concat(object_0);
		}

		// Token: 0x060016AE RID: 5806 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_9(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060016AF RID: 5807 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_10(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060016B0 RID: 5808 RVA: 0x00016269 File Offset: 0x00014469
		static void smethod_11(TextWriter textWriter_0)
		{
			textWriter_0.WriteLine();
		}

		// Token: 0x060016B1 RID: 5809 RVA: 0x0000DB07 File Offset: 0x0000BD07
		static string[] smethod_12(string string_0, string[] string_1, StringSplitOptions stringSplitOptions_0)
		{
			return string_0.Split(string_1, stringSplitOptions_0);
		}

		// Token: 0x060016B2 RID: 5810 RVA: 0x00016271 File Offset: 0x00014471
		static string smethod_13(object object_0, object object_1, object object_2)
		{
			return object_0 + object_1 + object_2;
		}

		// Token: 0x060016B3 RID: 5811 RVA: 0x0000D4F5 File Offset: 0x0000B6F5
		static void smethod_14(TextWriter textWriter_0, string string_0)
		{
			textWriter_0.WriteLine(string_0);
		}

		// Token: 0x040008EC RID: 2284
		private static readonly string[] NewLines = new string[]
		{
			<Module>.smethod_25<string>(4057262895U),
			<Module>.smethod_27<string>(3511083134U),
			<Module>.smethod_23<string>(235783197U)
		};

		// Token: 0x040008ED RID: 2285
		private readonly IniOptions options;

		// Token: 0x040008EE RID: 2286
		private TextWriter writer;
	}
}
