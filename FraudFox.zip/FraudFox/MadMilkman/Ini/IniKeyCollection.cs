﻿using System;
using System.Collections.Generic;

namespace MadMilkman.Ini
{
	// Token: 0x02000173 RID: 371
	public sealed class IniKeyCollection : IniItemCollection<IniKey>
	{
		// Token: 0x060015DB RID: 5595 RVA: 0x00015C60 File Offset: 0x00013E60
		internal IniKeyCollection(IniFile parentFile, IniSection parentSection, IniDuplication duplication, bool caseSensitive)
			: base(parentFile, parentSection, duplication, caseSensitive)
		{
		}

		// Token: 0x060015DC RID: 5596 RVA: 0x00015C6D File Offset: 0x00013E6D
		public IniKey Add(string name)
		{
			return this.Add(name, null);
		}

		// Token: 0x060015DD RID: 5597 RVA: 0x00015C77 File Offset: 0x00013E77
		public IniKey Add(KeyValuePair<string, string> nameValuePair)
		{
			return this.Add(nameValuePair.Key, nameValuePair.Value);
		}

		// Token: 0x060015DE RID: 5598 RVA: 0x00070538 File Offset: 0x0006E738
		public IniKey Add(string name, string value)
		{
			IniKey iniKey = new IniKey(base.ParentFile, name, value);
			base.Add(iniKey);
			return iniKey;
		}

		// Token: 0x060015DF RID: 5599 RVA: 0x00015C8D File Offset: 0x00013E8D
		public IniKey Insert(int index, string name)
		{
			return this.Insert(index, name, null);
		}

		// Token: 0x060015E0 RID: 5600 RVA: 0x00015C98 File Offset: 0x00013E98
		public IniKey Insert(int index, KeyValuePair<string, string> nameValuePair)
		{
			return this.Insert(index, nameValuePair.Key, nameValuePair.Value);
		}

		// Token: 0x060015E1 RID: 5601 RVA: 0x0007055C File Offset: 0x0006E75C
		public IniKey Insert(int index, string name, string value)
		{
			IniKey iniKey = new IniKey(base.ParentFile, name, value);
			base.Insert(index, iniKey);
			return iniKey;
		}
	}
}
