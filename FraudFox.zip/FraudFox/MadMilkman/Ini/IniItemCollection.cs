﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;

namespace MadMilkman.Ini
{
	// Token: 0x02000171 RID: 369
	[DebuggerTypeProxy(typeof(DebugCollectionViewer<>))]
	[DebuggerDisplay("Count = {Count}")]
	public abstract class IniItemCollection<T> : IList<T>, ICollection<T>, IEnumerable<T>, IEnumerable, IItemNameVerifier where T : IniItem
	{
		// Token: 0x17000331 RID: 817
		// (get) Token: 0x060015B9 RID: 5561 RVA: 0x00015AE0 File Offset: 0x00013CE0
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		protected IniFile ParentFile
		{
			get
			{
				return this.parentFile;
			}
		}

		// Token: 0x17000332 RID: 818
		// (get) Token: 0x060015BA RID: 5562 RVA: 0x00015AE8 File Offset: 0x00013CE8
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal IniItem Owner
		{
			get
			{
				return this.owner;
			}
		}

		// Token: 0x17000333 RID: 819
		// (get) Token: 0x060015BB RID: 5563 RVA: 0x00015AF0 File Offset: 0x00013CF0
		public int Count
		{
			get
			{
				return this.items.Count;
			}
		}

		// Token: 0x060015BC RID: 5564 RVA: 0x00015AFD File Offset: 0x00013CFD
		internal IniItemCollection(IniFile parentFile, IniItem owner, IniDuplication duplication, bool caseSensitive)
		{
			this.caseSensitive = caseSensitive;
			this.duplication = duplication;
			this.parentFile = parentFile;
			this.owner = owner;
			this.items = new List<T>();
		}

		// Token: 0x060015BD RID: 5565 RVA: 0x00015B2D File Offset: 0x00013D2D
		public void Add(T item)
		{
			if (this.VerifyItem(item))
			{
				this.items.Add(item);
			}
		}

		// Token: 0x060015BE RID: 5566 RVA: 0x0007016C File Offset: 0x0006E36C
		public void Clear()
		{
			IEnumerator<T> enumerator = this.items.GetEnumerator();
			try
			{
				while (IniItemCollection<T>.smethod_0(enumerator))
				{
					T t = enumerator.Current;
					t.ParentCollectionCore = null;
				}
			}
			finally
			{
				if (enumerator != null)
				{
					IniItemCollection<T>.smethod_1(enumerator);
				}
			}
			this.items.Clear();
		}

		// Token: 0x060015BF RID: 5567 RVA: 0x00015B49 File Offset: 0x00013D49
		public bool Contains(T item)
		{
			return this.items.Contains(item);
		}

		// Token: 0x060015C0 RID: 5568 RVA: 0x00015B57 File Offset: 0x00013D57
		public bool Contains(string name)
		{
			return this.GetItemIndexByName(name, 0) != -1;
		}

		// Token: 0x060015C1 RID: 5569 RVA: 0x00015B67 File Offset: 0x00013D67
		public void CopyTo(T[] array, int arrayIndex)
		{
			this.items.CopyTo(array, arrayIndex);
		}

		// Token: 0x060015C2 RID: 5570 RVA: 0x00015B76 File Offset: 0x00013D76
		public int IndexOf(T item)
		{
			return this.items.IndexOf(item);
		}

		// Token: 0x060015C3 RID: 5571 RVA: 0x00015B84 File Offset: 0x00013D84
		public int IndexOf(string name)
		{
			return this.GetItemIndexByName(name, 0);
		}

		// Token: 0x060015C4 RID: 5572 RVA: 0x00015B8E File Offset: 0x00013D8E
		public void Insert(int index, T item)
		{
			if (this.VerifyItem(item))
			{
				this.items.Insert(index, item);
			}
		}

		// Token: 0x060015C5 RID: 5573 RVA: 0x00015BAB File Offset: 0x00013DAB
		public bool Remove(T item)
		{
			if (!this.items.Remove(item))
			{
				return false;
			}
			item.ParentCollectionCore = null;
			return true;
		}

		// Token: 0x060015C6 RID: 5574 RVA: 0x000701CC File Offset: 0x0006E3CC
		public bool Remove(string name)
		{
			int itemIndexByName = this.GetItemIndexByName(name, 0);
			if (itemIndexByName == -1)
			{
				return false;
			}
			this.items.RemoveAt(itemIndexByName);
			return true;
		}

		// Token: 0x060015C7 RID: 5575 RVA: 0x000701F8 File Offset: 0x0006E3F8
		public void RemoveAt(int index)
		{
			T t = this.items[index];
			t.ParentCollectionCore = null;
			this.items.RemoveAt(index);
		}

		// Token: 0x17000334 RID: 820
		public T this[int index]
		{
			get
			{
				return this.items[index];
			}
			set
			{
				if (this.VerifyItem(value))
				{
					T t = this.items[index];
					t.ParentCollectionCore = null;
					this.items[index] = value;
				}
			}
		}

		// Token: 0x17000335 RID: 821
		public T this[string name]
		{
			get
			{
				int itemIndexByName = this.GetItemIndexByName(name, 0);
				if (itemIndexByName == -1)
				{
					return default(T);
				}
				return this.items[itemIndexByName];
			}
		}

		// Token: 0x17000336 RID: 822
		public IEnumerable<T> this[params string[] names]
		{
			get
			{
				Dictionary<string, int> returnedNames = new Dictionary<string, int>();
				for (int i = 0; i < names.Length; i++)
				{
					string name = names[i];
					int index;
					if (returnedNames.TryGetValue(name, out index))
					{
						if (index != -1)
						{
							index = this.GetItemIndexByName(name, index + 1);
							returnedNames[name] = index;
						}
					}
					else
					{
						index = this.GetItemIndexByName(name, 0);
						returnedNames.Add(name, index);
					}
					yield return (index != -1) ? this.items[index] : default(T);
				}
				yield break;
			}
		}

		// Token: 0x060015CC RID: 5580 RVA: 0x00015BDA File Offset: 0x00013DDA
		public IEnumerator<T> GetEnumerator()
		{
			return this.items.GetEnumerator();
		}

		// Token: 0x060015CD RID: 5581 RVA: 0x000702C4 File Offset: 0x0006E4C4
		private int GetItemIndexByName(string name, int startIndex = 0)
		{
			IEnumerable<IniItem> enumerable = (IEnumerable<IniItem>)this.items;
			int num = 0;
			IEnumerator<IniItem> enumerator = enumerable.GetEnumerator();
			try
			{
				while (IniItemCollection<T>.smethod_0(enumerator))
				{
					IniItem iniItem = enumerator.Current;
					if (num >= startIndex && IniItemCollection<T>.smethod_2(iniItem.Name, name, this.caseSensitive ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase))
					{
						return num;
					}
					num++;
				}
			}
			finally
			{
				if (enumerator != null)
				{
					IniItemCollection<T>.smethod_1(enumerator);
				}
			}
			return -1;
		}

		// Token: 0x060015CE RID: 5582 RVA: 0x00070344 File Offset: 0x0006E544
		private bool VerifyItem(IniItem item)
		{
			if (item == null)
			{
				throw IniItemCollection<T>.smethod_3(<Module>.smethod_27<string>(4196548275U));
			}
			if (item.ParentFile != this.parentFile)
			{
				throw IniItemCollection<T>.smethod_4();
			}
			if (item.ParentCollectionCore != null)
			{
				throw IniItemCollection<T>.smethod_4();
			}
			if (!this.VerifyItemName(item.Name))
			{
				return false;
			}
			item.ParentCollectionCore = this;
			return true;
		}

		// Token: 0x060015CF RID: 5583 RVA: 0x00015BE7 File Offset: 0x00013DE7
		private bool VerifyItemName(string name)
		{
			return ((IItemNameVerifier)this).VerifyItemName(name);
		}

		// Token: 0x060015D0 RID: 5584 RVA: 0x00015BF0 File Offset: 0x00013DF0
		bool IItemNameVerifier.VerifyItemName(string name)
		{
			if (this.duplication == IniDuplication.Allowed || !this.Contains(name))
			{
				return true;
			}
			if (this.duplication == IniDuplication.Disallowed)
			{
				throw IniItemCollection<T>.smethod_4();
			}
			return false;
		}

		// Token: 0x060015D1 RID: 5585 RVA: 0x00015C15 File Offset: 0x00013E15
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		// Token: 0x17000337 RID: 823
		// (get) Token: 0x060015D2 RID: 5586 RVA: 0x0000C17A File Offset: 0x0000A37A
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		bool ICollection<T>.IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x040008B1 RID: 2225
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly bool caseSensitive;

		// Token: 0x040008B2 RID: 2226
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly IniDuplication duplication;

		// Token: 0x040008B3 RID: 2227
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly IList<T> items;

		// Token: 0x040008B4 RID: 2228
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly IniFile parentFile;

		// Token: 0x040008B5 RID: 2229
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly IniItem owner;
	}
}
