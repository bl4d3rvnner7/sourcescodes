﻿using System;

namespace MadMilkman.Ini
{
	// Token: 0x0200016A RID: 362
	public enum IniCommentStarter
	{
		// Token: 0x0400089C RID: 2204
		Semicolon = 59,
		// Token: 0x0400089D RID: 2205
		Hash = 35
	}
}
