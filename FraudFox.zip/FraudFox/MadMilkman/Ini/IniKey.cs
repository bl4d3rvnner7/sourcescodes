﻿using System;
using System.Collections.Generic;

namespace MadMilkman.Ini
{
	// Token: 0x02000176 RID: 374
	public sealed class IniKey : IniItem
	{
		// Token: 0x17000345 RID: 837
		// (get) Token: 0x060015F9 RID: 5625 RVA: 0x00015DCA File Offset: 0x00013FCA
		// (set) Token: 0x060015FA RID: 5626 RVA: 0x00015DD2 File Offset: 0x00013FD2
		public string Value { get; set; }

		// Token: 0x17000346 RID: 838
		// (get) Token: 0x060015FB RID: 5627 RVA: 0x00015DDB File Offset: 0x00013FDB
		public IniKeyCollection ParentCollection
		{
			get
			{
				return (IniKeyCollection)base.ParentCollectionCore;
			}
		}

		// Token: 0x17000347 RID: 839
		// (get) Token: 0x060015FC RID: 5628 RVA: 0x00015DE8 File Offset: 0x00013FE8
		public IniSection ParentSection
		{
			get
			{
				return (IniSection)((base.ParentCollectionCore != null) ? this.ParentCollection.Owner : null);
			}
		}

		// Token: 0x17000348 RID: 840
		// (get) Token: 0x060015FD RID: 5629 RVA: 0x00015E05 File Offset: 0x00014005
		internal bool IsValueArray
		{
			get
			{
				return !IniKey.smethod_1(this.Value) && IniKey.smethod_2(this.Value, 0) == '{' && IniKey.smethod_2(this.Value, IniKey.smethod_3(this.Value) - 1) == '}';
			}
		}

		// Token: 0x17000349 RID: 841
		// (get) Token: 0x060015FE RID: 5630 RVA: 0x000706B0 File Offset: 0x0006E8B0
		// (set) Token: 0x060015FF RID: 5631 RVA: 0x00015E42 File Offset: 0x00014042
		internal string[] Values
		{
			get
			{
				string[] array = IniKey.smethod_5(IniKey.smethod_4(this.Value, 1, IniKey.smethod_3(this.Value) - 2), new char[] { ',' });
				for (;;)
				{
					IL_007A:
					int num = -492796163;
					for (;;)
					{
						int num2;
						switch (num ^ -492796164)
						{
						case 0:
							goto IL_0055;
						case 1:
							num2 = 0;
							num = -492796164;
							continue;
						case 2:
							goto IL_007A;
						case 3:
							break;
						default:
							goto IL_0055;
						}
						IL_002E:
						array[num2] = IniKey.smethod_6(array[num2]);
						num2++;
						num = -492796164;
						continue;
						IL_0055:
						if (num2 >= array.Length)
						{
							return array;
						}
						goto IL_002E;
					}
				}
				return array;
			}
			set
			{
				this.Value = IniKey.smethod_8(<Module>.smethod_25<string>(2085947603U), IniKey.smethod_7(<Module>.smethod_25<string>(1273292060U), value), <Module>.smethod_25<string>(2642727227U));
			}
		}

		// Token: 0x06001600 RID: 5632 RVA: 0x00015E73 File Offset: 0x00014073
		public IniKey(IniFile parentFile, string name)
			: this(parentFile, name, null)
		{
		}

		// Token: 0x06001601 RID: 5633 RVA: 0x00015E7E File Offset: 0x0001407E
		public IniKey(IniFile parentFile, string name, string value)
			: base(parentFile, name, null)
		{
			this.Value = value;
		}

		// Token: 0x06001602 RID: 5634 RVA: 0x00015E90 File Offset: 0x00014090
		public IniKey(IniFile parentFile, KeyValuePair<string, string> nameValuePair)
			: base(parentFile, nameValuePair.Key, null)
		{
			this.Value = nameValuePair.Value;
		}

		// Token: 0x06001603 RID: 5635 RVA: 0x00015EAE File Offset: 0x000140AE
		internal IniKey(IniFile parentFile, string name, IniComment trailingComment)
			: base(parentFile, name, trailingComment)
		{
		}

		// Token: 0x06001604 RID: 5636 RVA: 0x00015EB9 File Offset: 0x000140B9
		internal IniKey(IniFile destinationFile, IniKey sourceKey)
			: base(destinationFile, sourceKey)
		{
			this.Value = sourceKey.Value;
		}

		// Token: 0x06001605 RID: 5637 RVA: 0x00015ECF File Offset: 0x000140CF
		public IniKey Copy()
		{
			return this.Copy(base.ParentFile);
		}

		// Token: 0x06001606 RID: 5638 RVA: 0x00015EDD File Offset: 0x000140DD
		public IniKey Copy(IniFile destinationFile)
		{
			return new IniKey(destinationFile, this);
		}

		// Token: 0x06001607 RID: 5639 RVA: 0x00070740 File Offset: 0x0006E940
		public static bool IsSupportedValueType(Type type)
		{
			if (type == null)
			{
				throw IniKey.smethod_9(<Module>.smethod_23<string>(2780933721U));
			}
			return IniKey.smethod_10(type) || IniKey.smethod_11(type) || type == IniKey.smethod_12(typeof(string).TypeHandle) || type == IniKey.smethod_12(typeof(decimal).TypeHandle) || type == IniKey.smethod_12(typeof(DateTime).TypeHandle) || type == IniKey.smethod_12(typeof(TimeSpan).TypeHandle) || (IniKey.smethod_13(type) && IniKey.IsSupportedValueType(IniKey.smethod_14(type))) || (IniKey.smethod_15(type) && IniKey.smethod_16(type) == IniKey.smethod_12(typeof(List<>).TypeHandle) && IniKey.IsSupportedValueType(IniKey.smethod_17(type)[0]));
		}

		// Token: 0x06001608 RID: 5640 RVA: 0x00015EE6 File Offset: 0x000140E6
		public bool TryParseValue<T>(out T result)
		{
			return (base.ParentFile.HasValueMappings && base.ParentFile.ValueMappings.TryGetResult<T>(this.Value, out result)) || IniValueParser<T>.TryParse(this.Value, out result);
		}

		// Token: 0x06001609 RID: 5641 RVA: 0x000707E8 File Offset: 0x0006E9E8
		public bool TryParseValue<T>(out T[] results)
		{
			List<T> list;
			if (this.TryParseValue<T>(out list))
			{
				results = list.ToArray();
				return true;
			}
			results = null;
			return false;
		}

		// Token: 0x0600160A RID: 5642 RVA: 0x00070810 File Offset: 0x0006EA10
		public bool TryParseValue<T>(out List<T> results)
		{
			if (this.IsValueArray)
			{
				List<T> list = new List<T>();
				foreach (string text in this.Values)
				{
					T t;
					if (base.ParentFile.HasValueMappings && base.ParentFile.ValueMappings.TryGetResult<T>(text, out t))
					{
						list.Add(t);
					}
					else
					{
						if (!IniValueParser<T>.TryParse(text, out t))
						{
							results = null;
							return false;
						}
						list.Add(t);
					}
				}
				results = list;
				return true;
			}
			results = null;
			return false;
		}

		// Token: 0x0600160B RID: 5643 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_1(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x0600160C RID: 5644 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_2(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x0600160D RID: 5645 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_3(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x0600160E RID: 5646 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_4(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x0600160F RID: 5647 RVA: 0x0000C693 File Offset: 0x0000A893
		static string[] smethod_5(string string_0, char[] char_0)
		{
			return string_0.Split(char_0);
		}

		// Token: 0x06001610 RID: 5648 RVA: 0x0000C6B8 File Offset: 0x0000A8B8
		static string smethod_6(string string_0)
		{
			return string_0.Trim();
		}

		// Token: 0x06001611 RID: 5649 RVA: 0x0000DAF6 File Offset: 0x0000BCF6
		static string smethod_7(string string_0, string[] string_1)
		{
			return string.Join(string_0, string_1);
		}

		// Token: 0x06001612 RID: 5650 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_8(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x06001613 RID: 5651 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_9(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x06001614 RID: 5652 RVA: 0x00015F1C File Offset: 0x0001411C
		static bool smethod_10(Type type_0)
		{
			return type_0.IsPrimitive;
		}

		// Token: 0x06001615 RID: 5653 RVA: 0x00015F24 File Offset: 0x00014124
		static bool smethod_11(Type type_0)
		{
			return type_0.IsEnum;
		}

		// Token: 0x06001616 RID: 5654 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_12(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001617 RID: 5655 RVA: 0x00015F2C File Offset: 0x0001412C
		static bool smethod_13(Type type_0)
		{
			return type_0.IsArray;
		}

		// Token: 0x06001618 RID: 5656 RVA: 0x00015F34 File Offset: 0x00014134
		static Type smethod_14(Type type_0)
		{
			return type_0.GetElementType();
		}

		// Token: 0x06001619 RID: 5657 RVA: 0x00015F3C File Offset: 0x0001413C
		static bool smethod_15(Type type_0)
		{
			return type_0.IsGenericType;
		}

		// Token: 0x0600161A RID: 5658 RVA: 0x00015F44 File Offset: 0x00014144
		static Type smethod_16(Type type_0)
		{
			return type_0.GetGenericTypeDefinition();
		}

		// Token: 0x0600161B RID: 5659 RVA: 0x00015F4C File Offset: 0x0001414C
		static Type[] smethod_17(Type type_0)
		{
			return type_0.GetGenericArguments();
		}
	}
}
