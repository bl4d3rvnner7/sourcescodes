﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;

namespace MadMilkman.Ini
{
	// Token: 0x0200017C RID: 380
	internal static class IniEncryptor
	{
		// Token: 0x06001669 RID: 5737 RVA: 0x00070DB8 File Offset: 0x0006EFB8
		public static string Encrypt(string text, string passwordPhrase, Encoding encoding)
		{
			byte[] array = IniEncryptor.smethod_0(encoding, text);
			byte[] array2 = IniEncryptor.smethod_2(IniEncryptor.smethod_1(passwordPhrase, IniEncryptor.Salt, 1000), 32);
			MemoryStream memoryStream = IniEncryptor.smethod_3();
			RijndaelManaged rijndaelManaged = IniEncryptor.smethod_4();
			try
			{
				ICryptoTransform cryptoTransform = IniEncryptor.smethod_5(rijndaelManaged, array2, IniEncryptor.InitializationVector);
				try
				{
					CryptoStream cryptoStream = IniEncryptor.smethod_6(memoryStream, cryptoTransform, CryptoStreamMode.Write);
					try
					{
						IniEncryptor.smethod_7(cryptoStream, array, 0, array.Length);
					}
					finally
					{
						if (cryptoStream != null)
						{
							IniEncryptor.smethod_8(cryptoStream);
						}
					}
				}
				finally
				{
					if (cryptoTransform != null)
					{
						IniEncryptor.smethod_8(cryptoTransform);
					}
				}
			}
			finally
			{
				if (rijndaelManaged != null)
				{
					IniEncryptor.smethod_8(rijndaelManaged);
				}
			}
			return IniEncryptor.smethod_10(IniEncryptor.smethod_9(memoryStream));
		}

		// Token: 0x0600166A RID: 5738 RVA: 0x00070E74 File Offset: 0x0006F074
		public static string Decrypt(string text, string passwordPhrase, Encoding encoding)
		{
			byte[] array = IniEncryptor.smethod_11(text);
			byte[] array2 = IniEncryptor.smethod_2(IniEncryptor.smethod_1(passwordPhrase, IniEncryptor.Salt, 1000), 32);
			byte[] array3 = new byte[array.Length];
			RijndaelManaged rijndaelManaged = IniEncryptor.smethod_4();
			int num;
			try
			{
				ICryptoTransform cryptoTransform = IniEncryptor.smethod_12(rijndaelManaged, array2, IniEncryptor.InitializationVector);
				try
				{
					CryptoStream cryptoStream = IniEncryptor.smethod_6(IniEncryptor.smethod_13(array), cryptoTransform, CryptoStreamMode.Read);
					try
					{
						num = IniEncryptor.smethod_14(cryptoStream, array3, 0, array3.Length);
					}
					finally
					{
						if (cryptoStream != null)
						{
							IniEncryptor.smethod_8(cryptoStream);
						}
					}
				}
				finally
				{
					if (cryptoTransform != null)
					{
						IniEncryptor.smethod_8(cryptoTransform);
					}
				}
			}
			finally
			{
				if (rijndaelManaged != null)
				{
					IniEncryptor.smethod_8(rijndaelManaged);
				}
			}
			return IniEncryptor.smethod_15(encoding, array3, 0, num);
		}

		// Token: 0x0600166B RID: 5739 RVA: 0x00016155 File Offset: 0x00014355
		// Note: this type is marked as 'beforefieldinit'.
		static IniEncryptor()
		{
			byte[] array = new byte[16];
			IniEncryptor.smethod_16(array, fieldof(<PrivateImplementationDetails>{0CA23524-EC89-4460-8619-D6B680A934A9}.$$method0x60000d7-1).FieldHandle);
			IniEncryptor.InitializationVector = array;
			byte[] array2 = new byte[20];
			IniEncryptor.smethod_16(array2, fieldof(<PrivateImplementationDetails>{0CA23524-EC89-4460-8619-D6B680A934A9}.$$method0x60000d7-2).FieldHandle);
			IniEncryptor.Salt = array2;
		}

		// Token: 0x0600166C RID: 5740 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_0(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x0600166D RID: 5741 RVA: 0x000131A3 File Offset: 0x000113A3
		static Rfc2898DeriveBytes smethod_1(string string_0, byte[] byte_0, int int_0)
		{
			return new Rfc2898DeriveBytes(string_0, byte_0, int_0);
		}

		// Token: 0x0600166E RID: 5742 RVA: 0x000131AD File Offset: 0x000113AD
		static byte[] smethod_2(DeriveBytes deriveBytes_0, int int_0)
		{
			return deriveBytes_0.GetBytes(int_0);
		}

		// Token: 0x0600166F RID: 5743 RVA: 0x0000C8A7 File Offset: 0x0000AAA7
		static MemoryStream smethod_3()
		{
			return new MemoryStream();
		}

		// Token: 0x06001670 RID: 5744 RVA: 0x0000C83A File Offset: 0x0000AA3A
		static RijndaelManaged smethod_4()
		{
			return new RijndaelManaged();
		}

		// Token: 0x06001671 RID: 5745 RVA: 0x0000C89D File Offset: 0x0000AA9D
		static ICryptoTransform smethod_5(SymmetricAlgorithm symmetricAlgorithm_0, byte[] byte_0, byte[] byte_1)
		{
			return symmetricAlgorithm_0.CreateEncryptor(byte_0, byte_1);
		}

		// Token: 0x06001672 RID: 5746 RVA: 0x0000C87F File Offset: 0x0000AA7F
		static CryptoStream smethod_6(Stream stream_0, ICryptoTransform icryptoTransform_0, CryptoStreamMode cryptoStreamMode_0)
		{
			return new CryptoStream(stream_0, icryptoTransform_0, cryptoStreamMode_0);
		}

		// Token: 0x06001673 RID: 5747 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_7(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x06001674 RID: 5748 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_8(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06001675 RID: 5749 RVA: 0x0000C8C1 File Offset: 0x0000AAC1
		static byte[] smethod_9(MemoryStream memoryStream_0)
		{
			return memoryStream_0.ToArray();
		}

		// Token: 0x06001676 RID: 5750 RVA: 0x0000C8C9 File Offset: 0x0000AAC9
		static string smethod_10(byte[] byte_0)
		{
			return Convert.ToBase64String(byte_0);
		}

		// Token: 0x06001677 RID: 5751 RVA: 0x0000C86F File Offset: 0x0000AA6F
		static byte[] smethod_11(string string_0)
		{
			return Convert.FromBase64String(string_0);
		}

		// Token: 0x06001678 RID: 5752 RVA: 0x0000C865 File Offset: 0x0000AA65
		static ICryptoTransform smethod_12(SymmetricAlgorithm symmetricAlgorithm_0, byte[] byte_0, byte[] byte_1)
		{
			return symmetricAlgorithm_0.CreateDecryptor(byte_0, byte_1);
		}

		// Token: 0x06001679 RID: 5753 RVA: 0x0000C877 File Offset: 0x0000AA77
		static MemoryStream smethod_13(byte[] byte_0)
		{
			return new MemoryStream(byte_0);
		}

		// Token: 0x0600167A RID: 5754 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_14(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x0600167B RID: 5755 RVA: 0x0000DF79 File Offset: 0x0000C179
		static string smethod_15(Encoding encoding_0, byte[] byte_0, int int_0, int int_1)
		{
			return encoding_0.GetString(byte_0, int_0, int_1);
		}

		// Token: 0x0600167C RID: 5756 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_16(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x040008E3 RID: 2275
		private static readonly byte[] InitializationVector;

		// Token: 0x040008E4 RID: 2276
		private static readonly byte[] Salt;
	}
}
