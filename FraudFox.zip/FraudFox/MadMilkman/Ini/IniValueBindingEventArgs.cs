﻿using System;
using System.Diagnostics;

namespace MadMilkman.Ini
{
	// Token: 0x02000184 RID: 388
	public sealed class IniValueBindingEventArgs : EventArgs
	{
		// Token: 0x1700035F RID: 863
		// (get) Token: 0x06001711 RID: 5905 RVA: 0x00016492 File Offset: 0x00014692
		public string PlaceholderName
		{
			get
			{
				return this.placeholderName;
			}
		}

		// Token: 0x17000360 RID: 864
		// (get) Token: 0x06001712 RID: 5906 RVA: 0x0001649A File Offset: 0x0001469A
		public IniKey PlaceholderKey
		{
			get
			{
				return this.placeholderKey;
			}
		}

		// Token: 0x17000361 RID: 865
		// (get) Token: 0x06001713 RID: 5907 RVA: 0x000164A2 File Offset: 0x000146A2
		// (set) Token: 0x06001714 RID: 5908 RVA: 0x000164AA File Offset: 0x000146AA
		public string Value { get; set; }

		// Token: 0x17000362 RID: 866
		// (get) Token: 0x06001715 RID: 5909 RVA: 0x000164B3 File Offset: 0x000146B3
		public bool IsValueFound
		{
			get
			{
				return this.isValueFound;
			}
		}

		// Token: 0x06001716 RID: 5910 RVA: 0x000134DD File Offset: 0x000116DD
		internal IniValueBindingEventArgs()
		{
		}

		// Token: 0x06001717 RID: 5911 RVA: 0x000164BB File Offset: 0x000146BB
		internal void Initialize(string placeholderName, IniKey placeholderKey, string value, bool isValueFound)
		{
			this.placeholderName = placeholderName;
			this.placeholderKey = placeholderKey;
			this.Value = value;
			this.isValueFound = isValueFound;
		}

		// Token: 0x06001718 RID: 5912 RVA: 0x000164DA File Offset: 0x000146DA
		internal void Reset()
		{
			this.Initialize(null, null, null, false);
		}

		// Token: 0x04000910 RID: 2320
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string placeholderName;

		// Token: 0x04000911 RID: 2321
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private IniKey placeholderKey;

		// Token: 0x04000912 RID: 2322
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool isValueFound;
	}
}
