﻿using System;
using System.Diagnostics;

namespace MadMilkman.Ini
{
	// Token: 0x02000174 RID: 372
	[DebuggerDisplay("Text = {Text}")]
	public sealed class IniComment
	{
		// Token: 0x1700033A RID: 826
		// (get) Token: 0x060015E2 RID: 5602 RVA: 0x00015CAF File Offset: 0x00013EAF
		// (set) Token: 0x060015E3 RID: 5603 RVA: 0x00015CB7 File Offset: 0x00013EB7
		public int EmptyLinesBefore { get; set; }

		// Token: 0x1700033B RID: 827
		// (get) Token: 0x060015E4 RID: 5604 RVA: 0x00015CC0 File Offset: 0x00013EC0
		// (set) Token: 0x060015E5 RID: 5605 RVA: 0x00015CC8 File Offset: 0x00013EC8
		public int LeftIndentation { get; set; }

		// Token: 0x1700033C RID: 828
		// (get) Token: 0x060015E6 RID: 5606 RVA: 0x00015CD1 File Offset: 0x00013ED1
		// (set) Token: 0x060015E7 RID: 5607 RVA: 0x00070580 File Offset: 0x0006E780
		public string Text
		{
			get
			{
				return this.text;
			}
			set
			{
				if (value != null && this.type == IniCommentType.Leading)
				{
					this.text = IniComment.smethod_0(IniComment.smethod_0(IniComment.smethod_0(value, <Module>.smethod_25<string>(4057262895U), <Module>.smethod_24<string>(2570929253U)), <Module>.smethod_25<string>(3918067989U), <Module>.smethod_24<string>(2570929253U)), <Module>.smethod_27<string>(3335690069U), <Module>.smethod_26<string>(2342675128U));
					return;
				}
				this.text = value;
			}
		}

		// Token: 0x060015E8 RID: 5608 RVA: 0x00015CD9 File Offset: 0x00013ED9
		internal IniComment(IniCommentType type)
		{
			this.type = type;
		}

		// Token: 0x060015E9 RID: 5609 RVA: 0x00015CE8 File Offset: 0x00013EE8
		internal IniComment(IniComment source)
		{
			this.text = source.text;
			this.type = source.type;
			this.EmptyLinesBefore = source.EmptyLinesBefore;
			this.LeftIndentation = source.LeftIndentation;
		}

		// Token: 0x060015EA RID: 5610 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_0(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x040008C0 RID: 2240
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string text;

		// Token: 0x040008C1 RID: 2241
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly IniCommentType type;
	}
}
