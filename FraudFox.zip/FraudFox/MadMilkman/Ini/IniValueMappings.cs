﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace MadMilkman.Ini
{
	// Token: 0x02000185 RID: 389
	public sealed class IniValueMappings
	{
		// Token: 0x06001719 RID: 5913 RVA: 0x000164E6 File Offset: 0x000146E6
		internal IniValueMappings()
		{
			this.mappings = new Dictionary<string, object>(IniValueMappings.smethod_0());
		}

		// Token: 0x0600171A RID: 5914 RVA: 0x000723E4 File Offset: 0x000705E4
		public void Add<T>(string value, T mappedResult)
		{
			if (value == null)
			{
				throw IniValueMappings.smethod_1(<Module>.smethod_27<string>(2371252898U));
			}
			if (this.Contains(value) || !IniValueMappings.MappedTypeVerifier(IniValueMappings.smethod_2(typeof(T).TypeHandle)))
			{
				throw IniValueMappings.smethod_3();
			}
			this.mappings.Add(value, mappedResult);
		}

		// Token: 0x0600171B RID: 5915 RVA: 0x000164FE File Offset: 0x000146FE
		public bool Contains(string value)
		{
			return this.mappings.ContainsKey(value);
		}

		// Token: 0x0600171C RID: 5916 RVA: 0x0001650C File Offset: 0x0001470C
		public bool Remove(string value)
		{
			return this.mappings.Remove(value);
		}

		// Token: 0x0600171D RID: 5917 RVA: 0x0007243C File Offset: 0x0007063C
		internal bool TryGetResult<T>(string value, out T result)
		{
			object obj;
			if (!IniValueMappings.smethod_4(value) && this.mappings.TryGetValue(value, out obj) && IniValueMappings.smethod_5(obj) == IniValueMappings.smethod_2(typeof(T).TypeHandle))
			{
				result = (T)((object)obj);
				return true;
			}
			result = default(T);
			return false;
		}

		// Token: 0x0600171F RID: 5919 RVA: 0x00014724 File Offset: 0x00012924
		static StringComparer smethod_0()
		{
			return StringComparer.OrdinalIgnoreCase;
		}

		// Token: 0x06001720 RID: 5920 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_1(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x06001721 RID: 5921 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_2(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001722 RID: 5922 RVA: 0x0000C331 File Offset: 0x0000A531
		static InvalidOperationException smethod_3()
		{
			return new InvalidOperationException();
		}

		// Token: 0x06001723 RID: 5923 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_4(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06001724 RID: 5924 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_5(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x04000914 RID: 2324
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private static readonly Predicate<Type> MappedTypeVerifier = new Predicate<Type>(IniKey.IsSupportedValueType);

		// Token: 0x04000915 RID: 2325
		private readonly IDictionary<string, object> mappings;
	}
}
