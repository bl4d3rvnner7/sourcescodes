﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace MadMilkman.Ini
{
	// Token: 0x02000169 RID: 361
	internal sealed class DebugCollectionViewer<T>
	{
		// Token: 0x060015A2 RID: 5538 RVA: 0x0006FF94 File Offset: 0x0006E194
		public DebugCollectionViewer(IEnumerable<T> sequence)
		{
			for (;;)
			{
				IL_0038:
				int num = -153386664;
				for (;;)
				{
					switch (num ^ -153386663)
					{
					case 0:
						goto IL_0038;
					case 1:
						if (sequence == null)
						{
							goto Block_1;
						}
						goto IL_0008;
					case 3:
						goto IL_0008;
					}
					return;
					IL_0008:
					this.sequence = sequence;
					num = -153386661;
				}
			}
			Block_1:
			throw DebugCollectionViewer<T>.smethod_0(<Module>.smethod_25<string>(648607182U));
		}

		// Token: 0x1700032C RID: 812
		// (get) Token: 0x060015A3 RID: 5539 RVA: 0x0006FFF0 File Offset: 0x0006E1F0
		[DebuggerBrowsable(DebuggerBrowsableState.RootHidden)]
		public T[] Items
		{
			get
			{
				ICollection<T> collection = (this.sequence as ICollection<T>) ?? new List<T>(this.sequence);
				T[] array = new T[collection.Count];
				collection.CopyTo(array, 0);
				return array;
			}
		}

		// Token: 0x0400089A RID: 2202
		private readonly IEnumerable<T> sequence;
	}
}
