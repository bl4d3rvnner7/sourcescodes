﻿using System;

namespace MadMilkman.Ini
{
	// Token: 0x0200016D RID: 365
	public enum IniKeyDelimiter
	{
		// Token: 0x040008A6 RID: 2214
		Equal = 61,
		// Token: 0x040008A7 RID: 2215
		Colon = 58
	}
}
