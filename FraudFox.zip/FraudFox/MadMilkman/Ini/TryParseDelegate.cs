﻿using System;

namespace MadMilkman.Ini
{
	// Token: 0x02000186 RID: 390
	// (Invoke) Token: 0x06001726 RID: 5926
	internal delegate bool TryParseDelegate<TDelegate>(string value, out TDelegate result);
}
