﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;

namespace MadMilkman.Ini
{
	// Token: 0x02000177 RID: 375
	public sealed class IniSection : IniItem
	{
		// Token: 0x1700034A RID: 842
		// (get) Token: 0x0600161C RID: 5660 RVA: 0x00015F54 File Offset: 0x00014154
		public IniKeyCollection Keys
		{
			get
			{
				return this.keys;
			}
		}

		// Token: 0x1700034B RID: 843
		// (get) Token: 0x0600161D RID: 5661 RVA: 0x00015F5C File Offset: 0x0001415C
		public IniSectionCollection ParentCollection
		{
			get
			{
				return (IniSectionCollection)base.ParentCollectionCore;
			}
		}

		// Token: 0x0600161E RID: 5662 RVA: 0x00015F69 File Offset: 0x00014169
		public IniSection(IniFile parentFile, string name)
			: this(parentFile, name, null)
		{
		}

		// Token: 0x0600161F RID: 5663 RVA: 0x00015F74 File Offset: 0x00014174
		public IniSection(IniFile parentFile, string name, params IniKey[] keys)
			: this(parentFile, name, (IEnumerable<IniKey>)keys)
		{
		}

		// Token: 0x06001620 RID: 5664 RVA: 0x00015F84 File Offset: 0x00014184
		public IniSection(IniFile parentFile, string name, IEnumerable<KeyValuePair<string, string>> nameValuePairs)
			: this(parentFile, name, IniSection.GetIniKeysFromKeyValuePairs(parentFile, nameValuePairs))
		{
		}

		// Token: 0x06001621 RID: 5665 RVA: 0x0007089C File Offset: 0x0006EA9C
		public IniSection(IniFile parentFile, string name, IEnumerable<IniKey> keys)
			: base(parentFile, name, null)
		{
			this.keys = new IniKeyCollection(parentFile, this, parentFile.options.KeyDuplicate, parentFile.options.KeyNameCaseSensitive);
			if (keys != null)
			{
				IEnumerator<IniKey> enumerator = keys.GetEnumerator();
				try
				{
					while (IniSection.smethod_1(enumerator))
					{
						IniKey iniKey = enumerator.Current;
						this.keys.Add(iniKey);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						IniSection.smethod_2(enumerator);
					}
				}
			}
		}

		// Token: 0x06001622 RID: 5666 RVA: 0x00015F95 File Offset: 0x00014195
		internal IniSection(IniFile parentFile, string name, IniComment trailingComment)
			: base(parentFile, name, trailingComment)
		{
			this.keys = new IniKeyCollection(parentFile, this, parentFile.options.KeyDuplicate, parentFile.options.KeyNameCaseSensitive);
		}

		// Token: 0x06001623 RID: 5667 RVA: 0x0007091C File Offset: 0x0006EB1C
		internal IniSection(IniFile destinationFile, IniSection sourceSection)
			: base(destinationFile, sourceSection)
		{
			this.keys = new IniKeyCollection(destinationFile, this, destinationFile.options.KeyDuplicate, destinationFile.options.KeyNameCaseSensitive);
			IEnumerator<IniKey> enumerator = sourceSection.keys.GetEnumerator();
			try
			{
				while (IniSection.smethod_1(enumerator))
				{
					IniKey iniKey = enumerator.Current;
					this.keys.Add(iniKey.Copy(destinationFile));
				}
			}
			finally
			{
				if (enumerator != null)
				{
					IniSection.smethod_2(enumerator);
				}
			}
		}

		// Token: 0x06001624 RID: 5668 RVA: 0x00015FC3 File Offset: 0x000141C3
		public IniSection Copy()
		{
			return this.Copy(base.ParentFile);
		}

		// Token: 0x06001625 RID: 5669 RVA: 0x00015FD1 File Offset: 0x000141D1
		public IniSection Copy(IniFile destinationFile)
		{
			return new IniSection(destinationFile, this);
		}

		// Token: 0x06001626 RID: 5670 RVA: 0x00015FDA File Offset: 0x000141DA
		public void Serialize<T>(T source) where T : class, new()
		{
			IniSerializer.Serialize<T>(source, this);
		}

		// Token: 0x06001627 RID: 5671 RVA: 0x00015FE3 File Offset: 0x000141E3
		public T Deserialize<T>() where T : class, new()
		{
			return IniSerializer.Deserialize<T>(this);
		}

		// Token: 0x06001628 RID: 5672 RVA: 0x000709A0 File Offset: 0x0006EBA0
		private static IEnumerable<IniKey> GetIniKeysFromKeyValuePairs(IniFile parentFile, IEnumerable<KeyValuePair<string, string>> nameValuePairs)
		{
			if (nameValuePairs != null)
			{
				IEnumerator<KeyValuePair<string, string>> enumerator = nameValuePairs.GetEnumerator();
				try
				{
					while (IniSection.<GetIniKeysFromKeyValuePairs>d__0.smethod_2(enumerator))
					{
						KeyValuePair<string, string> pair = enumerator.Current;
						yield return new IniKey(parentFile, pair);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						IniSection.<GetIniKeysFromKeyValuePairs>d__0.smethod_4(enumerator);
					}
				}
			}
			yield break;
		}

		// Token: 0x06001629 RID: 5673 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_1(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x0600162A RID: 5674 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_2(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x040008CB RID: 2251
		public const string GlobalSectionName = "MADMILKMAN_INI_FILE_GLOBAL_SECTION";

		// Token: 0x040008CC RID: 2252
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly IniKeyCollection keys;
	}
}
