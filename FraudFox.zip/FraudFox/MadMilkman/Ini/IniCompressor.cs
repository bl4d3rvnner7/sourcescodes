﻿using System;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace MadMilkman.Ini
{
	// Token: 0x0200017B RID: 379
	internal static class IniCompressor
	{
		// Token: 0x06001658 RID: 5720 RVA: 0x00070CA8 File Offset: 0x0006EEA8
		public static string Compress(string text, Encoding encoding)
		{
			byte[] array = IniCompressor.smethod_0(encoding, text);
			MemoryStream memoryStream = IniCompressor.smethod_1();
			GZipStream gzipStream = IniCompressor.smethod_2(memoryStream, CompressionMode.Compress, true);
			try
			{
				IniCompressor.smethod_3(gzipStream, array, 0, array.Length);
			}
			finally
			{
				if (gzipStream != null)
				{
					IniCompressor.smethod_4(gzipStream);
				}
			}
			byte[] array2 = new byte[IniCompressor.smethod_5(memoryStream) + 4L];
			IniCompressor.smethod_6(memoryStream, 0L);
			IniCompressor.smethod_7(memoryStream, array2, 4, array2.Length - 4);
			IniCompressor.smethod_9(IniCompressor.smethod_8(array.Length), 0, array2, 0, 4);
			return IniCompressor.smethod_10(array2);
		}

		// Token: 0x06001659 RID: 5721 RVA: 0x00070D40 File Offset: 0x0006EF40
		public static string Decompress(string text, Encoding encoding)
		{
			byte[] array = IniCompressor.smethod_11(text);
			MemoryStream memoryStream = IniCompressor.smethod_12(array, 4, array.Length - 4);
			byte[] array2 = new byte[IniCompressor.smethod_13(array, 0)];
			IniCompressor.smethod_6(memoryStream, 0L);
			GZipStream gzipStream = IniCompressor.smethod_2(memoryStream, CompressionMode.Decompress, false);
			try
			{
				IniCompressor.smethod_7(gzipStream, array2, 0, array2.Length);
			}
			finally
			{
				if (gzipStream != null)
				{
					IniCompressor.smethod_4(gzipStream);
				}
			}
			return IniCompressor.smethod_14(encoding, array2);
		}

		// Token: 0x0600165A RID: 5722 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_0(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x0600165B RID: 5723 RVA: 0x0000C8A7 File Offset: 0x0000AAA7
		static MemoryStream smethod_1()
		{
			return new MemoryStream();
		}

		// Token: 0x0600165C RID: 5724 RVA: 0x00016141 File Offset: 0x00014341
		static GZipStream smethod_2(Stream stream_0, CompressionMode compressionMode_0, bool bool_0)
		{
			return new GZipStream(stream_0, compressionMode_0, bool_0);
		}

		// Token: 0x0600165D RID: 5725 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_3(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x0600165E RID: 5726 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_4(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x0600165F RID: 5727 RVA: 0x00012BE5 File Offset: 0x00010DE5
		static long smethod_5(Stream stream_0)
		{
			return stream_0.Length;
		}

		// Token: 0x06001660 RID: 5728 RVA: 0x00012D96 File Offset: 0x00010F96
		static void smethod_6(Stream stream_0, long long_0)
		{
			stream_0.Position = long_0;
		}

		// Token: 0x06001661 RID: 5729 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_7(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06001662 RID: 5730 RVA: 0x00012D75 File Offset: 0x00010F75
		static byte[] smethod_8(int int_0)
		{
			return BitConverter.GetBytes(int_0);
		}

		// Token: 0x06001663 RID: 5731 RVA: 0x00013254 File Offset: 0x00011454
		static void smethod_9(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Buffer.BlockCopy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x06001664 RID: 5732 RVA: 0x0000C8C9 File Offset: 0x0000AAC9
		static string smethod_10(byte[] byte_0)
		{
			return Convert.ToBase64String(byte_0);
		}

		// Token: 0x06001665 RID: 5733 RVA: 0x0000C86F File Offset: 0x0000AA6F
		static byte[] smethod_11(string string_0)
		{
			return Convert.FromBase64String(string_0);
		}

		// Token: 0x06001666 RID: 5734 RVA: 0x0001614B File Offset: 0x0001434B
		static MemoryStream smethod_12(byte[] byte_0, int int_0, int int_1)
		{
			return new MemoryStream(byte_0, int_0, int_1);
		}

		// Token: 0x06001667 RID: 5735 RVA: 0x00013E9E File Offset: 0x0001209E
		static int smethod_13(byte[] byte_0, int int_0)
		{
			return BitConverter.ToInt32(byte_0, int_0);
		}

		// Token: 0x06001668 RID: 5736 RVA: 0x0000C894 File Offset: 0x0000AA94
		static string smethod_14(Encoding encoding_0, byte[] byte_0)
		{
			return encoding_0.GetString(byte_0);
		}
	}
}
