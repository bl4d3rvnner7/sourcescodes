﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace MadMilkman.Ini
{
	// Token: 0x0200016F RID: 367
	public sealed class IniFile
	{
		// Token: 0x060015A4 RID: 5540 RVA: 0x000159F1 File Offset: 0x00013BF1
		public IniFile()
			: this(new IniOptions())
		{
		}

		// Token: 0x060015A5 RID: 5541 RVA: 0x000159FE File Offset: 0x00013BFE
		public IniFile(IniOptions options)
		{
			if (options == null)
			{
				throw IniFile.smethod_0(<Module>.smethod_24<string>(2842754287U));
			}
			this.options = new IniOptions(options);
			this.sections = new IniSectionCollection(this, options.SectionDuplicate, options.SectionNameCaseSensitive);
		}

		// Token: 0x1700032D RID: 813
		// (get) Token: 0x060015A6 RID: 5542 RVA: 0x00015A3D File Offset: 0x00013C3D
		public IniSectionCollection Sections
		{
			get
			{
				return this.sections;
			}
		}

		// Token: 0x1700032E RID: 814
		// (get) Token: 0x060015A7 RID: 5543 RVA: 0x00015A45 File Offset: 0x00013C45
		public IniValueMappings ValueMappings
		{
			get
			{
				if (this.valueMappings == null)
				{
					this.valueMappings = new IniValueMappings();
				}
				return this.valueMappings;
			}
		}

		// Token: 0x1700032F RID: 815
		// (get) Token: 0x060015A8 RID: 5544 RVA: 0x00015A60 File Offset: 0x00013C60
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		internal bool HasValueMappings
		{
			get
			{
				return this.valueMappings != null;
			}
		}

		// Token: 0x17000330 RID: 816
		// (get) Token: 0x060015A9 RID: 5545 RVA: 0x00015A6E File Offset: 0x00013C6E
		public IniValueBinding ValueBinding
		{
			get
			{
				if (this.valueBinding == null)
				{
					this.valueBinding = new IniValueBinding(this);
				}
				return this.valueBinding;
			}
		}

		// Token: 0x060015AA RID: 5546 RVA: 0x00070030 File Offset: 0x0006E230
		public void Load(string filePath)
		{
			if (filePath == null)
			{
				throw IniFile.smethod_0(<Module>.smethod_24<string>(3093751397U));
			}
			Stream stream = IniFile.smethod_1(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			try
			{
				this.Load(stream);
			}
			finally
			{
				if (stream != null)
				{
					IniFile.smethod_2(stream);
				}
			}
		}

		// Token: 0x060015AB RID: 5547 RVA: 0x00070080 File Offset: 0x0006E280
		public void Load(Stream fileStream)
		{
			if (fileStream == null)
			{
				throw IniFile.smethod_0(<Module>.smethod_26<string>(839744669U));
			}
			this.Load(IniFile.smethod_3(fileStream, this.options.Encoding));
			if (IniFile.smethod_4(fileStream))
			{
				IniFile.smethod_5(fileStream, 0L, SeekOrigin.Begin);
			}
		}

		// Token: 0x060015AC RID: 5548 RVA: 0x00015A8A File Offset: 0x00013C8A
		public void Load(TextReader fileReader)
		{
			if (fileReader == null)
			{
				throw IniFile.smethod_0(<Module>.smethod_26<string>(2277784697U));
			}
			new IniReader(this.options).Read(this, fileReader);
		}

		// Token: 0x060015AD RID: 5549 RVA: 0x000700D0 File Offset: 0x0006E2D0
		public void Save(string filePath)
		{
			if (filePath == null)
			{
				throw IniFile.smethod_0(<Module>.smethod_26<string>(2982440120U));
			}
			Stream stream = IniFile.smethod_6(filePath);
			try
			{
				this.Save(stream);
			}
			finally
			{
				if (stream != null)
				{
					IniFile.smethod_2(stream);
				}
			}
		}

		// Token: 0x060015AE RID: 5550 RVA: 0x0007011C File Offset: 0x0006E31C
		public void Save(Stream fileStream)
		{
			if (fileStream == null)
			{
				throw IniFile.smethod_0(<Module>.smethod_25<string>(1344581712U));
			}
			this.Save(IniFile.smethod_7(fileStream, this.options.Encoding));
			if (IniFile.smethod_4(fileStream))
			{
				IniFile.smethod_5(fileStream, 0L, SeekOrigin.Begin);
			}
		}

		// Token: 0x060015AF RID: 5551 RVA: 0x00015AB1 File Offset: 0x00013CB1
		public void Save(TextWriter fileWriter)
		{
			if (fileWriter == null)
			{
				throw IniFile.smethod_0(<Module>.smethod_27<string>(4010061503U));
			}
			new IniWriter(this.options).Write(this, fileWriter);
		}

		// Token: 0x060015B0 RID: 5552 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_0(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x060015B1 RID: 5553 RVA: 0x0000FB08 File Offset: 0x0000DD08
		static FileStream smethod_1(string string_0, FileMode fileMode_0, FileAccess fileAccess_0, FileShare fileShare_0)
		{
			return File.Open(string_0, fileMode_0, fileAccess_0, fileShare_0);
		}

		// Token: 0x060015B2 RID: 5554 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_2(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060015B3 RID: 5555 RVA: 0x00015509 File Offset: 0x00013709
		static StreamReader smethod_3(Stream stream_0, Encoding encoding_0)
		{
			return new StreamReader(stream_0, encoding_0);
		}

		// Token: 0x060015B4 RID: 5556 RVA: 0x00012BF7 File Offset: 0x00010DF7
		static bool smethod_4(Stream stream_0)
		{
			return stream_0.CanSeek;
		}

		// Token: 0x060015B5 RID: 5557 RVA: 0x00012BED File Offset: 0x00010DED
		static long smethod_5(Stream stream_0, long long_0, SeekOrigin seekOrigin_0)
		{
			return stream_0.Seek(long_0, seekOrigin_0);
		}

		// Token: 0x060015B6 RID: 5558 RVA: 0x00015AD8 File Offset: 0x00013CD8
		static FileStream smethod_6(string string_0)
		{
			return File.Create(string_0);
		}

		// Token: 0x060015B7 RID: 5559 RVA: 0x000146DF File Offset: 0x000128DF
		static StreamWriter smethod_7(Stream stream_0, Encoding encoding_0)
		{
			return new StreamWriter(stream_0, encoding_0);
		}

		// Token: 0x040008AD RID: 2221
		internal readonly IniOptions options;

		// Token: 0x040008AE RID: 2222
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private readonly IniSectionCollection sections;

		// Token: 0x040008AF RID: 2223
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private IniValueMappings valueMappings;

		// Token: 0x040008B0 RID: 2224
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private IniValueBinding valueBinding;
	}
}
