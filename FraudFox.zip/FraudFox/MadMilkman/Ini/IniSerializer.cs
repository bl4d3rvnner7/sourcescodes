﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;

namespace MadMilkman.Ini
{
	// Token: 0x02000180 RID: 384
	internal static class IniSerializer
	{
		// Token: 0x060016BA RID: 5818 RVA: 0x00071798 File Offset: 0x0006F998
		public static void Serialize<T>(T source, IniSection section) where T : class, new()
		{
			IEnumerator<KeyValuePair<string, PropertyInfo>> enumerator = IniSerializer.GetPropertyPairs(IniSerializer.smethod_0(typeof(T).TypeHandle)).GetEnumerator();
			try
			{
				while (IniSerializer.smethod_1(enumerator))
				{
					KeyValuePair<string, PropertyInfo> keyValuePair = enumerator.Current;
					IniKey iniKey = section.Keys.Add(keyValuePair.Key);
					if (iniKey.ParentCollectionCore != null)
					{
						IniSerializer.SetKeyValue(keyValuePair.Value, source, iniKey);
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					IniSerializer.smethod_2(enumerator);
				}
			}
		}

		// Token: 0x060016BB RID: 5819 RVA: 0x00071818 File Offset: 0x0006FA18
		public static T Deserialize<T>(IniSection section) where T : class, new()
		{
			T t = new T();
			IEnumerator<KeyValuePair<string, PropertyInfo>> enumerator = IniSerializer.GetPropertyPairs(IniSerializer.smethod_0(typeof(T).TypeHandle)).GetEnumerator();
			try
			{
				while (IniSerializer.smethod_1(enumerator))
				{
					KeyValuePair<string, PropertyInfo> keyValuePair = enumerator.Current;
					IniKey iniKey = section.Keys[keyValuePair.Key];
					if (iniKey != null)
					{
						IniSerializer.SetPropertyValue(keyValuePair.Value, t, iniKey);
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					IniSerializer.smethod_2(enumerator);
				}
			}
			return t;
		}

		// Token: 0x060016BC RID: 5820 RVA: 0x00071898 File Offset: 0x0006FA98
		private static IEnumerable<KeyValuePair<string, PropertyInfo>> GetPropertyPairs(Type type)
		{
			foreach (PropertyInfo property in IniSerializer.<GetPropertyPairs>d__0.smethod_2(type, BindingFlags.Instance | BindingFlags.Public))
			{
				if (IniSerializer.PropertyTypeVerifier(IniSerializer.<GetPropertyPairs>d__0.smethod_3(property)))
				{
					string propertyName = null;
					object[] attributes = IniSerializer.<GetPropertyPairs>d__0.smethod_5(property, IniSerializer.<GetPropertyPairs>d__0.smethod_4(typeof(IniSerializationAttribute).TypeHandle), false);
					if (attributes.Length > 0)
					{
						IniSerializationAttribute iniSerializationAttribute = (IniSerializationAttribute)attributes[0];
						if (iniSerializationAttribute.Ignore)
						{
							goto IL_00D9;
						}
						propertyName = iniSerializationAttribute.Alias;
					}
					yield return new KeyValuePair<string, PropertyInfo>(propertyName ?? IniSerializer.<GetPropertyPairs>d__0.smethod_6(property), property);
				}
				IL_00D9:;
			}
			yield break;
		}

		// Token: 0x060016BD RID: 5821 RVA: 0x000718B8 File Offset: 0x0006FAB8
		private static void SetKeyValue(PropertyInfo property, object source, IniKey key)
		{
			object obj = IniSerializer.smethod_3(property, source, null);
			if (obj == null)
			{
				return;
			}
			if (!IniSerializer.smethod_5(IniSerializer.smethod_4(property)) && IniSerializer.smethod_7(IniSerializer.smethod_4(property), IniSerializer.smethod_6(IniSerializer.smethod_0(typeof(IList).TypeHandle))) == null)
			{
				key.Value = IniSerializer.smethod_10(obj);
				return;
			}
			List<string> list = new List<string>();
			IEnumerator enumerator = IniSerializer.smethod_8((IEnumerable)obj);
			try
			{
				while (IniSerializer.smethod_1(enumerator))
				{
					object obj2 = IniSerializer.smethod_9(enumerator);
					list.Add(IniSerializer.smethod_10(obj2));
				}
			}
			finally
			{
				IDisposable disposable = enumerator as IDisposable;
				if (disposable != null)
				{
					IniSerializer.smethod_2(disposable);
				}
			}
			key.Values = list.ToArray();
		}

		// Token: 0x060016BE RID: 5822 RVA: 0x0007196C File Offset: 0x0006FB6C
		private static void SetPropertyValue(PropertyInfo property, object destination, IniKey key)
		{
			Type type = IniSerializer.smethod_4(property);
			if (IniSerializer.smethod_5(type) && key.IsValueArray)
			{
				string[] values = key.Values;
				Type type2 = IniSerializer.smethod_11(type);
				Array array = IniSerializer.smethod_12(type2, values.Length);
				for (int i = 0; i < values.Length; i++)
				{
					IniSerializer.smethod_15(array, IniSerializer.smethod_14(IniSerializer.smethod_13(type2), values[i]), i);
				}
				IniSerializer.smethod_16(property, destination, array, null);
				return;
			}
			if (IniSerializer.smethod_7(type, IniSerializer.smethod_6(IniSerializer.smethod_0(typeof(IList).TypeHandle))) != null && key.IsValueArray)
			{
				Type type3 = IniSerializer.smethod_17(type)[0];
				IList list = (IList)IniSerializer.smethod_19(IniSerializer.smethod_18(IniSerializer.smethod_0(typeof(List<>).TypeHandle), new Type[] { type3 }));
				foreach (string text in key.Values)
				{
					IniSerializer.smethod_20(list, IniSerializer.smethod_14(IniSerializer.smethod_13(type3), text));
				}
				IniSerializer.smethod_16(property, destination, list, null);
				return;
			}
			IniSerializer.smethod_16(property, destination, IniSerializer.smethod_14(IniSerializer.smethod_13(type), key.Value), null);
		}

		// Token: 0x060016C0 RID: 5824 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_0(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060016C1 RID: 5825 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_1(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060016C2 RID: 5826 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_2(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060016C3 RID: 5827 RVA: 0x0000CDFE File Offset: 0x0000AFFE
		static object smethod_3(PropertyInfo propertyInfo_0, object object_0, object[] object_1)
		{
			return propertyInfo_0.GetValue(object_0, object_1);
		}

		// Token: 0x060016C4 RID: 5828 RVA: 0x000162CE File Offset: 0x000144CE
		static Type smethod_4(PropertyInfo propertyInfo_0)
		{
			return propertyInfo_0.PropertyType;
		}

		// Token: 0x060016C5 RID: 5829 RVA: 0x00015F2C File Offset: 0x0001412C
		static bool smethod_5(Type type_0)
		{
			return type_0.IsArray;
		}

		// Token: 0x060016C6 RID: 5830 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_6(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x060016C7 RID: 5831 RVA: 0x000162D6 File Offset: 0x000144D6
		static Type smethod_7(Type type_0, string string_0)
		{
			return type_0.GetInterface(string_0);
		}

		// Token: 0x060016C8 RID: 5832 RVA: 0x0000DAD6 File Offset: 0x0000BCD6
		static IEnumerator smethod_8(IEnumerable ienumerable_0)
		{
			return ienumerable_0.GetEnumerator();
		}

		// Token: 0x060016C9 RID: 5833 RVA: 0x0000D8E2 File Offset: 0x0000BAE2
		static object smethod_9(IEnumerator ienumerator_0)
		{
			return ienumerator_0.Current;
		}

		// Token: 0x060016CA RID: 5834 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_10(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x060016CB RID: 5835 RVA: 0x00015F34 File Offset: 0x00014134
		static Type smethod_11(Type type_0)
		{
			return type_0.GetElementType();
		}

		// Token: 0x060016CC RID: 5836 RVA: 0x000162DF File Offset: 0x000144DF
		static Array smethod_12(Type type_0, int int_0)
		{
			return Array.CreateInstance(type_0, int_0);
		}

		// Token: 0x060016CD RID: 5837 RVA: 0x000162E8 File Offset: 0x000144E8
		static TypeConverter smethod_13(Type type_0)
		{
			return TypeDescriptor.GetConverter(type_0);
		}

		// Token: 0x060016CE RID: 5838 RVA: 0x000162F0 File Offset: 0x000144F0
		static object smethod_14(TypeConverter typeConverter_0, string string_0)
		{
			return typeConverter_0.ConvertFromInvariantString(string_0);
		}

		// Token: 0x060016CF RID: 5839 RVA: 0x000162F9 File Offset: 0x000144F9
		static void smethod_15(Array array_0, object object_0, int int_0)
		{
			array_0.SetValue(object_0, int_0);
		}

		// Token: 0x060016D0 RID: 5840 RVA: 0x0000CE08 File Offset: 0x0000B008
		static void smethod_16(PropertyInfo propertyInfo_0, object object_0, object object_1, object[] object_2)
		{
			propertyInfo_0.SetValue(object_0, object_1, object_2);
		}

		// Token: 0x060016D1 RID: 5841 RVA: 0x00015F4C File Offset: 0x0001414C
		static Type[] smethod_17(Type type_0)
		{
			return type_0.GetGenericArguments();
		}

		// Token: 0x060016D2 RID: 5842 RVA: 0x00016303 File Offset: 0x00014503
		static Type smethod_18(Type type_0, Type[] type_1)
		{
			return type_0.MakeGenericType(type_1);
		}

		// Token: 0x060016D3 RID: 5843 RVA: 0x0001630C File Offset: 0x0001450C
		static object smethod_19(Type type_0)
		{
			return Activator.CreateInstance(type_0);
		}

		// Token: 0x060016D4 RID: 5844 RVA: 0x00016314 File Offset: 0x00014514
		static int smethod_20(IList ilist_0, object object_0)
		{
			return ilist_0.Add(object_0);
		}

		// Token: 0x040008F1 RID: 2289
		private static readonly Predicate<Type> PropertyTypeVerifier = new Predicate<Type>(IniKey.IsSupportedValueType);
	}
}
