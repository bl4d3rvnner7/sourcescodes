﻿using System;
using System.IO;

namespace MadMilkman.Ini
{
	// Token: 0x0200017D RID: 381
	internal sealed class IniReader
	{
		// Token: 0x0600167D RID: 5757 RVA: 0x00016185 File Offset: 0x00014385
		public IniReader(IniOptions options)
		{
			this.options = options;
			this.currentEmptyLinesBefore = 0;
			this.currentTrailingComment = null;
			this.currentSection = null;
		}

		// Token: 0x0600167E RID: 5758 RVA: 0x00070F38 File Offset: 0x0006F138
		public void Read(IniFile iniFile, TextReader textReader)
		{
			this.reader = IniReader.smethod_1(this.DecompressAndDecryptText(IniReader.smethod_0(textReader)));
			string text;
			while ((text = IniReader.smethod_4(this.reader)) != null)
			{
				if (IniReader.smethod_3(IniReader.smethod_2(text)) == 0)
				{
					this.currentEmptyLinesBefore++;
				}
				else
				{
					this.ReadLine(text, iniFile);
				}
			}
		}

		// Token: 0x0600167F RID: 5759 RVA: 0x00070F94 File Offset: 0x0006F194
		private string DecompressAndDecryptText(string fileContent)
		{
			if (this.options.Compression)
			{
				fileContent = IniCompressor.Decompress(fileContent, this.options.Encoding);
			}
			if (!IniReader.smethod_5(this.options.EncryptionPassword))
			{
				fileContent = IniEncryptor.Decrypt(fileContent, this.options.EncryptionPassword, this.options.Encoding);
			}
			return fileContent;
		}

		// Token: 0x06001680 RID: 5760 RVA: 0x00070FF4 File Offset: 0x0006F1F4
		private void ReadLine(string line, IniFile file)
		{
			int num = Array.FindIndex<char>(IniReader.smethod_6(line), (char c) => !char.IsWhiteSpace(c) && c != '\t');
			char c2 = IniReader.smethod_7(line, num);
			if (c2 == (char)this.options.CommentStarter)
			{
				this.ReadTrailingComment(num, IniReader.smethod_8(line, num + 1));
			}
			else if (c2 == this.options.sectionWrapperStart)
			{
				this.ReadSection(num, line, file);
			}
			else
			{
				this.ReadKey(num, line, file);
			}
			this.currentEmptyLinesBefore = 0;
		}

		// Token: 0x06001681 RID: 5761 RVA: 0x00071080 File Offset: 0x0006F280
		private void ReadTrailingComment(int leftIndention, string text)
		{
			if (this.currentTrailingComment == null)
			{
				this.currentTrailingComment = new IniComment(IniCommentType.Trailing)
				{
					EmptyLinesBefore = this.currentEmptyLinesBefore,
					LeftIndentation = leftIndention,
					Text = text
				};
				return;
			}
			IniComment iniComment = this.currentTrailingComment;
			iniComment.Text = IniReader.smethod_10(iniComment.Text, IniReader.smethod_9(), text);
		}

		// Token: 0x06001682 RID: 5762 RVA: 0x000710DC File Offset: 0x0006F2DC
		private void ReadSection(int leftIndention, string line, IniFile file)
		{
			int num = -1;
			int num2 = leftIndention;
			while (num2 != -1 && ++num2 <= IniReader.smethod_3(line))
			{
				int num3 = IniReader.smethod_11(line, (char)this.options.CommentStarter, num2);
				if (num3 == -1)
				{
					num = IniReader.smethod_12(line, this.options.sectionWrapperEnd, IniReader.smethod_3(line) - 1, IniReader.smethod_3(line) - num2);
				}
				else
				{
					num = IniReader.smethod_12(line, this.options.sectionWrapperEnd, num3 - 1, num3 - num2);
				}
				if (num != -1)
				{
					break;
				}
				num2 = num3;
			}
			if (num != -1)
			{
				this.currentSection = new IniSection(file, IniReader.smethod_13(line, leftIndention + 1, num - leftIndention - 1), this.currentTrailingComment)
				{
					LeftIndentation = leftIndention,
					LeadingComment = 
					{
						EmptyLinesBefore = this.currentEmptyLinesBefore
					}
				};
				file.Sections.Add(this.currentSection);
				if (++num < IniReader.smethod_3(line))
				{
					this.ReadSectionLeadingComment(IniReader.smethod_8(line, num));
				}
			}
			this.currentTrailingComment = null;
		}

		// Token: 0x06001683 RID: 5763 RVA: 0x000711CC File Offset: 0x0006F3CC
		private void ReadSectionLeadingComment(string lineLeftover)
		{
			int num = Array.FindIndex<char>(IniReader.smethod_6(lineLeftover), (char c) => !char.IsWhiteSpace(c) && c != '\t');
			if (num != -1 && IniReader.smethod_7(lineLeftover, num) == (char)this.options.CommentStarter)
			{
				IniComment leadingComment = this.currentSection.LeadingComment;
				leadingComment.Text = IniReader.smethod_8(lineLeftover, num + 1);
				leadingComment.LeftIndentation = num;
			}
		}

		// Token: 0x06001684 RID: 5764 RVA: 0x00071240 File Offset: 0x0006F440
		private void ReadKey(int leftIndention, string line, IniFile file)
		{
			int num = IniReader.smethod_11(line, (char)this.options.KeyDelimiter, leftIndention);
			if (num != -1)
			{
				if (this.currentSection == null)
				{
					this.currentSection = file.Sections.Add(<Module>.smethod_23<string>(149420517U));
				}
				IniKey iniKey = new IniKey(file, IniReader.smethod_14(IniReader.smethod_13(line, leftIndention, num - leftIndention), new char[0]), this.currentTrailingComment)
				{
					LeftIndentation = leftIndention,
					LeadingComment = 
					{
						EmptyLinesBefore = this.currentEmptyLinesBefore
					}
				};
				this.currentSection.Keys.Add(iniKey);
				this.ReadKeyValueAndLeadingComment(IniReader.smethod_15(IniReader.smethod_8(line, num + 1), new char[0]), iniKey);
			}
			this.currentTrailingComment = null;
		}

		// Token: 0x06001685 RID: 5765 RVA: 0x000712FC File Offset: 0x0006F4FC
		private void ReadKeyValueAndLeadingComment(string lineLeftover, IniKey key)
		{
			int num = IniReader.smethod_16(lineLeftover, (char)this.options.CommentStarter);
			if (num == -1)
			{
				key.Value = IniReader.smethod_14(lineLeftover, new char[0]);
				return;
			}
			if (num != 0)
			{
				key.LeadingComment.Text = IniReader.smethod_8(lineLeftover, num + 1);
				int num2 = 0;
				for (;;)
				{
					if (IniReader.smethod_7(lineLeftover, --num) != ' ')
					{
						if (IniReader.smethod_7(lineLeftover, num) != '\t')
						{
							break;
						}
					}
					num2++;
				}
				key.LeadingComment.LeftIndentation = num2;
				key.Value = IniReader.smethod_13(lineLeftover, 0, num + 1);
				return;
			}
			key.Value = (key.LeadingComment.Text = string.Empty);
		}

		// Token: 0x06001688 RID: 5768 RVA: 0x0000DF57 File Offset: 0x0000C157
		static string smethod_0(TextReader textReader_0)
		{
			return textReader_0.ReadToEnd();
		}

		// Token: 0x06001689 RID: 5769 RVA: 0x000161BD File Offset: 0x000143BD
		static StringReader smethod_1(string string_0)
		{
			return new StringReader(string_0);
		}

		// Token: 0x0600168A RID: 5770 RVA: 0x0000C6B8 File Offset: 0x0000A8B8
		static string smethod_2(string string_0)
		{
			return string_0.Trim();
		}

		// Token: 0x0600168B RID: 5771 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_3(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x0600168C RID: 5772 RVA: 0x000161C5 File Offset: 0x000143C5
		static string smethod_4(TextReader textReader_0)
		{
			return textReader_0.ReadLine();
		}

		// Token: 0x0600168D RID: 5773 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_5(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x0600168E RID: 5774 RVA: 0x00014704 File Offset: 0x00012904
		static char[] smethod_6(string string_0)
		{
			return string_0.ToCharArray();
		}

		// Token: 0x0600168F RID: 5775 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_7(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x06001690 RID: 5776 RVA: 0x0000D416 File Offset: 0x0000B616
		static string smethod_8(string string_0, int int_0)
		{
			return string_0.Substring(int_0);
		}

		// Token: 0x06001691 RID: 5777 RVA: 0x0000CD86 File Offset: 0x0000AF86
		static string smethod_9()
		{
			return Environment.NewLine;
		}

		// Token: 0x06001692 RID: 5778 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_10(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x06001693 RID: 5779 RVA: 0x0000EE25 File Offset: 0x0000D025
		static int smethod_11(string string_0, char char_0, int int_0)
		{
			return string_0.IndexOf(char_0, int_0);
		}

		// Token: 0x06001694 RID: 5780 RVA: 0x000161CD File Offset: 0x000143CD
		static int smethod_12(string string_0, char char_0, int int_0, int int_1)
		{
			return string_0.LastIndexOf(char_0, int_0, int_1);
		}

		// Token: 0x06001695 RID: 5781 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_13(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x06001696 RID: 5782 RVA: 0x000161D8 File Offset: 0x000143D8
		static string smethod_14(string string_0, char[] char_0)
		{
			return string_0.TrimEnd(char_0);
		}

		// Token: 0x06001697 RID: 5783 RVA: 0x000161E1 File Offset: 0x000143E1
		static string smethod_15(string string_0, char[] char_0)
		{
			return string_0.TrimStart(char_0);
		}

		// Token: 0x06001698 RID: 5784 RVA: 0x0000FABD File Offset: 0x0000DCBD
		static int smethod_16(string string_0, char char_0)
		{
			return string_0.IndexOf(char_0);
		}

		// Token: 0x040008E5 RID: 2277
		private readonly IniOptions options;

		// Token: 0x040008E6 RID: 2278
		private TextReader reader;

		// Token: 0x040008E7 RID: 2279
		private int currentEmptyLinesBefore;

		// Token: 0x040008E8 RID: 2280
		private IniComment currentTrailingComment;

		// Token: 0x040008E9 RID: 2281
		private IniSection currentSection;
	}
}
