﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace FraudFox
{
	// Token: 0x0200001E RID: 30
	public class FontManager
	{
		// Token: 0x060001FE RID: 510
		[DllImport("gdi32.dll", SetLastError = true)]
		private static extern int AddFontResourceW([MarshalAs(UnmanagedType.LPWStr)] [In] string lpFileName);

		// Token: 0x060001FF RID: 511
		[DllImport("gdi32.dll", SetLastError = true)]
		private static extern int RemoveFontResourceW([MarshalAs(UnmanagedType.LPWStr)] [In] string lpFileName);

		// Token: 0x06000200 RID: 512
		[DllImport("user32.dll")]
		private static extern int SendMessage(int hWnd, uint msg, int wParam, int lParam);

		// Token: 0x06000201 RID: 513 RVA: 0x0000CF82 File Offset: 0x0000B182
		public static bool RegisterFont(string filePath)
		{
			int num = FontManager.AddFontResourceW(filePath);
			FontManager.SendMessage(65535, 29U, 0, 0);
			FontManager.ClearCache();
			return num > 0;
		}

		// Token: 0x06000202 RID: 514 RVA: 0x0002600C File Offset: 0x0002420C
		public static bool RegisterFont(IEnumerable<string> files)
		{
			IEnumerator<string> enumerator = files.GetEnumerator();
			try
			{
				while (FontManager.smethod_1(enumerator))
				{
					string text = enumerator.Current;
					if (FontManager.AddFontResourceW(text) < 1)
					{
						LogManager.AddEntry(FontManager.smethod_0(<Module>.smethod_23<string>(1848554298U), text), null);
						FontManager.SendMessage(65535, 29U, 0, 0);
						FontManager.ClearCache();
						return false;
					}
				}
				goto IL_005E;
			}
			finally
			{
				if (enumerator != null)
				{
					FontManager.smethod_2(enumerator);
				}
			}
			bool flag;
			return flag;
			IL_005E:
			FontManager.SendMessage(65535, 29U, 0, 0);
			FontManager.ClearCache();
			return true;
		}

		// Token: 0x06000203 RID: 515 RVA: 0x0000CFA1 File Offset: 0x0000B1A1
		public static bool RemoveFont(string filePath)
		{
			int num = FontManager.RemoveFontResourceW(filePath);
			FontManager.smethod_3(filePath);
			FontManager.SendMessage(65535, 29U, 0, 0);
			FontManager.ClearCache();
			return num > 0;
		}

		// Token: 0x06000204 RID: 516 RVA: 0x0002609C File Offset: 0x0002429C
		public static bool RemoveFont(IEnumerable<string> files)
		{
			IEnumerator<string> enumerator = files.GetEnumerator();
			try
			{
				while (FontManager.smethod_1(enumerator))
				{
					string text = enumerator.Current;
					if (FontManager.RemoveFontResourceW(text) < 1)
					{
						FontManager.smethod_3(text);
						FontManager.SendMessage(65535, 29U, 0, 0);
						FontManager.ClearCache();
						return false;
					}
					FontManager.smethod_3(text);
				}
				goto IL_0054;
			}
			finally
			{
				if (enumerator != null)
				{
					FontManager.smethod_2(enumerator);
				}
			}
			bool flag;
			return flag;
			IL_0054:
			FontManager.SendMessage(65535, 29U, 0, 0);
			FontManager.ClearCache();
			return true;
		}

		// Token: 0x06000205 RID: 517 RVA: 0x00026124 File Offset: 0x00024324
		public static void ClearCache()
		{
			string text = FontManager.smethod_5(FontManager.smethod_4(), <Module>.smethod_27<string>(2901476450U));
			if (FontManager.smethod_6(text))
			{
				FontManager.smethod_3(text);
			}
		}

		// Token: 0x06000206 RID: 518 RVA: 0x00026154 File Offset: 0x00024354
		public static List<string> InitInjection(List<string> fontNames)
		{
			FontManager.smethod_7(<Module>.smethod_25<string>(2579554749U), fontNames);
			string[] array = FontManager.smethod_9(FontManager.smethod_8(FontManager.CurrentPath, <Module>.smethod_24<string>(3666899264U), <Module>.smethod_23<string>(321114407U)), <Module>.smethod_25<string>(3652964417U));
			if (array.Length < fontNames.Count)
			{
				throw FontManager.smethod_11(FontManager.smethod_10(<Module>.smethod_23<string>(3494019441U), array.Length, fontNames.Count));
			}
			List<string> list = new List<string>();
			IEnumerator<string> enumerator = array.Take(fontNames.Count - 4).GetEnumerator();
			try
			{
				while (FontManager.smethod_1(enumerator))
				{
					string text = enumerator.Current;
					FontManager.smethod_13(text, FontManager.smethod_8(FontManager.CurrentPath, <Module>.smethod_24<string>(1159426895U), FontManager.smethod_12(text)), true);
					list.Add(FontManager.smethod_8(FontManager.CurrentPath, <Module>.smethod_26<string>(3844588058U), FontManager.smethod_12(text)));
				}
			}
			finally
			{
				if (enumerator != null)
				{
					FontManager.smethod_2(enumerator);
				}
			}
			FontManager.RegisterFont(list);
			return list;
		}

		// Token: 0x06000207 RID: 519 RVA: 0x00026264 File Offset: 0x00024464
		public static void InjectFonts()
		{
			Process process = FontManager.smethod_14();
			FontManager.smethod_16(FontManager.smethod_15(process), ProcessWindowStyle.Hidden);
			FontManager.smethod_18(FontManager.smethod_15(process), FontManager.smethod_17(FontManager.CurrentPath, <Module>.smethod_26<string>(1673163425U), <Module>.smethod_25<string>(471556369U), <Module>.smethod_27<string>(3361921840U)));
			FontManager.smethod_19(FontManager.smethod_15(process), FontManager.smethod_0(<Module>.smethod_23<string>(2023021925U), <Module>.smethod_24<string>(4253753549U)));
			FontManager.smethod_20(process);
			FontManager.smethod_21(process);
		}

		// Token: 0x06000208 RID: 520 RVA: 0x000262E8 File Offset: 0x000244E8
		public static void EjectFonts(List<string> fontPaths)
		{
			Process process = FontManager.smethod_14();
			FontManager.smethod_16(FontManager.smethod_15(process), ProcessWindowStyle.Hidden);
			FontManager.smethod_18(FontManager.smethod_15(process), FontManager.smethod_17(FontManager.CurrentPath, <Module>.smethod_23<string>(4176468443U), <Module>.smethod_24<string>(2858003491U), <Module>.smethod_23<string>(2197489552U)));
			FontManager.smethod_19(FontManager.smethod_15(process), FontManager.smethod_0(<Module>.smethod_26<string>(2800761112U), <Module>.smethod_25<string>(889141087U)));
			FontManager.RemoveFont(fontPaths);
			FontManager.smethod_20(process);
			FontManager.smethod_22(<Module>.smethod_26<string>(2925254234U), "");
		}

		// Token: 0x06000209 RID: 521 RVA: 0x00026380 File Offset: 0x00024580
		public static string CreateFont(string fontName)
		{
			string fileName = fontName;
			Array.ForEach<char>(FontManager.smethod_23(), delegate(char c)
			{
				fileName = fileName.Replace(c.ToString(), string.Empty);
			});
			Process process = FontManager.smethod_14();
			FontManager.smethod_24(FontManager.smethod_15(process), FontManager.smethod_5(FontManager.CurrentPath, <Module>.smethod_24<string>(1159426895U)));
			FontManager.smethod_16(FontManager.smethod_15(process), ProcessWindowStyle.Hidden);
			FontManager.smethod_18(FontManager.smethod_15(process), FontManager.smethod_17(FontManager.CurrentPath, <Module>.smethod_24<string>(3774616386U), <Module>.smethod_27<string>(2009892743U), <Module>.smethod_25<string>(2211492694U)));
			FontManager.smethod_19(FontManager.smethod_15(process), FontManager.smethod_10(<Module>.smethod_27<string>(2243001208U), FontManager.smethod_5(FontManager.CurrentPath, <Module>.smethod_26<string>(3844588058U)), FontManager.smethod_8(FontManager.CurrentPath, <Module>.smethod_27<string>(2953420310U), FontManager.smethod_0(<Module>.smethod_27<string>(1543675813U), fileName))));
			Process process2 = process;
			if (!FontManager.smethod_6(FontManager.smethod_8(FontManager.CurrentPath, <Module>.smethod_26<string>(3844588058U), FontManager.smethod_0(<Module>.smethod_27<string>(1870027664U), fileName))))
			{
				string text = FontManager.smethod_25(FontManager.smethod_17(FontManager.CurrentPath, <Module>.smethod_23<string>(885538157U), <Module>.smethod_25<string>(3861756776U), <Module>.smethod_26<string>(2115258477U)));
				FontManager.smethod_22(FontManager.smethod_8(FontManager.CurrentPath, <Module>.smethod_25<string>(3848397821U), FontManager.smethod_0(<Module>.smethod_26<string>(667642055U), fileName)), FontManager.smethod_26(text, <Module>.smethod_26<string>(2829490294U), fontName));
				FontManager.smethod_20(process2);
				FontManager.smethod_21(process2);
				FontManager.smethod_3(FontManager.smethod_8(FontManager.CurrentPath, <Module>.smethod_25<string>(3848397821U), FontManager.smethod_0(<Module>.smethod_26<string>(667642055U), fileName)));
			}
			if (!FontManager.smethod_6(FontManager.smethod_8(FontManager.CurrentPath, <Module>.smethod_24<string>(1159426895U), FontManager.smethod_0(<Module>.smethod_24<string>(879462997U), fileName))))
			{
				throw FontManager.smethod_27(FontManager.smethod_0(<Module>.smethod_25<string>(3702487080U), fontName));
			}
			return FontManager.smethod_8(FontManager.CurrentPath, <Module>.smethod_25<string>(3848397821U), FontManager.smethod_0(<Module>.smethod_25<string>(2559479959U), fileName));
		}

		// Token: 0x0600020A RID: 522 RVA: 0x000265B8 File Offset: 0x000247B8
		public static List<string> CreateFont(List<string> fontNames)
		{
			FontManager.<>c__DisplayClass18_0 CS$<>8__locals1 = new FontManager.<>c__DisplayClass18_0();
			CS$<>8__locals1.result = new ConcurrentBag<string>();
			CS$<>8__locals1.queue = new ConcurrentQueue<string>(fontNames);
			Task[] array = new Task[3];
			for (int i = 0; i < 3; i++)
			{
				Task[] array2 = array;
				int num = i;
				TaskFactory taskFactory = FontManager.smethod_28();
				Action action;
				if ((action = CS$<>8__locals1.<>9__0) == null)
				{
					FontManager.<>c__DisplayClass18_0 CS$<>8__locals2 = CS$<>8__locals1;
					action = (CS$<>8__locals2.<>9__0 = delegate
					{
						Process process = FontManager.<>c__DisplayClass18_0.smethod_0();
						FontManager.<>c__DisplayClass18_0.smethod_3(FontManager.<>c__DisplayClass18_0.smethod_1(process), FontManager.<>c__DisplayClass18_0.smethod_2(FontManager.CurrentPath, <Module>.smethod_25<string>(3848397821U)));
						FontManager.<>c__DisplayClass18_0.smethod_4(FontManager.<>c__DisplayClass18_0.smethod_1(process), ProcessWindowStyle.Hidden);
						FontManager.<>c__DisplayClass18_0.smethod_6(FontManager.<>c__DisplayClass18_0.smethod_1(process), FontManager.<>c__DisplayClass18_0.smethod_5(FontManager.CurrentPath, <Module>.smethod_26<string>(1673163425U), <Module>.smethod_24<string>(12644814U), <Module>.smethod_26<string>(2086529295U)));
						Process process2 = process;
						while (!CS$<>8__locals2.queue.IsEmpty)
						{
							string text;
							if (CS$<>8__locals2.queue.TryDequeue(out text))
							{
								string fileName = text;
								Array.ForEach<char>(FontManager.<>c__DisplayClass18_0.smethod_7(), delegate(char c)
								{
									fileName = fileName.Replace(c.ToString(), string.Empty);
								});
								if (FontManager.<>c__DisplayClass18_0.smethod_9(FontManager.<>c__DisplayClass18_0.smethod_5(FontManager.CurrentPath, <Module>.smethod_24<string>(3666899264U), <Module>.smethod_25<string>(3861756776U), FontManager.<>c__DisplayClass18_0.smethod_8(<Module>.smethod_23<string>(1424362544U), fileName))))
								{
									FontManager.<>c__DisplayClass18_0.smethod_11(FontManager.<>c__DisplayClass18_0.smethod_5(FontManager.CurrentPath, <Module>.smethod_25<string>(60687486U), <Module>.smethod_27<string>(3874760463U), FontManager.<>c__DisplayClass18_0.smethod_8(<Module>.smethod_24<string>(879462997U), fileName)), FontManager.<>c__DisplayClass18_0.smethod_10(FontManager.CurrentPath, <Module>.smethod_25<string>(3848397821U), FontManager.<>c__DisplayClass18_0.smethod_8(<Module>.smethod_25<string>(2559479959U), fileName)), true);
									CS$<>8__locals2.result.Add(FontManager.<>c__DisplayClass18_0.smethod_10(FontManager.CurrentPath, <Module>.smethod_24<string>(1159426895U), FontManager.<>c__DisplayClass18_0.smethod_8(<Module>.smethod_25<string>(2559479959U), fileName)));
								}
								else if (!FontManager.<>c__DisplayClass18_0.smethod_9(FontManager.<>c__DisplayClass18_0.smethod_10(FontManager.CurrentPath, <Module>.smethod_26<string>(3844588058U), FontManager.<>c__DisplayClass18_0.smethod_8(<Module>.smethod_24<string>(879462997U), fileName))))
								{
									FontManager.<>c__DisplayClass18_0.smethod_13(FontManager.<>c__DisplayClass18_0.smethod_1(process2), FontManager.<>c__DisplayClass18_0.smethod_12(<Module>.smethod_26<string>(1381873872U), FontManager.<>c__DisplayClass18_0.smethod_2(FontManager.CurrentPath, <Module>.smethod_26<string>(3844588058U)), FontManager.<>c__DisplayClass18_0.smethod_10(FontManager.CurrentPath, <Module>.smethod_23<string>(829095782U), FontManager.<>c__DisplayClass18_0.smethod_8(<Module>.smethod_24<string>(2329071616U), fileName))));
									string text2 = FontManager.<>c__DisplayClass18_0.smethod_14(FontManager.<>c__DisplayClass18_0.smethod_5(FontManager.CurrentPath, <Module>.smethod_24<string>(3666899264U), <Module>.smethod_23<string>(321114407U), <Module>.smethod_26<string>(2115258477U)));
									FontManager.<>c__DisplayClass18_0.smethod_16(FontManager.<>c__DisplayClass18_0.smethod_10(FontManager.CurrentPath, <Module>.smethod_23<string>(829095782U), FontManager.<>c__DisplayClass18_0.smethod_8(<Module>.smethod_27<string>(1543675813U), fileName)), FontManager.<>c__DisplayClass18_0.smethod_15(text2, <Module>.smethod_23<string>(688863786U), text));
									FontManager.<>c__DisplayClass18_0.smethod_17(process2);
									FontManager.<>c__DisplayClass18_0.smethod_18(process2);
									FontManager.<>c__DisplayClass18_0.smethod_19(FontManager.<>c__DisplayClass18_0.smethod_10(FontManager.CurrentPath, <Module>.smethod_25<string>(3848397821U), FontManager.<>c__DisplayClass18_0.smethod_8(<Module>.smethod_23<string>(1056613165U), fileName)));
									if (!FontManager.<>c__DisplayClass18_0.smethod_9(FontManager.<>c__DisplayClass18_0.smethod_10(FontManager.CurrentPath, <Module>.smethod_25<string>(3848397821U), FontManager.<>c__DisplayClass18_0.smethod_8(<Module>.smethod_27<string>(1870027664U), fileName))))
									{
										throw FontManager.<>c__DisplayClass18_0.smethod_20(FontManager.<>c__DisplayClass18_0.smethod_8(<Module>.smethod_27<string>(2563581519U), text));
									}
									CS$<>8__locals2.result.Add(FontManager.<>c__DisplayClass18_0.smethod_10(FontManager.CurrentPath, <Module>.smethod_27<string>(2953420310U), FontManager.<>c__DisplayClass18_0.smethod_8(<Module>.smethod_24<string>(879462997U), fileName)));
								}
							}
						}
					});
				}
				array2[num] = FontManager.smethod_29(taskFactory, action);
			}
			FontManager.smethod_30(array);
			return CS$<>8__locals1.result.ToList<string>();
		}

		// Token: 0x0600020D RID: 525 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_0(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x0600020E RID: 526 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_1(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x0600020F RID: 527 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_2(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06000210 RID: 528 RVA: 0x0000C7ED File Offset: 0x0000A9ED
		static void smethod_3(string string_0)
		{
			File.Delete(string_0);
		}

		// Token: 0x06000211 RID: 529 RVA: 0x0000CFDC File Offset: 0x0000B1DC
		static string smethod_4()
		{
			return Environment.SystemDirectory;
		}

		// Token: 0x06000212 RID: 530 RVA: 0x0000C656 File Offset: 0x0000A856
		static string smethod_5(string string_0, string string_1)
		{
			return Path.Combine(string_0, string_1);
		}

		// Token: 0x06000213 RID: 531 RVA: 0x0000C681 File Offset: 0x0000A881
		static bool smethod_6(string string_0)
		{
			return File.Exists(string_0);
		}

		// Token: 0x06000214 RID: 532 RVA: 0x0000CFE3 File Offset: 0x0000B1E3
		static void smethod_7(string string_0, IEnumerable<string> ienumerable_0)
		{
			File.WriteAllLines(string_0, ienumerable_0);
		}

		// Token: 0x06000215 RID: 533 RVA: 0x0000C784 File Offset: 0x0000A984
		static string smethod_8(string string_0, string string_1, string string_2)
		{
			return Path.Combine(string_0, string_1, string_2);
		}

		// Token: 0x06000216 RID: 534 RVA: 0x0000CD4E File Offset: 0x0000AF4E
		static string[] smethod_9(string string_0, string string_1)
		{
			return Directory.GetFiles(string_0, string_1);
		}

		// Token: 0x06000217 RID: 535 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_10(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x06000218 RID: 536 RVA: 0x0000CFEC File Offset: 0x0000B1EC
		static ApplicationException smethod_11(string string_0)
		{
			return new ApplicationException(string_0);
		}

		// Token: 0x06000219 RID: 537 RVA: 0x0000CFF4 File Offset: 0x0000B1F4
		static string smethod_12(string string_0)
		{
			return Path.GetFileName(string_0);
		}

		// Token: 0x0600021A RID: 538 RVA: 0x0000CFFC File Offset: 0x0000B1FC
		static void smethod_13(string string_0, string string_1, bool bool_0)
		{
			File.Copy(string_0, string_1, bool_0);
		}

		// Token: 0x0600021B RID: 539 RVA: 0x0000C775 File Offset: 0x0000A975
		static Process smethod_14()
		{
			return new Process();
		}

		// Token: 0x0600021C RID: 540 RVA: 0x0000C77C File Offset: 0x0000A97C
		static ProcessStartInfo smethod_15(Process process_0)
		{
			return process_0.StartInfo;
		}

		// Token: 0x0600021D RID: 541 RVA: 0x0000C7A9 File Offset: 0x0000A9A9
		static void smethod_16(ProcessStartInfo processStartInfo_0, ProcessWindowStyle processWindowStyle_0)
		{
			processStartInfo_0.WindowStyle = processWindowStyle_0;
		}

		// Token: 0x0600021E RID: 542 RVA: 0x0000C676 File Offset: 0x0000A876
		static string smethod_17(string string_0, string string_1, string string_2, string string_3)
		{
			return Path.Combine(string_0, string_1, string_2, string_3);
		}

		// Token: 0x0600021F RID: 543 RVA: 0x0000C78E File Offset: 0x0000A98E
		static void smethod_18(ProcessStartInfo processStartInfo_0, string string_0)
		{
			processStartInfo_0.FileName = string_0;
		}

		// Token: 0x06000220 RID: 544 RVA: 0x0000C797 File Offset: 0x0000A997
		static void smethod_19(ProcessStartInfo processStartInfo_0, string string_0)
		{
			processStartInfo_0.Arguments = string_0;
		}

		// Token: 0x06000221 RID: 545 RVA: 0x0000C7CD File Offset: 0x0000A9CD
		static bool smethod_20(Process process_0)
		{
			return process_0.Start();
		}

		// Token: 0x06000222 RID: 546 RVA: 0x0000D006 File Offset: 0x0000B206
		static void smethod_21(Process process_0)
		{
			process_0.WaitForExit();
		}

		// Token: 0x06000223 RID: 547 RVA: 0x0000CD3C File Offset: 0x0000AF3C
		static void smethod_22(string string_0, string string_1)
		{
			File.WriteAllText(string_0, string_1);
		}

		// Token: 0x06000224 RID: 548 RVA: 0x0000D00E File Offset: 0x0000B20E
		static char[] smethod_23()
		{
			return Path.GetInvalidFileNameChars();
		}

		// Token: 0x06000225 RID: 549 RVA: 0x0000C7A0 File Offset: 0x0000A9A0
		static void smethod_24(ProcessStartInfo processStartInfo_0, string string_0)
		{
			processStartInfo_0.WorkingDirectory = string_0;
		}

		// Token: 0x06000226 RID: 550 RVA: 0x0000C7E5 File Offset: 0x0000A9E5
		static string smethod_25(string string_0)
		{
			return File.ReadAllText(string_0);
		}

		// Token: 0x06000227 RID: 551 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_26(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x06000228 RID: 552 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_27(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x06000229 RID: 553 RVA: 0x0000D01D File Offset: 0x0000B21D
		static TaskFactory smethod_28()
		{
			return Task.Factory;
		}

		// Token: 0x0600022A RID: 554 RVA: 0x0000D024 File Offset: 0x0000B224
		static Task smethod_29(TaskFactory taskFactory_0, Action action_0)
		{
			return taskFactory_0.StartNew(action_0);
		}

		// Token: 0x0600022B RID: 555 RVA: 0x0000D02D File Offset: 0x0000B22D
		static void smethod_30(Task[] task_0)
		{
			Task.WaitAll(task_0);
		}

		// Token: 0x0600022C RID: 556 RVA: 0x0000C65F File Offset: 0x0000A85F
		static Assembly smethod_31()
		{
			return Assembly.GetExecutingAssembly();
		}

		// Token: 0x0600022D RID: 557 RVA: 0x0000C666 File Offset: 0x0000A866
		static string smethod_32(Assembly assembly_0)
		{
			return assembly_0.Location;
		}

		// Token: 0x0600022E RID: 558 RVA: 0x0000C66E File Offset: 0x0000A86E
		static string smethod_33(string string_0)
		{
			return Path.GetDirectoryName(string_0);
		}

		// Token: 0x04000082 RID: 130
		private const int WM_FONTCHANGE = 29;

		// Token: 0x04000083 RID: 131
		private const int HWND_BROADCAST = 65535;

		// Token: 0x04000084 RID: 132
		private const string _dllPath = "C:\\WINDOWS\\system32\\hook.dll";

		// Token: 0x04000085 RID: 133
		private const string _configPath = "C:\\WINDOWS\\system32\\fonts.ini";

		// Token: 0x04000086 RID: 134
		private const int OS_FONTS_NUM = 4;

		// Token: 0x04000087 RID: 135
		private static readonly string CurrentPath = FontManager.smethod_33(FontManager.smethod_32(FontManager.smethod_31()));
	}
}
