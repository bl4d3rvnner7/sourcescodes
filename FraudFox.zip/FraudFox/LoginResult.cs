﻿using System;
using System.Reflection;

namespace FraudFox
{
	// Token: 0x02000039 RID: 57
	[Obfuscation(Exclude = true, ApplyToMembers = true)]
	public struct LoginResult
	{
		// Token: 0x1700005D RID: 93
		// (get) Token: 0x06000434 RID: 1076 RVA: 0x0000DA4F File Offset: 0x0000BC4F
		// (set) Token: 0x06000435 RID: 1077 RVA: 0x0000DA57 File Offset: 0x0000BC57
		public int Now { get; set; }

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x06000436 RID: 1078 RVA: 0x0000DA60 File Offset: 0x0000BC60
		// (set) Token: 0x06000437 RID: 1079 RVA: 0x0000DA68 File Offset: 0x0000BC68
		public string Message { get; set; }
	}
}
