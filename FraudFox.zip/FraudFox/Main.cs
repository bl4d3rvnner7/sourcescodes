﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.Layout;
using System.Xml.Serialization;

namespace FraudFox
{
	// Token: 0x02000033 RID: 51
	public partial class Main : Form
	{
		// Token: 0x1700005B RID: 91
		// (get) Token: 0x0600031D RID: 797 RVA: 0x0000D4FE File Offset: 0x0000B6FE
		// (set) Token: 0x0600031E RID: 798 RVA: 0x0000D506 File Offset: 0x0000B706
		public string Username { get; set; }

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x0600031F RID: 799 RVA: 0x0000D50F File Offset: 0x0000B70F
		// (set) Token: 0x06000320 RID: 800 RVA: 0x0000D517 File Offset: 0x0000B717
		public ControlCenter FrmControlCenter { get; set; }

		// Token: 0x06000321 RID: 801 RVA: 0x00028B7C File Offset: 0x00026D7C
		public Main(int formSpawned)
		{
			int num = (int)Math.Truncate(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds);
			if (Math.Abs(num - formSpawned) > 10)
			{
				LogManager.AddEntry(string.Format(<Module>.smethod_26<string>(3063321483U), Math.Abs(num - formSpawned)), null);
				Application.Exit();
			}
			this.InitializeComponent();
			base.Hide();
			this._ffGenerator.PropertyChanged += this._ffGenerator_PropertyChanged;
		}

		// Token: 0x06000322 RID: 802 RVA: 0x00028C5C File Offset: 0x00026E5C
		public void ImportFileProfile(IWin32Window owner)
		{
			if (Main.smethod_3(this.ofd) == DialogResult.OK)
			{
				Main.smethod_4(this);
				this.SetStatus(<Module>.smethod_26<string>(2128832604U));
				Main.smethod_6(Main.smethod_5(this.FontList));
				Main.smethod_6(Main.smethod_5(this.PluginList));
				try
				{
					this._profileManager.ImportProfile(Main.smethod_7(this.ofd), this._ffGenerator);
					this.SetFormText(Main.smethod_10(Main.smethod_9(Main.smethod_8())), this.Username, Main.smethod_11(Main.smethod_7(this.ofd)));
				}
				catch (Exception ex)
				{
					for (;;)
					{
						IL_00C3:
						int num = 913061622;
						for (;;)
						{
							switch (num ^ 913061620)
							{
							case 0:
								goto IL_00C3;
							case 2:
								this.SetStatus(<Module>.smethod_26<string>(700368970U));
								num = 913061621;
								continue;
							}
							goto Block_6;
						}
					}
					Block_6:
					LogManager.AddEntry(<Module>.smethod_24<string>(928749030U), ex);
				}
				finally
				{
					Main.EnableControls(this);
					this.SetStatus(<Module>.smethod_23<string>(854798292U));
				}
			}
		}

		// Token: 0x06000323 RID: 803 RVA: 0x0000D520 File Offset: 0x0000B720
		public void ImportTextProfile()
		{
			new frmProfileText(delegate(string profileText)
			{
				try
				{
					Main.smethod_6(Main.smethod_5(this.FontList));
					Main.smethod_6(Main.smethod_5(this.PluginList));
					this._profileManager.ImportTextProfile(profileText, this._ffGenerator);
					this.SetStatus(<Module>.smethod_25<string>(4188340627U));
				}
				catch (Exception ex)
				{
					this.SetStatus(<Module>.smethod_25<string>(2100417037U));
					for (;;)
					{
						IL_0087:
						int num = -1288977971;
						for (;;)
						{
							switch (num ^ -1288977969)
							{
							case 0:
								goto IL_0087;
							case 2:
								LogManager.AddEntry(<Module>.smethod_27<string>(733343039U), ex);
								num = -1288977970;
								continue;
							}
							goto Block_4;
						}
					}
					Block_4:;
				}
				finally
				{
					if (!Main.smethod_130(this))
					{
						Main.smethod_131(this, this.FrmControlCenter);
					}
				}
			});
		}

		// Token: 0x06000324 RID: 804 RVA: 0x00028D78 File Offset: 0x00026F78
		private void SetStatus(string text)
		{
			if (Main.smethod_12(this.lblStatus))
			{
				Main.UpdateStatusDelegate updateStatusDelegate = new Main.UpdateStatusDelegate(this.SetStatus);
				this.method_0(updateStatusDelegate, new object[] { text });
				return;
			}
			Main.smethod_13(this.lblStatus, text);
		}

		// Token: 0x06000325 RID: 805 RVA: 0x00028DC0 File Offset: 0x00026FC0
		private void GlobalMouseEnter(object sender, EventArgs e)
		{
			Control control = sender as Control;
			if (control != null && Main.smethod_14(control) != null)
			{
				Main.smethod_13(this.lblHelp, Main.smethod_15(control) as string);
			}
		}

		// Token: 0x06000326 RID: 806 RVA: 0x0000D534 File Offset: 0x0000B734
		private void GlobalMouseLeave(object sender, EventArgs e)
		{
			Main.smethod_13(this.lblHelp, "");
		}

		// Token: 0x06000327 RID: 807 RVA: 0x00028DF8 File Offset: 0x00026FF8
		private void _ffGenerator_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			string text = Main.smethod_16(e);
			if (Main.smethod_17(text, <Module>.smethod_25<string>(1918415303U)))
			{
				Main.smethod_18(this.PluginList);
				if (this._ffGenerator.PluginList.Count < 1)
				{
					Main.smethod_6(Main.smethod_5(this.PluginList));
					using (List<BrowserPluginInfo>.Enumerator enumerator = this._defaultPlugins.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							BrowserPluginInfo browserPluginInfo = enumerator.Current;
							Main.smethod_19(Main.smethod_5(this.PluginList), browserPluginInfo);
						}
						goto IL_0292;
					}
				}
				for (int i = 0; i < this._ffGenerator.PluginList.Count; i++)
				{
					if (!Main.smethod_20(Main.smethod_5(this.PluginList), this._ffGenerator.PluginList[i]))
					{
						Main.smethod_23(Main.smethod_5(this.PluginList), this._ffGenerator.PluginList[i], true);
					}
					else
					{
						int num = Main.smethod_21(Main.smethod_5(this.PluginList), this._ffGenerator.PluginList[i]);
						Main.smethod_22(this.PluginList, num, true);
					}
				}
				IL_0292:
				Main.smethod_24(this.PluginList);
				this._ffGenerator.IsProfileImported = false;
				return;
			}
			if (!Main.smethod_17(text, <Module>.smethod_23<string>(664909159U)))
			{
				return;
			}
			Main.smethod_18(this.FontList);
			if (this._ffGenerator.FontList.Count < 1)
			{
				Main.smethod_6(Main.smethod_5(this.FontList));
				using (List<string>.Enumerator enumerator2 = this._defaultFonts.GetEnumerator())
				{
					while (enumerator2.MoveNext())
					{
						string text2 = enumerator2.Current;
						Main.smethod_19(Main.smethod_5(this.FontList), text2);
						Main.smethod_26(Main.smethod_25(this.BrowserCanvasFont), text2);
					}
					goto IL_0159;
				}
			}
			for (int j = 0; j < this._ffGenerator.FontList.Count; j++)
			{
				if (Main.smethod_20(Main.smethod_5(this.FontList), this._ffGenerator.FontList[j]))
				{
					int num2 = Main.smethod_21(Main.smethod_5(this.FontList), this._ffGenerator.FontList[j]);
					Main.smethod_22(this.FontList, num2, true);
				}
				else
				{
					Main.smethod_23(Main.smethod_5(this.FontList), this._ffGenerator.FontList[j], true);
				}
			}
			IL_0159:
			Main.smethod_24(this.FontList);
			this._ffGenerator.IsProfileImported = false;
		}

		// Token: 0x06000328 RID: 808 RVA: 0x000290CC File Offset: 0x000272CC
		private void InitializeGui()
		{
			Main.smethod_28(Main.smethod_27(this.lblStatus));
			Main.smethod_28(Main.smethod_27(this.AdvancedUseragent));
			Main.smethod_28(Main.smethod_27(this.AdvancedStartpage));
			Main.smethod_28(Main.smethod_27(this.AdvancedDisableDeviceFontEnumeration));
			Main.smethod_28(Main.smethod_27(this.AdvancedAVHardwareDisable));
			Main.smethod_28(Main.smethod_27(this.OSVersion));
			Main.smethod_28(Main.smethod_27(this.OSPlatform));
			Main.smethod_28(Main.smethod_27(this.OSLanguage));
			Main.smethod_28(Main.smethod_27(this.OSTimezone));
			Main.smethod_28(Main.smethod_27(this.OSResolution));
			Main.smethod_28(Main.smethod_27(this.BrowserVersion));
			Main.smethod_28(Main.smethod_27(this.BrowserProduct));
			Main.smethod_28(Main.smethod_27(this.BrowserFlash));
			Main.smethod_28(Main.smethod_27(this.BrowserCanvasStroke));
			Main.smethod_28(Main.smethod_27(this.BrowserCanvasFill));
			Main.smethod_28(Main.smethod_27(this.BrowserCanvasFont));
			Main.smethod_28(Main.smethod_27(this.BrowserCanvasFontSize));
			Main.smethod_28(Main.smethod_27(this.cbEnableFont));
			Main.smethod_29(Main.smethod_27(this.lblStatus), <Module>.smethod_23<string>(293767161U), this._ffGenerator, <Module>.smethod_25<string>(1013648414U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_29(Main.smethod_27(this.AdvancedUseragent), <Module>.smethod_23<string>(293767161U), this._ffGenerator, <Module>.smethod_24<string>(3397606459U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_29(Main.smethod_27(this.AdvancedStartpage), <Module>.smethod_23<string>(293767161U), this._ffGenerator, <Module>.smethod_23<string>(2767053804U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_29(Main.smethod_27(this.AdvancedDisableDeviceFontEnumeration), <Module>.smethod_23<string>(62857159U), this._ffGenerator, <Module>.smethod_25<string>(2336000021U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_29(Main.smethod_27(this.AdvancedAVHardwareDisable), <Module>.smethod_26<string>(1462482757U), this._ffGenerator, <Module>.smethod_23<string>(3346899060U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_30(this.OSVersion, this._ffGenerator.StaticData.OsVersionBindingSource);
			Main.smethod_31(this.OSVersion, <Module>.smethod_26<string>(2176714574U));
			Main.smethod_32(this.OSVersion, <Module>.smethod_25<string>(171763143U));
			Main.smethod_29(Main.smethod_27(this.OSVersion), <Module>.smethod_24<string>(1971877838U), this._ffGenerator, <Module>.smethod_24<string>(2016591343U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_30(this.OSPlatform, this._ffGenerator.StaticData.OsPlatformBindingSource);
			Main.smethod_31(this.OSPlatform, <Module>.smethod_27<string>(4235741554U));
			Main.smethod_32(this.OSPlatform, <Module>.smethod_27<string>(220504416U));
			Main.smethod_29(Main.smethod_27(this.OSPlatform), <Module>.smethod_24<string>(1971877838U), this._ffGenerator, <Module>.smethod_26<string>(3900465494U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_30(this.OSLanguage, this._ffGenerator.StaticData.OsLanguageBindingSource);
			Main.smethod_31(this.OSLanguage, <Module>.smethod_24<string>(2608526835U));
			Main.smethod_32(this.OSLanguage, <Module>.smethod_26<string>(2186290968U));
			Main.smethod_29(Main.smethod_27(this.OSLanguage), <Module>.smethod_23<string>(256138911U), this._ffGenerator, <Module>.smethod_23<string>(249250526U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_30(this.OSTimezone, this._ffGenerator.StaticData.OsTimezoneBindingSource);
			Main.smethod_31(this.OSTimezone, <Module>.smethod_24<string>(2608526835U));
			Main.smethod_32(this.OSTimezone, <Module>.smethod_24<string>(752438405U));
			Main.smethod_29(Main.smethod_27(this.OSTimezone), <Module>.smethod_23<string>(256138911U), this._ffGenerator, <Module>.smethod_23<string>(1140402786U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_30(this.OSResolution, this._ffGenerator.StaticData.OsResolutionBindingSource);
			Main.smethod_31(this.OSResolution, <Module>.smethod_23<string>(623888290U));
			Main.smethod_32(this.OSResolution, <Module>.smethod_27<string>(220504416U));
			Main.smethod_29(Main.smethod_27(this.OSResolution), <Module>.smethod_26<string>(43595517U), this._ffGenerator, <Module>.smethod_26<string>(3919618282U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_29(Main.smethod_27(this.BrowserVersion), <Module>.smethod_24<string>(4004276893U), this._ffGenerator, <Module>.smethod_25<string>(3539231512U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_30(this.BrowserProduct, this._ffGenerator.StaticData.BrowserProductBindingSource);
			Main.smethod_34(Main.smethod_27(this.BrowserProduct), Main.smethod_33(<Module>.smethod_24<string>(4004276893U), this._ffGenerator, <Module>.smethod_25<string>(2773659529U), false, DataSourceUpdateMode.OnPropertyChanged));
			Main.smethod_30(this.BrowserFlash, this._ffGenerator.StaticData.BrowserFlashBindingSource);
			Main.smethod_29(Main.smethod_27(this.BrowserFlash), <Module>.smethod_24<string>(4004276893U), this._ffGenerator, <Module>.smethod_25<string>(3191244247U), false, DataSourceUpdateMode.OnPropertyChanged);
			this._ffGenerator.BrowserFlash = <Module>.smethod_25<string>(1411158342U);
			Main.smethod_29(Main.smethod_27(this.BrowserCanvasStroke), <Module>.smethod_26<string>(1452906363U), this._ffGenerator, <Module>.smethod_26<string>(1091420196U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_29(Main.smethod_27(this.BrowserCanvasFill), <Module>.smethod_27<string>(453612881U), this._ffGenerator, <Module>.smethod_25<string>(3608828965U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_29(Main.smethod_27(this.BrowserCanvasFont), <Module>.smethod_26<string>(767403728U), this._ffGenerator, <Module>.smethod_23<string>(1296056288U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_29(Main.smethod_27(this.BrowserCanvasFontSize), <Module>.smethod_23<string>(1552668800U), this._ffGenerator, <Module>.smethod_26<string>(909468710U), false, DataSourceUpdateMode.OnPropertyChanged);
			Main.smethod_29(Main.smethod_27(this.cbEnableFont), <Module>.smethod_27<string>(4282363247U), this._ffGenerator, <Module>.smethod_25<string>(2753584739U), false, DataSourceUpdateMode.OnPropertyChanged);
			this.SetFormText(Main.smethod_10(Main.smethod_9(Main.smethod_8())), this.Username, null);
			Main.smethod_6(Main.smethod_5(this.FontList));
			Main.smethod_35(Main.smethod_25(this.BrowserCanvasFont));
			foreach (string text in this._defaultFonts)
			{
				Main.smethod_19(Main.smethod_5(this.FontList), text);
				Main.smethod_26(Main.smethod_25(this.BrowserCanvasFont), text);
			}
			Main.smethod_6(Main.smethod_5(this.PluginList));
			foreach (BrowserPluginInfo browserPluginInfo in this._defaultPlugins)
			{
				Main.smethod_19(Main.smethod_5(this.PluginList), browserPluginInfo);
			}
		}

		// Token: 0x06000329 RID: 809 RVA: 0x000297D0 File Offset: 0x000279D0
		private void SetFormText(Version version, string user, string profileFileName = null)
		{
			if (this.method_1())
			{
				Main.SetFormTextDelegate setFormTextDelegate = new Main.SetFormTextDelegate(this.SetFormText);
				this.method_0(setFormTextDelegate, new object[] { version, user, profileFileName });
				return;
			}
			if (!Main.smethod_36(profileFileName))
			{
				Main.smethod_13(this, Main.smethod_38(<Module>.smethod_26<string>(2205443756U), version, user, profileFileName));
				return;
			}
			Main.smethod_13(this, Main.smethod_37(<Module>.smethod_27<string>(1176024436U), version, user));
		}

		// Token: 0x0600032A RID: 810 RVA: 0x00029848 File Offset: 0x00027A48
		private void Main_Load(object sender, EventArgs e)
		{
			this.SetFormText(Main.smethod_10(Main.smethod_9(Main.smethod_8())), this.Username, null);
			LogManager.AddEntry(Main.smethod_37(<Module>.smethod_24<string>(3651655643U), Main.smethod_10(Main.smethod_9(Main.smethod_8())), this.Username), null);
			this.SetStatus("");
			if (Main.smethod_40(Main.smethod_39(<Module>.smethod_27<string>(4031490789U), <Module>.smethod_27<string>(4090104935U))))
			{
				try
				{
					this._defaultFonts = Main.DeserializeList<string>(Main.smethod_39(<Module>.smethod_25<string>(60687486U), <Module>.smethod_23<string>(1887930431U)));
				}
				catch (Exception ex)
				{
					this.SetStatus(<Module>.smethod_24<string>(1139610746U));
					LogManager.AddEntry(<Module>.smethod_25<string>(2706719324U), ex);
				}
			}
			if (Main.smethod_40(Main.smethod_39(<Module>.smethod_27<string>(4031490789U), <Module>.smethod_24<string>(380509685U))))
			{
				try
				{
					this._defaultPlugins = (from x in Main.DeserializeList<BrowserPluginInfo>(Main.smethod_39(<Module>.smethod_23<string>(885538157U), <Module>.smethod_24<string>(380509685U)))
						orderby x.Name
						select x).Distinct<BrowserPluginInfo>().ToList<BrowserPluginInfo>();
				}
				catch (Exception ex2)
				{
					for (;;)
					{
						IL_017F:
						int num = 100853159;
						for (;;)
						{
							switch (num ^ 100853156)
							{
							case 0:
								goto IL_017F;
							case 2:
								LogManager.AddEntry(<Module>.smethod_26<string>(935781087U), ex2);
								num = 100853157;
								continue;
							case 3:
								this.SetStatus(<Module>.smethod_25<string>(3959473478U));
								num = 100853158;
								continue;
							}
							goto Block_8;
						}
					}
					Block_8:;
				}
			}
			this._frmNotes = null;
			this.InitializeGui();
		}

		// Token: 0x0600032B RID: 811 RVA: 0x0000D546 File Offset: 0x0000B746
		private void Main_KeyDown(object sender, KeyEventArgs e)
		{
			if (Main.smethod_41(e) && Main.smethod_42(e) == Keys.L)
			{
				LogManager.ShowLogWindow();
			}
		}

		// Token: 0x0600032C RID: 812 RVA: 0x00029A08 File Offset: 0x00027C08
		private void Main_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (Main.smethod_43(<Module>.smethod_26<string>(3097629326U), <Module>.smethod_27<string>(2242551835U), MessageBoxButtons.YesNo) != DialogResult.Yes)
			{
				Main.smethod_44(e, true);
				return;
			}
			frmNotes frmNotes = this._frmNotes;
			if (frmNotes != null)
			{
				Main.smethod_45(frmNotes);
			}
			try
			{
				this.SetStatus(<Module>.smethod_25<string>(917260336U));
				FontManager.RemoveFont(Main.smethod_46(Main.smethod_39(this._currentPath, <Module>.smethod_24<string>(1159426895U)), <Module>.smethod_25<string>(3652964417U)));
				this.CleanUp();
				this._ffGenerator.Erase();
				this.InitializeGui();
				Main.smethod_47(this.fillDemo, Color.Transparent);
				Main.smethod_47(this.strokeDemo, Color.Transparent);
				Main.smethod_48(this.BrowserProduct, 0);
				this.SetStatus(<Module>.smethod_26<string>(1688318480U));
			}
			catch (Exception ex)
			{
				this.SetStatus(<Module>.smethod_26<string>(974086663U));
				LogManager.AddEntry(<Module>.smethod_23<string>(3919959078U), ex);
			}
			DateTime dateTime = DateTime.Now.AddMonths(-1);
			foreach (FileInfo fileInfo in new DirectoryInfo(Path.Combine(this._currentPath, <Module>.smethod_24<string>(1159426895U))).GetFiles())
			{
				try
				{
					if (fileInfo.LastAccessTime < dateTime)
					{
						fileInfo.Delete();
					}
				}
				catch (Exception)
				{
				}
			}
			if (this.FrmControlCenter.Visible)
			{
				e.Cancel = true;
				this.FrmControlCenter.Focus();
				base.Hide();
				return;
			}
			Environment.Exit(0);
		}

		// Token: 0x0600032D RID: 813 RVA: 0x00029BB0 File Offset: 0x00027DB0
		private void btnStart_Click(object sender, EventArgs e)
		{
			if (Main.smethod_49(<Module>.smethod_27<string>(2038750443U)).Length != 0)
			{
				this.SetStatus(<Module>.smethod_27<string>(1992128750U));
				return;
			}
			if (!this._ffGenerator.CheckProperties())
			{
				this.SetStatus(<Module>.smethod_25<string>(1781877645U));
				return;
			}
			Main.DisableControls(this);
			Main.smethod_50(this.bgwBrowser);
		}

		// Token: 0x0600032E RID: 814 RVA: 0x00029C10 File Offset: 0x00027E10
		private void BrowserProduct_SelectedValueChanged(object sender, EventArgs e)
		{
			Main.smethod_51(this.BrowserProduct);
			if (Main.smethod_52(this.BrowserProduct) != null)
			{
				string text = Main.smethod_52(this.BrowserProduct) as string;
				if (!Main.smethod_36(text) && this._ffGenerator.StaticData.BrowserVersion.ContainsKey(text))
				{
					BindingSource bindingSource = Main.smethod_53(this._ffGenerator.StaticData.BrowserVersion[text], null);
					Main.smethod_30(this.BrowserVersion, bindingSource);
					this._ffGenerator.BrowserVersion = (string)Main.smethod_52(this.BrowserVersion);
					this._ffGenerator.BrowserProduct = text;
				}
			}
			Main.smethod_54(this.BrowserProduct);
		}

		// Token: 0x0600032F RID: 815 RVA: 0x00029CC4 File Offset: 0x00027EC4
		private void OSRandomize_Click(object sender, EventArgs e)
		{
			Random random = Main.smethod_55();
			Main.smethod_48(this.OSVersion, Main.smethod_57(random, 0, Main.smethod_56(Main.smethod_25(this.OSVersion))));
			Main.smethod_48(this.OSPlatform, Main.smethod_57(random, 0, Main.smethod_56(Main.smethod_25(this.OSPlatform))));
			Main.smethod_48(this.OSLanguage, Main.smethod_57(random, 0, Main.smethod_56(Main.smethod_25(this.OSLanguage))));
			Main.smethod_48(this.OSTimezone, Main.smethod_57(random, 0, Main.smethod_56(Main.smethod_25(this.OSTimezone))));
			Main.smethod_48(this.OSResolution, Main.smethod_57(random, 0, Main.smethod_56(Main.smethod_25(this.OSResolution))));
		}

		// Token: 0x06000330 RID: 816 RVA: 0x00029D84 File Offset: 0x00027F84
		private void BrowserRandomize_Click(object sender, EventArgs e)
		{
			Random random = Main.smethod_55();
			Main.smethod_51(this.BrowserProduct);
			Main.smethod_48(this.BrowserProduct, Main.smethod_57(random, 0, Main.smethod_56(Main.smethod_25(this.BrowserProduct))));
			Main.smethod_48(this.BrowserFlash, Main.smethod_57(random, 0, Main.smethod_56(Main.smethod_25(this.BrowserFlash))));
			Main.smethod_54(this.BrowserProduct);
			this._ffGenerator.BrowserCanvasStroke = Main.smethod_59(<Module>.smethod_23<string>(534958167U), Main.smethod_58(random, 16777216));
			this._ffGenerator.BrowserCanvasFill = Main.smethod_59(<Module>.smethod_25<string>(3382619064U), Main.smethod_58(random, 16777216));
			this._ffGenerator.BrowserCanvasFontSize = Main.smethod_57(random, 5, 25);
			this._ffGenerator.BrowserCanvasFont = Main.smethod_61(Main.smethod_60(Main.smethod_25(this.BrowserCanvasFont), Main.smethod_57(random, 0, Main.smethod_56(Main.smethod_25(this.BrowserCanvasFont)))));
			Main.smethod_48(this.BrowserVersion, Main.smethod_57(random, 0, Main.smethod_56(Main.smethod_25(this.BrowserVersion))));
		}

		// Token: 0x06000331 RID: 817 RVA: 0x0000D55F File Offset: 0x0000B75F
		private void BrowserFlash_SelectedIndexChanged(object sender, EventArgs e)
		{
			this._ffGenerator.BrowserFlash = Main.smethod_52(this.BrowserFlash) as string;
		}

		// Token: 0x06000332 RID: 818 RVA: 0x00029EB4 File Offset: 0x000280B4
		private void btnFontAll_Click(object sender, EventArgs e)
		{
			for (int i = 0; i < Main.smethod_62(Main.smethod_5(this.FontList)); i++)
			{
				Main.smethod_22(this.FontList, i, this._fontsListChecked);
			}
			this._fontsListChecked = !this._fontsListChecked;
		}

		// Token: 0x06000333 RID: 819 RVA: 0x00029F00 File Offset: 0x00028100
		private void btnPluginAll_Click(object sender, EventArgs e)
		{
			for (int i = 0; i < Main.smethod_62(Main.smethod_5(this.PluginList)); i++)
			{
				Main.smethod_22(this.PluginList, i, this._pluginListChecked);
			}
			this._pluginListChecked = !this._pluginListChecked;
		}

		// Token: 0x06000334 RID: 820 RVA: 0x0000D57C File Offset: 0x0000B77C
		private void FontRandomize_Click(object sender, EventArgs e)
		{
			new frmRandomParameters(false, delegate(int number, string os)
			{
				IEnumerable<int> enumerable = Main.Shuffle<int>(Main.smethod_132(0, Main.smethod_62(Main.smethod_5(this.FontList))).ToList<int>()).Take(number);
				for (int i = 0; i < Main.smethod_62(Main.smethod_5(this.FontList)); i++)
				{
					Main.smethod_22(this.FontList, i, enumerable.Contains(i));
				}
			});
		}

		// Token: 0x06000335 RID: 821 RVA: 0x0000D591 File Offset: 0x0000B791
		private void PluginRandomize_Click(object sender, EventArgs e)
		{
			new frmRandomParameters(true, delegate(int number, string os)
			{
				List<BrowserPluginInfo> list = Main.smethod_5(this.PluginList).OfType<BrowserPluginInfo>().Where(delegate(BrowserPluginInfo x)
				{
					if (Main.<>c__DisplayClass41_0.smethod_0(os, <Module>.smethod_26<string>(1588556807U)))
					{
						return !Main.<>c__DisplayClass41_0.smethod_1(x.Filename, <Module>.smethod_25<string>(3580782431U));
					}
					return Main.<>c__DisplayClass41_0.smethod_1(x.Filename, <Module>.smethod_27<string>(1005054792U));
				})
					.ToList<BrowserPluginInfo>();
				list = Main.Shuffle<BrowserPluginInfo>(list).Take(number).ToList<BrowserPluginInfo>();
				for (int i = 0; i < Main.smethod_62(Main.smethod_5(this.PluginList)); i++)
				{
					Main.smethod_22(this.PluginList, i, list.Contains((BrowserPluginInfo)Main.smethod_67(Main.smethod_5(this.PluginList), i)));
				}
			});
		}

		// Token: 0x06000336 RID: 822 RVA: 0x0000D5A6 File Offset: 0x0000B7A6
		private void btnNotes_Click(object sender, EventArgs e)
		{
			if (this._frmNotes != null)
			{
				Main.smethod_63(this._frmNotes);
				return;
			}
			this._frmNotes = new frmNotes(this._ffGenerator.ProfileNotes, delegate(string newText)
			{
				this._ffGenerator.ProfileNotes = newText;
			});
		}

		// Token: 0x06000337 RID: 823 RVA: 0x00029F4C File Offset: 0x0002814C
		private void PluginList_ItemCheck(object sender, ItemCheckEventArgs e)
		{
			if (Main.smethod_64(e) == CheckState.Checked && Main.smethod_65(e) == CheckState.Unchecked)
			{
				this._ffGenerator.PluginList.Remove((BrowserPluginInfo)Main.smethod_67(Main.smethod_5(this.PluginList), Main.smethod_66(e)));
				return;
			}
			if (Main.smethod_64(e) == CheckState.Unchecked && Main.smethod_65(e) == CheckState.Checked)
			{
				this._ffGenerator.PluginList.Add((BrowserPluginInfo)Main.smethod_67(Main.smethod_5(this.PluginList), Main.smethod_66(e)));
			}
		}

		// Token: 0x06000338 RID: 824 RVA: 0x00029FD4 File Offset: 0x000281D4
		private void FontList_ItemCheck(object sender, ItemCheckEventArgs e)
		{
			if (Main.smethod_64(e) == CheckState.Checked && Main.smethod_65(e) == CheckState.Unchecked)
			{
				this._ffGenerator.FontList.Remove((string)Main.smethod_67(Main.smethod_5(this.FontList), Main.smethod_66(e)));
				return;
			}
			if (Main.smethod_64(e) == CheckState.Unchecked && Main.smethod_65(e) == CheckState.Checked)
			{
				this._ffGenerator.FontList.Add((string)Main.smethod_67(Main.smethod_5(this.FontList), Main.smethod_66(e)));
			}
		}

		// Token: 0x06000339 RID: 825 RVA: 0x0000D5DE File Offset: 0x0000B7DE
		private void btnFontAdd_Click(object sender, EventArgs e)
		{
			new frmNewFont(delegate(string name)
			{
				Main.smethod_133(Main.smethod_5(this.FontList), name, CheckState.Checked);
			});
		}

		// Token: 0x0600033A RID: 826 RVA: 0x0000D5F2 File Offset: 0x0000B7F2
		private void btnFontDelete_Click(object sender, EventArgs e)
		{
			if (Main.smethod_69(Main.smethod_68(this.FontList)) > 0)
			{
				Main.smethod_70(Main.smethod_5(this.FontList), Main.smethod_68(this.FontList));
			}
		}

		// Token: 0x0600033B RID: 827 RVA: 0x0000D622 File Offset: 0x0000B822
		private void btnPluginAdd_Click(object sender, EventArgs e)
		{
			new frmNewPlugin(delegate(string name, string description, string filename, string mime)
			{
				Main.smethod_133(Main.smethod_5(this.PluginList), new BrowserPluginInfo
				{
					Name = name,
					Description = description,
					Filename = filename,
					MimeType = new List<string> { mime }
				}, CheckState.Checked);
			});
		}

		// Token: 0x0600033C RID: 828 RVA: 0x0000D636 File Offset: 0x0000B836
		private void btnPluginDelete_Click(object sender, EventArgs e)
		{
			if (Main.smethod_69(Main.smethod_68(this.PluginList)) > 0)
			{
				Main.smethod_70(Main.smethod_5(this.PluginList), Main.smethod_68(this.PluginList));
			}
		}

		// Token: 0x0600033D RID: 829 RVA: 0x0000D666 File Offset: 0x0000B866
		private void AdvancedUseragent_TextChanged(object sender, EventArgs e)
		{
			this._ffGenerator.AdvancedUserAgent = Main.smethod_71(this.AdvancedUseragent);
		}

		// Token: 0x0600033E RID: 830 RVA: 0x0000D67E File Offset: 0x0000B87E
		private void AdvancedStartpage_TextChanged(object sender, EventArgs e)
		{
			this._ffGenerator.StartPage = Main.smethod_71(this.AdvancedStartpage);
		}

		// Token: 0x0600033F RID: 831 RVA: 0x0002A05C File Offset: 0x0002825C
		private void bgw_DoWork(object sender, DoWorkEventArgs e)
		{
			try
			{
				this.SetStatus(<Module>.smethod_27<string>(2359330754U));
				TimezoneManager.SetTimeZone(this._ffGenerator.OsTimezone);
			}
			catch (Exception ex)
			{
				this.SetStatus(<Module>.smethod_25<string>(3800203782U));
				LogManager.AddEntry(<Module>.smethod_24<string>(595943929U), ex);
				return;
			}
			try
			{
				this.SetStatus(<Module>.smethod_25<string>(757990640U));
				this._ffGenerator.GenerateFlashConfig(Main.smethod_73(Main.smethod_72(), <Module>.smethod_25<string>(1314770264U), <Module>.smethod_23<string>(322862290U), <Module>.smethod_23<string>(2934736193U)));
			}
			catch (Exception ex2)
			{
				for (;;)
				{
					IL_00DD:
					int num = -2066362725;
					for (;;)
					{
						switch (num ^ -2066362727)
						{
						case 0:
							goto IL_00DD;
						case 2:
							this.SetStatus(<Module>.smethod_23<string>(1077175173U));
							num = -2066362726;
							continue;
						case 3:
							LogManager.AddEntry(<Module>.smethod_27<string>(1747477205U), ex2);
							num = -2066362728;
							continue;
						}
						goto Block_18;
					}
				}
				Block_18:
				return;
			}
			try
			{
				this.SetStatus(<Module>.smethod_25<string>(2527374838U));
				this._ffGenerator.GenerateFlashMmsConfig(Main.smethod_73(Main.smethod_72(), <Module>.smethod_26<string>(2306786357U), <Module>.smethod_25<string>(1105977905U), <Module>.smethod_25<string>(3014557009U)));
			}
			catch (Exception ex3)
			{
				this.SetStatus(<Module>.smethod_25<string>(1732354982U));
				LogManager.AddEntry(<Module>.smethod_24<string>(2966229292U), ex3);
				return;
			}
			try
			{
				this.SetStatus(<Module>.smethod_23<string>(3683908574U));
				this._ffGenerator.GenerateCanvasConfig(Main.smethod_73(this._currentPath, <Module>.smethod_27<string>(488691494U), <Module>.smethod_23<string>(3646280324U), <Module>.smethod_27<string>(162339643U)));
			}
			catch (Exception ex4)
			{
				this.SetStatus(<Module>.smethod_26<string>(1898999148U));
				for (;;)
				{
					IL_01DF:
					int num2 = -2066362725;
					for (;;)
					{
						switch (num2 ^ -2066362727)
						{
						case 0:
							goto IL_01DF;
						case 2:
							LogManager.AddEntry(<Module>.smethod_27<string>(3478251386U), ex4);
							num2 = -2066362728;
							continue;
						}
						goto Block_23;
					}
				}
				Block_23:
				return;
			}
			try
			{
				this.SetStatus(<Module>.smethod_24<string>(1854506981U));
				this._ffGenerator.GenerateHeadersConfig(Main.smethod_73(this._currentPath, <Module>.smethod_23<string>(2330936310U), <Module>.smethod_27<string>(22474564U), <Module>.smethod_25<string>(2159312783U)));
			}
			catch (Exception ex5)
			{
				for (;;)
				{
					IL_0277:
					int num3 = -2066362728;
					for (;;)
					{
						switch (num3 ^ -2066362727)
						{
						case 1:
							this.SetStatus(<Module>.smethod_26<string>(3174240478U));
							LogManager.AddEntry(<Module>.smethod_24<string>(2897635789U), ex5);
							num3 = -2066362727;
							continue;
						case 2:
							goto IL_0277;
						}
						goto Block_26;
					}
				}
				Block_26:
				return;
			}
			try
			{
				this.SetStatus(<Module>.smethod_23<string>(1345713425U));
				this._ffGenerator.GenerateJsOverrideConfig(Main.smethod_73(this._currentPath, <Module>.smethod_26<string>(3308309994U), <Module>.smethod_26<string>(3317886388U), <Module>.smethod_25<string>(4247236373U)));
			}
			catch (Exception ex6)
			{
				this.SetStatus(<Module>.smethod_27<string>(2773154451U));
				for (;;)
				{
					IL_030F:
					int num4 = -2066362728;
					for (;;)
					{
						switch (num4 ^ -2066362727)
						{
						case 1:
							LogManager.AddEntry(<Module>.smethod_25<string>(1065828325U), ex6);
							num4 = -2066362727;
							continue;
						case 2:
							goto IL_030F;
						}
						goto Block_29;
					}
				}
				Block_29:
				return;
			}
			try
			{
				this.SetStatus(<Module>.smethod_27<string>(3543086445U));
				FontManager.InitInjection(Main.smethod_74(this.FontList).Cast<string>().ToList<string>());
			}
			catch (Exception ex7)
			{
				for (;;)
				{
					IL_0399:
					int num5 = -2066362726;
					for (;;)
					{
						switch (num5 ^ -2066362727)
						{
						case 0:
							goto IL_0399;
						case 1:
							LogManager.AddEntry(<Module>.smethod_27<string>(2797139357U), ex7);
							num5 = -2066362725;
							continue;
						case 3:
							this.SetStatus(<Module>.smethod_25<string>(1894354641U));
							num5 = -2066362728;
							continue;
						}
						goto Block_32;
					}
				}
				Block_32:;
			}
			int width = Main.smethod_76(Main.smethod_75()).Width;
			int height = Screen.PrimaryScreen.Bounds.Height;
			List<string> list = new List<string>();
			ProcessWindowStyle processWindowStyle;
			if (this._ffGenerator.OsResolution.Width < width && this._ffGenerator.OsResolution.Height < height)
			{
				processWindowStyle = ProcessWindowStyle.Normal;
				list.Add(string.Format(<Module>.smethod_27<string>(2564030892U), this._ffGenerator.OsResolution.Width));
				list.Add(string.Format(<Module>.smethod_24<string>(2693381317U), this._ffGenerator.OsResolution.Height));
				this.SetStatus(string.Format(<Module>.smethod_25<string>(3703888419U), this._ffGenerator.OsResolution.Width, this._ffGenerator.OsResolution.Height));
			}
			else
			{
				processWindowStyle = ProcessWindowStyle.Maximized;
				list.Add(string.Format(<Module>.smethod_27<string>(2564030892U), width));
				list.Add(string.Format(<Module>.smethod_24<string>(2693381317U), height - 50));
				this.SetStatus(<Module>.smethod_27<string>(1818083804U));
			}
			string text = ConfigManager.UserConfigFile.GetValue<string>(<Module>.smethod_27<string>(1305245181U), <Module>.smethod_27<string>(1491731953U), <Module>.smethod_26<string>(2333098734U));
			text = text.Replace(<Module>.smethod_24<string>(132050387U), string.Join(<Module>.smethod_23<string>(4219134048U), list));
			Process process = new Process
			{
				StartInfo = 
				{
					FileName = ConfigManager.UserConfigFile.GetValue<string>(<Module>.smethod_25<string>(452882918U), <Module>.smethod_26<string>(3771138762U), Path.Combine(this._currentPath, <Module>.smethod_26<string>(1638019705U))),
					WorkingDirectory = ConfigManager.UserConfigFile.GetValue<string>(<Module>.smethod_23<string>(909389637U), <Module>.smethod_26<string>(3076059733U), Path.Combine(new string[] { this._currentPath })),
					Arguments = text,
					WindowStyle = processWindowStyle
				}
			};
			LogManager.AddEntry(string.Format(<Module>.smethod_26<string>(933364282U), process.StartInfo.FileName, process.StartInfo.Arguments, process.StartInfo.WorkingDirectory), null);
			if (File.Exists(process.StartInfo.FileName))
			{
				process.Start();
				Thread.Sleep(4000);
				this.SetStatus(<Module>.smethod_27<string>(786635018U));
				bool flag = true;
				DateTime dateTime = DateTime.MinValue;
				while (flag)
				{
					if (this._ffGenerator.EnableFontSpoofing && dateTime < DateTime.Now.AddSeconds(-20.0) && Process.GetProcessesByName(<Module>.smethod_26<string>(981246252U)).Length != 0)
					{
						try
						{
							this.SetStatus(<Module>.smethod_24<string>(3315295372U));
							FontManager.InjectFonts();
							dateTime = DateTime.Now;
							this.SetStatus(<Module>.smethod_24<string>(3261436811U));
						}
						catch (Exception ex8)
						{
							for (;;)
							{
								IL_071E:
								int num6 = -2066362725;
								for (;;)
								{
									switch (num6 ^ -2066362727)
									{
									case 0:
										goto IL_071E;
									case 2:
										this.SetStatus(<Module>.smethod_23<string>(1413978393U));
										num6 = -2066362728;
										continue;
									}
									goto Block_35;
								}
							}
							Block_35:
							LogManager.AddEntry(<Module>.smethod_23<string>(267961504U), ex8);
						}
					}
					flag = Process.GetProcessesByName(<Module>.smethod_26<string>(3859743113U)).Length != 0;
					Thread.Sleep(200);
				}
				return;
			}
			this.SetStatus(<Module>.smethod_24<string>(876416506U));
		}

		// Token: 0x06000340 RID: 832 RVA: 0x0002A83C File Offset: 0x00028A3C
		private void bgwBrowser_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			this.SetStatus(<Module>.smethod_26<string>(516000679U));
			bool flag = !Main.smethod_36(this._ffGenerator.ImportedProfilePath);
			if (this._frmNotes != null && Main.smethod_77(this._frmNotes))
			{
				Main.smethod_78(this._frmNotes);
			}
			if ((flag && Main.smethod_79(Main.smethod_59(<Module>.smethod_23<string>(1776587270U), Main.smethod_11(this._ffGenerator.ImportedProfilePath)), <Module>.smethod_25<string>(954752668U), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) == DialogResult.Yes) || (!flag && Main.smethod_79(<Module>.smethod_23<string>(2493271903U), <Module>.smethod_23<string>(3940417939U), MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes))
			{
				this.SetStatus(<Module>.smethod_26<string>(573459043U));
				string text;
				if (!Main.smethod_36(this._ffGenerator.ImportedProfilePath))
				{
					text = this._ffGenerator.ImportedProfilePath;
				}
				else
				{
					if (Main.smethod_3(this.sfd) != DialogResult.OK)
					{
						return;
					}
					text = Main.smethod_7(this.sfd);
				}
				try
				{
					this._profileManager.ExportProfile(text, this._ffGenerator);
					this.SetStatus(<Module>.smethod_24<string>(2027262436U));
				}
				catch (Exception ex)
				{
					this.SetStatus(<Module>.smethod_26<string>(1105739374U));
					LogManager.AddEntry(<Module>.smethod_26<string>(3981819430U), ex);
				}
			}
			Main.EnableControls(this);
		}

		// Token: 0x06000341 RID: 833 RVA: 0x0002A9A0 File Offset: 0x00028BA0
		private void CleanUp()
		{
			IEnumerator<string> enumerator = new string[]
			{
				Main.smethod_73(this._currentPath, <Module>.smethod_25<string>(3849726445U), <Module>.smethod_23<string>(3646280324U), <Module>.smethod_26<string>(2562932190U)),
				Main.smethod_73(this._currentPath, <Module>.smethod_27<string>(488691494U), <Module>.smethod_23<string>(3646280324U), <Module>.smethod_27<string>(3251813207U)),
				Main.smethod_73(this._currentPath, <Module>.smethod_24<string>(1163999423U), <Module>.smethod_26<string>(3317886388U), <Module>.smethod_25<string>(1764532818U)),
				Main.smethod_73(this._currentPath, <Module>.smethod_23<string>(2330936310U), <Module>.smethod_27<string>(22474564U), <Module>.smethod_26<string>(4020125006U)),
				Main.smethod_73(this._currentPath, <Module>.smethod_25<string>(3849726445U), <Module>.smethod_25<string>(529123491U), <Module>.smethod_27<string>(2552487812U)),
				Main.smethod_73(this._currentPath, <Module>.smethod_25<string>(3849726445U), <Module>.smethod_24<string>(3602878289U), <Module>.smethod_23<string>(3558891790U)),
				Main.smethod_73(this._currentPath, <Module>.smethod_23<string>(2330936310U), <Module>.smethod_27<string>(22474564U), <Module>.smethod_24<string>(4044926549U)),
				Main.smethod_73(this._currentPath, <Module>.smethod_24<string>(1163999423U), <Module>.smethod_25<string>(529123491U), <Module>.smethod_23<string>(1894612522U)),
				Main.smethod_73(this._currentPath, <Module>.smethod_27<string>(488691494U), <Module>.smethod_25<string>(529123491U), <Module>.smethod_23<string>(1824496524U)),
				Main.smethod_73(this._currentPath, <Module>.smethod_26<string>(3308309994U), <Module>.smethod_24<string>(3602878289U), <Module>.smethod_25<string>(4247236373U)),
				Main.smethod_73(this._currentPath, <Module>.smethod_26<string>(3308309994U), <Module>.smethod_24<string>(3602878289U), <Module>.smethod_23<string>(629028792U)),
				Main.smethod_73(this._currentPath, <Module>.smethod_25<string>(3849726445U), <Module>.smethod_23<string>(3646280324U), <Module>.smethod_26<string>(1175190937U)),
				Main.smethod_73(this._currentPath, <Module>.smethod_25<string>(3849726445U), <Module>.smethod_26<string>(3317886388U), <Module>.smethod_23<string>(1263465393U)),
				Main.smethod_73(this._currentPath, <Module>.smethod_25<string>(3849726445U), <Module>.smethod_27<string>(22474564U), <Module>.smethod_27<string>(2593337965U)),
				Main.smethod_73(this._currentPath, <Module>.smethod_26<string>(3308309994U), <Module>.smethod_27<string>(22474564U), <Module>.smethod_25<string>(561301327U))
			}.Where(new Func<string, bool>(File.Exists)).GetEnumerator();
			try
			{
				while (Main.smethod_81(enumerator))
				{
					Main.smethod_80(enumerator.Current);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					Main.smethod_82(enumerator);
				}
			}
			FontManager.ClearCache();
			Main.EmptyDirectory(Main.smethod_84(Main.smethod_83(Environment.SpecialFolder.ApplicationData), <Module>.smethod_26<string>(2055383308U), <Module>.smethod_23<string>(527966635U)));
			Main.EmptyDirectory(Main.smethod_84(Main.smethod_83(Environment.SpecialFolder.ApplicationData), <Module>.smethod_27<string>(1940634263U), <Module>.smethod_26<string>(4207655153U)));
			Main.EmptyDirectory(Main.smethod_73(this._currentPath, <Module>.smethod_25<string>(3849726445U), <Module>.smethod_23<string>(3646280324U), <Module>.smethod_25<string>(1744458028U)));
			Main.EmptyDirectory(Main.smethod_73(this._currentPath, <Module>.smethod_25<string>(3849726445U), <Module>.smethod_23<string>(3646280324U), <Module>.smethod_26<string>(4226807941U)));
			Main.EmptyDirectory(Main.smethod_73(this._currentPath, <Module>.smethod_24<string>(1163999423U), <Module>.smethod_26<string>(3317886388U), <Module>.smethod_27<string>(1521039026U)));
			Main.EmptyDirectory(Main.smethod_73(this._currentPath, <Module>.smethod_23<string>(2330936310U), <Module>.smethod_25<string>(529123491U), <Module>.smethod_23<string>(1612400647U)));
			Main.EmptyDirectory(Main.smethod_73(this._currentPath, <Module>.smethod_26<string>(3308309994U), <Module>.smethod_26<string>(3317886388U), <Module>.smethod_25<string>(2162042746U)));
		}

		// Token: 0x06000342 RID: 834 RVA: 0x0002ADCC File Offset: 0x00028FCC
		private static List<T> DeserializeList<T>(string filePath)
		{
			XmlSerializer xmlSerializer = Main.smethod_86(Main.smethod_85(typeof(List<T>).TypeHandle));
			TextReader textReader = Main.smethod_87(filePath);
			List<T> list;
			try
			{
				list = (List<T>)Main.smethod_88(xmlSerializer, textReader);
			}
			finally
			{
				if (textReader != null)
				{
					Main.smethod_82(textReader);
				}
			}
			return list;
		}

		// Token: 0x06000343 RID: 835 RVA: 0x0002AE1C File Offset: 0x0002901C
		private static void EmptyDirectory(string directoryPath)
		{
			if (!Main.smethod_89(directoryPath))
			{
				return;
			}
			DirectoryInfo directoryInfo = Main.smethod_90(directoryPath);
			FileInfo[] array = Main.smethod_91(directoryInfo);
			for (int i = 0; i < array.Length; i++)
			{
				Main.smethod_92(array[i]);
			}
			DirectoryInfo[] array2 = Main.smethod_93(directoryInfo);
			for (int i = 0; i < array2.Length; i++)
			{
				Main.smethod_94(array2[i], true);
			}
		}

		// Token: 0x06000344 RID: 836 RVA: 0x0002AE7C File Offset: 0x0002907C
		private static void DisableControls(Control con)
		{
			string[] array = new string[]
			{
				<Module>.smethod_25<string>(2858017276U),
				<Module>.smethod_26<string>(1379457067U),
				<Module>.smethod_24<string>(2913896768U),
				<Module>.smethod_25<string>(3206004541U),
				<Module>.smethod_23<string>(3314308165U)
			};
			IEnumerator enumerator = Main.smethod_96(Main.smethod_95(con));
			try
			{
				while (Main.smethod_81(enumerator))
				{
					Main.DisableControls((Control)Main.smethod_97(enumerator));
				}
			}
			finally
			{
				IDisposable disposable = enumerator as IDisposable;
				if (disposable != null)
				{
					Main.smethod_82(disposable);
				}
			}
			if (!array.Contains(Main.smethod_98(con)))
			{
				Main.smethod_99(con, false);
			}
		}

		// Token: 0x06000345 RID: 837 RVA: 0x0002AF30 File Offset: 0x00029130
		private static void EnableControls(Control con)
		{
			IEnumerator enumerator = Main.smethod_96(Main.smethod_95(con));
			try
			{
				while (Main.smethod_81(enumerator))
				{
					Main.EnableControls((Control)Main.smethod_97(enumerator));
				}
			}
			finally
			{
				IDisposable disposable = enumerator as IDisposable;
				if (disposable != null)
				{
					Main.smethod_82(disposable);
				}
			}
			Main.smethod_99(con, true);
		}

		// Token: 0x06000346 RID: 838 RVA: 0x0002AF90 File Offset: 0x00029190
		private void PluginList_MouseMove(object sender, MouseEventArgs e)
		{
			int num = Main.smethod_101(this.PluginList, Main.smethod_100(e));
			if (num >= 0 && num <= Main.smethod_62(Main.smethod_5(this.PluginList)))
			{
				string text = Main.smethod_61(Main.smethod_67(Main.smethod_5(this.PluginList), num));
				if (Main.smethod_103(Main.smethod_102(this.toolTip, this.PluginList), text))
				{
					Main.smethod_104(this.toolTip, this.PluginList, text);
					return;
				}
			}
			else
			{
				Main.smethod_105(this.toolTip, this.PluginList);
			}
		}

		// Token: 0x06000347 RID: 839 RVA: 0x0002B01C File Offset: 0x0002921C
		private void BrowserCanvasStroke_TextChanged(object sender, EventArgs e)
		{
			string text = Main.smethod_106(Main.smethod_71(this.BrowserCanvasStroke), 1);
			int num;
			if (Main.smethod_103(text, string.Empty) && !int.TryParse(text, NumberStyles.HexNumber, Main.smethod_107(), out num))
			{
				Control browserCanvasStroke = this.BrowserCanvasStroke;
				string text2 = text;
				Main.smethod_13(browserCanvasStroke, Main.smethod_109(text2, Main.smethod_108(text2) - 1, 1));
				Main.smethod_110(this.BrowserCanvasStroke, Main.smethod_108(Main.smethod_71(this.BrowserCanvasStroke)));
			}
			if (Main.smethod_108(Main.smethod_71(this.BrowserCanvasStroke)) > 6)
			{
				try
				{
					Main.smethod_47(this.strokeDemo, Main.smethod_111(Main.smethod_71(this.BrowserCanvasStroke)));
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000348 RID: 840 RVA: 0x0002B0D4 File Offset: 0x000292D4
		private void BrowserCanvasFill_TextChanged(object sender, EventArgs e)
		{
			string text = Main.smethod_106(Main.smethod_71(this.BrowserCanvasFill), 1);
			int num;
			if (Main.smethod_103(text, string.Empty) && !int.TryParse(text, NumberStyles.HexNumber, Main.smethod_107(), out num))
			{
				Control browserCanvasFill = this.BrowserCanvasFill;
				string text2 = text;
				Main.smethod_13(browserCanvasFill, Main.smethod_109(text2, Main.smethod_108(text2) - 1, 1));
				Main.smethod_110(this.BrowserCanvasFill, Main.smethod_108(Main.smethod_71(this.BrowserCanvasFill)));
			}
			if (Main.smethod_108(Main.smethod_71(this.BrowserCanvasFill)) > 6)
			{
				try
				{
					Main.smethod_47(this.fillDemo, Main.smethod_111(Main.smethod_71(this.BrowserCanvasFill)));
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000349 RID: 841 RVA: 0x0002B18C File Offset: 0x0002938C
		private static IList<T> Shuffle<T>(IList<T> list)
		{
			Random random = Main.smethod_55();
			int i = list.Count;
			while (i > 1)
			{
				i--;
				int num = Main.smethod_58(random, i + 1);
				T t = list[num];
				list[num] = list[i];
				list[i] = t;
			}
			return list;
		}

		// Token: 0x0600034A RID: 842 RVA: 0x0002B1DC File Offset: 0x000293DC
		private void btnClean_Click(object sender, EventArgs e)
		{
			if (Main.smethod_43(<Module>.smethod_23<string>(1482552802U), <Module>.smethod_27<string>(2242551835U), MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				try
				{
					this.SetStatus(<Module>.smethod_26<string>(964510269U));
					FontManager.RemoveFont(Main.smethod_46(Main.smethod_39(this._currentPath, <Module>.smethod_26<string>(3844588058U)), <Module>.smethod_26<string>(4171766382U)));
					this.CleanUp();
					this._ffGenerator.Erase();
					this.InitializeGui();
					Main.smethod_47(this.fillDemo, Color.Transparent);
					Main.smethod_47(this.strokeDemo, Color.Transparent);
					Main.smethod_48(this.BrowserProduct, 0);
					this.SetStatus(<Module>.smethod_26<string>(1688318480U));
				}
				catch (Exception ex)
				{
					for (;;)
					{
						IL_00FD:
						int num = -854430317;
						for (;;)
						{
							switch (num ^ -854430318)
							{
							case 0:
								LogManager.AddEntry(<Module>.smethod_26<string>(1697894874U), ex);
								num = -854430320;
								continue;
							case 1:
								this.SetStatus(<Module>.smethod_27<string>(2131993829U));
								num = -854430318;
								continue;
							case 3:
								goto IL_00FD;
							}
							goto Block_4;
						}
					}
					Block_4:;
				}
			}
		}

		// Token: 0x06000354 RID: 852 RVA: 0x0000C65F File Offset: 0x0000A85F
		static Assembly smethod_0()
		{
			return Assembly.GetExecutingAssembly();
		}

		// Token: 0x06000355 RID: 853 RVA: 0x0000C666 File Offset: 0x0000A866
		static string smethod_1(Assembly assembly_0)
		{
			return assembly_0.Location;
		}

		// Token: 0x06000356 RID: 854 RVA: 0x0000C66E File Offset: 0x0000A86E
		static string smethod_2(string string_0)
		{
			return Path.GetDirectoryName(string_0);
		}

		// Token: 0x06000357 RID: 855 RVA: 0x0000D6E4 File Offset: 0x0000B8E4
		static DialogResult smethod_3(CommonDialog commonDialog_0)
		{
			return commonDialog_0.ShowDialog();
		}

		// Token: 0x06000358 RID: 856 RVA: 0x0000D092 File Offset: 0x0000B292
		static void smethod_4(Control control_0)
		{
			control_0.Show();
		}

		// Token: 0x06000359 RID: 857 RVA: 0x0000D6EC File Offset: 0x0000B8EC
		static CheckedListBox.ObjectCollection smethod_5(CheckedListBox checkedListBox_0)
		{
			return checkedListBox_0.Items;
		}

		// Token: 0x0600035A RID: 858 RVA: 0x0000D6F4 File Offset: 0x0000B8F4
		static void smethod_6(ListBox.ObjectCollection objectCollection_0)
		{
			objectCollection_0.Clear();
		}

		// Token: 0x0600035B RID: 859 RVA: 0x0000D6FC File Offset: 0x0000B8FC
		static string smethod_7(FileDialog fileDialog_0)
		{
			return fileDialog_0.FileName;
		}

		// Token: 0x0600035C RID: 860 RVA: 0x0000C7F5 File Offset: 0x0000A9F5
		static Assembly smethod_8()
		{
			return Assembly.GetEntryAssembly();
		}

		// Token: 0x0600035D RID: 861 RVA: 0x0000C7FC File Offset: 0x0000A9FC
		static AssemblyName smethod_9(Assembly assembly_0)
		{
			return assembly_0.GetName();
		}

		// Token: 0x0600035E RID: 862 RVA: 0x0000C804 File Offset: 0x0000AA04
		static Version smethod_10(AssemblyName assemblyName_0)
		{
			return assemblyName_0.Version;
		}

		// Token: 0x0600035F RID: 863 RVA: 0x0000CFF4 File Offset: 0x0000B1F4
		static string smethod_11(string string_0)
		{
			return Path.GetFileName(string_0);
		}

		// Token: 0x06000360 RID: 864 RVA: 0x0000D3FB File Offset: 0x0000B5FB
		static bool smethod_12(Control control_0)
		{
			return control_0.InvokeRequired;
		}

		// Token: 0x06000361 RID: 865 RVA: 0x0000D704 File Offset: 0x0000B904
		IAsyncResult method_0(Delegate delegate_0, object[] object_0)
		{
			return base.BeginInvoke(delegate_0, object_0);
		}

		// Token: 0x06000362 RID: 866 RVA: 0x0000C816 File Offset: 0x0000AA16
		static void smethod_13(Control control_0, string string_0)
		{
			control_0.Text = string_0;
		}

		// Token: 0x06000363 RID: 867 RVA: 0x0000D70E File Offset: 0x0000B90E
		static object smethod_14(Control control_0)
		{
			return control_0.Tag;
		}

		// Token: 0x06000364 RID: 868 RVA: 0x0000D716 File Offset: 0x0000B916
		static object smethod_15(Control control_0)
		{
			return control_0.Tag;
		}

		// Token: 0x06000365 RID: 869 RVA: 0x0000D71E File Offset: 0x0000B91E
		static string smethod_16(PropertyChangedEventArgs propertyChangedEventArgs_0)
		{
			return propertyChangedEventArgs_0.PropertyName;
		}

		// Token: 0x06000366 RID: 870 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_17(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06000367 RID: 871 RVA: 0x0000D726 File Offset: 0x0000B926
		static void smethod_18(ListBox listBox_0)
		{
			listBox_0.BeginUpdate();
		}

		// Token: 0x06000368 RID: 872 RVA: 0x0000D72E File Offset: 0x0000B92E
		static int smethod_19(ListBox.ObjectCollection objectCollection_0, object object_0)
		{
			return objectCollection_0.Add(object_0);
		}

		// Token: 0x06000369 RID: 873 RVA: 0x0000D737 File Offset: 0x0000B937
		static bool smethod_20(ListBox.ObjectCollection objectCollection_0, object object_0)
		{
			return objectCollection_0.Contains(object_0);
		}

		// Token: 0x0600036A RID: 874 RVA: 0x0000D740 File Offset: 0x0000B940
		static int smethod_21(ListBox.ObjectCollection objectCollection_0, object object_0)
		{
			return objectCollection_0.IndexOf(object_0);
		}

		// Token: 0x0600036B RID: 875 RVA: 0x0000D749 File Offset: 0x0000B949
		static void smethod_22(CheckedListBox checkedListBox_0, int int_0, bool bool_0)
		{
			checkedListBox_0.SetItemChecked(int_0, bool_0);
		}

		// Token: 0x0600036C RID: 876 RVA: 0x0000D753 File Offset: 0x0000B953
		static int smethod_23(CheckedListBox.ObjectCollection objectCollection_0, object object_0, bool bool_0)
		{
			return objectCollection_0.Add(object_0, bool_0);
		}

		// Token: 0x0600036D RID: 877 RVA: 0x0000D75D File Offset: 0x0000B95D
		static void smethod_24(ListBox listBox_0)
		{
			listBox_0.EndUpdate();
		}

		// Token: 0x0600036E RID: 878 RVA: 0x0000D765 File Offset: 0x0000B965
		static ComboBox.ObjectCollection smethod_25(ComboBox comboBox_0)
		{
			return comboBox_0.Items;
		}

		// Token: 0x0600036F RID: 879 RVA: 0x0000D76D File Offset: 0x0000B96D
		static int smethod_26(ComboBox.ObjectCollection objectCollection_0, object object_0)
		{
			return objectCollection_0.Add(object_0);
		}

		// Token: 0x06000370 RID: 880 RVA: 0x0000D776 File Offset: 0x0000B976
		static ControlBindingsCollection smethod_27(Control control_0)
		{
			return control_0.DataBindings;
		}

		// Token: 0x06000371 RID: 881 RVA: 0x0000D77E File Offset: 0x0000B97E
		static void smethod_28(ControlBindingsCollection controlBindingsCollection_0)
		{
			controlBindingsCollection_0.Clear();
		}

		// Token: 0x06000372 RID: 882 RVA: 0x0000D786 File Offset: 0x0000B986
		static Binding smethod_29(ControlBindingsCollection controlBindingsCollection_0, string string_0, object object_0, string string_1, bool bool_0, DataSourceUpdateMode dataSourceUpdateMode_0)
		{
			return controlBindingsCollection_0.Add(string_0, object_0, string_1, bool_0, dataSourceUpdateMode_0);
		}

		// Token: 0x06000373 RID: 883 RVA: 0x0000D795 File Offset: 0x0000B995
		static void smethod_30(ComboBox comboBox_0, object object_0)
		{
			comboBox_0.DataSource = object_0;
		}

		// Token: 0x06000374 RID: 884 RVA: 0x0000D79E File Offset: 0x0000B99E
		static void smethod_31(ListControl listControl_0, string string_0)
		{
			listControl_0.DisplayMember = string_0;
		}

		// Token: 0x06000375 RID: 885 RVA: 0x0000D7A7 File Offset: 0x0000B9A7
		static void smethod_32(ListControl listControl_0, string string_0)
		{
			listControl_0.ValueMember = string_0;
		}

		// Token: 0x06000376 RID: 886 RVA: 0x0000D7B0 File Offset: 0x0000B9B0
		static Binding smethod_33(string string_0, object object_0, string string_1, bool bool_0, DataSourceUpdateMode dataSourceUpdateMode_0)
		{
			return new Binding(string_0, object_0, string_1, bool_0, dataSourceUpdateMode_0);
		}

		// Token: 0x06000377 RID: 887 RVA: 0x0000D7BD File Offset: 0x0000B9BD
		static void smethod_34(ControlBindingsCollection controlBindingsCollection_0, Binding binding_0)
		{
			controlBindingsCollection_0.Add(binding_0);
		}

		// Token: 0x06000378 RID: 888 RVA: 0x0000D7C6 File Offset: 0x0000B9C6
		static void smethod_35(ComboBox.ObjectCollection objectCollection_0)
		{
			objectCollection_0.Clear();
		}

		// Token: 0x06000379 RID: 889 RVA: 0x0000D430 File Offset: 0x0000B630
		bool method_1()
		{
			return base.InvokeRequired;
		}

		// Token: 0x0600037A RID: 890 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_36(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x0600037B RID: 891 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_37(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x0600037C RID: 892 RVA: 0x0000CD96 File Offset: 0x0000AF96
		static string smethod_38(string string_0, object object_0, object object_1, object object_2)
		{
			return string.Format(string_0, object_0, object_1, object_2);
		}

		// Token: 0x0600037D RID: 893 RVA: 0x0000C656 File Offset: 0x0000A856
		static string smethod_39(string string_0, string string_1)
		{
			return Path.Combine(string_0, string_1);
		}

		// Token: 0x0600037E RID: 894 RVA: 0x0000C681 File Offset: 0x0000A881
		static bool smethod_40(string string_0)
		{
			return File.Exists(string_0);
		}

		// Token: 0x0600037F RID: 895 RVA: 0x0000D7CE File Offset: 0x0000B9CE
		static bool smethod_41(KeyEventArgs keyEventArgs_0)
		{
			return keyEventArgs_0.Control;
		}

		// Token: 0x06000380 RID: 896 RVA: 0x0000D43F File Offset: 0x0000B63F
		static Keys smethod_42(KeyEventArgs keyEventArgs_0)
		{
			return keyEventArgs_0.KeyCode;
		}

		// Token: 0x06000381 RID: 897 RVA: 0x0000D0AC File Offset: 0x0000B2AC
		static DialogResult smethod_43(string string_0, string string_1, MessageBoxButtons messageBoxButtons_0)
		{
			return MessageBox.Show(string_0, string_1, messageBoxButtons_0);
		}

		// Token: 0x06000382 RID: 898 RVA: 0x0000D0B6 File Offset: 0x0000B2B6
		static void smethod_44(CancelEventArgs cancelEventArgs_0, bool bool_0)
		{
			cancelEventArgs_0.Cancel = bool_0;
		}

		// Token: 0x06000383 RID: 899 RVA: 0x0000D17E File Offset: 0x0000B37E
		static void smethod_45(Form form_0)
		{
			form_0.Close();
		}

		// Token: 0x06000384 RID: 900 RVA: 0x0000CD4E File Offset: 0x0000AF4E
		static string[] smethod_46(string string_0, string string_1)
		{
			return Directory.GetFiles(string_0, string_1);
		}

		// Token: 0x06000385 RID: 901 RVA: 0x0000D7D6 File Offset: 0x0000B9D6
		static void smethod_47(Control control_0, Color color_0)
		{
			control_0.BackColor = color_0;
		}

		// Token: 0x06000386 RID: 902 RVA: 0x0000D15C File Offset: 0x0000B35C
		static void smethod_48(ListControl listControl_0, int int_0)
		{
			listControl_0.SelectedIndex = int_0;
		}

		// Token: 0x06000387 RID: 903 RVA: 0x0000D7DF File Offset: 0x0000B9DF
		static Process[] smethod_49(string string_0)
		{
			return Process.GetProcessesByName(string_0);
		}

		// Token: 0x06000388 RID: 904 RVA: 0x0000D3DB File Offset: 0x0000B5DB
		static void smethod_50(BackgroundWorker backgroundWorker_0)
		{
			backgroundWorker_0.RunWorkerAsync();
		}

		// Token: 0x06000389 RID: 905 RVA: 0x0000D7E7 File Offset: 0x0000B9E7
		static void smethod_51(ComboBox comboBox_0)
		{
			comboBox_0.BeginUpdate();
		}

		// Token: 0x0600038A RID: 906 RVA: 0x0000D7EF File Offset: 0x0000B9EF
		static object smethod_52(ComboBox comboBox_0)
		{
			return comboBox_0.SelectedItem;
		}

		// Token: 0x0600038B RID: 907 RVA: 0x0000D7F7 File Offset: 0x0000B9F7
		static BindingSource smethod_53(object object_0, string string_0)
		{
			return new BindingSource(object_0, string_0);
		}

		// Token: 0x0600038C RID: 908 RVA: 0x0000D800 File Offset: 0x0000BA00
		static void smethod_54(ComboBox comboBox_0)
		{
			comboBox_0.EndUpdate();
		}

		// Token: 0x0600038D RID: 909 RVA: 0x0000D808 File Offset: 0x0000BA08
		static Random smethod_55()
		{
			return new Random();
		}

		// Token: 0x0600038E RID: 910 RVA: 0x0000D80F File Offset: 0x0000BA0F
		static int smethod_56(ComboBox.ObjectCollection objectCollection_0)
		{
			return objectCollection_0.Count;
		}

		// Token: 0x0600038F RID: 911 RVA: 0x0000D817 File Offset: 0x0000BA17
		static int smethod_57(Random random_0, int int_0, int int_1)
		{
			return random_0.Next(int_0, int_1);
		}

		// Token: 0x06000390 RID: 912 RVA: 0x0000D821 File Offset: 0x0000BA21
		static int smethod_58(Random random_0, int int_0)
		{
			return random_0.Next(int_0);
		}

		// Token: 0x06000391 RID: 913 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_59(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x06000392 RID: 914 RVA: 0x0000D82A File Offset: 0x0000BA2A
		static object smethod_60(ComboBox.ObjectCollection objectCollection_0, int int_0)
		{
			return objectCollection_0[int_0];
		}

		// Token: 0x06000393 RID: 915 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_61(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06000394 RID: 916 RVA: 0x0000D83B File Offset: 0x0000BA3B
		static int smethod_62(ListBox.ObjectCollection objectCollection_0)
		{
			return objectCollection_0.Count;
		}

		// Token: 0x06000395 RID: 917 RVA: 0x0000C832 File Offset: 0x0000AA32
		static void smethod_63(Control control_0)
		{
			control_0.Show();
		}

		// Token: 0x06000396 RID: 918 RVA: 0x0000D843 File Offset: 0x0000BA43
		static CheckState smethod_64(ItemCheckEventArgs itemCheckEventArgs_0)
		{
			return itemCheckEventArgs_0.CurrentValue;
		}

		// Token: 0x06000397 RID: 919 RVA: 0x0000D84B File Offset: 0x0000BA4B
		static CheckState smethod_65(ItemCheckEventArgs itemCheckEventArgs_0)
		{
			return itemCheckEventArgs_0.NewValue;
		}

		// Token: 0x06000398 RID: 920 RVA: 0x0000D853 File Offset: 0x0000BA53
		static int smethod_66(ItemCheckEventArgs itemCheckEventArgs_0)
		{
			return itemCheckEventArgs_0.Index;
		}

		// Token: 0x06000399 RID: 921 RVA: 0x0000D85B File Offset: 0x0000BA5B
		static object smethod_67(ListBox.ObjectCollection objectCollection_0, int int_0)
		{
			return objectCollection_0[int_0];
		}

		// Token: 0x0600039A RID: 922 RVA: 0x0000D864 File Offset: 0x0000BA64
		static ListBox.SelectedObjectCollection smethod_68(ListBox listBox_0)
		{
			return listBox_0.SelectedItems;
		}

		// Token: 0x0600039B RID: 923 RVA: 0x0000D86C File Offset: 0x0000BA6C
		static int smethod_69(ListBox.SelectedObjectCollection selectedObjectCollection_0)
		{
			return selectedObjectCollection_0.Count;
		}

		// Token: 0x0600039C RID: 924 RVA: 0x0000D874 File Offset: 0x0000BA74
		static void smethod_70(ListBox.ObjectCollection objectCollection_0, object object_0)
		{
			objectCollection_0.Remove(object_0);
		}

		// Token: 0x0600039D RID: 925 RVA: 0x0000D09A File Offset: 0x0000B29A
		static string smethod_71(Control control_0)
		{
			return control_0.Text;
		}

		// Token: 0x0600039E RID: 926 RVA: 0x0000CFDC File Offset: 0x0000B1DC
		static string smethod_72()
		{
			return Environment.SystemDirectory;
		}

		// Token: 0x0600039F RID: 927 RVA: 0x0000C676 File Offset: 0x0000A876
		static string smethod_73(string string_0, string string_1, string string_2, string string_3)
		{
			return Path.Combine(string_0, string_1, string_2, string_3);
		}

		// Token: 0x060003A0 RID: 928 RVA: 0x0000D87D File Offset: 0x0000BA7D
		static CheckedListBox.CheckedItemCollection smethod_74(CheckedListBox checkedListBox_0)
		{
			return checkedListBox_0.CheckedItems;
		}

		// Token: 0x060003A1 RID: 929 RVA: 0x0000D885 File Offset: 0x0000BA85
		static Screen smethod_75()
		{
			return Screen.PrimaryScreen;
		}

		// Token: 0x060003A2 RID: 930 RVA: 0x0000D88C File Offset: 0x0000BA8C
		static Rectangle smethod_76(Screen screen_0)
		{
			return screen_0.Bounds;
		}

		// Token: 0x060003A3 RID: 931 RVA: 0x0000C82A File Offset: 0x0000AA2A
		static bool smethod_77(Control control_0)
		{
			return control_0.Visible;
		}

		// Token: 0x060003A4 RID: 932 RVA: 0x0000D894 File Offset: 0x0000BA94
		static void smethod_78(Form form_0)
		{
			form_0.Close();
		}

		// Token: 0x060003A5 RID: 933 RVA: 0x0000D89C File Offset: 0x0000BA9C
		static DialogResult smethod_79(string string_0, string string_1, MessageBoxButtons messageBoxButtons_0, MessageBoxIcon messageBoxIcon_0, MessageBoxDefaultButton messageBoxDefaultButton_0)
		{
			return MessageBox.Show(string_0, string_1, messageBoxButtons_0, messageBoxIcon_0, messageBoxDefaultButton_0);
		}

		// Token: 0x060003A6 RID: 934 RVA: 0x0000C7ED File Offset: 0x0000A9ED
		static void smethod_80(string string_0)
		{
			File.Delete(string_0);
		}

		// Token: 0x060003A7 RID: 935 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_81(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060003A8 RID: 936 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_82(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060003A9 RID: 937 RVA: 0x0000D8A9 File Offset: 0x0000BAA9
		static string smethod_83(Environment.SpecialFolder specialFolder_0)
		{
			return Environment.GetFolderPath(specialFolder_0);
		}

		// Token: 0x060003AA RID: 938 RVA: 0x0000C784 File Offset: 0x0000A984
		static string smethod_84(string string_0, string string_1, string string_2)
		{
			return Path.Combine(string_0, string_1, string_2);
		}

		// Token: 0x060003AB RID: 939 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_85(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060003AC RID: 940 RVA: 0x0000CDC1 File Offset: 0x0000AFC1
		static XmlSerializer smethod_86(Type type_0)
		{
			return new XmlSerializer(type_0);
		}

		// Token: 0x060003AD RID: 941 RVA: 0x0000CDDC File Offset: 0x0000AFDC
		static StreamReader smethod_87(string string_0)
		{
			return new StreamReader(string_0);
		}

		// Token: 0x060003AE RID: 942 RVA: 0x0000CDE4 File Offset: 0x0000AFE4
		static object smethod_88(XmlSerializer xmlSerializer_0, TextReader textReader_0)
		{
			return xmlSerializer_0.Deserialize(textReader_0);
		}

		// Token: 0x060003AF RID: 943 RVA: 0x0000D8B1 File Offset: 0x0000BAB1
		static bool smethod_89(string string_0)
		{
			return Directory.Exists(string_0);
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x0000D8B9 File Offset: 0x0000BAB9
		static DirectoryInfo smethod_90(string string_0)
		{
			return new DirectoryInfo(string_0);
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x0000D8C1 File Offset: 0x0000BAC1
		static FileInfo[] smethod_91(DirectoryInfo directoryInfo_0)
		{
			return directoryInfo_0.GetFiles();
		}

		// Token: 0x060003B2 RID: 946 RVA: 0x0000D4E5 File Offset: 0x0000B6E5
		static void smethod_92(FileSystemInfo fileSystemInfo_0)
		{
			fileSystemInfo_0.Delete();
		}

		// Token: 0x060003B3 RID: 947 RVA: 0x0000D8C9 File Offset: 0x0000BAC9
		static DirectoryInfo[] smethod_93(DirectoryInfo directoryInfo_0)
		{
			return directoryInfo_0.GetDirectories();
		}

		// Token: 0x060003B4 RID: 948 RVA: 0x0000D8D1 File Offset: 0x0000BAD1
		static void smethod_94(DirectoryInfo directoryInfo_0, bool bool_0)
		{
			directoryInfo_0.Delete(bool_0);
		}

		// Token: 0x060003B5 RID: 949 RVA: 0x0000C90F File Offset: 0x0000AB0F
		static Control.ControlCollection smethod_95(Control control_0)
		{
			return control_0.Controls;
		}

		// Token: 0x060003B6 RID: 950 RVA: 0x0000D8DA File Offset: 0x0000BADA
		static IEnumerator smethod_96(ArrangedElementCollection arrangedElementCollection_0)
		{
			return arrangedElementCollection_0.GetEnumerator();
		}

		// Token: 0x060003B7 RID: 951 RVA: 0x0000D8E2 File Offset: 0x0000BAE2
		static object smethod_97(IEnumerator ienumerator_0)
		{
			return ienumerator_0.Current;
		}

		// Token: 0x060003B8 RID: 952 RVA: 0x0000D8EA File Offset: 0x0000BAEA
		static string smethod_98(Control control_0)
		{
			return control_0.Name;
		}

		// Token: 0x060003B9 RID: 953 RVA: 0x0000D165 File Offset: 0x0000B365
		static void smethod_99(Control control_0, bool bool_0)
		{
			control_0.Enabled = bool_0;
		}

		// Token: 0x060003BA RID: 954 RVA: 0x0000D8F2 File Offset: 0x0000BAF2
		static Point smethod_100(MouseEventArgs mouseEventArgs_0)
		{
			return mouseEventArgs_0.Location;
		}

		// Token: 0x060003BB RID: 955 RVA: 0x0000D8FA File Offset: 0x0000BAFA
		static int smethod_101(ListBox listBox_0, Point point_0)
		{
			return listBox_0.IndexFromPoint(point_0);
		}

		// Token: 0x060003BC RID: 956 RVA: 0x0000D903 File Offset: 0x0000BB03
		static string smethod_102(ToolTip toolTip_0, Control control_0)
		{
			return toolTip_0.GetToolTip(control_0);
		}

		// Token: 0x060003BD RID: 957 RVA: 0x0000CDA1 File Offset: 0x0000AFA1
		static bool smethod_103(string string_0, string string_1)
		{
			return string_0 != string_1;
		}

		// Token: 0x060003BE RID: 958 RVA: 0x0000D90C File Offset: 0x0000BB0C
		static void smethod_104(ToolTip toolTip_0, Control control_0, string string_0)
		{
			toolTip_0.SetToolTip(control_0, string_0);
		}

		// Token: 0x060003BF RID: 959 RVA: 0x0000D916 File Offset: 0x0000BB16
		static void smethod_105(ToolTip toolTip_0, IWin32Window iwin32Window_0)
		{
			toolTip_0.Hide(iwin32Window_0);
		}

		// Token: 0x060003C0 RID: 960 RVA: 0x0000D416 File Offset: 0x0000B616
		static string smethod_106(string string_0, int int_0)
		{
			return string_0.Substring(int_0);
		}

		// Token: 0x060003C1 RID: 961 RVA: 0x0000D91F File Offset: 0x0000BB1F
		static NumberFormatInfo smethod_107()
		{
			return NumberFormatInfo.CurrentInfo;
		}

		// Token: 0x060003C2 RID: 962 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_108(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x060003C3 RID: 963 RVA: 0x0000D926 File Offset: 0x0000BB26
		static string smethod_109(string string_0, int int_0, int int_1)
		{
			return string_0.Remove(int_0, int_1);
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x0000D930 File Offset: 0x0000BB30
		static void smethod_110(TextBoxBase textBoxBase_0, int int_0)
		{
			textBoxBase_0.SelectionStart = int_0;
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x0000D939 File Offset: 0x0000BB39
		static Color smethod_111(string string_0)
		{
			return ColorTranslator.FromHtml(string_0);
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x0000D941 File Offset: 0x0000BB41
		static Container smethod_112()
		{
			return new Container();
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x0000C8E9 File Offset: 0x0000AAE9
		static ComponentResourceManager smethod_113(Type type_0)
		{
			return new ComponentResourceManager(type_0);
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x0000C8F8 File Offset: 0x0000AAF8
		static Button smethod_114()
		{
			return new Button();
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x0000C8F1 File Offset: 0x0000AAF1
		static GroupBox smethod_115()
		{
			return new GroupBox();
		}

		// Token: 0x060003CA RID: 970 RVA: 0x0000D194 File Offset: 0x0000B394
		static ComboBox smethod_116()
		{
			return new ComboBox();
		}

		// Token: 0x060003CB RID: 971 RVA: 0x0000D186 File Offset: 0x0000B386
		static Label smethod_117()
		{
			return new Label();
		}

		// Token: 0x060003CC RID: 972 RVA: 0x0000D44F File Offset: 0x0000B64F
		static PictureBox smethod_118()
		{
			return new PictureBox();
		}

		// Token: 0x060003CD RID: 973 RVA: 0x0000D948 File Offset: 0x0000BB48
		static MaskedTextBox smethod_119()
		{
			return new MaskedTextBox();
		}

		// Token: 0x060003CE RID: 974 RVA: 0x0000D18D File Offset: 0x0000B38D
		static NumericUpDown smethod_120()
		{
			return new NumericUpDown();
		}

		// Token: 0x060003CF RID: 975 RVA: 0x0000D94F File Offset: 0x0000BB4F
		static CheckBox smethod_121()
		{
			return new CheckBox();
		}

		// Token: 0x060003D0 RID: 976 RVA: 0x0000D956 File Offset: 0x0000BB56
		static CheckedListBox smethod_122()
		{
			return new CheckedListBox();
		}

		// Token: 0x060003D1 RID: 977 RVA: 0x0000D95D File Offset: 0x0000BB5D
		static OpenFileDialog smethod_123()
		{
			return new OpenFileDialog();
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x0000D964 File Offset: 0x0000BB64
		static SaveFileDialog smethod_124()
		{
			return new SaveFileDialog();
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x0000D456 File Offset: 0x0000B656
		static BackgroundWorker smethod_125()
		{
			return new BackgroundWorker();
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x0000D96B File Offset: 0x0000BB6B
		static ToolTip smethod_126(IContainer icontainer_0)
		{
			return new ToolTip(icontainer_0);
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x0000C8FF File Offset: 0x0000AAFF
		static void smethod_127(Control control_0)
		{
			control_0.SuspendLayout();
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x0000D19B File Offset: 0x0000B39B
		static void smethod_128(ISupportInitialize isupportInitialize_0)
		{
			isupportInitialize_0.BeginInit();
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x0000C907 File Offset: 0x0000AB07
		static void smethod_129(Control control_0)
		{
			control_0.SuspendLayout();
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x0000D973 File Offset: 0x0000BB73
		static bool smethod_130(Control control_0)
		{
			return control_0.Visible;
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x0000D97B File Offset: 0x0000BB7B
		static DialogResult smethod_131(Form form_0, IWin32Window iwin32Window_0)
		{
			return form_0.ShowDialog(iwin32Window_0);
		}

		// Token: 0x060003DA RID: 986 RVA: 0x0000D984 File Offset: 0x0000BB84
		static IEnumerable<int> smethod_132(int int_0, int int_1)
		{
			return Enumerable.Range(int_0, int_1);
		}

		// Token: 0x060003DB RID: 987 RVA: 0x0000D98D File Offset: 0x0000BB8D
		static int smethod_133(CheckedListBox.ObjectCollection objectCollection_0, object object_0, CheckState checkState_0)
		{
			return objectCollection_0.Add(object_0, checkState_0);
		}

		// Token: 0x040000CA RID: 202
		private const string FontsFileName = "FontList.xml";

		// Token: 0x040000CB RID: 203
		private const string PluginsFileName = "PluginList.xml";

		// Token: 0x040000CC RID: 204
		private ProfileManager _profileManager = new ProfileManager();

		// Token: 0x040000CD RID: 205
		private FFGenerator _ffGenerator = new FFGenerator();

		// Token: 0x040000CE RID: 206
		private static List<string> _logList = new List<string>();

		// Token: 0x040000CF RID: 207
		private List<string> _defaultFonts = new List<string>();

		// Token: 0x040000D0 RID: 208
		private List<BrowserPluginInfo> _defaultPlugins = new List<BrowserPluginInfo>();

		// Token: 0x040000D1 RID: 209
		private readonly string _currentPath = Main.smethod_2(Main.smethod_1(Main.smethod_0()));

		// Token: 0x040000D2 RID: 210
		private bool _fontsListChecked = true;

		// Token: 0x040000D3 RID: 211
		private bool _pluginListChecked = true;

		// Token: 0x040000D4 RID: 212
		private frmNotes _frmNotes;

		// Token: 0x02000034 RID: 52
		// (Invoke) Token: 0x060003DD RID: 989
		public delegate void UpdateStatusDelegate(string text);

		// Token: 0x02000035 RID: 53
		// (Invoke) Token: 0x060003E1 RID: 993
		public delegate void SetFormTextDelegate(Version version, string user, string profileFileName);
	}
}
