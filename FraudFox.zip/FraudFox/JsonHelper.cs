﻿using System;
using System.Web.Script.Serialization;

namespace FraudFox
{
	// Token: 0x0200001C RID: 28
	public static class JsonHelper
	{
		// Token: 0x060001E8 RID: 488 RVA: 0x0000CE76 File Offset: 0x0000B076
		public static string ToJson(this object obj)
		{
			return JsonHelper.smethod_1(JsonHelper.smethod_0(), obj);
		}

		// Token: 0x060001E9 RID: 489 RVA: 0x0000CE83 File Offset: 0x0000B083
		public static string ToJson(this object obj, int recursionDepth)
		{
			JavaScriptSerializer javaScriptSerializer = JsonHelper.smethod_0();
			JsonHelper.smethod_2(javaScriptSerializer, recursionDepth);
			return JsonHelper.smethod_1(javaScriptSerializer, obj);
		}

		// Token: 0x060001EA RID: 490 RVA: 0x0000CE97 File Offset: 0x0000B097
		static JavaScriptSerializer smethod_0()
		{
			return new JavaScriptSerializer();
		}

		// Token: 0x060001EB RID: 491 RVA: 0x0000CE9E File Offset: 0x0000B09E
		static string smethod_1(JavaScriptSerializer javaScriptSerializer_0, object object_0)
		{
			return javaScriptSerializer_0.Serialize(object_0);
		}

		// Token: 0x060001EC RID: 492 RVA: 0x0000CEA7 File Offset: 0x0000B0A7
		static void smethod_2(JavaScriptSerializer javaScriptSerializer_0, int int_0)
		{
			javaScriptSerializer_0.RecursionLimit = int_0;
		}
	}
}
