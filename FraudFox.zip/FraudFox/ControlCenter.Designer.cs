﻿namespace FraudFox
{
	// Token: 0x02000017 RID: 23
	public partial class ControlCenter : global::System.Windows.Forms.Form
	{
		// Token: 0x0600013B RID: 315 RVA: 0x0000C756 File Offset: 0x0000A956
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				global::FraudFox.ControlCenter.smethod_50(this.components);
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600013C RID: 316 RVA: 0x00023D08 File Offset: 0x00021F08
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = global::FraudFox.ControlCenter.smethod_52(global::FraudFox.ControlCenter.smethod_51(typeof(global::FraudFox.ControlCenter).TypeHandle));
			this.groupBox1 = global::FraudFox.ControlCenter.smethod_53();
			this.wbNews = new global::TheArtOfDev.HtmlRenderer.WinForms.HtmlPanel();
			this.groupBox2 = global::FraudFox.ControlCenter.smethod_53();
			this.btnRefresh = global::FraudFox.ControlCenter.smethod_54();
			this.groupBox3 = global::FraudFox.ControlCenter.smethod_53();
			this.btnNewProfile = global::FraudFox.ControlCenter.smethod_54();
			this.groupBox4 = global::FraudFox.ControlCenter.smethod_53();
			this.btnConfig = global::FraudFox.ControlCenter.smethod_54();
			this.btnSocksCap = global::FraudFox.ControlCenter.smethod_54();
			this.btnOsfuscator = global::FraudFox.ControlCenter.smethod_54();
			this.btnOpenTextProfile = global::FraudFox.ControlCenter.smethod_54();
			this.btnOpenFile = global::FraudFox.ControlCenter.smethod_54();
			this.wbSetup = new global::TheArtOfDev.HtmlRenderer.WinForms.HtmlPanel();
			global::FraudFox.ControlCenter.smethod_55(this.groupBox1);
			global::FraudFox.ControlCenter.smethod_55(this.groupBox2);
			global::FraudFox.ControlCenter.smethod_55(this.groupBox3);
			global::FraudFox.ControlCenter.smethod_55(this.groupBox4);
			global::FraudFox.ControlCenter.smethod_56(this);
			global::FraudFox.ControlCenter.smethod_58(global::FraudFox.ControlCenter.smethod_57(this.groupBox1), this.wbNews);
			this.groupBox1.Location = new global::System.Drawing.Point(6, 6);
			this.groupBox1.Margin = new global::System.Windows.Forms.Padding(2);
			this.groupBox1.Name = global::<Module>.smethod_23<string>(2573772052U);
			this.groupBox1.Padding = new global::System.Windows.Forms.Padding(2);
			this.groupBox1.Size = new global::System.Drawing.Size(252, 314);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = global::<Module>.smethod_27<string>(4031041416U);
			this.wbNews.AutoScroll = true;
			this.wbNews.AutoScrollMinSize = new global::System.Drawing.Size(241, 20);
			this.wbNews.BackColor = global::System.Drawing.SystemColors.Control;
			this.wbNews.BaseStylesheet = null;
			this.wbNews.Cursor = global::System.Windows.Forms.Cursors.Default;
			this.wbNews.Location = new global::System.Drawing.Point(6, 22);
			this.wbNews.Name = global::<Module>.smethod_25<string>(2605016750U);
			this.wbNews.Size = new global::System.Drawing.Size(241, 283);
			this.wbNews.TabIndex = 1;
			this.wbNews.Text = global::<Module>.smethod_25<string>(2396224391U);
			this.groupBox2.Controls.Add(this.wbSetup);
			this.groupBox2.Controls.Add(this.btnRefresh);
			this.groupBox2.Enabled = false;
			this.groupBox2.Location = new global::System.Drawing.Point(266, 6);
			this.groupBox2.Margin = new global::System.Windows.Forms.Padding(2);
			this.groupBox2.Name = global::<Module>.smethod_27<string>(3098607556U);
			this.groupBox2.Padding = new global::System.Windows.Forms.Padding(2);
			this.groupBox2.Size = new global::System.Drawing.Size(236, 95);
			this.groupBox2.TabIndex = 1;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = global::<Module>.smethod_25<string>(2953004015U);
			this.btnRefresh.Enabled = false;
			this.btnRefresh.Font = new global::System.Drawing.Font(global::<Module>.smethod_27<string>(2725634012U), 6.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.btnRefresh.Location = new global::System.Drawing.Point(169, 0);
			this.btnRefresh.Margin = new global::System.Windows.Forms.Padding(0);
			this.btnRefresh.Name = global::<Module>.smethod_23<string>(485301030U);
			this.btnRefresh.Size = new global::System.Drawing.Size(56, 21);
			this.btnRefresh.TabIndex = 8;
			this.btnRefresh.Text = global::<Module>.smethod_24<string>(4009866779U);
			this.btnRefresh.UseVisualStyleBackColor = true;
			this.btnRefresh.Click += new global::System.EventHandler(this.btnRefresh_Click);
			this.groupBox3.Controls.Add(this.btnNewProfile);
			this.groupBox3.Location = new global::System.Drawing.Point(266, 107);
			this.groupBox3.Margin = new global::System.Windows.Forms.Padding(2);
			this.groupBox3.Name = global::<Module>.smethod_26<string>(1604547739U);
			this.groupBox3.Padding = new global::System.Windows.Forms.Padding(2);
			this.groupBox3.Size = new global::System.Drawing.Size(236, 121);
			this.groupBox3.TabIndex = 2;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = global::<Module>.smethod_24<string>(2437806096U);
			this.btnNewProfile.Location = new global::System.Drawing.Point(11, 22);
			this.btnNewProfile.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnNewProfile.Name = global::<Module>.smethod_24<string>(988197477U);
			this.btnNewProfile.Size = new global::System.Drawing.Size(214, 27);
			this.btnNewProfile.TabIndex = 2;
			this.btnNewProfile.Text = global::<Module>.smethod_25<string>(775408182U);
			this.btnNewProfile.UseVisualStyleBackColor = true;
			this.btnNewProfile.Click += new global::System.EventHandler(this.btnNewProfile_Click);
			this.groupBox4.Controls.Add(this.btnConfig);
			this.groupBox4.Controls.Add(this.btnSocksCap);
			this.groupBox4.Controls.Add(this.btnOsfuscator);
			this.groupBox4.Location = new global::System.Drawing.Point(266, 232);
			this.groupBox4.Margin = new global::System.Windows.Forms.Padding(2);
			this.groupBox4.Name = global::<Module>.smethod_27<string>(3325944481U);
			this.groupBox4.Padding = new global::System.Windows.Forms.Padding(2);
			this.groupBox4.Size = new global::System.Drawing.Size(236, 88);
			this.groupBox4.TabIndex = 3;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = global::<Module>.smethod_24<string>(229096416U);
			this.btnConfig.Location = new global::System.Drawing.Point(11, 52);
			this.btnConfig.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnConfig.Name = global::<Module>.smethod_27<string>(2952970937U);
			this.btnConfig.Size = new global::System.Drawing.Size(214, 27);
			this.btnConfig.TabIndex = 5;
			this.btnConfig.Text = global::<Module>.smethod_25<string>(1888967430U);
			this.btnConfig.UseVisualStyleBackColor = true;
			this.btnConfig.Click += new global::System.EventHandler(this.btnConfig_Click);
			this.btnSocksCap.Location = new global::System.Drawing.Point(119, 21);
			this.btnSocksCap.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnSocksCap.Name = global::<Module>.smethod_25<string>(2515344507U);
			this.btnSocksCap.Size = new global::System.Drawing.Size(106, 27);
			this.btnSocksCap.TabIndex = 4;
			this.btnSocksCap.Text = global::<Module>.smethod_24<string>(3284808130U);
			this.btnSocksCap.UseVisualStyleBackColor = true;
			this.btnSocksCap.Click += new global::System.EventHandler(this.btnSocksCap_Click);
			this.btnOsfuscator.Location = new global::System.Drawing.Point(11, 21);
			this.btnOsfuscator.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnOsfuscator.Name = global::<Module>.smethod_27<string>(2346888928U);
			this.btnOsfuscator.Size = new global::System.Drawing.Size(106, 27);
			this.btnOsfuscator.TabIndex = 3;
			this.btnOsfuscator.Text = global::<Module>.smethod_23<string>(1550920917U);
			this.btnOsfuscator.UseVisualStyleBackColor = true;
			this.btnOsfuscator.Click += new global::System.EventHandler(this.btnOsfuscator_Click);
			this.btnOpenTextProfile.Location = new global::System.Drawing.Point(277, 191);
			this.btnOpenTextProfile.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnOpenTextProfile.Name = global::<Module>.smethod_27<string>(1834050305U);
			this.btnOpenTextProfile.Size = new global::System.Drawing.Size(214, 27);
			this.btnOpenTextProfile.TabIndex = 4;
			this.btnOpenTextProfile.Text = global::<Module>.smethod_23<string>(2672983179U);
			this.btnOpenTextProfile.UseVisualStyleBackColor = true;
			this.btnOpenTextProfile.Click += new global::System.EventHandler(this.btnOpenTextProfile_Click);
			this.btnOpenFile.Location = new global::System.Drawing.Point(277, 161);
			this.btnOpenFile.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnOpenFile.Name = global::<Module>.smethod_27<string>(901616445U);
			this.btnOpenFile.Size = new global::System.Drawing.Size(214, 27);
			this.btnOpenFile.TabIndex = 3;
			this.btnOpenFile.Text = global::<Module>.smethod_23<string>(3988327193U);
			this.btnOpenFile.UseVisualStyleBackColor = true;
			this.btnOpenFile.Click += new global::System.EventHandler(this.btnOpenFile_Click);
			this.wbSetup.AutoScroll = true;
			this.wbSetup.AutoScrollMinSize = new global::System.Drawing.Size(220, 20);
			this.wbSetup.BackColor = global::System.Drawing.SystemColors.Control;
			this.wbSetup.BaseStylesheet = null;
			this.wbSetup.Cursor = global::System.Windows.Forms.Cursors.Default;
			this.wbSetup.Location = new global::System.Drawing.Point(7, 22);
			this.wbSetup.Name = global::<Module>.smethod_23<string>(2474560925U);
			this.wbSetup.Size = new global::System.Drawing.Size(220, 68);
			this.wbSetup.TabIndex = 2;
			this.wbSetup.Text = global::<Module>.smethod_24<string>(1110649541U);
			this.wbSetup.Visible = false;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(515, 331);
			base.Controls.Add(this.btnOpenTextProfile);
			base.Controls.Add(this.btnOpenFile);
			base.Controls.Add(this.groupBox4);
			base.Controls.Add(this.groupBox3);
			base.Controls.Add(this.groupBox2);
			base.Controls.Add(this.groupBox1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject(global::<Module>.smethod_24<string>(743293349U));
			base.Margin = new global::System.Windows.Forms.Padding(2);
			base.Name = global::<Module>.smethod_24<string>(2369212593U);
			this.Text = global::<Module>.smethod_27<string>(2014765537U);
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.ControlCenter_FormClosing);
			base.FormClosed += new global::System.Windows.Forms.FormClosedEventHandler(this.ControlCenter_FormClosed);
			base.Load += new global::System.EventHandler(this.ControlCenter_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		// Token: 0x04000050 RID: 80
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000051 RID: 81
		private global::System.Windows.Forms.GroupBox groupBox1;

		// Token: 0x04000052 RID: 82
		private global::System.Windows.Forms.GroupBox groupBox2;

		// Token: 0x04000053 RID: 83
		private global::System.Windows.Forms.GroupBox groupBox3;

		// Token: 0x04000054 RID: 84
		private global::System.Windows.Forms.Button btnNewProfile;

		// Token: 0x04000055 RID: 85
		private global::System.Windows.Forms.GroupBox groupBox4;

		// Token: 0x04000056 RID: 86
		private global::TheArtOfDev.HtmlRenderer.WinForms.HtmlPanel wbNews;

		// Token: 0x04000057 RID: 87
		private global::System.Windows.Forms.Button btnRefresh;

		// Token: 0x04000058 RID: 88
		private global::System.Windows.Forms.Button btnConfig;

		// Token: 0x04000059 RID: 89
		private global::System.Windows.Forms.Button btnSocksCap;

		// Token: 0x0400005A RID: 90
		private global::System.Windows.Forms.Button btnOsfuscator;

		// Token: 0x0400005B RID: 91
		private global::System.Windows.Forms.Button btnOpenTextProfile;

		// Token: 0x0400005C RID: 92
		private global::System.Windows.Forms.Button btnOpenFile;

		// Token: 0x0400005D RID: 93
		private global::TheArtOfDev.HtmlRenderer.WinForms.HtmlPanel wbSetup;
	}
}
