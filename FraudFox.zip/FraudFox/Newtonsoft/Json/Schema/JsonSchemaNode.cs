﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x0200024E RID: 590
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	internal class JsonSchemaNode
	{
		// Token: 0x17000528 RID: 1320
		// (get) Token: 0x060022CD RID: 8909 RVA: 0x0001C798 File Offset: 0x0001A998
		// (set) Token: 0x060022CE RID: 8910 RVA: 0x0001C7A0 File Offset: 0x0001A9A0
		public string Id { get; private set; }

		// Token: 0x17000529 RID: 1321
		// (get) Token: 0x060022CF RID: 8911 RVA: 0x0001C7A9 File Offset: 0x0001A9A9
		// (set) Token: 0x060022D0 RID: 8912 RVA: 0x0001C7B1 File Offset: 0x0001A9B1
		public ReadOnlyCollection<JsonSchema> Schemas { get; private set; }

		// Token: 0x1700052A RID: 1322
		// (get) Token: 0x060022D1 RID: 8913 RVA: 0x0001C7BA File Offset: 0x0001A9BA
		// (set) Token: 0x060022D2 RID: 8914 RVA: 0x0001C7C2 File Offset: 0x0001A9C2
		public Dictionary<string, JsonSchemaNode> Properties { get; private set; }

		// Token: 0x1700052B RID: 1323
		// (get) Token: 0x060022D3 RID: 8915 RVA: 0x0001C7CB File Offset: 0x0001A9CB
		// (set) Token: 0x060022D4 RID: 8916 RVA: 0x0001C7D3 File Offset: 0x0001A9D3
		public Dictionary<string, JsonSchemaNode> PatternProperties { get; private set; }

		// Token: 0x1700052C RID: 1324
		// (get) Token: 0x060022D5 RID: 8917 RVA: 0x0001C7DC File Offset: 0x0001A9DC
		// (set) Token: 0x060022D6 RID: 8918 RVA: 0x0001C7E4 File Offset: 0x0001A9E4
		public List<JsonSchemaNode> Items { get; private set; }

		// Token: 0x1700052D RID: 1325
		// (get) Token: 0x060022D7 RID: 8919 RVA: 0x0001C7ED File Offset: 0x0001A9ED
		// (set) Token: 0x060022D8 RID: 8920 RVA: 0x0001C7F5 File Offset: 0x0001A9F5
		public JsonSchemaNode AdditionalProperties { get; set; }

		// Token: 0x1700052E RID: 1326
		// (get) Token: 0x060022D9 RID: 8921 RVA: 0x0001C7FE File Offset: 0x0001A9FE
		// (set) Token: 0x060022DA RID: 8922 RVA: 0x0001C806 File Offset: 0x0001AA06
		public JsonSchemaNode AdditionalItems { get; set; }

		// Token: 0x060022DB RID: 8923 RVA: 0x0008A2C0 File Offset: 0x000884C0
		public JsonSchemaNode(JsonSchema schema)
		{
			this.Schemas = new ReadOnlyCollection<JsonSchema>(new JsonSchema[] { schema });
			this.Properties = new Dictionary<string, JsonSchemaNode>();
			this.PatternProperties = new Dictionary<string, JsonSchemaNode>();
			this.Items = new List<JsonSchemaNode>();
			this.Id = JsonSchemaNode.GetId(this.Schemas);
		}

		// Token: 0x060022DC RID: 8924 RVA: 0x0008A320 File Offset: 0x00088520
		private JsonSchemaNode(JsonSchemaNode source, JsonSchema schema)
		{
			this.Schemas = new ReadOnlyCollection<JsonSchema>(source.Schemas.Union(new JsonSchema[] { schema }).ToList<JsonSchema>());
			this.Properties = new Dictionary<string, JsonSchemaNode>(source.Properties);
			this.PatternProperties = new Dictionary<string, JsonSchemaNode>(source.PatternProperties);
			this.Items = new List<JsonSchemaNode>(source.Items);
			this.AdditionalProperties = source.AdditionalProperties;
			this.AdditionalItems = source.AdditionalItems;
			this.Id = JsonSchemaNode.GetId(this.Schemas);
		}

		// Token: 0x060022DD RID: 8925 RVA: 0x0001C80F File Offset: 0x0001AA0F
		public JsonSchemaNode Combine(JsonSchema schema)
		{
			return new JsonSchemaNode(this, schema);
		}

		// Token: 0x060022DE RID: 8926 RVA: 0x0008A3BC File Offset: 0x000885BC
		public static string GetId(IEnumerable<JsonSchema> schemata)
		{
			return JsonSchemaNode.smethod_1(<Module>.smethod_25<string>(95595285U), schemata.Select((JsonSchema s) => s.InternalId).OrderBy((string id) => id, JsonSchemaNode.smethod_0()).ToArray<string>());
		}

		// Token: 0x060022E1 RID: 8929 RVA: 0x0001283F File Offset: 0x00010A3F
		static StringComparer smethod_0()
		{
			return StringComparer.Ordinal;
		}

		// Token: 0x060022E2 RID: 8930 RVA: 0x0000DAF6 File Offset: 0x0000BCF6
		static string smethod_1(string string_0, string[] string_1)
		{
			return string.Join(string_0, string_1);
		}
	}
}
