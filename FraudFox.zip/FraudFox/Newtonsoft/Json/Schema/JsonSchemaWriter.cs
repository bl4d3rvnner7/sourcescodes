﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x02000251 RID: 593
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	internal class JsonSchemaWriter
	{
		// Token: 0x060022EB RID: 8939 RVA: 0x0001C86C File Offset: 0x0001AA6C
		public JsonSchemaWriter(JsonWriter writer, JsonSchemaResolver resolver)
		{
			ValidationUtils.ArgumentNotNull(writer, <Module>.smethod_25<string>(3424533558U));
			this._writer = writer;
			this._resolver = resolver;
		}

		// Token: 0x060022EC RID: 8940 RVA: 0x0008A478 File Offset: 0x00088678
		private void ReferenceOrWriteSchema(JsonSchema schema)
		{
			if (schema.Id != null && this._resolver.GetSchema(schema.Id) != null)
			{
				this._writer.WriteStartObject();
				this._writer.WritePropertyName(<Module>.smethod_25<string>(2099451988U));
				this._writer.WriteValue(schema.Id);
				this._writer.WriteEndObject();
				return;
			}
			this.WriteSchema(schema);
		}

		// Token: 0x060022ED RID: 8941 RVA: 0x0008A4E4 File Offset: 0x000886E4
		public void WriteSchema(JsonSchema schema)
		{
			ValidationUtils.ArgumentNotNull(schema, <Module>.smethod_23<string>(1796736690U));
			if (!this._resolver.LoadedSchemas.Contains(schema))
			{
				this._resolver.LoadedSchemas.Add(schema);
			}
			this._writer.WriteStartObject();
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_25<string>(1989486810U), schema.Id);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_24<string>(3017533292U), schema.Title);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_26<string>(10868602U), schema.Description);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_24<string>(1567924673U), schema.Required);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_27<string>(1612793675U), schema.ReadOnly);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_26<string>(1903651106U), schema.Hidden);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_25<string>(1323251013U), schema.Transient);
			if (schema.Type != null)
			{
				this.WriteType(<Module>.smethod_27<string>(4029693297U), this._writer, schema.Type.Value);
			}
			if (!schema.AllowAdditionalProperties)
			{
				this._writer.WritePropertyName(<Module>.smethod_24<string>(3884351475U));
				this._writer.WriteValue(schema.AllowAdditionalProperties);
			}
			else if (schema.AdditionalProperties != null)
			{
				this._writer.WritePropertyName(<Module>.smethod_27<string>(1006711666U));
				this.ReferenceOrWriteSchema(schema.AdditionalProperties);
			}
			if (!schema.AllowAdditionalItems)
			{
				this._writer.WritePropertyName(<Module>.smethod_27<string>(726981508U));
				this._writer.WriteValue(schema.AllowAdditionalItems);
			}
			else if (schema.AdditionalItems != null)
			{
				this._writer.WritePropertyName(<Module>.smethod_24<string>(3654182289U));
				this.ReferenceOrWriteSchema(schema.AdditionalItems);
			}
			this.WriteSchemaDictionaryIfNotNull(this._writer, <Module>.smethod_24<string>(404892779U), schema.Properties);
			this.WriteSchemaDictionaryIfNotNull(this._writer, <Module>.smethod_26<string>(2333571307U), schema.PatternProperties);
			this.WriteItems(schema);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_26<string>(3781187729U), schema.Minimum);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_24<string>(3301561039U), schema.Maximum);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_26<string>(2352724095U), schema.ExclusiveMinimum);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_27<string>(74277806U), schema.ExclusiveMaximum);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_25<string>(3997402100U), schema.MinimumLength);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_27<string>(861075047U), schema.MaximumLength);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_26<string>(3206604089U), schema.MinimumItems);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_23<string>(217994926U), schema.MaximumItems);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_26<string>(1778140455U), schema.DivisibleBy);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_25<string>(676799146U), schema.Format);
			this.WritePropertyIfNotNull(this._writer, <Module>.smethod_24<string>(504476620U), schema.Pattern);
			if (schema.Enum != null)
			{
				this._writer.WritePropertyName(<Module>.smethod_26<string>(2511525060U));
				this._writer.WriteStartArray();
				IEnumerator<JToken> enumerator = schema.Enum.GetEnumerator();
				try
				{
					while (JsonSchemaWriter.smethod_0(enumerator))
					{
						JToken jtoken = enumerator.Current;
						jtoken.WriteTo(this._writer, new JsonConverter[0]);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						JsonSchemaWriter.smethod_1(enumerator);
					}
				}
				this._writer.WriteEndArray();
			}
			if (schema.Default != null)
			{
				this._writer.WritePropertyName(<Module>.smethod_27<string>(175160533U));
				schema.Default.WriteTo(this._writer, new JsonConverter[0]);
			}
			if (schema.Disallow != null)
			{
				this.WriteType(<Module>.smethod_23<string>(2848682954U), this._writer, schema.Disallow.Value);
			}
			if (schema.Extends != null && schema.Extends.Count > 0)
			{
				this._writer.WritePropertyName(<Module>.smethod_24<string>(3688733380U));
				if (schema.Extends.Count != 1)
				{
					this._writer.WriteStartArray();
					IEnumerator<JsonSchema> enumerator2 = schema.Extends.GetEnumerator();
					try
					{
						while (JsonSchemaWriter.smethod_0(enumerator2))
						{
							JsonSchema jsonSchema = enumerator2.Current;
							this.ReferenceOrWriteSchema(jsonSchema);
						}
					}
					finally
					{
						if (enumerator2 != null)
						{
							JsonSchemaWriter.smethod_1(enumerator2);
						}
					}
					this._writer.WriteEndArray();
				}
				else
				{
					this.ReferenceOrWriteSchema(schema.Extends[0]);
				}
			}
			this._writer.WriteEndObject();
		}

		// Token: 0x060022EE RID: 8942 RVA: 0x0008AA30 File Offset: 0x00088C30
		private void WriteSchemaDictionaryIfNotNull(JsonWriter writer, string propertyName, IDictionary<string, JsonSchema> properties)
		{
			if (properties != null)
			{
				writer.WritePropertyName(propertyName);
				writer.WriteStartObject();
				IEnumerator<KeyValuePair<string, JsonSchema>> enumerator = properties.GetEnumerator();
				try
				{
					while (JsonSchemaWriter.smethod_0(enumerator))
					{
						KeyValuePair<string, JsonSchema> keyValuePair = enumerator.Current;
						writer.WritePropertyName(keyValuePair.Key);
						this.ReferenceOrWriteSchema(keyValuePair.Value);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						JsonSchemaWriter.smethod_1(enumerator);
					}
				}
				writer.WriteEndObject();
			}
		}

		// Token: 0x060022EF RID: 8943 RVA: 0x0008AAA4 File Offset: 0x00088CA4
		private void WriteItems(JsonSchema schema)
		{
			if (schema.Items == null && !schema.PositionalItemsValidation)
			{
				return;
			}
			this._writer.WritePropertyName(<Module>.smethod_27<string>(4083743404U));
			if (schema.PositionalItemsValidation)
			{
				this._writer.WriteStartArray();
				if (schema.Items != null)
				{
					IEnumerator<JsonSchema> enumerator = schema.Items.GetEnumerator();
					try
					{
						while (JsonSchemaWriter.smethod_0(enumerator))
						{
							JsonSchema jsonSchema = enumerator.Current;
							this.ReferenceOrWriteSchema(jsonSchema);
						}
					}
					finally
					{
						if (enumerator != null)
						{
							JsonSchemaWriter.smethod_1(enumerator);
						}
					}
				}
				this._writer.WriteEndArray();
				return;
			}
			if (schema.Items != null && schema.Items.Count > 0)
			{
				this.ReferenceOrWriteSchema(schema.Items[0]);
				return;
			}
			this._writer.WriteStartObject();
			this._writer.WriteEndObject();
		}

		// Token: 0x060022F0 RID: 8944 RVA: 0x0008AB80 File Offset: 0x00088D80
		private void WriteType(string propertyName, JsonWriter writer, JsonSchemaType type)
		{
			IList<JsonSchemaType> list;
			if (JsonSchemaWriter.smethod_3(JsonSchemaWriter.smethod_2(typeof(JsonSchemaType).TypeHandle), type))
			{
				list = new List<JsonSchemaType> { type };
			}
			else
			{
				list = (from v in EnumUtils.GetFlagsValues<JsonSchemaType>(type)
					where v != JsonSchemaType.None
					select v).ToList<JsonSchemaType>();
			}
			if (list.Count == 0)
			{
				return;
			}
			writer.WritePropertyName(propertyName);
			if (list.Count != 1)
			{
				writer.WriteStartArray();
				IEnumerator<JsonSchemaType> enumerator = list.GetEnumerator();
				try
				{
					while (JsonSchemaWriter.smethod_0(enumerator))
					{
						JsonSchemaType jsonSchemaType = enumerator.Current;
						writer.WriteValue(JsonSchemaBuilder.MapType(jsonSchemaType));
					}
				}
				finally
				{
					if (enumerator != null)
					{
						JsonSchemaWriter.smethod_1(enumerator);
					}
				}
				writer.WriteEndArray();
				return;
			}
			writer.WriteValue(JsonSchemaBuilder.MapType(list[0]));
		}

		// Token: 0x060022F1 RID: 8945 RVA: 0x0001C892 File Offset: 0x0001AA92
		private void WritePropertyIfNotNull(JsonWriter writer, string propertyName, object value)
		{
			if (value != null)
			{
				writer.WritePropertyName(propertyName);
				writer.WriteValue(value);
			}
		}

		// Token: 0x060022F3 RID: 8947 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_0(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060022F4 RID: 8948 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_1(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060022F5 RID: 8949 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_2(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060022F6 RID: 8950 RVA: 0x0001C8AE File Offset: 0x0001AAAE
		static bool smethod_3(Type type_0, object object_0)
		{
			return Enum.IsDefined(type_0, object_0);
		}

		// Token: 0x04000C67 RID: 3175
		private readonly JsonWriter _writer;

		// Token: 0x04000C68 RID: 3176
		private readonly JsonSchemaResolver _resolver;
	}
}
