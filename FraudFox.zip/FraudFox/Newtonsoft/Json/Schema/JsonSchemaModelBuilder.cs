﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x0200024C RID: 588
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	internal class JsonSchemaModelBuilder
	{
		// Token: 0x060022C0 RID: 8896 RVA: 0x00089E7C File Offset: 0x0008807C
		public JsonSchemaModel Build(JsonSchema schema)
		{
			this._nodes = new JsonSchemaNodeCollection();
			this._node = this.AddSchema(null, schema);
			this._nodeModels = new Dictionary<JsonSchemaNode, JsonSchemaModel>();
			return this.BuildNodeModel(this._node);
		}

		// Token: 0x060022C1 RID: 8897 RVA: 0x00089EBC File Offset: 0x000880BC
		public JsonSchemaNode AddSchema(JsonSchemaNode existingNode, JsonSchema schema)
		{
			string text;
			if (existingNode != null)
			{
				if (existingNode.Schemas.Contains(schema))
				{
					return existingNode;
				}
				text = JsonSchemaNode.GetId(existingNode.Schemas.Union(new JsonSchema[] { schema }));
			}
			else
			{
				text = JsonSchemaNode.GetId(new JsonSchema[] { schema });
			}
			if (this._nodes.Contains(text))
			{
				return this._nodes[text];
			}
			JsonSchemaNode jsonSchemaNode = ((existingNode != null) ? existingNode.Combine(schema) : new JsonSchemaNode(schema));
			this._nodes.Add(jsonSchemaNode);
			this.AddProperties(schema.Properties, jsonSchemaNode.Properties);
			this.AddProperties(schema.PatternProperties, jsonSchemaNode.PatternProperties);
			if (schema.Items != null)
			{
				for (int i = 0; i < schema.Items.Count; i++)
				{
					this.AddItem(jsonSchemaNode, i, schema.Items[i]);
				}
			}
			if (schema.AdditionalItems != null)
			{
				this.AddAdditionalItems(jsonSchemaNode, schema.AdditionalItems);
			}
			if (schema.AdditionalProperties != null)
			{
				this.AddAdditionalProperties(jsonSchemaNode, schema.AdditionalProperties);
			}
			if (schema.Extends != null)
			{
				IEnumerator<JsonSchema> enumerator = schema.Extends.GetEnumerator();
				try
				{
					while (JsonSchemaModelBuilder.smethod_0(enumerator))
					{
						JsonSchema jsonSchema = enumerator.Current;
						jsonSchemaNode = this.AddSchema(jsonSchemaNode, jsonSchema);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						JsonSchemaModelBuilder.smethod_1(enumerator);
					}
				}
			}
			return jsonSchemaNode;
		}

		// Token: 0x060022C2 RID: 8898 RVA: 0x0008A028 File Offset: 0x00088228
		public void AddProperties(IDictionary<string, JsonSchema> source, IDictionary<string, JsonSchemaNode> target)
		{
			if (source != null)
			{
				IEnumerator<KeyValuePair<string, JsonSchema>> enumerator = source.GetEnumerator();
				try
				{
					while (JsonSchemaModelBuilder.smethod_0(enumerator))
					{
						KeyValuePair<string, JsonSchema> keyValuePair = enumerator.Current;
						this.AddProperty(target, keyValuePair.Key, keyValuePair.Value);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						JsonSchemaModelBuilder.smethod_1(enumerator);
					}
				}
			}
		}

		// Token: 0x060022C3 RID: 8899 RVA: 0x0008A084 File Offset: 0x00088284
		public void AddProperty(IDictionary<string, JsonSchemaNode> target, string propertyName, JsonSchema schema)
		{
			JsonSchemaNode jsonSchemaNode;
			target.TryGetValue(propertyName, out jsonSchemaNode);
			target[propertyName] = this.AddSchema(jsonSchemaNode, schema);
		}

		// Token: 0x060022C4 RID: 8900 RVA: 0x0008A0AC File Offset: 0x000882AC
		public void AddItem(JsonSchemaNode parentNode, int index, JsonSchema schema)
		{
			JsonSchemaNode jsonSchemaNode = ((parentNode.Items.Count > index) ? parentNode.Items[index] : null);
			JsonSchemaNode jsonSchemaNode2 = this.AddSchema(jsonSchemaNode, schema);
			if (parentNode.Items.Count <= index)
			{
				parentNode.Items.Add(jsonSchemaNode2);
				return;
			}
			parentNode.Items[index] = jsonSchemaNode2;
		}

		// Token: 0x060022C5 RID: 8901 RVA: 0x0001C740 File Offset: 0x0001A940
		public void AddAdditionalProperties(JsonSchemaNode parentNode, JsonSchema schema)
		{
			parentNode.AdditionalProperties = this.AddSchema(parentNode.AdditionalProperties, schema);
		}

		// Token: 0x060022C6 RID: 8902 RVA: 0x0001C755 File Offset: 0x0001A955
		public void AddAdditionalItems(JsonSchemaNode parentNode, JsonSchema schema)
		{
			parentNode.AdditionalItems = this.AddSchema(parentNode.AdditionalItems, schema);
		}

		// Token: 0x060022C7 RID: 8903 RVA: 0x0008A108 File Offset: 0x00088308
		private JsonSchemaModel BuildNodeModel(JsonSchemaNode node)
		{
			JsonSchemaModel jsonSchemaModel;
			if (!this._nodeModels.TryGetValue(node, out jsonSchemaModel))
			{
				jsonSchemaModel = JsonSchemaModel.Create(node.Schemas);
				this._nodeModels[node] = jsonSchemaModel;
				foreach (KeyValuePair<string, JsonSchemaNode> keyValuePair in node.Properties)
				{
					if (jsonSchemaModel.Properties == null)
					{
						jsonSchemaModel.Properties = new Dictionary<string, JsonSchemaModel>();
					}
					jsonSchemaModel.Properties[keyValuePair.Key] = this.BuildNodeModel(keyValuePair.Value);
				}
				foreach (KeyValuePair<string, JsonSchemaNode> keyValuePair2 in node.PatternProperties)
				{
					if (jsonSchemaModel.PatternProperties == null)
					{
						jsonSchemaModel.PatternProperties = new Dictionary<string, JsonSchemaModel>();
					}
					jsonSchemaModel.PatternProperties[keyValuePair2.Key] = this.BuildNodeModel(keyValuePair2.Value);
				}
				foreach (JsonSchemaNode jsonSchemaNode in node.Items)
				{
					if (jsonSchemaModel.Items == null)
					{
						jsonSchemaModel.Items = new List<JsonSchemaModel>();
					}
					jsonSchemaModel.Items.Add(this.BuildNodeModel(jsonSchemaNode));
				}
				if (node.AdditionalProperties != null)
				{
					jsonSchemaModel.AdditionalProperties = this.BuildNodeModel(node.AdditionalProperties);
				}
				if (node.AdditionalItems != null)
				{
					jsonSchemaModel.AdditionalItems = this.BuildNodeModel(node.AdditionalItems);
				}
				return jsonSchemaModel;
			}
			return jsonSchemaModel;
		}

		// Token: 0x060022C9 RID: 8905 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_0(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060022CA RID: 8906 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_1(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x04000C59 RID: 3161
		private JsonSchemaNodeCollection _nodes = new JsonSchemaNodeCollection();

		// Token: 0x04000C5A RID: 3162
		private Dictionary<JsonSchemaNode, JsonSchemaModel> _nodeModels = new Dictionary<JsonSchemaNode, JsonSchemaModel>();

		// Token: 0x04000C5B RID: 3163
		private JsonSchemaNode _node;
	}
}
