﻿using System;
using System.Runtime.Serialization;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x0200024A RID: 586
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	[Serializable]
	public class JsonSchemaException : JsonException
	{
		// Token: 0x1700050E RID: 1294
		// (get) Token: 0x06002282 RID: 8834 RVA: 0x0001C540 File Offset: 0x0001A740
		// (set) Token: 0x06002283 RID: 8835 RVA: 0x0001C548 File Offset: 0x0001A748
		public int LineNumber { get; private set; }

		// Token: 0x1700050F RID: 1295
		// (get) Token: 0x06002284 RID: 8836 RVA: 0x0001C551 File Offset: 0x0001A751
		// (set) Token: 0x06002285 RID: 8837 RVA: 0x0001C559 File Offset: 0x0001A759
		public int LinePosition { get; private set; }

		// Token: 0x17000510 RID: 1296
		// (get) Token: 0x06002286 RID: 8838 RVA: 0x0001C562 File Offset: 0x0001A762
		// (set) Token: 0x06002287 RID: 8839 RVA: 0x0001C56A File Offset: 0x0001A76A
		public string Path { get; private set; }

		// Token: 0x06002288 RID: 8840 RVA: 0x0001AC80 File Offset: 0x00018E80
		public JsonSchemaException()
		{
		}

		// Token: 0x06002289 RID: 8841 RVA: 0x0001AC88 File Offset: 0x00018E88
		public JsonSchemaException(string message)
			: base(message)
		{
		}

		// Token: 0x0600228A RID: 8842 RVA: 0x0001AC91 File Offset: 0x00018E91
		public JsonSchemaException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

		// Token: 0x0600228B RID: 8843 RVA: 0x0001AC9B File Offset: 0x00018E9B
		public JsonSchemaException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x0600228C RID: 8844 RVA: 0x0001C573 File Offset: 0x0001A773
		internal JsonSchemaException(string message, Exception innerException, string path, int lineNumber, int linePosition)
			: base(message, innerException)
		{
			this.Path = path;
			this.LineNumber = lineNumber;
			this.LinePosition = linePosition;
		}
	}
}
