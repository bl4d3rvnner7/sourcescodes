﻿using System;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x02000274 RID: 628
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	[Flags]
	public enum JsonSchemaType
	{
		// Token: 0x04000D37 RID: 3383
		None = 0,
		// Token: 0x04000D38 RID: 3384
		String = 1,
		// Token: 0x04000D39 RID: 3385
		Float = 2,
		// Token: 0x04000D3A RID: 3386
		Integer = 4,
		// Token: 0x04000D3B RID: 3387
		Boolean = 8,
		// Token: 0x04000D3C RID: 3388
		Object = 16,
		// Token: 0x04000D3D RID: 3389
		Array = 32,
		// Token: 0x04000D3E RID: 3390
		Null = 64,
		// Token: 0x04000D3F RID: 3391
		Any = 127
	}
}
