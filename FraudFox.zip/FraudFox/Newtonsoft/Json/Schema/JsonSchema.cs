﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x0200026D RID: 621
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	public class JsonSchema
	{
		// Token: 0x1700056D RID: 1389
		// (get) Token: 0x0600244A RID: 9290 RVA: 0x0001D1EB File Offset: 0x0001B3EB
		// (set) Token: 0x0600244B RID: 9291 RVA: 0x0001D1F3 File Offset: 0x0001B3F3
		public string Id { get; set; }

		// Token: 0x1700056E RID: 1390
		// (get) Token: 0x0600244C RID: 9292 RVA: 0x0001D1FC File Offset: 0x0001B3FC
		// (set) Token: 0x0600244D RID: 9293 RVA: 0x0001D204 File Offset: 0x0001B404
		public string Title { get; set; }

		// Token: 0x1700056F RID: 1391
		// (get) Token: 0x0600244E RID: 9294 RVA: 0x0001D20D File Offset: 0x0001B40D
		// (set) Token: 0x0600244F RID: 9295 RVA: 0x0001D215 File Offset: 0x0001B415
		public bool? Required { get; set; }

		// Token: 0x17000570 RID: 1392
		// (get) Token: 0x06002450 RID: 9296 RVA: 0x0001D21E File Offset: 0x0001B41E
		// (set) Token: 0x06002451 RID: 9297 RVA: 0x0001D226 File Offset: 0x0001B426
		public bool? ReadOnly { get; set; }

		// Token: 0x17000571 RID: 1393
		// (get) Token: 0x06002452 RID: 9298 RVA: 0x0001D22F File Offset: 0x0001B42F
		// (set) Token: 0x06002453 RID: 9299 RVA: 0x0001D237 File Offset: 0x0001B437
		public bool? Hidden { get; set; }

		// Token: 0x17000572 RID: 1394
		// (get) Token: 0x06002454 RID: 9300 RVA: 0x0001D240 File Offset: 0x0001B440
		// (set) Token: 0x06002455 RID: 9301 RVA: 0x0001D248 File Offset: 0x0001B448
		public bool? Transient { get; set; }

		// Token: 0x17000573 RID: 1395
		// (get) Token: 0x06002456 RID: 9302 RVA: 0x0001D251 File Offset: 0x0001B451
		// (set) Token: 0x06002457 RID: 9303 RVA: 0x0001D259 File Offset: 0x0001B459
		public string Description { get; set; }

		// Token: 0x17000574 RID: 1396
		// (get) Token: 0x06002458 RID: 9304 RVA: 0x0001D262 File Offset: 0x0001B462
		// (set) Token: 0x06002459 RID: 9305 RVA: 0x0001D26A File Offset: 0x0001B46A
		public JsonSchemaType? Type { get; set; }

		// Token: 0x17000575 RID: 1397
		// (get) Token: 0x0600245A RID: 9306 RVA: 0x0001D273 File Offset: 0x0001B473
		// (set) Token: 0x0600245B RID: 9307 RVA: 0x0001D27B File Offset: 0x0001B47B
		public string Pattern { get; set; }

		// Token: 0x17000576 RID: 1398
		// (get) Token: 0x0600245C RID: 9308 RVA: 0x0001D284 File Offset: 0x0001B484
		// (set) Token: 0x0600245D RID: 9309 RVA: 0x0001D28C File Offset: 0x0001B48C
		public int? MinimumLength { get; set; }

		// Token: 0x17000577 RID: 1399
		// (get) Token: 0x0600245E RID: 9310 RVA: 0x0001D295 File Offset: 0x0001B495
		// (set) Token: 0x0600245F RID: 9311 RVA: 0x0001D29D File Offset: 0x0001B49D
		public int? MaximumLength { get; set; }

		// Token: 0x17000578 RID: 1400
		// (get) Token: 0x06002460 RID: 9312 RVA: 0x0001D2A6 File Offset: 0x0001B4A6
		// (set) Token: 0x06002461 RID: 9313 RVA: 0x0001D2AE File Offset: 0x0001B4AE
		public double? DivisibleBy { get; set; }

		// Token: 0x17000579 RID: 1401
		// (get) Token: 0x06002462 RID: 9314 RVA: 0x0001D2B7 File Offset: 0x0001B4B7
		// (set) Token: 0x06002463 RID: 9315 RVA: 0x0001D2BF File Offset: 0x0001B4BF
		public double? Minimum { get; set; }

		// Token: 0x1700057A RID: 1402
		// (get) Token: 0x06002464 RID: 9316 RVA: 0x0001D2C8 File Offset: 0x0001B4C8
		// (set) Token: 0x06002465 RID: 9317 RVA: 0x0001D2D0 File Offset: 0x0001B4D0
		public double? Maximum { get; set; }

		// Token: 0x1700057B RID: 1403
		// (get) Token: 0x06002466 RID: 9318 RVA: 0x0001D2D9 File Offset: 0x0001B4D9
		// (set) Token: 0x06002467 RID: 9319 RVA: 0x0001D2E1 File Offset: 0x0001B4E1
		public bool? ExclusiveMinimum { get; set; }

		// Token: 0x1700057C RID: 1404
		// (get) Token: 0x06002468 RID: 9320 RVA: 0x0001D2EA File Offset: 0x0001B4EA
		// (set) Token: 0x06002469 RID: 9321 RVA: 0x0001D2F2 File Offset: 0x0001B4F2
		public bool? ExclusiveMaximum { get; set; }

		// Token: 0x1700057D RID: 1405
		// (get) Token: 0x0600246A RID: 9322 RVA: 0x0001D2FB File Offset: 0x0001B4FB
		// (set) Token: 0x0600246B RID: 9323 RVA: 0x0001D303 File Offset: 0x0001B503
		public int? MinimumItems { get; set; }

		// Token: 0x1700057E RID: 1406
		// (get) Token: 0x0600246C RID: 9324 RVA: 0x0001D30C File Offset: 0x0001B50C
		// (set) Token: 0x0600246D RID: 9325 RVA: 0x0001D314 File Offset: 0x0001B514
		public int? MaximumItems { get; set; }

		// Token: 0x1700057F RID: 1407
		// (get) Token: 0x0600246E RID: 9326 RVA: 0x0001D31D File Offset: 0x0001B51D
		// (set) Token: 0x0600246F RID: 9327 RVA: 0x0001D325 File Offset: 0x0001B525
		public IList<JsonSchema> Items { get; set; }

		// Token: 0x17000580 RID: 1408
		// (get) Token: 0x06002470 RID: 9328 RVA: 0x0001D32E File Offset: 0x0001B52E
		// (set) Token: 0x06002471 RID: 9329 RVA: 0x0001D336 File Offset: 0x0001B536
		public bool PositionalItemsValidation { get; set; }

		// Token: 0x17000581 RID: 1409
		// (get) Token: 0x06002472 RID: 9330 RVA: 0x0001D33F File Offset: 0x0001B53F
		// (set) Token: 0x06002473 RID: 9331 RVA: 0x0001D347 File Offset: 0x0001B547
		public JsonSchema AdditionalItems { get; set; }

		// Token: 0x17000582 RID: 1410
		// (get) Token: 0x06002474 RID: 9332 RVA: 0x0001D350 File Offset: 0x0001B550
		// (set) Token: 0x06002475 RID: 9333 RVA: 0x0001D358 File Offset: 0x0001B558
		public bool AllowAdditionalItems { get; set; }

		// Token: 0x17000583 RID: 1411
		// (get) Token: 0x06002476 RID: 9334 RVA: 0x0001D361 File Offset: 0x0001B561
		// (set) Token: 0x06002477 RID: 9335 RVA: 0x0001D369 File Offset: 0x0001B569
		public bool UniqueItems { get; set; }

		// Token: 0x17000584 RID: 1412
		// (get) Token: 0x06002478 RID: 9336 RVA: 0x0001D372 File Offset: 0x0001B572
		// (set) Token: 0x06002479 RID: 9337 RVA: 0x0001D37A File Offset: 0x0001B57A
		public IDictionary<string, JsonSchema> Properties { get; set; }

		// Token: 0x17000585 RID: 1413
		// (get) Token: 0x0600247A RID: 9338 RVA: 0x0001D383 File Offset: 0x0001B583
		// (set) Token: 0x0600247B RID: 9339 RVA: 0x0001D38B File Offset: 0x0001B58B
		public JsonSchema AdditionalProperties { get; set; }

		// Token: 0x17000586 RID: 1414
		// (get) Token: 0x0600247C RID: 9340 RVA: 0x0001D394 File Offset: 0x0001B594
		// (set) Token: 0x0600247D RID: 9341 RVA: 0x0001D39C File Offset: 0x0001B59C
		public IDictionary<string, JsonSchema> PatternProperties { get; set; }

		// Token: 0x17000587 RID: 1415
		// (get) Token: 0x0600247E RID: 9342 RVA: 0x0001D3A5 File Offset: 0x0001B5A5
		// (set) Token: 0x0600247F RID: 9343 RVA: 0x0001D3AD File Offset: 0x0001B5AD
		public bool AllowAdditionalProperties { get; set; }

		// Token: 0x17000588 RID: 1416
		// (get) Token: 0x06002480 RID: 9344 RVA: 0x0001D3B6 File Offset: 0x0001B5B6
		// (set) Token: 0x06002481 RID: 9345 RVA: 0x0001D3BE File Offset: 0x0001B5BE
		public string Requires { get; set; }

		// Token: 0x17000589 RID: 1417
		// (get) Token: 0x06002482 RID: 9346 RVA: 0x0001D3C7 File Offset: 0x0001B5C7
		// (set) Token: 0x06002483 RID: 9347 RVA: 0x0001D3CF File Offset: 0x0001B5CF
		public IList<JToken> Enum { get; set; }

		// Token: 0x1700058A RID: 1418
		// (get) Token: 0x06002484 RID: 9348 RVA: 0x0001D3D8 File Offset: 0x0001B5D8
		// (set) Token: 0x06002485 RID: 9349 RVA: 0x0001D3E0 File Offset: 0x0001B5E0
		public JsonSchemaType? Disallow { get; set; }

		// Token: 0x1700058B RID: 1419
		// (get) Token: 0x06002486 RID: 9350 RVA: 0x0001D3E9 File Offset: 0x0001B5E9
		// (set) Token: 0x06002487 RID: 9351 RVA: 0x0001D3F1 File Offset: 0x0001B5F1
		public JToken Default { get; set; }

		// Token: 0x1700058C RID: 1420
		// (get) Token: 0x06002488 RID: 9352 RVA: 0x0001D3FA File Offset: 0x0001B5FA
		// (set) Token: 0x06002489 RID: 9353 RVA: 0x0001D402 File Offset: 0x0001B602
		public IList<JsonSchema> Extends { get; set; }

		// Token: 0x1700058D RID: 1421
		// (get) Token: 0x0600248A RID: 9354 RVA: 0x0001D40B File Offset: 0x0001B60B
		// (set) Token: 0x0600248B RID: 9355 RVA: 0x0001D413 File Offset: 0x0001B613
		public string Format { get; set; }

		// Token: 0x1700058E RID: 1422
		// (get) Token: 0x0600248C RID: 9356 RVA: 0x0001D41C File Offset: 0x0001B61C
		// (set) Token: 0x0600248D RID: 9357 RVA: 0x0001D424 File Offset: 0x0001B624
		internal string Location { get; set; }

		// Token: 0x1700058F RID: 1423
		// (get) Token: 0x0600248E RID: 9358 RVA: 0x0001D42D File Offset: 0x0001B62D
		internal string InternalId
		{
			get
			{
				return this._internalId;
			}
		}

		// Token: 0x17000590 RID: 1424
		// (get) Token: 0x0600248F RID: 9359 RVA: 0x0001D435 File Offset: 0x0001B635
		// (set) Token: 0x06002490 RID: 9360 RVA: 0x0001D43D File Offset: 0x0001B63D
		internal string DeferredReference { get; set; }

		// Token: 0x17000591 RID: 1425
		// (get) Token: 0x06002491 RID: 9361 RVA: 0x0001D446 File Offset: 0x0001B646
		// (set) Token: 0x06002492 RID: 9362 RVA: 0x0001D44E File Offset: 0x0001B64E
		internal bool ReferencesResolved { get; set; }

		// Token: 0x06002493 RID: 9363 RVA: 0x0008D2AC File Offset: 0x0008B4AC
		public JsonSchema()
		{
			this.AllowAdditionalProperties = true;
			this.AllowAdditionalItems = true;
		}

		// Token: 0x06002494 RID: 9364 RVA: 0x0001D457 File Offset: 0x0001B657
		public static JsonSchema Read(JsonReader reader)
		{
			return JsonSchema.Read(reader, new JsonSchemaResolver());
		}

		// Token: 0x06002495 RID: 9365 RVA: 0x0008D2EC File Offset: 0x0008B4EC
		public static JsonSchema Read(JsonReader reader, JsonSchemaResolver resolver)
		{
			ValidationUtils.ArgumentNotNull(reader, <Module>.smethod_23<string>(3289837803U));
			ValidationUtils.ArgumentNotNull(resolver, <Module>.smethod_25<string>(1759581897U));
			JsonSchemaBuilder jsonSchemaBuilder = new JsonSchemaBuilder(resolver);
			return jsonSchemaBuilder.Read(reader);
		}

		// Token: 0x06002496 RID: 9366 RVA: 0x0001D464 File Offset: 0x0001B664
		public static JsonSchema Parse(string json)
		{
			return JsonSchema.Parse(json, new JsonSchemaResolver());
		}

		// Token: 0x06002497 RID: 9367 RVA: 0x0008D328 File Offset: 0x0008B528
		public static JsonSchema Parse(string json, JsonSchemaResolver resolver)
		{
			ValidationUtils.ArgumentNotNull(json, <Module>.smethod_24<string>(1343345373U));
			JsonReader jsonReader = new JsonTextReader(JsonSchema.smethod_0(json));
			JsonSchema jsonSchema;
			try
			{
				jsonSchema = JsonSchema.Read(jsonReader, resolver);
			}
			finally
			{
				if (jsonReader != null)
				{
					JsonSchema.smethod_1(jsonReader);
				}
			}
			return jsonSchema;
		}

		// Token: 0x06002498 RID: 9368 RVA: 0x0001D471 File Offset: 0x0001B671
		public void WriteTo(JsonWriter writer)
		{
			this.WriteTo(writer, new JsonSchemaResolver());
		}

		// Token: 0x06002499 RID: 9369 RVA: 0x0008D378 File Offset: 0x0008B578
		public void WriteTo(JsonWriter writer, JsonSchemaResolver resolver)
		{
			ValidationUtils.ArgumentNotNull(writer, <Module>.smethod_24<string>(411494440U));
			ValidationUtils.ArgumentNotNull(resolver, <Module>.smethod_25<string>(1759581897U));
			JsonSchemaWriter jsonSchemaWriter = new JsonSchemaWriter(writer, resolver);
			jsonSchemaWriter.WriteSchema(this);
		}

		// Token: 0x0600249A RID: 9370 RVA: 0x0008D3B4 File Offset: 0x0008B5B4
		public override string ToString()
		{
			StringWriter stringWriter = JsonSchema.smethod_3(JsonSchema.smethod_2());
			this.WriteTo(new JsonTextWriter(stringWriter)
			{
				Formatting = Formatting.Indented
			});
			return JsonSchema.smethod_4(stringWriter);
		}

		// Token: 0x0600249B RID: 9371 RVA: 0x000161BD File Offset: 0x000143BD
		static StringReader smethod_0(string string_0)
		{
			return new StringReader(string_0);
		}

		// Token: 0x0600249C RID: 9372 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_1(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x0600249D RID: 9373 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_2()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x0600249E RID: 9374 RVA: 0x00016261 File Offset: 0x00014461
		static StringWriter smethod_3(IFormatProvider iformatProvider_0)
		{
			return new StringWriter(iformatProvider_0);
		}

		// Token: 0x0600249F RID: 9375 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_4(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x04000CE2 RID: 3298
		private readonly string _internalId = Guid.NewGuid().ToString(<Module>.smethod_25<string>(1898776803U));
	}
}
