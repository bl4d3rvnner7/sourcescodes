﻿using System;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x02000253 RID: 595
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	public class ValidationEventArgs : EventArgs
	{
		// Token: 0x060022F7 RID: 8951 RVA: 0x0001C8B7 File Offset: 0x0001AAB7
		internal ValidationEventArgs(JsonSchemaException ex)
		{
			ValidationUtils.ArgumentNotNull(ex, <Module>.smethod_26<string>(2790258015U));
			this._ex = ex;
		}

		// Token: 0x17000530 RID: 1328
		// (get) Token: 0x060022F8 RID: 8952 RVA: 0x0001C8D6 File Offset: 0x0001AAD6
		public JsonSchemaException Exception
		{
			get
			{
				return this._ex;
			}
		}

		// Token: 0x17000531 RID: 1329
		// (get) Token: 0x060022F9 RID: 8953 RVA: 0x0001C8DE File Offset: 0x0001AADE
		public string Path
		{
			get
			{
				return this._ex.Path;
			}
		}

		// Token: 0x17000532 RID: 1330
		// (get) Token: 0x060022FA RID: 8954 RVA: 0x0001C8EB File Offset: 0x0001AAEB
		public string Message
		{
			get
			{
				return ValidationEventArgs.smethod_0(this._ex);
			}
		}

		// Token: 0x060022FB RID: 8955 RVA: 0x0000D3E3 File Offset: 0x0000B5E3
		static string smethod_0(Exception exception_0)
		{
			return exception_0.Message;
		}

		// Token: 0x04000C6E RID: 3182
		private readonly JsonSchemaException _ex;
	}
}
