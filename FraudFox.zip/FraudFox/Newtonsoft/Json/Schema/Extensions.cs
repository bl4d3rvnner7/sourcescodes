﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x02000247 RID: 583
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	public static class Extensions
	{
		// Token: 0x06002279 RID: 8825 RVA: 0x00089B04 File Offset: 0x00087D04
		[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
		public static bool IsValid(this JToken source, JsonSchema schema)
		{
			bool valid = true;
			source.Validate(schema, delegate(object sender, ValidationEventArgs e)
			{
				valid = false;
			});
			return valid;
		}

		// Token: 0x0600227A RID: 8826 RVA: 0x00089B38 File Offset: 0x00087D38
		[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
		public static bool IsValid(this JToken source, JsonSchema schema, out IList<string> errorMessages)
		{
			IList<string> errors = new List<string>();
			source.Validate(schema, delegate(object sender, ValidationEventArgs e)
			{
				errors.Add(e.Message);
			});
			errorMessages = errors;
			return errorMessages.Count == 0;
		}

		// Token: 0x0600227B RID: 8827 RVA: 0x0001C51A File Offset: 0x0001A71A
		[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
		public static void Validate(this JToken source, JsonSchema schema)
		{
			source.Validate(schema, null);
		}

		// Token: 0x0600227C RID: 8828 RVA: 0x00089B7C File Offset: 0x00087D7C
		[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
		public static void Validate(this JToken source, JsonSchema schema, ValidationEventHandler validationEventHandler)
		{
			ValidationUtils.ArgumentNotNull(source, <Module>.smethod_27<string>(3867050813U));
			ValidationUtils.ArgumentNotNull(schema, <Module>.smethod_23<string>(1796736690U));
			JsonValidatingReader jsonValidatingReader = new JsonValidatingReader(source.CreateReader());
			try
			{
				jsonValidatingReader.Schema = schema;
				if (validationEventHandler != null)
				{
					jsonValidatingReader.ValidationEventHandler += validationEventHandler;
				}
				while (jsonValidatingReader.Read())
				{
				}
			}
			finally
			{
				if (jsonValidatingReader != null)
				{
					Extensions.smethod_0(jsonValidatingReader);
				}
			}
		}

		// Token: 0x0600227D RID: 8829 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_0(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}
	}
}
