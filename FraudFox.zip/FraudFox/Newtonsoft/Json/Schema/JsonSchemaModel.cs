﻿using System;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x0200024B RID: 587
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	internal class JsonSchemaModel
	{
		// Token: 0x17000511 RID: 1297
		// (get) Token: 0x0600228D RID: 8845 RVA: 0x0001C594 File Offset: 0x0001A794
		// (set) Token: 0x0600228E RID: 8846 RVA: 0x0001C59C File Offset: 0x0001A79C
		public bool Required { get; set; }

		// Token: 0x17000512 RID: 1298
		// (get) Token: 0x0600228F RID: 8847 RVA: 0x0001C5A5 File Offset: 0x0001A7A5
		// (set) Token: 0x06002290 RID: 8848 RVA: 0x0001C5AD File Offset: 0x0001A7AD
		public JsonSchemaType Type { get; set; }

		// Token: 0x17000513 RID: 1299
		// (get) Token: 0x06002291 RID: 8849 RVA: 0x0001C5B6 File Offset: 0x0001A7B6
		// (set) Token: 0x06002292 RID: 8850 RVA: 0x0001C5BE File Offset: 0x0001A7BE
		public int? MinimumLength { get; set; }

		// Token: 0x17000514 RID: 1300
		// (get) Token: 0x06002293 RID: 8851 RVA: 0x0001C5C7 File Offset: 0x0001A7C7
		// (set) Token: 0x06002294 RID: 8852 RVA: 0x0001C5CF File Offset: 0x0001A7CF
		public int? MaximumLength { get; set; }

		// Token: 0x17000515 RID: 1301
		// (get) Token: 0x06002295 RID: 8853 RVA: 0x0001C5D8 File Offset: 0x0001A7D8
		// (set) Token: 0x06002296 RID: 8854 RVA: 0x0001C5E0 File Offset: 0x0001A7E0
		public double? DivisibleBy { get; set; }

		// Token: 0x17000516 RID: 1302
		// (get) Token: 0x06002297 RID: 8855 RVA: 0x0001C5E9 File Offset: 0x0001A7E9
		// (set) Token: 0x06002298 RID: 8856 RVA: 0x0001C5F1 File Offset: 0x0001A7F1
		public double? Minimum { get; set; }

		// Token: 0x17000517 RID: 1303
		// (get) Token: 0x06002299 RID: 8857 RVA: 0x0001C5FA File Offset: 0x0001A7FA
		// (set) Token: 0x0600229A RID: 8858 RVA: 0x0001C602 File Offset: 0x0001A802
		public double? Maximum { get; set; }

		// Token: 0x17000518 RID: 1304
		// (get) Token: 0x0600229B RID: 8859 RVA: 0x0001C60B File Offset: 0x0001A80B
		// (set) Token: 0x0600229C RID: 8860 RVA: 0x0001C613 File Offset: 0x0001A813
		public bool ExclusiveMinimum { get; set; }

		// Token: 0x17000519 RID: 1305
		// (get) Token: 0x0600229D RID: 8861 RVA: 0x0001C61C File Offset: 0x0001A81C
		// (set) Token: 0x0600229E RID: 8862 RVA: 0x0001C624 File Offset: 0x0001A824
		public bool ExclusiveMaximum { get; set; }

		// Token: 0x1700051A RID: 1306
		// (get) Token: 0x0600229F RID: 8863 RVA: 0x0001C62D File Offset: 0x0001A82D
		// (set) Token: 0x060022A0 RID: 8864 RVA: 0x0001C635 File Offset: 0x0001A835
		public int? MinimumItems { get; set; }

		// Token: 0x1700051B RID: 1307
		// (get) Token: 0x060022A1 RID: 8865 RVA: 0x0001C63E File Offset: 0x0001A83E
		// (set) Token: 0x060022A2 RID: 8866 RVA: 0x0001C646 File Offset: 0x0001A846
		public int? MaximumItems { get; set; }

		// Token: 0x1700051C RID: 1308
		// (get) Token: 0x060022A3 RID: 8867 RVA: 0x0001C64F File Offset: 0x0001A84F
		// (set) Token: 0x060022A4 RID: 8868 RVA: 0x0001C657 File Offset: 0x0001A857
		public IList<string> Patterns { get; set; }

		// Token: 0x1700051D RID: 1309
		// (get) Token: 0x060022A5 RID: 8869 RVA: 0x0001C660 File Offset: 0x0001A860
		// (set) Token: 0x060022A6 RID: 8870 RVA: 0x0001C668 File Offset: 0x0001A868
		public IList<JsonSchemaModel> Items { get; set; }

		// Token: 0x1700051E RID: 1310
		// (get) Token: 0x060022A7 RID: 8871 RVA: 0x0001C671 File Offset: 0x0001A871
		// (set) Token: 0x060022A8 RID: 8872 RVA: 0x0001C679 File Offset: 0x0001A879
		public IDictionary<string, JsonSchemaModel> Properties { get; set; }

		// Token: 0x1700051F RID: 1311
		// (get) Token: 0x060022A9 RID: 8873 RVA: 0x0001C682 File Offset: 0x0001A882
		// (set) Token: 0x060022AA RID: 8874 RVA: 0x0001C68A File Offset: 0x0001A88A
		public IDictionary<string, JsonSchemaModel> PatternProperties { get; set; }

		// Token: 0x17000520 RID: 1312
		// (get) Token: 0x060022AB RID: 8875 RVA: 0x0001C693 File Offset: 0x0001A893
		// (set) Token: 0x060022AC RID: 8876 RVA: 0x0001C69B File Offset: 0x0001A89B
		public JsonSchemaModel AdditionalProperties { get; set; }

		// Token: 0x17000521 RID: 1313
		// (get) Token: 0x060022AD RID: 8877 RVA: 0x0001C6A4 File Offset: 0x0001A8A4
		// (set) Token: 0x060022AE RID: 8878 RVA: 0x0001C6AC File Offset: 0x0001A8AC
		public JsonSchemaModel AdditionalItems { get; set; }

		// Token: 0x17000522 RID: 1314
		// (get) Token: 0x060022AF RID: 8879 RVA: 0x0001C6B5 File Offset: 0x0001A8B5
		// (set) Token: 0x060022B0 RID: 8880 RVA: 0x0001C6BD File Offset: 0x0001A8BD
		public bool PositionalItemsValidation { get; set; }

		// Token: 0x17000523 RID: 1315
		// (get) Token: 0x060022B1 RID: 8881 RVA: 0x0001C6C6 File Offset: 0x0001A8C6
		// (set) Token: 0x060022B2 RID: 8882 RVA: 0x0001C6CE File Offset: 0x0001A8CE
		public bool AllowAdditionalProperties { get; set; }

		// Token: 0x17000524 RID: 1316
		// (get) Token: 0x060022B3 RID: 8883 RVA: 0x0001C6D7 File Offset: 0x0001A8D7
		// (set) Token: 0x060022B4 RID: 8884 RVA: 0x0001C6DF File Offset: 0x0001A8DF
		public bool AllowAdditionalItems { get; set; }

		// Token: 0x17000525 RID: 1317
		// (get) Token: 0x060022B5 RID: 8885 RVA: 0x0001C6E8 File Offset: 0x0001A8E8
		// (set) Token: 0x060022B6 RID: 8886 RVA: 0x0001C6F0 File Offset: 0x0001A8F0
		public bool UniqueItems { get; set; }

		// Token: 0x17000526 RID: 1318
		// (get) Token: 0x060022B7 RID: 8887 RVA: 0x0001C6F9 File Offset: 0x0001A8F9
		// (set) Token: 0x060022B8 RID: 8888 RVA: 0x0001C701 File Offset: 0x0001A901
		public IList<JToken> Enum { get; set; }

		// Token: 0x17000527 RID: 1319
		// (get) Token: 0x060022B9 RID: 8889 RVA: 0x0001C70A File Offset: 0x0001A90A
		// (set) Token: 0x060022BA RID: 8890 RVA: 0x0001C712 File Offset: 0x0001A912
		public JsonSchemaType Disallow { get; set; }

		// Token: 0x060022BB RID: 8891 RVA: 0x0001C71B File Offset: 0x0001A91B
		public JsonSchemaModel()
		{
			this.Type = JsonSchemaType.Any;
			this.AllowAdditionalProperties = true;
			this.AllowAdditionalItems = true;
			this.Required = false;
		}

		// Token: 0x060022BC RID: 8892 RVA: 0x00089BF0 File Offset: 0x00087DF0
		public static JsonSchemaModel Create(IList<JsonSchema> schemata)
		{
			JsonSchemaModel jsonSchemaModel = new JsonSchemaModel();
			IEnumerator<JsonSchema> enumerator = schemata.GetEnumerator();
			try
			{
				while (JsonSchemaModel.smethod_0(enumerator))
				{
					JsonSchema jsonSchema = enumerator.Current;
					JsonSchemaModel.Combine(jsonSchemaModel, jsonSchema);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JsonSchemaModel.smethod_1(enumerator);
				}
			}
			return jsonSchemaModel;
		}

		// Token: 0x060022BD RID: 8893 RVA: 0x00089C40 File Offset: 0x00087E40
		private static void Combine(JsonSchemaModel model, JsonSchema schema)
		{
			model.Required = model.Required || (schema.Required ?? false);
			model.Type &= schema.Type ?? JsonSchemaType.Any;
			model.MinimumLength = MathUtils.Max(model.MinimumLength, schema.MinimumLength);
			model.MaximumLength = MathUtils.Min(model.MaximumLength, schema.MaximumLength);
			model.DivisibleBy = MathUtils.Max(model.DivisibleBy, schema.DivisibleBy);
			model.Minimum = MathUtils.Max(model.Minimum, schema.Minimum);
			model.Maximum = MathUtils.Max(model.Maximum, schema.Maximum);
			model.ExclusiveMinimum = model.ExclusiveMinimum || (schema.ExclusiveMinimum ?? false);
			model.ExclusiveMaximum = model.ExclusiveMaximum || (schema.ExclusiveMaximum ?? false);
			model.MinimumItems = MathUtils.Max(model.MinimumItems, schema.MinimumItems);
			model.MaximumItems = MathUtils.Min(model.MaximumItems, schema.MaximumItems);
			model.PositionalItemsValidation = model.PositionalItemsValidation || schema.PositionalItemsValidation;
			model.AllowAdditionalProperties = model.AllowAdditionalProperties && schema.AllowAdditionalProperties;
			model.AllowAdditionalItems = model.AllowAdditionalItems && schema.AllowAdditionalItems;
			model.UniqueItems = model.UniqueItems || schema.UniqueItems;
			if (schema.Enum != null)
			{
				if (model.Enum == null)
				{
					model.Enum = new List<JToken>();
				}
				model.Enum.AddRangeDistinct(schema.Enum, JToken.EqualityComparer);
			}
			model.Disallow |= schema.Disallow ?? JsonSchemaType.None;
			if (schema.Pattern != null)
			{
				if (model.Patterns == null)
				{
					model.Patterns = new List<string>();
				}
				model.Patterns.AddDistinct(schema.Pattern);
			}
		}

		// Token: 0x060022BE RID: 8894 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_0(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060022BF RID: 8895 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_1(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}
	}
}
