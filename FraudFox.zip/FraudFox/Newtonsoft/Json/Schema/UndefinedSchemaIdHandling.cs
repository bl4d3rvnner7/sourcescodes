﻿using System;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x02000252 RID: 594
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	public enum UndefinedSchemaIdHandling
	{
		// Token: 0x04000C6B RID: 3179
		None,
		// Token: 0x04000C6C RID: 3180
		UseTypeName,
		// Token: 0x04000C6D RID: 3181
		UseAssemblyQualifiedName
	}
}
