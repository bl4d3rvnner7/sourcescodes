﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x0200026E RID: 622
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	internal class JsonSchemaBuilder
	{
		// Token: 0x060024A0 RID: 9376 RVA: 0x0001D47F File Offset: 0x0001B67F
		public JsonSchemaBuilder(JsonSchemaResolver resolver)
		{
			this._stack = new List<JsonSchema>();
			this._documentSchemas = new Dictionary<string, JsonSchema>();
			this._resolver = resolver;
		}

		// Token: 0x060024A1 RID: 9377 RVA: 0x0001D4A4 File Offset: 0x0001B6A4
		private void Push(JsonSchema value)
		{
			this._currentSchema = value;
			this._stack.Add(value);
			this._resolver.LoadedSchemas.Add(value);
			this._documentSchemas.Add(value.Location, value);
		}

		// Token: 0x060024A2 RID: 9378 RVA: 0x0008D3E8 File Offset: 0x0008B5E8
		private JsonSchema Pop()
		{
			JsonSchema currentSchema = this._currentSchema;
			this._stack.RemoveAt(this._stack.Count - 1);
			this._currentSchema = this._stack.LastOrDefault<JsonSchema>();
			return currentSchema;
		}

		// Token: 0x17000592 RID: 1426
		// (get) Token: 0x060024A3 RID: 9379 RVA: 0x0001D4DC File Offset: 0x0001B6DC
		private JsonSchema CurrentSchema
		{
			get
			{
				return this._currentSchema;
			}
		}

		// Token: 0x060024A4 RID: 9380 RVA: 0x0008D428 File Offset: 0x0008B628
		internal JsonSchema Read(JsonReader reader)
		{
			JToken jtoken = JToken.ReadFrom(reader);
			this._rootSchema = jtoken as JObject;
			JsonSchema jsonSchema = this.BuildSchema(jtoken);
			this.ResolveReferences(jsonSchema);
			return jsonSchema;
		}

		// Token: 0x060024A5 RID: 9381 RVA: 0x0001D4E4 File Offset: 0x0001B6E4
		private string UnescapeReference(string reference)
		{
			return JsonSchemaBuilder.smethod_1(JsonSchemaBuilder.smethod_1(JsonSchemaBuilder.smethod_0(reference), <Module>.smethod_27<string>(1000490753U), <Module>.smethod_26<string>(2625042512U)), <Module>.smethod_25<string>(2525153880U), <Module>.smethod_27<string>(441030437U));
		}

		// Token: 0x060024A6 RID: 9382 RVA: 0x0008D45C File Offset: 0x0008B65C
		private JsonSchema ResolveReferences(JsonSchema schema)
		{
			if (schema.DeferredReference != null)
			{
				string text = schema.DeferredReference;
				bool flag;
				if (flag = JsonSchemaBuilder.smethod_2(text, <Module>.smethod_27<string>(3760158100U), StringComparison.Ordinal))
				{
					text = this.UnescapeReference(text);
				}
				JsonSchema jsonSchema = this._resolver.GetSchema(text);
				if (jsonSchema == null)
				{
					if (flag)
					{
						string[] array = JsonSchemaBuilder.smethod_4(JsonSchemaBuilder.smethod_3(schema.DeferredReference, new char[] { '#' }), new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
						JToken jtoken = this._rootSchema;
						foreach (string text2 in array)
						{
							string text3 = this.UnescapeReference(text2);
							if (jtoken.Type != JTokenType.Object)
							{
								if (jtoken.Type == JTokenType.Array || jtoken.Type == JTokenType.Constructor)
								{
									int num;
									if (int.TryParse(text3, out num) && num >= 0 && num < jtoken.Count<JToken>())
									{
										jtoken = jtoken[num];
									}
									else
									{
										jtoken = null;
									}
								}
							}
							else
							{
								jtoken = jtoken[text3];
							}
							if (jtoken == null)
							{
								break;
							}
						}
						if (jtoken != null)
						{
							jsonSchema = this.BuildSchema(jtoken);
						}
					}
					if (jsonSchema == null)
					{
						throw new JsonException(<Module>.smethod_24<string>(1862114834U).FormatWith(JsonSchemaBuilder.smethod_5(), schema.DeferredReference));
					}
				}
				schema = jsonSchema;
			}
			if (schema.ReferencesResolved)
			{
				return schema;
			}
			schema.ReferencesResolved = true;
			if (schema.Extends != null)
			{
				for (int j = 0; j < schema.Extends.Count; j++)
				{
					schema.Extends[j] = this.ResolveReferences(schema.Extends[j]);
				}
			}
			if (schema.Items != null)
			{
				for (int k = 0; k < schema.Items.Count; k++)
				{
					schema.Items[k] = this.ResolveReferences(schema.Items[k]);
				}
			}
			if (schema.AdditionalItems != null)
			{
				schema.AdditionalItems = this.ResolveReferences(schema.AdditionalItems);
			}
			if (schema.PatternProperties != null)
			{
				foreach (KeyValuePair<string, JsonSchema> keyValuePair in schema.PatternProperties.ToList<KeyValuePair<string, JsonSchema>>())
				{
					schema.PatternProperties[keyValuePair.Key] = this.ResolveReferences(keyValuePair.Value);
				}
			}
			if (schema.Properties != null)
			{
				foreach (KeyValuePair<string, JsonSchema> keyValuePair2 in schema.Properties.ToList<KeyValuePair<string, JsonSchema>>())
				{
					schema.Properties[keyValuePair2.Key] = this.ResolveReferences(keyValuePair2.Value);
				}
			}
			if (schema.AdditionalProperties != null)
			{
				schema.AdditionalProperties = this.ResolveReferences(schema.AdditionalProperties);
			}
			return schema;
		}

		// Token: 0x060024A7 RID: 9383 RVA: 0x0008D750 File Offset: 0x0008B950
		private JsonSchema BuildSchema(JToken token)
		{
			JObject jobject = token as JObject;
			if (jobject == null)
			{
				throw JsonException.Create(token, token.Path, <Module>.smethod_24<string>(2322453206U).FormatWith(JsonSchemaBuilder.smethod_5(), token.Type));
			}
			JToken jtoken;
			if (jobject.TryGetValue(<Module>.smethod_27<string>(2500852707U), out jtoken))
			{
				return new JsonSchema
				{
					DeferredReference = (string)jtoken
				};
			}
			string text = JsonSchemaBuilder.smethod_1(JsonSchemaBuilder.smethod_1(JsonSchemaBuilder.smethod_1(token.Path, <Module>.smethod_27<string>(859418173U), <Module>.smethod_26<string>(2625042512U)), <Module>.smethod_26<string>(3919254978U), <Module>.smethod_23<string>(1912091352U)), <Module>.smethod_24<string>(1279838660U), string.Empty);
			if (!JsonSchemaBuilder.smethod_6(text))
			{
				text = JsonSchemaBuilder.smethod_7(<Module>.smethod_26<string>(2625042512U), text);
			}
			text = JsonSchemaBuilder.smethod_7(<Module>.smethod_26<string>(652305348U), text);
			JsonSchema jsonSchema;
			if (this._documentSchemas.TryGetValue(text, out jsonSchema))
			{
				return jsonSchema;
			}
			this.Push(new JsonSchema
			{
				Location = text
			});
			this.ProcessSchemaProperties(jobject);
			return this.Pop();
		}

		// Token: 0x060024A8 RID: 9384 RVA: 0x0008D86C File Offset: 0x0008BA6C
		private void ProcessSchemaProperties(JObject schemaObject)
		{
			IEnumerator<KeyValuePair<string, JToken>> enumerator = schemaObject.GetEnumerator();
			try
			{
				while (JsonSchemaBuilder.smethod_8(enumerator))
				{
					KeyValuePair<string, JToken> keyValuePair = enumerator.Current;
					string key;
					switch (key = keyValuePair.Key)
					{

						this.CurrentSchema.Type = this.ProcessType(keyValuePair.Value);
						break;

						this.CurrentSchema.Id = (string)keyValuePair.Value;
						break;

						this.CurrentSchema.Title = (string)keyValuePair.Value;
						break;

						this.CurrentSchema.Description = (string)keyValuePair.Value;
						break;

						this.CurrentSchema.Properties = this.ProcessProperties(keyValuePair.Value);
						break;

						this.ProcessItems(keyValuePair.Value);
						break;

						this.ProcessAdditionalProperties(keyValuePair.Value);
						break;

						this.ProcessAdditionalItems(keyValuePair.Value);
						break;

						this.CurrentSchema.PatternProperties = this.ProcessProperties(keyValuePair.Value);
						break;

						this.CurrentSchema.Required = new bool?((bool)keyValuePair.Value);
						break;

						this.CurrentSchema.Requires = (string)keyValuePair.Value;
						break;

						this.CurrentSchema.Minimum = new double?((double)keyValuePair.Value);
						break;

						this.CurrentSchema.Maximum = new double?((double)keyValuePair.Value);
						break;

						this.CurrentSchema.ExclusiveMinimum = new bool?((bool)keyValuePair.Value);
						break;

						this.CurrentSchema.ExclusiveMaximum = new bool?((bool)keyValuePair.Value);
						break;

						this.CurrentSchema.MaximumLength = new int?((int)keyValuePair.Value);
						break;

						this.CurrentSchema.MinimumLength = new int?((int)keyValuePair.Value);
						break;

						this.CurrentSchema.MaximumItems = new int?((int)keyValuePair.Value);
						break;

						this.CurrentSchema.MinimumItems = new int?((int)keyValuePair.Value);
						break;

						this.CurrentSchema.DivisibleBy = new double?((double)keyValuePair.Value);
						break;

						this.CurrentSchema.Disallow = this.ProcessType(keyValuePair.Value);
						break;

						this.CurrentSchema.Default = keyValuePair.Value.DeepClone();
						break;

						this.CurrentSchema.Hidden = new bool?((bool)keyValuePair.Value);
						break;

						this.CurrentSchema.ReadOnly = new bool?((bool)keyValuePair.Value);
						break;

						this.CurrentSchema.Format = (string)keyValuePair.Value;
						break;

						this.CurrentSchema.Pattern = (string)keyValuePair.Value;
						break;

						this.ProcessEnum(keyValuePair.Value);
						break;

						this.ProcessExtends(keyValuePair.Value);
						break;

						this.CurrentSchema.UniqueItems = (bool)keyValuePair.Value;
						break;
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JsonSchemaBuilder.smethod_9(enumerator);
				}
			}
		}

		// Token: 0x060024A9 RID: 9385 RVA: 0x0008DEA8 File Offset: 0x0008C0A8
		private void ProcessExtends(JToken token)
		{
			IList<JsonSchema> list = new List<JsonSchema>();
			if (token.Type == JTokenType.Array)
			{
				IEnumerator<JToken> enumerator = ((IEnumerable<JToken>)token).GetEnumerator();
				try
				{
					while (JsonSchemaBuilder.smethod_8(enumerator))
					{
						JToken jtoken = enumerator.Current;
						list.Add(this.BuildSchema(jtoken));
					}
					goto IL_0053;
				}
				finally
				{
					if (enumerator != null)
					{
						JsonSchemaBuilder.smethod_9(enumerator);
					}
				}
			}
			JsonSchema jsonSchema = this.BuildSchema(token);
			if (jsonSchema != null)
			{
				list.Add(jsonSchema);
			}
			IL_0053:
			if (list.Count > 0)
			{
				this.CurrentSchema.Extends = list;
			}
		}

		// Token: 0x060024AA RID: 9386 RVA: 0x0008DF30 File Offset: 0x0008C130
		private void ProcessEnum(JToken token)
		{
			if (token.Type != JTokenType.Array)
			{
				throw JsonException.Create(token, token.Path, <Module>.smethod_26<string>(3224175949U).FormatWith(JsonSchemaBuilder.smethod_5(), token.Type));
			}
			this.CurrentSchema.Enum = new List<JToken>();
			IEnumerator<JToken> enumerator = ((IEnumerable<JToken>)token).GetEnumerator();
			try
			{
				while (JsonSchemaBuilder.smethod_8(enumerator))
				{
					JToken jtoken = enumerator.Current;
					this.CurrentSchema.Enum.Add(jtoken.DeepClone());
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JsonSchemaBuilder.smethod_9(enumerator);
				}
			}
		}

		// Token: 0x060024AB RID: 9387 RVA: 0x0001D51E File Offset: 0x0001B71E
		private void ProcessAdditionalProperties(JToken token)
		{
			if (token.Type == JTokenType.Boolean)
			{
				this.CurrentSchema.AllowAdditionalProperties = (bool)token;
				return;
			}
			this.CurrentSchema.AdditionalProperties = this.BuildSchema(token);
		}

		// Token: 0x060024AC RID: 9388 RVA: 0x0001D54E File Offset: 0x0001B74E
		private void ProcessAdditionalItems(JToken token)
		{
			if (token.Type == JTokenType.Boolean)
			{
				this.CurrentSchema.AllowAdditionalItems = (bool)token;
				return;
			}
			this.CurrentSchema.AdditionalItems = this.BuildSchema(token);
		}

		// Token: 0x060024AD RID: 9389 RVA: 0x0008DFD0 File Offset: 0x0008C1D0
		private IDictionary<string, JsonSchema> ProcessProperties(JToken token)
		{
			IDictionary<string, JsonSchema> dictionary = new Dictionary<string, JsonSchema>();
			if (token.Type == JTokenType.Object)
			{
				IEnumerator<JToken> enumerator = ((IEnumerable<JToken>)token).GetEnumerator();
				try
				{
					JProperty jproperty;
					for (;;)
					{
						IL_0098:
						int num = ((!JsonSchemaBuilder.smethod_8(enumerator)) ? (-31536959) : (-31536954));
						for (;;)
						{
							switch (num ^ -31536957)
							{
							case 0:
								goto IL_0098;
							case 1:
								if (dictionary.ContainsKey(jproperty.Name))
								{
									goto Block_4;
								}
								goto IL_0036;
							case 3:
								num = -31536954;
								continue;
							case 4:
								goto IL_0036;
							case 5:
								jproperty = (JProperty)enumerator.Current;
								num = -31536958;
								continue;
							}
							goto Block_5;
							IL_0036:
							dictionary.Add(jproperty.Name, this.BuildSchema(jproperty.Value));
							num = -31536957;
						}
					}
					Block_4:
					throw new JsonException(<Module>.smethod_26<string>(1843594285U).FormatWith(JsonSchemaBuilder.smethod_5(), jproperty.Name));
					Block_5:
					return dictionary;
				}
				finally
				{
					if (enumerator != null)
					{
						JsonSchemaBuilder.smethod_9(enumerator);
					}
				}
			}
			throw JsonException.Create(token, token.Path, <Module>.smethod_24<string>(3419440575U).FormatWith(JsonSchemaBuilder.smethod_5(), token.Type));
		}

		// Token: 0x060024AE RID: 9390 RVA: 0x0008E0EC File Offset: 0x0008C2EC
		private void ProcessItems(JToken token)
		{
			this.CurrentSchema.Items = new List<JsonSchema>();
			switch (token.Type)
			{
			case JTokenType.Object:
				this.CurrentSchema.Items.Add(this.BuildSchema(token));
				this.CurrentSchema.PositionalItemsValidation = false;
				return;
			case JTokenType.Array:
			{
				this.CurrentSchema.PositionalItemsValidation = true;
				IEnumerator<JToken> enumerator = ((IEnumerable<JToken>)token).GetEnumerator();
				try
				{
					while (JsonSchemaBuilder.smethod_8(enumerator))
					{
						JToken jtoken = enumerator.Current;
						this.CurrentSchema.Items.Add(this.BuildSchema(jtoken));
					}
				}
				finally
				{
					if (enumerator != null)
					{
						JsonSchemaBuilder.smethod_9(enumerator);
					}
				}
				return;
			}
			default:
				throw JsonException.Create(token, token.Path, <Module>.smethod_25<string>(2812916775U).FormatWith(JsonSchemaBuilder.smethod_5(), token.Type));
			}
		}

		// Token: 0x060024AF RID: 9391 RVA: 0x0008E1C8 File Offset: 0x0008C3C8
		private JsonSchemaType? ProcessType(JToken token)
		{
			JTokenType type = token.Type;
			if (type == JTokenType.Array)
			{
				JsonSchemaType? jsonSchemaType = new JsonSchemaType?(JsonSchemaType.None);
				IEnumerator<JToken> enumerator = ((IEnumerable<JToken>)token).GetEnumerator();
				try
				{
					while (JsonSchemaBuilder.smethod_8(enumerator))
					{
						JToken jtoken = enumerator.Current;
						if (jtoken.Type != JTokenType.String)
						{
							throw JsonException.Create(jtoken, jtoken.Path, <Module>.smethod_24<string>(3350847072U).FormatWith(JsonSchemaBuilder.smethod_5(), token.Type));
						}
						jsonSchemaType |= JsonSchemaBuilder.MapType((string)jtoken);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						JsonSchemaBuilder.smethod_9(enumerator);
					}
				}
				return jsonSchemaType;
			}
			if (type != JTokenType.String)
			{
				throw JsonException.Create(token, token.Path, <Module>.smethod_25<string>(1093055240U).FormatWith(JsonSchemaBuilder.smethod_5(), token.Type));
			}
			return new JsonSchemaType?(JsonSchemaBuilder.MapType((string)token));
		}

		// Token: 0x060024B0 RID: 9392 RVA: 0x0008E2D0 File Offset: 0x0008C4D0
		internal static JsonSchemaType MapType(string type)
		{
			JsonSchemaType jsonSchemaType;
			if (!JsonSchemaConstants.JsonSchemaTypeMapping.TryGetValue(type, out jsonSchemaType))
			{
				throw new JsonException(<Module>.smethod_23<string>(977448311U).FormatWith(JsonSchemaBuilder.smethod_5(), type));
			}
			return jsonSchemaType;
		}

		// Token: 0x060024B1 RID: 9393 RVA: 0x0008E308 File Offset: 0x0008C508
		internal static string MapType(JsonSchemaType type)
		{
			return JsonSchemaConstants.JsonSchemaTypeMapping.Single((KeyValuePair<string, JsonSchemaType> kv) => kv.Value == type).Key;
		}

		// Token: 0x060024B2 RID: 9394 RVA: 0x0000FAD7 File Offset: 0x0000DCD7
		static string smethod_0(string string_0)
		{
			return Uri.UnescapeDataString(string_0);
		}

		// Token: 0x060024B3 RID: 9395 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_1(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x060024B4 RID: 9396 RVA: 0x0000F8C5 File Offset: 0x0000DAC5
		static bool smethod_2(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.StartsWith(string_1, stringComparison_0);
		}

		// Token: 0x060024B5 RID: 9397 RVA: 0x000161E1 File Offset: 0x000143E1
		static string smethod_3(string string_0, char[] char_0)
		{
			return string_0.TrimStart(char_0);
		}

		// Token: 0x060024B6 RID: 9398 RVA: 0x0001D57E File Offset: 0x0001B77E
		static string[] smethod_4(string string_0, char[] char_0, StringSplitOptions stringSplitOptions_0)
		{
			return string_0.Split(char_0, stringSplitOptions_0);
		}

		// Token: 0x060024B7 RID: 9399 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_5()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060024B8 RID: 9400 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_6(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x060024B9 RID: 9401 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_7(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x060024BA RID: 9402 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_8(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060024BB RID: 9403 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_9(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x04000D07 RID: 3335
		private readonly IList<JsonSchema> _stack;

		// Token: 0x04000D08 RID: 3336
		private readonly JsonSchemaResolver _resolver;

		// Token: 0x04000D09 RID: 3337
		private readonly IDictionary<string, JsonSchema> _documentSchemas;

		// Token: 0x04000D0A RID: 3338
		private JsonSchema _currentSchema;

		// Token: 0x04000D0B RID: 3339
		private JObject _rootSchema;
	}
}
