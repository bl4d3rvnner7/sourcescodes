﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x0200024F RID: 591
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	public class JsonSchemaResolver
	{
		// Token: 0x1700052F RID: 1327
		// (get) Token: 0x060022E3 RID: 8931 RVA: 0x0001C820 File Offset: 0x0001AA20
		// (set) Token: 0x060022E4 RID: 8932 RVA: 0x0001C828 File Offset: 0x0001AA28
		public IList<JsonSchema> LoadedSchemas { get; protected set; }

		// Token: 0x060022E5 RID: 8933 RVA: 0x0001C831 File Offset: 0x0001AA31
		public JsonSchemaResolver()
		{
			this.LoadedSchemas = new List<JsonSchema>();
		}

		// Token: 0x060022E6 RID: 8934 RVA: 0x0008A428 File Offset: 0x00088628
		public virtual JsonSchema GetSchema(string reference)
		{
			JsonSchema jsonSchema = this.LoadedSchemas.SingleOrDefault((JsonSchema s) => JsonSchemaResolver.<>c__DisplayClass2.smethod_0(s.Id, reference, StringComparison.Ordinal));
			if (jsonSchema == null)
			{
				jsonSchema = this.LoadedSchemas.SingleOrDefault((JsonSchema s) => JsonSchemaResolver.<>c__DisplayClass2.smethod_0(s.Location, reference, StringComparison.Ordinal));
			}
			return jsonSchema;
		}
	}
}
