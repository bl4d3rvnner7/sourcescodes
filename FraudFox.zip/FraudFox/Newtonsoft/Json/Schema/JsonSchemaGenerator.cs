﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x02000271 RID: 625
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	public class JsonSchemaGenerator
	{
		// Token: 0x17000593 RID: 1427
		// (get) Token: 0x060024BF RID: 9407 RVA: 0x0001D599 File Offset: 0x0001B799
		// (set) Token: 0x060024C0 RID: 9408 RVA: 0x0001D5A1 File Offset: 0x0001B7A1
		public UndefinedSchemaIdHandling UndefinedSchemaIdHandling { get; set; }

		// Token: 0x17000594 RID: 1428
		// (get) Token: 0x060024C1 RID: 9409 RVA: 0x0001D5AA File Offset: 0x0001B7AA
		// (set) Token: 0x060024C2 RID: 9410 RVA: 0x0001D5C0 File Offset: 0x0001B7C0
		public IContractResolver ContractResolver
		{
			get
			{
				if (this._contractResolver == null)
				{
					return DefaultContractResolver.Instance;
				}
				return this._contractResolver;
			}
			set
			{
				this._contractResolver = value;
			}
		}

		// Token: 0x17000595 RID: 1429
		// (get) Token: 0x060024C3 RID: 9411 RVA: 0x0001D5C9 File Offset: 0x0001B7C9
		private JsonSchema CurrentSchema
		{
			get
			{
				return this._currentSchema;
			}
		}

		// Token: 0x060024C4 RID: 9412 RVA: 0x0001D5D1 File Offset: 0x0001B7D1
		private void Push(JsonSchemaGenerator.TypeSchema typeSchema)
		{
			this._currentSchema = typeSchema.Schema;
			this._stack.Add(typeSchema);
			this._resolver.LoadedSchemas.Add(typeSchema.Schema);
		}

		// Token: 0x060024C5 RID: 9413 RVA: 0x0008E3E8 File Offset: 0x0008C5E8
		private JsonSchemaGenerator.TypeSchema Pop()
		{
			JsonSchemaGenerator.TypeSchema typeSchema = this._stack[this._stack.Count - 1];
			this._stack.RemoveAt(this._stack.Count - 1);
			JsonSchemaGenerator.TypeSchema typeSchema2 = this._stack.LastOrDefault<JsonSchemaGenerator.TypeSchema>();
			if (typeSchema2 == null)
			{
				this._currentSchema = null;
			}
			else
			{
				this._currentSchema = typeSchema2.Schema;
			}
			return typeSchema;
		}

		// Token: 0x060024C6 RID: 9414 RVA: 0x0001D601 File Offset: 0x0001B801
		public JsonSchema Generate(Type type)
		{
			return this.Generate(type, new JsonSchemaResolver(), false);
		}

		// Token: 0x060024C7 RID: 9415 RVA: 0x0001D610 File Offset: 0x0001B810
		public JsonSchema Generate(Type type, JsonSchemaResolver resolver)
		{
			return this.Generate(type, resolver, false);
		}

		// Token: 0x060024C8 RID: 9416 RVA: 0x0001D61B File Offset: 0x0001B81B
		public JsonSchema Generate(Type type, bool rootSchemaNullable)
		{
			return this.Generate(type, new JsonSchemaResolver(), rootSchemaNullable);
		}

		// Token: 0x060024C9 RID: 9417 RVA: 0x0001D62A File Offset: 0x0001B82A
		public JsonSchema Generate(Type type, JsonSchemaResolver resolver, bool rootSchemaNullable)
		{
			ValidationUtils.ArgumentNotNull(type, <Module>.smethod_25<string>(965527090U));
			ValidationUtils.ArgumentNotNull(resolver, <Module>.smethod_27<string>(860625674U));
			this._resolver = resolver;
			return this.GenerateInternal(type, (!rootSchemaNullable) ? Required.Always : Required.Default, false);
		}

		// Token: 0x060024CA RID: 9418 RVA: 0x0008E44C File Offset: 0x0008C64C
		private string GetTitle(Type type)
		{
			JsonContainerAttribute cachedAttribute = JsonTypeReflector.GetCachedAttribute<JsonContainerAttribute>(type);
			if (cachedAttribute != null && !JsonSchemaGenerator.smethod_0(cachedAttribute.Title))
			{
				return cachedAttribute.Title;
			}
			return null;
		}

		// Token: 0x060024CB RID: 9419 RVA: 0x0008E478 File Offset: 0x0008C678
		private string GetDescription(Type type)
		{
			JsonContainerAttribute cachedAttribute = JsonTypeReflector.GetCachedAttribute<JsonContainerAttribute>(type);
			if (cachedAttribute != null && !JsonSchemaGenerator.smethod_0(cachedAttribute.Description))
			{
				return cachedAttribute.Description;
			}
			DescriptionAttribute attribute = ReflectionUtils.GetAttribute<DescriptionAttribute>(type);
			if (attribute != null)
			{
				return JsonSchemaGenerator.smethod_1(attribute);
			}
			return null;
		}

		// Token: 0x060024CC RID: 9420 RVA: 0x0008E4B8 File Offset: 0x0008C6B8
		private string GetTypeId(Type type, bool explicitOnly)
		{
			JsonContainerAttribute cachedAttribute = JsonTypeReflector.GetCachedAttribute<JsonContainerAttribute>(type);
			if (cachedAttribute != null && !JsonSchemaGenerator.smethod_0(cachedAttribute.Id))
			{
				return cachedAttribute.Id;
			}
			if (explicitOnly)
			{
				return null;
			}
			switch (this.UndefinedSchemaIdHandling)
			{
			case UndefinedSchemaIdHandling.UseTypeName:
				return JsonSchemaGenerator.smethod_2(type);
			case UndefinedSchemaIdHandling.UseAssemblyQualifiedName:
				return JsonSchemaGenerator.smethod_3(type);
			default:
				return null;
			}
		}

		// Token: 0x060024CD RID: 9421 RVA: 0x0008E510 File Offset: 0x0008C710
		private JsonSchema GenerateInternal(Type type, Required valueRequired, bool required)
		{
			Type type;
			IList<EnumValue<long>> namesAndValues;
			JsonContract jsonContract;
			for (;;)
			{
				IL_0531:
				int num = 1352748720;
				for (;;)
				{
					JsonSchema schema;
					JsonConverter jsonConverter;
					JsonContractType contractType;
					switch (num ^ 1352748689)
					{
					case 0:
						if (schema != null)
						{
							return schema;
						}
						goto IL_0085;
					case 1:
						this.CurrentSchema.Description = this.GetDescription(type);
						num = 1352748693;
						continue;
					case 2:
						this.CurrentSchema.Title = this.GetTitle(type);
						num = 1352748688;
						continue;
					case 3:
						goto IL_01EE;
					case 4:
						if (jsonConverter != null)
						{
							this.CurrentSchema.Type = new JsonSchemaType?(JsonSchemaType.Any);
							num = 1352748721;
							continue;
						}
						goto IL_03FF;
					case 5:
						goto IL_053E;
					case 7:
						this.CurrentSchema.Required = new bool?(true);
						num = 1352748691;
						continue;
					case 8:
					case 32:
						goto IL_06DC;
					case 9:
						goto IL_00A5;
					case 10:
						goto IL_03FF;
					case 11:
						goto IL_01CB;
					case 12:
					{
						JsonSchemaType? type2;
						if (type2 == JsonSchemaType.Integer)
						{
							num = 1352748674;
							continue;
						}
						goto IL_06DC;
					}
					case 13:
					{
						string typeId = this.GetTypeId(type, false);
						string typeId2 = this.GetTypeId(type, true);
						if (!JsonSchemaGenerator.smethod_0(typeId))
						{
							JsonSchema schema2 = this._resolver.GetSchema(typeId);
							num = 1352748686;
							continue;
						}
						goto IL_00F9;
					}
					case 14:
					{
						Type collectionItemType = ReflectionUtils.GetCollectionItemType(type);
						if (JsonSchemaGenerator.smethod_5(collectionItemType, null))
						{
							num = 1352748675;
							continue;
						}
						goto IL_06DC;
					}
					case 15:
					{
						JsonArrayAttribute cachedAttribute = JsonTypeReflector.GetCachedAttribute<JsonArrayAttribute>(type);
						num = 1352748672;
						continue;
					}
					case 16:
					{
						string typeId2;
						this.CurrentSchema.Id = typeId2;
						num = 1352748724;
						continue;
					}
					case 17:
					{
						JsonArrayAttribute cachedAttribute;
						bool flag = cachedAttribute == null || cachedAttribute.AllowNullItems;
						num = 1352748703;
						continue;
					}
					case 18:
						this.CurrentSchema.Items = new List<JsonSchema>();
						num = 1352748677;
						continue;
					case 19:
						if (type.IsEnum() && !JsonSchemaGenerator.smethod_7(type, JsonSchemaGenerator.smethod_6(typeof(FlagsAttribute).TypeHandle), true))
						{
							this.CurrentSchema.Enum = new List<JToken>();
							namesAndValues = EnumUtils.GetNamesAndValues<long>(type);
							num = 1352748695;
							continue;
						}
						goto IL_06DC;
					case 20:
					{
						Type collectionItemType;
						bool flag;
						this.CurrentSchema.Items.Add(this.GenerateInternal(collectionItemType, (!flag) ? Required.Always : Required.Default, false));
						num = 1352748697;
						continue;
					}
					case 21:
						goto IL_0531;
					case 22:
					{
						JsonSchema schema2;
						return schema2;
					}
					case 23:
						this.CurrentSchema.Id = this.GetTypeId(type, false);
						num = 1352748702;
						continue;
					case 24:
					{
						JsonSchema schema2;
						if (!JsonSchemaGenerator.HasFlag(schema2.Type, JsonSchemaType.Null))
						{
							schema2.Type |= JsonSchemaType.Null;
							num = 1352748725;
							continue;
						}
						goto IL_0022;
					}
					case 25:
					{
						JsonSchemaType? type2 = this.CurrentSchema.Type;
						num = 1352748701;
						continue;
					}
					case 26:
						goto IL_05AE;
					case 27:
						switch (contractType)
						{
						case JsonContractType.Object:
							goto IL_01CB;
						case JsonContractType.Array:
							goto IL_0175;
						case JsonContractType.Primitive:
							goto IL_01EE;
						case JsonContractType.String:
							goto IL_05C6;
						case JsonContractType.Dictionary:
							goto IL_05F8;
						case JsonContractType.Dynamic:
						case JsonContractType.Linq:
							goto IL_06A6;
						case JsonContractType.Serializable:
							goto IL_0660;
						default:
							num = 1352748692;
							continue;
						}
						break;
					case 28:
						goto IL_0175;
					case 29:
						this.CurrentSchema.Id = this.GetTypeId(type, false);
						num = 1352748683;
						continue;
					case 30:
					{
						JsonSchema schema2;
						if (schema2.Required != true)
						{
							schema2.Required = new bool?(true);
							num = 1352748679;
							continue;
						}
						return schema2;
					}
					case 31:
					{
						JsonSchema schema2;
						if (schema2 != null)
						{
							num = ((valueRequired != Required.Always) ? 1352748681 : 1352748725);
							continue;
						}
						goto IL_00F9;
					}
					case 33:
						type = type;
						ValidationUtils.ArgumentNotNull(type, <Module>.smethod_24<string>(1347420388U));
						num = 1352748700;
						continue;
					case 34:
						IL_0050:
						jsonContract = this.ContractResolver.ResolveContract(type);
						if ((jsonConverter = jsonContract.Converter) != null)
						{
							goto IL_00A5;
						}
						if ((jsonConverter = jsonContract.InternalConverter) != null)
						{
							num = 1352748696;
							continue;
						}
						goto IL_0085;
					case 35:
					{
						string typeId2;
						num = ((typeId2 != null) ? 1352748673 : 1352748724);
						continue;
					}
					case 36:
						goto IL_0022;
					case 37:
						num = (required ? 1352748694 : 1352748691);
						continue;
					}
					goto Block_24;
					IL_0022:
					num = (required ? 1352748687 : 1352748679);
					continue;
					IL_00F9:
					if (this._stack.Any((JsonSchemaGenerator.TypeSchema tc) => JsonSchemaGenerator.<>c__DisplayClass1.smethod_0(tc.Type, type)))
					{
						goto Block_8;
					}
					goto IL_0050;
					IL_0085:
					this.Push(new JsonSchemaGenerator.TypeSchema(type, new JsonSchema()));
					num = 1352748722;
					continue;
					IL_00A5:
					schema = jsonConverter.GetSchema();
					num = 1352748689;
					continue;
					IL_0175:
					this.CurrentSchema.Type = new JsonSchemaType?(this.AddNullType(JsonSchemaType.Array, valueRequired));
					num = 1352748678;
					continue;
					IL_01CB:
					this.CurrentSchema.Type = new JsonSchemaType?(this.AddNullType(JsonSchemaType.Object, valueRequired));
					num = 1352748684;
					continue;
					IL_01EE:
					this.CurrentSchema.Type = new JsonSchemaType?(this.GetJsonSchemaType(type, valueRequired));
					num = 1352748680;
					continue;
					IL_03FF:
					contractType = jsonContract.ContractType;
					num = 1352748682;
				}
			}
			Block_8:
			throw new JsonException(<Module>.smethod_23<string>(3538020341U).FormatWith(JsonSchemaGenerator.smethod_4(), type));
			Block_24:
			goto IL_055A;
			IL_053E:
			throw new JsonException(<Module>.smethod_23<string>(907332313U).FormatWith(JsonSchemaGenerator.smethod_4(), jsonContract));
			IL_055A:
			IEnumerator<EnumValue<long>> enumerator = namesAndValues.GetEnumerator();
			try
			{
				while (JsonSchemaGenerator.smethod_8(enumerator))
				{
					EnumValue<long> enumValue = enumerator.Current;
					JToken jtoken = JToken.FromObject(enumValue.Value);
					this.CurrentSchema.Enum.Add(jtoken);
				}
				goto IL_06DC;
			}
			finally
			{
				if (enumerator != null)
				{
					JsonSchemaGenerator.smethod_9(enumerator);
				}
			}
			IL_05AE:
			this.GenerateObjectSchema(type, (JsonObjectContract)jsonContract);
			goto IL_06DC;
			IL_05C6:
			JsonSchemaType jsonSchemaType = ((!ReflectionUtils.IsNullable(jsonContract.UnderlyingType)) ? JsonSchemaType.String : this.AddNullType(JsonSchemaType.String, valueRequired));
			this.CurrentSchema.Type = new JsonSchemaType?(jsonSchemaType);
			goto IL_06DC;
			IL_05F8:
			this.CurrentSchema.Type = new JsonSchemaType?(this.AddNullType(JsonSchemaType.Object, valueRequired));
			Type type3;
			Type type4;
			ReflectionUtils.GetDictionaryKeyValueTypes(type, out type3, out type4);
			if (!JsonSchemaGenerator.smethod_5(type3, null))
			{
				goto IL_06DC;
			}
			JsonContract jsonContract2 = this.ContractResolver.ResolveContract(type3);
			if (jsonContract2.ContractType == JsonContractType.Primitive)
			{
				this.CurrentSchema.AdditionalProperties = this.GenerateInternal(type4, Required.Default, false);
				goto IL_06DC;
			}
			goto IL_06DC;
			IL_0660:
			this.CurrentSchema.Type = new JsonSchemaType?(this.AddNullType(JsonSchemaType.Object, valueRequired));
			this.CurrentSchema.Id = this.GetTypeId(type, false);
			this.GenerateISerializableContract(type, (JsonISerializableContract)jsonContract);
			goto IL_06DC;
			IL_06A6:
			this.CurrentSchema.Type = new JsonSchemaType?(JsonSchemaType.Any);
			IL_06DC:
			return this.Pop().Schema;
		}

		// Token: 0x060024CE RID: 9422 RVA: 0x0001D662 File Offset: 0x0001B862
		private JsonSchemaType AddNullType(JsonSchemaType type, Required valueRequired)
		{
			if (valueRequired != Required.Always)
			{
				return type | JsonSchemaType.Null;
			}
			return type;
		}

		// Token: 0x060024CF RID: 9423 RVA: 0x00017878 File Offset: 0x00015A78
		private bool HasFlag(DefaultValueHandling value, DefaultValueHandling flag)
		{
			return (value & flag) == flag;
		}

		// Token: 0x060024D0 RID: 9424 RVA: 0x0008EC14 File Offset: 0x0008CE14
		private void GenerateObjectSchema(Type type, JsonObjectContract contract)
		{
			this.CurrentSchema.Properties = new Dictionary<string, JsonSchema>();
			IEnumerator<JsonProperty> enumerator = contract.Properties.GetEnumerator();
			try
			{
				while (JsonSchemaGenerator.smethod_8(enumerator))
				{
					JsonProperty jsonProperty = enumerator.Current;
					if (!jsonProperty.Ignored)
					{
						bool flag = jsonProperty.NullValueHandling == NullValueHandling.Ignore || this.HasFlag(jsonProperty.DefaultValueHandling.GetValueOrDefault(), DefaultValueHandling.Ignore) || jsonProperty.ShouldSerialize != null || jsonProperty.GetIsSpecified != null;
						JsonSchema jsonSchema = this.GenerateInternal(jsonProperty.PropertyType, jsonProperty.Required, !flag);
						if (jsonProperty.DefaultValue != null)
						{
							jsonSchema.Default = JToken.FromObject(jsonProperty.DefaultValue);
						}
						this.CurrentSchema.Properties.Add(jsonProperty.PropertyName, jsonSchema);
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JsonSchemaGenerator.smethod_9(enumerator);
				}
			}
			if (type.IsSealed())
			{
				this.CurrentSchema.AllowAdditionalProperties = false;
			}
		}

		// Token: 0x060024D1 RID: 9425 RVA: 0x0001D66E File Offset: 0x0001B86E
		private void GenerateISerializableContract(Type type, JsonISerializableContract contract)
		{
			this.CurrentSchema.AllowAdditionalProperties = true;
		}

		// Token: 0x060024D2 RID: 9426 RVA: 0x0008ED28 File Offset: 0x0008CF28
		internal static bool HasFlag(JsonSchemaType? value, JsonSchemaType flag)
		{
			if (value == null)
			{
				goto IL_0107;
			}
			JsonSchemaType? jsonSchemaType = value;
			int num = 2072832710;
			JsonSchemaType? jsonSchemaType8;
			for (;;)
			{
				IL_00CE:
				JsonSchemaType? jsonSchemaType2;
				bool flag2;
				JsonSchemaType? jsonSchemaType3;
				JsonSchemaType? jsonSchemaType7;
				switch (num ^ 2072832719)
				{
				case 0:
					flag2 = jsonSchemaType2 != null;
					goto IL_0064;
				case 1:
					return true;
				case 2:
					goto IL_0107;
				case 3:
					num = 2072832711;
					continue;
				case 4:
				{
					JsonSchemaType? jsonSchemaType4;
					jsonSchemaType3 = jsonSchemaType4;
					goto IL_00A4;
				}
				case 5:
					return true;
				case 6:
				{
					JsonSchemaType? jsonSchemaType5 = value;
					if (jsonSchemaType5 == null)
					{
						JsonSchemaType? jsonSchemaType4 = null;
						num = 2072832715;
						continue;
					}
					jsonSchemaType3 = new JsonSchemaType?(jsonSchemaType5.GetValueOrDefault() & JsonSchemaType.Float);
					goto IL_00A4;
				}
				case 8:
					if (jsonSchemaType2.GetValueOrDefault() == flag)
					{
						num = 2072832719;
						continue;
					}
					flag2 = false;
					goto IL_0064;
				case 9:
					if (jsonSchemaType == null)
					{
						JsonSchemaType? jsonSchemaType6 = null;
						num = 2072832709;
						continue;
					}
					jsonSchemaType7 = new JsonSchemaType?(jsonSchemaType.GetValueOrDefault() & flag);
					goto IL_001B;
				case 10:
				{
					JsonSchemaType? jsonSchemaType6;
					jsonSchemaType7 = jsonSchemaType6;
					goto IL_001B;
				}
				}
				break;
				IL_001B:
				jsonSchemaType2 = jsonSchemaType7;
				num = 2072832716;
				continue;
				IL_0064:
				if (flag2)
				{
					num = 2072832714;
					continue;
				}
				if (flag == JsonSchemaType.Integer)
				{
					num = 2072832713;
					continue;
				}
				return false;
				IL_00A4:
				jsonSchemaType8 = jsonSchemaType3;
				if (jsonSchemaType8.GetValueOrDefault() != JsonSchemaType.Float)
				{
					goto IL_0112;
				}
				num = 2072832712;
			}
			goto IL_0115;
			IL_0112:
			bool flag3 = false;
			goto IL_011C;
			IL_0115:
			flag3 = jsonSchemaType8 != null;
			IL_011C:
			if (flag3)
			{
				return true;
			}
			return false;
			IL_0107:
			num = 2072832718;
			goto IL_00CE;
		}

		// Token: 0x060024D3 RID: 9427 RVA: 0x0008EE58 File Offset: 0x0008D058
		private JsonSchemaType GetJsonSchemaType(Type type, Required valueRequired)
		{
			JsonSchemaType jsonSchemaType = JsonSchemaType.None;
			if (valueRequired != Required.Always && ReflectionUtils.IsNullable(type))
			{
				jsonSchemaType = JsonSchemaType.Null;
				if (ReflectionUtils.IsNullableType(type))
				{
					type = JsonSchemaGenerator.smethod_10(type);
				}
			}
			PrimitiveTypeCode typeCode = ConvertUtils.GetTypeCode(type);
			switch (typeCode)
			{
			case PrimitiveTypeCode.Empty:
			case PrimitiveTypeCode.Object:
				return jsonSchemaType | JsonSchemaType.String;
			case PrimitiveTypeCode.Char:
				return jsonSchemaType | JsonSchemaType.String;
			case PrimitiveTypeCode.Boolean:
				return jsonSchemaType | JsonSchemaType.Boolean;
			case PrimitiveTypeCode.SByte:
			case PrimitiveTypeCode.Int16:
			case PrimitiveTypeCode.UInt16:
			case PrimitiveTypeCode.Int32:
			case PrimitiveTypeCode.Byte:
			case PrimitiveTypeCode.UInt32:
			case PrimitiveTypeCode.Int64:
			case PrimitiveTypeCode.UInt64:
			case PrimitiveTypeCode.BigInteger:
				return jsonSchemaType | JsonSchemaType.Integer;
			case PrimitiveTypeCode.Single:
			case PrimitiveTypeCode.Double:
			case PrimitiveTypeCode.Decimal:
				return jsonSchemaType | JsonSchemaType.Float;
			case PrimitiveTypeCode.DateTime:
			case PrimitiveTypeCode.DateTimeOffset:
				return jsonSchemaType | JsonSchemaType.String;
			case PrimitiveTypeCode.Guid:
			case PrimitiveTypeCode.TimeSpan:
			case PrimitiveTypeCode.Uri:
			case PrimitiveTypeCode.String:
			case PrimitiveTypeCode.Bytes:
				return jsonSchemaType | JsonSchemaType.String;
			case PrimitiveTypeCode.DBNull:
				return jsonSchemaType | JsonSchemaType.Null;
			}
			throw new JsonException(<Module>.smethod_26<string>(3191449034U).FormatWith(JsonSchemaGenerator.smethod_4(), typeCode, type));
		}

		// Token: 0x060024D5 RID: 9429 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_0(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x060024D6 RID: 9430 RVA: 0x000130F6 File Offset: 0x000112F6
		static string smethod_1(DescriptionAttribute descriptionAttribute_0)
		{
			return descriptionAttribute_0.Description;
		}

		// Token: 0x060024D7 RID: 9431 RVA: 0x00017761 File Offset: 0x00015961
		static string smethod_2(Type type_0)
		{
			return type_0.FullName;
		}

		// Token: 0x060024D8 RID: 9432 RVA: 0x0001D68F File Offset: 0x0001B88F
		static string smethod_3(Type type_0)
		{
			return type_0.AssemblyQualifiedName;
		}

		// Token: 0x060024D9 RID: 9433 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_4()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060024DA RID: 9434 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_5(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x060024DB RID: 9435 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_6(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060024DC RID: 9436 RVA: 0x0001CA03 File Offset: 0x0001AC03
		static bool smethod_7(MemberInfo memberInfo_0, Type type_0, bool bool_0)
		{
			return memberInfo_0.IsDefined(type_0, bool_0);
		}

		// Token: 0x060024DD RID: 9437 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_8(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060024DE RID: 9438 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_9(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060024DF RID: 9439 RVA: 0x000175B6 File Offset: 0x000157B6
		static Type smethod_10(Type type_0)
		{
			return Nullable.GetUnderlyingType(type_0);
		}

		// Token: 0x04000D2E RID: 3374
		private IContractResolver _contractResolver;

		// Token: 0x04000D2F RID: 3375
		private JsonSchemaResolver _resolver;

		// Token: 0x04000D30 RID: 3376
		private readonly IList<JsonSchemaGenerator.TypeSchema> _stack = new List<JsonSchemaGenerator.TypeSchema>();

		// Token: 0x04000D31 RID: 3377
		private JsonSchema _currentSchema;

		// Token: 0x02000272 RID: 626
		private class TypeSchema
		{
			// Token: 0x17000596 RID: 1430
			// (get) Token: 0x060024E0 RID: 9440 RVA: 0x0001D697 File Offset: 0x0001B897
			// (set) Token: 0x060024E1 RID: 9441 RVA: 0x0001D69F File Offset: 0x0001B89F
			public Type Type { get; private set; }

			// Token: 0x17000597 RID: 1431
			// (get) Token: 0x060024E2 RID: 9442 RVA: 0x0001D6A8 File Offset: 0x0001B8A8
			// (set) Token: 0x060024E3 RID: 9443 RVA: 0x0001D6B0 File Offset: 0x0001B8B0
			public JsonSchema Schema { get; private set; }

			// Token: 0x060024E4 RID: 9444 RVA: 0x0001D6B9 File Offset: 0x0001B8B9
			public TypeSchema(Type type, JsonSchema schema)
			{
				ValidationUtils.ArgumentNotNull(type, <Module>.smethod_25<string>(965527090U));
				ValidationUtils.ArgumentNotNull(schema, <Module>.smethod_24<string>(1798093859U));
				this.Type = type;
				this.Schema = schema;
			}
		}
	}
}
