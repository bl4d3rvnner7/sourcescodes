﻿using System;
using System.Collections.Generic;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x02000270 RID: 624
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	internal static class JsonSchemaConstants
	{
		// Token: 0x04000D0D RID: 3341
		public const string TypePropertyName = "type";

		// Token: 0x04000D0E RID: 3342
		public const string PropertiesPropertyName = "properties";

		// Token: 0x04000D0F RID: 3343
		public const string ItemsPropertyName = "items";

		// Token: 0x04000D10 RID: 3344
		public const string AdditionalItemsPropertyName = "additionalItems";

		// Token: 0x04000D11 RID: 3345
		public const string RequiredPropertyName = "required";

		// Token: 0x04000D12 RID: 3346
		public const string PatternPropertiesPropertyName = "patternProperties";

		// Token: 0x04000D13 RID: 3347
		public const string AdditionalPropertiesPropertyName = "additionalProperties";

		// Token: 0x04000D14 RID: 3348
		public const string RequiresPropertyName = "requires";

		// Token: 0x04000D15 RID: 3349
		public const string MinimumPropertyName = "minimum";

		// Token: 0x04000D16 RID: 3350
		public const string MaximumPropertyName = "maximum";

		// Token: 0x04000D17 RID: 3351
		public const string ExclusiveMinimumPropertyName = "exclusiveMinimum";

		// Token: 0x04000D18 RID: 3352
		public const string ExclusiveMaximumPropertyName = "exclusiveMaximum";

		// Token: 0x04000D19 RID: 3353
		public const string MinimumItemsPropertyName = "minItems";

		// Token: 0x04000D1A RID: 3354
		public const string MaximumItemsPropertyName = "maxItems";

		// Token: 0x04000D1B RID: 3355
		public const string PatternPropertyName = "pattern";

		// Token: 0x04000D1C RID: 3356
		public const string MaximumLengthPropertyName = "maxLength";

		// Token: 0x04000D1D RID: 3357
		public const string MinimumLengthPropertyName = "minLength";

		// Token: 0x04000D1E RID: 3358
		public const string EnumPropertyName = "enum";

		// Token: 0x04000D1F RID: 3359
		public const string ReadOnlyPropertyName = "readonly";

		// Token: 0x04000D20 RID: 3360
		public const string TitlePropertyName = "title";

		// Token: 0x04000D21 RID: 3361
		public const string DescriptionPropertyName = "description";

		// Token: 0x04000D22 RID: 3362
		public const string FormatPropertyName = "format";

		// Token: 0x04000D23 RID: 3363
		public const string DefaultPropertyName = "default";

		// Token: 0x04000D24 RID: 3364
		public const string TransientPropertyName = "transient";

		// Token: 0x04000D25 RID: 3365
		public const string DivisibleByPropertyName = "divisibleBy";

		// Token: 0x04000D26 RID: 3366
		public const string HiddenPropertyName = "hidden";

		// Token: 0x04000D27 RID: 3367
		public const string DisallowPropertyName = "disallow";

		// Token: 0x04000D28 RID: 3368
		public const string ExtendsPropertyName = "extends";

		// Token: 0x04000D29 RID: 3369
		public const string IdPropertyName = "id";

		// Token: 0x04000D2A RID: 3370
		public const string UniqueItemsPropertyName = "uniqueItems";

		// Token: 0x04000D2B RID: 3371
		public const string OptionValuePropertyName = "value";

		// Token: 0x04000D2C RID: 3372
		public const string OptionLabelPropertyName = "label";

		// Token: 0x04000D2D RID: 3373
		public static readonly IDictionary<string, JsonSchemaType> JsonSchemaTypeMapping = new Dictionary<string, JsonSchemaType>
		{
			{
				<Module>.smethod_24<string>(3404705633U),
				JsonSchemaType.String
			},
			{
				<Module>.smethod_24<string>(329177770U),
				JsonSchemaType.Object
			},
			{
				<Module>.smethod_24<string>(4217665255U),
				JsonSchemaType.Integer
			},
			{
				<Module>.smethod_25<string>(2862439438U),
				JsonSchemaType.Float
			},
			{
				<Module>.smethod_26<string>(1702456006U),
				JsonSchemaType.Null
			},
			{
				<Module>.smethod_24<string>(1529309733U),
				JsonSchemaType.Boolean
			},
			{
				<Module>.smethod_27<string>(2742358641U),
				JsonSchemaType.Array
			},
			{
				<Module>.smethod_26<string>(1154093917U),
				JsonSchemaType.Any
			}
		};
	}
}
