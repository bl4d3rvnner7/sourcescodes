﻿using System;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x02000254 RID: 596
	// (Invoke) Token: 0x060022FD RID: 8957
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	public delegate void ValidationEventHandler(object sender, ValidationEventArgs e);
}
