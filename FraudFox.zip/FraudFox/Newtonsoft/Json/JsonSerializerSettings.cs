﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using Newtonsoft.Json.Serialization;

namespace Newtonsoft.Json
{
	// Token: 0x02000205 RID: 517
	public class JsonSerializerSettings
	{
		// Token: 0x17000414 RID: 1044
		// (get) Token: 0x06001D18 RID: 7448 RVA: 0x0007F8B4 File Offset: 0x0007DAB4
		// (set) Token: 0x06001D19 RID: 7449 RVA: 0x00019582 File Offset: 0x00017782
		public ReferenceLoopHandling ReferenceLoopHandling
		{
			get
			{
				ReferenceLoopHandling? referenceLoopHandling = this._referenceLoopHandling;
				if (referenceLoopHandling == null)
				{
					return ReferenceLoopHandling.Error;
				}
				return referenceLoopHandling.GetValueOrDefault();
			}
			set
			{
				this._referenceLoopHandling = new ReferenceLoopHandling?(value);
			}
		}

		// Token: 0x17000415 RID: 1045
		// (get) Token: 0x06001D1A RID: 7450 RVA: 0x0007F8DC File Offset: 0x0007DADC
		// (set) Token: 0x06001D1B RID: 7451 RVA: 0x00019590 File Offset: 0x00017790
		public MissingMemberHandling MissingMemberHandling
		{
			get
			{
				MissingMemberHandling? missingMemberHandling = this._missingMemberHandling;
				if (missingMemberHandling == null)
				{
					return MissingMemberHandling.Ignore;
				}
				return missingMemberHandling.GetValueOrDefault();
			}
			set
			{
				this._missingMemberHandling = new MissingMemberHandling?(value);
			}
		}

		// Token: 0x17000416 RID: 1046
		// (get) Token: 0x06001D1C RID: 7452 RVA: 0x0007F904 File Offset: 0x0007DB04
		// (set) Token: 0x06001D1D RID: 7453 RVA: 0x0001959E File Offset: 0x0001779E
		public ObjectCreationHandling ObjectCreationHandling
		{
			get
			{
				ObjectCreationHandling? objectCreationHandling = this._objectCreationHandling;
				if (objectCreationHandling == null)
				{
					return ObjectCreationHandling.Auto;
				}
				return objectCreationHandling.GetValueOrDefault();
			}
			set
			{
				this._objectCreationHandling = new ObjectCreationHandling?(value);
			}
		}

		// Token: 0x17000417 RID: 1047
		// (get) Token: 0x06001D1E RID: 7454 RVA: 0x0007F92C File Offset: 0x0007DB2C
		// (set) Token: 0x06001D1F RID: 7455 RVA: 0x000195AC File Offset: 0x000177AC
		public NullValueHandling NullValueHandling
		{
			get
			{
				NullValueHandling? nullValueHandling = this._nullValueHandling;
				if (nullValueHandling == null)
				{
					return NullValueHandling.Include;
				}
				return nullValueHandling.GetValueOrDefault();
			}
			set
			{
				this._nullValueHandling = new NullValueHandling?(value);
			}
		}

		// Token: 0x17000418 RID: 1048
		// (get) Token: 0x06001D20 RID: 7456 RVA: 0x0007F954 File Offset: 0x0007DB54
		// (set) Token: 0x06001D21 RID: 7457 RVA: 0x000195BA File Offset: 0x000177BA
		public DefaultValueHandling DefaultValueHandling
		{
			get
			{
				DefaultValueHandling? defaultValueHandling = this._defaultValueHandling;
				if (defaultValueHandling == null)
				{
					return DefaultValueHandling.Include;
				}
				return defaultValueHandling.GetValueOrDefault();
			}
			set
			{
				this._defaultValueHandling = new DefaultValueHandling?(value);
			}
		}

		// Token: 0x17000419 RID: 1049
		// (get) Token: 0x06001D22 RID: 7458 RVA: 0x000195C8 File Offset: 0x000177C8
		// (set) Token: 0x06001D23 RID: 7459 RVA: 0x000195D0 File Offset: 0x000177D0
		public IList<JsonConverter> Converters { get; set; }

		// Token: 0x1700041A RID: 1050
		// (get) Token: 0x06001D24 RID: 7460 RVA: 0x0007F97C File Offset: 0x0007DB7C
		// (set) Token: 0x06001D25 RID: 7461 RVA: 0x000195D9 File Offset: 0x000177D9
		public PreserveReferencesHandling PreserveReferencesHandling
		{
			get
			{
				PreserveReferencesHandling? preserveReferencesHandling = this._preserveReferencesHandling;
				if (preserveReferencesHandling == null)
				{
					return PreserveReferencesHandling.None;
				}
				return preserveReferencesHandling.GetValueOrDefault();
			}
			set
			{
				this._preserveReferencesHandling = new PreserveReferencesHandling?(value);
			}
		}

		// Token: 0x1700041B RID: 1051
		// (get) Token: 0x06001D26 RID: 7462 RVA: 0x0007F9A4 File Offset: 0x0007DBA4
		// (set) Token: 0x06001D27 RID: 7463 RVA: 0x000195E7 File Offset: 0x000177E7
		public TypeNameHandling TypeNameHandling
		{
			get
			{
				TypeNameHandling? typeNameHandling = this._typeNameHandling;
				if (typeNameHandling == null)
				{
					return TypeNameHandling.None;
				}
				return typeNameHandling.GetValueOrDefault();
			}
			set
			{
				this._typeNameHandling = new TypeNameHandling?(value);
			}
		}

		// Token: 0x1700041C RID: 1052
		// (get) Token: 0x06001D28 RID: 7464 RVA: 0x0007F9CC File Offset: 0x0007DBCC
		// (set) Token: 0x06001D29 RID: 7465 RVA: 0x000195F5 File Offset: 0x000177F5
		public MetadataPropertyHandling MetadataPropertyHandling
		{
			get
			{
				MetadataPropertyHandling? metadataPropertyHandling = this._metadataPropertyHandling;
				if (metadataPropertyHandling == null)
				{
					return MetadataPropertyHandling.Default;
				}
				return metadataPropertyHandling.GetValueOrDefault();
			}
			set
			{
				this._metadataPropertyHandling = new MetadataPropertyHandling?(value);
			}
		}

		// Token: 0x1700041D RID: 1053
		// (get) Token: 0x06001D2A RID: 7466 RVA: 0x0007F9F4 File Offset: 0x0007DBF4
		// (set) Token: 0x06001D2B RID: 7467 RVA: 0x00019603 File Offset: 0x00017803
		public FormatterAssemblyStyle TypeNameAssemblyFormat
		{
			get
			{
				FormatterAssemblyStyle? typeNameAssemblyFormat = this._typeNameAssemblyFormat;
				if (typeNameAssemblyFormat == null)
				{
					return FormatterAssemblyStyle.Simple;
				}
				return typeNameAssemblyFormat.GetValueOrDefault();
			}
			set
			{
				this._typeNameAssemblyFormat = new FormatterAssemblyStyle?(value);
			}
		}

		// Token: 0x1700041E RID: 1054
		// (get) Token: 0x06001D2C RID: 7468 RVA: 0x0007FA1C File Offset: 0x0007DC1C
		// (set) Token: 0x06001D2D RID: 7469 RVA: 0x00019611 File Offset: 0x00017811
		public ConstructorHandling ConstructorHandling
		{
			get
			{
				ConstructorHandling? constructorHandling = this._constructorHandling;
				if (constructorHandling == null)
				{
					return ConstructorHandling.Default;
				}
				return constructorHandling.GetValueOrDefault();
			}
			set
			{
				this._constructorHandling = new ConstructorHandling?(value);
			}
		}

		// Token: 0x1700041F RID: 1055
		// (get) Token: 0x06001D2E RID: 7470 RVA: 0x0001961F File Offset: 0x0001781F
		// (set) Token: 0x06001D2F RID: 7471 RVA: 0x00019627 File Offset: 0x00017827
		public IContractResolver ContractResolver { get; set; }

		// Token: 0x17000420 RID: 1056
		// (get) Token: 0x06001D30 RID: 7472 RVA: 0x00019630 File Offset: 0x00017830
		// (set) Token: 0x06001D31 RID: 7473 RVA: 0x00019638 File Offset: 0x00017838
		public IEqualityComparer EqualityComparer { get; set; }

		// Token: 0x17000421 RID: 1057
		// (get) Token: 0x06001D32 RID: 7474 RVA: 0x00019641 File Offset: 0x00017841
		// (set) Token: 0x06001D33 RID: 7475 RVA: 0x0007FA44 File Offset: 0x0007DC44
		[Obsolete("ReferenceResolver property is obsolete. Use the ReferenceResolverProvider property to set the IReferenceResolver: settings.ReferenceResolverProvider = () => resolver")]
		public IReferenceResolver ReferenceResolver
		{
			get
			{
				if (this.ReferenceResolverProvider == null)
				{
					return null;
				}
				return this.ReferenceResolverProvider();
			}
			set
			{
				this.ReferenceResolverProvider = () => value;
			}
		}

		// Token: 0x17000422 RID: 1058
		// (get) Token: 0x06001D34 RID: 7476 RVA: 0x00019658 File Offset: 0x00017858
		// (set) Token: 0x06001D35 RID: 7477 RVA: 0x00019660 File Offset: 0x00017860
		public Func<IReferenceResolver> ReferenceResolverProvider { get; set; }

		// Token: 0x17000423 RID: 1059
		// (get) Token: 0x06001D36 RID: 7478 RVA: 0x00019669 File Offset: 0x00017869
		// (set) Token: 0x06001D37 RID: 7479 RVA: 0x00019671 File Offset: 0x00017871
		public ITraceWriter TraceWriter { get; set; }

		// Token: 0x17000424 RID: 1060
		// (get) Token: 0x06001D38 RID: 7480 RVA: 0x0001967A File Offset: 0x0001787A
		// (set) Token: 0x06001D39 RID: 7481 RVA: 0x00019682 File Offset: 0x00017882
		public SerializationBinder Binder { get; set; }

		// Token: 0x17000425 RID: 1061
		// (get) Token: 0x06001D3A RID: 7482 RVA: 0x0001968B File Offset: 0x0001788B
		// (set) Token: 0x06001D3B RID: 7483 RVA: 0x00019693 File Offset: 0x00017893
		public EventHandler<ErrorEventArgs> Error { get; set; }

		// Token: 0x17000426 RID: 1062
		// (get) Token: 0x06001D3C RID: 7484 RVA: 0x0007FA70 File Offset: 0x0007DC70
		// (set) Token: 0x06001D3D RID: 7485 RVA: 0x0001969C File Offset: 0x0001789C
		public StreamingContext Context
		{
			get
			{
				StreamingContext? context = this._context;
				if (context == null)
				{
					return JsonSerializerSettings.DefaultContext;
				}
				return context.GetValueOrDefault();
			}
			set
			{
				this._context = new StreamingContext?(value);
			}
		}

		// Token: 0x17000427 RID: 1063
		// (get) Token: 0x06001D3E RID: 7486 RVA: 0x000196AA File Offset: 0x000178AA
		// (set) Token: 0x06001D3F RID: 7487 RVA: 0x000196C0 File Offset: 0x000178C0
		public string DateFormatString
		{
			get
			{
				return this._dateFormatString ?? <Module>.smethod_27<string>(1494287573U);
			}
			set
			{
				this._dateFormatString = value;
				this._dateFormatStringSet = true;
			}
		}

		// Token: 0x17000428 RID: 1064
		// (get) Token: 0x06001D40 RID: 7488 RVA: 0x000196D0 File Offset: 0x000178D0
		// (set) Token: 0x06001D41 RID: 7489 RVA: 0x0007FA9C File Offset: 0x0007DC9C
		public int? MaxDepth
		{
			get
			{
				return this._maxDepth;
			}
			set
			{
				if (value <= 0)
				{
					throw JsonSerializerSettings.smethod_0(<Module>.smethod_25<string>(4198077285U), <Module>.smethod_27<string>(2371252898U));
				}
				this._maxDepth = value;
				this._maxDepthSet = true;
			}
		}

		// Token: 0x17000429 RID: 1065
		// (get) Token: 0x06001D42 RID: 7490 RVA: 0x0007FAEC File Offset: 0x0007DCEC
		// (set) Token: 0x06001D43 RID: 7491 RVA: 0x000196D8 File Offset: 0x000178D8
		public Formatting Formatting
		{
			get
			{
				Formatting? formatting = this._formatting;
				if (formatting == null)
				{
					return Formatting.None;
				}
				return formatting.GetValueOrDefault();
			}
			set
			{
				this._formatting = new Formatting?(value);
			}
		}

		// Token: 0x1700042A RID: 1066
		// (get) Token: 0x06001D44 RID: 7492 RVA: 0x0007FB14 File Offset: 0x0007DD14
		// (set) Token: 0x06001D45 RID: 7493 RVA: 0x000196E6 File Offset: 0x000178E6
		public DateFormatHandling DateFormatHandling
		{
			get
			{
				DateFormatHandling? dateFormatHandling = this._dateFormatHandling;
				if (dateFormatHandling == null)
				{
					return DateFormatHandling.IsoDateFormat;
				}
				return dateFormatHandling.GetValueOrDefault();
			}
			set
			{
				this._dateFormatHandling = new DateFormatHandling?(value);
			}
		}

		// Token: 0x1700042B RID: 1067
		// (get) Token: 0x06001D46 RID: 7494 RVA: 0x0007FB3C File Offset: 0x0007DD3C
		// (set) Token: 0x06001D47 RID: 7495 RVA: 0x000196F4 File Offset: 0x000178F4
		public DateTimeZoneHandling DateTimeZoneHandling
		{
			get
			{
				DateTimeZoneHandling? dateTimeZoneHandling = this._dateTimeZoneHandling;
				if (dateTimeZoneHandling == null)
				{
					return DateTimeZoneHandling.RoundtripKind;
				}
				return dateTimeZoneHandling.GetValueOrDefault();
			}
			set
			{
				this._dateTimeZoneHandling = new DateTimeZoneHandling?(value);
			}
		}

		// Token: 0x1700042C RID: 1068
		// (get) Token: 0x06001D48 RID: 7496 RVA: 0x0007FB64 File Offset: 0x0007DD64
		// (set) Token: 0x06001D49 RID: 7497 RVA: 0x00019702 File Offset: 0x00017902
		public DateParseHandling DateParseHandling
		{
			get
			{
				DateParseHandling? dateParseHandling = this._dateParseHandling;
				if (dateParseHandling == null)
				{
					return DateParseHandling.DateTime;
				}
				return dateParseHandling.GetValueOrDefault();
			}
			set
			{
				this._dateParseHandling = new DateParseHandling?(value);
			}
		}

		// Token: 0x1700042D RID: 1069
		// (get) Token: 0x06001D4A RID: 7498 RVA: 0x0007FB8C File Offset: 0x0007DD8C
		// (set) Token: 0x06001D4B RID: 7499 RVA: 0x00019710 File Offset: 0x00017910
		public FloatFormatHandling FloatFormatHandling
		{
			get
			{
				FloatFormatHandling? floatFormatHandling = this._floatFormatHandling;
				if (floatFormatHandling == null)
				{
					return FloatFormatHandling.String;
				}
				return floatFormatHandling.GetValueOrDefault();
			}
			set
			{
				this._floatFormatHandling = new FloatFormatHandling?(value);
			}
		}

		// Token: 0x1700042E RID: 1070
		// (get) Token: 0x06001D4C RID: 7500 RVA: 0x0007FBB4 File Offset: 0x0007DDB4
		// (set) Token: 0x06001D4D RID: 7501 RVA: 0x0001971E File Offset: 0x0001791E
		public FloatParseHandling FloatParseHandling
		{
			get
			{
				FloatParseHandling? floatParseHandling = this._floatParseHandling;
				if (floatParseHandling == null)
				{
					return FloatParseHandling.Double;
				}
				return floatParseHandling.GetValueOrDefault();
			}
			set
			{
				this._floatParseHandling = new FloatParseHandling?(value);
			}
		}

		// Token: 0x1700042F RID: 1071
		// (get) Token: 0x06001D4E RID: 7502 RVA: 0x0007FBDC File Offset: 0x0007DDDC
		// (set) Token: 0x06001D4F RID: 7503 RVA: 0x0001972C File Offset: 0x0001792C
		public StringEscapeHandling StringEscapeHandling
		{
			get
			{
				StringEscapeHandling? stringEscapeHandling = this._stringEscapeHandling;
				if (stringEscapeHandling == null)
				{
					return StringEscapeHandling.Default;
				}
				return stringEscapeHandling.GetValueOrDefault();
			}
			set
			{
				this._stringEscapeHandling = new StringEscapeHandling?(value);
			}
		}

		// Token: 0x17000430 RID: 1072
		// (get) Token: 0x06001D50 RID: 7504 RVA: 0x0001973A File Offset: 0x0001793A
		// (set) Token: 0x06001D51 RID: 7505 RVA: 0x0001974B File Offset: 0x0001794B
		public CultureInfo Culture
		{
			get
			{
				return this._culture ?? JsonSerializerSettings.DefaultCulture;
			}
			set
			{
				this._culture = value;
			}
		}

		// Token: 0x17000431 RID: 1073
		// (get) Token: 0x06001D52 RID: 7506 RVA: 0x0007FC04 File Offset: 0x0007DE04
		// (set) Token: 0x06001D53 RID: 7507 RVA: 0x00019754 File Offset: 0x00017954
		public bool CheckAdditionalContent
		{
			get
			{
				return this._checkAdditionalContent ?? false;
			}
			set
			{
				this._checkAdditionalContent = new bool?(value);
			}
		}

		// Token: 0x06001D55 RID: 7509 RVA: 0x00019779 File Offset: 0x00017979
		public JsonSerializerSettings()
		{
			this.Converters = new List<JsonConverter>();
		}

		// Token: 0x06001D56 RID: 7510 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_0(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}

		// Token: 0x06001D57 RID: 7511 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_1()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x04000B12 RID: 2834
		internal const ReferenceLoopHandling DefaultReferenceLoopHandling = ReferenceLoopHandling.Error;

		// Token: 0x04000B13 RID: 2835
		internal const MissingMemberHandling DefaultMissingMemberHandling = MissingMemberHandling.Ignore;

		// Token: 0x04000B14 RID: 2836
		internal const NullValueHandling DefaultNullValueHandling = NullValueHandling.Include;

		// Token: 0x04000B15 RID: 2837
		internal const DefaultValueHandling DefaultDefaultValueHandling = DefaultValueHandling.Include;

		// Token: 0x04000B16 RID: 2838
		internal const ObjectCreationHandling DefaultObjectCreationHandling = ObjectCreationHandling.Auto;

		// Token: 0x04000B17 RID: 2839
		internal const PreserveReferencesHandling DefaultPreserveReferencesHandling = PreserveReferencesHandling.None;

		// Token: 0x04000B18 RID: 2840
		internal const ConstructorHandling DefaultConstructorHandling = ConstructorHandling.Default;

		// Token: 0x04000B19 RID: 2841
		internal const TypeNameHandling DefaultTypeNameHandling = TypeNameHandling.None;

		// Token: 0x04000B1A RID: 2842
		internal const MetadataPropertyHandling DefaultMetadataPropertyHandling = MetadataPropertyHandling.Default;

		// Token: 0x04000B1B RID: 2843
		internal const FormatterAssemblyStyle DefaultTypeNameAssemblyFormat = FormatterAssemblyStyle.Simple;

		// Token: 0x04000B1C RID: 2844
		internal const Formatting DefaultFormatting = Formatting.None;

		// Token: 0x04000B1D RID: 2845
		internal const DateFormatHandling DefaultDateFormatHandling = DateFormatHandling.IsoDateFormat;

		// Token: 0x04000B1E RID: 2846
		internal const DateTimeZoneHandling DefaultDateTimeZoneHandling = DateTimeZoneHandling.RoundtripKind;

		// Token: 0x04000B1F RID: 2847
		internal const DateParseHandling DefaultDateParseHandling = DateParseHandling.DateTime;

		// Token: 0x04000B20 RID: 2848
		internal const FloatParseHandling DefaultFloatParseHandling = FloatParseHandling.Double;

		// Token: 0x04000B21 RID: 2849
		internal const FloatFormatHandling DefaultFloatFormatHandling = FloatFormatHandling.String;

		// Token: 0x04000B22 RID: 2850
		internal const StringEscapeHandling DefaultStringEscapeHandling = StringEscapeHandling.Default;

		// Token: 0x04000B23 RID: 2851
		internal const FormatterAssemblyStyle DefaultFormatterAssemblyStyle = FormatterAssemblyStyle.Simple;

		// Token: 0x04000B24 RID: 2852
		internal const bool DefaultCheckAdditionalContent = false;

		// Token: 0x04000B25 RID: 2853
		internal const string DefaultDateFormatString = "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK";

		// Token: 0x04000B26 RID: 2854
		internal static readonly StreamingContext DefaultContext = default(StreamingContext);

		// Token: 0x04000B27 RID: 2855
		internal static readonly CultureInfo DefaultCulture = JsonSerializerSettings.smethod_1();

		// Token: 0x04000B28 RID: 2856
		internal Formatting? _formatting;

		// Token: 0x04000B29 RID: 2857
		internal DateFormatHandling? _dateFormatHandling;

		// Token: 0x04000B2A RID: 2858
		internal DateTimeZoneHandling? _dateTimeZoneHandling;

		// Token: 0x04000B2B RID: 2859
		internal DateParseHandling? _dateParseHandling;

		// Token: 0x04000B2C RID: 2860
		internal FloatFormatHandling? _floatFormatHandling;

		// Token: 0x04000B2D RID: 2861
		internal FloatParseHandling? _floatParseHandling;

		// Token: 0x04000B2E RID: 2862
		internal StringEscapeHandling? _stringEscapeHandling;

		// Token: 0x04000B2F RID: 2863
		internal CultureInfo _culture;

		// Token: 0x04000B30 RID: 2864
		internal bool? _checkAdditionalContent;

		// Token: 0x04000B31 RID: 2865
		internal int? _maxDepth;

		// Token: 0x04000B32 RID: 2866
		internal bool _maxDepthSet;

		// Token: 0x04000B33 RID: 2867
		internal string _dateFormatString;

		// Token: 0x04000B34 RID: 2868
		internal bool _dateFormatStringSet;

		// Token: 0x04000B35 RID: 2869
		internal FormatterAssemblyStyle? _typeNameAssemblyFormat;

		// Token: 0x04000B36 RID: 2870
		internal DefaultValueHandling? _defaultValueHandling;

		// Token: 0x04000B37 RID: 2871
		internal PreserveReferencesHandling? _preserveReferencesHandling;

		// Token: 0x04000B38 RID: 2872
		internal NullValueHandling? _nullValueHandling;

		// Token: 0x04000B39 RID: 2873
		internal ObjectCreationHandling? _objectCreationHandling;

		// Token: 0x04000B3A RID: 2874
		internal MissingMemberHandling? _missingMemberHandling;

		// Token: 0x04000B3B RID: 2875
		internal ReferenceLoopHandling? _referenceLoopHandling;

		// Token: 0x04000B3C RID: 2876
		internal StreamingContext? _context;

		// Token: 0x04000B3D RID: 2877
		internal ConstructorHandling? _constructorHandling;

		// Token: 0x04000B3E RID: 2878
		internal TypeNameHandling? _typeNameHandling;

		// Token: 0x04000B3F RID: 2879
		internal MetadataPropertyHandling? _metadataPropertyHandling;
	}
}
