﻿using System;
using System.Runtime.Serialization;

namespace Newtonsoft.Json
{
	// Token: 0x0200022C RID: 556
	[Serializable]
	public class JsonReaderException : JsonException
	{
		// Token: 0x170004B1 RID: 1201
		// (get) Token: 0x06001FC2 RID: 8130 RVA: 0x0001ACD9 File Offset: 0x00018ED9
		// (set) Token: 0x06001FC3 RID: 8131 RVA: 0x0001ACE1 File Offset: 0x00018EE1
		public int LineNumber { get; private set; }

		// Token: 0x170004B2 RID: 1202
		// (get) Token: 0x06001FC4 RID: 8132 RVA: 0x0001ACEA File Offset: 0x00018EEA
		// (set) Token: 0x06001FC5 RID: 8133 RVA: 0x0001ACF2 File Offset: 0x00018EF2
		public int LinePosition { get; private set; }

		// Token: 0x170004B3 RID: 1203
		// (get) Token: 0x06001FC6 RID: 8134 RVA: 0x0001ACFB File Offset: 0x00018EFB
		// (set) Token: 0x06001FC7 RID: 8135 RVA: 0x0001AD03 File Offset: 0x00018F03
		public string Path { get; private set; }

		// Token: 0x06001FC8 RID: 8136 RVA: 0x0001AC80 File Offset: 0x00018E80
		public JsonReaderException()
		{
		}

		// Token: 0x06001FC9 RID: 8137 RVA: 0x0001AC88 File Offset: 0x00018E88
		public JsonReaderException(string message)
			: base(message)
		{
		}

		// Token: 0x06001FCA RID: 8138 RVA: 0x0001AC91 File Offset: 0x00018E91
		public JsonReaderException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

		// Token: 0x06001FCB RID: 8139 RVA: 0x0001AC9B File Offset: 0x00018E9B
		public JsonReaderException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x06001FCC RID: 8140 RVA: 0x0001AD0C File Offset: 0x00018F0C
		internal JsonReaderException(string message, Exception innerException, string path, int lineNumber, int linePosition)
			: base(message, innerException)
		{
			this.Path = path;
			this.LineNumber = lineNumber;
			this.LinePosition = linePosition;
		}

		// Token: 0x06001FCD RID: 8141 RVA: 0x0001AD2D File Offset: 0x00018F2D
		internal static JsonReaderException Create(JsonReader reader, string message)
		{
			return JsonReaderException.Create(reader, message, null);
		}

		// Token: 0x06001FCE RID: 8142 RVA: 0x0001AD37 File Offset: 0x00018F37
		internal static JsonReaderException Create(JsonReader reader, string message, Exception ex)
		{
			return JsonReaderException.Create(reader as IJsonLineInfo, reader.Path, message, ex);
		}

		// Token: 0x06001FCF RID: 8143 RVA: 0x00085AA0 File Offset: 0x00083CA0
		internal static JsonReaderException Create(IJsonLineInfo lineInfo, string path, string message, Exception ex)
		{
			message = JsonPosition.FormatMessage(lineInfo, path, message);
			int num;
			int num2;
			if (lineInfo != null && lineInfo.HasLineInfo())
			{
				num = lineInfo.LineNumber;
				num2 = lineInfo.LinePosition;
			}
			else
			{
				num = 0;
				num2 = 0;
			}
			return new JsonReaderException(message, ex, path, num, num2);
		}
	}
}
