﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001BC RID: 444
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
	public class JsonExtensionDataAttribute : Attribute
	{
		// Token: 0x170003A3 RID: 931
		// (get) Token: 0x06001996 RID: 6550 RVA: 0x00017A16 File Offset: 0x00015C16
		// (set) Token: 0x06001997 RID: 6551 RVA: 0x00017A1E File Offset: 0x00015C1E
		public bool WriteData { get; set; }

		// Token: 0x170003A4 RID: 932
		// (get) Token: 0x06001998 RID: 6552 RVA: 0x00017A27 File Offset: 0x00015C27
		// (set) Token: 0x06001999 RID: 6553 RVA: 0x00017A2F File Offset: 0x00015C2F
		public bool ReadData { get; set; }

		// Token: 0x0600199A RID: 6554 RVA: 0x00017A38 File Offset: 0x00015C38
		public JsonExtensionDataAttribute()
		{
			this.WriteData = true;
			this.ReadData = true;
		}
	}
}
