﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200026B RID: 619
	public enum NullValueHandling
	{
		// Token: 0x04000CDC RID: 3292
		Include,
		// Token: 0x04000CDD RID: 3293
		Ignore
	}
}
