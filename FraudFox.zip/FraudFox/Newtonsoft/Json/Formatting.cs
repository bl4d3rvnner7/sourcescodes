﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001BA RID: 442
	public enum Formatting
	{
		// Token: 0x040009DB RID: 2523
		None,
		// Token: 0x040009DC RID: 2524
		Indented
	}
}
