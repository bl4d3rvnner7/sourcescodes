﻿using System;
using System.Xml;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x02000217 RID: 535
	internal class XmlDocumentTypeWrapper : XmlNodeWrapper, IXmlNode, IXmlDocumentType
	{
		// Token: 0x06001E37 RID: 7735 RVA: 0x00019D9D File Offset: 0x00017F9D
		public XmlDocumentTypeWrapper(XmlDocumentType documentType)
			: base(documentType)
		{
			this._documentType = documentType;
		}

		// Token: 0x17000467 RID: 1127
		// (get) Token: 0x06001E38 RID: 7736 RVA: 0x00019DAD File Offset: 0x00017FAD
		public string Name
		{
			get
			{
				return XmlDocumentTypeWrapper.smethod_10(this._documentType);
			}
		}

		// Token: 0x17000468 RID: 1128
		// (get) Token: 0x06001E39 RID: 7737 RVA: 0x00019DBA File Offset: 0x00017FBA
		public string System
		{
			get
			{
				return XmlDocumentTypeWrapper.smethod_11(this._documentType);
			}
		}

		// Token: 0x17000469 RID: 1129
		// (get) Token: 0x06001E3A RID: 7738 RVA: 0x00019DC7 File Offset: 0x00017FC7
		public string Public
		{
			get
			{
				return XmlDocumentTypeWrapper.smethod_12(this._documentType);
			}
		}

		// Token: 0x1700046A RID: 1130
		// (get) Token: 0x06001E3B RID: 7739 RVA: 0x00019DD4 File Offset: 0x00017FD4
		public string InternalSubset
		{
			get
			{
				return XmlDocumentTypeWrapper.smethod_13(this._documentType);
			}
		}

		// Token: 0x1700046B RID: 1131
		// (get) Token: 0x06001E3C RID: 7740 RVA: 0x00019DE1 File Offset: 0x00017FE1
		public override string LocalName
		{
			get
			{
				return <Module>.smethod_24<string>(3726845224U);
			}
		}

		// Token: 0x06001E3D RID: 7741 RVA: 0x00019DED File Offset: 0x00017FED
		static string smethod_10(XmlNode xmlNode_0)
		{
			return xmlNode_0.Name;
		}

		// Token: 0x06001E3E RID: 7742 RVA: 0x00019DF5 File Offset: 0x00017FF5
		static string smethod_11(XmlDocumentType xmlDocumentType_0)
		{
			return xmlDocumentType_0.SystemId;
		}

		// Token: 0x06001E3F RID: 7743 RVA: 0x00019DFD File Offset: 0x00017FFD
		static string smethod_12(XmlDocumentType xmlDocumentType_0)
		{
			return xmlDocumentType_0.PublicId;
		}

		// Token: 0x06001E40 RID: 7744 RVA: 0x00019E05 File Offset: 0x00018005
		static string smethod_13(XmlDocumentType xmlDocumentType_0)
		{
			return xmlDocumentType_0.InternalSubset;
		}

		// Token: 0x04000B72 RID: 2930
		private readonly XmlDocumentType _documentType;
	}
}
