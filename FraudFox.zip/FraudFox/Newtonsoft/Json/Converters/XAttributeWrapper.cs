﻿using System;
using System.Xml.Linq;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x02000220 RID: 544
	internal class XAttributeWrapper : XObjectWrapper
	{
		// Token: 0x1700048D RID: 1165
		// (get) Token: 0x06001EA5 RID: 7845 RVA: 0x0001A20F File Offset: 0x0001840F
		private XAttribute Attribute
		{
			get
			{
				return (XAttribute)base.WrappedNode;
			}
		}

		// Token: 0x06001EA6 RID: 7846 RVA: 0x00019F56 File Offset: 0x00018156
		public XAttributeWrapper(XAttribute attribute)
			: base(attribute)
		{
		}

		// Token: 0x1700048E RID: 1166
		// (get) Token: 0x06001EA7 RID: 7847 RVA: 0x0001A21C File Offset: 0x0001841C
		// (set) Token: 0x06001EA8 RID: 7848 RVA: 0x0001A229 File Offset: 0x00018429
		public override string Value
		{
			get
			{
				return XAttributeWrapper.smethod_2(this.Attribute);
			}
			set
			{
				XAttributeWrapper.smethod_3(this.Attribute, value);
			}
		}

		// Token: 0x1700048F RID: 1167
		// (get) Token: 0x06001EA9 RID: 7849 RVA: 0x0001A237 File Offset: 0x00018437
		public override string LocalName
		{
			get
			{
				return XAttributeWrapper.smethod_5(XAttributeWrapper.smethod_4(this.Attribute));
			}
		}

		// Token: 0x17000490 RID: 1168
		// (get) Token: 0x06001EAA RID: 7850 RVA: 0x0001A249 File Offset: 0x00018449
		public override string NamespaceUri
		{
			get
			{
				return XAttributeWrapper.smethod_6(XAttributeWrapper.smethod_4(this.Attribute));
			}
		}

		// Token: 0x17000491 RID: 1169
		// (get) Token: 0x06001EAB RID: 7851 RVA: 0x0001A25B File Offset: 0x0001845B
		public override IXmlNode ParentNode
		{
			get
			{
				if (XAttributeWrapper.smethod_7(this.Attribute) == null)
				{
					return null;
				}
				return XContainerWrapper.WrapNode(XAttributeWrapper.smethod_7(this.Attribute));
			}
		}

		// Token: 0x06001EAC RID: 7852 RVA: 0x0001A27C File Offset: 0x0001847C
		static string smethod_2(XAttribute xattribute_0)
		{
			return xattribute_0.Value;
		}

		// Token: 0x06001EAD RID: 7853 RVA: 0x0001A284 File Offset: 0x00018484
		static void smethod_3(XAttribute xattribute_0, string string_0)
		{
			xattribute_0.Value = string_0;
		}

		// Token: 0x06001EAE RID: 7854 RVA: 0x0001A28D File Offset: 0x0001848D
		static XName smethod_4(XAttribute xattribute_0)
		{
			return xattribute_0.Name;
		}

		// Token: 0x06001EAF RID: 7855 RVA: 0x0001A295 File Offset: 0x00018495
		static string smethod_5(XName xname_0)
		{
			return xname_0.LocalName;
		}

		// Token: 0x06001EB0 RID: 7856 RVA: 0x0001A29D File Offset: 0x0001849D
		static string smethod_6(XName xname_0)
		{
			return xname_0.NamespaceName;
		}

		// Token: 0x06001EB1 RID: 7857 RVA: 0x00019FDA File Offset: 0x000181DA
		static XElement smethod_7(XObject xobject_0)
		{
			return xobject_0.Parent;
		}
	}
}
