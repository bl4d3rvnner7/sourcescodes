﻿using System;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x020001A3 RID: 419
	public abstract class CustomCreationConverter<T> : JsonConverter
	{
		// Token: 0x060018F7 RID: 6391 RVA: 0x000176EC File Offset: 0x000158EC
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			throw CustomCreationConverter<T>.smethod_0(<Module>.smethod_25<string>(2091480244U));
		}

		// Token: 0x060018F8 RID: 6392 RVA: 0x0007661C File Offset: 0x0007481C
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			if (reader.TokenType == JsonToken.Null)
			{
				return null;
			}
			T t = this.Create(objectType);
			if (t == null)
			{
				throw new JsonSerializationException(<Module>.smethod_27<string>(1889897904U));
			}
			serializer.Populate(reader, t);
			return t;
		}

		// Token: 0x060018F9 RID: 6393
		public abstract T Create(Type objectType);

		// Token: 0x060018FA RID: 6394 RVA: 0x000176FD File Offset: 0x000158FD
		public override bool CanConvert(Type objectType)
		{
			return CustomCreationConverter<T>.smethod_2(CustomCreationConverter<T>.smethod_1(typeof(T).TypeHandle), objectType);
		}

		// Token: 0x17000395 RID: 917
		// (get) Token: 0x060018FB RID: 6395 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanWrite
		{
			get
			{
				return false;
			}
		}
	}
}
