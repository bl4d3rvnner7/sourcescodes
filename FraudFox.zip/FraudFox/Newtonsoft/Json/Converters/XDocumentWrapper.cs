﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x0200021C RID: 540
	internal class XDocumentWrapper : XContainerWrapper, IXmlNode, IXmlDocument
	{
		// Token: 0x17000481 RID: 1153
		// (get) Token: 0x06001E6F RID: 7791 RVA: 0x00019FEB File Offset: 0x000181EB
		private XDocument Document
		{
			get
			{
				return (XDocument)base.WrappedNode;
			}
		}

		// Token: 0x06001E70 RID: 7792 RVA: 0x00019FF8 File Offset: 0x000181F8
		public XDocumentWrapper(XDocument document)
			: base(document)
		{
		}

		// Token: 0x17000482 RID: 1154
		// (get) Token: 0x06001E71 RID: 7793 RVA: 0x00081C48 File Offset: 0x0007FE48
		public override IList<IXmlNode> ChildNodes
		{
			get
			{
				IList<IXmlNode> childNodes = base.ChildNodes;
				if (XDocumentWrapper.smethod_5(this.Document) != null && childNodes[0].NodeType != XmlNodeType.XmlDeclaration)
				{
					childNodes.Insert(0, new XDeclarationWrapper(XDocumentWrapper.smethod_5(this.Document)));
				}
				return childNodes;
			}
		}

		// Token: 0x06001E72 RID: 7794 RVA: 0x0001A001 File Offset: 0x00018201
		public IXmlNode CreateComment(string text)
		{
			return new XObjectWrapper(XDocumentWrapper.smethod_6(text));
		}

		// Token: 0x06001E73 RID: 7795 RVA: 0x0001A00E File Offset: 0x0001820E
		public IXmlNode CreateTextNode(string text)
		{
			return new XObjectWrapper(XDocumentWrapper.smethod_7(text));
		}

		// Token: 0x06001E74 RID: 7796 RVA: 0x0001A01B File Offset: 0x0001821B
		public IXmlNode CreateCDataSection(string data)
		{
			return new XObjectWrapper(XDocumentWrapper.smethod_8(data));
		}

		// Token: 0x06001E75 RID: 7797 RVA: 0x0001A00E File Offset: 0x0001820E
		public IXmlNode CreateWhitespace(string text)
		{
			return new XObjectWrapper(XDocumentWrapper.smethod_7(text));
		}

		// Token: 0x06001E76 RID: 7798 RVA: 0x0001A00E File Offset: 0x0001820E
		public IXmlNode CreateSignificantWhitespace(string text)
		{
			return new XObjectWrapper(XDocumentWrapper.smethod_7(text));
		}

		// Token: 0x06001E77 RID: 7799 RVA: 0x0001A028 File Offset: 0x00018228
		public IXmlNode CreateXmlDeclaration(string version, string encoding, string standalone)
		{
			return new XDeclarationWrapper(XDocumentWrapper.smethod_9(version, encoding, standalone));
		}

		// Token: 0x06001E78 RID: 7800 RVA: 0x0001A037 File Offset: 0x00018237
		public IXmlNode CreateXmlDocumentType(string name, string publicId, string systemId, string internalSubset)
		{
			return new XDocumentTypeWrapper(XDocumentWrapper.smethod_10(name, publicId, systemId, internalSubset));
		}

		// Token: 0x06001E79 RID: 7801 RVA: 0x0001A048 File Offset: 0x00018248
		public IXmlNode CreateProcessingInstruction(string target, string data)
		{
			return new XProcessingInstructionWrapper(XDocumentWrapper.smethod_11(target, data));
		}

		// Token: 0x06001E7A RID: 7802 RVA: 0x0001A056 File Offset: 0x00018256
		public IXmlElement CreateElement(string elementName)
		{
			return new XElementWrapper(XDocumentWrapper.smethod_13(XDocumentWrapper.smethod_12(elementName)));
		}

		// Token: 0x06001E7B RID: 7803 RVA: 0x00081C94 File Offset: 0x0007FE94
		public IXmlElement CreateElement(string qualifiedName, string namespaceUri)
		{
			string localName = MiscellaneousUtils.GetLocalName(qualifiedName);
			return new XElementWrapper(XDocumentWrapper.smethod_13(XDocumentWrapper.smethod_14(localName, namespaceUri)));
		}

		// Token: 0x06001E7C RID: 7804 RVA: 0x0001A068 File Offset: 0x00018268
		public IXmlNode CreateAttribute(string name, string value)
		{
			return new XAttributeWrapper(XDocumentWrapper.smethod_15(XDocumentWrapper.smethod_12(name), value));
		}

		// Token: 0x06001E7D RID: 7805 RVA: 0x00081CBC File Offset: 0x0007FEBC
		public IXmlNode CreateAttribute(string qualifiedName, string namespaceUri, string value)
		{
			string localName = MiscellaneousUtils.GetLocalName(qualifiedName);
			return new XAttributeWrapper(XDocumentWrapper.smethod_15(XDocumentWrapper.smethod_14(localName, namespaceUri), value));
		}

		// Token: 0x17000483 RID: 1155
		// (get) Token: 0x06001E7E RID: 7806 RVA: 0x0001A07B File Offset: 0x0001827B
		public IXmlElement DocumentElement
		{
			get
			{
				if (XDocumentWrapper.smethod_16(this.Document) == null)
				{
					return null;
				}
				return new XElementWrapper(XDocumentWrapper.smethod_16(this.Document));
			}
		}

		// Token: 0x06001E7F RID: 7807 RVA: 0x00081CE4 File Offset: 0x0007FEE4
		public override IXmlNode AppendChild(IXmlNode newChild)
		{
			XDeclarationWrapper xdeclarationWrapper = newChild as XDeclarationWrapper;
			if (xdeclarationWrapper != null)
			{
				XDocumentWrapper.smethod_17(this.Document, xdeclarationWrapper.Declaration);
				return xdeclarationWrapper;
			}
			return base.AppendChild(newChild);
		}

		// Token: 0x06001E80 RID: 7808 RVA: 0x0001A09C File Offset: 0x0001829C
		static XDeclaration smethod_5(XDocument xdocument_0)
		{
			return xdocument_0.Declaration;
		}

		// Token: 0x06001E81 RID: 7809 RVA: 0x0001A0A4 File Offset: 0x000182A4
		static XComment smethod_6(string string_0)
		{
			return new XComment(string_0);
		}

		// Token: 0x06001E82 RID: 7810 RVA: 0x0001A0AC File Offset: 0x000182AC
		static XText smethod_7(string string_0)
		{
			return new XText(string_0);
		}

		// Token: 0x06001E83 RID: 7811 RVA: 0x0001A0B4 File Offset: 0x000182B4
		static XCData smethod_8(string string_0)
		{
			return new XCData(string_0);
		}

		// Token: 0x06001E84 RID: 7812 RVA: 0x0001A0BC File Offset: 0x000182BC
		static XDeclaration smethod_9(string string_0, string string_1, string string_2)
		{
			return new XDeclaration(string_0, string_1, string_2);
		}

		// Token: 0x06001E85 RID: 7813 RVA: 0x0001A0C6 File Offset: 0x000182C6
		static XDocumentType smethod_10(string string_0, string string_1, string string_2, string string_3)
		{
			return new XDocumentType(string_0, string_1, string_2, string_3);
		}

		// Token: 0x06001E86 RID: 7814 RVA: 0x0001A0D1 File Offset: 0x000182D1
		static XProcessingInstruction smethod_11(string string_0, string string_1)
		{
			return new XProcessingInstruction(string_0, string_1);
		}

		// Token: 0x06001E87 RID: 7815 RVA: 0x0001A0DA File Offset: 0x000182DA
		static XName smethod_12(string string_0)
		{
			return string_0;
		}

		// Token: 0x06001E88 RID: 7816 RVA: 0x0001A0E2 File Offset: 0x000182E2
		static XElement smethod_13(XName xname_0)
		{
			return new XElement(xname_0);
		}

		// Token: 0x06001E89 RID: 7817 RVA: 0x0001A0EA File Offset: 0x000182EA
		static XName smethod_14(string string_0, string string_1)
		{
			return XName.Get(string_0, string_1);
		}

		// Token: 0x06001E8A RID: 7818 RVA: 0x0001A0F3 File Offset: 0x000182F3
		static XAttribute smethod_15(XName xname_0, object object_0)
		{
			return new XAttribute(xname_0, object_0);
		}

		// Token: 0x06001E8B RID: 7819 RVA: 0x0001A0FC File Offset: 0x000182FC
		static XElement smethod_16(XDocument xdocument_0)
		{
			return xdocument_0.Root;
		}

		// Token: 0x06001E8C RID: 7820 RVA: 0x0001A104 File Offset: 0x00018304
		static void smethod_17(XDocument xdocument_0, XDeclaration xdeclaration_0)
		{
			xdocument_0.Declaration = xdeclaration_0;
		}
	}
}
