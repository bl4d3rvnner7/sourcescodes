﻿using System;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x02000210 RID: 528
	internal interface IXmlDocument : IXmlNode
	{
		// Token: 0x06001DF1 RID: 7665
		IXmlNode CreateComment(string text);

		// Token: 0x06001DF2 RID: 7666
		IXmlNode CreateTextNode(string text);

		// Token: 0x06001DF3 RID: 7667
		IXmlNode CreateCDataSection(string data);

		// Token: 0x06001DF4 RID: 7668
		IXmlNode CreateWhitespace(string text);

		// Token: 0x06001DF5 RID: 7669
		IXmlNode CreateSignificantWhitespace(string text);

		// Token: 0x06001DF6 RID: 7670
		IXmlNode CreateXmlDeclaration(string version, string encoding, string standalone);

		// Token: 0x06001DF7 RID: 7671
		IXmlNode CreateXmlDocumentType(string name, string publicId, string systemId, string internalSubset);

		// Token: 0x06001DF8 RID: 7672
		IXmlNode CreateProcessingInstruction(string target, string data);

		// Token: 0x06001DF9 RID: 7673
		IXmlElement CreateElement(string elementName);

		// Token: 0x06001DFA RID: 7674
		IXmlElement CreateElement(string qualifiedName, string namespaceUri);

		// Token: 0x06001DFB RID: 7675
		IXmlNode CreateAttribute(string name, string value);

		// Token: 0x06001DFC RID: 7676
		IXmlNode CreateAttribute(string qualifiedName, string namespaceUri, string value);

		// Token: 0x17000459 RID: 1113
		// (get) Token: 0x06001DFD RID: 7677
		IXmlElement DocumentElement { get; }
	}
}
