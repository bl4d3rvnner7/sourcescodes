﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Numerics;
using System.Xml;
using System.Xml.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x02000222 RID: 546
	public class XmlNodeConverter : JsonConverter
	{
		// Token: 0x17000498 RID: 1176
		// (get) Token: 0x06001EC7 RID: 7879 RVA: 0x0001A38C File Offset: 0x0001858C
		// (set) Token: 0x06001EC8 RID: 7880 RVA: 0x0001A394 File Offset: 0x00018594
		public string DeserializeRootElementName { get; set; }

		// Token: 0x17000499 RID: 1177
		// (get) Token: 0x06001EC9 RID: 7881 RVA: 0x0001A39D File Offset: 0x0001859D
		// (set) Token: 0x06001ECA RID: 7882 RVA: 0x0001A3A5 File Offset: 0x000185A5
		public bool WriteArrayAttribute { get; set; }

		// Token: 0x1700049A RID: 1178
		// (get) Token: 0x06001ECB RID: 7883 RVA: 0x0001A3AE File Offset: 0x000185AE
		// (set) Token: 0x06001ECC RID: 7884 RVA: 0x0001A3B6 File Offset: 0x000185B6
		public bool OmitRootObject { get; set; }

		// Token: 0x06001ECD RID: 7885 RVA: 0x00081D40 File Offset: 0x0007FF40
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			IXmlNode xmlNode = this.WrapXml(value);
			XmlNamespaceManager xmlNamespaceManager = XmlNodeConverter.smethod_1(XmlNodeConverter.smethod_0());
			this.PushParentNamespaces(xmlNode, xmlNamespaceManager);
			if (!this.OmitRootObject)
			{
				writer.WriteStartObject();
			}
			this.SerializeNode(writer, xmlNode, xmlNamespaceManager, !this.OmitRootObject);
			if (!this.OmitRootObject)
			{
				writer.WriteEndObject();
			}
		}

		// Token: 0x06001ECE RID: 7886 RVA: 0x00081D98 File Offset: 0x0007FF98
		private IXmlNode WrapXml(object value)
		{
			if (value is XObject)
			{
				return XContainerWrapper.WrapNode((XObject)value);
			}
			if (!(value is XmlNode))
			{
				throw XmlNodeConverter.smethod_2(<Module>.smethod_27<string>(363374488U), <Module>.smethod_23<string>(2033612370U));
			}
			return XmlNodeWrapper.WrapNode((XmlNode)value);
		}

		// Token: 0x06001ECF RID: 7887 RVA: 0x00081DE8 File Offset: 0x0007FFE8
		private void PushParentNamespaces(IXmlNode node, XmlNamespaceManager manager)
		{
			List<IXmlNode> list = null;
			IXmlNode xmlNode = node;
			while ((xmlNode = xmlNode.ParentNode) != null)
			{
				if (xmlNode.NodeType == XmlNodeType.Element)
				{
					if (list == null)
					{
						list = new List<IXmlNode>();
					}
					list.Add(xmlNode);
				}
			}
			if (list != null)
			{
				list.Reverse();
				foreach (IXmlNode xmlNode2 in list)
				{
					XmlNodeConverter.smethod_3(manager);
					IEnumerator<IXmlNode> enumerator2 = xmlNode2.Attributes.GetEnumerator();
					try
					{
						while (XmlNodeConverter.smethod_7(enumerator2))
						{
							IXmlNode xmlNode3 = enumerator2.Current;
							if (XmlNodeConverter.smethod_4(xmlNode3.NamespaceUri, <Module>.smethod_24<string>(1111655733U)) && XmlNodeConverter.smethod_5(xmlNode3.LocalName, <Module>.smethod_23<string>(2545702777U)))
							{
								XmlNodeConverter.smethod_6(manager, xmlNode3.LocalName, xmlNode3.Value);
							}
						}
					}
					finally
					{
						if (enumerator2 != null)
						{
							XmlNodeConverter.smethod_8(enumerator2);
						}
					}
				}
			}
		}

		// Token: 0x06001ED0 RID: 7888 RVA: 0x00081EF4 File Offset: 0x000800F4
		private string ResolveFullName(IXmlNode node, XmlNamespaceManager manager)
		{
			string text = ((node.NamespaceUri == null || (XmlNodeConverter.smethod_4(node.LocalName, <Module>.smethod_24<string>(3144054788U)) && XmlNodeConverter.smethod_4(node.NamespaceUri, <Module>.smethod_24<string>(1111655733U)))) ? null : XmlNodeConverter.smethod_9(manager, node.NamespaceUri));
			if (!XmlNodeConverter.smethod_10(text))
			{
				return XmlNodeConverter.smethod_11(text, <Module>.smethod_24<string>(440969907U), node.LocalName);
			}
			return node.LocalName;
		}

		// Token: 0x06001ED1 RID: 7889 RVA: 0x00081F6C File Offset: 0x0008016C
		private string GetPropertyName(IXmlNode node, XmlNamespaceManager manager)
		{
			switch (node.NodeType)
			{
			case XmlNodeType.Element:
				return this.ResolveFullName(node, manager);
			case XmlNodeType.Attribute:
				if (XmlNodeConverter.smethod_4(node.NamespaceUri, <Module>.smethod_23<string>(1753761644U)))
				{
					return XmlNodeConverter.smethod_12(<Module>.smethod_27<string>(2865428782U), node.LocalName);
				}
				return XmlNodeConverter.smethod_12(<Module>.smethod_26<string>(800603216U), this.ResolveFullName(node, manager));
			case XmlNodeType.Text:
				return <Module>.smethod_25<string>(3206368116U);
			case XmlNodeType.CDATA:
				return <Module>.smethod_23<string>(824981134U);
			case XmlNodeType.ProcessingInstruction:
				return XmlNodeConverter.smethod_12(<Module>.smethod_27<string>(2700230678U), this.ResolveFullName(node, manager));
			case XmlNodeType.Comment:
				return <Module>.smethod_25<string>(2411348260U);
			case XmlNodeType.DocumentType:
				return XmlNodeConverter.smethod_12(<Module>.smethod_23<string>(2333606900U), this.ResolveFullName(node, manager));
			case XmlNodeType.Whitespace:
				return <Module>.smethod_26<string>(1040013066U);
			case XmlNodeType.SignificantWhitespace:
				return <Module>.smethod_24<string>(4241042157U);
			case XmlNodeType.XmlDeclaration:
				return <Module>.smethod_27<string>(2140770362U);
			}
			throw new JsonSerializationException(XmlNodeConverter.smethod_13(<Module>.smethod_23<string>(4186027418U), node.NodeType));
		}

		// Token: 0x06001ED2 RID: 7890 RVA: 0x000820B0 File Offset: 0x000802B0
		private bool IsArray(IXmlNode node)
		{
			IXmlNode xmlNode;
			if (node.Attributes != null)
			{
				xmlNode = node.Attributes.SingleOrDefault((IXmlNode a) => XmlNodeConverter.smethod_4(a.LocalName, <Module>.smethod_23<string>(4011559791U)) && XmlNodeConverter.smethod_4(a.NamespaceUri, <Module>.smethod_25<string>(1506581371U)));
			}
			else
			{
				xmlNode = null;
			}
			IXmlNode xmlNode2 = xmlNode;
			return xmlNode2 != null && XmlNodeConverter.smethod_14(xmlNode2.Value);
		}

		// Token: 0x06001ED3 RID: 7891 RVA: 0x00082104 File Offset: 0x00080304
		private void SerializeGroupedNodes(JsonWriter writer, IXmlNode node, XmlNamespaceManager manager, bool writePropertyName)
		{
			Dictionary<string, List<IXmlNode>> dictionary = new Dictionary<string, List<IXmlNode>>();
			for (int i = 0; i < node.ChildNodes.Count; i++)
			{
				IXmlNode xmlNode = node.ChildNodes[i];
				string propertyName = this.GetPropertyName(xmlNode, manager);
				List<IXmlNode> list;
				if (!dictionary.TryGetValue(propertyName, out list))
				{
					list = new List<IXmlNode>();
					dictionary.Add(propertyName, list);
				}
				list.Add(xmlNode);
			}
			foreach (KeyValuePair<string, List<IXmlNode>> keyValuePair in dictionary)
			{
				List<IXmlNode> value = keyValuePair.Value;
				bool flag = value.Count != 1 || this.IsArray(value[0]);
				if (flag)
				{
					string key = keyValuePair.Key;
					if (writePropertyName)
					{
						writer.WritePropertyName(key);
					}
					writer.WriteStartArray();
					for (int j = 0; j < value.Count; j++)
					{
						this.SerializeNode(writer, value[j], manager, false);
					}
					writer.WriteEndArray();
				}
				else
				{
					this.SerializeNode(writer, value[0], manager, writePropertyName);
				}
			}
		}

		// Token: 0x06001ED4 RID: 7892 RVA: 0x00082234 File Offset: 0x00080434
		private void SerializeNode(JsonWriter writer, IXmlNode node, XmlNamespaceManager manager, bool writePropertyName)
		{
			switch (node.NodeType)
			{
			case XmlNodeType.Element:
			{
				if (this.IsArray(node))
				{
					if (node.ChildNodes.All((IXmlNode n) => XmlNodeConverter.<>c__DisplayClass4.smethod_0(n.LocalName, node.LocalName)) && node.ChildNodes.Count > 0)
					{
						this.SerializeGroupedNodes(writer, node, manager, false);
						return;
					}
				}
				XmlNodeConverter.smethod_3(manager);
				IEnumerator<IXmlNode> enumerator = node.Attributes.GetEnumerator();
				try
				{
					while (XmlNodeConverter.smethod_7(enumerator))
					{
						IXmlNode xmlNode = enumerator.Current;
						if (XmlNodeConverter.smethod_4(xmlNode.NamespaceUri, <Module>.smethod_24<string>(1111655733U)))
						{
							string text = (XmlNodeConverter.smethod_5(xmlNode.LocalName, <Module>.smethod_23<string>(2545702777U)) ? xmlNode.LocalName : string.Empty);
							string value = xmlNode.Value;
							XmlNodeConverter.smethod_6(manager, text, value);
						}
					}
				}
				finally
				{
					if (enumerator != null)
					{
						XmlNodeConverter.smethod_8(enumerator);
					}
				}
				if (writePropertyName)
				{
					writer.WritePropertyName(this.GetPropertyName(node, manager));
				}
				if (!this.ValueAttributes(node.Attributes).Any<IXmlNode>())
				{
					if (node.ChildNodes.Count == 1)
					{
						if (node.ChildNodes[0].NodeType == XmlNodeType.Text)
						{
							writer.WriteValue(node.ChildNodes[0].Value);
							goto IL_026B;
						}
					}
				}
				if (node.ChildNodes.Count == 0 && CollectionUtils.IsNullOrEmpty<IXmlNode>(node.Attributes))
				{
					IXmlElement xmlElement = (IXmlElement)node;
					if (!xmlElement.IsEmpty)
					{
						writer.WriteValue(string.Empty);
					}
					else
					{
						writer.WriteNull();
					}
				}
				else
				{
					writer.WriteStartObject();
					for (int i = 0; i < node.Attributes.Count; i++)
					{
						this.SerializeNode(writer, node.Attributes[i], manager, true);
					}
					this.SerializeGroupedNodes(writer, node, manager, true);
					writer.WriteEndObject();
				}
				IL_026B:
				XmlNodeConverter.smethod_15(manager);
				return;
			}
			case XmlNodeType.Attribute:
			case XmlNodeType.Text:
			case XmlNodeType.CDATA:
			case XmlNodeType.ProcessingInstruction:
			case XmlNodeType.Whitespace:
			case XmlNodeType.SignificantWhitespace:
				if (XmlNodeConverter.smethod_4(node.NamespaceUri, <Module>.smethod_26<string>(762297640U)) && XmlNodeConverter.smethod_4(node.Value, <Module>.smethod_23<string>(1753761644U)))
				{
					return;
				}
				if (XmlNodeConverter.smethod_4(node.NamespaceUri, <Module>.smethod_23<string>(1753761644U)) && XmlNodeConverter.smethod_4(node.LocalName, <Module>.smethod_24<string>(2086191038U)))
				{
					return;
				}
				if (writePropertyName)
				{
					writer.WritePropertyName(this.GetPropertyName(node, manager));
				}
				writer.WriteValue(node.Value);
				return;
			case XmlNodeType.Comment:
				if (writePropertyName)
				{
					writer.WriteComment(node.Value);
					return;
				}
				return;
			case XmlNodeType.Document:
			case XmlNodeType.DocumentFragment:
				this.SerializeGroupedNodes(writer, node, manager, writePropertyName);
				return;
			case XmlNodeType.DocumentType:
			{
				IXmlDocumentType xmlDocumentType = (IXmlDocumentType)node;
				writer.WritePropertyName(this.GetPropertyName(node, manager));
				writer.WriteStartObject();
				if (!XmlNodeConverter.smethod_10(xmlDocumentType.Name))
				{
					writer.WritePropertyName(<Module>.smethod_23<string>(1536525265U));
					writer.WriteValue(xmlDocumentType.Name);
				}
				if (!XmlNodeConverter.smethod_10(xmlDocumentType.Public))
				{
					writer.WritePropertyName(<Module>.smethod_25<string>(1904091299U));
					writer.WriteValue(xmlDocumentType.Public);
				}
				if (!XmlNodeConverter.smethod_10(xmlDocumentType.System))
				{
					writer.WritePropertyName(<Module>.smethod_27<string>(1808646971U));
					writer.WriteValue(xmlDocumentType.System);
				}
				if (!XmlNodeConverter.smethod_10(xmlDocumentType.InternalSubset))
				{
					writer.WritePropertyName(<Module>.smethod_23<string>(1168775886U));
					writer.WriteValue(xmlDocumentType.InternalSubset);
				}
				writer.WriteEndObject();
				return;
			}
			case XmlNodeType.XmlDeclaration:
			{
				IXmlDeclaration xmlDeclaration = (IXmlDeclaration)node;
				writer.WritePropertyName(this.GetPropertyName(node, manager));
				writer.WriteStartObject();
				if (!XmlNodeConverter.smethod_10(xmlDeclaration.Version))
				{
					writer.WritePropertyName(<Module>.smethod_25<string>(651337145U));
					writer.WriteValue(xmlDeclaration.Version);
				}
				if (!XmlNodeConverter.smethod_10(xmlDeclaration.Encoding))
				{
					writer.WritePropertyName(<Module>.smethod_27<string>(2461350673U));
					writer.WriteValue(xmlDeclaration.Encoding);
				}
				if (!XmlNodeConverter.smethod_10(xmlDeclaration.Standalone))
				{
					writer.WritePropertyName(<Module>.smethod_25<string>(1277714222U));
					writer.WriteValue(xmlDeclaration.Standalone);
				}
				writer.WriteEndObject();
				return;
			}
			}
			throw new JsonSerializationException(XmlNodeConverter.smethod_13(<Module>.smethod_24<string>(337819730U), node.NodeType));
		}

		// Token: 0x06001ED5 RID: 7893 RVA: 0x00082734 File Offset: 0x00080934
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			if (reader.TokenType == JsonToken.Null)
			{
				return null;
			}
			XmlNamespaceManager xmlNamespaceManager = XmlNodeConverter.smethod_1(XmlNodeConverter.smethod_0());
			IXmlDocument xmlDocument = null;
			IXmlNode xmlNode = null;
			if (XmlNodeConverter.smethod_17(XmlNodeConverter.smethod_16(typeof(XObject).TypeHandle), objectType))
			{
				if (XmlNodeConverter.smethod_18(objectType, XmlNodeConverter.smethod_16(typeof(XDocument).TypeHandle)) && XmlNodeConverter.smethod_18(objectType, XmlNodeConverter.smethod_16(typeof(XElement).TypeHandle)))
				{
					throw new JsonSerializationException(<Module>.smethod_27<string>(2222470668U));
				}
				XDocument xdocument = XmlNodeConverter.smethod_19();
				xmlDocument = new XDocumentWrapper(xdocument);
				xmlNode = xmlDocument;
			}
			if (XmlNodeConverter.smethod_17(XmlNodeConverter.smethod_16(typeof(XmlNode).TypeHandle), objectType))
			{
				if (XmlNodeConverter.smethod_18(objectType, XmlNodeConverter.smethod_16(typeof(XmlDocument).TypeHandle)))
				{
					throw new JsonSerializationException(<Module>.smethod_27<string>(1383280194U));
				}
				XmlDocument xmlDocument2 = XmlNodeConverter.smethod_20();
				XmlNodeConverter.smethod_21(xmlDocument2, null);
				xmlDocument = new XmlDocumentWrapper(xmlDocument2);
				xmlNode = xmlDocument;
			}
			if (xmlDocument == null || xmlNode == null)
			{
				throw new JsonSerializationException(XmlNodeConverter.smethod_13(<Module>.smethod_25<string>(1048847073U), objectType));
			}
			if (reader.TokenType != JsonToken.StartObject)
			{
				throw new JsonSerializationException(<Module>.smethod_27<string>(404224641U));
			}
			if (XmlNodeConverter.smethod_10(this.DeserializeRootElementName))
			{
				reader.Read();
				this.DeserializeNode(reader, xmlDocument, xmlNamespaceManager, xmlNode);
			}
			else
			{
				this.ReadElement(reader, xmlDocument, xmlNode, this.DeserializeRootElementName, xmlNamespaceManager);
			}
			if (XmlNodeConverter.smethod_22(objectType, XmlNodeConverter.smethod_16(typeof(XElement).TypeHandle)))
			{
				XElement xelement = (XElement)xmlDocument.DocumentElement.WrappedNode;
				XmlNodeConverter.smethod_23(xelement);
				return xelement;
			}
			return xmlDocument.WrappedNode;
		}

		// Token: 0x06001ED6 RID: 7894 RVA: 0x0008289C File Offset: 0x00080A9C
		private void DeserializeValue(JsonReader reader, IXmlDocument document, XmlNamespaceManager manager, string propertyName, IXmlNode currentNode)
		{
			if (propertyName != null)
			{
				if (XmlNodeConverter.smethod_4(propertyName, <Module>.smethod_26<string>(325781249U)))
				{
					currentNode.AppendChild(document.CreateTextNode(XmlNodeConverter.smethod_24(reader.Value)));
					return;
				}
				if (XmlNodeConverter.smethod_4(propertyName, <Module>.smethod_26<string>(2229066850U)))
				{
					currentNode.AppendChild(document.CreateCDataSection(XmlNodeConverter.smethod_24(reader.Value)));
					return;
				}
				if (XmlNodeConverter.smethod_4(propertyName, <Module>.smethod_26<string>(1040013066U)))
				{
					currentNode.AppendChild(document.CreateWhitespace(XmlNodeConverter.smethod_24(reader.Value)));
					return;
				}
				if (XmlNodeConverter.smethod_4(propertyName, <Module>.smethod_27<string>(2420500520U)))
				{
					currentNode.AppendChild(document.CreateSignificantWhitespace(XmlNodeConverter.smethod_24(reader.Value)));
					return;
				}
			}
			if (!XmlNodeConverter.smethod_10(propertyName) && XmlNodeConverter.smethod_25(propertyName, 0) == '?')
			{
				this.CreateInstruction(reader, document, currentNode, propertyName);
				return;
			}
			if (XmlNodeConverter.smethod_26(propertyName, <Module>.smethod_24<string>(476527190U), StringComparison.OrdinalIgnoreCase))
			{
				this.CreateDocumentType(reader, document, currentNode);
				return;
			}
			if (reader.TokenType != JsonToken.StartArray)
			{
				this.ReadElement(reader, document, currentNode, propertyName, manager);
				return;
			}
			this.ReadArrayElements(reader, document, propertyName, currentNode, manager);
		}

		// Token: 0x06001ED7 RID: 7895 RVA: 0x000829C8 File Offset: 0x00080BC8
		private void ReadElement(JsonReader reader, IXmlDocument document, IXmlNode currentNode, string propertyName, XmlNamespaceManager manager)
		{
			if (XmlNodeConverter.smethod_10(propertyName))
			{
				throw new JsonSerializationException(<Module>.smethod_25<string>(2155763201U));
			}
			Dictionary<string, string> dictionary = this.ReadAttributeElements(reader, manager);
			string prefix = MiscellaneousUtils.GetPrefix(propertyName);
			if (propertyName.StartsWith('@'))
			{
				string text = XmlNodeConverter.smethod_27(propertyName, 1);
				string text2 = XmlNodeConverter.smethod_24(reader.Value);
				string prefix2 = MiscellaneousUtils.GetPrefix(text);
				IXmlNode xmlNode = ((!XmlNodeConverter.smethod_10(prefix2)) ? document.CreateAttribute(text, XmlNodeConverter.smethod_28(manager, prefix2), text2) : document.CreateAttribute(text, text2));
				((IXmlElement)currentNode).SetAttributeNode(xmlNode);
				return;
			}
			IXmlElement xmlElement = this.CreateElement(propertyName, document, prefix, manager);
			currentNode.AppendChild(xmlElement);
			foreach (KeyValuePair<string, string> keyValuePair in dictionary)
			{
				string prefix3 = MiscellaneousUtils.GetPrefix(keyValuePair.Key);
				IXmlNode xmlNode2 = ((!XmlNodeConverter.smethod_10(prefix3)) ? document.CreateAttribute(keyValuePair.Key, XmlNodeConverter.smethod_28(manager, prefix3) ?? string.Empty, keyValuePair.Value) : document.CreateAttribute(keyValuePair.Key, keyValuePair.Value));
				xmlElement.SetAttributeNode(xmlNode2);
			}
			if (reader.TokenType != JsonToken.String && reader.TokenType != JsonToken.Integer)
			{
				if (reader.TokenType != JsonToken.Float)
				{
					if (reader.TokenType != JsonToken.Boolean)
					{
						if (reader.TokenType != JsonToken.Date)
						{
							if (reader.TokenType != JsonToken.Null)
							{
								if (reader.TokenType != JsonToken.EndObject)
								{
									XmlNodeConverter.smethod_3(manager);
									this.DeserializeNode(reader, document, manager, xmlElement);
									XmlNodeConverter.smethod_15(manager);
								}
								XmlNodeConverter.smethod_30(manager, string.Empty, XmlNodeConverter.smethod_29(manager));
								return;
							}
							return;
						}
					}
				}
			}
			xmlElement.AppendChild(document.CreateTextNode(this.ConvertTokenToXmlValue(reader)));
		}

		// Token: 0x06001ED8 RID: 7896 RVA: 0x00082BA0 File Offset: 0x00080DA0
		private string ConvertTokenToXmlValue(JsonReader reader)
		{
			if (reader.TokenType == JsonToken.String)
			{
				return XmlNodeConverter.smethod_24(reader.Value);
			}
			if (reader.TokenType == JsonToken.Integer)
			{
				if (reader.Value is BigInteger)
				{
					return ((BigInteger)reader.Value).ToString(XmlNodeConverter.smethod_31());
				}
				return XmlConvert.ToString(Convert.ToInt64(reader.Value, CultureInfo.InvariantCulture));
			}
			else if (reader.TokenType == JsonToken.Float)
			{
				if (reader.Value is decimal)
				{
					return XmlConvert.ToString((decimal)reader.Value);
				}
				if (reader.Value is float)
				{
					return XmlConvert.ToString((float)reader.Value);
				}
				return XmlConvert.ToString(Convert.ToDouble(reader.Value, CultureInfo.InvariantCulture));
			}
			else
			{
				if (reader.TokenType == JsonToken.Boolean)
				{
					return XmlConvert.ToString(Convert.ToBoolean(reader.Value, CultureInfo.InvariantCulture));
				}
				if (reader.TokenType == JsonToken.Date)
				{
					if (reader.Value is DateTimeOffset)
					{
						return XmlConvert.ToString((DateTimeOffset)reader.Value);
					}
					DateTime dateTime = Convert.ToDateTime(reader.Value, CultureInfo.InvariantCulture);
					return XmlConvert.ToString(dateTime, DateTimeUtils.ToSerializationMode(dateTime.Kind));
				}
				else
				{
					if (reader.TokenType == JsonToken.Null)
					{
						return null;
					}
					throw JsonSerializationException.Create(reader, <Module>.smethod_26<string>(3827488771U).FormatWith(CultureInfo.InvariantCulture, reader.TokenType));
				}
			}
		}

		// Token: 0x06001ED9 RID: 7897 RVA: 0x00082D04 File Offset: 0x00080F04
		private void ReadArrayElements(JsonReader reader, IXmlDocument document, string propertyName, IXmlNode currentNode, XmlNamespaceManager manager)
		{
			string prefix = MiscellaneousUtils.GetPrefix(propertyName);
			IXmlElement xmlElement = this.CreateElement(propertyName, document, prefix, manager);
			currentNode.AppendChild(xmlElement);
			int num = 0;
			while (reader.Read() && reader.TokenType != JsonToken.EndArray)
			{
				this.DeserializeValue(reader, document, manager, propertyName, xmlElement);
				num++;
			}
			if (this.WriteArrayAttribute)
			{
				this.AddJsonArrayAttribute(xmlElement, document);
			}
			if (num == 1)
			{
				if (this.WriteArrayAttribute)
				{
					IXmlElement xmlElement2 = xmlElement.ChildNodes.OfType<IXmlElement>().Single((IXmlElement n) => XmlNodeConverter.<>c__DisplayClass8.smethod_0(n.LocalName, propertyName));
					this.AddJsonArrayAttribute(xmlElement2, document);
				}
			}
		}

		// Token: 0x06001EDA RID: 7898 RVA: 0x00082DC0 File Offset: 0x00080FC0
		private void AddJsonArrayAttribute(IXmlElement element, IXmlDocument document)
		{
			element.SetAttributeNode(document.CreateAttribute(<Module>.smethod_27<string>(429037984U), <Module>.smethod_23<string>(1753761644U), <Module>.smethod_23<string>(4283490662U)));
			if (element is XElementWrapper && element.GetPrefixOfNamespace(<Module>.smethod_26<string>(781450428U)) == null)
			{
				element.SetAttributeNode(document.CreateAttribute(<Module>.smethod_27<string>(4164544964U), <Module>.smethod_23<string>(669327632U), <Module>.smethod_23<string>(1753761644U)));
			}
		}

		// Token: 0x06001EDB RID: 7899 RVA: 0x00082E3C File Offset: 0x0008103C
		private Dictionary<string, string> ReadAttributeElements(JsonReader reader, XmlNamespaceManager manager)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			bool flag = false;
			bool flag2 = false;
			if (reader.TokenType != JsonToken.String)
			{
				if (reader.TokenType != JsonToken.Null)
				{
					if (reader.TokenType != JsonToken.Boolean)
					{
						if (reader.TokenType != JsonToken.Integer)
						{
							if (reader.TokenType != JsonToken.Float && reader.TokenType != JsonToken.Date)
							{
								if (reader.TokenType != JsonToken.StartConstructor)
								{
									while (!flag && !flag2 && reader.Read())
									{
										JsonToken tokenType = reader.TokenType;
										switch (tokenType)
										{
										case JsonToken.PropertyName:
										{
											string text = XmlNodeConverter.smethod_24(reader.Value);
											if (!XmlNodeConverter.smethod_10(text))
											{
												char c = XmlNodeConverter.smethod_25(text, 0);
												char c2 = c;
												if (c2 != '$')
												{
													if (c2 == '@')
													{
														text = XmlNodeConverter.smethod_27(text, 1);
														reader.Read();
														string text2 = this.ConvertTokenToXmlValue(reader);
														dictionary.Add(text, text2);
														string text3;
														if (this.IsNamespaceAttribute(text, out text3))
														{
															XmlNodeConverter.smethod_6(manager, text3, text2);
														}
													}
													else
													{
														flag = true;
													}
												}
												else
												{
													text = XmlNodeConverter.smethod_27(text, 1);
													reader.Read();
													string text2 = XmlNodeConverter.smethod_24(reader.Value);
													string text4 = XmlNodeConverter.smethod_9(manager, <Module>.smethod_26<string>(781450428U));
													if (text4 == null)
													{
														int? num = null;
														while (XmlNodeConverter.smethod_28(manager, XmlNodeConverter.smethod_13(<Module>.smethod_23<string>(3478082200U), num)) != null)
														{
															num = new int?(num.GetValueOrDefault() + 1);
														}
														text4 = XmlNodeConverter.smethod_13(<Module>.smethod_25<string>(505499119U), num);
														dictionary.Add(XmlNodeConverter.smethod_12(<Module>.smethod_27<string>(4257788350U), text4), <Module>.smethod_27<string>(3352934380U));
														XmlNodeConverter.smethod_6(manager, text4, <Module>.smethod_27<string>(3352934380U));
													}
													dictionary.Add(XmlNodeConverter.smethod_11(text4, <Module>.smethod_23<string>(3023872610U), text), text2);
												}
											}
											else
											{
												flag = true;
											}
											break;
										}
										case JsonToken.Comment:
											flag2 = true;
											break;
										default:
											if (tokenType != JsonToken.EndObject)
											{
												throw new JsonSerializationException(XmlNodeConverter.smethod_13(<Module>.smethod_25<string>(1271071102U), reader.TokenType));
											}
											flag2 = true;
											break;
										}
									}
								}
							}
						}
					}
				}
			}
			return dictionary;
		}

		// Token: 0x06001EDC RID: 7900 RVA: 0x00083070 File Offset: 0x00081270
		private void CreateInstruction(JsonReader reader, IXmlDocument document, IXmlNode currentNode, string propertyName)
		{
			if (XmlNodeConverter.smethod_4(propertyName, <Module>.smethod_23<string>(3455669162U)))
			{
				string text = null;
				string text2 = null;
				string text3 = null;
				while (reader.Read())
				{
					if (reader.TokenType == JsonToken.EndObject)
					{
						break;
					}
					string text4;
					if ((text4 = XmlNodeConverter.smethod_24(reader.Value)) != null)
					{
						if (XmlNodeConverter.smethod_4(text4, <Module>.smethod_25<string>(651337145U)))
						{
							reader.Read();
							text = XmlNodeConverter.smethod_24(reader.Value);
							continue;
						}
						if (XmlNodeConverter.smethod_4(text4, <Module>.smethod_25<string>(442544786U)))
						{
							reader.Read();
							text2 = XmlNodeConverter.smethod_24(reader.Value);
							continue;
						}
						if (XmlNodeConverter.smethod_4(text4, <Module>.smethod_27<string>(1901890357U)))
						{
							reader.Read();
							text3 = XmlNodeConverter.smethod_24(reader.Value);
							continue;
						}
					}
					throw new JsonSerializationException(XmlNodeConverter.smethod_13(<Module>.smethod_24<string>(1803683745U), reader.Value));
				}
				IXmlNode xmlNode = document.CreateXmlDeclaration(text, text2, text3);
				currentNode.AppendChild(xmlNode);
				return;
			}
			IXmlNode xmlNode2 = document.CreateProcessingInstruction(XmlNodeConverter.smethod_27(propertyName, 1), XmlNodeConverter.smethod_24(reader.Value));
			currentNode.AppendChild(xmlNode2);
		}

		// Token: 0x06001EDD RID: 7901 RVA: 0x00083194 File Offset: 0x00081394
		private void CreateDocumentType(JsonReader reader, IXmlDocument document, IXmlNode currentNode)
		{
			string text = null;
			string text2 = null;
			string text3 = null;
			string text4 = null;
			while (reader.Read() && reader.TokenType != JsonToken.EndObject)
			{
				string text5;
				if ((text5 = XmlNodeConverter.smethod_24(reader.Value)) != null)
				{
					if (XmlNodeConverter.smethod_4(text5, <Module>.smethod_27<string>(2088377129U)))
					{
						reader.Read();
						text = XmlNodeConverter.smethod_24(reader.Value);
						continue;
					}
					if (XmlNodeConverter.smethod_4(text5, <Module>.smethod_23<string>(2290838148U)))
					{
						reader.Read();
						text2 = XmlNodeConverter.smethod_24(reader.Value);
						continue;
					}
					if (XmlNodeConverter.smethod_4(text5, <Module>.smethod_26<string>(1821279641U)))
					{
						reader.Read();
						text3 = XmlNodeConverter.smethod_24(reader.Value);
						continue;
					}
					if (XmlNodeConverter.smethod_4(text5, <Module>.smethod_27<string>(1762025278U)))
					{
						reader.Read();
						text4 = XmlNodeConverter.smethod_24(reader.Value);
						continue;
					}
				}
				throw new JsonSerializationException(XmlNodeConverter.smethod_13(<Module>.smethod_23<string>(1813802932U), reader.Value));
			}
			IXmlNode xmlNode = document.CreateXmlDocumentType(text, text2, text3, text4);
			currentNode.AppendChild(xmlNode);
		}

		// Token: 0x06001EDE RID: 7902 RVA: 0x000832AC File Offset: 0x000814AC
		private IXmlElement CreateElement(string elementName, IXmlDocument document, string elementPrefix, XmlNamespaceManager manager)
		{
			string text = ((!XmlNodeConverter.smethod_10(elementPrefix)) ? XmlNodeConverter.smethod_28(manager, elementPrefix) : XmlNodeConverter.smethod_29(manager));
			return (!XmlNodeConverter.smethod_10(text)) ? document.CreateElement(elementName, text) : document.CreateElement(elementName);
		}

		// Token: 0x06001EDF RID: 7903 RVA: 0x000832F0 File Offset: 0x000814F0
		private void DeserializeNode(JsonReader reader, IXmlDocument document, XmlNamespaceManager manager, IXmlNode currentNode)
		{
			JsonToken tokenType;
			for (;;)
			{
				tokenType = reader.TokenType;
				switch (tokenType)
				{
				case JsonToken.StartConstructor:
				{
					string text = XmlNodeConverter.smethod_24(reader.Value);
					while (reader.Read())
					{
						if (reader.TokenType == JsonToken.EndConstructor)
						{
							break;
						}
						this.DeserializeValue(reader, document, manager, text, currentNode);
					}
					goto IL_0041;
				}
				case JsonToken.PropertyName:
				{
					if (currentNode.NodeType == XmlNodeType.Document)
					{
						if (document.DocumentElement != null)
						{
							goto IL_017C;
						}
					}
					string propertyName = XmlNodeConverter.smethod_24(reader.Value);
					reader.Read();
					if (reader.TokenType != JsonToken.StartArray)
					{
						this.DeserializeValue(reader, document, manager, propertyName, currentNode);
						goto IL_0041;
					}
					int num = 0;
					while (reader.Read() && reader.TokenType != JsonToken.EndArray)
					{
						this.DeserializeValue(reader, document, manager, propertyName, currentNode);
						num++;
					}
					if (num == 1 && this.WriteArrayAttribute)
					{
						IXmlElement xmlElement = currentNode.ChildNodes.OfType<IXmlElement>().Single((IXmlElement n) => XmlNodeConverter.<>c__DisplayClassc.smethod_0(n.LocalName, propertyName));
						this.AddJsonArrayAttribute(xmlElement, document);
						goto IL_0041;
					}
					goto IL_0041;
				}
				case JsonToken.Comment:
					currentNode.AppendChild(document.CreateComment((string)reader.Value));
					goto IL_0041;
				}
				break;
				IL_0041:
				if (reader.TokenType != JsonToken.PropertyName && !reader.Read())
				{
					return;
				}
			}
			switch (tokenType)
			{
			case JsonToken.EndObject:
			case JsonToken.EndArray:
				return;
			default:
				throw new JsonSerializationException(XmlNodeConverter.smethod_13(<Module>.smethod_27<string>(1967553853U), reader.TokenType));
			}
			return;
			IL_017C:
			throw new JsonSerializationException(<Module>.smethod_23<string>(2704955192U));
		}

		// Token: 0x06001EE0 RID: 7904 RVA: 0x0008348C File Offset: 0x0008168C
		private bool IsNamespaceAttribute(string attributeName, out string prefix)
		{
			if (XmlNodeConverter.smethod_32(attributeName, <Module>.smethod_23<string>(2545702777U), StringComparison.Ordinal))
			{
				if (XmlNodeConverter.smethod_33(attributeName) == 5)
				{
					prefix = string.Empty;
					return true;
				}
				if (XmlNodeConverter.smethod_25(attributeName, 5) == ':')
				{
					prefix = XmlNodeConverter.smethod_34(attributeName, 6, XmlNodeConverter.smethod_33(attributeName) - 6);
					return true;
				}
			}
			prefix = null;
			return false;
		}

		// Token: 0x06001EE1 RID: 7905 RVA: 0x0001A3BF File Offset: 0x000185BF
		private IEnumerable<IXmlNode> ValueAttributes(IEnumerable<IXmlNode> c)
		{
			return c.Where((IXmlNode a) => XmlNodeConverter.smethod_5(a.NamespaceUri, <Module>.smethod_24<string>(1571994105U)));
		}

		// Token: 0x06001EE2 RID: 7906 RVA: 0x000834E0 File Offset: 0x000816E0
		public override bool CanConvert(Type valueType)
		{
			if (XmlNodeConverter.smethod_17(XmlNodeConverter.smethod_16(typeof(XObject).TypeHandle), valueType))
			{
				goto IL_0046;
			}
			if (!XmlNodeConverter.smethod_17(XmlNodeConverter.smethod_16(typeof(XmlNode).TypeHandle), valueType))
			{
				return false;
			}
			int num = -1377293065;
			IL_002D:
			switch (num ^ -1377293067)
			{
			case 0:
				IL_0046:
				num = -1377293068;
				goto IL_002D;
			case 1:
				return true;
			}
			return true;
		}

		// Token: 0x06001EE6 RID: 7910 RVA: 0x0001A42B File Offset: 0x0001862B
		static NameTable smethod_0()
		{
			return new NameTable();
		}

		// Token: 0x06001EE7 RID: 7911 RVA: 0x0001A432 File Offset: 0x00018632
		static XmlNamespaceManager smethod_1(XmlNameTable xmlNameTable_0)
		{
			return new XmlNamespaceManager(xmlNameTable_0);
		}

		// Token: 0x06001EE8 RID: 7912 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_2(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}

		// Token: 0x06001EE9 RID: 7913 RVA: 0x0001A43A File Offset: 0x0001863A
		static void smethod_3(XmlNamespaceManager xmlNamespaceManager_0)
		{
			xmlNamespaceManager_0.PushScope();
		}

		// Token: 0x06001EEA RID: 7914 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_4(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06001EEB RID: 7915 RVA: 0x0000CDA1 File Offset: 0x0000AFA1
		static bool smethod_5(string string_0, string string_1)
		{
			return string_0 != string_1;
		}

		// Token: 0x06001EEC RID: 7916 RVA: 0x0001A442 File Offset: 0x00018642
		static void smethod_6(XmlNamespaceManager xmlNamespaceManager_0, string string_0, string string_1)
		{
			xmlNamespaceManager_0.AddNamespace(string_0, string_1);
		}

		// Token: 0x06001EED RID: 7917 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_7(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06001EEE RID: 7918 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_8(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06001EEF RID: 7919 RVA: 0x0001A44C File Offset: 0x0001864C
		static string smethod_9(XmlNamespaceManager xmlNamespaceManager_0, string string_0)
		{
			return xmlNamespaceManager_0.LookupPrefix(string_0);
		}

		// Token: 0x06001EF0 RID: 7920 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_10(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06001EF1 RID: 7921 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_11(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x06001EF2 RID: 7922 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_12(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x06001EF3 RID: 7923 RVA: 0x0000EE96 File Offset: 0x0000D096
		static string smethod_13(object object_0, object object_1)
		{
			return object_0 + object_1;
		}

		// Token: 0x06001EF4 RID: 7924 RVA: 0x0001A455 File Offset: 0x00018655
		static bool smethod_14(string string_0)
		{
			return XmlConvert.ToBoolean(string_0);
		}

		// Token: 0x06001EF5 RID: 7925 RVA: 0x0001A45D File Offset: 0x0001865D
		static bool smethod_15(XmlNamespaceManager xmlNamespaceManager_0)
		{
			return xmlNamespaceManager_0.PopScope();
		}

		// Token: 0x06001EF6 RID: 7926 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_16(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001EF7 RID: 7927 RVA: 0x00017625 File Offset: 0x00015825
		static bool smethod_17(Type type_0, Type type_1)
		{
			return type_0.IsAssignableFrom(type_1);
		}

		// Token: 0x06001EF8 RID: 7928 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_18(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x06001EF9 RID: 7929 RVA: 0x0001A465 File Offset: 0x00018665
		static XDocument smethod_19()
		{
			return new XDocument();
		}

		// Token: 0x06001EFA RID: 7930 RVA: 0x0001A46C File Offset: 0x0001866C
		static XmlDocument smethod_20()
		{
			return new XmlDocument();
		}

		// Token: 0x06001EFB RID: 7931 RVA: 0x0001A473 File Offset: 0x00018673
		static void smethod_21(XmlDocument xmlDocument_0, XmlResolver xmlResolver_0)
		{
			xmlDocument_0.XmlResolver = xmlResolver_0;
		}

		// Token: 0x06001EFC RID: 7932 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_22(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x06001EFD RID: 7933 RVA: 0x0001A47C File Offset: 0x0001867C
		static void smethod_23(XNode xnode_0)
		{
			xnode_0.Remove();
		}

		// Token: 0x06001EFE RID: 7934 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_24(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06001EFF RID: 7935 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_25(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x06001F00 RID: 7936 RVA: 0x000170FF File Offset: 0x000152FF
		static bool smethod_26(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string.Equals(string_0, string_1, stringComparison_0);
		}

		// Token: 0x06001F01 RID: 7937 RVA: 0x0000D416 File Offset: 0x0000B616
		static string smethod_27(string string_0, int int_0)
		{
			return string_0.Substring(int_0);
		}

		// Token: 0x06001F02 RID: 7938 RVA: 0x0001A484 File Offset: 0x00018684
		static string smethod_28(XmlNamespaceManager xmlNamespaceManager_0, string string_0)
		{
			return xmlNamespaceManager_0.LookupNamespace(string_0);
		}

		// Token: 0x06001F03 RID: 7939 RVA: 0x0001A48D File Offset: 0x0001868D
		static string smethod_29(XmlNamespaceManager xmlNamespaceManager_0)
		{
			return xmlNamespaceManager_0.DefaultNamespace;
		}

		// Token: 0x06001F04 RID: 7940 RVA: 0x0001A495 File Offset: 0x00018695
		static void smethod_30(XmlNamespaceManager xmlNamespaceManager_0, string string_0, string string_1)
		{
			xmlNamespaceManager_0.RemoveNamespace(string_0, string_1);
		}

		// Token: 0x06001F05 RID: 7941 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_31()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001F06 RID: 7942 RVA: 0x0000F8C5 File Offset: 0x0000DAC5
		static bool smethod_32(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.StartsWith(string_1, stringComparison_0);
		}

		// Token: 0x06001F07 RID: 7943 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_33(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06001F08 RID: 7944 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_34(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x04000B78 RID: 2936
		private const string TextName = "#text";

		// Token: 0x04000B79 RID: 2937
		private const string CommentName = "#comment";

		// Token: 0x04000B7A RID: 2938
		private const string CDataName = "#cdata-section";

		// Token: 0x04000B7B RID: 2939
		private const string WhitespaceName = "#whitespace";

		// Token: 0x04000B7C RID: 2940
		private const string SignificantWhitespaceName = "#significant-whitespace";

		// Token: 0x04000B7D RID: 2941
		private const string DeclarationName = "?xml";

		// Token: 0x04000B7E RID: 2942
		private const string JsonNamespaceUri = "http://james.newtonking.com/projects/json";
	}
}
