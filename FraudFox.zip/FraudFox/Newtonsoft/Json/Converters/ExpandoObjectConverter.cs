﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x020001AB RID: 427
	public class ExpandoObjectConverter : JsonConverter
	{
		// Token: 0x0600192A RID: 6442 RVA: 0x0000C600 File Offset: 0x0000A800
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
		}

		// Token: 0x0600192B RID: 6443 RVA: 0x00017811 File Offset: 0x00015A11
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			return this.ReadValue(reader);
		}

		// Token: 0x0600192C RID: 6444 RVA: 0x000770B8 File Offset: 0x000752B8
		private object ReadValue(JsonReader reader)
		{
			while (reader.TokenType == JsonToken.Comment)
			{
				if (!reader.Read())
				{
					throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(4208851707U));
				}
			}
			switch (reader.TokenType)
			{
			case JsonToken.StartObject:
				return this.ReadObject(reader);
			case JsonToken.StartArray:
				return this.ReadList(reader);
			default:
				if (JsonTokenUtils.IsPrimitiveToken(reader.TokenType))
				{
					return reader.Value;
				}
				throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(1250817624U).FormatWith(ExpandoObjectConverter.smethod_0(), reader.TokenType));
			}
		}

		// Token: 0x0600192D RID: 6445 RVA: 0x0007714C File Offset: 0x0007534C
		private object ReadList(JsonReader reader)
		{
			IList<object> list = new List<object>();
			while (reader.Read())
			{
				JsonToken tokenType = reader.TokenType;
				if (tokenType != JsonToken.Comment)
				{
					if (tokenType == JsonToken.EndArray)
					{
						return list;
					}
					object obj = this.ReadValue(reader);
					list.Add(obj);
				}
			}
			throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(2630073452U));
		}

		// Token: 0x0600192E RID: 6446 RVA: 0x0007719C File Offset: 0x0007539C
		private object ReadObject(JsonReader reader)
		{
			IDictionary<string, object> dictionary = ExpandoObjectConverter.smethod_1();
			while (reader.Read())
			{
				JsonToken tokenType = reader.TokenType;
				switch (tokenType)
				{
				case JsonToken.PropertyName:
				{
					string text = ExpandoObjectConverter.smethod_2(reader.Value);
					if (!reader.Read())
					{
						throw JsonSerializationException.Create(reader, <Module>.smethod_26<string>(3234588220U));
					}
					object obj = this.ReadValue(reader);
					dictionary[text] = obj;
					break;
				}
				case JsonToken.Comment:
					break;
				default:
					if (tokenType == JsonToken.EndObject)
					{
						return dictionary;
					}
					break;
				}
			}
			throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(2630073452U));
		}

		// Token: 0x0600192F RID: 6447 RVA: 0x0001781A File Offset: 0x00015A1A
		public override bool CanConvert(Type objectType)
		{
			return ExpandoObjectConverter.smethod_4(objectType, ExpandoObjectConverter.smethod_3(typeof(ExpandoObject).TypeHandle));
		}

		// Token: 0x17000397 RID: 919
		// (get) Token: 0x06001930 RID: 6448 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanWrite
		{
			get
			{
				return false;
			}
		}

		// Token: 0x06001932 RID: 6450 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_0()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001933 RID: 6451 RVA: 0x0001782C File Offset: 0x00015A2C
		static ExpandoObject smethod_1()
		{
			return new ExpandoObject();
		}

		// Token: 0x06001934 RID: 6452 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_2(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06001935 RID: 6453 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_3(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001936 RID: 6454 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_4(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}
	}
}
