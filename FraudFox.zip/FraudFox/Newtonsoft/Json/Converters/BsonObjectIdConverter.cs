﻿using System;
using System.Globalization;
using Newtonsoft.Json.Bson;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x020001AD RID: 429
	public class BsonObjectIdConverter : JsonConverter
	{
		// Token: 0x06001947 RID: 6471 RVA: 0x000774C0 File Offset: 0x000756C0
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			BsonObjectId bsonObjectId = (BsonObjectId)value;
			BsonWriter bsonWriter = writer as BsonWriter;
			if (bsonWriter != null)
			{
				bsonWriter.WriteObjectId(bsonObjectId.Value);
				return;
			}
			writer.WriteValue(bsonObjectId.Value);
		}

		// Token: 0x06001948 RID: 6472 RVA: 0x000774F8 File Offset: 0x000756F8
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			if (reader.TokenType != JsonToken.Bytes)
			{
				throw new JsonSerializationException(<Module>.smethod_24<string>(1856530531U).FormatWith(BsonObjectIdConverter.smethod_0(), reader.TokenType));
			}
			byte[] array = (byte[])reader.Value;
			return new BsonObjectId(array);
		}

		// Token: 0x06001949 RID: 6473 RVA: 0x00017866 File Offset: 0x00015A66
		public override bool CanConvert(Type objectType)
		{
			return BsonObjectIdConverter.smethod_2(objectType, BsonObjectIdConverter.smethod_1(typeof(BsonObjectId).TypeHandle));
		}

		// Token: 0x0600194B RID: 6475 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_0()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x0600194C RID: 6476 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_1(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x0600194D RID: 6477 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_2(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}
	}
}
