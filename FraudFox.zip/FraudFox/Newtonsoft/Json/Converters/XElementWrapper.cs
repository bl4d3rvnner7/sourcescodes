﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x02000221 RID: 545
	internal class XElementWrapper : XContainerWrapper, IXmlNode, IXmlElement
	{
		// Token: 0x17000492 RID: 1170
		// (get) Token: 0x06001EB2 RID: 7858 RVA: 0x0001A2A5 File Offset: 0x000184A5
		private XElement Element
		{
			get
			{
				return (XElement)base.WrappedNode;
			}
		}

		// Token: 0x06001EB3 RID: 7859 RVA: 0x00019FF8 File Offset: 0x000181F8
		public XElementWrapper(XElement element)
			: base(element)
		{
		}

		// Token: 0x06001EB4 RID: 7860 RVA: 0x00081D18 File Offset: 0x0007FF18
		public void SetAttributeNode(IXmlNode attribute)
		{
			XObjectWrapper xobjectWrapper = (XObjectWrapper)attribute;
			XElementWrapper.smethod_5(this.Element, xobjectWrapper.WrappedNode);
		}

		// Token: 0x17000493 RID: 1171
		// (get) Token: 0x06001EB5 RID: 7861 RVA: 0x0001A2B2 File Offset: 0x000184B2
		public override IList<IXmlNode> Attributes
		{
			get
			{
				return (from a in XElementWrapper.smethod_6(this.Element)
					select new XAttributeWrapper(a)).Cast<IXmlNode>().ToList<IXmlNode>();
			}
		}

		// Token: 0x17000494 RID: 1172
		// (get) Token: 0x06001EB6 RID: 7862 RVA: 0x0001A2EB File Offset: 0x000184EB
		// (set) Token: 0x06001EB7 RID: 7863 RVA: 0x0001A2F8 File Offset: 0x000184F8
		public override string Value
		{
			get
			{
				return XElementWrapper.smethod_7(this.Element);
			}
			set
			{
				XElementWrapper.smethod_8(this.Element, value);
			}
		}

		// Token: 0x17000495 RID: 1173
		// (get) Token: 0x06001EB8 RID: 7864 RVA: 0x0001A306 File Offset: 0x00018506
		public override string LocalName
		{
			get
			{
				return XElementWrapper.smethod_10(XElementWrapper.smethod_9(this.Element));
			}
		}

		// Token: 0x17000496 RID: 1174
		// (get) Token: 0x06001EB9 RID: 7865 RVA: 0x0001A318 File Offset: 0x00018518
		public override string NamespaceUri
		{
			get
			{
				return XElementWrapper.smethod_11(XElementWrapper.smethod_9(this.Element));
			}
		}

		// Token: 0x06001EBA RID: 7866 RVA: 0x0001A32A File Offset: 0x0001852A
		public string GetPrefixOfNamespace(string namespaceUri)
		{
			return XElementWrapper.smethod_13(this.Element, XElementWrapper.smethod_12(namespaceUri));
		}

		// Token: 0x17000497 RID: 1175
		// (get) Token: 0x06001EBB RID: 7867 RVA: 0x0001A33D File Offset: 0x0001853D
		public bool IsEmpty
		{
			get
			{
				return XElementWrapper.smethod_14(this.Element);
			}
		}

		// Token: 0x06001EBD RID: 7869 RVA: 0x00019FE2 File Offset: 0x000181E2
		static void smethod_5(XContainer xcontainer_0, object object_0)
		{
			xcontainer_0.Add(object_0);
		}

		// Token: 0x06001EBE RID: 7870 RVA: 0x0001A352 File Offset: 0x00018552
		static IEnumerable<XAttribute> smethod_6(XElement xelement_0)
		{
			return xelement_0.Attributes();
		}

		// Token: 0x06001EBF RID: 7871 RVA: 0x0001A35A File Offset: 0x0001855A
		static string smethod_7(XElement xelement_0)
		{
			return xelement_0.Value;
		}

		// Token: 0x06001EC0 RID: 7872 RVA: 0x0001A362 File Offset: 0x00018562
		static void smethod_8(XElement xelement_0, string string_0)
		{
			xelement_0.Value = string_0;
		}

		// Token: 0x06001EC1 RID: 7873 RVA: 0x0001A36B File Offset: 0x0001856B
		static XName smethod_9(XElement xelement_0)
		{
			return xelement_0.Name;
		}

		// Token: 0x06001EC2 RID: 7874 RVA: 0x0001A295 File Offset: 0x00018495
		static string smethod_10(XName xname_0)
		{
			return xname_0.LocalName;
		}

		// Token: 0x06001EC3 RID: 7875 RVA: 0x0001A29D File Offset: 0x0001849D
		static string smethod_11(XName xname_0)
		{
			return xname_0.NamespaceName;
		}

		// Token: 0x06001EC4 RID: 7876 RVA: 0x0001A373 File Offset: 0x00018573
		static XNamespace smethod_12(string string_0)
		{
			return string_0;
		}

		// Token: 0x06001EC5 RID: 7877 RVA: 0x0001A37B File Offset: 0x0001857B
		static string smethod_13(XElement xelement_0, XNamespace xnamespace_0)
		{
			return xelement_0.GetPrefixOfNamespace(xnamespace_0);
		}

		// Token: 0x06001EC6 RID: 7878 RVA: 0x0001A384 File Offset: 0x00018584
		static bool smethod_14(XElement xelement_0)
		{
			return xelement_0.IsEmpty;
		}
	}
}
