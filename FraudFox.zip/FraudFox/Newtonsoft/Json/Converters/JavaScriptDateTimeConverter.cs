﻿using System;
using System.Globalization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x0200020D RID: 525
	public class JavaScriptDateTimeConverter : DateTimeConverterBase
	{
		// Token: 0x06001DC8 RID: 7624 RVA: 0x00081884 File Offset: 0x0007FA84
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			long num;
			if (value is DateTime)
			{
				DateTime dateTime = ((DateTime)value).ToUniversalTime();
				num = DateTimeUtils.ConvertDateTimeToJavaScriptTicks(dateTime);
			}
			else
			{
				if (!(value is DateTimeOffset))
				{
					throw new JsonSerializationException(<Module>.smethod_25<string>(3872894773U));
				}
				num = DateTimeUtils.ConvertDateTimeToJavaScriptTicks(((DateTimeOffset)value).ToUniversalTime().UtcDateTime);
			}
			writer.WriteStartConstructor(<Module>.smethod_23<string>(2473942043U));
			writer.WriteValue(num);
			writer.WriteEndConstructor();
		}

		// Token: 0x06001DC9 RID: 7625 RVA: 0x00081904 File Offset: 0x0007FB04
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			Type type = (ReflectionUtils.IsNullableType(objectType) ? JavaScriptDateTimeConverter.smethod_2(objectType) : objectType);
			if (reader.TokenType != JsonToken.Null)
			{
				if (reader.TokenType == JsonToken.StartConstructor)
				{
					if (JavaScriptDateTimeConverter.smethod_5(JavaScriptDateTimeConverter.smethod_4(reader.Value), <Module>.smethod_23<string>(2473942043U), StringComparison.Ordinal))
					{
						reader.Read();
						if (reader.TokenType != JsonToken.Integer)
						{
							throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(3493297412U).FormatWith(JavaScriptDateTimeConverter.smethod_3(), reader.TokenType));
						}
						long num = (long)reader.Value;
						DateTime dateTime = DateTimeUtils.ConvertJavaScriptTicksToDateTime(num);
						reader.Read();
						if (reader.TokenType != JsonToken.EndConstructor)
						{
							throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(3336189939U).FormatWith(JavaScriptDateTimeConverter.smethod_3(), reader.TokenType));
						}
						if (JavaScriptDateTimeConverter.smethod_7(type, JavaScriptDateTimeConverter.smethod_6(typeof(DateTimeOffset).TypeHandle)))
						{
							return new DateTimeOffset(dateTime);
						}
						return dateTime;
					}
				}
				throw JsonSerializationException.Create(reader, <Module>.smethod_26<string>(3724565242U).FormatWith(JavaScriptDateTimeConverter.smethod_3(), reader.TokenType, reader.Value));
			}
			if (!ReflectionUtils.IsNullable(objectType))
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_26<string>(2912988557U).FormatWith(JavaScriptDateTimeConverter.smethod_3(), objectType));
			}
			return null;
		}

		// Token: 0x06001DCB RID: 7627 RVA: 0x000175B6 File Offset: 0x000157B6
		static Type smethod_2(Type type_0)
		{
			return Nullable.GetUnderlyingType(type_0);
		}

		// Token: 0x06001DCC RID: 7628 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_3()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001DCD RID: 7629 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_4(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06001DCE RID: 7630 RVA: 0x000170FF File Offset: 0x000152FF
		static bool smethod_5(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string.Equals(string_0, string_1, stringComparison_0);
		}

		// Token: 0x06001DCF RID: 7631 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_6(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001DD0 RID: 7632 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_7(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}
	}
}
