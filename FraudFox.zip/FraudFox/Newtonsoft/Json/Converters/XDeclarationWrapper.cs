﻿using System;
using System.Xml;
using System.Xml.Linq;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x02000219 RID: 537
	internal class XDeclarationWrapper : XObjectWrapper, IXmlNode, IXmlDeclaration
	{
		// Token: 0x17000474 RID: 1140
		// (get) Token: 0x06001E4E RID: 7758 RVA: 0x00019E47 File Offset: 0x00018047
		// (set) Token: 0x06001E4F RID: 7759 RVA: 0x00019E4F File Offset: 0x0001804F
		internal XDeclaration Declaration { get; private set; }

		// Token: 0x06001E50 RID: 7760 RVA: 0x00019E58 File Offset: 0x00018058
		public XDeclarationWrapper(XDeclaration declaration)
			: base(null)
		{
			this.Declaration = declaration;
		}

		// Token: 0x17000475 RID: 1141
		// (get) Token: 0x06001E51 RID: 7761 RVA: 0x00019E68 File Offset: 0x00018068
		public override XmlNodeType NodeType
		{
			get
			{
				return XmlNodeType.XmlDeclaration;
			}
		}

		// Token: 0x17000476 RID: 1142
		// (get) Token: 0x06001E52 RID: 7762 RVA: 0x00019E6C File Offset: 0x0001806C
		public string Version
		{
			get
			{
				return XDeclarationWrapper.smethod_2(this.Declaration);
			}
		}

		// Token: 0x17000477 RID: 1143
		// (get) Token: 0x06001E53 RID: 7763 RVA: 0x00019E79 File Offset: 0x00018079
		// (set) Token: 0x06001E54 RID: 7764 RVA: 0x00019E86 File Offset: 0x00018086
		public string Encoding
		{
			get
			{
				return XDeclarationWrapper.smethod_3(this.Declaration);
			}
			set
			{
				XDeclarationWrapper.smethod_4(this.Declaration, value);
			}
		}

		// Token: 0x17000478 RID: 1144
		// (get) Token: 0x06001E55 RID: 7765 RVA: 0x00019E94 File Offset: 0x00018094
		// (set) Token: 0x06001E56 RID: 7766 RVA: 0x00019EA1 File Offset: 0x000180A1
		public string Standalone
		{
			get
			{
				return XDeclarationWrapper.smethod_5(this.Declaration);
			}
			set
			{
				XDeclarationWrapper.smethod_6(this.Declaration, value);
			}
		}

		// Token: 0x06001E57 RID: 7767 RVA: 0x00019EAF File Offset: 0x000180AF
		static string smethod_2(XDeclaration xdeclaration_0)
		{
			return xdeclaration_0.Version;
		}

		// Token: 0x06001E58 RID: 7768 RVA: 0x00019EB7 File Offset: 0x000180B7
		static string smethod_3(XDeclaration xdeclaration_0)
		{
			return xdeclaration_0.Encoding;
		}

		// Token: 0x06001E59 RID: 7769 RVA: 0x00019EBF File Offset: 0x000180BF
		static void smethod_4(XDeclaration xdeclaration_0, string string_0)
		{
			xdeclaration_0.Encoding = string_0;
		}

		// Token: 0x06001E5A RID: 7770 RVA: 0x00019EC8 File Offset: 0x000180C8
		static string smethod_5(XDeclaration xdeclaration_0)
		{
			return xdeclaration_0.Standalone;
		}

		// Token: 0x06001E5B RID: 7771 RVA: 0x00019ED0 File Offset: 0x000180D0
		static void smethod_6(XDeclaration xdeclaration_0, string string_0)
		{
			xdeclaration_0.Standalone = string_0;
		}
	}
}
