﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x0200021B RID: 539
	internal class XContainerWrapper : XObjectWrapper
	{
		// Token: 0x1700047E RID: 1150
		// (get) Token: 0x06001E66 RID: 7782 RVA: 0x00019F49 File Offset: 0x00018149
		private XContainer Container
		{
			get
			{
				return (XContainer)base.WrappedNode;
			}
		}

		// Token: 0x06001E67 RID: 7783 RVA: 0x00019F56 File Offset: 0x00018156
		public XContainerWrapper(XContainer container)
			: base(container)
		{
		}

		// Token: 0x1700047F RID: 1151
		// (get) Token: 0x06001E68 RID: 7784 RVA: 0x00019F5F File Offset: 0x0001815F
		public override IList<IXmlNode> ChildNodes
		{
			get
			{
				if (this._childNodes == null)
				{
					this._childNodes = XContainerWrapper.smethod_2(this.Container).Select(new Func<XNode, IXmlNode>(XContainerWrapper.WrapNode)).ToList<IXmlNode>();
				}
				return this._childNodes;
			}
		}

		// Token: 0x17000480 RID: 1152
		// (get) Token: 0x06001E69 RID: 7785 RVA: 0x00019F96 File Offset: 0x00018196
		public override IXmlNode ParentNode
		{
			get
			{
				if (XContainerWrapper.smethod_3(this.Container) == null)
				{
					return null;
				}
				return XContainerWrapper.WrapNode(XContainerWrapper.smethod_3(this.Container));
			}
		}

		// Token: 0x06001E6A RID: 7786 RVA: 0x00081B90 File Offset: 0x0007FD90
		internal static IXmlNode WrapNode(XObject node)
		{
			if (node is XDocument)
			{
				return new XDocumentWrapper((XDocument)node);
			}
			if (node is XElement)
			{
				return new XElementWrapper((XElement)node);
			}
			if (node is XContainer)
			{
				return new XContainerWrapper((XContainer)node);
			}
			if (node is XProcessingInstruction)
			{
				return new XProcessingInstructionWrapper((XProcessingInstruction)node);
			}
			if (node is XText)
			{
				return new XTextWrapper((XText)node);
			}
			if (node is XComment)
			{
				return new XCommentWrapper((XComment)node);
			}
			if (node is XAttribute)
			{
				return new XAttributeWrapper((XAttribute)node);
			}
			if (node is XDocumentType)
			{
				return new XDocumentTypeWrapper((XDocumentType)node);
			}
			return new XObjectWrapper(node);
		}

		// Token: 0x06001E6B RID: 7787 RVA: 0x00019FB7 File Offset: 0x000181B7
		public override IXmlNode AppendChild(IXmlNode newChild)
		{
			XContainerWrapper.smethod_4(this.Container, newChild.WrappedNode);
			this._childNodes = null;
			return newChild;
		}

		// Token: 0x06001E6C RID: 7788 RVA: 0x00019FD2 File Offset: 0x000181D2
		static IEnumerable<XNode> smethod_2(XContainer xcontainer_0)
		{
			return xcontainer_0.Nodes();
		}

		// Token: 0x06001E6D RID: 7789 RVA: 0x00019FDA File Offset: 0x000181DA
		static XElement smethod_3(XObject xobject_0)
		{
			return xobject_0.Parent;
		}

		// Token: 0x06001E6E RID: 7790 RVA: 0x00019FE2 File Offset: 0x000181E2
		static void smethod_4(XContainer xcontainer_0, object object_0)
		{
			xcontainer_0.Add(object_0);
		}

		// Token: 0x04000B76 RID: 2934
		private IList<IXmlNode> _childNodes;
	}
}
