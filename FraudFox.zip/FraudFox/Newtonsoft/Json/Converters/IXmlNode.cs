﻿using System;
using System.Collections.Generic;
using System.Xml;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x0200020E RID: 526
	internal interface IXmlNode
	{
		// Token: 0x17000449 RID: 1097
		// (get) Token: 0x06001DD1 RID: 7633
		XmlNodeType NodeType { get; }

		// Token: 0x1700044A RID: 1098
		// (get) Token: 0x06001DD2 RID: 7634
		string LocalName { get; }

		// Token: 0x1700044B RID: 1099
		// (get) Token: 0x06001DD3 RID: 7635
		IList<IXmlNode> ChildNodes { get; }

		// Token: 0x1700044C RID: 1100
		// (get) Token: 0x06001DD4 RID: 7636
		IList<IXmlNode> Attributes { get; }

		// Token: 0x1700044D RID: 1101
		// (get) Token: 0x06001DD5 RID: 7637
		IXmlNode ParentNode { get; }

		// Token: 0x1700044E RID: 1102
		// (get) Token: 0x06001DD6 RID: 7638
		// (set) Token: 0x06001DD7 RID: 7639
		string Value { get; set; }

		// Token: 0x06001DD8 RID: 7640
		IXmlNode AppendChild(IXmlNode newChild);

		// Token: 0x1700044F RID: 1103
		// (get) Token: 0x06001DD9 RID: 7641
		string NamespaceUri { get; }

		// Token: 0x17000450 RID: 1104
		// (get) Token: 0x06001DDA RID: 7642
		object WrappedNode { get; }
	}
}
