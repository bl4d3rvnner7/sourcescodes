﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Globalization;
using System.Reflection;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x020001A0 RID: 416
	public class BinaryConverter : JsonConverter
	{
		// Token: 0x060018B0 RID: 6320 RVA: 0x00075D70 File Offset: 0x00073F70
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			if (value == null)
			{
				writer.WriteNull();
				return;
			}
			byte[] byteArray = this.GetByteArray(value);
			writer.WriteValue(byteArray);
		}

		// Token: 0x060018B1 RID: 6321 RVA: 0x00075D98 File Offset: 0x00073F98
		private byte[] GetByteArray(object value)
		{
			if (BinaryConverter.smethod_0(value).AssignableToTypeName(<Module>.smethod_25<string>(2618811995U)))
			{
				this.EnsureReflectionObject(BinaryConverter.smethod_0(value));
				return (byte[])this._reflectionObject.GetValue(value, <Module>.smethod_27<string>(357153575U));
			}
			if (!(value is SqlBinary))
			{
				throw new JsonSerializationException(<Module>.smethod_26<string>(2170027558U).FormatWith(CultureInfo.InvariantCulture, value.GetType()));
			}
			return ((SqlBinary)value).Value;
		}

		// Token: 0x060018B2 RID: 6322 RVA: 0x00075E1C File Offset: 0x0007401C
		private void EnsureReflectionObject(Type t)
		{
			if (this._reflectionObject == null)
			{
				this._reflectionObject = ReflectionObject.Create(t, BinaryConverter.smethod_2(t, new Type[] { BinaryConverter.smethod_1(typeof(byte[]).TypeHandle) }), new string[] { <Module>.smethod_26<string>(1455795741U) });
			}
		}

		// Token: 0x060018B3 RID: 6323 RVA: 0x00075E78 File Offset: 0x00074078
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			Type type = (ReflectionUtils.IsNullableType(objectType) ? BinaryConverter.smethod_3(objectType) : objectType);
			if (reader.TokenType == JsonToken.Null)
			{
				if (!ReflectionUtils.IsNullable(objectType))
				{
					throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(2810745263U).FormatWith(BinaryConverter.smethod_4(), objectType));
				}
				return null;
			}
			else
			{
				byte[] array;
				if (reader.TokenType == JsonToken.StartArray)
				{
					array = this.ReadByteArray(reader);
				}
				else
				{
					if (reader.TokenType != JsonToken.String)
					{
						throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(842362928U).FormatWith(BinaryConverter.smethod_4(), reader.TokenType));
					}
					string text = BinaryConverter.smethod_5(reader.Value);
					array = BinaryConverter.smethod_6(text);
				}
				if (type.AssignableToTypeName(<Module>.smethod_27<string>(776748812U)))
				{
					this.EnsureReflectionObject(type);
					return this._reflectionObject.Creator(new object[] { array });
				}
				if (!BinaryConverter.smethod_7(type, BinaryConverter.smethod_1(typeof(SqlBinary).TypeHandle)))
				{
					throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(3334148144U).FormatWith(CultureInfo.InvariantCulture, objectType));
				}
				return new SqlBinary(array);
			}
		}

		// Token: 0x060018B4 RID: 6324 RVA: 0x00075F8C File Offset: 0x0007418C
		private byte[] ReadByteArray(JsonReader reader)
		{
			List<byte> list = new List<byte>();
			while (reader.Read())
			{
				JsonToken tokenType = reader.TokenType;
				switch (tokenType)
				{
				case JsonToken.Comment:
					continue;
				case JsonToken.Raw:
					break;
				case JsonToken.Integer:
					list.Add(BinaryConverter.smethod_8(reader.Value, BinaryConverter.smethod_4()));
					continue;
				default:
					if (tokenType == JsonToken.EndArray)
					{
						return list.ToArray();
					}
					break;
				}
				throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(2679143888U).FormatWith(BinaryConverter.smethod_4(), reader.TokenType));
			}
			throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(2892993295U));
		}

		// Token: 0x060018B5 RID: 6325 RVA: 0x00017568 File Offset: 0x00015768
		public override bool CanConvert(Type objectType)
		{
			return objectType.AssignableToTypeName(<Module>.smethod_23<string>(1669868876U)) || BinaryConverter.smethod_7(objectType, BinaryConverter.smethod_1(typeof(SqlBinary).TypeHandle)) || BinaryConverter.smethod_7(objectType, BinaryConverter.smethod_1(typeof(SqlBinary?).TypeHandle));
		}

		// Token: 0x060018B7 RID: 6327 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_0(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x060018B8 RID: 6328 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_1(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060018B9 RID: 6329 RVA: 0x000175AD File Offset: 0x000157AD
		static ConstructorInfo smethod_2(Type type_0, Type[] type_1)
		{
			return type_0.GetConstructor(type_1);
		}

		// Token: 0x060018BA RID: 6330 RVA: 0x000175B6 File Offset: 0x000157B6
		static Type smethod_3(Type type_0)
		{
			return Nullable.GetUnderlyingType(type_0);
		}

		// Token: 0x060018BB RID: 6331 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_4()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060018BC RID: 6332 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_5(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x060018BD RID: 6333 RVA: 0x0000C86F File Offset: 0x0000AA6F
		static byte[] smethod_6(string string_0)
		{
			return Convert.FromBase64String(string_0);
		}

		// Token: 0x060018BE RID: 6334 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_7(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x060018BF RID: 6335 RVA: 0x000175BE File Offset: 0x000157BE
		static byte smethod_8(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToByte(object_0, iformatProvider_0);
		}

		// Token: 0x0400099F RID: 2463
		private const string BinaryTypeName = "System.Data.Linq.Binary";

		// Token: 0x040009A0 RID: 2464
		private const string BinaryToArrayName = "ToArray";

		// Token: 0x040009A1 RID: 2465
		private ReflectionObject _reflectionObject;
	}
}
