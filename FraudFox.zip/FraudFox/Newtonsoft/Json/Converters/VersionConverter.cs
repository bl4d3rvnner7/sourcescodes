﻿using System;
using System.Globalization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x020001B1 RID: 433
	public class VersionConverter : JsonConverter
	{
		// Token: 0x06001971 RID: 6513 RVA: 0x0001790D File Offset: 0x00015B0D
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			if (value == null)
			{
				writer.WriteNull();
				return;
			}
			if (!(value is Version))
			{
				throw new JsonSerializationException(<Module>.smethod_26<string>(2116566927U));
			}
			writer.WriteValue(VersionConverter.smethod_0(value));
		}

		// Token: 0x06001972 RID: 6514 RVA: 0x00077A14 File Offset: 0x00075C14
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			if (reader.TokenType == JsonToken.Null)
			{
				return null;
			}
			if (reader.TokenType == JsonToken.String)
			{
				try
				{
					return VersionConverter.smethod_1((string)reader.Value);
				}
				catch (Exception ex)
				{
					throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(569709361U).FormatWith(VersionConverter.smethod_2(), reader.Value), ex);
				}
			}
			throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(2874275624U).FormatWith(VersionConverter.smethod_2(), reader.TokenType, reader.Value));
		}

		// Token: 0x06001973 RID: 6515 RVA: 0x0001793D File Offset: 0x00015B3D
		public override bool CanConvert(Type objectType)
		{
			return VersionConverter.smethod_4(objectType, VersionConverter.smethod_3(typeof(Version).TypeHandle));
		}

		// Token: 0x06001975 RID: 6517 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_0(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06001976 RID: 6518 RVA: 0x0001794F File Offset: 0x00015B4F
		static Version smethod_1(string string_0)
		{
			return new Version(string_0);
		}

		// Token: 0x06001977 RID: 6519 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_2()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001978 RID: 6520 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_3(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001979 RID: 6521 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_4(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}
	}
}
