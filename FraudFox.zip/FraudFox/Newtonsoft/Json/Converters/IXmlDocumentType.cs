﻿using System;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x02000216 RID: 534
	internal interface IXmlDocumentType : IXmlNode
	{
		// Token: 0x17000463 RID: 1123
		// (get) Token: 0x06001E33 RID: 7731
		string Name { get; }

		// Token: 0x17000464 RID: 1124
		// (get) Token: 0x06001E34 RID: 7732
		string System { get; }

		// Token: 0x17000465 RID: 1125
		// (get) Token: 0x06001E35 RID: 7733
		string Public { get; }

		// Token: 0x17000466 RID: 1126
		// (get) Token: 0x06001E36 RID: 7734
		string InternalSubset { get; }
	}
}
