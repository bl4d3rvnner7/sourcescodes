﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Linq;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x02000218 RID: 536
	internal class XObjectWrapper : IXmlNode
	{
		// Token: 0x06001E41 RID: 7745 RVA: 0x00019E0D File Offset: 0x0001800D
		public XObjectWrapper(XObject xmlObject)
		{
			this._xmlObject = xmlObject;
		}

		// Token: 0x1700046C RID: 1132
		// (get) Token: 0x06001E42 RID: 7746 RVA: 0x00019E1C File Offset: 0x0001801C
		public object WrappedNode
		{
			get
			{
				return this._xmlObject;
			}
		}

		// Token: 0x1700046D RID: 1133
		// (get) Token: 0x06001E43 RID: 7747 RVA: 0x00019E24 File Offset: 0x00018024
		public virtual XmlNodeType NodeType
		{
			get
			{
				return XObjectWrapper.smethod_0(this._xmlObject);
			}
		}

		// Token: 0x1700046E RID: 1134
		// (get) Token: 0x06001E44 RID: 7748 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		public virtual string LocalName
		{
			get
			{
				return null;
			}
		}

		// Token: 0x1700046F RID: 1135
		// (get) Token: 0x06001E45 RID: 7749 RVA: 0x00019E31 File Offset: 0x00018031
		public virtual IList<IXmlNode> ChildNodes
		{
			get
			{
				return new List<IXmlNode>();
			}
		}

		// Token: 0x17000470 RID: 1136
		// (get) Token: 0x06001E46 RID: 7750 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		public virtual IList<IXmlNode> Attributes
		{
			get
			{
				return null;
			}
		}

		// Token: 0x17000471 RID: 1137
		// (get) Token: 0x06001E47 RID: 7751 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		public virtual IXmlNode ParentNode
		{
			get
			{
				return null;
			}
		}

		// Token: 0x17000472 RID: 1138
		// (get) Token: 0x06001E48 RID: 7752 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		// (set) Token: 0x06001E49 RID: 7753 RVA: 0x00019E38 File Offset: 0x00018038
		public virtual string Value
		{
			get
			{
				return null;
			}
			set
			{
				throw XObjectWrapper.smethod_1();
			}
		}

		// Token: 0x06001E4A RID: 7754 RVA: 0x00019E38 File Offset: 0x00018038
		public virtual IXmlNode AppendChild(IXmlNode newChild)
		{
			throw XObjectWrapper.smethod_1();
		}

		// Token: 0x17000473 RID: 1139
		// (get) Token: 0x06001E4B RID: 7755 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		public virtual string NamespaceUri
		{
			get
			{
				return null;
			}
		}

		// Token: 0x06001E4C RID: 7756 RVA: 0x00019E3F File Offset: 0x0001803F
		static XmlNodeType smethod_0(XObject xobject_0)
		{
			return xobject_0.NodeType;
		}

		// Token: 0x06001E4D RID: 7757 RVA: 0x0000C331 File Offset: 0x0000A531
		static InvalidOperationException smethod_1()
		{
			return new InvalidOperationException();
		}

		// Token: 0x04000B73 RID: 2931
		private readonly XObject _xmlObject;
	}
}
