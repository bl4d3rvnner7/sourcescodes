﻿using System;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Bson;
using Newtonsoft.Json.Serialization;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x020001AE RID: 430
	public class RegexConverter : JsonConverter
	{
		// Token: 0x0600194E RID: 6478 RVA: 0x00077548 File Offset: 0x00075748
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			Regex regex = (Regex)value;
			BsonWriter bsonWriter = writer as BsonWriter;
			if (bsonWriter != null)
			{
				this.WriteBson(bsonWriter, regex);
				return;
			}
			this.WriteJson(writer, regex, serializer);
		}

		// Token: 0x0600194F RID: 6479 RVA: 0x00017878 File Offset: 0x00015A78
		private bool HasFlag(RegexOptions options, RegexOptions flag)
		{
			return (options & flag) == flag;
		}

		// Token: 0x06001950 RID: 6480 RVA: 0x00077578 File Offset: 0x00075778
		private void WriteBson(BsonWriter writer, Regex regex)
		{
			string text = null;
			if (this.HasFlag(RegexConverter.smethod_0(regex), RegexOptions.IgnoreCase))
			{
				text = RegexConverter.smethod_1(text, <Module>.smethod_27<string>(1102651290U));
			}
			if (this.HasFlag(RegexConverter.smethod_0(regex), RegexOptions.Multiline))
			{
				text = RegexConverter.smethod_1(text, <Module>.smethod_25<string>(3214412575U));
			}
			if (this.HasFlag(RegexConverter.smethod_0(regex), RegexOptions.Singleline))
			{
				text = RegexConverter.smethod_1(text, <Module>.smethod_27<string>(1759848722U));
			}
			text = RegexConverter.smethod_1(text, <Module>.smethod_25<string>(3075217669U));
			if (this.HasFlag(RegexConverter.smethod_0(regex), RegexOptions.ExplicitCapture))
			{
				text = RegexConverter.smethod_1(text, <Module>.smethod_23<string>(4160324908U));
			}
			writer.WriteRegex(RegexConverter.smethod_2(regex), text);
		}

		// Token: 0x06001951 RID: 6481 RVA: 0x00077628 File Offset: 0x00075828
		private void WriteJson(JsonWriter writer, Regex regex, JsonSerializer serializer)
		{
			DefaultContractResolver defaultContractResolver = serializer.ContractResolver as DefaultContractResolver;
			writer.WriteStartObject();
			writer.WritePropertyName((defaultContractResolver != null) ? defaultContractResolver.GetResolvedPropertyName(<Module>.smethod_23<string>(987419874U)) : <Module>.smethod_24<string>(3942788147U));
			writer.WriteValue(RegexConverter.smethod_2(regex));
			writer.WritePropertyName((defaultContractResolver != null) ? defaultContractResolver.GetResolvedPropertyName(<Module>.smethod_27<string>(869542825U)) : <Module>.smethod_25<string>(3701594746U));
			serializer.Serialize(writer, RegexConverter.smethod_0(regex));
			writer.WriteEndObject();
		}

		// Token: 0x06001952 RID: 6482 RVA: 0x00017880 File Offset: 0x00015A80
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			if (reader.TokenType == JsonToken.StartObject)
			{
				return this.ReadRegexObject(reader, serializer);
			}
			if (reader.TokenType == JsonToken.String)
			{
				return this.ReadRegexString(reader);
			}
			throw JsonSerializationException.Create(reader, <Module>.smethod_26<string>(1507675444U));
		}

		// Token: 0x06001953 RID: 6483 RVA: 0x000776B8 File Offset: 0x000758B8
		private object ReadRegexString(JsonReader reader)
		{
			string text = (string)reader.Value;
			int num = RegexConverter.smethod_3(text, '/');
			string text2 = RegexConverter.smethod_4(text, 1, num - 1);
			string text3 = RegexConverter.smethod_5(text, num + 1);
			RegexOptions regexOptions = RegexOptions.None;
			string text4 = text3;
			for (int i = 0; i < RegexConverter.smethod_7(text4); i++)
			{
				char c = RegexConverter.smethod_6(text4, i);
				char c2 = c;
				if (c2 > 'm')
				{
					if (c2 != 's')
					{
						if (c2 == 'x')
						{
							regexOptions |= RegexOptions.ExplicitCapture;
						}
					}
					else
					{
						regexOptions |= RegexOptions.Singleline;
					}
				}
				else if (c2 != 'i')
				{
					if (c2 == 'm')
					{
						regexOptions |= RegexOptions.Multiline;
					}
				}
				else
				{
					regexOptions |= RegexOptions.IgnoreCase;
				}
			}
			return RegexConverter.smethod_8(text2, regexOptions);
		}

		// Token: 0x06001954 RID: 6484 RVA: 0x00077764 File Offset: 0x00075964
		private Regex ReadRegexObject(JsonReader reader, JsonSerializer serializer)
		{
			string text = null;
			RegexOptions? regexOptions = null;
			while (reader.Read())
			{
				JsonToken tokenType = reader.TokenType;
				switch (tokenType)
				{
				case JsonToken.PropertyName:
				{
					string text2 = RegexConverter.smethod_2(reader.Value);
					if (!reader.Read())
					{
						throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(4278697954U));
					}
					if (RegexConverter.smethod_9(text2, <Module>.smethod_25<string>(3910387105U), StringComparison.OrdinalIgnoreCase))
					{
						text = (string)reader.Value;
					}
					else if (RegexConverter.smethod_9(text2, <Module>.smethod_23<string>(3599293777U), StringComparison.OrdinalIgnoreCase))
					{
						regexOptions = new RegexOptions?(serializer.Deserialize<RegexOptions>(reader));
					}
					else
					{
						reader.Skip();
					}
					break;
				}
				case JsonToken.Comment:
					break;
				default:
					if (tokenType == JsonToken.EndObject)
					{
						if (text == null)
						{
							throw JsonSerializationException.Create(reader, <Module>.smethod_26<string>(107940992U));
						}
						return RegexConverter.smethod_8(text, regexOptions ?? RegexOptions.None);
					}
					break;
				}
			}
			throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(1734078467U));
		}

		// Token: 0x06001955 RID: 6485 RVA: 0x000178B9 File Offset: 0x00015AB9
		public override bool CanConvert(Type objectType)
		{
			return RegexConverter.smethod_11(objectType, RegexConverter.smethod_10(typeof(Regex).TypeHandle));
		}

		// Token: 0x06001957 RID: 6487 RVA: 0x000178CB File Offset: 0x00015ACB
		static RegexOptions smethod_0(Regex regex_0)
		{
			return regex_0.Options;
		}

		// Token: 0x06001958 RID: 6488 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_1(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x06001959 RID: 6489 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_2(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x0600195A RID: 6490 RVA: 0x0000FFFF File Offset: 0x0000E1FF
		static int smethod_3(string string_0, char char_0)
		{
			return string_0.LastIndexOf(char_0);
		}

		// Token: 0x0600195B RID: 6491 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_4(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x0600195C RID: 6492 RVA: 0x0000D416 File Offset: 0x0000B616
		static string smethod_5(string string_0, int int_0)
		{
			return string_0.Substring(int_0);
		}

		// Token: 0x0600195D RID: 6493 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_6(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x0600195E RID: 6494 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_7(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x0600195F RID: 6495 RVA: 0x0000FE6E File Offset: 0x0000E06E
		static Regex smethod_8(string string_0, RegexOptions regexOptions_0)
		{
			return new Regex(string_0, regexOptions_0);
		}

		// Token: 0x06001960 RID: 6496 RVA: 0x000170FF File Offset: 0x000152FF
		static bool smethod_9(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string.Equals(string_0, string_1, stringComparison_0);
		}

		// Token: 0x06001961 RID: 6497 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_10(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001962 RID: 6498 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_11(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x040009B7 RID: 2487
		private const string PatternName = "Pattern";

		// Token: 0x040009B8 RID: 2488
		private const string OptionsName = "Options";
	}
}
