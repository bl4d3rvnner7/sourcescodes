﻿using System;
using System.Xml.Linq;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x0200021A RID: 538
	internal class XDocumentTypeWrapper : XObjectWrapper, IXmlNode, IXmlDocumentType
	{
		// Token: 0x06001E5C RID: 7772 RVA: 0x00019ED9 File Offset: 0x000180D9
		public XDocumentTypeWrapper(XDocumentType documentType)
			: base(documentType)
		{
			this._documentType = documentType;
		}

		// Token: 0x17000479 RID: 1145
		// (get) Token: 0x06001E5D RID: 7773 RVA: 0x00019EE9 File Offset: 0x000180E9
		public string Name
		{
			get
			{
				return XDocumentTypeWrapper.smethod_2(this._documentType);
			}
		}

		// Token: 0x1700047A RID: 1146
		// (get) Token: 0x06001E5E RID: 7774 RVA: 0x00019EF6 File Offset: 0x000180F6
		public string System
		{
			get
			{
				return XDocumentTypeWrapper.smethod_3(this._documentType);
			}
		}

		// Token: 0x1700047B RID: 1147
		// (get) Token: 0x06001E5F RID: 7775 RVA: 0x00019F03 File Offset: 0x00018103
		public string Public
		{
			get
			{
				return XDocumentTypeWrapper.smethod_4(this._documentType);
			}
		}

		// Token: 0x1700047C RID: 1148
		// (get) Token: 0x06001E60 RID: 7776 RVA: 0x00019F10 File Offset: 0x00018110
		public string InternalSubset
		{
			get
			{
				return XDocumentTypeWrapper.smethod_5(this._documentType);
			}
		}

		// Token: 0x1700047D RID: 1149
		// (get) Token: 0x06001E61 RID: 7777 RVA: 0x00019F1D File Offset: 0x0001811D
		public override string LocalName
		{
			get
			{
				return <Module>.smethod_26<string>(2885840303U);
			}
		}

		// Token: 0x06001E62 RID: 7778 RVA: 0x00019F29 File Offset: 0x00018129
		static string smethod_2(XDocumentType xdocumentType_0)
		{
			return xdocumentType_0.Name;
		}

		// Token: 0x06001E63 RID: 7779 RVA: 0x00019F31 File Offset: 0x00018131
		static string smethod_3(XDocumentType xdocumentType_0)
		{
			return xdocumentType_0.SystemId;
		}

		// Token: 0x06001E64 RID: 7780 RVA: 0x00019F39 File Offset: 0x00018139
		static string smethod_4(XDocumentType xdocumentType_0)
		{
			return xdocumentType_0.PublicId;
		}

		// Token: 0x06001E65 RID: 7781 RVA: 0x00019F41 File Offset: 0x00018141
		static string smethod_5(XDocumentType xdocumentType_0)
		{
			return xdocumentType_0.InternalSubset;
		}

		// Token: 0x04000B75 RID: 2933
		private readonly XDocumentType _documentType;
	}
}
