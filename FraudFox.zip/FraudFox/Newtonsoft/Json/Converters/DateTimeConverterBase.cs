﻿using System;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x020001A4 RID: 420
	public abstract class DateTimeConverterBase : JsonConverter
	{
		// Token: 0x060018FD RID: 6397 RVA: 0x0007666C File Offset: 0x0007486C
		public override bool CanConvert(Type objectType)
		{
			if (!DateTimeConverterBase.smethod_1(objectType, DateTimeConverterBase.smethod_0(typeof(DateTime).TypeHandle)))
			{
				if (DateTimeConverterBase.smethod_1(objectType, DateTimeConverterBase.smethod_0(typeof(DateTime?).TypeHandle)))
				{
					goto IL_006A;
				}
				if (DateTimeConverterBase.smethod_1(objectType, DateTimeConverterBase.smethod_0(typeof(DateTimeOffset).TypeHandle)))
				{
					return true;
				}
				if (!DateTimeConverterBase.smethod_1(objectType, DateTimeConverterBase.smethod_0(typeof(DateTimeOffset?).TypeHandle)))
				{
					return false;
				}
				int num = -1832200409;
				IL_0051:
				switch (num ^ -1832200409)
				{
				case 1:
					return true;
				case 2:
					IL_006A:
					num = -1832200410;
					goto IL_0051;
				}
				return true;
			}
			return true;
		}

		// Token: 0x060018FF RID: 6399 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_0(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001900 RID: 6400 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_1(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}
	}
}
