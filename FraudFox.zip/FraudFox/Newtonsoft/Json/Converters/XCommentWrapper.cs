﻿using System;
using System.Xml.Linq;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x0200021E RID: 542
	internal class XCommentWrapper : XObjectWrapper
	{
		// Token: 0x17000487 RID: 1159
		// (get) Token: 0x06001E95 RID: 7829 RVA: 0x0001A167 File Offset: 0x00018367
		private XComment Text
		{
			get
			{
				return (XComment)base.WrappedNode;
			}
		}

		// Token: 0x06001E96 RID: 7830 RVA: 0x00019F56 File Offset: 0x00018156
		public XCommentWrapper(XComment text)
			: base(text)
		{
		}

		// Token: 0x17000488 RID: 1160
		// (get) Token: 0x06001E97 RID: 7831 RVA: 0x0001A174 File Offset: 0x00018374
		// (set) Token: 0x06001E98 RID: 7832 RVA: 0x0001A181 File Offset: 0x00018381
		public override string Value
		{
			get
			{
				return XCommentWrapper.smethod_2(this.Text);
			}
			set
			{
				XCommentWrapper.smethod_3(this.Text, value);
			}
		}

		// Token: 0x17000489 RID: 1161
		// (get) Token: 0x06001E99 RID: 7833 RVA: 0x0001A18F File Offset: 0x0001838F
		public override IXmlNode ParentNode
		{
			get
			{
				if (XCommentWrapper.smethod_4(this.Text) == null)
				{
					return null;
				}
				return XContainerWrapper.WrapNode(XCommentWrapper.smethod_4(this.Text));
			}
		}

		// Token: 0x06001E9A RID: 7834 RVA: 0x0001A1B0 File Offset: 0x000183B0
		static string smethod_2(XComment xcomment_0)
		{
			return xcomment_0.Value;
		}

		// Token: 0x06001E9B RID: 7835 RVA: 0x0001A1B8 File Offset: 0x000183B8
		static void smethod_3(XComment xcomment_0, string string_0)
		{
			xcomment_0.Value = string_0;
		}

		// Token: 0x06001E9C RID: 7836 RVA: 0x00019FDA File Offset: 0x000181DA
		static XElement smethod_4(XObject xobject_0)
		{
			return xobject_0.Parent;
		}
	}
}
