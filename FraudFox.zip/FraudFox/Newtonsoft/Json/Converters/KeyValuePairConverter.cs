﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x020001AC RID: 428
	public class KeyValuePairConverter : JsonConverter
	{
		// Token: 0x06001937 RID: 6455 RVA: 0x00077220 File Offset: 0x00075420
		private static ReflectionObject InitializeReflectionObject(Type t)
		{
			IList<Type> list = KeyValuePairConverter.smethod_0(t);
			Type type = list[0];
			Type type2 = list[1];
			return ReflectionObject.Create(t, KeyValuePairConverter.smethod_1(t, new Type[] { type, type2 }), new string[]
			{
				<Module>.smethod_24<string>(2608526835U),
				<Module>.smethod_25<string>(171763143U)
			});
		}

		// Token: 0x06001938 RID: 6456 RVA: 0x00077298 File Offset: 0x00075498
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			ReflectionObject reflectionObject = KeyValuePairConverter.ReflectionObjectPerType.Get(KeyValuePairConverter.smethod_2(value));
			DefaultContractResolver defaultContractResolver = serializer.ContractResolver as DefaultContractResolver;
			writer.WriteStartObject();
			writer.WritePropertyName((defaultContractResolver != null) ? defaultContractResolver.GetResolvedPropertyName(<Module>.smethod_24<string>(2608526835U)) : <Module>.smethod_25<string>(310958049U));
			serializer.Serialize(writer, reflectionObject.GetValue(value, <Module>.smethod_25<string>(310958049U)), reflectionObject.GetType(<Module>.smethod_25<string>(310958049U)));
			writer.WritePropertyName((defaultContractResolver != null) ? defaultContractResolver.GetResolvedPropertyName(<Module>.smethod_25<string>(171763143U)) : <Module>.smethod_25<string>(171763143U));
			serializer.Serialize(writer, reflectionObject.GetValue(value, <Module>.smethod_25<string>(171763143U)), reflectionObject.GetType(<Module>.smethod_23<string>(1552668800U)));
			writer.WriteEndObject();
		}

		// Token: 0x06001939 RID: 6457 RVA: 0x00077368 File Offset: 0x00075568
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			bool flag;
			Type type = ((flag = ReflectionUtils.IsNullableType(objectType)) ? KeyValuePairConverter.smethod_3(objectType) : objectType);
			ReflectionObject reflectionObject = KeyValuePairConverter.ReflectionObjectPerType.Get(type);
			if (reader.TokenType != JsonToken.Null)
			{
				object obj = null;
				object obj2 = null;
				KeyValuePairConverter.ReadAndAssert(reader);
				while (reader.TokenType == JsonToken.PropertyName)
				{
					string text = KeyValuePairConverter.smethod_4(reader.Value);
					if (KeyValuePairConverter.smethod_5(text, <Module>.smethod_24<string>(2608526835U), StringComparison.OrdinalIgnoreCase))
					{
						KeyValuePairConverter.ReadAndAssert(reader);
						obj = serializer.Deserialize(reader, reflectionObject.GetType(<Module>.smethod_23<string>(623888290U)));
					}
					else if (!KeyValuePairConverter.smethod_5(text, <Module>.smethod_23<string>(1552668800U), StringComparison.OrdinalIgnoreCase))
					{
						reader.Skip();
					}
					else
					{
						KeyValuePairConverter.ReadAndAssert(reader);
						obj2 = serializer.Deserialize(reader, reflectionObject.GetType(<Module>.smethod_26<string>(2186290968U)));
					}
					KeyValuePairConverter.ReadAndAssert(reader);
				}
				return reflectionObject.Creator(new object[] { obj, obj2 });
			}
			if (!flag)
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(708600618U));
			}
			return null;
		}

		// Token: 0x0600193A RID: 6458 RVA: 0x00077478 File Offset: 0x00075678
		public override bool CanConvert(Type objectType)
		{
			Type type = ((!ReflectionUtils.IsNullableType(objectType)) ? objectType : KeyValuePairConverter.smethod_3(objectType));
			return type.IsValueType() && type.IsGenericType() && KeyValuePairConverter.smethod_8(KeyValuePairConverter.smethod_6(type), KeyValuePairConverter.smethod_7(typeof(KeyValuePair<, >).TypeHandle));
		}

		// Token: 0x0600193B RID: 6459 RVA: 0x00017833 File Offset: 0x00015A33
		private static void ReadAndAssert(JsonReader reader)
		{
			if (!reader.Read())
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(1396192159U));
			}
		}

		// Token: 0x0600193E RID: 6462 RVA: 0x00015F4C File Offset: 0x0001414C
		static Type[] smethod_0(Type type_0)
		{
			return type_0.GetGenericArguments();
		}

		// Token: 0x0600193F RID: 6463 RVA: 0x000175AD File Offset: 0x000157AD
		static ConstructorInfo smethod_1(Type type_0, Type[] type_1)
		{
			return type_0.GetConstructor(type_1);
		}

		// Token: 0x06001940 RID: 6464 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_2(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06001941 RID: 6465 RVA: 0x000175B6 File Offset: 0x000157B6
		static Type smethod_3(Type type_0)
		{
			return Nullable.GetUnderlyingType(type_0);
		}

		// Token: 0x06001942 RID: 6466 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_4(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06001943 RID: 6467 RVA: 0x000170FF File Offset: 0x000152FF
		static bool smethod_5(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string.Equals(string_0, string_1, stringComparison_0);
		}

		// Token: 0x06001944 RID: 6468 RVA: 0x00015F44 File Offset: 0x00014144
		static Type smethod_6(Type type_0)
		{
			return type_0.GetGenericTypeDefinition();
		}

		// Token: 0x06001945 RID: 6469 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_7(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001946 RID: 6470 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_8(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x040009B4 RID: 2484
		private const string KeyName = "Key";

		// Token: 0x040009B5 RID: 2485
		private const string ValueName = "Value";

		// Token: 0x040009B6 RID: 2486
		private static readonly ThreadSafeStore<Type, ReflectionObject> ReflectionObjectPerType = new ThreadSafeStore<Type, ReflectionObject>(new Func<Type, ReflectionObject>(KeyValuePairConverter.InitializeReflectionObject));
	}
}
