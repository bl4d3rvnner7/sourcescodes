﻿using System;
using System.Xml.Linq;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x0200021D RID: 541
	internal class XTextWrapper : XObjectWrapper
	{
		// Token: 0x17000484 RID: 1156
		// (get) Token: 0x06001E8D RID: 7821 RVA: 0x0001A10D File Offset: 0x0001830D
		private XText Text
		{
			get
			{
				return (XText)base.WrappedNode;
			}
		}

		// Token: 0x06001E8E RID: 7822 RVA: 0x00019F56 File Offset: 0x00018156
		public XTextWrapper(XText text)
			: base(text)
		{
		}

		// Token: 0x17000485 RID: 1157
		// (get) Token: 0x06001E8F RID: 7823 RVA: 0x0001A11A File Offset: 0x0001831A
		// (set) Token: 0x06001E90 RID: 7824 RVA: 0x0001A127 File Offset: 0x00018327
		public override string Value
		{
			get
			{
				return XTextWrapper.smethod_2(this.Text);
			}
			set
			{
				XTextWrapper.smethod_3(this.Text, value);
			}
		}

		// Token: 0x17000486 RID: 1158
		// (get) Token: 0x06001E91 RID: 7825 RVA: 0x0001A135 File Offset: 0x00018335
		public override IXmlNode ParentNode
		{
			get
			{
				if (XTextWrapper.smethod_4(this.Text) == null)
				{
					return null;
				}
				return XContainerWrapper.WrapNode(XTextWrapper.smethod_4(this.Text));
			}
		}

		// Token: 0x06001E92 RID: 7826 RVA: 0x0001A156 File Offset: 0x00018356
		static string smethod_2(XText xtext_0)
		{
			return xtext_0.Value;
		}

		// Token: 0x06001E93 RID: 7827 RVA: 0x0001A15E File Offset: 0x0001835E
		static void smethod_3(XText xtext_0, string string_0)
		{
			xtext_0.Value = string_0;
		}

		// Token: 0x06001E94 RID: 7828 RVA: 0x00019FDA File Offset: 0x000181DA
		static XElement smethod_4(XObject xobject_0)
		{
			return xobject_0.Parent;
		}
	}
}
