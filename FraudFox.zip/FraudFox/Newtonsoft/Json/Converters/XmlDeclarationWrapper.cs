﻿using System;
using System.Xml;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x02000215 RID: 533
	internal class XmlDeclarationWrapper : XmlNodeWrapper, IXmlNode, IXmlDeclaration
	{
		// Token: 0x06001E28 RID: 7720 RVA: 0x00019D20 File Offset: 0x00017F20
		public XmlDeclarationWrapper(XmlDeclaration declaration)
			: base(declaration)
		{
			this._declaration = declaration;
		}

		// Token: 0x17000460 RID: 1120
		// (get) Token: 0x06001E29 RID: 7721 RVA: 0x00019D30 File Offset: 0x00017F30
		public string Version
		{
			get
			{
				return XmlDeclarationWrapper.smethod_10(this._declaration);
			}
		}

		// Token: 0x17000461 RID: 1121
		// (get) Token: 0x06001E2A RID: 7722 RVA: 0x00019D3D File Offset: 0x00017F3D
		// (set) Token: 0x06001E2B RID: 7723 RVA: 0x00019D4A File Offset: 0x00017F4A
		public string Encoding
		{
			get
			{
				return XmlDeclarationWrapper.smethod_11(this._declaration);
			}
			set
			{
				XmlDeclarationWrapper.smethod_12(this._declaration, value);
			}
		}

		// Token: 0x17000462 RID: 1122
		// (get) Token: 0x06001E2C RID: 7724 RVA: 0x00019D58 File Offset: 0x00017F58
		// (set) Token: 0x06001E2D RID: 7725 RVA: 0x00019D65 File Offset: 0x00017F65
		public string Standalone
		{
			get
			{
				return XmlDeclarationWrapper.smethod_13(this._declaration);
			}
			set
			{
				XmlDeclarationWrapper.smethod_14(this._declaration, value);
			}
		}

		// Token: 0x06001E2E RID: 7726 RVA: 0x00019D73 File Offset: 0x00017F73
		static string smethod_10(XmlDeclaration xmlDeclaration_0)
		{
			return xmlDeclaration_0.Version;
		}

		// Token: 0x06001E2F RID: 7727 RVA: 0x00019D7B File Offset: 0x00017F7B
		static string smethod_11(XmlDeclaration xmlDeclaration_0)
		{
			return xmlDeclaration_0.Encoding;
		}

		// Token: 0x06001E30 RID: 7728 RVA: 0x00019D83 File Offset: 0x00017F83
		static void smethod_12(XmlDeclaration xmlDeclaration_0, string string_0)
		{
			xmlDeclaration_0.Encoding = string_0;
		}

		// Token: 0x06001E31 RID: 7729 RVA: 0x00019D8C File Offset: 0x00017F8C
		static string smethod_13(XmlDeclaration xmlDeclaration_0)
		{
			return xmlDeclaration_0.Standalone;
		}

		// Token: 0x06001E32 RID: 7730 RVA: 0x00019D94 File Offset: 0x00017F94
		static void smethod_14(XmlDeclaration xmlDeclaration_0, string string_0)
		{
			xmlDeclaration_0.Standalone = string_0;
		}

		// Token: 0x04000B71 RID: 2929
		private readonly XmlDeclaration _declaration;
	}
}
