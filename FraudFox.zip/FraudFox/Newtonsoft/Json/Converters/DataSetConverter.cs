﻿using System;
using System.Collections;
using System.Data;
using Newtonsoft.Json.Serialization;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x020001A1 RID: 417
	public class DataSetConverter : JsonConverter
	{
		// Token: 0x060018C0 RID: 6336 RVA: 0x00076020 File Offset: 0x00074220
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			DataSet dataSet = (DataSet)value;
			DefaultContractResolver defaultContractResolver = serializer.ContractResolver as DefaultContractResolver;
			DataTableConverter dataTableConverter = new DataTableConverter();
			writer.WriteStartObject();
			IEnumerator enumerator = DataSetConverter.smethod_1(DataSetConverter.smethod_0(dataSet));
			try
			{
				while (DataSetConverter.smethod_4(enumerator))
				{
					DataTable dataTable = (DataTable)DataSetConverter.smethod_2(enumerator);
					writer.WritePropertyName((defaultContractResolver != null) ? defaultContractResolver.GetResolvedPropertyName(DataSetConverter.smethod_3(dataTable)) : DataSetConverter.smethod_3(dataTable));
					dataTableConverter.WriteJson(writer, dataTable, serializer);
				}
			}
			finally
			{
				IDisposable disposable = enumerator as IDisposable;
				if (disposable != null)
				{
					DataSetConverter.smethod_5(disposable);
				}
			}
			writer.WriteEndObject();
		}

		// Token: 0x060018C1 RID: 6337 RVA: 0x000760C8 File Offset: 0x000742C8
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			DataSet dataSet = ((!DataSetConverter.smethod_7(objectType, DataSetConverter.smethod_6(typeof(DataSet).TypeHandle))) ? ((DataSet)DataSetConverter.smethod_8(objectType)) : DataSetConverter.smethod_9());
			DataTableConverter dataTableConverter = new DataTableConverter();
			this.CheckedRead(reader);
			while (reader.TokenType == JsonToken.PropertyName)
			{
				DataTable dataTable = DataSetConverter.smethod_10(DataSetConverter.smethod_0(dataSet), (string)reader.Value);
				bool flag = dataTable != null;
				dataTable = (DataTable)dataTableConverter.ReadJson(reader, DataSetConverter.smethod_6(typeof(DataTable).TypeHandle), dataTable, serializer);
				if (!flag)
				{
					DataSetConverter.smethod_11(DataSetConverter.smethod_0(dataSet), dataTable);
				}
				this.CheckedRead(reader);
			}
			return dataSet;
		}

		// Token: 0x060018C2 RID: 6338 RVA: 0x000175C7 File Offset: 0x000157C7
		public override bool CanConvert(Type valueType)
		{
			return DataSetConverter.smethod_12(DataSetConverter.smethod_6(typeof(DataSet).TypeHandle), valueType);
		}

		// Token: 0x060018C3 RID: 6339 RVA: 0x000175D9 File Offset: 0x000157D9
		private void CheckedRead(JsonReader reader)
		{
			if (!reader.Read())
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(186406461U));
			}
		}

		// Token: 0x060018C5 RID: 6341 RVA: 0x000175F4 File Offset: 0x000157F4
		static DataTableCollection smethod_0(DataSet dataSet_0)
		{
			return dataSet_0.Tables;
		}

		// Token: 0x060018C6 RID: 6342 RVA: 0x000175FC File Offset: 0x000157FC
		static IEnumerator smethod_1(InternalDataCollectionBase internalDataCollectionBase_0)
		{
			return internalDataCollectionBase_0.GetEnumerator();
		}

		// Token: 0x060018C7 RID: 6343 RVA: 0x0000D8E2 File Offset: 0x0000BAE2
		static object smethod_2(IEnumerator ienumerator_0)
		{
			return ienumerator_0.Current;
		}

		// Token: 0x060018C8 RID: 6344 RVA: 0x00017604 File Offset: 0x00015804
		static string smethod_3(DataTable dataTable_0)
		{
			return dataTable_0.TableName;
		}

		// Token: 0x060018C9 RID: 6345 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_4(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060018CA RID: 6346 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_5(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060018CB RID: 6347 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_6(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060018CC RID: 6348 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_7(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x060018CD RID: 6349 RVA: 0x0001630C File Offset: 0x0001450C
		static object smethod_8(Type type_0)
		{
			return Activator.CreateInstance(type_0);
		}

		// Token: 0x060018CE RID: 6350 RVA: 0x0001760C File Offset: 0x0001580C
		static DataSet smethod_9()
		{
			return new DataSet();
		}

		// Token: 0x060018CF RID: 6351 RVA: 0x00017613 File Offset: 0x00015813
		static DataTable smethod_10(DataTableCollection dataTableCollection_0, string string_0)
		{
			return dataTableCollection_0[string_0];
		}

		// Token: 0x060018D0 RID: 6352 RVA: 0x0001761C File Offset: 0x0001581C
		static void smethod_11(DataTableCollection dataTableCollection_0, DataTable dataTable_0)
		{
			dataTableCollection_0.Add(dataTable_0);
		}

		// Token: 0x060018D1 RID: 6353 RVA: 0x00017625 File Offset: 0x00015825
		static bool smethod_12(Type type_0, Type type_1)
		{
			return type_0.IsAssignableFrom(type_1);
		}
	}
}
