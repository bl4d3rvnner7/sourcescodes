﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x0200020F RID: 527
	internal class XmlNodeWrapper : IXmlNode
	{
		// Token: 0x06001DDB RID: 7643 RVA: 0x00019A4A File Offset: 0x00017C4A
		public XmlNodeWrapper(XmlNode node)
		{
			this._node = node;
		}

		// Token: 0x17000451 RID: 1105
		// (get) Token: 0x06001DDC RID: 7644 RVA: 0x00019A59 File Offset: 0x00017C59
		public object WrappedNode
		{
			get
			{
				return this._node;
			}
		}

		// Token: 0x17000452 RID: 1106
		// (get) Token: 0x06001DDD RID: 7645 RVA: 0x00019A61 File Offset: 0x00017C61
		public XmlNodeType NodeType
		{
			get
			{
				return XmlNodeWrapper.smethod_0(this._node);
			}
		}

		// Token: 0x17000453 RID: 1107
		// (get) Token: 0x06001DDE RID: 7646 RVA: 0x00019A6E File Offset: 0x00017C6E
		public virtual string LocalName
		{
			get
			{
				return XmlNodeWrapper.smethod_1(this._node);
			}
		}

		// Token: 0x17000454 RID: 1108
		// (get) Token: 0x06001DDF RID: 7647 RVA: 0x00019A7B File Offset: 0x00017C7B
		public IList<IXmlNode> ChildNodes
		{
			get
			{
				if (this._childNodes == null)
				{
					this._childNodes = XmlNodeWrapper.smethod_2(this._node).Cast<XmlNode>().Select(new Func<XmlNode, IXmlNode>(XmlNodeWrapper.WrapNode))
						.ToList<IXmlNode>();
				}
				return this._childNodes;
			}
		}

		// Token: 0x06001DE0 RID: 7648 RVA: 0x00081A54 File Offset: 0x0007FC54
		internal static IXmlNode WrapNode(XmlNode node)
		{
			XmlNodeType xmlNodeType = XmlNodeWrapper.smethod_0(node);
			if (xmlNodeType == XmlNodeType.Element)
			{
				return new XmlElementWrapper((XmlElement)node);
			}
			if (xmlNodeType == XmlNodeType.DocumentType)
			{
				return new XmlDocumentTypeWrapper((XmlDocumentType)node);
			}
			if (xmlNodeType != XmlNodeType.XmlDeclaration)
			{
				return new XmlNodeWrapper(node);
			}
			return new XmlDeclarationWrapper((XmlDeclaration)node);
		}

		// Token: 0x17000455 RID: 1109
		// (get) Token: 0x06001DE1 RID: 7649 RVA: 0x00019AB7 File Offset: 0x00017CB7
		public IList<IXmlNode> Attributes
		{
			get
			{
				if (XmlNodeWrapper.smethod_3(this._node) == null)
				{
					return null;
				}
				return XmlNodeWrapper.smethod_3(this._node).Cast<XmlAttribute>().Select(new Func<XmlAttribute, IXmlNode>(XmlNodeWrapper.WrapNode))
					.ToList<IXmlNode>();
			}
		}

		// Token: 0x17000456 RID: 1110
		// (get) Token: 0x06001DE2 RID: 7650 RVA: 0x00081AA0 File Offset: 0x0007FCA0
		public IXmlNode ParentNode
		{
			get
			{
				XmlNode xmlNode = ((!(this._node is XmlAttribute)) ? XmlNodeWrapper.smethod_4(this._node) : XmlNodeWrapper.smethod_5((XmlAttribute)this._node));
				if (xmlNode == null)
				{
					return null;
				}
				return XmlNodeWrapper.WrapNode(xmlNode);
			}
		}

		// Token: 0x17000457 RID: 1111
		// (get) Token: 0x06001DE3 RID: 7651 RVA: 0x00019AEE File Offset: 0x00017CEE
		// (set) Token: 0x06001DE4 RID: 7652 RVA: 0x00019AFB File Offset: 0x00017CFB
		public string Value
		{
			get
			{
				return XmlNodeWrapper.smethod_6(this._node);
			}
			set
			{
				XmlNodeWrapper.smethod_7(this._node, value);
			}
		}

		// Token: 0x06001DE5 RID: 7653 RVA: 0x00081AE4 File Offset: 0x0007FCE4
		public IXmlNode AppendChild(IXmlNode newChild)
		{
			XmlNodeWrapper xmlNodeWrapper = (XmlNodeWrapper)newChild;
			XmlNodeWrapper.smethod_8(this._node, xmlNodeWrapper._node);
			this._childNodes = null;
			return newChild;
		}

		// Token: 0x17000458 RID: 1112
		// (get) Token: 0x06001DE6 RID: 7654 RVA: 0x00019B09 File Offset: 0x00017D09
		public string NamespaceUri
		{
			get
			{
				return XmlNodeWrapper.smethod_9(this._node);
			}
		}

		// Token: 0x06001DE7 RID: 7655 RVA: 0x00019B16 File Offset: 0x00017D16
		static XmlNodeType smethod_0(XmlNode xmlNode_0)
		{
			return xmlNode_0.NodeType;
		}

		// Token: 0x06001DE8 RID: 7656 RVA: 0x00019B1E File Offset: 0x00017D1E
		static string smethod_1(XmlNode xmlNode_0)
		{
			return xmlNode_0.LocalName;
		}

		// Token: 0x06001DE9 RID: 7657 RVA: 0x00019B26 File Offset: 0x00017D26
		static XmlNodeList smethod_2(XmlNode xmlNode_0)
		{
			return xmlNode_0.ChildNodes;
		}

		// Token: 0x06001DEA RID: 7658 RVA: 0x00019B2E File Offset: 0x00017D2E
		static XmlAttributeCollection smethod_3(XmlNode xmlNode_0)
		{
			return xmlNode_0.Attributes;
		}

		// Token: 0x06001DEB RID: 7659 RVA: 0x00019B36 File Offset: 0x00017D36
		static XmlNode smethod_4(XmlNode xmlNode_0)
		{
			return xmlNode_0.ParentNode;
		}

		// Token: 0x06001DEC RID: 7660 RVA: 0x00019B3E File Offset: 0x00017D3E
		static XmlElement smethod_5(XmlAttribute xmlAttribute_0)
		{
			return xmlAttribute_0.OwnerElement;
		}

		// Token: 0x06001DED RID: 7661 RVA: 0x00019B46 File Offset: 0x00017D46
		static string smethod_6(XmlNode xmlNode_0)
		{
			return xmlNode_0.Value;
		}

		// Token: 0x06001DEE RID: 7662 RVA: 0x00019B4E File Offset: 0x00017D4E
		static void smethod_7(XmlNode xmlNode_0, string string_0)
		{
			xmlNode_0.Value = string_0;
		}

		// Token: 0x06001DEF RID: 7663 RVA: 0x00019B57 File Offset: 0x00017D57
		static XmlNode smethod_8(XmlNode xmlNode_0, XmlNode xmlNode_1)
		{
			return xmlNode_0.AppendChild(xmlNode_1);
		}

		// Token: 0x06001DF0 RID: 7664 RVA: 0x00019B60 File Offset: 0x00017D60
		static string smethod_9(XmlNode xmlNode_0)
		{
			return xmlNode_0.NamespaceURI;
		}

		// Token: 0x04000B6D RID: 2925
		private readonly XmlNode _node;

		// Token: 0x04000B6E RID: 2926
		private IList<IXmlNode> _childNodes;
	}
}
