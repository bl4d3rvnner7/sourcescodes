﻿using System;
using System.Globalization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x020001AF RID: 431
	public class StringEnumConverter : JsonConverter
	{
		// Token: 0x17000398 RID: 920
		// (get) Token: 0x06001963 RID: 6499 RVA: 0x000178D3 File Offset: 0x00015AD3
		// (set) Token: 0x06001964 RID: 6500 RVA: 0x000178DB File Offset: 0x00015ADB
		public bool CamelCaseText { get; set; }

		// Token: 0x17000399 RID: 921
		// (get) Token: 0x06001965 RID: 6501 RVA: 0x000178E4 File Offset: 0x00015AE4
		// (set) Token: 0x06001966 RID: 6502 RVA: 0x000178EC File Offset: 0x00015AEC
		public bool AllowIntegerValues { get; set; }

		// Token: 0x06001967 RID: 6503 RVA: 0x000178F5 File Offset: 0x00015AF5
		public StringEnumConverter()
		{
			this.AllowIntegerValues = true;
		}

		// Token: 0x06001968 RID: 6504 RVA: 0x0007785C File Offset: 0x00075A5C
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			if (value == null)
			{
				writer.WriteNull();
				return;
			}
			Enum @enum = (Enum)value;
			string text = StringEnumConverter.smethod_0(@enum, <Module>.smethod_25<string>(1925421998U));
			if (!char.IsNumber(StringEnumConverter.smethod_1(text, 0)))
			{
				if (StringEnumConverter.smethod_1(text, 0) != '-')
				{
					Type type = StringEnumConverter.smethod_2(@enum);
					string text2 = EnumUtils.ToEnumName(type, text, this.CamelCaseText);
					writer.WriteValue(text2);
					return;
				}
			}
			writer.WriteValue(value);
		}

		// Token: 0x06001969 RID: 6505 RVA: 0x000778CC File Offset: 0x00075ACC
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			bool flag;
			Type type = ((!(flag = ReflectionUtils.IsNullableType(objectType))) ? objectType : StringEnumConverter.smethod_3(objectType));
			if (reader.TokenType != JsonToken.Null)
			{
				try
				{
					if (reader.TokenType == JsonToken.String)
					{
						string text = StringEnumConverter.smethod_5(reader.Value);
						return EnumUtils.ParseEnumName(text, flag, type);
					}
					if (reader.TokenType == JsonToken.Integer)
					{
						if (!this.AllowIntegerValues)
						{
							throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(3580479652U).FormatWith(StringEnumConverter.smethod_4(), reader.Value));
						}
						return ConvertUtils.ConvertOrCast(reader.Value, StringEnumConverter.smethod_4(), type);
					}
				}
				catch (Exception ex)
				{
					throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(600856370U).FormatWith(StringEnumConverter.smethod_4(), MiscellaneousUtils.FormatValueForPrint(reader.Value), objectType), ex);
				}
				throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(4272926414U).FormatWith(StringEnumConverter.smethod_4(), reader.TokenType));
			}
			if (!ReflectionUtils.IsNullableType(objectType))
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(2820903422U).FormatWith(StringEnumConverter.smethod_4(), objectType));
			}
			return null;
		}

		// Token: 0x0600196A RID: 6506 RVA: 0x000779EC File Offset: 0x00075BEC
		public override bool CanConvert(Type objectType)
		{
			Type type = (ReflectionUtils.IsNullableType(objectType) ? StringEnumConverter.smethod_3(objectType) : objectType);
			return type.IsEnum();
		}

		// Token: 0x0600196B RID: 6507 RVA: 0x00017904 File Offset: 0x00015B04
		static string smethod_0(Enum enum_0, string string_0)
		{
			return enum_0.ToString(string_0);
		}

		// Token: 0x0600196C RID: 6508 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_1(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x0600196D RID: 6509 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_2(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x0600196E RID: 6510 RVA: 0x000175B6 File Offset: 0x000157B6
		static Type smethod_3(Type type_0)
		{
			return Nullable.GetUnderlyingType(type_0);
		}

		// Token: 0x0600196F RID: 6511 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_4()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001970 RID: 6512 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_5(object object_0)
		{
			return object_0.ToString();
		}
	}
}
