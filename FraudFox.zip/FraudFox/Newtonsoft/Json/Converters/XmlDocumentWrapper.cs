﻿using System;
using System.Xml;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x02000211 RID: 529
	internal class XmlDocumentWrapper : XmlNodeWrapper, IXmlNode, IXmlDocument
	{
		// Token: 0x06001DFE RID: 7678 RVA: 0x00019B68 File Offset: 0x00017D68
		public XmlDocumentWrapper(XmlDocument document)
			: base(document)
		{
			this._document = document;
		}

		// Token: 0x06001DFF RID: 7679 RVA: 0x00019B78 File Offset: 0x00017D78
		public IXmlNode CreateComment(string data)
		{
			return new XmlNodeWrapper(XmlDocumentWrapper.smethod_10(this._document, data));
		}

		// Token: 0x06001E00 RID: 7680 RVA: 0x00019B8B File Offset: 0x00017D8B
		public IXmlNode CreateTextNode(string text)
		{
			return new XmlNodeWrapper(XmlDocumentWrapper.smethod_11(this._document, text));
		}

		// Token: 0x06001E01 RID: 7681 RVA: 0x00019B9E File Offset: 0x00017D9E
		public IXmlNode CreateCDataSection(string data)
		{
			return new XmlNodeWrapper(XmlDocumentWrapper.smethod_12(this._document, data));
		}

		// Token: 0x06001E02 RID: 7682 RVA: 0x00019BB1 File Offset: 0x00017DB1
		public IXmlNode CreateWhitespace(string text)
		{
			return new XmlNodeWrapper(XmlDocumentWrapper.smethod_13(this._document, text));
		}

		// Token: 0x06001E03 RID: 7683 RVA: 0x00019BC4 File Offset: 0x00017DC4
		public IXmlNode CreateSignificantWhitespace(string text)
		{
			return new XmlNodeWrapper(XmlDocumentWrapper.smethod_14(this._document, text));
		}

		// Token: 0x06001E04 RID: 7684 RVA: 0x00019BD7 File Offset: 0x00017DD7
		public IXmlNode CreateXmlDeclaration(string version, string encoding, string standalone)
		{
			return new XmlDeclarationWrapper(XmlDocumentWrapper.smethod_15(this._document, version, encoding, standalone));
		}

		// Token: 0x06001E05 RID: 7685 RVA: 0x00019BEC File Offset: 0x00017DEC
		public IXmlNode CreateXmlDocumentType(string name, string publicId, string systemId, string internalSubset)
		{
			return new XmlDocumentTypeWrapper(XmlDocumentWrapper.smethod_16(this._document, name, publicId, systemId, null));
		}

		// Token: 0x06001E06 RID: 7686 RVA: 0x00019C02 File Offset: 0x00017E02
		public IXmlNode CreateProcessingInstruction(string target, string data)
		{
			return new XmlNodeWrapper(XmlDocumentWrapper.smethod_17(this._document, target, data));
		}

		// Token: 0x06001E07 RID: 7687 RVA: 0x00019C16 File Offset: 0x00017E16
		public IXmlElement CreateElement(string elementName)
		{
			return new XmlElementWrapper(XmlDocumentWrapper.smethod_18(this._document, elementName));
		}

		// Token: 0x06001E08 RID: 7688 RVA: 0x00019C29 File Offset: 0x00017E29
		public IXmlElement CreateElement(string qualifiedName, string namespaceUri)
		{
			return new XmlElementWrapper(XmlDocumentWrapper.smethod_19(this._document, qualifiedName, namespaceUri));
		}

		// Token: 0x06001E09 RID: 7689 RVA: 0x00081B14 File Offset: 0x0007FD14
		public IXmlNode CreateAttribute(string name, string value)
		{
			return new XmlNodeWrapper(XmlDocumentWrapper.smethod_20(this._document, name))
			{
				Value = value
			};
		}

		// Token: 0x06001E0A RID: 7690 RVA: 0x00081B3C File Offset: 0x0007FD3C
		public IXmlNode CreateAttribute(string qualifiedName, string namespaceUri, string value)
		{
			return new XmlNodeWrapper(XmlDocumentWrapper.smethod_21(this._document, qualifiedName, namespaceUri))
			{
				Value = value
			};
		}

		// Token: 0x1700045A RID: 1114
		// (get) Token: 0x06001E0B RID: 7691 RVA: 0x00019C3D File Offset: 0x00017E3D
		public IXmlElement DocumentElement
		{
			get
			{
				if (XmlDocumentWrapper.smethod_22(this._document) == null)
				{
					return null;
				}
				return new XmlElementWrapper(XmlDocumentWrapper.smethod_22(this._document));
			}
		}

		// Token: 0x06001E0C RID: 7692 RVA: 0x00019C5E File Offset: 0x00017E5E
		static XmlComment smethod_10(XmlDocument xmlDocument_0, string string_0)
		{
			return xmlDocument_0.CreateComment(string_0);
		}

		// Token: 0x06001E0D RID: 7693 RVA: 0x00019C67 File Offset: 0x00017E67
		static XmlText smethod_11(XmlDocument xmlDocument_0, string string_0)
		{
			return xmlDocument_0.CreateTextNode(string_0);
		}

		// Token: 0x06001E0E RID: 7694 RVA: 0x00019C70 File Offset: 0x00017E70
		static XmlCDataSection smethod_12(XmlDocument xmlDocument_0, string string_0)
		{
			return xmlDocument_0.CreateCDataSection(string_0);
		}

		// Token: 0x06001E0F RID: 7695 RVA: 0x00019C79 File Offset: 0x00017E79
		static XmlWhitespace smethod_13(XmlDocument xmlDocument_0, string string_0)
		{
			return xmlDocument_0.CreateWhitespace(string_0);
		}

		// Token: 0x06001E10 RID: 7696 RVA: 0x00019C82 File Offset: 0x00017E82
		static XmlSignificantWhitespace smethod_14(XmlDocument xmlDocument_0, string string_0)
		{
			return xmlDocument_0.CreateSignificantWhitespace(string_0);
		}

		// Token: 0x06001E11 RID: 7697 RVA: 0x00019C8B File Offset: 0x00017E8B
		static XmlDeclaration smethod_15(XmlDocument xmlDocument_0, string string_0, string string_1, string string_2)
		{
			return xmlDocument_0.CreateXmlDeclaration(string_0, string_1, string_2);
		}

		// Token: 0x06001E12 RID: 7698 RVA: 0x00019C96 File Offset: 0x00017E96
		static XmlDocumentType smethod_16(XmlDocument xmlDocument_0, string string_0, string string_1, string string_2, string string_3)
		{
			return xmlDocument_0.CreateDocumentType(string_0, string_1, string_2, string_3);
		}

		// Token: 0x06001E13 RID: 7699 RVA: 0x00019CA3 File Offset: 0x00017EA3
		static XmlProcessingInstruction smethod_17(XmlDocument xmlDocument_0, string string_0, string string_1)
		{
			return xmlDocument_0.CreateProcessingInstruction(string_0, string_1);
		}

		// Token: 0x06001E14 RID: 7700 RVA: 0x00019CAD File Offset: 0x00017EAD
		static XmlElement smethod_18(XmlDocument xmlDocument_0, string string_0)
		{
			return xmlDocument_0.CreateElement(string_0);
		}

		// Token: 0x06001E15 RID: 7701 RVA: 0x00019CB6 File Offset: 0x00017EB6
		static XmlElement smethod_19(XmlDocument xmlDocument_0, string string_0, string string_1)
		{
			return xmlDocument_0.CreateElement(string_0, string_1);
		}

		// Token: 0x06001E16 RID: 7702 RVA: 0x00019CC0 File Offset: 0x00017EC0
		static XmlAttribute smethod_20(XmlDocument xmlDocument_0, string string_0)
		{
			return xmlDocument_0.CreateAttribute(string_0);
		}

		// Token: 0x06001E17 RID: 7703 RVA: 0x00019CC9 File Offset: 0x00017EC9
		static XmlAttribute smethod_21(XmlDocument xmlDocument_0, string string_0, string string_1)
		{
			return xmlDocument_0.CreateAttribute(string_0, string_1);
		}

		// Token: 0x06001E18 RID: 7704 RVA: 0x00019CD3 File Offset: 0x00017ED3
		static XmlElement smethod_22(XmlDocument xmlDocument_0)
		{
			return xmlDocument_0.DocumentElement;
		}

		// Token: 0x04000B6F RID: 2927
		private readonly XmlDocument _document;
	}
}
