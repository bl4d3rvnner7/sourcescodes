﻿using System;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x02000212 RID: 530
	internal interface IXmlElement : IXmlNode
	{
		// Token: 0x06001E19 RID: 7705
		void SetAttributeNode(IXmlNode attribute);

		// Token: 0x06001E1A RID: 7706
		string GetPrefixOfNamespace(string namespaceUri);

		// Token: 0x1700045B RID: 1115
		// (get) Token: 0x06001E1B RID: 7707
		bool IsEmpty { get; }
	}
}
