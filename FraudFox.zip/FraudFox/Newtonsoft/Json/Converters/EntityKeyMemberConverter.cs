﻿using System;
using System.Globalization;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x020001AA RID: 426
	public class EntityKeyMemberConverter : JsonConverter
	{
		// Token: 0x0600191C RID: 6428 RVA: 0x00076E7C File Offset: 0x0007507C
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			EntityKeyMemberConverter.EnsureReflectionObject(EntityKeyMemberConverter.smethod_0(value));
			DefaultContractResolver defaultContractResolver = serializer.ContractResolver as DefaultContractResolver;
			string text = (string)EntityKeyMemberConverter._reflectionObject.GetValue(value, <Module>.smethod_23<string>(623888290U));
			object value2 = EntityKeyMemberConverter._reflectionObject.GetValue(value, <Module>.smethod_27<string>(220504416U));
			Type type = ((value2 != null) ? EntityKeyMemberConverter.smethod_0(value2) : null);
			writer.WriteStartObject();
			writer.WritePropertyName((defaultContractResolver != null) ? defaultContractResolver.GetResolvedPropertyName(<Module>.smethod_27<string>(4235741554U)) : <Module>.smethod_26<string>(2176714574U));
			writer.WriteValue(text);
			writer.WritePropertyName((defaultContractResolver != null) ? defaultContractResolver.GetResolvedPropertyName(<Module>.smethod_27<string>(3748994084U)) : <Module>.smethod_23<string>(4268069156U));
			writer.WriteValue(EntityKeyMemberConverter.smethod_1(type, null) ? EntityKeyMemberConverter.smethod_2(type) : null);
			writer.WritePropertyName((defaultContractResolver != null) ? defaultContractResolver.GetResolvedPropertyName(<Module>.smethod_24<string>(752438405U)) : <Module>.smethod_26<string>(2186290968U));
			if (EntityKeyMemberConverter.smethod_1(type, null))
			{
				string text2;
				if (JsonSerializerInternalWriter.TryConvertToString(value2, type, out text2))
				{
					writer.WriteValue(text2);
				}
				else
				{
					writer.WriteValue(value2);
				}
			}
			else
			{
				writer.WriteNull();
			}
			writer.WriteEndObject();
		}

		// Token: 0x0600191D RID: 6429 RVA: 0x0001779D File Offset: 0x0001599D
		private static void ReadAndAssertProperty(JsonReader reader, string propertyName)
		{
			EntityKeyMemberConverter.ReadAndAssert(reader);
			if (reader.TokenType != JsonToken.PropertyName || !EntityKeyMemberConverter.smethod_4(EntityKeyMemberConverter.smethod_3(reader.Value), propertyName, StringComparison.OrdinalIgnoreCase))
			{
				throw new JsonSerializationException(<Module>.smethod_25<string>(2399317929U).FormatWith(EntityKeyMemberConverter.smethod_5(), propertyName));
			}
		}

		// Token: 0x0600191E RID: 6430 RVA: 0x000177DD File Offset: 0x000159DD
		private static void ReadAndAssert(JsonReader reader)
		{
			if (!reader.Read())
			{
				throw new JsonSerializationException(<Module>.smethod_23<string>(2778257515U));
			}
		}

		// Token: 0x0600191F RID: 6431 RVA: 0x00076FA8 File Offset: 0x000751A8
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			EntityKeyMemberConverter.EnsureReflectionObject(objectType);
			object obj = EntityKeyMemberConverter._reflectionObject.Creator(new object[0]);
			EntityKeyMemberConverter.ReadAndAssertProperty(reader, <Module>.smethod_27<string>(4235741554U));
			EntityKeyMemberConverter.ReadAndAssert(reader);
			EntityKeyMemberConverter._reflectionObject.SetValue(obj, <Module>.smethod_23<string>(623888290U), EntityKeyMemberConverter.smethod_3(reader.Value));
			EntityKeyMemberConverter.ReadAndAssertProperty(reader, <Module>.smethod_27<string>(3748994084U));
			EntityKeyMemberConverter.ReadAndAssert(reader);
			string text = EntityKeyMemberConverter.smethod_3(reader.Value);
			Type type = EntityKeyMemberConverter.smethod_6(text);
			EntityKeyMemberConverter.ReadAndAssertProperty(reader, <Module>.smethod_23<string>(1552668800U));
			EntityKeyMemberConverter.ReadAndAssert(reader);
			EntityKeyMemberConverter._reflectionObject.SetValue(obj, <Module>.smethod_24<string>(752438405U), serializer.Deserialize(reader, type));
			EntityKeyMemberConverter.ReadAndAssert(reader);
			return obj;
		}

		// Token: 0x06001920 RID: 6432 RVA: 0x0007706C File Offset: 0x0007526C
		private static void EnsureReflectionObject(Type objectType)
		{
			if (EntityKeyMemberConverter._reflectionObject == null)
			{
				EntityKeyMemberConverter._reflectionObject = ReflectionObject.Create(objectType, new string[]
				{
					<Module>.smethod_26<string>(2176714574U),
					<Module>.smethod_27<string>(220504416U)
				});
			}
		}

		// Token: 0x06001921 RID: 6433 RVA: 0x000177F7 File Offset: 0x000159F7
		public override bool CanConvert(Type objectType)
		{
			return objectType.AssignableToTypeName(<Module>.smethod_23<string>(359665364U));
		}

		// Token: 0x06001923 RID: 6435 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_0(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06001924 RID: 6436 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_1(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x06001925 RID: 6437 RVA: 0x00017761 File Offset: 0x00015961
		static string smethod_2(Type type_0)
		{
			return type_0.FullName;
		}

		// Token: 0x06001926 RID: 6438 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_3(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06001927 RID: 6439 RVA: 0x000170FF File Offset: 0x000152FF
		static bool smethod_4(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string.Equals(string_0, string_1, stringComparison_0);
		}

		// Token: 0x06001928 RID: 6440 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_5()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001929 RID: 6441 RVA: 0x00017809 File Offset: 0x00015A09
		static Type smethod_6(string string_0)
		{
			return Type.GetType(string_0);
		}

		// Token: 0x040009AF RID: 2479
		private const string EntityKeyMemberFullTypeName = "System.Data.EntityKeyMember";

		// Token: 0x040009B0 RID: 2480
		private const string KeyPropertyName = "Key";

		// Token: 0x040009B1 RID: 2481
		private const string TypePropertyName = "Type";

		// Token: 0x040009B2 RID: 2482
		private const string ValuePropertyName = "Value";

		// Token: 0x040009B3 RID: 2483
		private static ReflectionObject _reflectionObject;
	}
}
