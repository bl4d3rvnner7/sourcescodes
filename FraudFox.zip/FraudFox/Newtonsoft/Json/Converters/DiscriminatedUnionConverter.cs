﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x020001A5 RID: 421
	public class DiscriminatedUnionConverter : JsonConverter
	{
		// Token: 0x06001901 RID: 6401 RVA: 0x000766F0 File Offset: 0x000748F0
		private static Type CreateUnionTypeLookup(Type t)
		{
			MethodCall<object, object> getUnionCases = FSharpUtils.GetUnionCases;
			object obj = null;
			object[] array = new object[2];
			array[0] = t;
			object[] array2 = (object[])getUnionCases(obj, array);
			object obj2 = array2.First<object>();
			return (Type)FSharpUtils.GetUnionCaseInfoDeclaringType(obj2);
		}

		// Token: 0x06001902 RID: 6402 RVA: 0x00076734 File Offset: 0x00074934
		private static DiscriminatedUnionConverter.Union CreateUnion(Type t)
		{
			DiscriminatedUnionConverter.Union union = new DiscriminatedUnionConverter.Union();
			DiscriminatedUnionConverter.Union union2 = union;
			MethodCall<object, object> preComputeUnionTagReader = FSharpUtils.PreComputeUnionTagReader;
			object obj = null;
			object[] array = new object[2];
			array[0] = t;
			union2.TagReader = (FSharpFunction)preComputeUnionTagReader(obj, array);
			union.Cases = new List<DiscriminatedUnionConverter.UnionCase>();
			MethodCall<object, object> getUnionCases = FSharpUtils.GetUnionCases;
			object obj2 = null;
			object[] array2 = new object[2];
			array2[0] = t;
			object[] array3 = (object[])getUnionCases(obj2, array2);
			foreach (object obj3 in array3)
			{
				DiscriminatedUnionConverter.UnionCase unionCase = new DiscriminatedUnionConverter.UnionCase();
				unionCase.Tag = (int)FSharpUtils.GetUnionCaseInfoTag(obj3);
				unionCase.Name = (string)FSharpUtils.GetUnionCaseInfoName(obj3);
				unionCase.Fields = (PropertyInfo[])FSharpUtils.GetUnionCaseInfoFields(obj3, new object[0]);
				DiscriminatedUnionConverter.UnionCase unionCase2 = unionCase;
				MethodCall<object, object> preComputeUnionReader = FSharpUtils.PreComputeUnionReader;
				object obj4 = null;
				object[] array5 = new object[2];
				array5[0] = obj3;
				unionCase2.FieldReader = (FSharpFunction)preComputeUnionReader(obj4, array5);
				DiscriminatedUnionConverter.UnionCase unionCase3 = unionCase;
				MethodCall<object, object> preComputeUnionConstructor = FSharpUtils.PreComputeUnionConstructor;
				object obj5 = null;
				object[] array6 = new object[2];
				array6[0] = obj3;
				unionCase3.Constructor = (FSharpFunction)preComputeUnionConstructor(obj5, array6);
				union.Cases.Add(unionCase);
			}
			return union;
		}

		// Token: 0x06001903 RID: 6403 RVA: 0x00076868 File Offset: 0x00074A68
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			DefaultContractResolver defaultContractResolver = serializer.ContractResolver as DefaultContractResolver;
			Type type = DiscriminatedUnionConverter.UnionTypeLookupCache.Get(DiscriminatedUnionConverter.smethod_0(value));
			DiscriminatedUnionConverter.Union union = DiscriminatedUnionConverter.UnionCache.Get(type);
			int tag = (int)union.TagReader.Invoke(new object[] { value });
			DiscriminatedUnionConverter.UnionCase unionCase = union.Cases.Single((DiscriminatedUnionConverter.UnionCase c) => c.Tag == tag);
			writer.WriteStartObject();
			writer.WritePropertyName((defaultContractResolver != null) ? defaultContractResolver.GetResolvedPropertyName(<Module>.smethod_26<string>(3014331158U)) : <Module>.smethod_26<string>(3014331158U));
			writer.WriteValue(unionCase.Name);
			if (unionCase.Fields != null && unionCase.Fields.Length > 0)
			{
				object[] array = (object[])unionCase.FieldReader.Invoke(new object[] { value });
				writer.WritePropertyName((defaultContractResolver != null) ? defaultContractResolver.GetResolvedPropertyName(<Module>.smethod_24<string>(2027759949U)) : <Module>.smethod_24<string>(2027759949U));
				writer.WriteStartArray();
				foreach (object obj in array)
				{
					serializer.Serialize(writer, obj);
				}
				writer.WriteEndArray();
			}
			writer.WriteEndObject();
		}

		// Token: 0x06001904 RID: 6404 RVA: 0x000769B4 File Offset: 0x00074BB4
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			DiscriminatedUnionConverter.UnionCase unionCase;
			object[] array;
			object[] array2;
			string text;
			for (;;)
			{
				IL_0345:
				int num = 1804486491;
				for (;;)
				{
					JArray jarray;
					switch (num ^ 1804486466)
					{
					case 0:
						if (reader.TokenType != JsonToken.StartArray)
						{
							goto Block_13;
						}
						goto IL_0182;
					case 1:
						if (reader.TokenType != JsonToken.PropertyName)
						{
							num = ((unionCase != null) ? 1804486493 : 1804486481);
							continue;
						}
						goto IL_021E;
					case 2:
						if (reader.TokenType == JsonToken.Null)
						{
							num = 1804486478;
							continue;
						}
						unionCase = null;
						num = 1804486470;
						continue;
					case 3:
						num = ((unionCase != null) ? 1804486485 : 1804486472);
						continue;
					case 4:
						CS$<>8__locals1.caseName = null;
						jarray = null;
						num = 1804486489;
						continue;
					case 5:
						DiscriminatedUnionConverter.ReadAndAssert(reader);
						num = 1804486466;
						continue;
					case 6:
						goto IL_0360;
					case 7:
						goto IL_021E;
					case 8:
						num = 1804486467;
						continue;
					case 9:
					{
						int num2;
						num = ((num2 < jarray.Count) ? 1804486498 : 1804486473);
						continue;
					}
					case 10:
						goto IL_0381;
					case 11:
						array = new object[1];
						num = 1804486484;
						continue;
					case 12:
						goto IL_03A2;
					case 13:
					{
						DiscriminatedUnionConverter.Union union = DiscriminatedUnionConverter.UnionCache.Get(objectType);
						CS$<>8__locals1.caseName = DiscriminatedUnionConverter.smethod_1(reader.Value);
						num = 1804486486;
						continue;
					}
					case 14:
						num = ((unionCase.Fields.Length == jarray.Count) ? 1804486495 : 1804486468);
						continue;
					case 15:
						goto IL_0182;
					case 16:
					{
						int num2;
						JToken jtoken;
						PropertyInfo propertyInfo;
						array2[num2] = jtoken.ToObject(DiscriminatedUnionConverter.smethod_4(propertyInfo), serializer);
						num = 1804486497;
						continue;
					}
					case 17:
						num = 1804486485;
						continue;
					case 18:
						DiscriminatedUnionConverter.ReadAndAssert(reader);
						num = 1804486479;
						continue;
					case 19:
						goto IL_03A4;
					case 20:
					{
						DiscriminatedUnionConverter.Union union;
						unionCase = union.Cases.SingleOrDefault((DiscriminatedUnionConverter.UnionCase c) => DiscriminatedUnionConverter.<>c__DisplayClass5.smethod_0(c.Name, CS$<>8__locals1.caseName));
						num = 1804486465;
						continue;
					}
					case 21:
						num = (DiscriminatedUnionConverter.smethod_2(text, <Module>.smethod_26<string>(3014331158U), StringComparison.OrdinalIgnoreCase) ? 1804486480 : 1804486496);
						continue;
					case 23:
						DiscriminatedUnionConverter.ReadAndAssert(reader);
						num = 1804486467;
						continue;
					case 24:
						goto IL_03C9;
					case 25:
						num = 1804486464;
						continue;
					case 26:
						if (jarray == null)
						{
							goto Block_4;
						}
						goto IL_003F;
					case 27:
						DiscriminatedUnionConverter.ReadAndAssert(reader);
						num = 1804486474;
						continue;
					case 28:
					{
						int num2;
						PropertyInfo propertyInfo = unionCase.Fields[num2];
						num = 1804486482;
						continue;
					}
					case 29:
					{
						int num2 = 0;
						num = 1804486475;
						continue;
					}
					case 30:
						goto IL_0345;
					case 31:
						array2 = new object[unionCase.Fields.Length];
						num = ((unionCase.Fields.Length <= 0) ? 1804486499 : 1804486488);
						continue;
					case 32:
					{
						int num2;
						JToken jtoken = jarray[num2];
						num = 1804486494;
						continue;
					}
					case 33:
						goto IL_003F;
					case 34:
						num = (DiscriminatedUnionConverter.smethod_2(text, <Module>.smethod_27<string>(1516924360U), StringComparison.OrdinalIgnoreCase) ? 1804486471 : 1804486490);
						continue;
					case 35:
					{
						int num2;
						num2++;
						num = 1804486475;
						continue;
					}
					}
					goto Block_14;
					IL_003F:
					num = ((jarray == null) ? 1804486473 : 1804486476);
					continue;
					IL_0182:
					jarray = (JArray)JToken.ReadFrom(reader);
					num = 1804486483;
					continue;
					IL_021E:
					text = DiscriminatedUnionConverter.smethod_1(reader.Value);
					num = 1804486487;
				}
			}
			Block_4:
			throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(3570198648U).FormatWith(DiscriminatedUnionConverter.smethod_3(), <Module>.smethod_25<string>(3692221663U)));
			Block_13:
			throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(650008521U));
			Block_14:
			goto IL_040B;
			IL_0360:
			throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(19258644U).FormatWith(DiscriminatedUnionConverter.smethod_3(), CS$<>8__locals1.caseName));
			IL_0381:
			throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(770183495U).FormatWith(DiscriminatedUnionConverter.smethod_3(), CS$<>8__locals1.caseName));
			IL_03A2:
			return null;
			IL_03A4:
			throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(998314197U).FormatWith(DiscriminatedUnionConverter.smethod_3(), <Module>.smethod_24<string>(3883848379U)));
			IL_03C9:
			throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(351382035U).FormatWith(DiscriminatedUnionConverter.smethod_3(), text));
			IL_040B:
			array[0] = array2;
			object[] array3 = array;
			return unionCase.Constructor.Invoke(array3);
		}

		// Token: 0x06001905 RID: 6405 RVA: 0x00076DE4 File Offset: 0x00074FE4
		public override bool CanConvert(Type objectType)
		{
			if (DiscriminatedUnionConverter.smethod_6(DiscriminatedUnionConverter.smethod_5(typeof(IEnumerable).TypeHandle), objectType))
			{
				return false;
			}
			object[] array = DiscriminatedUnionConverter.smethod_7(objectType, true);
			bool flag = false;
			foreach (object obj in array)
			{
				Type type = DiscriminatedUnionConverter.smethod_0(obj);
				if (DiscriminatedUnionConverter.smethod_9(DiscriminatedUnionConverter.smethod_8(type), <Module>.smethod_24<string>(1077613321U)))
				{
					FSharpUtils.EnsureInitialized(type.Assembly());
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				return false;
			}
			MethodCall<object, object> isUnion = FSharpUtils.IsUnion;
			object obj2 = null;
			object[] array3 = new object[2];
			array3[0] = objectType;
			return (bool)isUnion(obj2, array3);
		}

		// Token: 0x06001906 RID: 6406 RVA: 0x0001770F File Offset: 0x0001590F
		private static void ReadAndAssert(JsonReader reader)
		{
			if (!reader.Read())
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(10730110U));
			}
		}

		// Token: 0x06001909 RID: 6409 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_0(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x0600190A RID: 6410 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_1(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x0600190B RID: 6411 RVA: 0x000170FF File Offset: 0x000152FF
		static bool smethod_2(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string.Equals(string_0, string_1, stringComparison_0);
		}

		// Token: 0x0600190C RID: 6412 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_3()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x0600190D RID: 6413 RVA: 0x000162CE File Offset: 0x000144CE
		static Type smethod_4(PropertyInfo propertyInfo_0)
		{
			return propertyInfo_0.PropertyType;
		}

		// Token: 0x0600190E RID: 6414 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_5(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x0600190F RID: 6415 RVA: 0x00017625 File Offset: 0x00015825
		static bool smethod_6(Type type_0, Type type_1)
		{
			return type_0.IsAssignableFrom(type_1);
		}

		// Token: 0x06001910 RID: 6416 RVA: 0x00017758 File Offset: 0x00015958
		static object[] smethod_7(MemberInfo memberInfo_0, bool bool_0)
		{
			return memberInfo_0.GetCustomAttributes(bool_0);
		}

		// Token: 0x06001911 RID: 6417 RVA: 0x00017761 File Offset: 0x00015961
		static string smethod_8(Type type_0)
		{
			return type_0.FullName;
		}

		// Token: 0x06001912 RID: 6418 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_9(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x040009A2 RID: 2466
		private const string CasePropertyName = "Case";

		// Token: 0x040009A3 RID: 2467
		private const string FieldsPropertyName = "Fields";

		// Token: 0x040009A4 RID: 2468
		private static readonly ThreadSafeStore<Type, DiscriminatedUnionConverter.Union> UnionCache = new ThreadSafeStore<Type, DiscriminatedUnionConverter.Union>(new Func<Type, DiscriminatedUnionConverter.Union>(DiscriminatedUnionConverter.CreateUnion));

		// Token: 0x040009A5 RID: 2469
		private static readonly ThreadSafeStore<Type, Type> UnionTypeLookupCache = new ThreadSafeStore<Type, Type>(new Func<Type, Type>(DiscriminatedUnionConverter.CreateUnionTypeLookup));

		// Token: 0x020001A6 RID: 422
		internal class Union
		{
			// Token: 0x17000396 RID: 918
			// (get) Token: 0x06001913 RID: 6419 RVA: 0x00017769 File Offset: 0x00015969
			// (set) Token: 0x06001914 RID: 6420 RVA: 0x00017771 File Offset: 0x00015971
			public FSharpFunction TagReader { get; set; }

			// Token: 0x040009A6 RID: 2470
			public List<DiscriminatedUnionConverter.UnionCase> Cases;
		}

		// Token: 0x020001A7 RID: 423
		internal class UnionCase
		{
			// Token: 0x040009A8 RID: 2472
			public int Tag;

			// Token: 0x040009A9 RID: 2473
			public string Name;

			// Token: 0x040009AA RID: 2474
			public PropertyInfo[] Fields;

			// Token: 0x040009AB RID: 2475
			public FSharpFunction FieldReader;

			// Token: 0x040009AC RID: 2476
			public FSharpFunction Constructor;
		}
	}
}
