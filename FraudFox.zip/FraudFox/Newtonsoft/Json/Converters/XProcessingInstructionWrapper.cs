﻿using System;
using System.Xml.Linq;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x0200021F RID: 543
	internal class XProcessingInstructionWrapper : XObjectWrapper
	{
		// Token: 0x1700048A RID: 1162
		// (get) Token: 0x06001E9D RID: 7837 RVA: 0x0001A1C1 File Offset: 0x000183C1
		private XProcessingInstruction ProcessingInstruction
		{
			get
			{
				return (XProcessingInstruction)base.WrappedNode;
			}
		}

		// Token: 0x06001E9E RID: 7838 RVA: 0x00019F56 File Offset: 0x00018156
		public XProcessingInstructionWrapper(XProcessingInstruction processingInstruction)
			: base(processingInstruction)
		{
		}

		// Token: 0x1700048B RID: 1163
		// (get) Token: 0x06001E9F RID: 7839 RVA: 0x0001A1CE File Offset: 0x000183CE
		public override string LocalName
		{
			get
			{
				return XProcessingInstructionWrapper.smethod_2(this.ProcessingInstruction);
			}
		}

		// Token: 0x1700048C RID: 1164
		// (get) Token: 0x06001EA0 RID: 7840 RVA: 0x0001A1DB File Offset: 0x000183DB
		// (set) Token: 0x06001EA1 RID: 7841 RVA: 0x0001A1E8 File Offset: 0x000183E8
		public override string Value
		{
			get
			{
				return XProcessingInstructionWrapper.smethod_3(this.ProcessingInstruction);
			}
			set
			{
				XProcessingInstructionWrapper.smethod_4(this.ProcessingInstruction, value);
			}
		}

		// Token: 0x06001EA2 RID: 7842 RVA: 0x0001A1F6 File Offset: 0x000183F6
		static string smethod_2(XProcessingInstruction xprocessingInstruction_0)
		{
			return xprocessingInstruction_0.Target;
		}

		// Token: 0x06001EA3 RID: 7843 RVA: 0x0001A1FE File Offset: 0x000183FE
		static string smethod_3(XProcessingInstruction xprocessingInstruction_0)
		{
			return xprocessingInstruction_0.Data;
		}

		// Token: 0x06001EA4 RID: 7844 RVA: 0x0001A206 File Offset: 0x00018406
		static void smethod_4(XProcessingInstruction xprocessingInstruction_0, string string_0)
		{
			xprocessingInstruction_0.Data = string_0;
		}
	}
}
