﻿using System;
using System.Globalization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x0200020C RID: 524
	public class IsoDateTimeConverter : DateTimeConverterBase
	{
		// Token: 0x17000446 RID: 1094
		// (get) Token: 0x06001DBA RID: 7610 RVA: 0x000199E5 File Offset: 0x00017BE5
		// (set) Token: 0x06001DBB RID: 7611 RVA: 0x000199ED File Offset: 0x00017BED
		public DateTimeStyles DateTimeStyles
		{
			get
			{
				return this._dateTimeStyles;
			}
			set
			{
				this._dateTimeStyles = value;
			}
		}

		// Token: 0x17000447 RID: 1095
		// (get) Token: 0x06001DBC RID: 7612 RVA: 0x000199F6 File Offset: 0x00017BF6
		// (set) Token: 0x06001DBD RID: 7613 RVA: 0x00019A07 File Offset: 0x00017C07
		public string DateTimeFormat
		{
			get
			{
				return this._dateTimeFormat ?? string.Empty;
			}
			set
			{
				this._dateTimeFormat = StringUtils.NullEmptyString(value);
			}
		}

		// Token: 0x17000448 RID: 1096
		// (get) Token: 0x06001DBE RID: 7614 RVA: 0x00019A15 File Offset: 0x00017C15
		// (set) Token: 0x06001DBF RID: 7615 RVA: 0x00019A26 File Offset: 0x00017C26
		public CultureInfo Culture
		{
			get
			{
				return this._culture ?? IsoDateTimeConverter.smethod_2();
			}
			set
			{
				this._culture = value;
			}
		}

		// Token: 0x06001DC0 RID: 7616 RVA: 0x0008155C File Offset: 0x0007F75C
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			string text;
			if (value is DateTime)
			{
				DateTime dateTime = (DateTime)value;
				if ((this._dateTimeStyles & DateTimeStyles.AdjustToUniversal) == DateTimeStyles.AdjustToUniversal || (this._dateTimeStyles & DateTimeStyles.AssumeUniversal) == DateTimeStyles.AssumeUniversal)
				{
					dateTime = dateTime.ToUniversalTime();
				}
				text = dateTime.ToString(this._dateTimeFormat ?? <Module>.smethod_24<string>(2565836880U), this.Culture);
			}
			else
			{
				if (!(value is DateTimeOffset))
				{
					throw new JsonSerializationException(<Module>.smethod_25<string>(2312302934U).FormatWith(CultureInfo.InvariantCulture, ReflectionUtils.GetObjectType(value)));
				}
				DateTimeOffset dateTimeOffset = (DateTimeOffset)value;
				if ((this._dateTimeStyles & DateTimeStyles.AdjustToUniversal) == DateTimeStyles.AdjustToUniversal || (this._dateTimeStyles & DateTimeStyles.AssumeUniversal) == DateTimeStyles.AssumeUniversal)
				{
					dateTimeOffset = dateTimeOffset.ToUniversalTime();
				}
				text = dateTimeOffset.ToString(this._dateTimeFormat ?? <Module>.smethod_24<string>(2565836880U), this.Culture);
			}
			writer.WriteValue(text);
		}

		// Token: 0x06001DC1 RID: 7617 RVA: 0x00081640 File Offset: 0x0007F840
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			bool flag = ReflectionUtils.IsNullableType(objectType);
			string text;
			Type type2;
			for (;;)
			{
				IL_0113:
				int num = -1639102432;
				for (;;)
				{
					Type type;
					switch (num ^ -1639102425)
					{
					case 0:
						goto IL_011A;
					case 1:
						goto IL_011C;
					case 2:
						if (flag)
						{
							goto Block_10;
						}
						goto IL_0088;
					case 3:
						if (!string.IsNullOrEmpty(this._dateTimeFormat))
						{
							num = -1639102418;
							continue;
						}
						goto IL_0144;
					case 4:
						goto IL_015C;
					case 5:
						type = objectType;
						goto IL_001F;
					case 6:
						text = reader.Value.ToString();
						if (string.IsNullOrEmpty(text))
						{
							num = -1639102427;
							continue;
						}
						goto IL_0088;
					case 7:
						if (!flag)
						{
							num = -1639102430;
							continue;
						}
						type = IsoDateTimeConverter.smethod_3(objectType);
						goto IL_001F;
					case 9:
						goto IL_0217;
					case 10:
						goto IL_0113;
					}
					goto Block_11;
					IL_001F:
					type2 = type;
					if (reader.TokenType == JsonToken.Null)
					{
						num = ((!ReflectionUtils.IsNullableType(objectType)) ? (-1639102429) : (-1639102425));
						continue;
					}
					if (reader.TokenType == JsonToken.Date)
					{
						goto Block_4;
					}
					num = ((reader.TokenType != JsonToken.String) ? (-1639102426) : (-1639102431));
					continue;
					IL_0088:
					if (type2 == typeof(DateTimeOffset))
					{
						num = -1639102428;
					}
					else
					{
						if (string.IsNullOrEmpty(this._dateTimeFormat))
						{
							goto IL_0178;
						}
						num = -1639102417;
					}
				}
			}
			Block_4:
			if (IsoDateTimeConverter.smethod_6(type2, IsoDateTimeConverter.smethod_5(typeof(DateTimeOffset).TypeHandle)))
			{
				if (!(reader.Value is DateTimeOffset))
				{
					return new DateTimeOffset((DateTime)reader.Value);
				}
				return reader.Value;
			}
			else
			{
				if (reader.Value is DateTimeOffset)
				{
					return ((DateTimeOffset)reader.Value).DateTime;
				}
				return reader.Value;
			}
			Block_10:
			return null;
			Block_11:
			goto IL_01F9;
			IL_011A:
			return null;
			IL_011C:
			throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(1814418511U).FormatWith(CultureInfo.InvariantCulture, reader.TokenType));
			IL_0144:
			return DateTimeOffset.Parse(text, this.Culture, this._dateTimeStyles);
			IL_015C:
			throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(3906173783U).FormatWith(IsoDateTimeConverter.smethod_4(), objectType));
			IL_0178:
			return DateTime.Parse(text, this.Culture, this._dateTimeStyles);
			IL_01F9:
			return DateTime.ParseExact(text, this._dateTimeFormat, this.Culture, this._dateTimeStyles);
			IL_0217:
			return DateTimeOffset.ParseExact(text, this._dateTimeFormat, this.Culture, this._dateTimeStyles);
		}

		// Token: 0x06001DC3 RID: 7619 RVA: 0x00019275 File Offset: 0x00017475
		static CultureInfo smethod_2()
		{
			return CultureInfo.CurrentCulture;
		}

		// Token: 0x06001DC4 RID: 7620 RVA: 0x000175B6 File Offset: 0x000157B6
		static Type smethod_3(Type type_0)
		{
			return Nullable.GetUnderlyingType(type_0);
		}

		// Token: 0x06001DC5 RID: 7621 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_4()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001DC6 RID: 7622 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_5(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001DC7 RID: 7623 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_6(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x04000B69 RID: 2921
		private const string DefaultDateTimeFormat = "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK";

		// Token: 0x04000B6A RID: 2922
		private DateTimeStyles _dateTimeStyles = DateTimeStyles.RoundtripKind;

		// Token: 0x04000B6B RID: 2923
		private string _dateTimeFormat;

		// Token: 0x04000B6C RID: 2924
		private CultureInfo _culture;
	}
}
