﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x020001A2 RID: 418
	public class DataTableConverter : JsonConverter
	{
		// Token: 0x060018D2 RID: 6354 RVA: 0x00076164 File Offset: 0x00074364
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			DataTable dataTable = (DataTable)value;
			DefaultContractResolver defaultContractResolver = serializer.ContractResolver as DefaultContractResolver;
			writer.WriteStartArray();
			IEnumerator enumerator = DataTableConverter.smethod_1(DataTableConverter.smethod_0(dataTable));
			try
			{
				while (DataTableConverter.smethod_7(enumerator))
				{
					DataRow dataRow = (DataRow)DataTableConverter.smethod_2(enumerator);
					writer.WriteStartObject();
					IEnumerator enumerator2 = DataTableConverter.smethod_1(DataTableConverter.smethod_4(DataTableConverter.smethod_3(dataRow)));
					try
					{
						while (DataTableConverter.smethod_7(enumerator2))
						{
							DataColumn dataColumn = (DataColumn)DataTableConverter.smethod_2(enumerator2);
							object obj = DataTableConverter.smethod_5(dataRow, dataColumn);
							if (serializer.NullValueHandling == NullValueHandling.Ignore)
							{
								if (obj == null || obj == DBNull.Value)
								{
									continue;
								}
							}
							writer.WritePropertyName((defaultContractResolver != null) ? defaultContractResolver.GetResolvedPropertyName(DataTableConverter.smethod_6(dataColumn)) : DataTableConverter.smethod_6(dataColumn));
							serializer.Serialize(writer, obj);
						}
					}
					finally
					{
						IDisposable disposable = enumerator2 as IDisposable;
						if (disposable != null)
						{
							DataTableConverter.smethod_8(disposable);
						}
					}
					writer.WriteEndObject();
				}
			}
			finally
			{
				IDisposable disposable2 = enumerator as IDisposable;
				if (disposable2 != null)
				{
					DataTableConverter.smethod_8(disposable2);
				}
			}
			writer.WriteEndArray();
		}

		// Token: 0x060018D3 RID: 6355 RVA: 0x00076284 File Offset: 0x00074484
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			DataTable dataTable = existingValue as DataTable;
			for (;;)
			{
				IL_010C:
				int num = 1300196726;
				for (;;)
				{
					DataTable dataTable2;
					switch (num ^ 1300196727)
					{
					case 0:
						if (!DataTableConverter.smethod_10(objectType, DataTableConverter.smethod_9(typeof(DataTable).TypeHandle)))
						{
							num = 1300196733;
							continue;
						}
						dataTable2 = DataTableConverter.smethod_12();
						break;
					case 1:
						num = ((dataTable != null) ? 1300196724 : 1300196727);
						continue;
					case 2:
						goto IL_0085;
					case 3:
						if (reader.TokenType == JsonToken.PropertyName)
						{
							DataTableConverter.smethod_13(dataTable, (string)reader.Value);
							num = 1300196734;
							continue;
						}
						goto IL_0085;
					case 4:
						goto IL_0041;
					case 5:
						goto IL_0113;
					case 6:
						DataTableConverter.CheckedRead(reader);
						num = 1300196735;
						continue;
					case 7:
						goto IL_010C;
					case 8:
						goto IL_0032;
					case 9:
						DataTableConverter.CheckedRead(reader);
						num = 1300196725;
						continue;
					case 10:
						dataTable2 = (DataTable)DataTableConverter.smethod_11(objectType);
						break;
					default:
						goto IL_0032;
					}
					dataTable = dataTable2;
					num = 1300196724;
					continue;
					IL_0041:
					DataTableConverter.CreateRow(reader, dataTable, serializer);
					DataTableConverter.CheckedRead(reader);
					num = 1300196735;
					continue;
					IL_0032:
					if (reader.TokenType == JsonToken.EndArray)
					{
						return dataTable;
					}
					goto IL_0041;
					IL_0085:
					num = ((reader.TokenType == JsonToken.StartArray) ? 1300196721 : 1300196722);
				}
			}
			return dataTable;
			IL_0113:
			throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(1793034630U).FormatWith(DataTableConverter.smethod_14(), reader.TokenType));
		}

		// Token: 0x060018D4 RID: 6356 RVA: 0x000763CC File Offset: 0x000745CC
		private static void CreateRow(JsonReader reader, DataTable dt, JsonSerializer serializer)
		{
			DataRow dataRow = DataTableConverter.smethod_15(dt);
			DataTableConverter.CheckedRead(reader);
			while (reader.TokenType == JsonToken.PropertyName)
			{
				string text = (string)reader.Value;
				DataTableConverter.CheckedRead(reader);
				DataColumn dataColumn = DataTableConverter.smethod_16(DataTableConverter.smethod_4(dt), text);
				if (dataColumn == null)
				{
					Type columnDataType = DataTableConverter.GetColumnDataType(reader);
					dataColumn = DataTableConverter.smethod_17(text, columnDataType);
					DataTableConverter.smethod_18(DataTableConverter.smethod_4(dt), dataColumn);
				}
				if (!DataTableConverter.smethod_10(DataTableConverter.smethod_19(dataColumn), DataTableConverter.smethod_9(typeof(DataTable).TypeHandle)))
				{
					if (DataTableConverter.smethod_21(DataTableConverter.smethod_19(dataColumn)) && DataTableConverter.smethod_22(DataTableConverter.smethod_19(dataColumn), DataTableConverter.smethod_9(typeof(byte[]).TypeHandle)))
					{
						if (reader.TokenType == JsonToken.StartArray)
						{
							DataTableConverter.CheckedRead(reader);
						}
						List<object> list = new List<object>();
						while (reader.TokenType != JsonToken.EndArray)
						{
							list.Add(reader.Value);
							DataTableConverter.CheckedRead(reader);
						}
						Array array = DataTableConverter.smethod_24(DataTableConverter.smethod_23(DataTableConverter.smethod_19(dataColumn)), list.Count);
						DataTableConverter.smethod_25(list.ToArray(), array, list.Count);
						DataTableConverter.smethod_20(dataRow, text, array);
					}
					else
					{
						DataTableConverter.smethod_20(dataRow, text, (reader.Value != null) ? serializer.Deserialize(reader, DataTableConverter.smethod_19(dataColumn)) : DBNull.Value);
					}
				}
				else
				{
					if (reader.TokenType == JsonToken.StartArray)
					{
						DataTableConverter.CheckedRead(reader);
					}
					DataTable dataTable = DataTableConverter.smethod_12();
					while (reader.TokenType != JsonToken.EndArray)
					{
						DataTableConverter.CreateRow(reader, dataTable, serializer);
						DataTableConverter.CheckedRead(reader);
					}
					DataTableConverter.smethod_20(dataRow, text, dataTable);
				}
				DataTableConverter.CheckedRead(reader);
			}
			DataTableConverter.smethod_26(dataRow);
			DataTableConverter.smethod_27(DataTableConverter.smethod_0(dt), dataRow);
		}

		// Token: 0x060018D5 RID: 6357 RVA: 0x00076560 File Offset: 0x00074760
		private static Type GetColumnDataType(JsonReader reader)
		{
			JsonToken tokenType = reader.TokenType;
			switch (tokenType)
			{
			case JsonToken.StartArray:
			{
				DataTableConverter.CheckedRead(reader);
				if (reader.TokenType == JsonToken.StartObject)
				{
					return DataTableConverter.smethod_9(typeof(DataTable).TypeHandle);
				}
				Type columnDataType = DataTableConverter.GetColumnDataType(reader);
				return DataTableConverter.smethod_28(columnDataType);
			}
			case JsonToken.Integer:
			case JsonToken.Float:
			case JsonToken.String:
			case JsonToken.Boolean:
			case JsonToken.Date:
			case JsonToken.Bytes:
				return reader.ValueType;
			case JsonToken.Null:
			case JsonToken.Undefined:
				return DataTableConverter.smethod_9(typeof(string).TypeHandle);
			}
			throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(1920042827U).FormatWith(DataTableConverter.smethod_14(), tokenType));
		}

		// Token: 0x060018D6 RID: 6358 RVA: 0x0001762E File Offset: 0x0001582E
		private static void CheckedRead(JsonReader reader)
		{
			if (!reader.Read())
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(524292769U));
			}
		}

		// Token: 0x060018D7 RID: 6359 RVA: 0x00017649 File Offset: 0x00015849
		public override bool CanConvert(Type valueType)
		{
			return DataTableConverter.smethod_29(DataTableConverter.smethod_9(typeof(DataTable).TypeHandle), valueType);
		}

		// Token: 0x060018D9 RID: 6361 RVA: 0x0001765B File Offset: 0x0001585B
		static DataRowCollection smethod_0(DataTable dataTable_0)
		{
			return dataTable_0.Rows;
		}

		// Token: 0x060018DA RID: 6362 RVA: 0x000175FC File Offset: 0x000157FC
		static IEnumerator smethod_1(InternalDataCollectionBase internalDataCollectionBase_0)
		{
			return internalDataCollectionBase_0.GetEnumerator();
		}

		// Token: 0x060018DB RID: 6363 RVA: 0x0000D8E2 File Offset: 0x0000BAE2
		static object smethod_2(IEnumerator ienumerator_0)
		{
			return ienumerator_0.Current;
		}

		// Token: 0x060018DC RID: 6364 RVA: 0x00017663 File Offset: 0x00015863
		static DataTable smethod_3(DataRow dataRow_0)
		{
			return dataRow_0.Table;
		}

		// Token: 0x060018DD RID: 6365 RVA: 0x0001766B File Offset: 0x0001586B
		static DataColumnCollection smethod_4(DataTable dataTable_0)
		{
			return dataTable_0.Columns;
		}

		// Token: 0x060018DE RID: 6366 RVA: 0x00017673 File Offset: 0x00015873
		static object smethod_5(DataRow dataRow_0, DataColumn dataColumn_0)
		{
			return dataRow_0[dataColumn_0];
		}

		// Token: 0x060018DF RID: 6367 RVA: 0x0001767C File Offset: 0x0001587C
		static string smethod_6(DataColumn dataColumn_0)
		{
			return dataColumn_0.ColumnName;
		}

		// Token: 0x060018E0 RID: 6368 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_7(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060018E1 RID: 6369 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_8(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060018E2 RID: 6370 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_9(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060018E3 RID: 6371 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_10(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x060018E4 RID: 6372 RVA: 0x0001630C File Offset: 0x0001450C
		static object smethod_11(Type type_0)
		{
			return Activator.CreateInstance(type_0);
		}

		// Token: 0x060018E5 RID: 6373 RVA: 0x00017684 File Offset: 0x00015884
		static DataTable smethod_12()
		{
			return new DataTable();
		}

		// Token: 0x060018E6 RID: 6374 RVA: 0x0001768B File Offset: 0x0001588B
		static void smethod_13(DataTable dataTable_0, string string_0)
		{
			dataTable_0.TableName = string_0;
		}

		// Token: 0x060018E7 RID: 6375 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_14()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060018E8 RID: 6376 RVA: 0x00017694 File Offset: 0x00015894
		static DataRow smethod_15(DataTable dataTable_0)
		{
			return dataTable_0.NewRow();
		}

		// Token: 0x060018E9 RID: 6377 RVA: 0x0001769C File Offset: 0x0001589C
		static DataColumn smethod_16(DataColumnCollection dataColumnCollection_0, string string_0)
		{
			return dataColumnCollection_0[string_0];
		}

		// Token: 0x060018EA RID: 6378 RVA: 0x000176A5 File Offset: 0x000158A5
		static DataColumn smethod_17(string string_0, Type type_0)
		{
			return new DataColumn(string_0, type_0);
		}

		// Token: 0x060018EB RID: 6379 RVA: 0x000176AE File Offset: 0x000158AE
		static void smethod_18(DataColumnCollection dataColumnCollection_0, DataColumn dataColumn_0)
		{
			dataColumnCollection_0.Add(dataColumn_0);
		}

		// Token: 0x060018EC RID: 6380 RVA: 0x000176B7 File Offset: 0x000158B7
		static Type smethod_19(DataColumn dataColumn_0)
		{
			return dataColumn_0.DataType;
		}

		// Token: 0x060018ED RID: 6381 RVA: 0x000176BF File Offset: 0x000158BF
		static void smethod_20(DataRow dataRow_0, string string_0, object object_0)
		{
			dataRow_0[string_0] = object_0;
		}

		// Token: 0x060018EE RID: 6382 RVA: 0x00015F2C File Offset: 0x0001412C
		static bool smethod_21(Type type_0)
		{
			return type_0.IsArray;
		}

		// Token: 0x060018EF RID: 6383 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_22(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x060018F0 RID: 6384 RVA: 0x00015F34 File Offset: 0x00014134
		static Type smethod_23(Type type_0)
		{
			return type_0.GetElementType();
		}

		// Token: 0x060018F1 RID: 6385 RVA: 0x000162DF File Offset: 0x000144DF
		static Array smethod_24(Type type_0, int int_0)
		{
			return Array.CreateInstance(type_0, int_0);
		}

		// Token: 0x060018F2 RID: 6386 RVA: 0x000176C9 File Offset: 0x000158C9
		static void smethod_25(Array array_0, Array array_1, int int_0)
		{
			Array.Copy(array_0, array_1, int_0);
		}

		// Token: 0x060018F3 RID: 6387 RVA: 0x000176D3 File Offset: 0x000158D3
		static void smethod_26(DataRow dataRow_0)
		{
			dataRow_0.EndEdit();
		}

		// Token: 0x060018F4 RID: 6388 RVA: 0x000176DB File Offset: 0x000158DB
		static void smethod_27(DataRowCollection dataRowCollection_0, DataRow dataRow_0)
		{
			dataRowCollection_0.Add(dataRow_0);
		}

		// Token: 0x060018F5 RID: 6389 RVA: 0x000176E4 File Offset: 0x000158E4
		static Type smethod_28(Type type_0)
		{
			return type_0.MakeArrayType();
		}

		// Token: 0x060018F6 RID: 6390 RVA: 0x00017625 File Offset: 0x00015825
		static bool smethod_29(Type type_0, Type type_1)
		{
			return type_0.IsAssignableFrom(type_1);
		}
	}
}
