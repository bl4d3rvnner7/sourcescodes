﻿using System;
using System.Xml;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x02000213 RID: 531
	internal class XmlElementWrapper : XmlNodeWrapper, IXmlNode, IXmlElement
	{
		// Token: 0x06001E1C RID: 7708 RVA: 0x00019CDB File Offset: 0x00017EDB
		public XmlElementWrapper(XmlElement element)
			: base(element)
		{
			this._element = element;
		}

		// Token: 0x06001E1D RID: 7709 RVA: 0x00081B64 File Offset: 0x0007FD64
		public void SetAttributeNode(IXmlNode attribute)
		{
			XmlNodeWrapper xmlNodeWrapper = (XmlNodeWrapper)attribute;
			XmlElementWrapper.smethod_10(this._element, (XmlAttribute)xmlNodeWrapper.WrappedNode);
		}

		// Token: 0x06001E1E RID: 7710 RVA: 0x00019CEB File Offset: 0x00017EEB
		public string GetPrefixOfNamespace(string namespaceUri)
		{
			return XmlElementWrapper.smethod_11(this._element, namespaceUri);
		}

		// Token: 0x1700045C RID: 1116
		// (get) Token: 0x06001E1F RID: 7711 RVA: 0x00019CF9 File Offset: 0x00017EF9
		public bool IsEmpty
		{
			get
			{
				return XmlElementWrapper.smethod_12(this._element);
			}
		}

		// Token: 0x06001E20 RID: 7712 RVA: 0x00019D06 File Offset: 0x00017F06
		static XmlAttribute smethod_10(XmlElement xmlElement_0, XmlAttribute xmlAttribute_0)
		{
			return xmlElement_0.SetAttributeNode(xmlAttribute_0);
		}

		// Token: 0x06001E21 RID: 7713 RVA: 0x00019D0F File Offset: 0x00017F0F
		static string smethod_11(XmlNode xmlNode_0, string string_0)
		{
			return xmlNode_0.GetPrefixOfNamespace(string_0);
		}

		// Token: 0x06001E22 RID: 7714 RVA: 0x00019D18 File Offset: 0x00017F18
		static bool smethod_12(XmlElement xmlElement_0)
		{
			return xmlElement_0.IsEmpty;
		}

		// Token: 0x04000B70 RID: 2928
		private readonly XmlElement _element;
	}
}
