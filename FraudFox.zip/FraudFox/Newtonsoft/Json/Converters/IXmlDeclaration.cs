﻿using System;

namespace Newtonsoft.Json.Converters
{
	// Token: 0x02000214 RID: 532
	internal interface IXmlDeclaration : IXmlNode
	{
		// Token: 0x1700045D RID: 1117
		// (get) Token: 0x06001E23 RID: 7715
		string Version { get; }

		// Token: 0x1700045E RID: 1118
		// (get) Token: 0x06001E24 RID: 7716
		// (set) Token: 0x06001E25 RID: 7717
		string Encoding { get; set; }

		// Token: 0x1700045F RID: 1119
		// (get) Token: 0x06001E26 RID: 7718
		// (set) Token: 0x06001E27 RID: 7719
		string Standalone { get; set; }
	}
}
