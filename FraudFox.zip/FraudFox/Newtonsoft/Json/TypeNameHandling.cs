﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020002B7 RID: 695
	[Flags]
	public enum TypeNameHandling
	{
		// Token: 0x04000DEA RID: 3562
		None = 0,
		// Token: 0x04000DEB RID: 3563
		Objects = 1,
		// Token: 0x04000DEC RID: 3564
		Arrays = 2,
		// Token: 0x04000DED RID: 3565
		All = 3,
		// Token: 0x04000DEE RID: 3566
		Auto = 4
	}
}
