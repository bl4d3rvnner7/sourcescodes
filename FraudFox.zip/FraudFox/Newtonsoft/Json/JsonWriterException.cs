﻿using System;
using System.Runtime.Serialization;

namespace Newtonsoft.Json
{
	// Token: 0x0200022B RID: 555
	[Serializable]
	public class JsonWriterException : JsonException
	{
		// Token: 0x170004B0 RID: 1200
		// (get) Token: 0x06001FB9 RID: 8121 RVA: 0x0001AC6F File Offset: 0x00018E6F
		// (set) Token: 0x06001FBA RID: 8122 RVA: 0x0001AC77 File Offset: 0x00018E77
		public string Path { get; private set; }

		// Token: 0x06001FBB RID: 8123 RVA: 0x0001AC80 File Offset: 0x00018E80
		public JsonWriterException()
		{
		}

		// Token: 0x06001FBC RID: 8124 RVA: 0x0001AC88 File Offset: 0x00018E88
		public JsonWriterException(string message)
			: base(message)
		{
		}

		// Token: 0x06001FBD RID: 8125 RVA: 0x0001AC91 File Offset: 0x00018E91
		public JsonWriterException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

		// Token: 0x06001FBE RID: 8126 RVA: 0x0001AC9B File Offset: 0x00018E9B
		public JsonWriterException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x06001FBF RID: 8127 RVA: 0x0001ACA5 File Offset: 0x00018EA5
		internal JsonWriterException(string message, Exception innerException, string path)
			: base(message, innerException)
		{
			this.Path = path;
		}

		// Token: 0x06001FC0 RID: 8128 RVA: 0x0001ACB6 File Offset: 0x00018EB6
		internal static JsonWriterException Create(JsonWriter writer, string message, Exception ex)
		{
			return JsonWriterException.Create(writer.ContainerPath, message, ex);
		}

		// Token: 0x06001FC1 RID: 8129 RVA: 0x0001ACC5 File Offset: 0x00018EC5
		internal static JsonWriterException Create(string path, string message, Exception ex)
		{
			message = JsonPosition.FormatMessage(null, path, message);
			return new JsonWriterException(message, ex, path);
		}
	}
}
