﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000204 RID: 516
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Interface, AllowMultiple = false)]
	public sealed class JsonObjectAttribute : JsonContainerAttribute
	{
		// Token: 0x17000412 RID: 1042
		// (get) Token: 0x06001D11 RID: 7441 RVA: 0x00019554 File Offset: 0x00017754
		// (set) Token: 0x06001D12 RID: 7442 RVA: 0x0001955C File Offset: 0x0001775C
		public MemberSerialization MemberSerialization
		{
			get
			{
				return this._memberSerialization;
			}
			set
			{
				this._memberSerialization = value;
			}
		}

		// Token: 0x17000413 RID: 1043
		// (get) Token: 0x06001D13 RID: 7443 RVA: 0x0007F88C File Offset: 0x0007DA8C
		// (set) Token: 0x06001D14 RID: 7444 RVA: 0x00019565 File Offset: 0x00017765
		public Required ItemRequired
		{
			get
			{
				Required? itemRequired = this._itemRequired;
				if (itemRequired == null)
				{
					return Required.Default;
				}
				return itemRequired.GetValueOrDefault();
			}
			set
			{
				this._itemRequired = new Required?(value);
			}
		}

		// Token: 0x06001D15 RID: 7445 RVA: 0x000179F3 File Offset: 0x00015BF3
		public JsonObjectAttribute()
		{
		}

		// Token: 0x06001D16 RID: 7446 RVA: 0x00019573 File Offset: 0x00017773
		public JsonObjectAttribute(MemberSerialization memberSerialization)
		{
			this.MemberSerialization = memberSerialization;
		}

		// Token: 0x06001D17 RID: 7447 RVA: 0x000179FB File Offset: 0x00015BFB
		public JsonObjectAttribute(string id)
			: base(id)
		{
		}

		// Token: 0x04000B10 RID: 2832
		private MemberSerialization _memberSerialization;

		// Token: 0x04000B11 RID: 2833
		internal Required? _itemRequired;
	}
}
