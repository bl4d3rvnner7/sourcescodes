﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000202 RID: 514
	[Flags]
	public enum DefaultValueHandling
	{
		// Token: 0x04000B0A RID: 2826
		Include = 0,
		// Token: 0x04000B0B RID: 2827
		Ignore = 1,
		// Token: 0x04000B0C RID: 2828
		Populate = 2,
		// Token: 0x04000B0D RID: 2829
		IgnoreAndPopulate = 3
	}
}
