﻿using System;
using System.Runtime.Serialization;

namespace Newtonsoft.Json
{
	// Token: 0x02000233 RID: 563
	[Serializable]
	public class JsonSerializationException : JsonException
	{
		// Token: 0x0600203A RID: 8250 RVA: 0x0001AC80 File Offset: 0x00018E80
		public JsonSerializationException()
		{
		}

		// Token: 0x0600203B RID: 8251 RVA: 0x0001AC88 File Offset: 0x00018E88
		public JsonSerializationException(string message)
			: base(message)
		{
		}

		// Token: 0x0600203C RID: 8252 RVA: 0x0001AC91 File Offset: 0x00018E91
		public JsonSerializationException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

		// Token: 0x0600203D RID: 8253 RVA: 0x0001AC9B File Offset: 0x00018E9B
		public JsonSerializationException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x0600203E RID: 8254 RVA: 0x0001B0EA File Offset: 0x000192EA
		internal static JsonSerializationException Create(JsonReader reader, string message)
		{
			return JsonSerializationException.Create(reader, message, null);
		}

		// Token: 0x0600203F RID: 8255 RVA: 0x0001B0F4 File Offset: 0x000192F4
		internal static JsonSerializationException Create(JsonReader reader, string message, Exception ex)
		{
			return JsonSerializationException.Create(reader as IJsonLineInfo, reader.Path, message, ex);
		}

		// Token: 0x06002040 RID: 8256 RVA: 0x0001B109 File Offset: 0x00019309
		internal static JsonSerializationException Create(IJsonLineInfo lineInfo, string path, string message, Exception ex)
		{
			message = JsonPosition.FormatMessage(lineInfo, path, message);
			return new JsonSerializationException(message, ex);
		}
	}
}
