﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200026A RID: 618
	public enum MissingMemberHandling
	{
		// Token: 0x04000CD9 RID: 3289
		Ignore,
		// Token: 0x04000CDA RID: 3290
		Error
	}
}
