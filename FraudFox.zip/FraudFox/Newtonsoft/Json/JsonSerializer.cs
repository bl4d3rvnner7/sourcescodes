﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Threading;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json
{
	// Token: 0x02000234 RID: 564
	public class JsonSerializer
	{
		// Token: 0x14000027 RID: 39
		// (add) Token: 0x06002041 RID: 8257 RVA: 0x000862CC File Offset: 0x000844CC
		// (remove) Token: 0x06002042 RID: 8258 RVA: 0x00086308 File Offset: 0x00084508
		public virtual event EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs> Error
		{
			add
			{
				EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs> eventHandler = this.Error;
				EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs> eventHandler3 = (EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs>)JsonSerializer.smethod_0(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs>>(ref this.Error, eventHandler3, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs> eventHandler = this.Error;
				EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs> eventHandler3 = (EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs>)JsonSerializer.smethod_1(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs>>(ref this.Error, eventHandler3, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x170004B5 RID: 1205
		// (get) Token: 0x06002043 RID: 8259 RVA: 0x0001B11C File Offset: 0x0001931C
		// (set) Token: 0x06002044 RID: 8260 RVA: 0x0001B124 File Offset: 0x00019324
		public virtual IReferenceResolver ReferenceResolver
		{
			get
			{
				return this.GetReferenceResolver();
			}
			set
			{
				if (value == null)
				{
					throw JsonSerializer.smethod_2(<Module>.smethod_25<string>(3622406065U), <Module>.smethod_23<string>(433483422U));
				}
				this._referenceResolver = value;
			}
		}

		// Token: 0x170004B6 RID: 1206
		// (get) Token: 0x06002045 RID: 8261 RVA: 0x0001B14A File Offset: 0x0001934A
		// (set) Token: 0x06002046 RID: 8262 RVA: 0x0001B152 File Offset: 0x00019352
		public virtual SerializationBinder Binder
		{
			get
			{
				return this._binder;
			}
			set
			{
				if (value == null)
				{
					throw JsonSerializer.smethod_2(<Module>.smethod_23<string>(2033612370U), <Module>.smethod_23<string>(395855172U));
				}
				this._binder = value;
			}
		}

		// Token: 0x170004B7 RID: 1207
		// (get) Token: 0x06002047 RID: 8263 RVA: 0x0001B178 File Offset: 0x00019378
		// (set) Token: 0x06002048 RID: 8264 RVA: 0x0001B180 File Offset: 0x00019380
		public virtual ITraceWriter TraceWriter
		{
			get
			{
				return this._traceWriter;
			}
			set
			{
				this._traceWriter = value;
			}
		}

		// Token: 0x170004B8 RID: 1208
		// (get) Token: 0x06002049 RID: 8265 RVA: 0x0001B189 File Offset: 0x00019389
		// (set) Token: 0x0600204A RID: 8266 RVA: 0x0001B191 File Offset: 0x00019391
		public virtual IEqualityComparer EqualityComparer
		{
			get
			{
				return this._equalityComparer;
			}
			set
			{
				this._equalityComparer = value;
			}
		}

		// Token: 0x170004B9 RID: 1209
		// (get) Token: 0x0600204B RID: 8267 RVA: 0x0001B19A File Offset: 0x0001939A
		// (set) Token: 0x0600204C RID: 8268 RVA: 0x0001B1A2 File Offset: 0x000193A2
		public virtual TypeNameHandling TypeNameHandling
		{
			get
			{
				return this._typeNameHandling;
			}
			set
			{
				if (value < TypeNameHandling.None || value > TypeNameHandling.Auto)
				{
					throw JsonSerializer.smethod_3(<Module>.smethod_27<string>(2371252898U));
				}
				this._typeNameHandling = value;
			}
		}

		// Token: 0x170004BA RID: 1210
		// (get) Token: 0x0600204D RID: 8269 RVA: 0x0001B1C3 File Offset: 0x000193C3
		// (set) Token: 0x0600204E RID: 8270 RVA: 0x0001B1CB File Offset: 0x000193CB
		public virtual FormatterAssemblyStyle TypeNameAssemblyFormat
		{
			get
			{
				return this._typeNameAssemblyFormat;
			}
			set
			{
				if (value < FormatterAssemblyStyle.Simple || value > FormatterAssemblyStyle.Full)
				{
					throw JsonSerializer.smethod_3(<Module>.smethod_26<string>(1806306238U));
				}
				this._typeNameAssemblyFormat = value;
			}
		}

		// Token: 0x170004BB RID: 1211
		// (get) Token: 0x0600204F RID: 8271 RVA: 0x0001B1EC File Offset: 0x000193EC
		// (set) Token: 0x06002050 RID: 8272 RVA: 0x0001B1F4 File Offset: 0x000193F4
		public virtual PreserveReferencesHandling PreserveReferencesHandling
		{
			get
			{
				return this._preserveReferencesHandling;
			}
			set
			{
				if (value < PreserveReferencesHandling.None || value > PreserveReferencesHandling.All)
				{
					throw JsonSerializer.smethod_3(<Module>.smethod_25<string>(3622406065U));
				}
				this._preserveReferencesHandling = value;
			}
		}

		// Token: 0x170004BC RID: 1212
		// (get) Token: 0x06002051 RID: 8273 RVA: 0x0001B215 File Offset: 0x00019415
		// (set) Token: 0x06002052 RID: 8274 RVA: 0x0001B21D File Offset: 0x0001941D
		public virtual ReferenceLoopHandling ReferenceLoopHandling
		{
			get
			{
				return this._referenceLoopHandling;
			}
			set
			{
				if (value < ReferenceLoopHandling.Error || value > ReferenceLoopHandling.Serialize)
				{
					throw JsonSerializer.smethod_3(<Module>.smethod_23<string>(2033612370U));
				}
				this._referenceLoopHandling = value;
			}
		}

		// Token: 0x170004BD RID: 1213
		// (get) Token: 0x06002053 RID: 8275 RVA: 0x0001B23E File Offset: 0x0001943E
		// (set) Token: 0x06002054 RID: 8276 RVA: 0x0001B246 File Offset: 0x00019446
		public virtual MissingMemberHandling MissingMemberHandling
		{
			get
			{
				return this._missingMemberHandling;
			}
			set
			{
				if (value < MissingMemberHandling.Ignore || value > MissingMemberHandling.Error)
				{
					throw JsonSerializer.smethod_3(<Module>.smethod_26<string>(1806306238U));
				}
				this._missingMemberHandling = value;
			}
		}

		// Token: 0x170004BE RID: 1214
		// (get) Token: 0x06002055 RID: 8277 RVA: 0x0001B267 File Offset: 0x00019467
		// (set) Token: 0x06002056 RID: 8278 RVA: 0x0001B26F File Offset: 0x0001946F
		public virtual NullValueHandling NullValueHandling
		{
			get
			{
				return this._nullValueHandling;
			}
			set
			{
				if (value < NullValueHandling.Include || value > NullValueHandling.Ignore)
				{
					throw JsonSerializer.smethod_3(<Module>.smethod_27<string>(2371252898U));
				}
				this._nullValueHandling = value;
			}
		}

		// Token: 0x170004BF RID: 1215
		// (get) Token: 0x06002057 RID: 8279 RVA: 0x0001B290 File Offset: 0x00019490
		// (set) Token: 0x06002058 RID: 8280 RVA: 0x0001B298 File Offset: 0x00019498
		public virtual DefaultValueHandling DefaultValueHandling
		{
			get
			{
				return this._defaultValueHandling;
			}
			set
			{
				if (value < DefaultValueHandling.Include || value > DefaultValueHandling.IgnoreAndPopulate)
				{
					throw JsonSerializer.smethod_3(<Module>.smethod_26<string>(1806306238U));
				}
				this._defaultValueHandling = value;
			}
		}

		// Token: 0x170004C0 RID: 1216
		// (get) Token: 0x06002059 RID: 8281 RVA: 0x0001B2B9 File Offset: 0x000194B9
		// (set) Token: 0x0600205A RID: 8282 RVA: 0x0001B2C1 File Offset: 0x000194C1
		public virtual ObjectCreationHandling ObjectCreationHandling
		{
			get
			{
				return this._objectCreationHandling;
			}
			set
			{
				if (value < ObjectCreationHandling.Auto || value > ObjectCreationHandling.Replace)
				{
					throw JsonSerializer.smethod_3(<Module>.smethod_24<string>(4014942403U));
				}
				this._objectCreationHandling = value;
			}
		}

		// Token: 0x170004C1 RID: 1217
		// (get) Token: 0x0600205B RID: 8283 RVA: 0x0001B2E2 File Offset: 0x000194E2
		// (set) Token: 0x0600205C RID: 8284 RVA: 0x0001B2EA File Offset: 0x000194EA
		public virtual ConstructorHandling ConstructorHandling
		{
			get
			{
				return this._constructorHandling;
			}
			set
			{
				if (value < ConstructorHandling.Default || value > ConstructorHandling.AllowNonPublicDefaultConstructor)
				{
					throw JsonSerializer.smethod_3(<Module>.smethod_24<string>(4014942403U));
				}
				this._constructorHandling = value;
			}
		}

		// Token: 0x170004C2 RID: 1218
		// (get) Token: 0x0600205D RID: 8285 RVA: 0x0001B30B File Offset: 0x0001950B
		// (set) Token: 0x0600205E RID: 8286 RVA: 0x0001B313 File Offset: 0x00019513
		public virtual MetadataPropertyHandling MetadataPropertyHandling
		{
			get
			{
				return this._metadataPropertyHandling;
			}
			set
			{
				if (value < MetadataPropertyHandling.Default || value > MetadataPropertyHandling.Ignore)
				{
					throw JsonSerializer.smethod_3(<Module>.smethod_26<string>(1806306238U));
				}
				this._metadataPropertyHandling = value;
			}
		}

		// Token: 0x170004C3 RID: 1219
		// (get) Token: 0x0600205F RID: 8287 RVA: 0x0001B334 File Offset: 0x00019534
		public virtual JsonConverterCollection Converters
		{
			get
			{
				if (this._converters == null)
				{
					this._converters = new JsonConverterCollection();
				}
				return this._converters;
			}
		}

		// Token: 0x170004C4 RID: 1220
		// (get) Token: 0x06002060 RID: 8288 RVA: 0x0001B34F File Offset: 0x0001954F
		// (set) Token: 0x06002061 RID: 8289 RVA: 0x0001B357 File Offset: 0x00019557
		public virtual IContractResolver ContractResolver
		{
			get
			{
				return this._contractResolver;
			}
			set
			{
				this._contractResolver = value ?? DefaultContractResolver.Instance;
			}
		}

		// Token: 0x170004C5 RID: 1221
		// (get) Token: 0x06002062 RID: 8290 RVA: 0x0001B369 File Offset: 0x00019569
		// (set) Token: 0x06002063 RID: 8291 RVA: 0x0001B371 File Offset: 0x00019571
		public virtual StreamingContext Context
		{
			get
			{
				return this._context;
			}
			set
			{
				this._context = value;
			}
		}

		// Token: 0x170004C6 RID: 1222
		// (get) Token: 0x06002064 RID: 8292 RVA: 0x00086344 File Offset: 0x00084544
		// (set) Token: 0x06002065 RID: 8293 RVA: 0x0001B37A File Offset: 0x0001957A
		public virtual Formatting Formatting
		{
			get
			{
				Formatting? formatting = this._formatting;
				if (formatting == null)
				{
					return Formatting.None;
				}
				return formatting.GetValueOrDefault();
			}
			set
			{
				this._formatting = new Formatting?(value);
			}
		}

		// Token: 0x170004C7 RID: 1223
		// (get) Token: 0x06002066 RID: 8294 RVA: 0x0008636C File Offset: 0x0008456C
		// (set) Token: 0x06002067 RID: 8295 RVA: 0x0001B388 File Offset: 0x00019588
		public virtual DateFormatHandling DateFormatHandling
		{
			get
			{
				DateFormatHandling? dateFormatHandling = this._dateFormatHandling;
				if (dateFormatHandling == null)
				{
					return DateFormatHandling.IsoDateFormat;
				}
				return dateFormatHandling.GetValueOrDefault();
			}
			set
			{
				this._dateFormatHandling = new DateFormatHandling?(value);
			}
		}

		// Token: 0x170004C8 RID: 1224
		// (get) Token: 0x06002068 RID: 8296 RVA: 0x00086394 File Offset: 0x00084594
		// (set) Token: 0x06002069 RID: 8297 RVA: 0x0001B396 File Offset: 0x00019596
		public virtual DateTimeZoneHandling DateTimeZoneHandling
		{
			get
			{
				DateTimeZoneHandling? dateTimeZoneHandling = this._dateTimeZoneHandling;
				if (dateTimeZoneHandling == null)
				{
					return DateTimeZoneHandling.RoundtripKind;
				}
				return dateTimeZoneHandling.GetValueOrDefault();
			}
			set
			{
				this._dateTimeZoneHandling = new DateTimeZoneHandling?(value);
			}
		}

		// Token: 0x170004C9 RID: 1225
		// (get) Token: 0x0600206A RID: 8298 RVA: 0x000863BC File Offset: 0x000845BC
		// (set) Token: 0x0600206B RID: 8299 RVA: 0x0001B3A4 File Offset: 0x000195A4
		public virtual DateParseHandling DateParseHandling
		{
			get
			{
				DateParseHandling? dateParseHandling = this._dateParseHandling;
				if (dateParseHandling == null)
				{
					return DateParseHandling.DateTime;
				}
				return dateParseHandling.GetValueOrDefault();
			}
			set
			{
				this._dateParseHandling = new DateParseHandling?(value);
			}
		}

		// Token: 0x170004CA RID: 1226
		// (get) Token: 0x0600206C RID: 8300 RVA: 0x000863E4 File Offset: 0x000845E4
		// (set) Token: 0x0600206D RID: 8301 RVA: 0x0001B3B2 File Offset: 0x000195B2
		public virtual FloatParseHandling FloatParseHandling
		{
			get
			{
				FloatParseHandling? floatParseHandling = this._floatParseHandling;
				if (floatParseHandling == null)
				{
					return FloatParseHandling.Double;
				}
				return floatParseHandling.GetValueOrDefault();
			}
			set
			{
				this._floatParseHandling = new FloatParseHandling?(value);
			}
		}

		// Token: 0x170004CB RID: 1227
		// (get) Token: 0x0600206E RID: 8302 RVA: 0x0008640C File Offset: 0x0008460C
		// (set) Token: 0x0600206F RID: 8303 RVA: 0x0001B3C0 File Offset: 0x000195C0
		public virtual FloatFormatHandling FloatFormatHandling
		{
			get
			{
				FloatFormatHandling? floatFormatHandling = this._floatFormatHandling;
				if (floatFormatHandling == null)
				{
					return FloatFormatHandling.String;
				}
				return floatFormatHandling.GetValueOrDefault();
			}
			set
			{
				this._floatFormatHandling = new FloatFormatHandling?(value);
			}
		}

		// Token: 0x170004CC RID: 1228
		// (get) Token: 0x06002070 RID: 8304 RVA: 0x00086434 File Offset: 0x00084634
		// (set) Token: 0x06002071 RID: 8305 RVA: 0x0001B3CE File Offset: 0x000195CE
		public virtual StringEscapeHandling StringEscapeHandling
		{
			get
			{
				StringEscapeHandling? stringEscapeHandling = this._stringEscapeHandling;
				if (stringEscapeHandling == null)
				{
					return StringEscapeHandling.Default;
				}
				return stringEscapeHandling.GetValueOrDefault();
			}
			set
			{
				this._stringEscapeHandling = new StringEscapeHandling?(value);
			}
		}

		// Token: 0x170004CD RID: 1229
		// (get) Token: 0x06002072 RID: 8306 RVA: 0x0001B3DC File Offset: 0x000195DC
		// (set) Token: 0x06002073 RID: 8307 RVA: 0x0001B3F2 File Offset: 0x000195F2
		public virtual string DateFormatString
		{
			get
			{
				return this._dateFormatString ?? <Module>.smethod_27<string>(1494287573U);
			}
			set
			{
				this._dateFormatString = value;
				this._dateFormatStringSet = true;
			}
		}

		// Token: 0x170004CE RID: 1230
		// (get) Token: 0x06002074 RID: 8308 RVA: 0x0001B402 File Offset: 0x00019602
		// (set) Token: 0x06002075 RID: 8309 RVA: 0x0001B413 File Offset: 0x00019613
		public virtual CultureInfo Culture
		{
			get
			{
				return this._culture ?? JsonSerializerSettings.DefaultCulture;
			}
			set
			{
				this._culture = value;
			}
		}

		// Token: 0x170004CF RID: 1231
		// (get) Token: 0x06002076 RID: 8310 RVA: 0x0001B41C File Offset: 0x0001961C
		// (set) Token: 0x06002077 RID: 8311 RVA: 0x0008645C File Offset: 0x0008465C
		public virtual int? MaxDepth
		{
			get
			{
				return this._maxDepth;
			}
			set
			{
				if (value <= 0)
				{
					throw JsonSerializer.smethod_4(<Module>.smethod_27<string>(2285058862U), <Module>.smethod_23<string>(2033612370U));
				}
				this._maxDepth = value;
				this._maxDepthSet = true;
			}
		}

		// Token: 0x170004D0 RID: 1232
		// (get) Token: 0x06002078 RID: 8312 RVA: 0x000864AC File Offset: 0x000846AC
		// (set) Token: 0x06002079 RID: 8313 RVA: 0x0001B424 File Offset: 0x00019624
		public virtual bool CheckAdditionalContent
		{
			get
			{
				return this._checkAdditionalContent ?? false;
			}
			set
			{
				this._checkAdditionalContent = new bool?(value);
			}
		}

		// Token: 0x0600207A RID: 8314 RVA: 0x0001B432 File Offset: 0x00019632
		internal bool IsCheckAdditionalContentSet()
		{
			return this._checkAdditionalContent != null;
		}

		// Token: 0x0600207B RID: 8315 RVA: 0x000864D4 File Offset: 0x000846D4
		public JsonSerializer()
		{
			this._referenceLoopHandling = ReferenceLoopHandling.Error;
			this._missingMemberHandling = MissingMemberHandling.Ignore;
			this._nullValueHandling = NullValueHandling.Include;
			this._defaultValueHandling = DefaultValueHandling.Include;
			this._objectCreationHandling = ObjectCreationHandling.Auto;
			this._preserveReferencesHandling = PreserveReferencesHandling.None;
			this._constructorHandling = ConstructorHandling.Default;
			this._typeNameHandling = TypeNameHandling.None;
			this._metadataPropertyHandling = MetadataPropertyHandling.Default;
			this._context = JsonSerializerSettings.DefaultContext;
			this._binder = DefaultSerializationBinder.Instance;
			this._culture = JsonSerializerSettings.DefaultCulture;
			this._contractResolver = DefaultContractResolver.Instance;
		}

		// Token: 0x0600207C RID: 8316 RVA: 0x0001B43F File Offset: 0x0001963F
		public static JsonSerializer Create()
		{
			return new JsonSerializer();
		}

		// Token: 0x0600207D RID: 8317 RVA: 0x00086554 File Offset: 0x00084754
		public static JsonSerializer Create(JsonSerializerSettings settings)
		{
			JsonSerializer jsonSerializer = JsonSerializer.Create();
			if (settings != null)
			{
				JsonSerializer.ApplySerializerSettings(jsonSerializer, settings);
			}
			return jsonSerializer;
		}

		// Token: 0x0600207E RID: 8318 RVA: 0x00086574 File Offset: 0x00084774
		public static JsonSerializer CreateDefault()
		{
			Func<JsonSerializerSettings> defaultSettings = JsonConvert.DefaultSettings;
			JsonSerializerSettings jsonSerializerSettings = ((defaultSettings != null) ? defaultSettings() : null);
			return JsonSerializer.Create(jsonSerializerSettings);
		}

		// Token: 0x0600207F RID: 8319 RVA: 0x0008659C File Offset: 0x0008479C
		public static JsonSerializer CreateDefault(JsonSerializerSettings settings)
		{
			JsonSerializer jsonSerializer = JsonSerializer.CreateDefault();
			if (settings != null)
			{
				JsonSerializer.ApplySerializerSettings(jsonSerializer, settings);
			}
			return jsonSerializer;
		}

		// Token: 0x06002080 RID: 8320 RVA: 0x000865BC File Offset: 0x000847BC
		private static void ApplySerializerSettings(JsonSerializer serializer, JsonSerializerSettings settings)
		{
			if (!CollectionUtils.IsNullOrEmpty<JsonConverter>(settings.Converters))
			{
				for (int i = 0; i < settings.Converters.Count; i++)
				{
					serializer.Converters.Insert(i, settings.Converters[i]);
				}
			}
			if (settings._typeNameHandling != null)
			{
				serializer.TypeNameHandling = settings.TypeNameHandling;
			}
			if (settings._metadataPropertyHandling != null)
			{
				serializer.MetadataPropertyHandling = settings.MetadataPropertyHandling;
			}
			if (settings._typeNameAssemblyFormat != null)
			{
				serializer.TypeNameAssemblyFormat = settings.TypeNameAssemblyFormat;
			}
			if (settings._preserveReferencesHandling != null)
			{
				serializer.PreserveReferencesHandling = settings.PreserveReferencesHandling;
			}
			if (settings._referenceLoopHandling != null)
			{
				serializer.ReferenceLoopHandling = settings.ReferenceLoopHandling;
			}
			if (settings._missingMemberHandling != null)
			{
				serializer.MissingMemberHandling = settings.MissingMemberHandling;
			}
			if (settings._objectCreationHandling != null)
			{
				serializer.ObjectCreationHandling = settings.ObjectCreationHandling;
			}
			if (settings._nullValueHandling != null)
			{
				serializer.NullValueHandling = settings.NullValueHandling;
			}
			if (settings._defaultValueHandling != null)
			{
				serializer.DefaultValueHandling = settings.DefaultValueHandling;
			}
			if (settings._constructorHandling != null)
			{
				serializer.ConstructorHandling = settings.ConstructorHandling;
			}
			if (settings._context != null)
			{
				serializer.Context = settings.Context;
			}
			if (settings._checkAdditionalContent != null)
			{
				serializer._checkAdditionalContent = settings._checkAdditionalContent;
			}
			if (settings.Error != null)
			{
				serializer.Error += settings.Error;
			}
			if (settings.ContractResolver != null)
			{
				serializer.ContractResolver = settings.ContractResolver;
			}
			if (settings.ReferenceResolverProvider != null)
			{
				serializer.ReferenceResolver = settings.ReferenceResolverProvider();
			}
			if (settings.TraceWriter != null)
			{
				serializer.TraceWriter = settings.TraceWriter;
			}
			if (settings.EqualityComparer != null)
			{
				serializer.EqualityComparer = settings.EqualityComparer;
			}
			if (settings.Binder != null)
			{
				serializer.Binder = settings.Binder;
			}
			if (settings._formatting != null)
			{
				serializer._formatting = settings._formatting;
			}
			if (settings._dateFormatHandling != null)
			{
				serializer._dateFormatHandling = settings._dateFormatHandling;
			}
			if (settings._dateTimeZoneHandling != null)
			{
				serializer._dateTimeZoneHandling = settings._dateTimeZoneHandling;
			}
			if (settings._dateParseHandling != null)
			{
				serializer._dateParseHandling = settings._dateParseHandling;
			}
			if (settings._dateFormatStringSet)
			{
				serializer._dateFormatString = settings._dateFormatString;
				serializer._dateFormatStringSet = settings._dateFormatStringSet;
			}
			if (settings._floatFormatHandling != null)
			{
				serializer._floatFormatHandling = settings._floatFormatHandling;
			}
			if (settings._floatParseHandling != null)
			{
				serializer._floatParseHandling = settings._floatParseHandling;
			}
			if (settings._stringEscapeHandling != null)
			{
				serializer._stringEscapeHandling = settings._stringEscapeHandling;
			}
			if (settings._culture != null)
			{
				serializer._culture = settings._culture;
			}
			if (settings._maxDepthSet)
			{
				serializer._maxDepth = settings._maxDepth;
				serializer._maxDepthSet = settings._maxDepthSet;
			}
		}

		// Token: 0x06002081 RID: 8321 RVA: 0x0001B446 File Offset: 0x00019646
		public void Populate(TextReader reader, object target)
		{
			this.Populate(new JsonTextReader(reader), target);
		}

		// Token: 0x06002082 RID: 8322 RVA: 0x0001B455 File Offset: 0x00019655
		public void Populate(JsonReader reader, object target)
		{
			this.PopulateInternal(reader, target);
		}

		// Token: 0x06002083 RID: 8323 RVA: 0x000868B0 File Offset: 0x00084AB0
		internal virtual void PopulateInternal(JsonReader reader, object target)
		{
			ValidationUtils.ArgumentNotNull(reader, <Module>.smethod_25<string>(985892740U));
			ValidationUtils.ArgumentNotNull(target, <Module>.smethod_26<string>(2441328446U));
			CultureInfo cultureInfo;
			DateTimeZoneHandling? dateTimeZoneHandling;
			DateParseHandling? dateParseHandling;
			FloatParseHandling? floatParseHandling;
			int? num;
			string text;
			this.SetupReader(reader, out cultureInfo, out dateTimeZoneHandling, out dateParseHandling, out floatParseHandling, out num, out text);
			TraceJsonReader traceJsonReader = ((this.TraceWriter == null || this.TraceWriter.LevelFilter < TraceLevel.Verbose) ? null : new TraceJsonReader(reader));
			JsonSerializerInternalReader jsonSerializerInternalReader = new JsonSerializerInternalReader(this);
			jsonSerializerInternalReader.Populate(traceJsonReader ?? reader, target);
			if (traceJsonReader != null)
			{
				this.TraceWriter.Trace(TraceLevel.Verbose, traceJsonReader.GetDeserializedJsonMessage(), null);
			}
			this.ResetReader(reader, cultureInfo, dateTimeZoneHandling, dateParseHandling, floatParseHandling, num, text);
		}

		// Token: 0x06002084 RID: 8324 RVA: 0x0001B45F File Offset: 0x0001965F
		public object Deserialize(JsonReader reader)
		{
			return this.Deserialize(reader, null);
		}

		// Token: 0x06002085 RID: 8325 RVA: 0x0001B469 File Offset: 0x00019669
		public object Deserialize(TextReader reader, Type objectType)
		{
			return this.Deserialize(new JsonTextReader(reader), objectType);
		}

		// Token: 0x06002086 RID: 8326 RVA: 0x0001B478 File Offset: 0x00019678
		public T Deserialize<T>(JsonReader reader)
		{
			return (T)((object)this.Deserialize(reader, JsonSerializer.smethod_5(typeof(T).TypeHandle)));
		}

		// Token: 0x06002087 RID: 8327 RVA: 0x0001B490 File Offset: 0x00019690
		public object Deserialize(JsonReader reader, Type objectType)
		{
			return this.DeserializeInternal(reader, objectType);
		}

		// Token: 0x06002088 RID: 8328 RVA: 0x00086950 File Offset: 0x00084B50
		internal virtual object DeserializeInternal(JsonReader reader, Type objectType)
		{
			ValidationUtils.ArgumentNotNull(reader, <Module>.smethod_27<string>(3246799795U));
			CultureInfo cultureInfo;
			DateTimeZoneHandling? dateTimeZoneHandling;
			DateParseHandling? dateParseHandling;
			FloatParseHandling? floatParseHandling;
			int? num;
			string text;
			this.SetupReader(reader, out cultureInfo, out dateTimeZoneHandling, out dateParseHandling, out floatParseHandling, out num, out text);
			TraceJsonReader traceJsonReader = ((this.TraceWriter == null || this.TraceWriter.LevelFilter < TraceLevel.Verbose) ? null : new TraceJsonReader(reader));
			JsonSerializerInternalReader jsonSerializerInternalReader = new JsonSerializerInternalReader(this);
			object obj = jsonSerializerInternalReader.Deserialize(traceJsonReader ?? reader, objectType, this.CheckAdditionalContent);
			if (traceJsonReader != null)
			{
				this.TraceWriter.Trace(TraceLevel.Verbose, traceJsonReader.GetDeserializedJsonMessage(), null);
			}
			this.ResetReader(reader, cultureInfo, dateTimeZoneHandling, dateParseHandling, floatParseHandling, num, text);
			return obj;
		}

		// Token: 0x06002089 RID: 8329 RVA: 0x000869EC File Offset: 0x00084BEC
		private void SetupReader(JsonReader reader, out CultureInfo previousCulture, out DateTimeZoneHandling? previousDateTimeZoneHandling, out DateParseHandling? previousDateParseHandling, out FloatParseHandling? previousFloatParseHandling, out int? previousMaxDepth, out string previousDateFormatString)
		{
			if (this._culture != null)
			{
				if (JsonSerializer.smethod_6(this._culture, reader.Culture))
				{
					628624241;
				}
				else
				{
					628624247;
				}
			}
			else
			{
				previousCulture = null;
				if (this._dateTimeZoneHandling != null && reader.DateTimeZoneHandling != this._dateTimeZoneHandling)
				{
					previousDateTimeZoneHandling = new DateTimeZoneHandling?(reader.DateTimeZoneHandling);
					reader.DateTimeZoneHandling = this._dateTimeZoneHandling.Value;
				}
				else
				{
					previousDateTimeZoneHandling = null;
				}
				if (this._dateParseHandling != null)
				{
					628624240;
				}
				else
				{
					628624252;
				}
			}
		}

		// Token: 0x0600208A RID: 8330 RVA: 0x00086AA0 File Offset: 0x00084CA0
		private void ResetReader(JsonReader reader, CultureInfo previousCulture, DateTimeZoneHandling? previousDateTimeZoneHandling, DateParseHandling? previousDateParseHandling, FloatParseHandling? previousFloatParseHandling, int? previousMaxDepth, string previousDateFormatString)
		{
			if (previousCulture != null)
			{
				reader.Culture = previousCulture;
			}
			if (previousDateTimeZoneHandling != null)
			{
				reader.DateTimeZoneHandling = previousDateTimeZoneHandling.Value;
			}
			if (previousDateParseHandling != null)
			{
				reader.DateParseHandling = previousDateParseHandling.Value;
			}
			if (previousFloatParseHandling != null)
			{
				reader.FloatParseHandling = previousFloatParseHandling.Value;
			}
			if (this._maxDepthSet)
			{
				reader.MaxDepth = previousMaxDepth;
			}
			if (this._dateFormatStringSet)
			{
				reader.DateFormatString = previousDateFormatString;
			}
			JsonTextReader jsonTextReader = reader as JsonTextReader;
			if (jsonTextReader != null)
			{
				jsonTextReader.NameTable = null;
			}
		}

		// Token: 0x0600208B RID: 8331 RVA: 0x0001B49A File Offset: 0x0001969A
		public void Serialize(TextWriter textWriter, object value)
		{
			this.Serialize(new JsonTextWriter(textWriter), value);
		}

		// Token: 0x0600208C RID: 8332 RVA: 0x0001B4A9 File Offset: 0x000196A9
		public void Serialize(JsonWriter jsonWriter, object value, Type objectType)
		{
			this.SerializeInternal(jsonWriter, value, objectType);
		}

		// Token: 0x0600208D RID: 8333 RVA: 0x0001B4B4 File Offset: 0x000196B4
		public void Serialize(TextWriter textWriter, object value, Type objectType)
		{
			this.Serialize(new JsonTextWriter(textWriter), value, objectType);
		}

		// Token: 0x0600208E RID: 8334 RVA: 0x0001B4C4 File Offset: 0x000196C4
		public void Serialize(JsonWriter jsonWriter, object value)
		{
			this.SerializeInternal(jsonWriter, value, null);
		}

		// Token: 0x0600208F RID: 8335 RVA: 0x00086B2C File Offset: 0x00084D2C
		internal virtual void SerializeInternal(JsonWriter jsonWriter, object value, Type objectType)
		{
			ValidationUtils.ArgumentNotNull(jsonWriter, <Module>.smethod_23<string>(28105793U));
			Formatting? formatting = null;
			if (this._formatting != null && jsonWriter.Formatting != this._formatting)
			{
				formatting = new Formatting?(jsonWriter.Formatting);
				jsonWriter.Formatting = this._formatting.Value;
			}
			DateFormatHandling? dateFormatHandling = null;
			if (this._dateFormatHandling != null && jsonWriter.DateFormatHandling != this._dateFormatHandling)
			{
				dateFormatHandling = new DateFormatHandling?(jsonWriter.DateFormatHandling);
				jsonWriter.DateFormatHandling = this._dateFormatHandling.Value;
			}
			DateTimeZoneHandling? dateTimeZoneHandling = null;
			if (this._dateTimeZoneHandling != null && jsonWriter.DateTimeZoneHandling != this._dateTimeZoneHandling)
			{
				dateTimeZoneHandling = new DateTimeZoneHandling?(jsonWriter.DateTimeZoneHandling);
				jsonWriter.DateTimeZoneHandling = this._dateTimeZoneHandling.Value;
			}
			FloatFormatHandling? floatFormatHandling = null;
			if (this._floatFormatHandling != null && jsonWriter.FloatFormatHandling != this._floatFormatHandling)
			{
				floatFormatHandling = new FloatFormatHandling?(jsonWriter.FloatFormatHandling);
				jsonWriter.FloatFormatHandling = this._floatFormatHandling.Value;
			}
			StringEscapeHandling? stringEscapeHandling = null;
			if (this._stringEscapeHandling != null && jsonWriter.StringEscapeHandling != this._stringEscapeHandling)
			{
				stringEscapeHandling = new StringEscapeHandling?(jsonWriter.StringEscapeHandling);
				jsonWriter.StringEscapeHandling = this._stringEscapeHandling.Value;
			}
			CultureInfo cultureInfo = null;
			if (this._culture != null && !JsonSerializer.smethod_6(this._culture, jsonWriter.Culture))
			{
				cultureInfo = jsonWriter.Culture;
				jsonWriter.Culture = this._culture;
			}
			string text = null;
			if (this._dateFormatStringSet && JsonSerializer.smethod_7(jsonWriter.DateFormatString, this._dateFormatString))
			{
				text = jsonWriter.DateFormatString;
				jsonWriter.DateFormatString = this._dateFormatString;
			}
			TraceJsonWriter traceJsonWriter = ((this.TraceWriter == null || this.TraceWriter.LevelFilter < TraceLevel.Verbose) ? null : new TraceJsonWriter(jsonWriter));
			JsonSerializerInternalWriter jsonSerializerInternalWriter = new JsonSerializerInternalWriter(this);
			jsonSerializerInternalWriter.Serialize(traceJsonWriter ?? jsonWriter, value, objectType);
			if (traceJsonWriter != null)
			{
				this.TraceWriter.Trace(TraceLevel.Verbose, traceJsonWriter.GetSerializedJsonMessage(), null);
			}
			if (formatting != null)
			{
				jsonWriter.Formatting = formatting.Value;
			}
			if (dateFormatHandling != null)
			{
				jsonWriter.DateFormatHandling = dateFormatHandling.Value;
			}
			if (dateTimeZoneHandling != null)
			{
				jsonWriter.DateTimeZoneHandling = dateTimeZoneHandling.Value;
			}
			if (floatFormatHandling != null)
			{
				jsonWriter.FloatFormatHandling = floatFormatHandling.Value;
			}
			if (stringEscapeHandling != null)
			{
				jsonWriter.StringEscapeHandling = stringEscapeHandling.Value;
			}
			if (this._dateFormatStringSet)
			{
				jsonWriter.DateFormatString = text;
			}
			if (cultureInfo != null)
			{
				jsonWriter.Culture = cultureInfo;
			}
		}

		// Token: 0x06002090 RID: 8336 RVA: 0x0001B4CF File Offset: 0x000196CF
		internal IReferenceResolver GetReferenceResolver()
		{
			if (this._referenceResolver == null)
			{
				this._referenceResolver = new DefaultReferenceResolver();
			}
			return this._referenceResolver;
		}

		// Token: 0x06002091 RID: 8337 RVA: 0x0001B4EA File Offset: 0x000196EA
		internal JsonConverter GetMatchingConverter(Type type)
		{
			return JsonSerializer.GetMatchingConverter(this._converters, type);
		}

		// Token: 0x06002092 RID: 8338 RVA: 0x00086E58 File Offset: 0x00085058
		internal static JsonConverter GetMatchingConverter(IList<JsonConverter> converters, Type objectType)
		{
			if (converters != null)
			{
				for (int i = 0; i < converters.Count; i++)
				{
					JsonConverter jsonConverter = converters[i];
					if (jsonConverter.CanConvert(objectType))
					{
						return jsonConverter;
					}
				}
			}
			return null;
		}

		// Token: 0x06002093 RID: 8339 RVA: 0x00086E90 File Offset: 0x00085090
		internal void OnError(Newtonsoft.Json.Serialization.ErrorEventArgs e)
		{
			EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs> error = this.Error;
			if (error != null)
			{
				error(this, e);
			}
		}

		// Token: 0x06002094 RID: 8340 RVA: 0x0000CD19 File Offset: 0x0000AF19
		static Delegate smethod_0(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Combine(delegate_0, delegate_1);
		}

		// Token: 0x06002095 RID: 8341 RVA: 0x0000CD22 File Offset: 0x0000AF22
		static Delegate smethod_1(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Remove(delegate_0, delegate_1);
		}

		// Token: 0x06002096 RID: 8342 RVA: 0x0001B4F8 File Offset: 0x000196F8
		static ArgumentNullException smethod_2(string string_0, string string_1)
		{
			return new ArgumentNullException(string_0, string_1);
		}

		// Token: 0x06002097 RID: 8343 RVA: 0x0000F870 File Offset: 0x0000DA70
		static ArgumentOutOfRangeException smethod_3(string string_0)
		{
			return new ArgumentOutOfRangeException(string_0);
		}

		// Token: 0x06002098 RID: 8344 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_4(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}

		// Token: 0x06002099 RID: 8345 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_5(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x0600209A RID: 8346 RVA: 0x0000ED73 File Offset: 0x0000CF73
		static bool smethod_6(object object_0, object object_1)
		{
			return object_0.Equals(object_1);
		}

		// Token: 0x0600209B RID: 8347 RVA: 0x0000CDA1 File Offset: 0x0000AFA1
		static bool smethod_7(string string_0, string string_1)
		{
			return string_0 != string_1;
		}

		// Token: 0x04000BC9 RID: 3017
		internal TypeNameHandling _typeNameHandling;

		// Token: 0x04000BCA RID: 3018
		internal FormatterAssemblyStyle _typeNameAssemblyFormat;

		// Token: 0x04000BCB RID: 3019
		internal PreserveReferencesHandling _preserveReferencesHandling;

		// Token: 0x04000BCC RID: 3020
		internal ReferenceLoopHandling _referenceLoopHandling;

		// Token: 0x04000BCD RID: 3021
		internal MissingMemberHandling _missingMemberHandling;

		// Token: 0x04000BCE RID: 3022
		internal ObjectCreationHandling _objectCreationHandling;

		// Token: 0x04000BCF RID: 3023
		internal NullValueHandling _nullValueHandling;

		// Token: 0x04000BD0 RID: 3024
		internal DefaultValueHandling _defaultValueHandling;

		// Token: 0x04000BD1 RID: 3025
		internal ConstructorHandling _constructorHandling;

		// Token: 0x04000BD2 RID: 3026
		internal MetadataPropertyHandling _metadataPropertyHandling;

		// Token: 0x04000BD3 RID: 3027
		internal JsonConverterCollection _converters;

		// Token: 0x04000BD4 RID: 3028
		internal IContractResolver _contractResolver;

		// Token: 0x04000BD5 RID: 3029
		internal ITraceWriter _traceWriter;

		// Token: 0x04000BD6 RID: 3030
		internal IEqualityComparer _equalityComparer;

		// Token: 0x04000BD7 RID: 3031
		internal SerializationBinder _binder;

		// Token: 0x04000BD8 RID: 3032
		internal StreamingContext _context;

		// Token: 0x04000BD9 RID: 3033
		private IReferenceResolver _referenceResolver;

		// Token: 0x04000BDA RID: 3034
		private Formatting? _formatting;

		// Token: 0x04000BDB RID: 3035
		private DateFormatHandling? _dateFormatHandling;

		// Token: 0x04000BDC RID: 3036
		private DateTimeZoneHandling? _dateTimeZoneHandling;

		// Token: 0x04000BDD RID: 3037
		private DateParseHandling? _dateParseHandling;

		// Token: 0x04000BDE RID: 3038
		private FloatFormatHandling? _floatFormatHandling;

		// Token: 0x04000BDF RID: 3039
		private FloatParseHandling? _floatParseHandling;

		// Token: 0x04000BE0 RID: 3040
		private StringEscapeHandling? _stringEscapeHandling;

		// Token: 0x04000BE1 RID: 3041
		private CultureInfo _culture;

		// Token: 0x04000BE2 RID: 3042
		private int? _maxDepth;

		// Token: 0x04000BE3 RID: 3043
		private bool _maxDepthSet;

		// Token: 0x04000BE4 RID: 3044
		private bool? _checkAdditionalContent;

		// Token: 0x04000BE5 RID: 3045
		private string _dateFormatString;

		// Token: 0x04000BE6 RID: 3046
		private bool _dateFormatStringSet;
	}
}
