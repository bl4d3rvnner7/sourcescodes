﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001B0 RID: 432
	public enum ConstructorHandling
	{
		// Token: 0x040009BC RID: 2492
		Default,
		// Token: 0x040009BD RID: 2493
		AllowNonPublicDefaultConstructor
	}
}
