﻿using System;
using System.Globalization;
using System.IO;
using System.Numerics;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json
{
	// Token: 0x0200022A RID: 554
	public class JsonTextWriter : JsonWriter
	{
		// Token: 0x170004AB RID: 1195
		// (get) Token: 0x06001F71 RID: 8049 RVA: 0x0001A831 File Offset: 0x00018A31
		private Base64Encoder Base64Encoder
		{
			get
			{
				if (this._base64Encoder == null)
				{
					this._base64Encoder = new Base64Encoder(this._writer);
				}
				return this._base64Encoder;
			}
		}

		// Token: 0x170004AC RID: 1196
		// (get) Token: 0x06001F72 RID: 8050 RVA: 0x0001A852 File Offset: 0x00018A52
		// (set) Token: 0x06001F73 RID: 8051 RVA: 0x0001A85A File Offset: 0x00018A5A
		public int Indentation
		{
			get
			{
				return this._indentation;
			}
			set
			{
				if (value < 0)
				{
					throw JsonTextWriter.smethod_16(<Module>.smethod_25<string>(881605633U));
				}
				this._indentation = value;
			}
		}

		// Token: 0x170004AD RID: 1197
		// (get) Token: 0x06001F74 RID: 8052 RVA: 0x0001A877 File Offset: 0x00018A77
		// (set) Token: 0x06001F75 RID: 8053 RVA: 0x0001A87F File Offset: 0x00018A7F
		public char QuoteChar
		{
			get
			{
				return this._quoteChar;
			}
			set
			{
				if (value != '"' && value != '\'')
				{
					throw JsonTextWriter.smethod_16(<Module>.smethod_24<string>(2612070839U));
				}
				this._quoteChar = value;
				this.UpdateCharEscapeFlags();
			}
		}

		// Token: 0x170004AE RID: 1198
		// (get) Token: 0x06001F76 RID: 8054 RVA: 0x0001A8A8 File Offset: 0x00018AA8
		// (set) Token: 0x06001F77 RID: 8055 RVA: 0x0001A8B0 File Offset: 0x00018AB0
		public char IndentChar
		{
			get
			{
				return this._indentChar;
			}
			set
			{
				if (value != this._indentChar)
				{
					this._indentChar = value;
					this._indentChars = null;
				}
			}
		}

		// Token: 0x170004AF RID: 1199
		// (get) Token: 0x06001F78 RID: 8056 RVA: 0x0001A8C9 File Offset: 0x00018AC9
		// (set) Token: 0x06001F79 RID: 8057 RVA: 0x0001A8D1 File Offset: 0x00018AD1
		public bool QuoteName
		{
			get
			{
				return this._quoteName;
			}
			set
			{
				this._quoteName = value;
			}
		}

		// Token: 0x06001F7A RID: 8058 RVA: 0x000854FC File Offset: 0x000836FC
		public JsonTextWriter(TextWriter textWriter)
		{
			if (textWriter == null)
			{
				throw JsonTextWriter.smethod_17(<Module>.smethod_24<string>(3939227394U));
			}
			this._writer = textWriter;
			this._quoteChar = '"';
			this._quoteName = true;
			this._indentChar = ' ';
			this._indentation = 2;
			this.UpdateCharEscapeFlags();
		}

		// Token: 0x06001F7B RID: 8059 RVA: 0x0001A8DA File Offset: 0x00018ADA
		public override void Flush()
		{
			JsonTextWriter.smethod_18(this._writer);
		}

		// Token: 0x06001F7C RID: 8060 RVA: 0x0001A8E7 File Offset: 0x00018AE7
		public override void Close()
		{
			base.Close();
			if (base.CloseOutput && this._writer != null)
			{
				JsonTextWriter.smethod_19(this._writer);
			}
		}

		// Token: 0x06001F7D RID: 8061 RVA: 0x0001A90A File Offset: 0x00018B0A
		public override void WriteStartObject()
		{
			base.InternalWriteStart(JsonToken.StartObject, JsonContainerType.Object);
			JsonTextWriter.smethod_20(this._writer, '{');
		}

		// Token: 0x06001F7E RID: 8062 RVA: 0x0001A921 File Offset: 0x00018B21
		public override void WriteStartArray()
		{
			base.InternalWriteStart(JsonToken.StartArray, JsonContainerType.Array);
			JsonTextWriter.smethod_20(this._writer, '[');
		}

		// Token: 0x06001F7F RID: 8063 RVA: 0x0001A938 File Offset: 0x00018B38
		public override void WriteStartConstructor(string name)
		{
			base.InternalWriteStart(JsonToken.StartConstructor, JsonContainerType.Constructor);
			JsonTextWriter.smethod_21(this._writer, <Module>.smethod_25<string>(3874296112U));
			JsonTextWriter.smethod_21(this._writer, name);
			JsonTextWriter.smethod_20(this._writer, '(');
		}

		// Token: 0x06001F80 RID: 8064 RVA: 0x00085550 File Offset: 0x00083750
		protected override void WriteEnd(JsonToken token)
		{
			switch (token)
			{
			case JsonToken.EndObject:
				JsonTextWriter.smethod_20(this._writer, '}');
				return;
			case JsonToken.EndArray:
				JsonTextWriter.smethod_20(this._writer, ']');
				return;
			case JsonToken.EndConstructor:
				JsonTextWriter.smethod_20(this._writer, ')');
				return;
			default:
				throw JsonWriterException.Create(this, JsonTextWriter.smethod_22(<Module>.smethod_25<string>(3735101206U), token), null);
			}
		}

		// Token: 0x06001F81 RID: 8065 RVA: 0x0001A970 File Offset: 0x00018B70
		public override void WritePropertyName(string name)
		{
			base.InternalWritePropertyName(name);
			this.WriteEscapedString(name, this._quoteName);
			JsonTextWriter.smethod_20(this._writer, ':');
		}

		// Token: 0x06001F82 RID: 8066 RVA: 0x000855BC File Offset: 0x000837BC
		public override void WritePropertyName(string name, bool escape)
		{
			base.InternalWritePropertyName(name);
			if (escape)
			{
				this.WriteEscapedString(name, this._quoteName);
			}
			else
			{
				if (this._quoteName)
				{
					JsonTextWriter.smethod_20(this._writer, this._quoteChar);
				}
				JsonTextWriter.smethod_21(this._writer, name);
				if (this._quoteName)
				{
					JsonTextWriter.smethod_20(this._writer, this._quoteChar);
				}
			}
			JsonTextWriter.smethod_20(this._writer, ':');
		}

		// Token: 0x06001F83 RID: 8067 RVA: 0x0001A993 File Offset: 0x00018B93
		internal override void OnStringEscapeHandlingChanged()
		{
			this.UpdateCharEscapeFlags();
		}

		// Token: 0x06001F84 RID: 8068 RVA: 0x0001A99B File Offset: 0x00018B9B
		private void UpdateCharEscapeFlags()
		{
			this._charEscapeFlags = JavaScriptUtils.GetCharEscapeFlags(base.StringEscapeHandling, this._quoteChar);
		}

		// Token: 0x06001F85 RID: 8069 RVA: 0x00085630 File Offset: 0x00083830
		protected override void WriteIndent()
		{
			JsonTextWriter.smethod_23(this._writer);
			int i = base.Top * this._indentation;
			if (i > 0)
			{
				if (this._indentChars == null)
				{
					this._indentChars = JsonTextWriter.smethod_25(JsonTextWriter.smethod_24(this._indentChar, 10));
				}
				while (i > 0)
				{
					int num = JsonTextWriter.smethod_26(i, 10);
					JsonTextWriter.smethod_27(this._writer, this._indentChars, 0, num);
					i -= num;
				}
			}
		}

		// Token: 0x06001F86 RID: 8070 RVA: 0x0001A9B4 File Offset: 0x00018BB4
		protected override void WriteValueDelimiter()
		{
			JsonTextWriter.smethod_20(this._writer, ',');
		}

		// Token: 0x06001F87 RID: 8071 RVA: 0x0001A9C3 File Offset: 0x00018BC3
		protected override void WriteIndentSpace()
		{
			JsonTextWriter.smethod_20(this._writer, ' ');
		}

		// Token: 0x06001F88 RID: 8072 RVA: 0x0001A9D2 File Offset: 0x00018BD2
		private void WriteValueInternal(string value, JsonToken token)
		{
			JsonTextWriter.smethod_21(this._writer, value);
		}

		// Token: 0x06001F89 RID: 8073 RVA: 0x000856A0 File Offset: 0x000838A0
		public override void WriteValue(object value)
		{
			if (value is BigInteger)
			{
				base.InternalWriteValue(JsonToken.Integer);
				this.WriteValueInternal(((BigInteger)value).ToString(JsonTextWriter.smethod_28()), JsonToken.String);
				return;
			}
			base.WriteValue(value);
		}

		// Token: 0x06001F8A RID: 8074 RVA: 0x0001A9E0 File Offset: 0x00018BE0
		public override void WriteNull()
		{
			base.InternalWriteValue(JsonToken.Null);
			this.WriteValueInternal(JsonConvert.Null, JsonToken.Null);
		}

		// Token: 0x06001F8B RID: 8075 RVA: 0x0001A9F7 File Offset: 0x00018BF7
		public override void WriteUndefined()
		{
			base.InternalWriteValue(JsonToken.Undefined);
			this.WriteValueInternal(JsonConvert.Undefined, JsonToken.Undefined);
		}

		// Token: 0x06001F8C RID: 8076 RVA: 0x0001AA0E File Offset: 0x00018C0E
		public override void WriteRaw(string json)
		{
			base.InternalWriteRaw();
			JsonTextWriter.smethod_21(this._writer, json);
		}

		// Token: 0x06001F8D RID: 8077 RVA: 0x0001AA22 File Offset: 0x00018C22
		public override void WriteValue(string value)
		{
			base.InternalWriteValue(JsonToken.String);
			if (value == null)
			{
				this.WriteValueInternal(JsonConvert.Null, JsonToken.Null);
				return;
			}
			this.WriteEscapedString(value, true);
		}

		// Token: 0x06001F8E RID: 8078 RVA: 0x0001AA45 File Offset: 0x00018C45
		private void WriteEscapedString(string value, bool quote)
		{
			this.EnsureWriteBuffer();
			JavaScriptUtils.WriteEscapedJavaScriptString(this._writer, value, this._quoteChar, quote, this._charEscapeFlags, base.StringEscapeHandling, ref this._writeBuffer);
		}

		// Token: 0x06001F8F RID: 8079 RVA: 0x0001AA72 File Offset: 0x00018C72
		public override void WriteValue(int value)
		{
			base.InternalWriteValue(JsonToken.Integer);
			this.WriteIntegerValue((long)value);
		}

		// Token: 0x06001F90 RID: 8080 RVA: 0x0001AA83 File Offset: 0x00018C83
		[CLSCompliant(false)]
		public override void WriteValue(uint value)
		{
			base.InternalWriteValue(JsonToken.Integer);
			this.WriteIntegerValue((long)((ulong)value));
		}

		// Token: 0x06001F91 RID: 8081 RVA: 0x0001AA94 File Offset: 0x00018C94
		public override void WriteValue(long value)
		{
			base.InternalWriteValue(JsonToken.Integer);
			this.WriteIntegerValue(value);
		}

		// Token: 0x06001F92 RID: 8082 RVA: 0x0001AAA4 File Offset: 0x00018CA4
		[CLSCompliant(false)]
		public override void WriteValue(ulong value)
		{
			base.InternalWriteValue(JsonToken.Integer);
			this.WriteIntegerValue(value);
		}

		// Token: 0x06001F93 RID: 8083 RVA: 0x0001AAB4 File Offset: 0x00018CB4
		public override void WriteValue(float value)
		{
			base.InternalWriteValue(JsonToken.Float);
			this.WriteValueInternal(JsonConvert.ToString(value, base.FloatFormatHandling, this.QuoteChar, false), JsonToken.Float);
		}

		// Token: 0x06001F94 RID: 8084 RVA: 0x0001AAD7 File Offset: 0x00018CD7
		public override void WriteValue(float? value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			base.InternalWriteValue(JsonToken.Float);
			this.WriteValueInternal(JsonConvert.ToString(value.Value, base.FloatFormatHandling, this.QuoteChar, true), JsonToken.Float);
		}

		// Token: 0x06001F95 RID: 8085 RVA: 0x0001AB10 File Offset: 0x00018D10
		public override void WriteValue(double value)
		{
			base.InternalWriteValue(JsonToken.Float);
			this.WriteValueInternal(JsonConvert.ToString(value, base.FloatFormatHandling, this.QuoteChar, false), JsonToken.Float);
		}

		// Token: 0x06001F96 RID: 8086 RVA: 0x0001AB33 File Offset: 0x00018D33
		public override void WriteValue(double? value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			base.InternalWriteValue(JsonToken.Float);
			this.WriteValueInternal(JsonConvert.ToString(value.Value, base.FloatFormatHandling, this.QuoteChar, true), JsonToken.Float);
		}

		// Token: 0x06001F97 RID: 8087 RVA: 0x0001AB6C File Offset: 0x00018D6C
		public override void WriteValue(bool value)
		{
			base.InternalWriteValue(JsonToken.Boolean);
			this.WriteValueInternal(JsonConvert.ToString(value), JsonToken.Boolean);
		}

		// Token: 0x06001F98 RID: 8088 RVA: 0x0001AA72 File Offset: 0x00018C72
		public override void WriteValue(short value)
		{
			base.InternalWriteValue(JsonToken.Integer);
			this.WriteIntegerValue((long)value);
		}

		// Token: 0x06001F99 RID: 8089 RVA: 0x0001AA83 File Offset: 0x00018C83
		[CLSCompliant(false)]
		public override void WriteValue(ushort value)
		{
			base.InternalWriteValue(JsonToken.Integer);
			this.WriteIntegerValue((long)((ulong)value));
		}

		// Token: 0x06001F9A RID: 8090 RVA: 0x0001AB84 File Offset: 0x00018D84
		public override void WriteValue(char value)
		{
			base.InternalWriteValue(JsonToken.String);
			this.WriteValueInternal(JsonConvert.ToString(value), JsonToken.String);
		}

		// Token: 0x06001F9B RID: 8091 RVA: 0x0001AA83 File Offset: 0x00018C83
		public override void WriteValue(byte value)
		{
			base.InternalWriteValue(JsonToken.Integer);
			this.WriteIntegerValue((long)((ulong)value));
		}

		// Token: 0x06001F9C RID: 8092 RVA: 0x0001AA72 File Offset: 0x00018C72
		[CLSCompliant(false)]
		public override void WriteValue(sbyte value)
		{
			base.InternalWriteValue(JsonToken.Integer);
			this.WriteIntegerValue((long)value);
		}

		// Token: 0x06001F9D RID: 8093 RVA: 0x0001AB9C File Offset: 0x00018D9C
		public override void WriteValue(decimal value)
		{
			base.InternalWriteValue(JsonToken.Float);
			this.WriteValueInternal(JsonConvert.ToString(value), JsonToken.Float);
		}

		// Token: 0x06001F9E RID: 8094 RVA: 0x000856E0 File Offset: 0x000838E0
		public override void WriteValue(DateTime value)
		{
			base.InternalWriteValue(JsonToken.Date);
			value = DateTimeUtils.EnsureDateTime(value, base.DateTimeZoneHandling);
			if (JsonTextWriter.smethod_29(base.DateFormatString))
			{
				this.EnsureWriteBuffer();
				this._writeBuffer[0] = this._quoteChar;
				int num = DateTimeUtils.WriteDateTimeString(this._writeBuffer, 1, value, null, value.Kind, base.DateFormatHandling);
				this._writeBuffer[num++] = this._quoteChar;
				this._writer.Write(this._writeBuffer, 0, num);
				return;
			}
			this._writer.Write(this._quoteChar);
			this._writer.Write(value.ToString(base.DateFormatString, base.Culture));
			this._writer.Write(this._quoteChar);
		}

		// Token: 0x06001F9F RID: 8095 RVA: 0x000857B4 File Offset: 0x000839B4
		public override void WriteValue(byte[] value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			base.InternalWriteValue(JsonToken.Bytes);
			JsonTextWriter.smethod_20(this._writer, this._quoteChar);
			this.Base64Encoder.Encode(value, 0, value.Length);
			this.Base64Encoder.Flush();
			JsonTextWriter.smethod_20(this._writer, this._quoteChar);
		}

		// Token: 0x06001FA0 RID: 8096 RVA: 0x00085810 File Offset: 0x00083A10
		public override void WriteValue(DateTimeOffset value)
		{
			base.InternalWriteValue(JsonToken.Date);
			if (JsonTextWriter.smethod_29(base.DateFormatString))
			{
				this.EnsureWriteBuffer();
				this._writeBuffer[0] = this._quoteChar;
				int num = DateTimeUtils.WriteDateTimeString(this._writeBuffer, 1, (base.DateFormatHandling == DateFormatHandling.IsoDateFormat) ? value.DateTime : value.UtcDateTime, new TimeSpan?(value.Offset), DateTimeKind.Local, base.DateFormatHandling);
				this._writeBuffer[num++] = this._quoteChar;
				this._writer.Write(this._writeBuffer, 0, num);
				return;
			}
			this._writer.Write(this._quoteChar);
			this._writer.Write(value.ToString(base.DateFormatString, base.Culture));
			this._writer.Write(this._quoteChar);
		}

		// Token: 0x06001FA1 RID: 8097 RVA: 0x000858E8 File Offset: 0x00083AE8
		public override void WriteValue(Guid value)
		{
			base.InternalWriteValue(JsonToken.String);
			string text = value.ToString(<Module>.smethod_25<string>(3054924734U), JsonTextWriter.smethod_28());
			this._writer.Write(this._quoteChar);
			this._writer.Write(text);
			this._writer.Write(this._quoteChar);
		}

		// Token: 0x06001FA2 RID: 8098 RVA: 0x00085944 File Offset: 0x00083B44
		public override void WriteValue(TimeSpan value)
		{
			base.InternalWriteValue(JsonToken.String);
			string text = value.ToString(null, JsonTextWriter.smethod_28());
			this._writer.Write(this._quoteChar);
			this._writer.Write(text);
			this._writer.Write(this._quoteChar);
		}

		// Token: 0x06001FA3 RID: 8099 RVA: 0x0001ABB2 File Offset: 0x00018DB2
		public override void WriteValue(Uri value)
		{
			if (JsonTextWriter.smethod_30(value, null))
			{
				this.WriteNull();
				return;
			}
			base.InternalWriteValue(JsonToken.String);
			this.WriteEscapedString(JsonTextWriter.smethod_31(value), true);
		}

		// Token: 0x06001FA4 RID: 8100 RVA: 0x0001ABD9 File Offset: 0x00018DD9
		public override void WriteComment(string text)
		{
			base.InternalWriteComment();
			JsonTextWriter.smethod_21(this._writer, <Module>.smethod_25<string>(833193449U));
			JsonTextWriter.smethod_21(this._writer, text);
			JsonTextWriter.smethod_21(this._writer, <Module>.smethod_24<string>(1959172029U));
		}

		// Token: 0x06001FA5 RID: 8101 RVA: 0x0001AC17 File Offset: 0x00018E17
		public override void WriteWhitespace(string ws)
		{
			base.InternalWriteWhitespace(ws);
			JsonTextWriter.smethod_21(this._writer, ws);
		}

		// Token: 0x06001FA6 RID: 8102 RVA: 0x0001AC2C File Offset: 0x00018E2C
		private void EnsureWriteBuffer()
		{
			if (this._writeBuffer == null)
			{
				this._writeBuffer = new char[35];
			}
		}

		// Token: 0x06001FA7 RID: 8103 RVA: 0x00085998 File Offset: 0x00083B98
		private void WriteIntegerValue(long value)
		{
			if (value >= 0L && value <= 9L)
			{
				JsonTextWriter.smethod_20(this._writer, (char)(48L + value));
				return;
			}
			ulong num = (ulong)((value < 0L) ? (-(ulong)value) : value);
			if (value < 0L)
			{
				JsonTextWriter.smethod_20(this._writer, '-');
			}
			this.WriteIntegerValue(num);
		}

		// Token: 0x06001FA8 RID: 8104 RVA: 0x00085A08 File Offset: 0x00083C08
		private void WriteIntegerValue(ulong uvalue)
		{
			if (uvalue <= 9UL)
			{
				JsonTextWriter.smethod_20(this._writer, (char)(48UL + uvalue));
				return;
			}
			this.EnsureWriteBuffer();
			int num = MathUtils.IntLength(uvalue);
			int num2 = 0;
			do
			{
				this._writeBuffer[num - ++num2] = (char)(48UL + uvalue % 10UL);
				uvalue /= 10UL;
			}
			while (uvalue != 0UL);
			JsonTextWriter.smethod_27(this._writer, this._writeBuffer, 0, num2);
		}

		// Token: 0x06001FA9 RID: 8105 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_16(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x06001FAA RID: 8106 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_17(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x06001FAB RID: 8107 RVA: 0x000146F1 File Offset: 0x000128F1
		static void smethod_18(TextWriter textWriter_0)
		{
			textWriter_0.Flush();
		}

		// Token: 0x06001FAC RID: 8108 RVA: 0x0001AC43 File Offset: 0x00018E43
		static void smethod_19(TextWriter textWriter_0)
		{
			textWriter_0.Close();
		}

		// Token: 0x06001FAD RID: 8109 RVA: 0x0001AC4B File Offset: 0x00018E4B
		static void smethod_20(TextWriter textWriter_0, char char_0)
		{
			textWriter_0.Write(char_0);
		}

		// Token: 0x06001FAE RID: 8110 RVA: 0x000146E8 File Offset: 0x000128E8
		static void smethod_21(TextWriter textWriter_0, string string_0)
		{
			textWriter_0.Write(string_0);
		}

		// Token: 0x06001FAF RID: 8111 RVA: 0x0000EE96 File Offset: 0x0000D096
		static string smethod_22(object object_0, object object_1)
		{
			return object_0 + object_1;
		}

		// Token: 0x06001FB0 RID: 8112 RVA: 0x00016269 File Offset: 0x00014469
		static void smethod_23(TextWriter textWriter_0)
		{
			textWriter_0.WriteLine();
		}

		// Token: 0x06001FB1 RID: 8113 RVA: 0x000100A6 File Offset: 0x0000E2A6
		static string smethod_24(char char_0, int int_0)
		{
			return new string(char_0, int_0);
		}

		// Token: 0x06001FB2 RID: 8114 RVA: 0x0001AC54 File Offset: 0x00018E54
		static char[] smethod_25(string string_0)
		{
			return string_0.ToCharArray();
		}

		// Token: 0x06001FB3 RID: 8115 RVA: 0x0000F046 File Offset: 0x0000D246
		static int smethod_26(int int_0, int int_1)
		{
			return Math.Min(int_0, int_1);
		}

		// Token: 0x06001FB4 RID: 8116 RVA: 0x0001AC5C File Offset: 0x00018E5C
		static void smethod_27(TextWriter textWriter_0, char[] char_0, int int_0, int int_1)
		{
			textWriter_0.Write(char_0, int_0, int_1);
		}

		// Token: 0x06001FB5 RID: 8117 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_28()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001FB6 RID: 8118 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_29(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06001FB7 RID: 8119 RVA: 0x0000FCA7 File Offset: 0x0000DEA7
		static bool smethod_30(Uri uri_0, Uri uri_1)
		{
			return uri_0 == uri_1;
		}

		// Token: 0x06001FB8 RID: 8120 RVA: 0x0001AC67 File Offset: 0x00018E67
		static string smethod_31(Uri uri_0)
		{
			return uri_0.OriginalString;
		}

		// Token: 0x04000BA9 RID: 2985
		private readonly TextWriter _writer;

		// Token: 0x04000BAA RID: 2986
		private Base64Encoder _base64Encoder;

		// Token: 0x04000BAB RID: 2987
		private char _indentChar;

		// Token: 0x04000BAC RID: 2988
		private int _indentation;

		// Token: 0x04000BAD RID: 2989
		private char _quoteChar;

		// Token: 0x04000BAE RID: 2990
		private bool _quoteName;

		// Token: 0x04000BAF RID: 2991
		private bool[] _charEscapeFlags;

		// Token: 0x04000BB0 RID: 2992
		private char[] _writeBuffer;

		// Token: 0x04000BB1 RID: 2993
		private char[] _indentChars;
	}
}
