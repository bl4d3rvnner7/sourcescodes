﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json
{
	// Token: 0x020001BE RID: 446
	internal struct JsonPosition
	{
		// Token: 0x0600199B RID: 6555 RVA: 0x00017A4E File Offset: 0x00015C4E
		public JsonPosition(JsonContainerType type)
		{
			this.Type = type;
			this.HasIndex = JsonPosition.TypeHasIndex(type);
			this.Position = -1;
			this.PropertyName = null;
		}

		// Token: 0x0600199C RID: 6556 RVA: 0x00077B4C File Offset: 0x00075D4C
		internal void WriteTo(StringBuilder sb)
		{
			switch (this.Type)
			{
			case JsonContainerType.Object:
			{
				if (JsonPosition.smethod_0(sb) > 0)
				{
					JsonPosition.smethod_1(sb, '.');
				}
				string propertyName = this.PropertyName;
				if (JsonPosition.smethod_2(propertyName, JsonPosition.SpecialCharacters) != -1)
				{
					JsonPosition.smethod_3(sb, <Module>.smethod_27<string>(3194855935U));
					JsonPosition.smethod_3(sb, propertyName);
					JsonPosition.smethod_3(sb, <Module>.smethod_24<string>(960242464U));
					return;
				}
				JsonPosition.smethod_3(sb, propertyName);
				return;
			}
			case JsonContainerType.Array:
			case JsonContainerType.Constructor:
				JsonPosition.smethod_1(sb, '[');
				JsonPosition.smethod_4(sb, this.Position);
				JsonPosition.smethod_1(sb, ']');
				return;
			default:
				return;
			}
		}

		// Token: 0x0600199D RID: 6557 RVA: 0x00017A71 File Offset: 0x00015C71
		internal static bool TypeHasIndex(JsonContainerType type)
		{
			return type == JsonContainerType.Array || type == JsonContainerType.Constructor;
		}

		// Token: 0x0600199E RID: 6558 RVA: 0x00077BF0 File Offset: 0x00075DF0
		internal static string BuildPath(IEnumerable<JsonPosition> positions)
		{
			StringBuilder stringBuilder = JsonPosition.smethod_5();
			IEnumerator<JsonPosition> enumerator = positions.GetEnumerator();
			try
			{
				while (JsonPosition.smethod_6(enumerator))
				{
					JsonPosition jsonPosition = enumerator.Current;
					jsonPosition.WriteTo(stringBuilder);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JsonPosition.smethod_7(enumerator);
				}
			}
			return JsonPosition.smethod_8(stringBuilder);
		}

		// Token: 0x0600199F RID: 6559 RVA: 0x00077C48 File Offset: 0x00075E48
		internal static string FormatMessage(IJsonLineInfo lineInfo, string path, string message)
		{
			if (!JsonPosition.smethod_10(message, JsonPosition.smethod_9(), StringComparison.Ordinal))
			{
				message = JsonPosition.smethod_11(message);
				if (!message.EndsWith('.'))
				{
					message = JsonPosition.smethod_12(message, <Module>.smethod_25<string>(1403186598U));
				}
				message = JsonPosition.smethod_12(message, <Module>.smethod_25<string>(482330791U));
			}
			message = JsonPosition.smethod_12(message, <Module>.smethod_26<string>(2394282353U).FormatWith(JsonPosition.smethod_13(), path));
			if (lineInfo != null && lineInfo.HasLineInfo())
			{
				message = JsonPosition.smethod_12(message, <Module>.smethod_25<string>(3243860448U).FormatWith(JsonPosition.smethod_13(), lineInfo.LineNumber, lineInfo.LinePosition));
			}
			message = JsonPosition.smethod_12(message, <Module>.smethod_27<string>(859418173U));
			return message;
		}

		// Token: 0x060019A0 RID: 6560 RVA: 0x00017A7D File Offset: 0x00015C7D
		// Note: this type is marked as 'beforefieldinit'.
		static JsonPosition()
		{
			char[] array = new char[6];
			JsonPosition.smethod_14(array, fieldof(<PrivateImplementationDetails>{2050F94B-4B51-45A2-913D-663F8B3DB301}.$$method0x6000bf7-1).FieldHandle);
			JsonPosition.SpecialCharacters = array;
		}

		// Token: 0x060019A1 RID: 6561 RVA: 0x00010084 File Offset: 0x0000E284
		static int smethod_0(StringBuilder stringBuilder_0)
		{
			return stringBuilder_0.Length;
		}

		// Token: 0x060019A2 RID: 6562 RVA: 0x0001008C File Offset: 0x0000E28C
		static StringBuilder smethod_1(StringBuilder stringBuilder_0, char char_0)
		{
			return stringBuilder_0.Append(char_0);
		}

		// Token: 0x060019A3 RID: 6563 RVA: 0x00017A95 File Offset: 0x00015C95
		static int smethod_2(string string_0, char[] char_0)
		{
			return string_0.IndexOfAny(char_0);
		}

		// Token: 0x060019A4 RID: 6564 RVA: 0x0000DB11 File Offset: 0x0000BD11
		static StringBuilder smethod_3(StringBuilder stringBuilder_0, string string_0)
		{
			return stringBuilder_0.Append(string_0);
		}

		// Token: 0x060019A5 RID: 6565 RVA: 0x00017A9E File Offset: 0x00015C9E
		static StringBuilder smethod_4(StringBuilder stringBuilder_0, int int_0)
		{
			return stringBuilder_0.Append(int_0);
		}

		// Token: 0x060019A6 RID: 6566 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_5()
		{
			return new StringBuilder();
		}

		// Token: 0x060019A7 RID: 6567 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_6(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060019A8 RID: 6568 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_7(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060019A9 RID: 6569 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_8(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x060019AA RID: 6570 RVA: 0x0000CD86 File Offset: 0x0000AF86
		static string smethod_9()
		{
			return Environment.NewLine;
		}

		// Token: 0x060019AB RID: 6571 RVA: 0x00017AA7 File Offset: 0x00015CA7
		static bool smethod_10(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.EndsWith(string_1, stringComparison_0);
		}

		// Token: 0x060019AC RID: 6572 RVA: 0x0000C6B8 File Offset: 0x0000A8B8
		static string smethod_11(string string_0)
		{
			return string_0.Trim();
		}

		// Token: 0x060019AD RID: 6573 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_12(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x060019AE RID: 6574 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_13()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060019AF RID: 6575 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_14(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x040009E4 RID: 2532
		private static readonly char[] SpecialCharacters;

		// Token: 0x040009E5 RID: 2533
		internal JsonContainerType Type;

		// Token: 0x040009E6 RID: 2534
		internal int Position;

		// Token: 0x040009E7 RID: 2535
		internal string PropertyName;

		// Token: 0x040009E8 RID: 2536
		internal bool HasIndex;
	}
}
