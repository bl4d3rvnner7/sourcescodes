﻿using System;

namespace Newtonsoft.Json.Bson
{
	// Token: 0x02000192 RID: 402
	internal abstract class BsonToken
	{
		// Token: 0x17000376 RID: 886
		// (get) Token: 0x060017D1 RID: 6097
		public abstract BsonType Type { get; }

		// Token: 0x17000377 RID: 887
		// (get) Token: 0x060017D2 RID: 6098 RVA: 0x00016AA6 File Offset: 0x00014CA6
		// (set) Token: 0x060017D3 RID: 6099 RVA: 0x00016AAE File Offset: 0x00014CAE
		public BsonToken Parent { get; set; }

		// Token: 0x17000378 RID: 888
		// (get) Token: 0x060017D4 RID: 6100 RVA: 0x00016AB7 File Offset: 0x00014CB7
		// (set) Token: 0x060017D5 RID: 6101 RVA: 0x00016ABF File Offset: 0x00014CBF
		public int CalculatedSize { get; set; }
	}
}
