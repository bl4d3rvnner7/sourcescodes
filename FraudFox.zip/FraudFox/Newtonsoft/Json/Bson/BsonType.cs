﻿using System;

namespace Newtonsoft.Json.Bson
{
	// Token: 0x0200019A RID: 410
	internal enum BsonType : sbyte
	{
		// Token: 0x0400096E RID: 2414
		Number = 1,
		// Token: 0x0400096F RID: 2415
		String,
		// Token: 0x04000970 RID: 2416
		Object,
		// Token: 0x04000971 RID: 2417
		Array,
		// Token: 0x04000972 RID: 2418
		Binary,
		// Token: 0x04000973 RID: 2419
		Undefined,
		// Token: 0x04000974 RID: 2420
		Oid,
		// Token: 0x04000975 RID: 2421
		Boolean,
		// Token: 0x04000976 RID: 2422
		Date,
		// Token: 0x04000977 RID: 2423
		Null,
		// Token: 0x04000978 RID: 2424
		Regex,
		// Token: 0x04000979 RID: 2425
		Reference,
		// Token: 0x0400097A RID: 2426
		Code,
		// Token: 0x0400097B RID: 2427
		Symbol,
		// Token: 0x0400097C RID: 2428
		CodeWScope,
		// Token: 0x0400097D RID: 2429
		Integer,
		// Token: 0x0400097E RID: 2430
		TimeStamp,
		// Token: 0x0400097F RID: 2431
		Long,
		// Token: 0x04000980 RID: 2432
		MinKey = -1,
		// Token: 0x04000981 RID: 2433
		MaxKey = 127
	}
}
