﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Newtonsoft.Json.Bson
{
	// Token: 0x02000193 RID: 403
	internal class BsonObject : BsonToken, IEnumerable<BsonProperty>, IEnumerable
	{
		// Token: 0x060017D7 RID: 6103 RVA: 0x0007478C File Offset: 0x0007298C
		public void Add(string name, BsonToken token)
		{
			this._children.Add(new BsonProperty
			{
				Name = new BsonString(name, false),
				Value = token
			});
			token.Parent = this;
		}

		// Token: 0x17000379 RID: 889
		// (get) Token: 0x060017D8 RID: 6104 RVA: 0x00016AC8 File Offset: 0x00014CC8
		public override BsonType Type
		{
			get
			{
				return BsonType.Object;
			}
		}

		// Token: 0x060017D9 RID: 6105 RVA: 0x00016ACB File Offset: 0x00014CCB
		public IEnumerator<BsonProperty> GetEnumerator()
		{
			return this._children.GetEnumerator();
		}

		// Token: 0x060017DA RID: 6106 RVA: 0x00016ADD File Offset: 0x00014CDD
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		// Token: 0x04000962 RID: 2402
		private readonly List<BsonProperty> _children = new List<BsonProperty>();
	}
}
