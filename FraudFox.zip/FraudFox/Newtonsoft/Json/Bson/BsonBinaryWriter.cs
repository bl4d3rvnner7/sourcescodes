﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Bson
{
	// Token: 0x0200018C RID: 396
	internal class BsonBinaryWriter
	{
		// Token: 0x17000363 RID: 867
		// (get) Token: 0x0600172F RID: 5935 RVA: 0x00016567 File Offset: 0x00014767
		// (set) Token: 0x06001730 RID: 5936 RVA: 0x0001656F File Offset: 0x0001476F
		public DateTimeKind DateTimeKindHandling { get; set; }

		// Token: 0x06001731 RID: 5937 RVA: 0x00016578 File Offset: 0x00014778
		public BsonBinaryWriter(BinaryWriter writer)
		{
			this.DateTimeKindHandling = DateTimeKind.Utc;
			this._writer = writer;
		}

		// Token: 0x06001732 RID: 5938 RVA: 0x0001658E File Offset: 0x0001478E
		public void Flush()
		{
			BsonBinaryWriter.smethod_0(this._writer);
		}

		// Token: 0x06001733 RID: 5939 RVA: 0x0001659B File Offset: 0x0001479B
		public void Close()
		{
			BsonBinaryWriter.smethod_1(this._writer);
		}

		// Token: 0x06001734 RID: 5940 RVA: 0x000165A8 File Offset: 0x000147A8
		public void WriteToken(BsonToken t)
		{
			this.CalculateSize(t);
			this.WriteTokenInternal(t);
		}

		// Token: 0x06001735 RID: 5941 RVA: 0x00072680 File Offset: 0x00070880
		private void WriteTokenInternal(BsonToken t)
		{
			BsonType type = t.Type;
			BsonObject bsonObject;
			for (;;)
			{
				IL_00AB:
				int num = 1992933866;
				for (;;)
				{
					switch (num ^ 1992933867)
					{
					case 0:
						goto IL_00AB;
					case 1:
						switch (type)
						{
						case BsonType.Number:
							goto IL_00B2;
						case BsonType.String:
							goto IL_00D7;
						case BsonType.Object:
							goto IL_000C;
						case BsonType.Array:
							goto IL_0107;
						case BsonType.Binary:
							goto IL_01B0;
						case BsonType.Undefined:
						case BsonType.Null:
							return;
						case BsonType.Oid:
							goto IL_01F5;
						case BsonType.Boolean:
							goto IL_0219;
						case BsonType.Date:
							goto IL_0239;
						case BsonType.Regex:
							goto IL_02CC;
						case BsonType.Integer:
							goto IL_032F;
						case BsonType.Long:
							goto IL_0383;
						}
						goto Block_1;
					case 2:
						BsonBinaryWriter.smethod_2(this._writer, bsonObject.CalculatedSize);
						num = 1992933864;
						continue;
					case 4:
						goto IL_000C;
					}
					goto Block_2;
					IL_000C:
					bsonObject = (BsonObject)t;
					num = 1992933865;
				}
			}
			Block_1:
			goto IL_0354;
			Block_2:
			goto IL_03A8;
			IL_00B2:
			BsonValue bsonValue = (BsonValue)t;
			this._writer.Write(Convert.ToDouble(bsonValue.Value, CultureInfo.InvariantCulture));
			return;
			IL_00D7:
			BsonString bsonString = (BsonString)t;
			this.WriteString((string)bsonString.Value, bsonString.ByteCount, new int?(bsonString.CalculatedSize - 4));
			return;
			IL_0107:
			BsonArray bsonArray = (BsonArray)t;
			BsonBinaryWriter.smethod_2(this._writer, bsonArray.CalculatedSize);
			ulong num2 = 0UL;
			foreach (BsonToken bsonToken in bsonArray)
			{
				BsonBinaryWriter.smethod_3(this._writer, (sbyte)bsonToken.Type);
				this.WriteString(num2.ToString(BsonBinaryWriter.smethod_7()), MathUtils.IntLength(num2), null);
				this.WriteTokenInternal(bsonToken);
				num2 += 1UL;
			}
			this._writer.Write(0);
			return;
			IL_01B0:
			BsonBinary bsonBinary = (BsonBinary)t;
			byte[] array = (byte[])bsonBinary.Value;
			this._writer.Write(array.Length);
			this._writer.Write((byte)bsonBinary.BinaryType);
			this._writer.Write(array);
			return;
			IL_01F5:
			BsonValue bsonValue2 = (BsonValue)t;
			byte[] array2 = (byte[])bsonValue2.Value;
			this._writer.Write(array2);
			return;
			IL_0219:
			BsonValue bsonValue3 = (BsonValue)t;
			this._writer.Write((bool)bsonValue3.Value);
			return;
			IL_0239:
			BsonValue bsonValue4 = (BsonValue)t;
			long num3;
			if (bsonValue4.Value is DateTime)
			{
				DateTime dateTime = (DateTime)bsonValue4.Value;
				if (this.DateTimeKindHandling == DateTimeKind.Utc)
				{
					dateTime = dateTime.ToUniversalTime();
				}
				else if (this.DateTimeKindHandling == DateTimeKind.Local)
				{
					dateTime = dateTime.ToLocalTime();
				}
				num3 = DateTimeUtils.ConvertDateTimeToJavaScriptTicks(dateTime, false);
			}
			else
			{
				DateTimeOffset dateTimeOffset = (DateTimeOffset)bsonValue4.Value;
				num3 = DateTimeUtils.ConvertDateTimeToJavaScriptTicks(dateTimeOffset.UtcDateTime, dateTimeOffset.Offset);
			}
			this._writer.Write(num3);
			return;
			IL_02CC:
			BsonRegex bsonRegex = (BsonRegex)t;
			this.WriteString((string)bsonRegex.Pattern.Value, bsonRegex.Pattern.ByteCount, null);
			this.WriteString((string)bsonRegex.Options.Value, bsonRegex.Options.ByteCount, null);
			return;
			IL_032F:
			BsonValue bsonValue5 = (BsonValue)t;
			this._writer.Write(Convert.ToInt32(bsonValue5.Value, CultureInfo.InvariantCulture));
			return;
			IL_0354:
			throw new ArgumentOutOfRangeException(<Module>.smethod_24<string>(2212198272U), <Module>.smethod_26<string>(3773283089U).FormatWith(CultureInfo.InvariantCulture, t.Type));
			IL_0383:
			BsonValue bsonValue6 = (BsonValue)t;
			this._writer.Write(Convert.ToInt64(bsonValue6.Value, CultureInfo.InvariantCulture));
			return;
			IL_03A8:
			IEnumerator<BsonProperty> enumerator2 = bsonObject.GetEnumerator();
			try
			{
				while (BsonBinaryWriter.smethod_4(enumerator2))
				{
					BsonProperty bsonProperty = enumerator2.Current;
					BsonBinaryWriter.smethod_3(this._writer, (sbyte)bsonProperty.Value.Type);
					this.WriteString((string)bsonProperty.Name.Value, bsonProperty.Name.ByteCount, null);
					this.WriteTokenInternal(bsonProperty.Value);
				}
			}
			finally
			{
				if (enumerator2 != null)
				{
					BsonBinaryWriter.smethod_5(enumerator2);
				}
			}
			BsonBinaryWriter.smethod_6(this._writer, 0);
		}

		// Token: 0x06001736 RID: 5942 RVA: 0x000165B9 File Offset: 0x000147B9
		private void WriteString(string s, int byteCount, int? calculatedlengthPrefix)
		{
			if (calculatedlengthPrefix != null)
			{
				BsonBinaryWriter.smethod_2(this._writer, calculatedlengthPrefix.Value);
			}
			this.WriteUtf8Bytes(s, byteCount);
			BsonBinaryWriter.smethod_6(this._writer, 0);
		}

		// Token: 0x06001737 RID: 5943 RVA: 0x00072AD0 File Offset: 0x00070CD0
		public void WriteUtf8Bytes(string s, int byteCount)
		{
			if (s != null)
			{
				if (this._largeByteBuffer == null)
				{
					this._largeByteBuffer = new byte[256];
				}
				if (byteCount <= 256)
				{
					BsonBinaryWriter.smethod_9(BsonBinaryWriter.Encoding, s, 0, BsonBinaryWriter.smethod_8(s), this._largeByteBuffer, 0);
					BsonBinaryWriter.smethod_10(this._writer, this._largeByteBuffer, 0, byteCount);
					return;
				}
				byte[] array = BsonBinaryWriter.smethod_11(BsonBinaryWriter.Encoding, s);
				BsonBinaryWriter.smethod_12(this._writer, array);
			}
		}

		// Token: 0x06001738 RID: 5944 RVA: 0x000165EA File Offset: 0x000147EA
		private int CalculateSize(int stringByteCount)
		{
			return stringByteCount + 1;
		}

		// Token: 0x06001739 RID: 5945 RVA: 0x00072B48 File Offset: 0x00070D48
		private int CalculateSizeWithLength(int stringByteCount, bool includeSize)
		{
			int num = (includeSize ? 5 : 1);
			return num + stringByteCount;
		}

		// Token: 0x0600173A RID: 5946 RVA: 0x00072B60 File Offset: 0x00070D60
		private int CalculateSize(BsonToken t)
		{
			switch (t.Type)
			{
			case BsonType.Number:
				return 8;
			case BsonType.String:
			{
				BsonString bsonString = (BsonString)t;
				string text = (string)bsonString.Value;
				bsonString.ByteCount = ((text != null) ? BsonBinaryWriter.smethod_13(BsonBinaryWriter.Encoding, text) : 0);
				bsonString.CalculatedSize = this.CalculateSizeWithLength(bsonString.ByteCount, bsonString.IncludeLength);
				return bsonString.CalculatedSize;
			}
			case BsonType.Object:
			{
				BsonObject bsonObject = (BsonObject)t;
				int num = 4;
				IEnumerator<BsonProperty> enumerator = bsonObject.GetEnumerator();
				try
				{
					while (BsonBinaryWriter.smethod_4(enumerator))
					{
						BsonProperty bsonProperty = enumerator.Current;
						int num2 = 1 + this.CalculateSize(bsonProperty.Name);
						num2 += this.CalculateSize(bsonProperty.Value);
						num += num2;
					}
				}
				finally
				{
					if (enumerator != null)
					{
						BsonBinaryWriter.smethod_5(enumerator);
					}
				}
				num++;
				bsonObject.CalculatedSize = num;
				return num;
			}
			case BsonType.Array:
			{
				BsonArray bsonArray = (BsonArray)t;
				int num3 = 4;
				ulong num4 = 0UL;
				IEnumerator<BsonToken> enumerator2 = bsonArray.GetEnumerator();
				try
				{
					while (BsonBinaryWriter.smethod_4(enumerator2))
					{
						BsonToken bsonToken = enumerator2.Current;
						num3++;
						num3 += this.CalculateSize(MathUtils.IntLength(num4));
						num3 += this.CalculateSize(bsonToken);
						num4 += 1UL;
					}
				}
				finally
				{
					if (enumerator2 != null)
					{
						BsonBinaryWriter.smethod_5(enumerator2);
					}
				}
				num3++;
				bsonArray.CalculatedSize = num3;
				return bsonArray.CalculatedSize;
			}
			case BsonType.Binary:
			{
				BsonBinary bsonBinary = (BsonBinary)t;
				byte[] array = (byte[])bsonBinary.Value;
				bsonBinary.CalculatedSize = 5 + array.Length;
				return bsonBinary.CalculatedSize;
			}
			case BsonType.Undefined:
			case BsonType.Null:
				return 0;
			case BsonType.Oid:
				return 12;
			case BsonType.Boolean:
				return 1;
			case BsonType.Date:
				return 8;
			case BsonType.Regex:
			{
				BsonRegex bsonRegex = (BsonRegex)t;
				int num5 = 0 + this.CalculateSize(bsonRegex.Pattern);
				num5 += this.CalculateSize(bsonRegex.Options);
				bsonRegex.CalculatedSize = num5;
				return bsonRegex.CalculatedSize;
			}
			case BsonType.Integer:
				return 4;
			case BsonType.Long:
				return 8;
			}
			throw BsonBinaryWriter.smethod_14(<Module>.smethod_27<string>(2424923941U), <Module>.smethod_27<string>(2704654099U).FormatWith(BsonBinaryWriter.smethod_7(), t.Type));
		}

		// Token: 0x0600173C RID: 5948 RVA: 0x000165FC File Offset: 0x000147FC
		static void smethod_0(BinaryWriter binaryWriter_0)
		{
			binaryWriter_0.Flush();
		}

		// Token: 0x0600173D RID: 5949 RVA: 0x00016604 File Offset: 0x00014804
		static void smethod_1(BinaryWriter binaryWriter_0)
		{
			binaryWriter_0.Close();
		}

		// Token: 0x0600173E RID: 5950 RVA: 0x0001660C File Offset: 0x0001480C
		static void smethod_2(BinaryWriter binaryWriter_0, int int_0)
		{
			binaryWriter_0.Write(int_0);
		}

		// Token: 0x0600173F RID: 5951 RVA: 0x00016615 File Offset: 0x00014815
		static void smethod_3(BinaryWriter binaryWriter_0, sbyte sbyte_0)
		{
			binaryWriter_0.Write(sbyte_0);
		}

		// Token: 0x06001740 RID: 5952 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_4(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06001741 RID: 5953 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_5(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06001742 RID: 5954 RVA: 0x0001661E File Offset: 0x0001481E
		static void smethod_6(BinaryWriter binaryWriter_0, byte byte_0)
		{
			binaryWriter_0.Write(byte_0);
		}

		// Token: 0x06001743 RID: 5955 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_7()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001744 RID: 5956 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_8(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06001745 RID: 5957 RVA: 0x00016627 File Offset: 0x00014827
		static int smethod_9(Encoding encoding_0, string string_0, int int_0, int int_1, byte[] byte_0, int int_2)
		{
			return encoding_0.GetBytes(string_0, int_0, int_1, byte_0, int_2);
		}

		// Token: 0x06001746 RID: 5958 RVA: 0x00016636 File Offset: 0x00014836
		static void smethod_10(BinaryWriter binaryWriter_0, byte[] byte_0, int int_0, int int_1)
		{
			binaryWriter_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x06001747 RID: 5959 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_11(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x06001748 RID: 5960 RVA: 0x00016641 File Offset: 0x00014841
		static void smethod_12(BinaryWriter binaryWriter_0, byte[] byte_0)
		{
			binaryWriter_0.Write(byte_0);
		}

		// Token: 0x06001749 RID: 5961 RVA: 0x0001233F File Offset: 0x0001053F
		static int smethod_13(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetByteCount(string_0);
		}

		// Token: 0x0600174A RID: 5962 RVA: 0x0000DECA File Offset: 0x0000C0CA
		static ArgumentOutOfRangeException smethod_14(string string_0, string string_1)
		{
			return new ArgumentOutOfRangeException(string_0, string_1);
		}

		// Token: 0x0600174B RID: 5963 RVA: 0x0001664A File Offset: 0x0001484A
		static UTF8Encoding smethod_15(bool bool_0)
		{
			return new UTF8Encoding(bool_0);
		}

		// Token: 0x04000922 RID: 2338
		private static readonly Encoding Encoding = BsonBinaryWriter.smethod_15(false);

		// Token: 0x04000923 RID: 2339
		private readonly BinaryWriter _writer;

		// Token: 0x04000924 RID: 2340
		private byte[] _largeByteBuffer;
	}
}
