﻿using System;

namespace Newtonsoft.Json.Bson
{
	// Token: 0x02000199 RID: 409
	internal class BsonProperty
	{
		// Token: 0x17000383 RID: 899
		// (get) Token: 0x060017F2 RID: 6130 RVA: 0x00016C00 File Offset: 0x00014E00
		// (set) Token: 0x060017F3 RID: 6131 RVA: 0x00016C08 File Offset: 0x00014E08
		public BsonString Name { get; set; }

		// Token: 0x17000384 RID: 900
		// (get) Token: 0x060017F4 RID: 6132 RVA: 0x00016C11 File Offset: 0x00014E11
		// (set) Token: 0x060017F5 RID: 6133 RVA: 0x00016C19 File Offset: 0x00014E19
		public BsonToken Value { get; set; }
	}
}
