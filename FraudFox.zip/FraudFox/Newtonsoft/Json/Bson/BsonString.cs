﻿using System;

namespace Newtonsoft.Json.Bson
{
	// Token: 0x02000196 RID: 406
	internal class BsonString : BsonValue
	{
		// Token: 0x1700037D RID: 893
		// (get) Token: 0x060017E4 RID: 6116 RVA: 0x00016B63 File Offset: 0x00014D63
		// (set) Token: 0x060017E5 RID: 6117 RVA: 0x00016B6B File Offset: 0x00014D6B
		public int ByteCount { get; set; }

		// Token: 0x1700037E RID: 894
		// (get) Token: 0x060017E6 RID: 6118 RVA: 0x00016B74 File Offset: 0x00014D74
		// (set) Token: 0x060017E7 RID: 6119 RVA: 0x00016B7C File Offset: 0x00014D7C
		public bool IncludeLength { get; set; }

		// Token: 0x060017E8 RID: 6120 RVA: 0x00016B85 File Offset: 0x00014D85
		public BsonString(object value, bool includeLength)
			: base(value, BsonType.String)
		{
			this.IncludeLength = includeLength;
		}
	}
}
