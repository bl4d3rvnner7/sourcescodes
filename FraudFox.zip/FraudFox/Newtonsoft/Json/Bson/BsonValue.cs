﻿using System;

namespace Newtonsoft.Json.Bson
{
	// Token: 0x02000195 RID: 405
	internal class BsonValue : BsonToken
	{
		// Token: 0x060017E1 RID: 6113 RVA: 0x00016B3D File Offset: 0x00014D3D
		public BsonValue(object value, BsonType type)
		{
			this._value = value;
			this._type = type;
		}

		// Token: 0x1700037B RID: 891
		// (get) Token: 0x060017E2 RID: 6114 RVA: 0x00016B53 File Offset: 0x00014D53
		public object Value
		{
			get
			{
				return this._value;
			}
		}

		// Token: 0x1700037C RID: 892
		// (get) Token: 0x060017E3 RID: 6115 RVA: 0x00016B5B File Offset: 0x00014D5B
		public override BsonType Type
		{
			get
			{
				return this._type;
			}
		}

		// Token: 0x04000964 RID: 2404
		private readonly object _value;

		// Token: 0x04000965 RID: 2405
		private readonly BsonType _type;
	}
}
