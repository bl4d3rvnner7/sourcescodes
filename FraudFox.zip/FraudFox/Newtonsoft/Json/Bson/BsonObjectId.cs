﻿using System;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Bson
{
	// Token: 0x0200019E RID: 414
	public class BsonObjectId
	{
		// Token: 0x17000392 RID: 914
		// (get) Token: 0x060018A5 RID: 6309 RVA: 0x00017517 File Offset: 0x00015717
		// (set) Token: 0x060018A6 RID: 6310 RVA: 0x0001751F File Offset: 0x0001571F
		public byte[] Value { get; private set; }

		// Token: 0x060018A7 RID: 6311 RVA: 0x00017528 File Offset: 0x00015728
		public BsonObjectId(byte[] value)
		{
			ValidationUtils.ArgumentNotNull(value, <Module>.smethod_26<string>(1806306238U));
			if (value.Length != 12)
			{
				throw BsonObjectId.smethod_0(<Module>.smethod_24<string>(3349835297U), <Module>.smethod_27<string>(2371252898U));
			}
			this.Value = value;
		}

		// Token: 0x060018A8 RID: 6312 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_0(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}
	}
}
