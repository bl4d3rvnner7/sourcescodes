﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Bson
{
	// Token: 0x0200018F RID: 399
	public class BsonReader : JsonReader
	{
		// Token: 0x17000373 RID: 883
		// (get) Token: 0x06001791 RID: 6033 RVA: 0x0001684C File Offset: 0x00014A4C
		// (set) Token: 0x06001792 RID: 6034 RVA: 0x00016854 File Offset: 0x00014A54
		[Obsolete("JsonNet35BinaryCompatibility will be removed in a future version of Json.NET.")]
		public bool JsonNet35BinaryCompatibility
		{
			get
			{
				return this._jsonNet35BinaryCompatibility;
			}
			set
			{
				this._jsonNet35BinaryCompatibility = value;
			}
		}

		// Token: 0x17000374 RID: 884
		// (get) Token: 0x06001793 RID: 6035 RVA: 0x0001685D File Offset: 0x00014A5D
		// (set) Token: 0x06001794 RID: 6036 RVA: 0x00016865 File Offset: 0x00014A65
		public bool ReadRootValueAsArray
		{
			get
			{
				return this._readRootValueAsArray;
			}
			set
			{
				this._readRootValueAsArray = value;
			}
		}

		// Token: 0x17000375 RID: 885
		// (get) Token: 0x06001795 RID: 6037 RVA: 0x0001686E File Offset: 0x00014A6E
		// (set) Token: 0x06001796 RID: 6038 RVA: 0x00016876 File Offset: 0x00014A76
		public DateTimeKind DateTimeKindHandling
		{
			get
			{
				return this._dateTimeKindHandling;
			}
			set
			{
				this._dateTimeKindHandling = value;
			}
		}

		// Token: 0x06001797 RID: 6039 RVA: 0x0001687F File Offset: 0x00014A7F
		public BsonReader(Stream stream)
			: this(stream, false, DateTimeKind.Local)
		{
		}

		// Token: 0x06001798 RID: 6040 RVA: 0x0001688A File Offset: 0x00014A8A
		public BsonReader(BinaryReader reader)
			: this(reader, false, DateTimeKind.Local)
		{
		}

		// Token: 0x06001799 RID: 6041 RVA: 0x00016895 File Offset: 0x00014A95
		public BsonReader(Stream stream, bool readRootValueAsArray, DateTimeKind dateTimeKindHandling)
		{
			ValidationUtils.ArgumentNotNull(stream, <Module>.smethod_25<string>(1482447994U));
			this._reader = BsonReader.smethod_12(stream);
			this._stack = new List<BsonReader.ContainerContext>();
			this._readRootValueAsArray = readRootValueAsArray;
			this._dateTimeKindHandling = dateTimeKindHandling;
		}

		// Token: 0x0600179A RID: 6042 RVA: 0x000168D2 File Offset: 0x00014AD2
		public BsonReader(BinaryReader reader, bool readRootValueAsArray, DateTimeKind dateTimeKindHandling)
		{
			ValidationUtils.ArgumentNotNull(reader, <Module>.smethod_27<string>(3246799795U));
			this._reader = reader;
			this._stack = new List<BsonReader.ContainerContext>();
			this._readRootValueAsArray = readRootValueAsArray;
			this._dateTimeKindHandling = dateTimeKindHandling;
		}

		// Token: 0x0600179B RID: 6043 RVA: 0x00073B60 File Offset: 0x00071D60
		private string ReadElement()
		{
			this._currentElementType = this.ReadType();
			return this.ReadString();
		}

		// Token: 0x0600179C RID: 6044 RVA: 0x0001690A File Offset: 0x00014B0A
		public override byte[] ReadAsBytes()
		{
			return base.ReadAsBytesInternal();
		}

		// Token: 0x0600179D RID: 6045 RVA: 0x00016912 File Offset: 0x00014B12
		public override decimal? ReadAsDecimal()
		{
			return base.ReadAsDecimalInternal();
		}

		// Token: 0x0600179E RID: 6046 RVA: 0x0001691A File Offset: 0x00014B1A
		public override int? ReadAsInt32()
		{
			return base.ReadAsInt32Internal();
		}

		// Token: 0x0600179F RID: 6047 RVA: 0x00016922 File Offset: 0x00014B22
		public override string ReadAsString()
		{
			return base.ReadAsStringInternal();
		}

		// Token: 0x060017A0 RID: 6048 RVA: 0x0001692A File Offset: 0x00014B2A
		public override DateTime? ReadAsDateTime()
		{
			return base.ReadAsDateTimeInternal();
		}

		// Token: 0x060017A1 RID: 6049 RVA: 0x00016932 File Offset: 0x00014B32
		public override DateTimeOffset? ReadAsDateTimeOffset()
		{
			return base.ReadAsDateTimeOffsetInternal();
		}

		// Token: 0x060017A2 RID: 6050 RVA: 0x0001693A File Offset: 0x00014B3A
		public override bool Read()
		{
			this._readType = Newtonsoft.Json.ReadType.Read;
			return this.ReadInternal();
		}

		// Token: 0x060017A3 RID: 6051 RVA: 0x00073B84 File Offset: 0x00071D84
		internal override bool ReadInternal()
		{
			bool flag2;
			try
			{
				bool flag;
				switch (this._bsonReaderState)
				{
				case BsonReader.BsonReaderState.Normal:
					flag = this.ReadNormal();
					break;
				case BsonReader.BsonReaderState.ReferenceStart:
				case BsonReader.BsonReaderState.ReferenceRef:
				case BsonReader.BsonReaderState.ReferenceId:
					flag = this.ReadReference();
					break;
				case BsonReader.BsonReaderState.CodeWScopeStart:
				case BsonReader.BsonReaderState.CodeWScopeCode:
				case BsonReader.BsonReaderState.CodeWScopeScope:
				case BsonReader.BsonReaderState.CodeWScopeScopeObject:
				case BsonReader.BsonReaderState.CodeWScopeScopeEnd:
					flag = this.ReadCodeWScope();
					break;
				default:
					throw JsonReaderException.Create(this, <Module>.smethod_25<string>(777100381U).FormatWith(BsonReader.smethod_13(), this._bsonReaderState));
				}
				if (!flag)
				{
					base.SetToken(JsonToken.None);
					flag2 = false;
				}
				else
				{
					flag2 = true;
				}
			}
			catch (EndOfStreamException)
			{
				for (;;)
				{
					IL_00B9:
					int num = -9756508;
					for (;;)
					{
						switch (num ^ -9756506)
						{
						case 0:
							goto IL_00B9;
						case 1:
							flag2 = false;
							num = -9756507;
							continue;
						case 2:
							base.SetToken(JsonToken.None);
							num = -9756505;
							continue;
						}
						goto Block_5;
					}
				}
				Block_5:;
			}
			return flag2;
		}

		// Token: 0x060017A4 RID: 6052 RVA: 0x00016949 File Offset: 0x00014B49
		public override void Close()
		{
			base.Close();
			if (base.CloseInput && this._reader != null)
			{
				BsonReader.smethod_14(this._reader);
			}
		}

		// Token: 0x060017A5 RID: 6053 RVA: 0x00073C64 File Offset: 0x00071E64
		private bool ReadCodeWScope()
		{
			switch (this._bsonReaderState)
			{
			case BsonReader.BsonReaderState.CodeWScopeStart:
				base.SetToken(JsonToken.PropertyName, <Module>.smethod_27<string>(2780582865U));
				this._bsonReaderState = BsonReader.BsonReaderState.CodeWScopeCode;
				return true;
			case BsonReader.BsonReaderState.CodeWScopeCode:
				this.ReadInt32();
				base.SetToken(JsonToken.String, this.ReadLengthString());
				this._bsonReaderState = BsonReader.BsonReaderState.CodeWScopeScope;
				return true;
			case BsonReader.BsonReaderState.CodeWScopeScope:
			{
				if (base.CurrentState == JsonReader.State.PostValue)
				{
					base.SetToken(JsonToken.PropertyName, <Module>.smethod_25<string>(2308244347U));
					return true;
				}
				base.SetToken(JsonToken.StartObject);
				this._bsonReaderState = BsonReader.BsonReaderState.CodeWScopeScopeObject;
				BsonReader.ContainerContext containerContext = new BsonReader.ContainerContext(BsonType.Object);
				this.PushContext(containerContext);
				containerContext.Length = this.ReadInt32();
				return true;
			}
			case BsonReader.BsonReaderState.CodeWScopeScopeObject:
			{
				bool flag;
				if ((flag = this.ReadNormal()) && this.TokenType == JsonToken.EndObject)
				{
					this._bsonReaderState = BsonReader.BsonReaderState.CodeWScopeScopeEnd;
				}
				return flag;
			}
			case BsonReader.BsonReaderState.CodeWScopeScopeEnd:
				base.SetToken(JsonToken.EndObject);
				this._bsonReaderState = BsonReader.BsonReaderState.Normal;
				return true;
			default:
				throw BsonReader.smethod_15();
			}
		}

		// Token: 0x060017A6 RID: 6054 RVA: 0x00073D48 File Offset: 0x00071F48
		private bool ReadReference()
		{
			JsonReader.State currentState = base.CurrentState;
			switch (currentState)
			{
			case JsonReader.State.Property:
				if (this._bsonReaderState == BsonReader.BsonReaderState.ReferenceRef)
				{
					base.SetToken(JsonToken.String, this.ReadLengthString());
					return true;
				}
				if (this._bsonReaderState == BsonReader.BsonReaderState.ReferenceId)
				{
					base.SetToken(JsonToken.Bytes, this.ReadBytes(12));
					return true;
				}
				throw JsonReaderException.Create(this, BsonReader.smethod_16(<Module>.smethod_26<string>(1904305331U), this._bsonReaderState));
			case JsonReader.State.ObjectStart:
				base.SetToken(JsonToken.PropertyName, <Module>.smethod_23<string>(2130147291U));
				this._bsonReaderState = BsonReader.BsonReaderState.ReferenceRef;
				return true;
			default:
				if (currentState != JsonReader.State.PostValue)
				{
					throw JsonReaderException.Create(this, BsonReader.smethod_16(<Module>.smethod_25<string>(1960257082U), base.CurrentState));
				}
				if (this._bsonReaderState == BsonReader.BsonReaderState.ReferenceRef)
				{
					base.SetToken(JsonToken.PropertyName, <Module>.smethod_25<string>(3282608689U));
					this._bsonReaderState = BsonReader.BsonReaderState.ReferenceId;
					return true;
				}
				if (this._bsonReaderState == BsonReader.BsonReaderState.ReferenceId)
				{
					base.SetToken(JsonToken.EndObject);
					this._bsonReaderState = BsonReader.BsonReaderState.Normal;
					return true;
				}
				throw JsonReaderException.Create(this, BsonReader.smethod_16(<Module>.smethod_27<string>(2407609321U), this._bsonReaderState));
			}
		}

		// Token: 0x060017A7 RID: 6055 RVA: 0x00073E60 File Offset: 0x00072060
		private bool ReadNormal()
		{
			switch (base.CurrentState)
			{
			case JsonReader.State.Start:
			{
				JsonToken jsonToken = ((!this._readRootValueAsArray) ? JsonToken.StartObject : JsonToken.StartArray);
				BsonType bsonType = ((!this._readRootValueAsArray) ? BsonType.Object : BsonType.Array);
				base.SetToken(jsonToken);
				BsonReader.ContainerContext containerContext = new BsonReader.ContainerContext(bsonType);
				this.PushContext(containerContext);
				containerContext.Length = this.ReadInt32();
				return true;
			}
			case JsonReader.State.Complete:
			case JsonReader.State.Closed:
				return false;
			case JsonReader.State.Property:
				this.ReadType(this._currentElementType);
				return true;
			case JsonReader.State.ObjectStart:
			case JsonReader.State.ArrayStart:
			case JsonReader.State.PostValue:
			{
				BsonReader.ContainerContext currentContext = this._currentContext;
				if (currentContext == null)
				{
					return false;
				}
				int num = currentContext.Length - 1;
				if (currentContext.Position < num)
				{
					if (currentContext.Type == BsonType.Array)
					{
						this.ReadElement();
						this.ReadType(this._currentElementType);
						return true;
					}
					base.SetToken(JsonToken.PropertyName, this.ReadElement());
					return true;
				}
				else
				{
					if (currentContext.Position != num)
					{
						throw JsonReaderException.Create(this, <Module>.smethod_23<string>(3271023678U));
					}
					if (this.ReadByte() == 0)
					{
						this.PopContext();
						if (this._currentContext != null)
						{
							this.MovePosition(currentContext.Length);
						}
						JsonToken jsonToken2 = ((currentContext.Type == BsonType.Object) ? JsonToken.EndObject : JsonToken.EndArray);
						base.SetToken(jsonToken2);
						return true;
					}
					throw JsonReaderException.Create(this, <Module>.smethod_25<string>(3143413783U));
				}
				break;
			}
			case JsonReader.State.ConstructorStart:
			case JsonReader.State.Constructor:
			case JsonReader.State.Error:
			case JsonReader.State.Finished:
				return false;
			}
			throw BsonReader.smethod_15();
		}

		// Token: 0x060017A8 RID: 6056 RVA: 0x00073FC4 File Offset: 0x000721C4
		private void PopContext()
		{
			this._stack.RemoveAt(this._stack.Count - 1);
			if (this._stack.Count == 0)
			{
				this._currentContext = null;
				return;
			}
			this._currentContext = this._stack[this._stack.Count - 1];
		}

		// Token: 0x060017A9 RID: 6057 RVA: 0x0001696C File Offset: 0x00014B6C
		private void PushContext(BsonReader.ContainerContext newContext)
		{
			this._stack.Add(newContext);
			this._currentContext = newContext;
		}

		// Token: 0x060017AA RID: 6058 RVA: 0x00016981 File Offset: 0x00014B81
		private byte ReadByte()
		{
			this.MovePosition(1);
			return BsonReader.smethod_17(this._reader);
		}

		// Token: 0x060017AB RID: 6059 RVA: 0x0007401C File Offset: 0x0007221C
		private void ReadType(BsonType type)
		{
			switch (type)
			{
			case BsonType.Number:
			{
				double num = this.ReadDouble();
				if (this._floatParseHandling == FloatParseHandling.Decimal)
				{
					base.SetToken(JsonToken.Float, BsonReader.smethod_18(num, BsonReader.smethod_13()));
					return;
				}
				base.SetToken(JsonToken.Float, num);
				return;
			}
			case BsonType.String:
			case BsonType.Symbol:
				base.SetToken(JsonToken.String, this.ReadLengthString());
				return;
			case BsonType.Object:
			{
				base.SetToken(JsonToken.StartObject);
				BsonReader.ContainerContext containerContext = new BsonReader.ContainerContext(BsonType.Object);
				this.PushContext(containerContext);
				containerContext.Length = this.ReadInt32();
				return;
			}
			case BsonType.Array:
			{
				base.SetToken(JsonToken.StartArray);
				BsonReader.ContainerContext containerContext2 = new BsonReader.ContainerContext(BsonType.Array);
				this.PushContext(containerContext2);
				containerContext2.Length = this.ReadInt32();
				return;
			}
			case BsonType.Binary:
			{
				BsonBinaryType bsonBinaryType;
				byte[] array = this.ReadBinary(out bsonBinaryType);
				object obj = ((bsonBinaryType != BsonBinaryType.Uuid) ? array : new Guid(array));
				base.SetToken(JsonToken.Bytes, obj);
				return;
			}
			case BsonType.Undefined:
				base.SetToken(JsonToken.Undefined);
				return;
			case BsonType.Oid:
			{
				byte[] array2 = this.ReadBytes(12);
				base.SetToken(JsonToken.Bytes, array2);
				return;
			}
			case BsonType.Boolean:
			{
				bool flag = Convert.ToBoolean(this.ReadByte());
				base.SetToken(JsonToken.Boolean, flag);
				return;
			}
			case BsonType.Date:
			{
				long num2 = this.ReadInt64();
				DateTime dateTime = DateTimeUtils.ConvertJavaScriptTicksToDateTime(num2);
				DateTime dateTime2;
				switch (this.DateTimeKindHandling)
				{
				case DateTimeKind.Unspecified:
					dateTime2 = DateTime.SpecifyKind(dateTime, DateTimeKind.Unspecified);
					goto IL_01A6;
				case DateTimeKind.Local:
					dateTime2 = dateTime.ToLocalTime();
					goto IL_01A6;
				}
				dateTime2 = dateTime;
				IL_01A6:
				base.SetToken(JsonToken.Date, dateTime2);
				return;
			}
			case BsonType.Null:
				base.SetToken(JsonToken.Null);
				return;
			case BsonType.Regex:
			{
				string text = this.ReadString();
				string text2 = this.ReadString();
				string text3 = <Module>.smethod_23<string>(1912091352U) + text + <Module>.smethod_26<string>(2625042512U) + text2;
				base.SetToken(JsonToken.String, text3);
				return;
			}
			case BsonType.Reference:
				base.SetToken(JsonToken.StartObject);
				this._bsonReaderState = BsonReader.BsonReaderState.ReferenceStart;
				return;
			case BsonType.Code:
				base.SetToken(JsonToken.String, this.ReadLengthString());
				return;
			case BsonType.CodeWScope:
				base.SetToken(JsonToken.StartObject);
				this._bsonReaderState = BsonReader.BsonReaderState.CodeWScopeStart;
				return;
			case BsonType.Integer:
				base.SetToken(JsonToken.Integer, (long)this.ReadInt32());
				return;
			case BsonType.TimeStamp:
			case BsonType.Long:
				base.SetToken(JsonToken.Integer, this.ReadInt64());
				return;
			default:
				throw new ArgumentOutOfRangeException(<Module>.smethod_26<string>(1001144091U), <Module>.smethod_25<string>(339440873U) + type);
			}
		}

		// Token: 0x060017AC RID: 6060 RVA: 0x00074284 File Offset: 0x00072484
		private byte[] ReadBinary(out BsonBinaryType binaryType)
		{
			int num = this.ReadInt32();
			binaryType = (BsonBinaryType)this.ReadByte();
			if (binaryType == BsonBinaryType.BinaryOld && !this._jsonNet35BinaryCompatibility)
			{
				num = this.ReadInt32();
			}
			return this.ReadBytes(num);
		}

		// Token: 0x060017AD RID: 6061 RVA: 0x000742BC File Offset: 0x000724BC
		private string ReadString()
		{
			this.EnsureBuffers();
			StringBuilder stringBuilder = null;
			int num = 0;
			int num2 = 0;
			int num4;
			for (;;)
			{
				int num3 = num2;
				byte b;
				while (num3 < 128 && (b = BsonReader.smethod_17(this._reader)) > 0)
				{
					this._byteBuffer[num3++] = b;
				}
				num4 = num3 - num2;
				num += num4;
				if (num3 < 128 && stringBuilder == null)
				{
					break;
				}
				int lastFullCharStop = this.GetLastFullCharStop(num3 - 1);
				int num5 = BsonReader.smethod_20(BsonReader.smethod_19(), this._byteBuffer, 0, lastFullCharStop + 1, this._charBuffer, 0);
				if (stringBuilder == null)
				{
					stringBuilder = BsonReader.smethod_22(256);
				}
				BsonReader.smethod_23(stringBuilder, this._charBuffer, 0, num5);
				if (lastFullCharStop < num4 - 1)
				{
					num2 = num4 - lastFullCharStop - 1;
					BsonReader.smethod_24(this._byteBuffer, lastFullCharStop + 1, this._byteBuffer, 0, num2);
				}
				else
				{
					if (num3 < 128)
					{
						goto IL_0105;
					}
					num2 = 0;
				}
			}
			int num6 = BsonReader.smethod_20(BsonReader.smethod_19(), this._byteBuffer, 0, num4, this._charBuffer, 0);
			this.MovePosition(num + 1);
			return BsonReader.smethod_21(this._charBuffer, 0, num6);
			IL_0105:
			this.MovePosition(num + 1);
			return BsonReader.smethod_25(stringBuilder);
		}

		// Token: 0x060017AE RID: 6062 RVA: 0x000743E0 File Offset: 0x000725E0
		private string ReadLengthString()
		{
			int num = this.ReadInt32();
			this.MovePosition(num);
			string @string = this.GetString(num - 1);
			BsonReader.smethod_17(this._reader);
			return @string;
		}

		// Token: 0x060017AF RID: 6063 RVA: 0x00074414 File Offset: 0x00072614
		private string GetString(int length)
		{
			if (length == 0)
			{
				goto IL_01D7;
			}
			this.EnsureBuffers();
			StringBuilder stringBuilder = null;
			int num = -266982627;
			int num6;
			for (;;)
			{
				IL_0182:
				int num3;
				int num4;
				int num5;
				switch (num ^ -266982626)
				{
				case 0:
					goto IL_0179;
				case 1:
				{
					int num2;
					BsonReader.smethod_23(stringBuilder, this._charBuffer, 0, num2);
					int lastFullCharStop;
					num = ((lastFullCharStop >= num3 - 1) ? (-266982638) : (-266982634));
					continue;
				}
				case 2:
					num = ((stringBuilder == null) ? (-266982637) : (-266982632));
					continue;
				case 3:
					num4 = 0;
					num5 = 0;
					num = -266982633;
					continue;
				case 4:
					num = -266982626;
					continue;
				case 5:
					num6 = BsonReader.smethod_20(BsonReader.smethod_19(), this._byteBuffer, 0, num3, this._charBuffer, 0);
					num = -266982639;
					continue;
				case 6:
				{
					int lastFullCharStop;
					int num2 = BsonReader.smethod_20(BsonReader.smethod_19(), this._byteBuffer, 0, lastFullCharStop + 1, this._charBuffer, 0);
					num = -266982625;
					continue;
				}
				case 7:
					goto IL_01E5;
				case 8:
				{
					int lastFullCharStop;
					num5 = num3 - lastFullCharStop - 1;
					BsonReader.smethod_24(this._byteBuffer, lastFullCharStop + 1, this._byteBuffer, 0, num5);
					num = -266982630;
					continue;
				}
				case 9:
					break;
				case 10:
				{
					if (num3 == length)
					{
						num = -266982629;
						continue;
					}
					int lastFullCharStop = this.GetLastFullCharStop(num3 - 1);
					num = -266982628;
					continue;
				}
				case 11:
					num3 += num5;
					num = -266982636;
					continue;
				case 12:
					num5 = 0;
					num = -266982626;
					continue;
				case 13:
					stringBuilder = BsonReader.smethod_22(length);
					num = -266982632;
					continue;
				case 14:
					num4 += num3;
					num = -266982635;
					continue;
				case 15:
					goto IL_01F5;
				case 16:
					goto IL_0204;
				case 17:
					goto IL_01D7;
				default:
					goto IL_0179;
				}
				IL_0079:
				int num7 = ((length - num4 > 128 - num5) ? (128 - num5) : (length - num4));
				num3 = BsonReader.smethod_26(this._reader, this._byteBuffer, num5, num7);
				num = ((num3 == 0) ? (-266982631) : (-266982640));
				continue;
				IL_0179:
				if (num4 >= length)
				{
					break;
				}
				goto IL_0079;
			}
			return BsonReader.smethod_25(stringBuilder);
			IL_01E5:
			throw BsonReader.smethod_27(<Module>.smethod_23<string>(2143820914U));
			IL_01F5:
			return BsonReader.smethod_21(this._charBuffer, 0, num6);
			IL_0204:
			return string.Empty;
			IL_01D7:
			num = -266982642;
			goto IL_0182;
		}

		// Token: 0x060017B0 RID: 6064 RVA: 0x0007462C File Offset: 0x0007282C
		private int GetLastFullCharStop(int start)
		{
			int i = start;
			int num = 0;
			while (i >= 0)
			{
				num = this.BytesInSequence(this._byteBuffer[i]);
				if (num == 0)
				{
					i--;
				}
				else
				{
					if (num != 1)
					{
						i--;
						break;
					}
					break;
				}
			}
			if (num == start - i)
			{
				return start;
			}
			return i;
		}

		// Token: 0x060017B1 RID: 6065 RVA: 0x0007466C File Offset: 0x0007286C
		private int BytesInSequence(byte b)
		{
			if (b <= BsonReader.SeqRange1[1])
			{
				return 1;
			}
			if (b >= BsonReader.SeqRange2[0] && b <= BsonReader.SeqRange2[1])
			{
				return 2;
			}
			if (b >= BsonReader.SeqRange3[0] && b <= BsonReader.SeqRange3[1])
			{
				return 3;
			}
			if (b >= BsonReader.SeqRange4[0] && b <= BsonReader.SeqRange4[1])
			{
				return 4;
			}
			return 0;
		}

		// Token: 0x060017B2 RID: 6066 RVA: 0x000746C8 File Offset: 0x000728C8
		private void EnsureBuffers()
		{
			if (this._byteBuffer == null)
			{
				this._byteBuffer = new byte[128];
			}
			if (this._charBuffer == null)
			{
				int num = BsonReader.smethod_28(BsonReader.smethod_19(), 128);
				this._charBuffer = new char[num];
			}
		}

		// Token: 0x060017B3 RID: 6067 RVA: 0x00016995 File Offset: 0x00014B95
		private double ReadDouble()
		{
			this.MovePosition(8);
			return BsonReader.smethod_29(this._reader);
		}

		// Token: 0x060017B4 RID: 6068 RVA: 0x000169A9 File Offset: 0x00014BA9
		private int ReadInt32()
		{
			this.MovePosition(4);
			return BsonReader.smethod_30(this._reader);
		}

		// Token: 0x060017B5 RID: 6069 RVA: 0x000169BD File Offset: 0x00014BBD
		private long ReadInt64()
		{
			this.MovePosition(8);
			return BsonReader.smethod_31(this._reader);
		}

		// Token: 0x060017B6 RID: 6070 RVA: 0x000169D1 File Offset: 0x00014BD1
		private BsonType ReadType()
		{
			this.MovePosition(1);
			return (BsonType)BsonReader.smethod_32(this._reader);
		}

		// Token: 0x060017B7 RID: 6071 RVA: 0x000169E5 File Offset: 0x00014BE5
		private void MovePosition(int count)
		{
			this._currentContext.Position += count;
		}

		// Token: 0x060017B8 RID: 6072 RVA: 0x000169FA File Offset: 0x00014BFA
		private byte[] ReadBytes(int count)
		{
			this.MovePosition(count);
			return BsonReader.smethod_33(this._reader, count);
		}

		// Token: 0x060017BA RID: 6074 RVA: 0x00016A0F File Offset: 0x00014C0F
		static BinaryReader smethod_12(Stream stream_0)
		{
			return new BinaryReader(stream_0);
		}

		// Token: 0x060017BB RID: 6075 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_13()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060017BC RID: 6076 RVA: 0x00016A17 File Offset: 0x00014C17
		static void smethod_14(BinaryReader binaryReader_0)
		{
			binaryReader_0.Close();
		}

		// Token: 0x060017BD RID: 6077 RVA: 0x00016A1F File Offset: 0x00014C1F
		static ArgumentOutOfRangeException smethod_15()
		{
			return new ArgumentOutOfRangeException();
		}

		// Token: 0x060017BE RID: 6078 RVA: 0x0000EE96 File Offset: 0x0000D096
		static string smethod_16(object object_0, object object_1)
		{
			return object_0 + object_1;
		}

		// Token: 0x060017BF RID: 6079 RVA: 0x00016A26 File Offset: 0x00014C26
		static byte smethod_17(BinaryReader binaryReader_0)
		{
			return binaryReader_0.ReadByte();
		}

		// Token: 0x060017C0 RID: 6080 RVA: 0x00016830 File Offset: 0x00014A30
		static decimal smethod_18(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToDecimal(object_0, iformatProvider_0);
		}

		// Token: 0x060017C1 RID: 6081 RVA: 0x0000DB1A File Offset: 0x0000BD1A
		static Encoding smethod_19()
		{
			return Encoding.UTF8;
		}

		// Token: 0x060017C2 RID: 6082 RVA: 0x00016A2E File Offset: 0x00014C2E
		static int smethod_20(Encoding encoding_0, byte[] byte_0, int int_0, int int_1, char[] char_0, int int_2)
		{
			return encoding_0.GetChars(byte_0, int_0, int_1, char_0, int_2);
		}

		// Token: 0x060017C3 RID: 6083 RVA: 0x00016A3D File Offset: 0x00014C3D
		static string smethod_21(char[] char_0, int int_0, int int_1)
		{
			return new string(char_0, int_0, int_1);
		}

		// Token: 0x060017C4 RID: 6084 RVA: 0x0000FD8A File Offset: 0x0000DF8A
		static StringBuilder smethod_22(int int_0)
		{
			return new StringBuilder(int_0);
		}

		// Token: 0x060017C5 RID: 6085 RVA: 0x00016A47 File Offset: 0x00014C47
		static StringBuilder smethod_23(StringBuilder stringBuilder_0, char[] char_0, int int_0, int int_1)
		{
			return stringBuilder_0.Append(char_0, int_0, int_1);
		}

		// Token: 0x060017C6 RID: 6086 RVA: 0x0000C3EE File Offset: 0x0000A5EE
		static void smethod_24(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Array.Copy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x060017C7 RID: 6087 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_25(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x060017C8 RID: 6088 RVA: 0x00016A52 File Offset: 0x00014C52
		static int smethod_26(BinaryReader binaryReader_0, byte[] byte_0, int int_0, int int_1)
		{
			return binaryReader_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x060017C9 RID: 6089 RVA: 0x00016A5D File Offset: 0x00014C5D
		static EndOfStreamException smethod_27(string string_0)
		{
			return new EndOfStreamException(string_0);
		}

		// Token: 0x060017CA RID: 6090 RVA: 0x00016A65 File Offset: 0x00014C65
		static int smethod_28(Encoding encoding_0, int int_0)
		{
			return encoding_0.GetMaxCharCount(int_0);
		}

		// Token: 0x060017CB RID: 6091 RVA: 0x00016A6E File Offset: 0x00014C6E
		static double smethod_29(BinaryReader binaryReader_0)
		{
			return binaryReader_0.ReadDouble();
		}

		// Token: 0x060017CC RID: 6092 RVA: 0x00016A76 File Offset: 0x00014C76
		static int smethod_30(BinaryReader binaryReader_0)
		{
			return binaryReader_0.ReadInt32();
		}

		// Token: 0x060017CD RID: 6093 RVA: 0x00016A7E File Offset: 0x00014C7E
		static long smethod_31(BinaryReader binaryReader_0)
		{
			return binaryReader_0.ReadInt64();
		}

		// Token: 0x060017CE RID: 6094 RVA: 0x00016A86 File Offset: 0x00014C86
		static sbyte smethod_32(BinaryReader binaryReader_0)
		{
			return binaryReader_0.ReadSByte();
		}

		// Token: 0x060017CF RID: 6095 RVA: 0x00016A8E File Offset: 0x00014C8E
		static byte[] smethod_33(BinaryReader binaryReader_0, int int_0)
		{
			return binaryReader_0.ReadBytes(int_0);
		}

		// Token: 0x04000944 RID: 2372
		private const int MaxCharBytesSize = 128;

		// Token: 0x04000945 RID: 2373
		private static readonly byte[] SeqRange1 = new byte[] { 0, 127 };

		// Token: 0x04000946 RID: 2374
		private static readonly byte[] SeqRange2 = new byte[] { 194, 223 };

		// Token: 0x04000947 RID: 2375
		private static readonly byte[] SeqRange3 = new byte[] { 224, 239 };

		// Token: 0x04000948 RID: 2376
		private static readonly byte[] SeqRange4 = new byte[] { 240, 244 };

		// Token: 0x04000949 RID: 2377
		private readonly BinaryReader _reader;

		// Token: 0x0400094A RID: 2378
		private readonly List<BsonReader.ContainerContext> _stack;

		// Token: 0x0400094B RID: 2379
		private byte[] _byteBuffer;

		// Token: 0x0400094C RID: 2380
		private char[] _charBuffer;

		// Token: 0x0400094D RID: 2381
		private BsonType _currentElementType;

		// Token: 0x0400094E RID: 2382
		private BsonReader.BsonReaderState _bsonReaderState;

		// Token: 0x0400094F RID: 2383
		private BsonReader.ContainerContext _currentContext;

		// Token: 0x04000950 RID: 2384
		private bool _readRootValueAsArray;

		// Token: 0x04000951 RID: 2385
		private bool _jsonNet35BinaryCompatibility;

		// Token: 0x04000952 RID: 2386
		private DateTimeKind _dateTimeKindHandling;

		// Token: 0x02000190 RID: 400
		private enum BsonReaderState
		{
			// Token: 0x04000954 RID: 2388
			Normal,
			// Token: 0x04000955 RID: 2389
			ReferenceStart,
			// Token: 0x04000956 RID: 2390
			ReferenceRef,
			// Token: 0x04000957 RID: 2391
			ReferenceId,
			// Token: 0x04000958 RID: 2392
			CodeWScopeStart,
			// Token: 0x04000959 RID: 2393
			CodeWScopeCode,
			// Token: 0x0400095A RID: 2394
			CodeWScopeScope,
			// Token: 0x0400095B RID: 2395
			CodeWScopeScopeObject,
			// Token: 0x0400095C RID: 2396
			CodeWScopeScopeEnd
		}

		// Token: 0x02000191 RID: 401
		private class ContainerContext
		{
			// Token: 0x060017D0 RID: 6096 RVA: 0x00016A97 File Offset: 0x00014C97
			public ContainerContext(BsonType type)
			{
				this.Type = type;
			}

			// Token: 0x0400095D RID: 2397
			public readonly BsonType Type;

			// Token: 0x0400095E RID: 2398
			public int Length;

			// Token: 0x0400095F RID: 2399
			public int Position;
		}
	}
}
