﻿using System;

namespace Newtonsoft.Json.Bson
{
	// Token: 0x02000198 RID: 408
	internal class BsonRegex : BsonToken
	{
		// Token: 0x17000380 RID: 896
		// (get) Token: 0x060017EC RID: 6124 RVA: 0x00016BB8 File Offset: 0x00014DB8
		// (set) Token: 0x060017ED RID: 6125 RVA: 0x00016BC0 File Offset: 0x00014DC0
		public BsonString Pattern { get; set; }

		// Token: 0x17000381 RID: 897
		// (get) Token: 0x060017EE RID: 6126 RVA: 0x00016BC9 File Offset: 0x00014DC9
		// (set) Token: 0x060017EF RID: 6127 RVA: 0x00016BD1 File Offset: 0x00014DD1
		public BsonString Options { get; set; }

		// Token: 0x060017F0 RID: 6128 RVA: 0x00016BDA File Offset: 0x00014DDA
		public BsonRegex(string pattern, string options)
		{
			this.Pattern = new BsonString(pattern, false);
			this.Options = new BsonString(options, false);
		}

		// Token: 0x17000382 RID: 898
		// (get) Token: 0x060017F1 RID: 6129 RVA: 0x00016BFC File Offset: 0x00014DFC
		public override BsonType Type
		{
			get
			{
				return BsonType.Regex;
			}
		}
	}
}
