﻿using System;

namespace Newtonsoft.Json.Bson
{
	// Token: 0x02000197 RID: 407
	internal class BsonBinary : BsonValue
	{
		// Token: 0x1700037F RID: 895
		// (get) Token: 0x060017E9 RID: 6121 RVA: 0x00016B96 File Offset: 0x00014D96
		// (set) Token: 0x060017EA RID: 6122 RVA: 0x00016B9E File Offset: 0x00014D9E
		public BsonBinaryType BinaryType { get; set; }

		// Token: 0x060017EB RID: 6123 RVA: 0x00016BA7 File Offset: 0x00014DA7
		public BsonBinary(byte[] value, BsonBinaryType binaryType)
			: base(value, BsonType.Binary)
		{
			this.BinaryType = binaryType;
		}
	}
}
