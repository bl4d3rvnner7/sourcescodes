﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Newtonsoft.Json.Bson
{
	// Token: 0x02000194 RID: 404
	internal class BsonArray : BsonToken, IEnumerable<BsonToken>, IEnumerable
	{
		// Token: 0x060017DC RID: 6108 RVA: 0x00016AF8 File Offset: 0x00014CF8
		public void Add(BsonToken token)
		{
			this._children.Add(token);
			token.Parent = this;
		}

		// Token: 0x1700037A RID: 890
		// (get) Token: 0x060017DD RID: 6109 RVA: 0x00016B0D File Offset: 0x00014D0D
		public override BsonType Type
		{
			get
			{
				return BsonType.Array;
			}
		}

		// Token: 0x060017DE RID: 6110 RVA: 0x00016B10 File Offset: 0x00014D10
		public IEnumerator<BsonToken> GetEnumerator()
		{
			return this._children.GetEnumerator();
		}

		// Token: 0x060017DF RID: 6111 RVA: 0x00016B22 File Offset: 0x00014D22
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		// Token: 0x04000963 RID: 2403
		private readonly List<BsonToken> _children = new List<BsonToken>();
	}
}
