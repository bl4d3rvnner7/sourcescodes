﻿using System;

namespace Newtonsoft.Json.Bson
{
	// Token: 0x0200018B RID: 395
	internal enum BsonBinaryType : byte
	{
		// Token: 0x0400091B RID: 2331
		Binary,
		// Token: 0x0400091C RID: 2332
		Function,
		// Token: 0x0400091D RID: 2333
		[Obsolete("This type has been deprecated in the BSON specification. Use Binary instead.")]
		BinaryOld,
		// Token: 0x0400091E RID: 2334
		[Obsolete("This type has been deprecated in the BSON specification. Use Uuid instead.")]
		UuidOld,
		// Token: 0x0400091F RID: 2335
		Uuid,
		// Token: 0x04000920 RID: 2336
		Md5,
		// Token: 0x04000921 RID: 2337
		UserDefined = 128
	}
}
