﻿using System;
using System.Globalization;
using System.IO;
using System.Numerics;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Bson
{
	// Token: 0x0200019D RID: 413
	public class BsonWriter : JsonWriter
	{
		// Token: 0x17000391 RID: 913
		// (get) Token: 0x06001877 RID: 6263 RVA: 0x00017137 File Offset: 0x00015337
		// (set) Token: 0x06001878 RID: 6264 RVA: 0x00017144 File Offset: 0x00015344
		public DateTimeKind DateTimeKindHandling
		{
			get
			{
				return this._writer.DateTimeKindHandling;
			}
			set
			{
				this._writer.DateTimeKindHandling = value;
			}
		}

		// Token: 0x06001879 RID: 6265 RVA: 0x00017152 File Offset: 0x00015352
		public BsonWriter(Stream stream)
		{
			ValidationUtils.ArgumentNotNull(stream, <Module>.smethod_26<string>(368920435U));
			this._writer = new BsonBinaryWriter(BsonWriter.smethod_16(stream));
		}

		// Token: 0x0600187A RID: 6266 RVA: 0x0001717B File Offset: 0x0001537B
		public BsonWriter(BinaryWriter writer)
		{
			ValidationUtils.ArgumentNotNull(writer, <Module>.smethod_26<string>(4111618735U));
			this._writer = new BsonBinaryWriter(writer);
		}

		// Token: 0x0600187B RID: 6267 RVA: 0x0001719F File Offset: 0x0001539F
		public override void Flush()
		{
			this._writer.Flush();
		}

		// Token: 0x0600187C RID: 6268 RVA: 0x000171AC File Offset: 0x000153AC
		protected override void WriteEnd(JsonToken token)
		{
			base.WriteEnd(token);
			this.RemoveParent();
			if (base.Top == 0)
			{
				this._writer.WriteToken(this._root);
			}
		}

		// Token: 0x0600187D RID: 6269 RVA: 0x000171D4 File Offset: 0x000153D4
		public override void WriteComment(string text)
		{
			throw JsonWriterException.Create(this, <Module>.smethod_25<string>(3215741199U), null);
		}

		// Token: 0x0600187E RID: 6270 RVA: 0x000171E7 File Offset: 0x000153E7
		public override void WriteStartConstructor(string name)
		{
			throw JsonWriterException.Create(this, <Module>.smethod_27<string>(2746402998U), null);
		}

		// Token: 0x0600187F RID: 6271 RVA: 0x000171FA File Offset: 0x000153FA
		public override void WriteRaw(string json)
		{
			throw JsonWriterException.Create(this, <Module>.smethod_27<string>(1767347445U), null);
		}

		// Token: 0x06001880 RID: 6272 RVA: 0x0001720D File Offset: 0x0001540D
		public override void WriteRawValue(string json)
		{
			throw JsonWriterException.Create(this, <Module>.smethod_26<string>(4149924311U), null);
		}

		// Token: 0x06001881 RID: 6273 RVA: 0x00017220 File Offset: 0x00015420
		public override void WriteStartArray()
		{
			base.WriteStartArray();
			this.AddParent(new BsonArray());
		}

		// Token: 0x06001882 RID: 6274 RVA: 0x00017233 File Offset: 0x00015433
		public override void WriteStartObject()
		{
			base.WriteStartObject();
			this.AddParent(new BsonObject());
		}

		// Token: 0x06001883 RID: 6275 RVA: 0x00017246 File Offset: 0x00015446
		public override void WritePropertyName(string name)
		{
			base.WritePropertyName(name);
			this._propertyName = name;
		}

		// Token: 0x06001884 RID: 6276 RVA: 0x00017256 File Offset: 0x00015456
		public override void Close()
		{
			base.Close();
			if (base.CloseOutput && this._writer != null)
			{
				this._writer.Close();
			}
		}

		// Token: 0x06001885 RID: 6277 RVA: 0x00017279 File Offset: 0x00015479
		private void AddParent(BsonToken container)
		{
			this.AddToken(container);
			this._parent = container;
		}

		// Token: 0x06001886 RID: 6278 RVA: 0x00017289 File Offset: 0x00015489
		private void RemoveParent()
		{
			this._parent = this._parent.Parent;
		}

		// Token: 0x06001887 RID: 6279 RVA: 0x0001729C File Offset: 0x0001549C
		private void AddValue(object value, BsonType type)
		{
			this.AddToken(new BsonValue(value, type));
		}

		// Token: 0x06001888 RID: 6280 RVA: 0x00075C18 File Offset: 0x00073E18
		internal void AddToken(BsonToken token)
		{
			if (this._parent == null)
			{
				if (token.Type != BsonType.Object)
				{
					if (token.Type != BsonType.Array)
					{
						throw JsonWriterException.Create(this, <Module>.smethod_24<string>(695522187U).FormatWith(BsonWriter.smethod_17(), token.Type), null);
					}
				}
				this._parent = token;
				this._root = token;
				return;
			}
			if (this._parent is BsonObject)
			{
				((BsonObject)this._parent).Add(this._propertyName, token);
				this._propertyName = null;
				return;
			}
			((BsonArray)this._parent).Add(token);
		}

		// Token: 0x06001889 RID: 6281 RVA: 0x00075CB4 File Offset: 0x00073EB4
		public override void WriteValue(object value)
		{
			if (value is BigInteger)
			{
				base.InternalWriteValue(JsonToken.Integer);
				this.AddToken(new BsonBinary(((BigInteger)value).ToByteArray(), BsonBinaryType.Binary));
				return;
			}
			base.WriteValue(value);
		}

		// Token: 0x0600188A RID: 6282 RVA: 0x000172AB File Offset: 0x000154AB
		public override void WriteNull()
		{
			base.WriteNull();
			this.AddValue(null, BsonType.Null);
		}

		// Token: 0x0600188B RID: 6283 RVA: 0x000172BC File Offset: 0x000154BC
		public override void WriteUndefined()
		{
			base.WriteUndefined();
			this.AddValue(null, BsonType.Undefined);
		}

		// Token: 0x0600188C RID: 6284 RVA: 0x000172CC File Offset: 0x000154CC
		public override void WriteValue(string value)
		{
			base.WriteValue(value);
			if (value != null)
			{
				this.AddToken(new BsonString(value, true));
				return;
			}
			this.AddValue(null, BsonType.Null);
		}

		// Token: 0x0600188D RID: 6285 RVA: 0x000172EF File Offset: 0x000154EF
		public override void WriteValue(int value)
		{
			base.WriteValue(value);
			this.AddValue(value, BsonType.Integer);
		}

		// Token: 0x0600188E RID: 6286 RVA: 0x00017306 File Offset: 0x00015506
		[CLSCompliant(false)]
		public override void WriteValue(uint value)
		{
			if (value > 2147483647U)
			{
				throw JsonWriterException.Create(this, <Module>.smethod_26<string>(3483574464U), null);
			}
			base.WriteValue(value);
			this.AddValue(value, BsonType.Integer);
		}

		// Token: 0x0600188F RID: 6287 RVA: 0x00017337 File Offset: 0x00015537
		public override void WriteValue(long value)
		{
			base.WriteValue(value);
			this.AddValue(value, BsonType.Long);
		}

		// Token: 0x06001890 RID: 6288 RVA: 0x0001734E File Offset: 0x0001554E
		[CLSCompliant(false)]
		public override void WriteValue(ulong value)
		{
			if (value > 9223372036854775807UL)
			{
				throw JsonWriterException.Create(this, <Module>.smethod_23<string>(1358561872U), null);
			}
			base.WriteValue(value);
			this.AddValue(value, BsonType.Long);
		}

		// Token: 0x06001891 RID: 6289 RVA: 0x00017383 File Offset: 0x00015583
		public override void WriteValue(float value)
		{
			base.WriteValue(value);
			this.AddValue(value, BsonType.Number);
		}

		// Token: 0x06001892 RID: 6290 RVA: 0x00017399 File Offset: 0x00015599
		public override void WriteValue(double value)
		{
			base.WriteValue(value);
			this.AddValue(value, BsonType.Number);
		}

		// Token: 0x06001893 RID: 6291 RVA: 0x000173AF File Offset: 0x000155AF
		public override void WriteValue(bool value)
		{
			base.WriteValue(value);
			this.AddValue(value, BsonType.Boolean);
		}

		// Token: 0x06001894 RID: 6292 RVA: 0x000173C5 File Offset: 0x000155C5
		public override void WriteValue(short value)
		{
			base.WriteValue(value);
			this.AddValue(value, BsonType.Integer);
		}

		// Token: 0x06001895 RID: 6293 RVA: 0x000173DC File Offset: 0x000155DC
		[CLSCompliant(false)]
		public override void WriteValue(ushort value)
		{
			base.WriteValue(value);
			this.AddValue(value, BsonType.Integer);
		}

		// Token: 0x06001896 RID: 6294 RVA: 0x00075CF4 File Offset: 0x00073EF4
		public override void WriteValue(char value)
		{
			base.WriteValue(value);
			string text = value.ToString(BsonWriter.smethod_17());
			this.AddToken(new BsonString(text, true));
		}

		// Token: 0x06001897 RID: 6295 RVA: 0x000173F3 File Offset: 0x000155F3
		public override void WriteValue(byte value)
		{
			base.WriteValue(value);
			this.AddValue(value, BsonType.Integer);
		}

		// Token: 0x06001898 RID: 6296 RVA: 0x0001740A File Offset: 0x0001560A
		[CLSCompliant(false)]
		public override void WriteValue(sbyte value)
		{
			base.WriteValue(value);
			this.AddValue(value, BsonType.Integer);
		}

		// Token: 0x06001899 RID: 6297 RVA: 0x00017421 File Offset: 0x00015621
		public override void WriteValue(decimal value)
		{
			base.WriteValue(value);
			this.AddValue(value, BsonType.Number);
		}

		// Token: 0x0600189A RID: 6298 RVA: 0x00017437 File Offset: 0x00015637
		public override void WriteValue(DateTime value)
		{
			base.WriteValue(value);
			value = DateTimeUtils.EnsureDateTime(value, base.DateTimeZoneHandling);
			this.AddValue(value, BsonType.Date);
		}

		// Token: 0x0600189B RID: 6299 RVA: 0x0001745C File Offset: 0x0001565C
		public override void WriteValue(DateTimeOffset value)
		{
			base.WriteValue(value);
			this.AddValue(value, BsonType.Date);
		}

		// Token: 0x0600189C RID: 6300 RVA: 0x00017473 File Offset: 0x00015673
		public override void WriteValue(byte[] value)
		{
			base.WriteValue(value);
			this.AddToken(new BsonBinary(value, BsonBinaryType.Binary));
		}

		// Token: 0x0600189D RID: 6301 RVA: 0x00017489 File Offset: 0x00015689
		public override void WriteValue(Guid value)
		{
			base.WriteValue(value);
			this.AddToken(new BsonBinary(value.ToByteArray(), BsonBinaryType.Uuid));
		}

		// Token: 0x0600189E RID: 6302 RVA: 0x000174A5 File Offset: 0x000156A5
		public override void WriteValue(TimeSpan value)
		{
			base.WriteValue(value);
			this.AddToken(new BsonString(value.ToString(), true));
		}

		// Token: 0x0600189F RID: 6303 RVA: 0x000174C7 File Offset: 0x000156C7
		public override void WriteValue(Uri value)
		{
			base.WriteValue(value);
			this.AddToken(new BsonString(BsonWriter.smethod_18(value), true));
		}

		// Token: 0x060018A0 RID: 6304 RVA: 0x00075D24 File Offset: 0x00073F24
		public void WriteObjectId(byte[] value)
		{
			ValidationUtils.ArgumentNotNull(value, <Module>.smethod_27<string>(2371252898U));
			if (value.Length != 12)
			{
				throw JsonWriterException.Create(this, <Module>.smethod_24<string>(2889496925U), null);
			}
			base.UpdateScopeWithFinishedValue();
			base.AutoComplete(JsonToken.Undefined);
			this.AddValue(value, BsonType.Oid);
		}

		// Token: 0x060018A1 RID: 6305 RVA: 0x000174E2 File Offset: 0x000156E2
		public void WriteRegex(string pattern, string options)
		{
			ValidationUtils.ArgumentNotNull(pattern, <Module>.smethod_26<string>(3056634467U));
			base.UpdateScopeWithFinishedValue();
			base.AutoComplete(JsonToken.Undefined);
			this.AddToken(new BsonRegex(pattern, options));
		}

		// Token: 0x060018A2 RID: 6306 RVA: 0x0001750F File Offset: 0x0001570F
		static BinaryWriter smethod_16(Stream stream_0)
		{
			return new BinaryWriter(stream_0);
		}

		// Token: 0x060018A3 RID: 6307 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_17()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060018A4 RID: 6308 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_18(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x0400099A RID: 2458
		private readonly BsonBinaryWriter _writer;

		// Token: 0x0400099B RID: 2459
		private BsonToken _root;

		// Token: 0x0400099C RID: 2460
		private BsonToken _parent;

		// Token: 0x0400099D RID: 2461
		private string _propertyName;
	}
}
