﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text.RegularExpressions;
using System.Threading;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Schema;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json
{
	// Token: 0x02000207 RID: 519
	[Obsolete("JSON Schema validation has been moved to its own package. See http://www.newtonsoft.com/jsonschema for more details.")]
	public class JsonValidatingReader : JsonReader, IJsonLineInfo
	{
		// Token: 0x14000026 RID: 38
		// (add) Token: 0x06001D5A RID: 7514 RVA: 0x0007FC2C File Offset: 0x0007DE2C
		// (remove) Token: 0x06001D5B RID: 7515 RVA: 0x0007FC64 File Offset: 0x0007DE64
		public event ValidationEventHandler ValidationEventHandler
		{
			add
			{
				ValidationEventHandler validationEventHandler = this.ValidationEventHandler;
				ValidationEventHandler validationEventHandler2;
				do
				{
					validationEventHandler2 = validationEventHandler;
					ValidationEventHandler validationEventHandler3 = (ValidationEventHandler)JsonValidatingReader.smethod_12(validationEventHandler2, value);
					validationEventHandler = Interlocked.CompareExchange<ValidationEventHandler>(ref this.ValidationEventHandler, validationEventHandler3, validationEventHandler2);
				}
				while (validationEventHandler != validationEventHandler2);
			}
			remove
			{
				ValidationEventHandler validationEventHandler = this.ValidationEventHandler;
				for (;;)
				{
					IL_004C:
					int num = -1066663898;
					for (;;)
					{
						switch (num ^ -1066663900)
						{
						case 0:
							goto IL_004C;
						case 1:
							goto IL_0012;
						case 2:
							break;
						default:
							goto IL_0012;
						}
						IL_0009:
						ValidationEventHandler validationEventHandler2 = validationEventHandler;
						num = -1066663899;
						continue;
						IL_0012:
						ValidationEventHandler validationEventHandler3 = (ValidationEventHandler)JsonValidatingReader.smethod_13(validationEventHandler2, value);
						validationEventHandler = Interlocked.CompareExchange<ValidationEventHandler>(ref this.ValidationEventHandler, validationEventHandler3, validationEventHandler2);
						if (validationEventHandler == validationEventHandler2)
						{
							return;
						}
						goto IL_0009;
					}
				}
			}
		}

		// Token: 0x17000432 RID: 1074
		// (get) Token: 0x06001D5C RID: 7516 RVA: 0x00019794 File Offset: 0x00017994
		public override object Value
		{
			get
			{
				return this._reader.Value;
			}
		}

		// Token: 0x17000433 RID: 1075
		// (get) Token: 0x06001D5D RID: 7517 RVA: 0x000197A1 File Offset: 0x000179A1
		public override int Depth
		{
			get
			{
				return this._reader.Depth;
			}
		}

		// Token: 0x17000434 RID: 1076
		// (get) Token: 0x06001D5E RID: 7518 RVA: 0x000197AE File Offset: 0x000179AE
		public override string Path
		{
			get
			{
				return this._reader.Path;
			}
		}

		// Token: 0x17000435 RID: 1077
		// (get) Token: 0x06001D5F RID: 7519 RVA: 0x000197BB File Offset: 0x000179BB
		// (set) Token: 0x06001D60 RID: 7520 RVA: 0x0000C600 File Offset: 0x0000A800
		public override char QuoteChar
		{
			get
			{
				return this._reader.QuoteChar;
			}
			protected internal set
			{
			}
		}

		// Token: 0x17000436 RID: 1078
		// (get) Token: 0x06001D61 RID: 7521 RVA: 0x000197C8 File Offset: 0x000179C8
		public override JsonToken TokenType
		{
			get
			{
				return this._reader.TokenType;
			}
		}

		// Token: 0x17000437 RID: 1079
		// (get) Token: 0x06001D62 RID: 7522 RVA: 0x000197D5 File Offset: 0x000179D5
		public override Type ValueType
		{
			get
			{
				return this._reader.ValueType;
			}
		}

		// Token: 0x06001D63 RID: 7523 RVA: 0x000197E2 File Offset: 0x000179E2
		private void Push(JsonValidatingReader.SchemaScope scope)
		{
			this._stack.Push(scope);
			this._currentScope = scope;
		}

		// Token: 0x06001D64 RID: 7524 RVA: 0x0007FCC4 File Offset: 0x0007DEC4
		private JsonValidatingReader.SchemaScope Pop()
		{
			JsonValidatingReader.SchemaScope schemaScope = this._stack.Pop();
			this._currentScope = ((this._stack.Count != 0) ? this._stack.Peek() : null);
			return schemaScope;
		}

		// Token: 0x17000438 RID: 1080
		// (get) Token: 0x06001D65 RID: 7525 RVA: 0x000197F7 File Offset: 0x000179F7
		private IList<JsonSchemaModel> CurrentSchemas
		{
			get
			{
				return this._currentScope.Schemas;
			}
		}

		// Token: 0x17000439 RID: 1081
		// (get) Token: 0x06001D66 RID: 7526 RVA: 0x0007FD00 File Offset: 0x0007DF00
		private IList<JsonSchemaModel> CurrentMemberSchemas
		{
			get
			{
				if (this._currentScope == null)
				{
					return new List<JsonSchemaModel>(new JsonSchemaModel[] { this._model });
				}
				if (this._currentScope.Schemas == null || this._currentScope.Schemas.Count == 0)
				{
					return JsonValidatingReader.EmptySchemaList;
				}
				switch (this._currentScope.TokenType)
				{
				case JTokenType.None:
					return this._currentScope.Schemas;
				case JTokenType.Object:
					if (this._currentScope.CurrentPropertyName != null)
					{
						IList<JsonSchemaModel> list = new List<JsonSchemaModel>();
						IEnumerator<JsonSchemaModel> enumerator = this.CurrentSchemas.GetEnumerator();
						try
						{
							while (JsonValidatingReader.smethod_15(enumerator))
							{
								JsonSchemaModel jsonSchemaModel = enumerator.Current;
								JsonSchemaModel jsonSchemaModel2;
								if (jsonSchemaModel.Properties != null && jsonSchemaModel.Properties.TryGetValue(this._currentScope.CurrentPropertyName, out jsonSchemaModel2))
								{
									list.Add(jsonSchemaModel2);
								}
								if (jsonSchemaModel.PatternProperties != null)
								{
									IEnumerator<KeyValuePair<string, JsonSchemaModel>> enumerator2 = jsonSchemaModel.PatternProperties.GetEnumerator();
									try
									{
										while (JsonValidatingReader.smethod_15(enumerator2))
										{
											KeyValuePair<string, JsonSchemaModel> keyValuePair = enumerator2.Current;
											if (JsonValidatingReader.smethod_14(this._currentScope.CurrentPropertyName, keyValuePair.Key))
											{
												list.Add(keyValuePair.Value);
											}
										}
									}
									finally
									{
										if (enumerator2 != null)
										{
											JsonValidatingReader.smethod_16(enumerator2);
										}
									}
								}
								if (list.Count == 0 && jsonSchemaModel.AllowAdditionalProperties && jsonSchemaModel.AdditionalProperties != null)
								{
									list.Add(jsonSchemaModel.AdditionalProperties);
								}
							}
						}
						finally
						{
							if (enumerator != null)
							{
								JsonValidatingReader.smethod_16(enumerator);
							}
						}
						return list;
					}
					throw new JsonReaderException(<Module>.smethod_24<string>(73099453U));
				case JTokenType.Array:
				{
					IList<JsonSchemaModel> list2 = new List<JsonSchemaModel>();
					IEnumerator<JsonSchemaModel> enumerator3 = this.CurrentSchemas.GetEnumerator();
					try
					{
						while (JsonValidatingReader.smethod_15(enumerator3))
						{
							JsonSchemaModel jsonSchemaModel3 = enumerator3.Current;
							if (!jsonSchemaModel3.PositionalItemsValidation)
							{
								if (jsonSchemaModel3.Items != null && jsonSchemaModel3.Items.Count > 0)
								{
									list2.Add(jsonSchemaModel3.Items[0]);
								}
							}
							else
							{
								if (jsonSchemaModel3.Items != null && jsonSchemaModel3.Items.Count > 0 && jsonSchemaModel3.Items.Count > this._currentScope.ArrayItemCount - 1)
								{
									list2.Add(jsonSchemaModel3.Items[this._currentScope.ArrayItemCount - 1]);
								}
								if (jsonSchemaModel3.AllowAdditionalItems && jsonSchemaModel3.AdditionalItems != null)
								{
									list2.Add(jsonSchemaModel3.AdditionalItems);
								}
							}
						}
					}
					finally
					{
						if (enumerator3 != null)
						{
							JsonValidatingReader.smethod_16(enumerator3);
						}
					}
					return list2;
				}
				case JTokenType.Constructor:
					return JsonValidatingReader.EmptySchemaList;
				default:
					throw JsonValidatingReader.smethod_18(<Module>.smethod_27<string>(1096430377U), <Module>.smethod_24<string>(3608965688U).FormatWith(JsonValidatingReader.smethod_17(), this._currentScope.TokenType));
				}
			}
		}

		// Token: 0x06001D67 RID: 7527 RVA: 0x0007FFE8 File Offset: 0x0007E1E8
		private void RaiseError(string message, JsonSchemaModel schema)
		{
			string text = ((!((IJsonLineInfo)this).HasLineInfo()) ? message : JsonValidatingReader.smethod_19(message, <Module>.smethod_26<string>(3845060631U).FormatWith(JsonValidatingReader.smethod_17(), ((IJsonLineInfo)this).LineNumber, ((IJsonLineInfo)this).LinePosition)));
			this.OnValidationEvent(new JsonSchemaException(text, null, this.Path, ((IJsonLineInfo)this).LineNumber, ((IJsonLineInfo)this).LinePosition));
		}

		// Token: 0x06001D68 RID: 7528 RVA: 0x00080054 File Offset: 0x0007E254
		private void OnValidationEvent(JsonSchemaException exception)
		{
			ValidationEventHandler validationEventHandler = this.ValidationEventHandler;
			if (validationEventHandler == null)
			{
				throw exception;
			}
			validationEventHandler(this, new ValidationEventArgs(exception));
		}

		// Token: 0x06001D69 RID: 7529 RVA: 0x00019804 File Offset: 0x00017A04
		public JsonValidatingReader(JsonReader reader)
		{
			ValidationUtils.ArgumentNotNull(reader, <Module>.smethod_27<string>(3246799795U));
			this._reader = reader;
			this._stack = new Stack<JsonValidatingReader.SchemaScope>();
		}

		// Token: 0x1700043A RID: 1082
		// (get) Token: 0x06001D6A RID: 7530 RVA: 0x0001982E File Offset: 0x00017A2E
		// (set) Token: 0x06001D6B RID: 7531 RVA: 0x00019836 File Offset: 0x00017A36
		public JsonSchema Schema
		{
			get
			{
				return this._schema;
			}
			set
			{
				if (this.TokenType != JsonToken.None)
				{
					throw JsonValidatingReader.smethod_20(<Module>.smethod_27<string>(4064252228U));
				}
				this._schema = value;
				this._model = null;
			}
		}

		// Token: 0x1700043B RID: 1083
		// (get) Token: 0x06001D6C RID: 7532 RVA: 0x0001985E File Offset: 0x00017A5E
		public JsonReader Reader
		{
			get
			{
				return this._reader;
			}
		}

		// Token: 0x06001D6D RID: 7533 RVA: 0x0008007C File Offset: 0x0007E27C
		private void ValidateNotDisallowed(JsonSchemaModel schema)
		{
			if (schema == null)
			{
				return;
			}
			JsonSchemaType? currentNodeSchemaType = this.GetCurrentNodeSchemaType();
			if (currentNodeSchemaType != null && JsonSchemaGenerator.HasFlag(new JsonSchemaType?(schema.Disallow), currentNodeSchemaType.Value))
			{
				this.RaiseError(<Module>.smethod_23<string>(4020092912U).FormatWith(JsonValidatingReader.smethod_17(), currentNodeSchemaType), schema);
			}
		}

		// Token: 0x06001D6E RID: 7534 RVA: 0x000800D8 File Offset: 0x0007E2D8
		private JsonSchemaType? GetCurrentNodeSchemaType()
		{
			switch (this._reader.TokenType)
			{
			case JsonToken.StartObject:
				return new JsonSchemaType?(JsonSchemaType.Object);
			case JsonToken.StartArray:
				return new JsonSchemaType?(JsonSchemaType.Array);
			case JsonToken.Integer:
				return new JsonSchemaType?(JsonSchemaType.Integer);
			case JsonToken.Float:
				return new JsonSchemaType?(JsonSchemaType.Float);
			case JsonToken.String:
				return new JsonSchemaType?(JsonSchemaType.String);
			case JsonToken.Boolean:
				return new JsonSchemaType?(JsonSchemaType.Boolean);
			case JsonToken.Null:
				return new JsonSchemaType?(JsonSchemaType.Null);
			}
			return null;
		}

		// Token: 0x06001D6F RID: 7535 RVA: 0x00080164 File Offset: 0x0007E364
		public override int? ReadAsInt32()
		{
			int? num = this._reader.ReadAsInt32();
			this.ValidateCurrentToken();
			return num;
		}

		// Token: 0x06001D70 RID: 7536 RVA: 0x00080184 File Offset: 0x0007E384
		public override byte[] ReadAsBytes()
		{
			byte[] array = this._reader.ReadAsBytes();
			this.ValidateCurrentToken();
			return array;
		}

		// Token: 0x06001D71 RID: 7537 RVA: 0x000801A4 File Offset: 0x0007E3A4
		public override decimal? ReadAsDecimal()
		{
			decimal? num = this._reader.ReadAsDecimal();
			this.ValidateCurrentToken();
			return num;
		}

		// Token: 0x06001D72 RID: 7538 RVA: 0x000801C4 File Offset: 0x0007E3C4
		public override string ReadAsString()
		{
			string text = this._reader.ReadAsString();
			this.ValidateCurrentToken();
			return text;
		}

		// Token: 0x06001D73 RID: 7539 RVA: 0x000801E4 File Offset: 0x0007E3E4
		public override DateTime? ReadAsDateTime()
		{
			DateTime? dateTime = this._reader.ReadAsDateTime();
			this.ValidateCurrentToken();
			return dateTime;
		}

		// Token: 0x06001D74 RID: 7540 RVA: 0x00080204 File Offset: 0x0007E404
		public override DateTimeOffset? ReadAsDateTimeOffset()
		{
			DateTimeOffset? dateTimeOffset = this._reader.ReadAsDateTimeOffset();
			this.ValidateCurrentToken();
			return dateTimeOffset;
		}

		// Token: 0x06001D75 RID: 7541 RVA: 0x00019866 File Offset: 0x00017A66
		public override bool Read()
		{
			if (!this._reader.Read())
			{
				return false;
			}
			if (this._reader.TokenType == JsonToken.Comment)
			{
				return true;
			}
			this.ValidateCurrentToken();
			return true;
		}

		// Token: 0x06001D76 RID: 7542 RVA: 0x00080224 File Offset: 0x0007E424
		private void ValidateCurrentToken()
		{
			if (this._model == null)
			{
				JsonSchemaModelBuilder jsonSchemaModelBuilder = new JsonSchemaModelBuilder();
				this._model = jsonSchemaModelBuilder.Build(this._schema);
				if (!JsonTokenUtils.IsStartToken(this._reader.TokenType))
				{
					this.Push(new JsonValidatingReader.SchemaScope(JTokenType.None, this.CurrentMemberSchemas));
				}
			}
			switch (this._reader.TokenType)
			{
			case JsonToken.None:
				return;
			case JsonToken.StartObject:
			{
				this.ProcessValue();
				IList<JsonSchemaModel> list = this.CurrentMemberSchemas.Where(new Func<JsonSchemaModel, bool>(this.ValidateObject)).ToList<JsonSchemaModel>();
				this.Push(new JsonValidatingReader.SchemaScope(JTokenType.Object, list));
				this.WriteToken(this.CurrentSchemas);
				return;
			}
			case JsonToken.StartArray:
			{
				this.ProcessValue();
				IList<JsonSchemaModel> list2 = this.CurrentMemberSchemas.Where(new Func<JsonSchemaModel, bool>(this.ValidateArray)).ToList<JsonSchemaModel>();
				this.Push(new JsonValidatingReader.SchemaScope(JTokenType.Array, list2));
				this.WriteToken(this.CurrentSchemas);
				return;
			}
			case JsonToken.StartConstructor:
				this.ProcessValue();
				this.Push(new JsonValidatingReader.SchemaScope(JTokenType.Constructor, null));
				this.WriteToken(this.CurrentSchemas);
				return;
			case JsonToken.PropertyName:
			{
				this.WriteToken(this.CurrentSchemas);
				IEnumerator<JsonSchemaModel> enumerator = this.CurrentSchemas.GetEnumerator();
				try
				{
					while (JsonValidatingReader.smethod_15(enumerator))
					{
						JsonSchemaModel jsonSchemaModel = enumerator.Current;
						this.ValidatePropertyName(jsonSchemaModel);
					}
					return;
				}
				finally
				{
					if (enumerator != null)
					{
						JsonValidatingReader.smethod_16(enumerator);
					}
				}
				break;
			}
			case JsonToken.Raw:
				this.ProcessValue();
				return;
			case JsonToken.Integer:
			{
				this.ProcessValue();
				this.WriteToken(this.CurrentMemberSchemas);
				IEnumerator<JsonSchemaModel> enumerator2 = this.CurrentMemberSchemas.GetEnumerator();
				try
				{
					while (JsonValidatingReader.smethod_15(enumerator2))
					{
						JsonSchemaModel jsonSchemaModel2 = enumerator2.Current;
						this.ValidateInteger(jsonSchemaModel2);
					}
					return;
				}
				finally
				{
					if (enumerator2 != null)
					{
						JsonValidatingReader.smethod_16(enumerator2);
					}
				}
				goto IL_01DE;
			}
			case JsonToken.Float:
				goto IL_01DE;
			case JsonToken.String:
				goto IL_022B;
			case JsonToken.Boolean:
				goto IL_0278;
			case JsonToken.Null:
				goto IL_02C2;
			case JsonToken.Undefined:
			case JsonToken.Date:
			case JsonToken.Bytes:
				this.WriteToken(this.CurrentMemberSchemas);
				return;
			case JsonToken.EndObject:
			{
				this.WriteToken(this.CurrentSchemas);
				IEnumerator<JsonSchemaModel> enumerator3 = this.CurrentSchemas.GetEnumerator();
				try
				{
					while (JsonValidatingReader.smethod_15(enumerator3))
					{
						JsonSchemaModel jsonSchemaModel3 = enumerator3.Current;
						this.ValidateEndObject(jsonSchemaModel3);
					}
				}
				finally
				{
					if (enumerator3 != null)
					{
						JsonValidatingReader.smethod_16(enumerator3);
					}
				}
				this.Pop();
				return;
			}
			case JsonToken.EndArray:
			{
				this.WriteToken(this.CurrentSchemas);
				IEnumerator<JsonSchemaModel> enumerator4 = this.CurrentSchemas.GetEnumerator();
				try
				{
					while (JsonValidatingReader.smethod_15(enumerator4))
					{
						JsonSchemaModel jsonSchemaModel4 = enumerator4.Current;
						this.ValidateEndArray(jsonSchemaModel4);
					}
				}
				finally
				{
					if (enumerator4 != null)
					{
						JsonValidatingReader.smethod_16(enumerator4);
					}
				}
				this.Pop();
				return;
			}
			case JsonToken.EndConstructor:
				this.WriteToken(this.CurrentSchemas);
				this.Pop();
				return;
			}
			throw JsonValidatingReader.smethod_21();
			IL_01DE:
			this.ProcessValue();
			this.WriteToken(this.CurrentMemberSchemas);
			IEnumerator<JsonSchemaModel> enumerator5 = this.CurrentMemberSchemas.GetEnumerator();
			try
			{
				while (JsonValidatingReader.smethod_15(enumerator5))
				{
					JsonSchemaModel jsonSchemaModel5 = enumerator5.Current;
					this.ValidateFloat(jsonSchemaModel5);
				}
				return;
			}
			finally
			{
				if (enumerator5 != null)
				{
					JsonValidatingReader.smethod_16(enumerator5);
				}
			}
			IL_022B:
			this.ProcessValue();
			this.WriteToken(this.CurrentMemberSchemas);
			IEnumerator<JsonSchemaModel> enumerator6 = this.CurrentMemberSchemas.GetEnumerator();
			try
			{
				while (JsonValidatingReader.smethod_15(enumerator6))
				{
					JsonSchemaModel jsonSchemaModel6 = enumerator6.Current;
					this.ValidateString(jsonSchemaModel6);
				}
				return;
			}
			finally
			{
				if (enumerator6 != null)
				{
					JsonValidatingReader.smethod_16(enumerator6);
				}
			}
			IL_0278:
			this.ProcessValue();
			this.WriteToken(this.CurrentMemberSchemas);
			IEnumerator<JsonSchemaModel> enumerator7 = this.CurrentMemberSchemas.GetEnumerator();
			try
			{
				while (JsonValidatingReader.smethod_15(enumerator7))
				{
					JsonSchemaModel jsonSchemaModel7 = enumerator7.Current;
					this.ValidateBoolean(jsonSchemaModel7);
				}
				return;
			}
			finally
			{
				if (enumerator7 != null)
				{
					JsonValidatingReader.smethod_16(enumerator7);
				}
			}
			IL_02C2:
			this.ProcessValue();
			this.WriteToken(this.CurrentMemberSchemas);
			IEnumerator<JsonSchemaModel> enumerator8 = this.CurrentMemberSchemas.GetEnumerator();
			try
			{
				while (JsonValidatingReader.smethod_15(enumerator8))
				{
					JsonSchemaModel jsonSchemaModel8 = enumerator8.Current;
					this.ValidateNull(jsonSchemaModel8);
				}
			}
			finally
			{
				if (enumerator8 != null)
				{
					JsonValidatingReader.smethod_16(enumerator8);
				}
			}
		}

		// Token: 0x06001D77 RID: 7543 RVA: 0x0008065C File Offset: 0x0007E85C
		private void WriteToken(IList<JsonSchemaModel> schemas)
		{
			using (Stack<JsonValidatingReader.SchemaScope>.Enumerator enumerator = this._stack.GetEnumerator())
			{
				IL_02D2:
				while (enumerator.MoveNext())
				{
					JToken token;
					for (;;)
					{
						IL_0211:
						JsonValidatingReader.SchemaScope schemaScope = enumerator.Current;
						int num = 1215799832;
						for (;;)
						{
							bool flag;
							bool flag2;
							switch (num ^ 1215799834)
							{
							case 0:
								flag = schemaScope.ArrayItemCount > 0;
								goto IL_0025;
							case 1:
								goto IL_0183;
							case 2:
								if (schemaScope.TokenType == JTokenType.Array)
								{
									num = 1215799829;
									continue;
								}
								goto IL_0024;
							case 4:
								num = 1215799836;
								continue;
							case 5:
								if (schemaScope.CurrentItemWriter != null)
								{
									goto IL_0183;
								}
								if (!JsonTokenUtils.IsEndToken(this._reader.TokenType))
								{
									num = 1215799830;
									continue;
								}
								goto IL_02D2;
							case 6:
								goto IL_0211;
							case 7:
								goto IL_02D2;
							case 8:
								if (this._reader.TokenType != JsonToken.PropertyName)
								{
									num = 1215799828;
									continue;
								}
								goto IL_02D2;
							case 9:
								goto IL_0134;
							case 10:
								if (schemaScope.UniqueArrayItems.Contains(token, JToken.EqualityComparer))
								{
									this.RaiseError(<Module>.smethod_23<string>(479438499U).FormatWith(JsonValidatingReader.smethod_17(), schemaScope.ArrayItemCount - 1), schemaScope.Schemas.First((JsonSchemaModel s) => s.UniqueItems));
									num = 1215799827;
									continue;
								}
								goto IL_0134;
							case 11:
								if (schemas.Any((JsonSchemaModel s) => s.Enum != null))
								{
									num = 1215799839;
									continue;
								}
								goto IL_02D2;
							case 12:
								schemaScope.CurrentItemWriter = new JTokenWriter();
								num = 1215799835;
								continue;
							case 13:
								if (schemaScope.CurrentItemWriter.Top == 0)
								{
									num = 1215799826;
									continue;
								}
								goto IL_02D2;
							case 14:
								token = schemaScope.CurrentItemWriter.Token;
								schemaScope.CurrentItemWriter = null;
								num = ((!flag2) ? 1215799833 : 1215799824);
								continue;
							case 15:
								if (schemaScope.IsUniqueArray)
								{
									num = 1215799834;
									continue;
								}
								goto IL_0024;
							}
							goto Block_15;
							IL_0025:
							num = ((!(flag2 = flag)) ? 1215799825 : 1215799839);
							continue;
							IL_0024:
							flag = false;
							goto IL_0025;
							IL_0134:
							schemaScope.UniqueArrayItems.Add(token);
							num = 1215799837;
							continue;
							IL_0183:
							schemaScope.CurrentItemWriter.WriteToken(this._reader, false);
							num = 1215799831;
						}
					}
					IL_0220:
					if (schemas.Any((JsonSchemaModel s) => s.Enum != null))
					{
						IEnumerator<JsonSchemaModel> enumerator2 = schemas.GetEnumerator();
						try
						{
							while (JsonValidatingReader.smethod_15(enumerator2))
							{
								JsonSchemaModel jsonSchemaModel = enumerator2.Current;
								if (jsonSchemaModel.Enum != null && !jsonSchemaModel.Enum.ContainsValue(token, JToken.EqualityComparer))
								{
									StringWriter stringWriter = JsonValidatingReader.smethod_22(JsonValidatingReader.smethod_17());
									token.WriteTo(new JsonTextWriter(stringWriter), new JsonConverter[0]);
									this.RaiseError(<Module>.smethod_25<string>(4182061082U).FormatWith(JsonValidatingReader.smethod_17(), JsonValidatingReader.smethod_23(stringWriter)), jsonSchemaModel);
								}
							}
						}
						finally
						{
							if (enumerator2 != null)
							{
								JsonValidatingReader.smethod_16(enumerator2);
							}
						}
						continue;
					}
					continue;
					Block_15:
					goto IL_0220;
				}
			}
		}

		// Token: 0x06001D78 RID: 7544 RVA: 0x0008098C File Offset: 0x0007EB8C
		private void ValidateEndObject(JsonSchemaModel schema)
		{
			if (schema == null)
			{
				return;
			}
			Dictionary<string, bool> requiredProperties = this._currentScope.RequiredProperties;
			if (requiredProperties != null)
			{
				List<string> list = (from kv in requiredProperties
					where !kv.Value
					select kv.Key).ToList<string>();
				if (list.Count > 0)
				{
					this.RaiseError(<Module>.smethod_27<string>(3825372223U).FormatWith(JsonValidatingReader.smethod_17(), JsonValidatingReader.smethod_24(<Module>.smethod_25<string>(1412486966U), list.ToArray())), schema);
				}
			}
		}

		// Token: 0x06001D79 RID: 7545 RVA: 0x00080A34 File Offset: 0x0007EC34
		private void ValidateEndArray(JsonSchemaModel schema)
		{
			if (schema == null)
			{
				return;
			}
			int arrayItemCount = this._currentScope.ArrayItemCount;
			if (schema.MaximumItems != null && arrayItemCount > schema.MaximumItems)
			{
				this.RaiseError(<Module>.smethod_23<string>(828373753U).FormatWith(JsonValidatingReader.smethod_17(), arrayItemCount, schema.MaximumItems), schema);
			}
			if (schema.MinimumItems != null && arrayItemCount < schema.MinimumItems)
			{
				this.RaiseError(<Module>.smethod_24<string>(3594230746U).FormatWith(JsonValidatingReader.smethod_17(), arrayItemCount, schema.MinimumItems), schema);
			}
		}

		// Token: 0x06001D7A RID: 7546 RVA: 0x0001988E File Offset: 0x00017A8E
		private void ValidateNull(JsonSchemaModel schema)
		{
			if (schema == null)
			{
				return;
			}
			if (this.TestType(schema, JsonSchemaType.Null))
			{
				this.ValidateNotDisallowed(schema);
				return;
			}
		}

		// Token: 0x06001D7B RID: 7547 RVA: 0x000198A7 File Offset: 0x00017AA7
		private void ValidateBoolean(JsonSchemaModel schema)
		{
			if (schema == null)
			{
				return;
			}
			if (!this.TestType(schema, JsonSchemaType.Boolean))
			{
				return;
			}
			this.ValidateNotDisallowed(schema);
		}

		// Token: 0x06001D7C RID: 7548 RVA: 0x00080B0C File Offset: 0x0007ED0C
		private void ValidateString(JsonSchemaModel schema)
		{
			if (schema == null)
			{
				return;
			}
			string text;
			for (;;)
			{
				IL_01B7:
				int num = ((!this.TestType(schema, JsonSchemaType.String)) ? 1336329374 : 1336329371);
				for (;;)
				{
					bool flag;
					int? minimumLength2;
					switch (num ^ 1336329363)
					{
					case 0:
					{
						int? maximumLength = schema.MaximumLength;
						int num2;
						if (num2 > maximumLength.GetValueOrDefault())
						{
							num = 1336329361;
							continue;
						}
						flag = false;
						goto IL_012D;
					}
					case 1:
					{
						int num3 = JsonValidatingReader.smethod_25(text);
						num = 1336329364;
						continue;
					}
					case 2:
					{
						int? maximumLength;
						flag = maximumLength != null;
						goto IL_012D;
					}
					case 3:
						text = JsonValidatingReader.smethod_23(this._reader.Value);
						num = 1336329368;
						continue;
					case 4:
					{
						int num3;
						int? minimumLength;
						if (num3 < minimumLength)
						{
							num = 1336329375;
							continue;
						}
						break;
					}
					case 5:
						this.RaiseError(<Module>.smethod_25<string>(3993343513U).FormatWith(JsonValidatingReader.smethod_17(), text, schema.MaximumLength), schema);
						num = 1336329369;
						continue;
					case 6:
						num = 1336329372;
						continue;
					case 7:
					{
						int? minimumLength = schema.MinimumLength;
						num = 1336329367;
						continue;
					}
					case 8:
						this.ValidateNotDisallowed(schema);
						num = 1336329360;
						continue;
					case 10:
						goto IL_0080;
					case 11:
						if (schema.MaximumLength != null)
						{
							int num2 = JsonValidatingReader.smethod_25(text);
							num = 1336329363;
							continue;
						}
						goto IL_0080;
					case 12:
						this.RaiseError(<Module>.smethod_25<string>(3953193933U).FormatWith(JsonValidatingReader.smethod_17(), text, schema.MinimumLength), schema);
						num = 1336329370;
						continue;
					case 13:
						return;
					case 14:
						num = ((minimumLength2 != null) ? 1336329362 : 1336329370);
						continue;
					case 15:
						goto IL_01B7;
					}
					goto Block_8;
					IL_0080:
					minimumLength2 = schema.MinimumLength;
					num = 1336329373;
					continue;
					IL_012D:
					if (!flag)
					{
						goto IL_0080;
					}
					num = 1336329366;
				}
			}
			Block_8:
			if (schema.Patterns != null)
			{
				IEnumerator<string> enumerator = schema.Patterns.GetEnumerator();
				try
				{
					while (JsonValidatingReader.smethod_15(enumerator))
					{
						string text2 = enumerator.Current;
						if (!JsonValidatingReader.smethod_14(text, text2))
						{
							this.RaiseError(<Module>.smethod_27<string>(2204706675U).FormatWith(JsonValidatingReader.smethod_17(), text, text2), schema);
						}
					}
				}
				finally
				{
					if (enumerator != null)
					{
						JsonValidatingReader.smethod_16(enumerator);
					}
				}
			}
		}

		// Token: 0x06001D7D RID: 7549 RVA: 0x00080D50 File Offset: 0x0007EF50
		private void ValidateInteger(JsonSchemaModel schema)
		{
			if (schema == null)
			{
				return;
			}
			if (!this.TestType(schema, JsonSchemaType.Integer))
			{
				return;
			}
			this.ValidateNotDisallowed(schema);
			object value = this._reader.Value;
			if (schema.Maximum != null)
			{
				if (JValue.Compare(JTokenType.Integer, value, schema.Maximum) > 0)
				{
					this.RaiseError(<Module>.smethod_27<string>(1318894508U).FormatWith(JsonValidatingReader.smethod_17(), value, schema.Maximum), schema);
				}
				if (schema.ExclusiveMaximum && JValue.Compare(JTokenType.Integer, value, schema.Maximum) == 0)
				{
					this.RaiseError(<Module>.smethod_23<string>(3139221656U).FormatWith(JsonValidatingReader.smethod_17(), value, schema.Maximum), schema);
				}
			}
			if (schema.Minimum != null)
			{
				if (JValue.Compare(JTokenType.Integer, value, schema.Minimum) < 0)
				{
					this.RaiseError(<Module>.smethod_24<string>(308349846U).FormatWith(JsonValidatingReader.smethod_17(), value, schema.Minimum), schema);
				}
				if (schema.ExclusiveMinimum && JValue.Compare(JTokenType.Integer, value, schema.Minimum) == 0)
				{
					this.RaiseError(<Module>.smethod_23<string>(2366094648U).FormatWith(JsonValidatingReader.smethod_17(), value, schema.Minimum), schema);
				}
			}
			if (schema.DivisibleBy != null)
			{
				bool flag;
				if (value is BigInteger)
				{
					BigInteger bigInteger = (BigInteger)value;
					if (JsonValidatingReader.smethod_27(schema.DivisibleBy.Value - JsonValidatingReader.smethod_26(schema.DivisibleBy.Value)).Equals(0.0))
					{
						flag = bigInteger % new BigInteger(schema.DivisibleBy.Value) != 0L;
					}
					else
					{
						flag = bigInteger != 0L;
					}
				}
				else
				{
					flag = !JsonValidatingReader.IsZero((double)Convert.ToInt64(value, CultureInfo.InvariantCulture) % schema.DivisibleBy.Value);
				}
				if (flag)
				{
					this.RaiseError(<Module>.smethod_26<string>(3335930821U).FormatWith(CultureInfo.InvariantCulture, JsonConvert.ToString(value), schema.DivisibleBy), schema);
				}
			}
		}

		// Token: 0x06001D7E RID: 7550 RVA: 0x00080F9C File Offset: 0x0007F19C
		private void ProcessValue()
		{
			if (this._currentScope != null && this._currentScope.TokenType == JTokenType.Array)
			{
				this._currentScope.ArrayItemCount++;
				IEnumerator<JsonSchemaModel> enumerator = this.CurrentSchemas.GetEnumerator();
				try
				{
					while (JsonValidatingReader.smethod_15(enumerator))
					{
						JsonSchemaModel jsonSchemaModel = enumerator.Current;
						if (jsonSchemaModel != null && jsonSchemaModel.PositionalItemsValidation && !jsonSchemaModel.AllowAdditionalItems && (jsonSchemaModel.Items == null || this._currentScope.ArrayItemCount - 1 >= jsonSchemaModel.Items.Count))
						{
							this.RaiseError(<Module>.smethod_26<string>(3355083609U).FormatWith(JsonValidatingReader.smethod_17(), this._currentScope.ArrayItemCount), jsonSchemaModel);
						}
					}
				}
				finally
				{
					if (enumerator != null)
					{
						JsonValidatingReader.smethod_16(enumerator);
					}
				}
			}
		}

		// Token: 0x06001D7F RID: 7551 RVA: 0x00081074 File Offset: 0x0007F274
		private void ValidateFloat(JsonSchemaModel schema)
		{
			if (schema == null)
			{
				return;
			}
			if (!this.TestType(schema, JsonSchemaType.Float))
			{
				return;
			}
			this.ValidateNotDisallowed(schema);
			double num = JsonValidatingReader.smethod_28(this._reader.Value, JsonValidatingReader.smethod_17());
			if (schema.Maximum != null)
			{
				double num2 = num;
				double? maximum = schema.Maximum;
				if (num2 > maximum.GetValueOrDefault() && maximum != null)
				{
					this.RaiseError(<Module>.smethod_26<string>(13757980U).FormatWith(JsonValidatingReader.smethod_17(), JsonConvert.ToString(num), schema.Maximum), schema);
				}
				if (schema.ExclusiveMaximum)
				{
					double num3 = num;
					double? maximum2 = schema.Maximum;
					if (num3 == maximum2.GetValueOrDefault() && maximum2 != null)
					{
						this.RaiseError(<Module>.smethod_23<string>(3270920531U).FormatWith(JsonValidatingReader.smethod_17(), JsonConvert.ToString(num), schema.Maximum), schema);
					}
				}
			}
			if (schema.Minimum != null)
			{
				double num4 = num;
				double? minimum = schema.Minimum;
				if (num4 < minimum.GetValueOrDefault() && minimum != null)
				{
					this.RaiseError(<Module>.smethod_26<string>(3632799035U).FormatWith(JsonValidatingReader.smethod_17(), JsonConvert.ToString(num), schema.Minimum), schema);
				}
				if (schema.ExclusiveMinimum)
				{
					double num5 = num;
					double? minimum2 = schema.Minimum;
					if (num5 == minimum2.GetValueOrDefault() && minimum2 != null)
					{
						this.RaiseError(<Module>.smethod_24<string>(2379872520U).FormatWith(JsonValidatingReader.smethod_17(), JsonConvert.ToString(num), schema.Minimum), schema);
					}
				}
			}
			if (schema.DivisibleBy != null)
			{
				double num6 = JsonValidatingReader.FloatingPointRemainder(num, schema.DivisibleBy.Value);
				if (!JsonValidatingReader.IsZero(num6))
				{
					this.RaiseError(<Module>.smethod_24<string>(2610041706U).FormatWith(JsonValidatingReader.smethod_17(), JsonConvert.ToString(num), schema.DivisibleBy), schema);
				}
			}
		}

		// Token: 0x06001D80 RID: 7552 RVA: 0x000198BF File Offset: 0x00017ABF
		private static double FloatingPointRemainder(double dividend, double divisor)
		{
			return dividend - JsonValidatingReader.smethod_29(dividend / divisor) * divisor;
		}

		// Token: 0x06001D81 RID: 7553 RVA: 0x000198CD File Offset: 0x00017ACD
		private static bool IsZero(double value)
		{
			return JsonValidatingReader.smethod_27(value) < 4.4408920985006262E-15;
		}

		// Token: 0x06001D82 RID: 7554 RVA: 0x0008127C File Offset: 0x0007F47C
		private void ValidatePropertyName(JsonSchemaModel schema)
		{
			if (schema == null)
			{
				return;
			}
			string text = JsonValidatingReader.smethod_30(this._reader.Value, JsonValidatingReader.smethod_17());
			if (this._currentScope.RequiredProperties.ContainsKey(text))
			{
				this._currentScope.RequiredProperties[text] = true;
			}
			if (!schema.AllowAdditionalProperties && !this.IsPropertyDefinied(schema, text))
			{
				this.RaiseError(<Module>.smethod_23<string>(3968791039U).FormatWith(JsonValidatingReader.smethod_17(), text), schema);
			}
			this._currentScope.CurrentPropertyName = text;
		}

		// Token: 0x06001D83 RID: 7555 RVA: 0x00081304 File Offset: 0x0007F504
		private bool IsPropertyDefinied(JsonSchemaModel schema, string propertyName)
		{
			if (schema.Properties != null && schema.Properties.ContainsKey(propertyName))
			{
				return true;
			}
			if (schema.PatternProperties != null)
			{
				IEnumerator<string> enumerator = schema.PatternProperties.Keys.GetEnumerator();
				try
				{
					while (JsonValidatingReader.smethod_15(enumerator))
					{
						string text = enumerator.Current;
						if (JsonValidatingReader.smethod_14(propertyName, text))
						{
							return true;
						}
					}
					return false;
				}
				finally
				{
					if (enumerator != null)
					{
						JsonValidatingReader.smethod_16(enumerator);
					}
				}
				bool flag;
				return flag;
			}
			return false;
		}

		// Token: 0x06001D84 RID: 7556 RVA: 0x000198E0 File Offset: 0x00017AE0
		private bool ValidateArray(JsonSchemaModel schema)
		{
			return schema == null || this.TestType(schema, JsonSchemaType.Array);
		}

		// Token: 0x06001D85 RID: 7557 RVA: 0x000198F0 File Offset: 0x00017AF0
		private bool ValidateObject(JsonSchemaModel schema)
		{
			return schema == null || this.TestType(schema, JsonSchemaType.Object);
		}

		// Token: 0x06001D86 RID: 7558 RVA: 0x00081380 File Offset: 0x0007F580
		private bool TestType(JsonSchemaModel currentSchema, JsonSchemaType currentType)
		{
			if (!JsonSchemaGenerator.HasFlag(new JsonSchemaType?(currentSchema.Type), currentType))
			{
				this.RaiseError(<Module>.smethod_23<string>(2672261150U).FormatWith(JsonValidatingReader.smethod_17(), currentSchema.Type, currentType), currentSchema);
				return false;
			}
			return true;
		}

		// Token: 0x06001D87 RID: 7559 RVA: 0x000813D0 File Offset: 0x0007F5D0
		bool IJsonLineInfo.HasLineInfo()
		{
			IJsonLineInfo jsonLineInfo = this._reader as IJsonLineInfo;
			return jsonLineInfo != null && jsonLineInfo.HasLineInfo();
		}

		// Token: 0x1700043C RID: 1084
		// (get) Token: 0x06001D88 RID: 7560 RVA: 0x000813F4 File Offset: 0x0007F5F4
		int IJsonLineInfo.LineNumber
		{
			get
			{
				IJsonLineInfo jsonLineInfo = this._reader as IJsonLineInfo;
				if (jsonLineInfo == null)
				{
					return 0;
				}
				return jsonLineInfo.LineNumber;
			}
		}

		// Token: 0x1700043D RID: 1085
		// (get) Token: 0x06001D89 RID: 7561 RVA: 0x00081418 File Offset: 0x0007F618
		int IJsonLineInfo.LinePosition
		{
			get
			{
				IJsonLineInfo jsonLineInfo = this._reader as IJsonLineInfo;
				if (jsonLineInfo == null)
				{
					return 0;
				}
				return jsonLineInfo.LinePosition;
			}
		}

		// Token: 0x06001D90 RID: 7568 RVA: 0x0000CD19 File Offset: 0x0000AF19
		static Delegate smethod_12(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Combine(delegate_0, delegate_1);
		}

		// Token: 0x06001D91 RID: 7569 RVA: 0x0000CD22 File Offset: 0x0000AF22
		static Delegate smethod_13(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Remove(delegate_0, delegate_1);
		}

		// Token: 0x06001D92 RID: 7570 RVA: 0x00019937 File Offset: 0x00017B37
		static bool smethod_14(string string_0, string string_1)
		{
			return Regex.IsMatch(string_0, string_1);
		}

		// Token: 0x06001D93 RID: 7571 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_15(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06001D94 RID: 7572 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_16(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06001D95 RID: 7573 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_17()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001D96 RID: 7574 RVA: 0x0000DECA File Offset: 0x0000C0CA
		static ArgumentOutOfRangeException smethod_18(string string_0, string string_1)
		{
			return new ArgumentOutOfRangeException(string_0, string_1);
		}

		// Token: 0x06001D97 RID: 7575 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_19(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x06001D98 RID: 7576 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_20(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x06001D99 RID: 7577 RVA: 0x00016A1F File Offset: 0x00014C1F
		static ArgumentOutOfRangeException smethod_21()
		{
			return new ArgumentOutOfRangeException();
		}

		// Token: 0x06001D9A RID: 7578 RVA: 0x00016261 File Offset: 0x00014461
		static StringWriter smethod_22(IFormatProvider iformatProvider_0)
		{
			return new StringWriter(iformatProvider_0);
		}

		// Token: 0x06001D9B RID: 7579 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_23(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06001D9C RID: 7580 RVA: 0x0000DAF6 File Offset: 0x0000BCF6
		static string smethod_24(string string_0, string[] string_1)
		{
			return string.Join(string_0, string_1);
		}

		// Token: 0x06001D9D RID: 7581 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_25(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06001D9E RID: 7582 RVA: 0x00019940 File Offset: 0x00017B40
		static double smethod_26(double double_0)
		{
			return Math.Truncate(double_0);
		}

		// Token: 0x06001D9F RID: 7583 RVA: 0x0000FC9F File Offset: 0x0000DE9F
		static double smethod_27(double double_0)
		{
			return Math.Abs(double_0);
		}

		// Token: 0x06001DA0 RID: 7584 RVA: 0x00017112 File Offset: 0x00015312
		static double smethod_28(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToDouble(object_0, iformatProvider_0);
		}

		// Token: 0x06001DA1 RID: 7585 RVA: 0x0000EE64 File Offset: 0x0000D064
		static double smethod_29(double double_0)
		{
			return Math.Floor(double_0);
		}

		// Token: 0x06001DA2 RID: 7586 RVA: 0x00018E7F File Offset: 0x0001707F
		static string smethod_30(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToString(object_0, iformatProvider_0);
		}

		// Token: 0x04000B48 RID: 2888
		private readonly JsonReader _reader;

		// Token: 0x04000B49 RID: 2889
		private readonly Stack<JsonValidatingReader.SchemaScope> _stack;

		// Token: 0x04000B4A RID: 2890
		private JsonSchema _schema;

		// Token: 0x04000B4B RID: 2891
		private JsonSchemaModel _model;

		// Token: 0x04000B4C RID: 2892
		private JsonValidatingReader.SchemaScope _currentScope;

		// Token: 0x04000B4E RID: 2894
		private static readonly IList<JsonSchemaModel> EmptySchemaList = new List<JsonSchemaModel>();

		// Token: 0x02000208 RID: 520
		private class SchemaScope
		{
			// Token: 0x1700043E RID: 1086
			// (get) Token: 0x06001DA3 RID: 7587 RVA: 0x00019948 File Offset: 0x00017B48
			// (set) Token: 0x06001DA4 RID: 7588 RVA: 0x00019950 File Offset: 0x00017B50
			public string CurrentPropertyName { get; set; }

			// Token: 0x1700043F RID: 1087
			// (get) Token: 0x06001DA5 RID: 7589 RVA: 0x00019959 File Offset: 0x00017B59
			// (set) Token: 0x06001DA6 RID: 7590 RVA: 0x00019961 File Offset: 0x00017B61
			public int ArrayItemCount { get; set; }

			// Token: 0x17000440 RID: 1088
			// (get) Token: 0x06001DA7 RID: 7591 RVA: 0x0001996A File Offset: 0x00017B6A
			// (set) Token: 0x06001DA8 RID: 7592 RVA: 0x00019972 File Offset: 0x00017B72
			public bool IsUniqueArray { get; set; }

			// Token: 0x17000441 RID: 1089
			// (get) Token: 0x06001DA9 RID: 7593 RVA: 0x0001997B File Offset: 0x00017B7B
			// (set) Token: 0x06001DAA RID: 7594 RVA: 0x00019983 File Offset: 0x00017B83
			public IList<JToken> UniqueArrayItems { get; set; }

			// Token: 0x17000442 RID: 1090
			// (get) Token: 0x06001DAB RID: 7595 RVA: 0x0001998C File Offset: 0x00017B8C
			// (set) Token: 0x06001DAC RID: 7596 RVA: 0x00019994 File Offset: 0x00017B94
			public JTokenWriter CurrentItemWriter { get; set; }

			// Token: 0x17000443 RID: 1091
			// (get) Token: 0x06001DAD RID: 7597 RVA: 0x0001999D File Offset: 0x00017B9D
			public IList<JsonSchemaModel> Schemas
			{
				get
				{
					return this._schemas;
				}
			}

			// Token: 0x17000444 RID: 1092
			// (get) Token: 0x06001DAE RID: 7598 RVA: 0x000199A5 File Offset: 0x00017BA5
			public Dictionary<string, bool> RequiredProperties
			{
				get
				{
					return this._requiredProperties;
				}
			}

			// Token: 0x17000445 RID: 1093
			// (get) Token: 0x06001DAF RID: 7599 RVA: 0x000199AD File Offset: 0x00017BAD
			public JTokenType TokenType
			{
				get
				{
					return this._tokenType;
				}
			}

			// Token: 0x06001DB0 RID: 7600 RVA: 0x0008143C File Offset: 0x0007F63C
			public SchemaScope(JTokenType tokenType, IList<JsonSchemaModel> schemas)
			{
				this._tokenType = tokenType;
				this._schemas = schemas;
				this._requiredProperties = schemas.SelectMany(new Func<JsonSchemaModel, IEnumerable<string>>(this.GetRequiredProperties)).Distinct<string>().ToDictionary((string p) => p, (string p) => false);
				if (tokenType == JTokenType.Array)
				{
					if (schemas.Any((JsonSchemaModel s) => s.UniqueItems))
					{
						this.IsUniqueArray = true;
						this.UniqueArrayItems = new List<JToken>();
					}
				}
			}

			// Token: 0x06001DB1 RID: 7601 RVA: 0x000814F4 File Offset: 0x0007F6F4
			private IEnumerable<string> GetRequiredProperties(JsonSchemaModel schema)
			{
				if (schema != null && schema.Properties != null)
				{
					return from p in schema.Properties
						where p.Value.Required
						select p.Key;
				}
				return Enumerable.Empty<string>();
			}

			// Token: 0x04000B54 RID: 2900
			private readonly JTokenType _tokenType;

			// Token: 0x04000B55 RID: 2901
			private readonly IList<JsonSchemaModel> _schemas;

			// Token: 0x04000B56 RID: 2902
			private readonly Dictionary<string, bool> _requiredProperties;
		}
	}
}
