﻿using System;
using System.Collections.ObjectModel;

namespace Newtonsoft.Json
{
	// Token: 0x0200022D RID: 557
	public class JsonConverterCollection : Collection<JsonConverter>
	{
	}
}
