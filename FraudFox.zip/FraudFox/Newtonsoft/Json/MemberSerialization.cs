﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200020A RID: 522
	public enum MemberSerialization
	{
		// Token: 0x04000B62 RID: 2914
		OptOut,
		// Token: 0x04000B63 RID: 2915
		OptIn,
		// Token: 0x04000B64 RID: 2916
		Fields
	}
}
