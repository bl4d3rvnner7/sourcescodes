﻿using System;
using System.Runtime.Serialization;

namespace Newtonsoft.Json
{
	// Token: 0x020001B6 RID: 438
	[Serializable]
	public class JsonException : Exception
	{
		// Token: 0x06001990 RID: 6544 RVA: 0x0000F665 File Offset: 0x0000D865
		public JsonException()
		{
		}

		// Token: 0x06001991 RID: 6545 RVA: 0x0000C1DA File Offset: 0x0000A3DA
		public JsonException(string message)
			: base(message)
		{
		}

		// Token: 0x06001992 RID: 6546 RVA: 0x0000F66D File Offset: 0x0000D86D
		public JsonException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

		// Token: 0x06001993 RID: 6547 RVA: 0x00013288 File Offset: 0x00011488
		public JsonException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		// Token: 0x06001994 RID: 6548 RVA: 0x00017A04 File Offset: 0x00015C04
		internal static JsonException Create(IJsonLineInfo lineInfo, string path, string message)
		{
			message = JsonPosition.FormatMessage(lineInfo, path, message);
			return new JsonException(message);
		}
	}
}
