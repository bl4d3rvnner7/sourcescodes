﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000200 RID: 512
	[Flags]
	public enum PreserveReferencesHandling
	{
		// Token: 0x04000B04 RID: 2820
		None = 0,
		// Token: 0x04000B05 RID: 2821
		Objects = 1,
		// Token: 0x04000B06 RID: 2822
		Arrays = 2,
		// Token: 0x04000B07 RID: 2823
		All = 3
	}
}
