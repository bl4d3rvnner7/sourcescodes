﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json
{
	// Token: 0x0200018D RID: 397
	public abstract class JsonReader : IDisposable
	{
		// Token: 0x17000364 RID: 868
		// (get) Token: 0x0600174C RID: 5964 RVA: 0x00016652 File Offset: 0x00014852
		protected JsonReader.State CurrentState
		{
			get
			{
				return this._currentState;
			}
		}

		// Token: 0x17000365 RID: 869
		// (get) Token: 0x0600174D RID: 5965 RVA: 0x0001665A File Offset: 0x0001485A
		// (set) Token: 0x0600174E RID: 5966 RVA: 0x00016662 File Offset: 0x00014862
		public bool CloseInput { get; set; }

		// Token: 0x17000366 RID: 870
		// (get) Token: 0x0600174F RID: 5967 RVA: 0x0001666B File Offset: 0x0001486B
		// (set) Token: 0x06001750 RID: 5968 RVA: 0x00016673 File Offset: 0x00014873
		public bool SupportMultipleContent { get; set; }

		// Token: 0x17000367 RID: 871
		// (get) Token: 0x06001751 RID: 5969 RVA: 0x0001667C File Offset: 0x0001487C
		// (set) Token: 0x06001752 RID: 5970 RVA: 0x00016684 File Offset: 0x00014884
		public virtual char QuoteChar
		{
			get
			{
				return this._quoteChar;
			}
			protected internal set
			{
				this._quoteChar = value;
			}
		}

		// Token: 0x17000368 RID: 872
		// (get) Token: 0x06001753 RID: 5971 RVA: 0x0001668D File Offset: 0x0001488D
		// (set) Token: 0x06001754 RID: 5972 RVA: 0x00016695 File Offset: 0x00014895
		public DateTimeZoneHandling DateTimeZoneHandling
		{
			get
			{
				return this._dateTimeZoneHandling;
			}
			set
			{
				this._dateTimeZoneHandling = value;
			}
		}

		// Token: 0x17000369 RID: 873
		// (get) Token: 0x06001755 RID: 5973 RVA: 0x0001669E File Offset: 0x0001489E
		// (set) Token: 0x06001756 RID: 5974 RVA: 0x000166A6 File Offset: 0x000148A6
		public DateParseHandling DateParseHandling
		{
			get
			{
				return this._dateParseHandling;
			}
			set
			{
				this._dateParseHandling = value;
			}
		}

		// Token: 0x1700036A RID: 874
		// (get) Token: 0x06001757 RID: 5975 RVA: 0x000166AF File Offset: 0x000148AF
		// (set) Token: 0x06001758 RID: 5976 RVA: 0x000166B7 File Offset: 0x000148B7
		public FloatParseHandling FloatParseHandling
		{
			get
			{
				return this._floatParseHandling;
			}
			set
			{
				this._floatParseHandling = value;
			}
		}

		// Token: 0x1700036B RID: 875
		// (get) Token: 0x06001759 RID: 5977 RVA: 0x000166C0 File Offset: 0x000148C0
		// (set) Token: 0x0600175A RID: 5978 RVA: 0x000166C8 File Offset: 0x000148C8
		public string DateFormatString
		{
			get
			{
				return this._dateFormatString;
			}
			set
			{
				this._dateFormatString = value;
			}
		}

		// Token: 0x1700036C RID: 876
		// (get) Token: 0x0600175B RID: 5979 RVA: 0x000166D1 File Offset: 0x000148D1
		// (set) Token: 0x0600175C RID: 5980 RVA: 0x00072DD4 File Offset: 0x00070FD4
		public int? MaxDepth
		{
			get
			{
				return this._maxDepth;
			}
			set
			{
				int? num = value;
				for (;;)
				{
					IL_005B:
					int num2 = 1380567407;
					for (;;)
					{
						bool flag;
						switch (num2 ^ 1380567404)
						{
						case 0:
							goto IL_005B;
						case 1:
							goto IL_0062;
						case 2:
							flag = num != null;
							goto IL_0024;
						case 3:
							if (num.GetValueOrDefault() <= 0)
							{
								num2 = 1380567406;
								continue;
							}
							flag = false;
							goto IL_0024;
						case 4:
							IL_0004:
							this._maxDepth = value;
							num2 = 1380567401;
							continue;
						}
						goto Block_3;
						IL_0024:
						if (!flag)
						{
							goto IL_0004;
						}
						num2 = 1380567405;
					}
				}
				Block_3:
				return;
				IL_0062:
				throw JsonReader.smethod_0(<Module>.smethod_26<string>(3068627666U), <Module>.smethod_27<string>(2371252898U));
			}
		}

		// Token: 0x1700036D RID: 877
		// (get) Token: 0x0600175D RID: 5981 RVA: 0x000166D9 File Offset: 0x000148D9
		public virtual JsonToken TokenType
		{
			get
			{
				return this._tokenType;
			}
		}

		// Token: 0x1700036E RID: 878
		// (get) Token: 0x0600175E RID: 5982 RVA: 0x000166E1 File Offset: 0x000148E1
		public virtual object Value
		{
			get
			{
				return this._value;
			}
		}

		// Token: 0x1700036F RID: 879
		// (get) Token: 0x0600175F RID: 5983 RVA: 0x000166E9 File Offset: 0x000148E9
		public virtual Type ValueType
		{
			get
			{
				if (this._value == null)
				{
					return null;
				}
				return JsonReader.smethod_1(this._value);
			}
		}

		// Token: 0x17000370 RID: 880
		// (get) Token: 0x06001760 RID: 5984 RVA: 0x00072E60 File Offset: 0x00071060
		public virtual int Depth
		{
			get
			{
				int count = this._stack.Count;
				if (!JsonTokenUtils.IsStartToken(this.TokenType) && this._currentPosition.Type != JsonContainerType.None)
				{
					return count + 1;
				}
				return count;
			}
		}

		// Token: 0x17000371 RID: 881
		// (get) Token: 0x06001761 RID: 5985 RVA: 0x00072E98 File Offset: 0x00071098
		public virtual string Path
		{
			get
			{
				if (this._currentPosition.Type == JsonContainerType.None)
				{
					return string.Empty;
				}
				IEnumerable<JsonPosition> enumerable = ((this._currentState == JsonReader.State.ArrayStart || this._currentState == JsonReader.State.ConstructorStart || this._currentState == JsonReader.State.ObjectStart) ? this._stack : this._stack.Concat(new JsonPosition[] { this._currentPosition }));
				return JsonPosition.BuildPath(enumerable);
			}
		}

		// Token: 0x17000372 RID: 882
		// (get) Token: 0x06001762 RID: 5986 RVA: 0x00016700 File Offset: 0x00014900
		// (set) Token: 0x06001763 RID: 5987 RVA: 0x00016711 File Offset: 0x00014911
		public CultureInfo Culture
		{
			get
			{
				return this._culture ?? JsonReader.smethod_2();
			}
			set
			{
				this._culture = value;
			}
		}

		// Token: 0x06001764 RID: 5988 RVA: 0x0001671A File Offset: 0x0001491A
		internal JsonPosition GetPosition(int depth)
		{
			if (depth < this._stack.Count)
			{
				return this._stack[depth];
			}
			return this._currentPosition;
		}

		// Token: 0x06001765 RID: 5989 RVA: 0x0001673D File Offset: 0x0001493D
		protected JsonReader()
		{
			this._currentState = JsonReader.State.Start;
			this._stack = new List<JsonPosition>(4);
			this._dateTimeZoneHandling = DateTimeZoneHandling.RoundtripKind;
			this._dateParseHandling = DateParseHandling.DateTime;
			this._floatParseHandling = FloatParseHandling.Double;
			this.CloseInput = true;
		}

		// Token: 0x06001766 RID: 5990 RVA: 0x00072F10 File Offset: 0x00071110
		private void Push(JsonContainerType value)
		{
			this.UpdateScopeWithFinishedValue();
			if (this._currentPosition.Type == JsonContainerType.None)
			{
				this._currentPosition = new JsonPosition(value);
				return;
			}
			this._stack.Add(this._currentPosition);
			this._currentPosition = new JsonPosition(value);
			if (this._maxDepth != null && this.Depth + 1 > this._maxDepth && !this._hasExceededMaxDepth)
			{
				this._hasExceededMaxDepth = true;
				throw JsonReaderException.Create(this, <Module>.smethod_27<string>(3538073033U).FormatWith(JsonReader.smethod_2(), this._maxDepth));
			}
		}

		// Token: 0x06001767 RID: 5991 RVA: 0x00072FC4 File Offset: 0x000711C4
		private JsonContainerType Pop()
		{
			JsonPosition jsonPosition;
			if (this._stack.Count > 0)
			{
				jsonPosition = this._currentPosition;
				this._currentPosition = this._stack[this._stack.Count - 1];
				this._stack.RemoveAt(this._stack.Count - 1);
			}
			else
			{
				jsonPosition = this._currentPosition;
				this._currentPosition = default(JsonPosition);
			}
			if (this._maxDepth != null && this.Depth <= this._maxDepth)
			{
				this._hasExceededMaxDepth = false;
			}
			return jsonPosition.Type;
		}

		// Token: 0x06001768 RID: 5992 RVA: 0x00016774 File Offset: 0x00014974
		private JsonContainerType Peek()
		{
			return this._currentPosition.Type;
		}

		// Token: 0x06001769 RID: 5993
		public abstract bool Read();

		// Token: 0x0600176A RID: 5994
		public abstract int? ReadAsInt32();

		// Token: 0x0600176B RID: 5995
		public abstract string ReadAsString();

		// Token: 0x0600176C RID: 5996
		public abstract byte[] ReadAsBytes();

		// Token: 0x0600176D RID: 5997
		public abstract decimal? ReadAsDecimal();

		// Token: 0x0600176E RID: 5998
		public abstract DateTime? ReadAsDateTime();

		// Token: 0x0600176F RID: 5999
		public abstract DateTimeOffset? ReadAsDateTimeOffset();

		// Token: 0x06001770 RID: 6000 RVA: 0x00016781 File Offset: 0x00014981
		internal virtual bool ReadInternal()
		{
			throw JsonReader.smethod_3();
		}

		// Token: 0x06001771 RID: 6001 RVA: 0x00073070 File Offset: 0x00071270
		internal DateTimeOffset? ReadAsDateTimeOffsetInternal()
		{
			this._readType = ReadType.ReadAsDateTimeOffset;
			while (this.ReadInternal())
			{
				JsonToken tokenType = this.TokenType;
				if (tokenType != JsonToken.Comment)
				{
					if (tokenType == JsonToken.Date)
					{
						if (this.Value is DateTime)
						{
							this.SetToken(JsonToken.Date, new DateTimeOffset((DateTime)this.Value), false);
						}
						return new DateTimeOffset?((DateTimeOffset)this.Value);
					}
					if (tokenType == JsonToken.Null)
					{
						return null;
					}
					if (tokenType == JsonToken.String)
					{
						string text = (string)this.Value;
						if (string.IsNullOrEmpty(text))
						{
							this.SetToken(JsonToken.Null);
							return null;
						}
						object obj;
						DateTimeOffset dateTimeOffset;
						if (DateTimeUtils.TryParseDateTime(text, DateParseHandling.DateTimeOffset, this.DateTimeZoneHandling, this._dateFormatString, this.Culture, out obj))
						{
							dateTimeOffset = (DateTimeOffset)obj;
							this.SetToken(JsonToken.Date, dateTimeOffset, false);
							return new DateTimeOffset?(dateTimeOffset);
						}
						if (DateTimeOffset.TryParse(text, this.Culture, DateTimeStyles.RoundtripKind, out dateTimeOffset))
						{
							this.SetToken(JsonToken.Date, dateTimeOffset, false);
							return new DateTimeOffset?(dateTimeOffset);
						}
						throw JsonReaderException.Create(this, <Module>.smethod_24<string>(2496226019U).FormatWith(CultureInfo.InvariantCulture, this.Value));
					}
					else
					{
						if (tokenType == JsonToken.EndArray)
						{
							return null;
						}
						throw JsonReaderException.Create(this, <Module>.smethod_26<string>(1184494853U).FormatWith(CultureInfo.InvariantCulture, tokenType));
					}
				}
			}
			this.SetToken(JsonToken.None);
			return null;
		}

		// Token: 0x06001772 RID: 6002 RVA: 0x000731EC File Offset: 0x000713EC
		internal byte[] ReadAsBytesInternal()
		{
			this._readType = ReadType.ReadAsBytes;
			while (this.ReadInternal())
			{
				JsonToken jsonToken = this.TokenType;
				if (jsonToken != JsonToken.Comment)
				{
					if (this.IsWrappedInTypeObject())
					{
						byte[] array = this.ReadAsBytes();
						this.ReadInternal();
						this.SetToken(JsonToken.Bytes, array, false);
						return array;
					}
					if (jsonToken == JsonToken.String)
					{
						string text = (string)this.Value;
						byte[] array2;
						Guid guid;
						if (JsonReader.smethod_4(text) == 0)
						{
							array2 = new byte[0];
						}
						else if (ConvertUtils.TryConvertGuid(text, out guid))
						{
							array2 = guid.ToByteArray();
						}
						else
						{
							array2 = Convert.FromBase64String(text);
						}
						this.SetToken(JsonToken.Bytes, array2, false);
						return array2;
					}
					if (jsonToken == JsonToken.Null)
					{
						return null;
					}
					if (jsonToken == JsonToken.Bytes)
					{
						if (this.ValueType == typeof(Guid))
						{
							byte[] array3 = ((Guid)this.Value).ToByteArray();
							this.SetToken(JsonToken.Bytes, array3, false);
							return array3;
						}
						return (byte[])this.Value;
					}
					else
					{
						if (jsonToken == JsonToken.StartArray)
						{
							List<byte> list = new List<byte>();
							while (this.ReadInternal())
							{
								jsonToken = this.TokenType;
								JsonToken jsonToken2 = jsonToken;
								switch (jsonToken2)
								{
								case JsonToken.Comment:
									continue;
								case JsonToken.Raw:
									break;
								case JsonToken.Integer:
									list.Add(Convert.ToByte(this.Value, CultureInfo.InvariantCulture));
									continue;
								default:
									if (jsonToken2 == JsonToken.EndArray)
									{
										byte[] array4 = list.ToArray();
										this.SetToken(JsonToken.Bytes, array4, false);
										return array4;
									}
									break;
								}
								throw JsonReaderException.Create(this, <Module>.smethod_27<string>(1766448699U).FormatWith(CultureInfo.InvariantCulture, jsonToken));
							}
							throw JsonReaderException.Create(this, <Module>.smethod_23<string>(2892993295U));
						}
						if (jsonToken == JsonToken.EndArray)
						{
							return null;
						}
						throw JsonReaderException.Create(this, <Module>.smethod_24<string>(4053551760U).FormatWith(CultureInfo.InvariantCulture, jsonToken));
					}
				}
			}
			this.SetToken(JsonToken.None);
			return null;
		}

		// Token: 0x06001773 RID: 6003 RVA: 0x000733A8 File Offset: 0x000715A8
		internal decimal? ReadAsDecimalInternal()
		{
			this._readType = ReadType.ReadAsDecimal;
			while (this.ReadInternal())
			{
				JsonToken tokenType = this.TokenType;
				if (tokenType != JsonToken.Comment)
				{
					if (tokenType != JsonToken.Integer)
					{
						if (tokenType != JsonToken.Float)
						{
							if (tokenType == JsonToken.Null)
							{
								return null;
							}
							if (tokenType == JsonToken.String)
							{
								string text = (string)this.Value;
								if (JsonReader.smethod_6(text))
								{
									this.SetToken(JsonToken.Null);
									return null;
								}
								decimal num;
								if (decimal.TryParse(text, NumberStyles.Number, this.Culture, out num))
								{
									this.SetToken(JsonToken.Float, num, false);
									return new decimal?(num);
								}
								throw JsonReaderException.Create(this, <Module>.smethod_25<string>(608457602U).FormatWith(JsonReader.smethod_2(), this.Value));
							}
							else
							{
								if (tokenType == JsonToken.EndArray)
								{
									return null;
								}
								throw JsonReaderException.Create(this, <Module>.smethod_25<string>(2000406662U).FormatWith(JsonReader.smethod_2(), tokenType));
							}
						}
					}
					if (!(this.Value is decimal))
					{
						this.SetToken(JsonToken.Float, JsonReader.smethod_5(this.Value, JsonReader.smethod_2()), false);
					}
					return new decimal?((decimal)this.Value);
				}
			}
			this.SetToken(JsonToken.None);
			return null;
		}

		// Token: 0x06001774 RID: 6004 RVA: 0x000734E0 File Offset: 0x000716E0
		internal int? ReadAsInt32Internal()
		{
			this._readType = ReadType.ReadAsInt32;
			while (this.ReadInternal())
			{
				JsonToken tokenType = this.TokenType;
				if (tokenType != JsonToken.Comment)
				{
					if (tokenType != JsonToken.Integer)
					{
						if (tokenType != JsonToken.Float)
						{
							if (tokenType == JsonToken.Null)
							{
								return null;
							}
							if (tokenType == JsonToken.String)
							{
								string text = (string)this.Value;
								if (JsonReader.smethod_6(text))
								{
									this.SetToken(JsonToken.Null);
									return null;
								}
								int num;
								if (int.TryParse(text, NumberStyles.Integer, this.Culture, out num))
								{
									this.SetToken(JsonToken.Integer, num, false);
									return new int?(num);
								}
								throw JsonReaderException.Create(this, <Module>.smethod_24<string>(1668531455U).FormatWith(JsonReader.smethod_2(), this.Value));
							}
							else
							{
								if (tokenType == JsonToken.EndArray)
								{
									return null;
								}
								throw JsonReaderException.Create(this, <Module>.smethod_23<string>(1714488658U).FormatWith(JsonReader.smethod_2(), this.TokenType));
							}
						}
					}
					if (!(this.Value is int))
					{
						this.SetToken(JsonToken.Integer, JsonReader.smethod_7(this.Value, JsonReader.smethod_2()), false);
					}
					return new int?((int)this.Value);
				}
			}
			this.SetToken(JsonToken.None);
			return null;
		}

		// Token: 0x06001775 RID: 6005 RVA: 0x00073620 File Offset: 0x00071820
		internal string ReadAsStringInternal()
		{
			this._readType = ReadType.ReadAsString;
			while (this.ReadInternal())
			{
				JsonToken tokenType = this.TokenType;
				if (tokenType != JsonToken.Comment)
				{
					if (tokenType == JsonToken.String)
					{
						return (string)this.Value;
					}
					if (tokenType == JsonToken.Null)
					{
						return null;
					}
					if (JsonTokenUtils.IsPrimitiveToken(tokenType) && this.Value != null)
					{
						string text;
						if (!(this.Value is IFormattable))
						{
							text = JsonReader.smethod_9(this.Value);
						}
						else
						{
							text = JsonReader.smethod_8((IFormattable)this.Value, null, this.Culture);
						}
						this.SetToken(JsonToken.String, text, false);
						return text;
					}
					if (tokenType == JsonToken.EndArray)
					{
						return null;
					}
					throw JsonReaderException.Create(this, <Module>.smethod_23<string>(2398685543U).FormatWith(JsonReader.smethod_2(), tokenType));
				}
			}
			this.SetToken(JsonToken.None);
			return null;
		}

		// Token: 0x06001776 RID: 6006 RVA: 0x000736E4 File Offset: 0x000718E4
		internal DateTime? ReadAsDateTimeInternal()
		{
			this._readType = ReadType.ReadAsDateTime;
			while (this.ReadInternal())
			{
				if (this.TokenType != JsonToken.Comment)
				{
					if (this.TokenType == JsonToken.Date)
					{
						return new DateTime?((DateTime)this.Value);
					}
					if (this.TokenType == JsonToken.Null)
					{
						return null;
					}
					if (this.TokenType == JsonToken.String)
					{
						string text = (string)this.Value;
						if (JsonReader.smethod_6(text))
						{
							this.SetToken(JsonToken.Null);
							return null;
						}
						object obj;
						DateTime dateTime;
						if (DateTimeUtils.TryParseDateTime(text, DateParseHandling.DateTime, this.DateTimeZoneHandling, this._dateFormatString, this.Culture, out obj))
						{
							dateTime = (DateTime)obj;
							dateTime = DateTimeUtils.EnsureDateTime(dateTime, this.DateTimeZoneHandling);
							this.SetToken(JsonToken.Date, dateTime, false);
							return new DateTime?(dateTime);
						}
						if (DateTime.TryParse(text, this.Culture, DateTimeStyles.RoundtripKind, out dateTime))
						{
							dateTime = DateTimeUtils.EnsureDateTime(dateTime, this.DateTimeZoneHandling);
							this.SetToken(JsonToken.Date, dateTime, false);
							return new DateTime?(dateTime);
						}
						throw JsonReaderException.Create(this, <Module>.smethod_27<string>(635984987U).FormatWith(JsonReader.smethod_2(), this.Value));
					}
					else
					{
						if (this.TokenType == JsonToken.EndArray)
						{
							return null;
						}
						throw JsonReaderException.Create(this, <Module>.smethod_27<string>(1952935471U).FormatWith(JsonReader.smethod_2(), this.TokenType));
					}
				}
			}
			this.SetToken(JsonToken.None);
			return null;
		}

		// Token: 0x06001777 RID: 6007 RVA: 0x00073868 File Offset: 0x00071A68
		private bool IsWrappedInTypeObject()
		{
			this._readType = ReadType.Read;
			if (this.TokenType != JsonToken.StartObject)
			{
				return false;
			}
			if (this.ReadInternal())
			{
				if (JsonReader.smethod_10(JsonReader.smethod_9(this.Value), <Module>.smethod_27<string>(3998518423U)))
				{
					this.ReadInternal();
					if (this.Value != null && JsonReader.smethod_11(JsonReader.smethod_9(this.Value), <Module>.smethod_25<string>(1771539513U), StringComparison.Ordinal))
					{
						this.ReadInternal();
						if (JsonReader.smethod_10(JsonReader.smethod_9(this.Value), <Module>.smethod_24<string>(2163420918U)))
						{
							return true;
						}
					}
				}
				throw JsonReaderException.Create(this, <Module>.smethod_24<string>(4053551760U).FormatWith(JsonReader.smethod_2(), JsonToken.StartObject));
			}
			throw JsonReaderException.Create(this, <Module>.smethod_23<string>(2892993295U));
		}

		// Token: 0x06001778 RID: 6008 RVA: 0x00073934 File Offset: 0x00071B34
		public void Skip()
		{
			if (this.TokenType == JsonToken.PropertyName)
			{
				this.Read();
			}
			if (JsonTokenUtils.IsStartToken(this.TokenType))
			{
				int depth = this.Depth;
				while (this.Read() && depth < this.Depth)
				{
				}
			}
		}

		// Token: 0x06001779 RID: 6009 RVA: 0x00016788 File Offset: 0x00014988
		protected void SetToken(JsonToken newToken)
		{
			this.SetToken(newToken, null, true);
		}

		// Token: 0x0600177A RID: 6010 RVA: 0x00016793 File Offset: 0x00014993
		protected void SetToken(JsonToken newToken, object value)
		{
			this.SetToken(newToken, value, true);
		}

		// Token: 0x0600177B RID: 6011 RVA: 0x00073978 File Offset: 0x00071B78
		internal void SetToken(JsonToken newToken, object value, bool updateIndex)
		{
			this._tokenType = newToken;
			this._value = value;
			switch (newToken)
			{
			case JsonToken.StartObject:
				this._currentState = JsonReader.State.ObjectStart;
				this.Push(JsonContainerType.Object);
				return;
			case JsonToken.StartArray:
				this._currentState = JsonReader.State.ArrayStart;
				this.Push(JsonContainerType.Array);
				return;
			case JsonToken.StartConstructor:
				this._currentState = JsonReader.State.ConstructorStart;
				this.Push(JsonContainerType.Constructor);
				return;
			case JsonToken.PropertyName:
				this._currentState = JsonReader.State.Property;
				this._currentPosition.PropertyName = (string)value;
				return;
			case JsonToken.Comment:
				break;
			case JsonToken.Raw:
			case JsonToken.Integer:
			case JsonToken.Float:
			case JsonToken.String:
			case JsonToken.Boolean:
			case JsonToken.Null:
			case JsonToken.Undefined:
			case JsonToken.Date:
			case JsonToken.Bytes:
				this.SetPostValueState(updateIndex);
				break;
			case JsonToken.EndObject:
				this.ValidateEnd(JsonToken.EndObject);
				return;
			case JsonToken.EndArray:
				this.ValidateEnd(JsonToken.EndArray);
				return;
			case JsonToken.EndConstructor:
				this.ValidateEnd(JsonToken.EndConstructor);
				return;
			default:
				return;
			}
		}

		// Token: 0x0600177C RID: 6012 RVA: 0x0001679E File Offset: 0x0001499E
		internal void SetPostValueState(bool updateIndex)
		{
			if (this.Peek() != JsonContainerType.None)
			{
				this._currentState = JsonReader.State.PostValue;
			}
			else
			{
				this.SetFinished();
			}
			if (updateIndex)
			{
				this.UpdateScopeWithFinishedValue();
			}
		}

		// Token: 0x0600177D RID: 6013 RVA: 0x000167C0 File Offset: 0x000149C0
		private void UpdateScopeWithFinishedValue()
		{
			if (this._currentPosition.HasIndex)
			{
				this._currentPosition.Position = this._currentPosition.Position + 1;
			}
		}

		// Token: 0x0600177E RID: 6014 RVA: 0x00073A4C File Offset: 0x00071C4C
		private void ValidateEnd(JsonToken endToken)
		{
			JsonContainerType jsonContainerType = this.Pop();
			if (this.GetTypeForCloseToken(endToken) != jsonContainerType)
			{
				throw JsonReaderException.Create(this, <Module>.smethod_24<string>(1756941107U).FormatWith(JsonReader.smethod_2(), endToken, jsonContainerType));
			}
			if (this.Peek() != JsonContainerType.None)
			{
				this._currentState = JsonReader.State.PostValue;
				return;
			}
			this.SetFinished();
		}

		// Token: 0x0600177F RID: 6015 RVA: 0x00073AA8 File Offset: 0x00071CA8
		protected void SetStateBasedOnCurrent()
		{
			JsonContainerType jsonContainerType = this.Peek();
			switch (jsonContainerType)
			{
			case JsonContainerType.None:
				this.SetFinished();
				return;
			case JsonContainerType.Object:
				this._currentState = JsonReader.State.Object;
				return;
			case JsonContainerType.Array:
				this._currentState = JsonReader.State.Array;
				return;
			case JsonContainerType.Constructor:
				this._currentState = JsonReader.State.Constructor;
				return;
			default:
				throw JsonReaderException.Create(this, <Module>.smethod_25<string>(3581073291U).FormatWith(JsonReader.smethod_2(), jsonContainerType));
			}
		}

		// Token: 0x06001780 RID: 6016 RVA: 0x000167E2 File Offset: 0x000149E2
		private void SetFinished()
		{
			if (this.SupportMultipleContent)
			{
				this._currentState = JsonReader.State.Start;
				return;
			}
			this._currentState = JsonReader.State.Finished;
		}

		// Token: 0x06001781 RID: 6017 RVA: 0x00073B14 File Offset: 0x00071D14
		private JsonContainerType GetTypeForCloseToken(JsonToken token)
		{
			switch (token)
			{
			case JsonToken.EndObject:
				return JsonContainerType.Object;
			case JsonToken.EndArray:
				return JsonContainerType.Array;
			case JsonToken.EndConstructor:
				return JsonContainerType.Constructor;
			default:
				throw JsonReaderException.Create(this, <Module>.smethod_23<string>(1606744410U).FormatWith(JsonReader.smethod_2(), token));
			}
		}

		// Token: 0x06001782 RID: 6018 RVA: 0x000167FC File Offset: 0x000149FC
		void IDisposable.Dispose()
		{
			this.Dispose(true);
		}

		// Token: 0x06001783 RID: 6019 RVA: 0x00016805 File Offset: 0x00014A05
		protected virtual void Dispose(bool disposing)
		{
			if (this._currentState != JsonReader.State.Closed && disposing)
			{
				this.Close();
			}
		}

		// Token: 0x06001784 RID: 6020 RVA: 0x00016819 File Offset: 0x00014A19
		public virtual void Close()
		{
			this._currentState = JsonReader.State.Closed;
			this._tokenType = JsonToken.None;
			this._value = null;
		}

		// Token: 0x06001785 RID: 6021 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_0(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}

		// Token: 0x06001786 RID: 6022 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_1(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06001787 RID: 6023 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_2()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001788 RID: 6024 RVA: 0x000109B6 File Offset: 0x0000EBB6
		static NotImplementedException smethod_3()
		{
			return new NotImplementedException();
		}

		// Token: 0x06001789 RID: 6025 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_4(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x0600178A RID: 6026 RVA: 0x00016830 File Offset: 0x00014A30
		static decimal smethod_5(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToDecimal(object_0, iformatProvider_0);
		}

		// Token: 0x0600178B RID: 6027 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_6(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x0600178C RID: 6028 RVA: 0x00016839 File Offset: 0x00014A39
		static int smethod_7(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToInt32(object_0, iformatProvider_0);
		}

		// Token: 0x0600178D RID: 6029 RVA: 0x00016842 File Offset: 0x00014A42
		static string smethod_8(IFormattable iformattable_0, string string_0, IFormatProvider iformatProvider_0)
		{
			return iformattable_0.ToString(string_0, iformatProvider_0);
		}

		// Token: 0x0600178E RID: 6030 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_9(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x0600178F RID: 6031 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_10(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06001790 RID: 6032 RVA: 0x0000F8C5 File Offset: 0x0000DAC5
		static bool smethod_11(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.StartsWith(string_1, stringComparison_0);
		}

		// Token: 0x04000926 RID: 2342
		private JsonToken _tokenType;

		// Token: 0x04000927 RID: 2343
		private object _value;

		// Token: 0x04000928 RID: 2344
		internal char _quoteChar;

		// Token: 0x04000929 RID: 2345
		internal JsonReader.State _currentState;

		// Token: 0x0400092A RID: 2346
		internal ReadType _readType;

		// Token: 0x0400092B RID: 2347
		private JsonPosition _currentPosition;

		// Token: 0x0400092C RID: 2348
		private CultureInfo _culture;

		// Token: 0x0400092D RID: 2349
		private DateTimeZoneHandling _dateTimeZoneHandling;

		// Token: 0x0400092E RID: 2350
		private int? _maxDepth;

		// Token: 0x0400092F RID: 2351
		private bool _hasExceededMaxDepth;

		// Token: 0x04000930 RID: 2352
		internal DateParseHandling _dateParseHandling;

		// Token: 0x04000931 RID: 2353
		internal FloatParseHandling _floatParseHandling;

		// Token: 0x04000932 RID: 2354
		private string _dateFormatString;

		// Token: 0x04000933 RID: 2355
		private readonly List<JsonPosition> _stack;

		// Token: 0x0200018E RID: 398
		protected internal enum State
		{
			// Token: 0x04000937 RID: 2359
			Start,
			// Token: 0x04000938 RID: 2360
			Complete,
			// Token: 0x04000939 RID: 2361
			Property,
			// Token: 0x0400093A RID: 2362
			ObjectStart,
			// Token: 0x0400093B RID: 2363
			Object,
			// Token: 0x0400093C RID: 2364
			ArrayStart,
			// Token: 0x0400093D RID: 2365
			Array,
			// Token: 0x0400093E RID: 2366
			Closed,
			// Token: 0x0400093F RID: 2367
			PostValue,
			// Token: 0x04000940 RID: 2368
			ConstructorStart,
			// Token: 0x04000941 RID: 2369
			Constructor,
			// Token: 0x04000942 RID: 2370
			Error,
			// Token: 0x04000943 RID: 2371
			Finished
		}
	}
}
