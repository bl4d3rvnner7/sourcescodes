﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001B5 RID: 437
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Interface, AllowMultiple = false)]
	public sealed class JsonDictionaryAttribute : JsonContainerAttribute
	{
		// Token: 0x0600198E RID: 6542 RVA: 0x000179F3 File Offset: 0x00015BF3
		public JsonDictionaryAttribute()
		{
		}

		// Token: 0x0600198F RID: 6543 RVA: 0x000179FB File Offset: 0x00015BFB
		public JsonDictionaryAttribute(string id)
			: base(id)
		{
		}
	}
}
