﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020002D6 RID: 726
	public enum WriteState
	{
		// Token: 0x04000E70 RID: 3696
		Error,
		// Token: 0x04000E71 RID: 3697
		Closed,
		// Token: 0x04000E72 RID: 3698
		Object,
		// Token: 0x04000E73 RID: 3699
		Array,
		// Token: 0x04000E74 RID: 3700
		Constructor,
		// Token: 0x04000E75 RID: 3701
		Property,
		// Token: 0x04000E76 RID: 3702
		Start
	}
}
