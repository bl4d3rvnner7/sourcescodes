﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.Serialization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001DD RID: 477
	public abstract class JsonContract
	{
		// Token: 0x170003C7 RID: 967
		// (get) Token: 0x06001AB8 RID: 6840 RVA: 0x00018126 File Offset: 0x00016326
		// (set) Token: 0x06001AB9 RID: 6841 RVA: 0x0001812E File Offset: 0x0001632E
		public Type UnderlyingType { get; private set; }

		// Token: 0x170003C8 RID: 968
		// (get) Token: 0x06001ABA RID: 6842 RVA: 0x00018137 File Offset: 0x00016337
		// (set) Token: 0x06001ABB RID: 6843 RVA: 0x0001813F File Offset: 0x0001633F
		public Type CreatedType
		{
			get
			{
				return this._createdType;
			}
			set
			{
				this._createdType = value;
				this.IsSealed = this._createdType.IsSealed();
				this.IsInstantiable = !this._createdType.IsInterface() && !this._createdType.IsAbstract();
			}
		}

		// Token: 0x170003C9 RID: 969
		// (get) Token: 0x06001ABC RID: 6844 RVA: 0x0001817D File Offset: 0x0001637D
		// (set) Token: 0x06001ABD RID: 6845 RVA: 0x00018185 File Offset: 0x00016385
		public bool? IsReference { get; set; }

		// Token: 0x170003CA RID: 970
		// (get) Token: 0x06001ABE RID: 6846 RVA: 0x0001818E File Offset: 0x0001638E
		// (set) Token: 0x06001ABF RID: 6847 RVA: 0x00018196 File Offset: 0x00016396
		public JsonConverter Converter { get; set; }

		// Token: 0x170003CB RID: 971
		// (get) Token: 0x06001AC0 RID: 6848 RVA: 0x0001819F File Offset: 0x0001639F
		// (set) Token: 0x06001AC1 RID: 6849 RVA: 0x000181A7 File Offset: 0x000163A7
		internal JsonConverter InternalConverter { get; set; }

		// Token: 0x170003CC RID: 972
		// (get) Token: 0x06001AC2 RID: 6850 RVA: 0x000181B0 File Offset: 0x000163B0
		public IList<SerializationCallback> OnDeserializedCallbacks
		{
			get
			{
				if (this._onDeserializedCallbacks == null)
				{
					this._onDeserializedCallbacks = new List<SerializationCallback>();
				}
				return this._onDeserializedCallbacks;
			}
		}

		// Token: 0x170003CD RID: 973
		// (get) Token: 0x06001AC3 RID: 6851 RVA: 0x000181CB File Offset: 0x000163CB
		public IList<SerializationCallback> OnDeserializingCallbacks
		{
			get
			{
				if (this._onDeserializingCallbacks == null)
				{
					this._onDeserializingCallbacks = new List<SerializationCallback>();
				}
				return this._onDeserializingCallbacks;
			}
		}

		// Token: 0x170003CE RID: 974
		// (get) Token: 0x06001AC4 RID: 6852 RVA: 0x000181E6 File Offset: 0x000163E6
		public IList<SerializationCallback> OnSerializedCallbacks
		{
			get
			{
				if (this._onSerializedCallbacks == null)
				{
					this._onSerializedCallbacks = new List<SerializationCallback>();
				}
				return this._onSerializedCallbacks;
			}
		}

		// Token: 0x170003CF RID: 975
		// (get) Token: 0x06001AC5 RID: 6853 RVA: 0x00018201 File Offset: 0x00016401
		public IList<SerializationCallback> OnSerializingCallbacks
		{
			get
			{
				if (this._onSerializingCallbacks == null)
				{
					this._onSerializingCallbacks = new List<SerializationCallback>();
				}
				return this._onSerializingCallbacks;
			}
		}

		// Token: 0x170003D0 RID: 976
		// (get) Token: 0x06001AC6 RID: 6854 RVA: 0x0001821C File Offset: 0x0001641C
		public IList<SerializationErrorCallback> OnErrorCallbacks
		{
			get
			{
				if (this._onErrorCallbacks == null)
				{
					this._onErrorCallbacks = new List<SerializationErrorCallback>();
				}
				return this._onErrorCallbacks;
			}
		}

		// Token: 0x170003D1 RID: 977
		// (get) Token: 0x06001AC7 RID: 6855 RVA: 0x00018237 File Offset: 0x00016437
		// (set) Token: 0x06001AC8 RID: 6856 RVA: 0x0001825A File Offset: 0x0001645A
		[Obsolete("This property is obsolete and has been replaced by the OnDeserializedCallbacks collection.")]
		public MethodInfo OnDeserialized
		{
			get
			{
				if (this.OnDeserializedCallbacks.Count <= 0)
				{
					return null;
				}
				return this.OnDeserializedCallbacks[0].Method();
			}
			set
			{
				this.OnDeserializedCallbacks.Clear();
				this.OnDeserializedCallbacks.Add(JsonContract.CreateSerializationCallback(value));
			}
		}

		// Token: 0x170003D2 RID: 978
		// (get) Token: 0x06001AC9 RID: 6857 RVA: 0x00018278 File Offset: 0x00016478
		// (set) Token: 0x06001ACA RID: 6858 RVA: 0x0001829B File Offset: 0x0001649B
		[Obsolete("This property is obsolete and has been replaced by the OnDeserializingCallbacks collection.")]
		public MethodInfo OnDeserializing
		{
			get
			{
				if (this.OnDeserializingCallbacks.Count <= 0)
				{
					return null;
				}
				return this.OnDeserializingCallbacks[0].Method();
			}
			set
			{
				this.OnDeserializingCallbacks.Clear();
				this.OnDeserializingCallbacks.Add(JsonContract.CreateSerializationCallback(value));
			}
		}

		// Token: 0x170003D3 RID: 979
		// (get) Token: 0x06001ACB RID: 6859 RVA: 0x000182B9 File Offset: 0x000164B9
		// (set) Token: 0x06001ACC RID: 6860 RVA: 0x000182DC File Offset: 0x000164DC
		[Obsolete("This property is obsolete and has been replaced by the OnSerializedCallbacks collection.")]
		public MethodInfo OnSerialized
		{
			get
			{
				if (this.OnSerializedCallbacks.Count <= 0)
				{
					return null;
				}
				return this.OnSerializedCallbacks[0].Method();
			}
			set
			{
				this.OnSerializedCallbacks.Clear();
				this.OnSerializedCallbacks.Add(JsonContract.CreateSerializationCallback(value));
			}
		}

		// Token: 0x170003D4 RID: 980
		// (get) Token: 0x06001ACD RID: 6861 RVA: 0x000182FA File Offset: 0x000164FA
		// (set) Token: 0x06001ACE RID: 6862 RVA: 0x0001831D File Offset: 0x0001651D
		[Obsolete("This property is obsolete and has been replaced by the OnSerializingCallbacks collection.")]
		public MethodInfo OnSerializing
		{
			get
			{
				if (this.OnSerializingCallbacks.Count <= 0)
				{
					return null;
				}
				return this.OnSerializingCallbacks[0].Method();
			}
			set
			{
				this.OnSerializingCallbacks.Clear();
				this.OnSerializingCallbacks.Add(JsonContract.CreateSerializationCallback(value));
			}
		}

		// Token: 0x170003D5 RID: 981
		// (get) Token: 0x06001ACF RID: 6863 RVA: 0x0001833B File Offset: 0x0001653B
		// (set) Token: 0x06001AD0 RID: 6864 RVA: 0x0001835E File Offset: 0x0001655E
		[Obsolete("This property is obsolete and has been replaced by the OnErrorCallbacks collection.")]
		public MethodInfo OnError
		{
			get
			{
				if (this.OnErrorCallbacks.Count <= 0)
				{
					return null;
				}
				return this.OnErrorCallbacks[0].Method();
			}
			set
			{
				this.OnErrorCallbacks.Clear();
				this.OnErrorCallbacks.Add(JsonContract.CreateSerializationErrorCallback(value));
			}
		}

		// Token: 0x170003D6 RID: 982
		// (get) Token: 0x06001AD1 RID: 6865 RVA: 0x0001837C File Offset: 0x0001657C
		// (set) Token: 0x06001AD2 RID: 6866 RVA: 0x00018384 File Offset: 0x00016584
		public Func<object> DefaultCreator { get; set; }

		// Token: 0x170003D7 RID: 983
		// (get) Token: 0x06001AD3 RID: 6867 RVA: 0x0001838D File Offset: 0x0001658D
		// (set) Token: 0x06001AD4 RID: 6868 RVA: 0x00018395 File Offset: 0x00016595
		public bool DefaultCreatorNonPublic { get; set; }

		// Token: 0x06001AD5 RID: 6869 RVA: 0x0007AD5C File Offset: 0x00078F5C
		internal JsonContract(Type underlyingType)
		{
			for (;;)
			{
				IL_01CC:
				int num = 1161653987;
				for (;;)
				{
					switch (num ^ 1161653985)
					{
					case 0:
						if (JsonContract.smethod_2(this.NonNullableUnderlyingType, JsonContract.smethod_1(typeof(int).TypeHandle)))
						{
							goto Block_8;
						}
						goto IL_00CF;
					case 1:
						return;
					case 2:
						ValidationUtils.ArgumentNotNull(underlyingType, <Module>.smethod_25<string>(637978190U));
						this.UnderlyingType = underlyingType;
						num = 1161653998;
						continue;
					case 3:
						this.IsEnum = this.NonNullableUnderlyingType.IsEnum();
						num = (JsonContract.smethod_2(this.NonNullableUnderlyingType, JsonContract.smethod_1(typeof(byte[]).TypeHandle)) ? 1161653999 : 1161653985);
						continue;
					case 4:
						this.CreatedType = this.NonNullableUnderlyingType;
						this.IsConvertable = ConvertUtils.IsConvertible(this.NonNullableUnderlyingType);
						num = 1161653986;
						continue;
					case 6:
						goto IL_00CF;
					case 7:
						goto IL_01CC;
					case 8:
						this.InternalReadType = ReadType.ReadAsDateTimeOffset;
						num = 1161653984;
						continue;
					case 9:
						goto IL_0093;
					case 10:
						goto IL_01EC;
					case 11:
						return;
					case 12:
						if (JsonContract.smethod_2(this.NonNullableUnderlyingType, JsonContract.smethod_1(typeof(DateTime).TypeHandle)))
						{
							this.InternalReadType = ReadType.ReadAsDateTime;
							num = 1161653994;
							continue;
						}
						goto IL_0040;
					case 13:
						goto IL_0040;
					case 14:
						goto IL_01F5;
					case 15:
						this.IsNullable = ReflectionUtils.IsNullable(underlyingType);
						this.NonNullableUnderlyingType = ((!this.IsNullable || !ReflectionUtils.IsNullableType(underlyingType)) ? underlyingType : JsonContract.smethod_0(underlyingType));
						num = 1161653989;
						continue;
					}
					goto Block_9;
					IL_0040:
					num = (JsonContract.smethod_2(this.NonNullableUnderlyingType, JsonContract.smethod_1(typeof(DateTimeOffset).TypeHandle)) ? 1161653993 : 1161653988);
					continue;
					IL_0093:
					num = ((!JsonContract.smethod_2(this.NonNullableUnderlyingType, JsonContract.smethod_1(typeof(string).TypeHandle))) ? 1161653997 : 1161653995);
					continue;
					IL_00CF:
					if (JsonContract.smethod_2(this.NonNullableUnderlyingType, JsonContract.smethod_1(typeof(decimal).TypeHandle)))
					{
						goto Block_6;
					}
					goto IL_0093;
				}
			}
			Block_6:
			this.InternalReadType = ReadType.ReadAsDecimal;
			return;
			Block_8:
			this.InternalReadType = ReadType.ReadAsInt32;
			return;
			Block_9:
			this.InternalReadType = ReadType.Read;
			return;
			IL_01EC:
			this.InternalReadType = ReadType.ReadAsString;
			return;
			IL_01F5:
			this.InternalReadType = ReadType.ReadAsBytes;
		}

		// Token: 0x06001AD6 RID: 6870 RVA: 0x0007AF68 File Offset: 0x00079168
		internal void InvokeOnSerializing(object o, StreamingContext context)
		{
			if (this._onSerializingCallbacks != null)
			{
				IEnumerator<SerializationCallback> enumerator = this._onSerializingCallbacks.GetEnumerator();
				try
				{
					while (JsonContract.smethod_3(enumerator))
					{
						SerializationCallback serializationCallback = enumerator.Current;
						serializationCallback(o, context);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						JsonContract.smethod_4(enumerator);
					}
				}
			}
		}

		// Token: 0x06001AD7 RID: 6871 RVA: 0x0007AFC0 File Offset: 0x000791C0
		internal void InvokeOnSerialized(object o, StreamingContext context)
		{
			if (this._onSerializedCallbacks != null)
			{
				IEnumerator<SerializationCallback> enumerator = this._onSerializedCallbacks.GetEnumerator();
				try
				{
					while (JsonContract.smethod_3(enumerator))
					{
						SerializationCallback serializationCallback = enumerator.Current;
						serializationCallback(o, context);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						JsonContract.smethod_4(enumerator);
					}
				}
			}
		}

		// Token: 0x06001AD8 RID: 6872 RVA: 0x0007B018 File Offset: 0x00079218
		internal void InvokeOnDeserializing(object o, StreamingContext context)
		{
			if (this._onDeserializingCallbacks != null)
			{
				IEnumerator<SerializationCallback> enumerator = this._onDeserializingCallbacks.GetEnumerator();
				try
				{
					while (JsonContract.smethod_3(enumerator))
					{
						SerializationCallback serializationCallback = enumerator.Current;
						serializationCallback(o, context);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						JsonContract.smethod_4(enumerator);
					}
				}
			}
		}

		// Token: 0x06001AD9 RID: 6873 RVA: 0x0007B070 File Offset: 0x00079270
		internal void InvokeOnDeserialized(object o, StreamingContext context)
		{
			if (this._onDeserializedCallbacks != null)
			{
				foreach (SerializationCallback serializationCallback in this._onDeserializedCallbacks)
				{
					serializationCallback(o, context);
				}
			}
		}

		// Token: 0x06001ADA RID: 6874 RVA: 0x0007B0D0 File Offset: 0x000792D0
		internal void InvokeOnError(object o, StreamingContext context, ErrorContext errorContext)
		{
			if (this._onErrorCallbacks != null)
			{
				IEnumerator<SerializationErrorCallback> enumerator = this._onErrorCallbacks.GetEnumerator();
				try
				{
					while (JsonContract.smethod_3(enumerator))
					{
						SerializationErrorCallback serializationErrorCallback = enumerator.Current;
						serializationErrorCallback(o, context, errorContext);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						JsonContract.smethod_4(enumerator);
					}
				}
			}
		}

		// Token: 0x06001ADB RID: 6875 RVA: 0x0007B128 File Offset: 0x00079328
		internal static SerializationCallback CreateSerializationCallback(MethodInfo callbackMethodInfo)
		{
			return delegate(object o, StreamingContext context)
			{
				JsonContract.<>c__DisplayClass1.smethod_0(callbackMethodInfo, o, new object[] { context });
			};
		}

		// Token: 0x06001ADC RID: 6876 RVA: 0x0007B150 File Offset: 0x00079350
		internal static SerializationErrorCallback CreateSerializationErrorCallback(MethodInfo callbackMethodInfo)
		{
			return delegate(object o, StreamingContext context, ErrorContext econtext)
			{
				JsonContract.<>c__DisplayClass4.smethod_0(callbackMethodInfo, o, new object[] { context, econtext });
			};
		}

		// Token: 0x06001ADD RID: 6877 RVA: 0x000175B6 File Offset: 0x000157B6
		static Type smethod_0(Type type_0)
		{
			return Nullable.GetUnderlyingType(type_0);
		}

		// Token: 0x06001ADE RID: 6878 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_1(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001ADF RID: 6879 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_2(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x06001AE0 RID: 6880 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_3(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06001AE1 RID: 6881 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_4(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x04000A70 RID: 2672
		internal bool IsNullable;

		// Token: 0x04000A71 RID: 2673
		internal bool IsConvertable;

		// Token: 0x04000A72 RID: 2674
		internal bool IsEnum;

		// Token: 0x04000A73 RID: 2675
		internal Type NonNullableUnderlyingType;

		// Token: 0x04000A74 RID: 2676
		internal ReadType InternalReadType;

		// Token: 0x04000A75 RID: 2677
		internal JsonContractType ContractType;

		// Token: 0x04000A76 RID: 2678
		internal bool IsReadOnlyOrFixedSize;

		// Token: 0x04000A77 RID: 2679
		internal bool IsSealed;

		// Token: 0x04000A78 RID: 2680
		internal bool IsInstantiable;

		// Token: 0x04000A79 RID: 2681
		private List<SerializationCallback> _onDeserializedCallbacks;

		// Token: 0x04000A7A RID: 2682
		private IList<SerializationCallback> _onDeserializingCallbacks;

		// Token: 0x04000A7B RID: 2683
		private IList<SerializationCallback> _onSerializedCallbacks;

		// Token: 0x04000A7C RID: 2684
		private IList<SerializationCallback> _onSerializingCallbacks;

		// Token: 0x04000A7D RID: 2685
		private IList<SerializationErrorCallback> _onErrorCallbacks;

		// Token: 0x04000A7E RID: 2686
		private Type _createdType;
	}
}
