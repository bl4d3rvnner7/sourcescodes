﻿using System;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001DA RID: 474
	public interface IValueProvider
	{
		// Token: 0x06001AAE RID: 6830
		void SetValue(object target, object value);

		// Token: 0x06001AAF RID: 6831
		object GetValue(object target);
	}
}
