﻿using System;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001FA RID: 506
	public class JsonPrimitiveContract : JsonContract
	{
		// Token: 0x17000408 RID: 1032
		// (get) Token: 0x06001CDF RID: 7391 RVA: 0x00019416 File Offset: 0x00017616
		// (set) Token: 0x06001CE0 RID: 7392 RVA: 0x0001941E File Offset: 0x0001761E
		internal PrimitiveTypeCode TypeCode { get; set; }

		// Token: 0x06001CE1 RID: 7393 RVA: 0x00019427 File Offset: 0x00017627
		public JsonPrimitiveContract(Type underlyingType)
			: base(underlyingType)
		{
			this.ContractType = JsonContractType.Primitive;
			this.TypeCode = ConvertUtils.GetTypeCode(underlyingType);
			this.IsReadOnlyOrFixedSize = true;
		}
	}
}
