﻿using System;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x0200029B RID: 667
	// (Invoke) Token: 0x060026F3 RID: 9971
	public delegate object ObjectConstructor<T>(params object[] args);
}
