﻿using System;
using System.Collections.Generic;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001DC RID: 476
	public interface IAttributeProvider
	{
		// Token: 0x06001AB6 RID: 6838
		IList<Attribute> GetAttributes(bool inherit);

		// Token: 0x06001AB7 RID: 6839
		IList<Attribute> GetAttributes(Type attributeType, bool inherit);
	}
}
