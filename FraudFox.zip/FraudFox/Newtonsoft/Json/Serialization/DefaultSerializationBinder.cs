﻿using System;
using System.Globalization;
using System.Reflection;
using System.Runtime.Serialization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x0200025E RID: 606
	public class DefaultSerializationBinder : SerializationBinder
	{
		// Token: 0x06002392 RID: 9106 RVA: 0x0008C8F4 File Offset: 0x0008AAF4
		private static Type GetTypeFromTypeNameKey(DefaultSerializationBinder.TypeNameKey typeNameKey)
		{
			string assemblyName = typeNameKey.AssemblyName;
			string typeName = typeNameKey.TypeName;
			if (assemblyName == null)
			{
				return DefaultSerializationBinder.smethod_9(typeName);
			}
			Assembly assembly = DefaultSerializationBinder.smethod_0(assemblyName);
			if (DefaultSerializationBinder.smethod_1(assembly, null))
			{
				Assembly[] array = DefaultSerializationBinder.smethod_3(DefaultSerializationBinder.smethod_2());
				foreach (Assembly assembly2 in array)
				{
					if (DefaultSerializationBinder.smethod_5(DefaultSerializationBinder.smethod_4(assembly2), assemblyName))
					{
						assembly = assembly2;
						break;
					}
				}
			}
			if (DefaultSerializationBinder.smethod_1(assembly, null))
			{
				throw new JsonSerializationException(<Module>.smethod_23<string>(1482037067U).FormatWith(DefaultSerializationBinder.smethod_6(), assemblyName));
			}
			Type type = DefaultSerializationBinder.smethod_7(assembly, typeName);
			if (DefaultSerializationBinder.smethod_8(type, null))
			{
				throw new JsonSerializationException(<Module>.smethod_25<string>(2893215935U).FormatWith(DefaultSerializationBinder.smethod_6(), typeName, DefaultSerializationBinder.smethod_4(assembly)));
			}
			return type;
		}

		// Token: 0x06002393 RID: 9107 RVA: 0x0001CC3C File Offset: 0x0001AE3C
		public override Type BindToType(string assemblyName, string typeName)
		{
			return this._typeCache.Get(new DefaultSerializationBinder.TypeNameKey(assemblyName, typeName));
		}

		// Token: 0x06002394 RID: 9108 RVA: 0x0001CC50 File Offset: 0x0001AE50
		public override void BindToName(Type serializedType, out string assemblyName, out string typeName)
		{
			assemblyName = DefaultSerializationBinder.smethod_4(DefaultSerializationBinder.smethod_10(serializedType));
			typeName = DefaultSerializationBinder.smethod_11(serializedType);
		}

		// Token: 0x06002397 RID: 9111 RVA: 0x0001CC92 File Offset: 0x0001AE92
		static Assembly smethod_0(string string_0)
		{
			return Assembly.LoadWithPartialName(string_0);
		}

		// Token: 0x06002398 RID: 9112 RVA: 0x0001CC9A File Offset: 0x0001AE9A
		static bool smethod_1(Assembly assembly_0, Assembly assembly_1)
		{
			return assembly_0 == assembly_1;
		}

		// Token: 0x06002399 RID: 9113 RVA: 0x0001CCA3 File Offset: 0x0001AEA3
		static AppDomain smethod_2()
		{
			return AppDomain.CurrentDomain;
		}

		// Token: 0x0600239A RID: 9114 RVA: 0x0001CCAA File Offset: 0x0001AEAA
		static Assembly[] smethod_3(AppDomain appDomain_0)
		{
			return appDomain_0.GetAssemblies();
		}

		// Token: 0x0600239B RID: 9115 RVA: 0x0001CCB2 File Offset: 0x0001AEB2
		static string smethod_4(Assembly assembly_0)
		{
			return assembly_0.FullName;
		}

		// Token: 0x0600239C RID: 9116 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_5(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x0600239D RID: 9117 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_6()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x0600239E RID: 9118 RVA: 0x0001CCBA File Offset: 0x0001AEBA
		static Type smethod_7(Assembly assembly_0, string string_0)
		{
			return assembly_0.GetType(string_0);
		}

		// Token: 0x0600239F RID: 9119 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_8(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x060023A0 RID: 9120 RVA: 0x00017809 File Offset: 0x00015A09
		static Type smethod_9(string string_0)
		{
			return Type.GetType(string_0);
		}

		// Token: 0x060023A1 RID: 9121 RVA: 0x0000DD49 File Offset: 0x0000BF49
		static Assembly smethod_10(Type type_0)
		{
			return type_0.Assembly;
		}

		// Token: 0x060023A2 RID: 9122 RVA: 0x00017761 File Offset: 0x00015961
		static string smethod_11(Type type_0)
		{
			return type_0.FullName;
		}

		// Token: 0x04000C8D RID: 3213
		internal static readonly DefaultSerializationBinder Instance = new DefaultSerializationBinder();

		// Token: 0x04000C8E RID: 3214
		private readonly ThreadSafeStore<DefaultSerializationBinder.TypeNameKey, Type> _typeCache = new ThreadSafeStore<DefaultSerializationBinder.TypeNameKey, Type>(new Func<DefaultSerializationBinder.TypeNameKey, Type>(DefaultSerializationBinder.GetTypeFromTypeNameKey));

		// Token: 0x0200025F RID: 607
		internal struct TypeNameKey : IEquatable<DefaultSerializationBinder.TypeNameKey>
		{
			// Token: 0x060023A3 RID: 9123 RVA: 0x0001CCC3 File Offset: 0x0001AEC3
			public TypeNameKey(string assemblyName, string typeName)
			{
				this.AssemblyName = assemblyName;
				this.TypeName = typeName;
			}

			// Token: 0x060023A4 RID: 9124 RVA: 0x0001CCD3 File Offset: 0x0001AED3
			public override int GetHashCode()
			{
				return ((this.AssemblyName != null) ? DefaultSerializationBinder.TypeNameKey.smethod_0(this.AssemblyName) : 0) ^ ((this.TypeName != null) ? DefaultSerializationBinder.TypeNameKey.smethod_0(this.TypeName) : 0);
			}

			// Token: 0x060023A5 RID: 9125 RVA: 0x0001CD02 File Offset: 0x0001AF02
			public override bool Equals(object obj)
			{
				return obj is DefaultSerializationBinder.TypeNameKey && this.Equals((DefaultSerializationBinder.TypeNameKey)obj);
			}

			// Token: 0x060023A6 RID: 9126 RVA: 0x0001CD1A File Offset: 0x0001AF1A
			public bool Equals(DefaultSerializationBinder.TypeNameKey other)
			{
				return DefaultSerializationBinder.TypeNameKey.smethod_1(this.AssemblyName, other.AssemblyName) && DefaultSerializationBinder.TypeNameKey.smethod_1(this.TypeName, other.TypeName);
			}

			// Token: 0x060023A7 RID: 9127 RVA: 0x0000CF7A File Offset: 0x0000B17A
			static int smethod_0(object object_0)
			{
				return object_0.GetHashCode();
			}

			// Token: 0x060023A8 RID: 9128 RVA: 0x0000CD45 File Offset: 0x0000AF45
			static bool smethod_1(string string_0, string string_1)
			{
				return string_0 == string_1;
			}

			// Token: 0x04000C8F RID: 3215
			internal readonly string AssemblyName;

			// Token: 0x04000C90 RID: 3216
			internal readonly string TypeName;
		}
	}
}
