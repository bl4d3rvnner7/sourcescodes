﻿using System;
using System.Globalization;
using System.IO;
using System.Numerics;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001E5 RID: 485
	internal class TraceJsonWriter : JsonWriter
	{
		// Token: 0x06001B21 RID: 6945 RVA: 0x0007B580 File Offset: 0x00079780
		public TraceJsonWriter(JsonWriter innerWriter)
		{
			this._innerWriter = innerWriter;
			this._sw = TraceJsonWriter.smethod_17(TraceJsonWriter.smethod_16());
			TraceJsonWriter.smethod_20(this._sw, TraceJsonWriter.smethod_19(<Module>.smethod_25<string>(2099524703U), TraceJsonWriter.smethod_18()));
			this._textWriter = new JsonTextWriter(this._sw);
			this._textWriter.Formatting = Formatting.Indented;
			this._textWriter.Culture = innerWriter.Culture;
			this._textWriter.DateFormatHandling = innerWriter.DateFormatHandling;
			this._textWriter.DateFormatString = innerWriter.DateFormatString;
			this._textWriter.DateTimeZoneHandling = innerWriter.DateTimeZoneHandling;
			this._textWriter.FloatFormatHandling = innerWriter.FloatFormatHandling;
		}

		// Token: 0x06001B22 RID: 6946 RVA: 0x0001851C File Offset: 0x0001671C
		public string GetSerializedJsonMessage()
		{
			return TraceJsonWriter.smethod_21(this._sw);
		}

		// Token: 0x06001B23 RID: 6947 RVA: 0x00018529 File Offset: 0x00016729
		public override void WriteValue(decimal value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B24 RID: 6948 RVA: 0x0001854A File Offset: 0x0001674A
		public override void WriteValue(bool value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B25 RID: 6949 RVA: 0x0001856B File Offset: 0x0001676B
		public override void WriteValue(byte value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B26 RID: 6950 RVA: 0x0001858C File Offset: 0x0001678C
		public override void WriteValue(byte? value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B27 RID: 6951 RVA: 0x000185AD File Offset: 0x000167AD
		public override void WriteValue(char value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B28 RID: 6952 RVA: 0x000185CE File Offset: 0x000167CE
		public override void WriteValue(byte[] value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B29 RID: 6953 RVA: 0x000185EF File Offset: 0x000167EF
		public override void WriteValue(DateTime value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B2A RID: 6954 RVA: 0x00018610 File Offset: 0x00016810
		public override void WriteValue(DateTimeOffset value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B2B RID: 6955 RVA: 0x00018631 File Offset: 0x00016831
		public override void WriteValue(double value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B2C RID: 6956 RVA: 0x00018652 File Offset: 0x00016852
		public override void WriteUndefined()
		{
			this._textWriter.WriteUndefined();
			this._innerWriter.WriteUndefined();
			base.WriteUndefined();
		}

		// Token: 0x06001B2D RID: 6957 RVA: 0x00018670 File Offset: 0x00016870
		public override void WriteNull()
		{
			this._textWriter.WriteNull();
			this._innerWriter.WriteNull();
			base.WriteUndefined();
		}

		// Token: 0x06001B2E RID: 6958 RVA: 0x0001868E File Offset: 0x0001688E
		public override void WriteValue(float value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B2F RID: 6959 RVA: 0x000186AF File Offset: 0x000168AF
		public override void WriteValue(Guid value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B30 RID: 6960 RVA: 0x000186D0 File Offset: 0x000168D0
		public override void WriteValue(int value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B31 RID: 6961 RVA: 0x000186F1 File Offset: 0x000168F1
		public override void WriteValue(long value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B32 RID: 6962 RVA: 0x0007B63C File Offset: 0x0007983C
		public override void WriteValue(object value)
		{
			if (value is BigInteger)
			{
				this._textWriter.WriteValue(value);
				this._innerWriter.WriteValue(value);
				base.InternalWriteValue(JsonToken.Integer);
				return;
			}
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B33 RID: 6963 RVA: 0x00018712 File Offset: 0x00016912
		public override void WriteValue(sbyte value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B34 RID: 6964 RVA: 0x00018733 File Offset: 0x00016933
		public override void WriteValue(short value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B35 RID: 6965 RVA: 0x00018754 File Offset: 0x00016954
		public override void WriteValue(string value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B36 RID: 6966 RVA: 0x00018775 File Offset: 0x00016975
		public override void WriteValue(TimeSpan value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B37 RID: 6967 RVA: 0x00018796 File Offset: 0x00016996
		public override void WriteValue(uint value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B38 RID: 6968 RVA: 0x000187B7 File Offset: 0x000169B7
		public override void WriteValue(ulong value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B39 RID: 6969 RVA: 0x000187D8 File Offset: 0x000169D8
		public override void WriteValue(Uri value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B3A RID: 6970 RVA: 0x000187F9 File Offset: 0x000169F9
		public override void WriteValue(ushort value)
		{
			this._textWriter.WriteValue(value);
			this._innerWriter.WriteValue(value);
			base.WriteValue(value);
		}

		// Token: 0x06001B3B RID: 6971 RVA: 0x0001881A File Offset: 0x00016A1A
		public override void WriteWhitespace(string ws)
		{
			this._textWriter.WriteWhitespace(ws);
			this._innerWriter.WriteWhitespace(ws);
			base.WriteWhitespace(ws);
		}

		// Token: 0x06001B3C RID: 6972 RVA: 0x0001883B File Offset: 0x00016A3B
		public override void WriteComment(string text)
		{
			this._textWriter.WriteComment(text);
			this._innerWriter.WriteComment(text);
			base.WriteComment(text);
		}

		// Token: 0x06001B3D RID: 6973 RVA: 0x0001885C File Offset: 0x00016A5C
		public override void WriteStartArray()
		{
			this._textWriter.WriteStartArray();
			this._innerWriter.WriteStartArray();
			base.WriteStartArray();
		}

		// Token: 0x06001B3E RID: 6974 RVA: 0x0001887A File Offset: 0x00016A7A
		public override void WriteEndArray()
		{
			this._textWriter.WriteEndArray();
			this._innerWriter.WriteEndArray();
			base.WriteEndArray();
		}

		// Token: 0x06001B3F RID: 6975 RVA: 0x00018898 File Offset: 0x00016A98
		public override void WriteStartConstructor(string name)
		{
			this._textWriter.WriteStartConstructor(name);
			this._innerWriter.WriteStartConstructor(name);
			base.WriteStartConstructor(name);
		}

		// Token: 0x06001B40 RID: 6976 RVA: 0x000188B9 File Offset: 0x00016AB9
		public override void WriteEndConstructor()
		{
			this._textWriter.WriteEndConstructor();
			this._innerWriter.WriteEndConstructor();
			base.WriteEndConstructor();
		}

		// Token: 0x06001B41 RID: 6977 RVA: 0x000188D7 File Offset: 0x00016AD7
		public override void WritePropertyName(string name)
		{
			this._textWriter.WritePropertyName(name);
			this._innerWriter.WritePropertyName(name);
			base.WritePropertyName(name);
		}

		// Token: 0x06001B42 RID: 6978 RVA: 0x000188F8 File Offset: 0x00016AF8
		public override void WritePropertyName(string name, bool escape)
		{
			this._textWriter.WritePropertyName(name, escape);
			this._innerWriter.WritePropertyName(name, escape);
			base.WritePropertyName(name);
		}

		// Token: 0x06001B43 RID: 6979 RVA: 0x0001891B File Offset: 0x00016B1B
		public override void WriteStartObject()
		{
			this._textWriter.WriteStartObject();
			this._innerWriter.WriteStartObject();
			base.WriteStartObject();
		}

		// Token: 0x06001B44 RID: 6980 RVA: 0x00018939 File Offset: 0x00016B39
		public override void WriteEndObject()
		{
			this._textWriter.WriteEndObject();
			this._innerWriter.WriteEndObject();
			base.WriteEndObject();
		}

		// Token: 0x06001B45 RID: 6981 RVA: 0x00018957 File Offset: 0x00016B57
		public override void WriteRaw(string json)
		{
			this._textWriter.WriteRaw(json);
			this._innerWriter.WriteRaw(json);
			base.WriteRaw(json);
		}

		// Token: 0x06001B46 RID: 6982 RVA: 0x00018978 File Offset: 0x00016B78
		public override void WriteRawValue(string json)
		{
			this._textWriter.WriteRawValue(json);
			this._innerWriter.WriteRawValue(json);
			base.WriteRawValue(json);
		}

		// Token: 0x06001B47 RID: 6983 RVA: 0x00018999 File Offset: 0x00016B99
		public override void Close()
		{
			this._textWriter.Close();
			this._innerWriter.Close();
			base.Close();
		}

		// Token: 0x06001B48 RID: 6984 RVA: 0x000189B7 File Offset: 0x00016BB7
		public override void Flush()
		{
			this._textWriter.Flush();
			this._innerWriter.Flush();
		}

		// Token: 0x06001B49 RID: 6985 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_16()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001B4A RID: 6986 RVA: 0x00016261 File Offset: 0x00014461
		static StringWriter smethod_17(IFormatProvider iformatProvider_0)
		{
			return new StringWriter(iformatProvider_0);
		}

		// Token: 0x06001B4B RID: 6987 RVA: 0x0000CD86 File Offset: 0x0000AF86
		static string smethod_18()
		{
			return Environment.NewLine;
		}

		// Token: 0x06001B4C RID: 6988 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_19(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x06001B4D RID: 6989 RVA: 0x000146E8 File Offset: 0x000128E8
		static void smethod_20(TextWriter textWriter_0, string string_0)
		{
			textWriter_0.Write(string_0);
		}

		// Token: 0x06001B4E RID: 6990 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_21(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x04000A93 RID: 2707
		private readonly JsonWriter _innerWriter;

		// Token: 0x04000A94 RID: 2708
		private readonly JsonTextWriter _textWriter;

		// Token: 0x04000A95 RID: 2709
		private readonly StringWriter _sw;
	}
}
