﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000276 RID: 630
	internal abstract class JsonSerializerInternalBase
	{
		// Token: 0x06002504 RID: 9476 RVA: 0x0001D85A File Offset: 0x0001BA5A
		protected JsonSerializerInternalBase(JsonSerializer serializer)
		{
			ValidationUtils.ArgumentNotNull(serializer, <Module>.smethod_24<string>(1591301575U));
			this.Serializer = serializer;
			this.TraceWriter = serializer.TraceWriter;
		}

		// Token: 0x170005A4 RID: 1444
		// (get) Token: 0x06002505 RID: 9477 RVA: 0x0001D885 File Offset: 0x0001BA85
		internal BidirectionalDictionary<string, object> DefaultReferenceMappings
		{
			get
			{
				if (this._mappings == null)
				{
					this._mappings = new BidirectionalDictionary<string, object>(EqualityComparer<string>.Default, new JsonSerializerInternalBase.ReferenceEqualsEqualityComparer(), <Module>.smethod_26<string>(1820443764U), <Module>.smethod_24<string>(3248211157U));
				}
				return this._mappings;
			}
		}

		// Token: 0x06002506 RID: 9478 RVA: 0x0001D8BE File Offset: 0x0001BABE
		private ErrorContext GetErrorContext(object currentObject, object member, string path, Exception error)
		{
			if (this._currentErrorContext == null)
			{
				this._currentErrorContext = new ErrorContext(currentObject, member, path, error);
			}
			if (this._currentErrorContext.Error != error)
			{
				throw JsonSerializerInternalBase.smethod_0(<Module>.smethod_24<string>(1039501477U));
			}
			return this._currentErrorContext;
		}

		// Token: 0x06002507 RID: 9479 RVA: 0x0001D8FD File Offset: 0x0001BAFD
		protected void ClearErrorContext()
		{
			if (this._currentErrorContext == null)
			{
				throw JsonSerializerInternalBase.smethod_0(<Module>.smethod_26<string>(3526622824U));
			}
			this._currentErrorContext = null;
		}

		// Token: 0x06002508 RID: 9480 RVA: 0x0008F0E8 File Offset: 0x0008D2E8
		protected bool IsErrorHandled(object currentObject, JsonContract contract, object keyValue, IJsonLineInfo lineInfo, string path, Exception ex)
		{
			ErrorContext errorContext = this.GetErrorContext(currentObject, keyValue, path, ex);
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Error && !errorContext.Traced)
			{
				errorContext.Traced = true;
				string text = (JsonSerializerInternalBase.smethod_3(JsonSerializerInternalBase.smethod_1(this), JsonSerializerInternalBase.smethod_2(typeof(JsonSerializerInternalWriter).TypeHandle)) ? <Module>.smethod_26<string>(4279160217U) : <Module>.smethod_23<string>(3419995089U));
				if (contract != null)
				{
					text = JsonSerializerInternalBase.smethod_4(text, <Module>.smethod_26<string>(2342675128U), contract.UnderlyingType);
				}
				text = JsonSerializerInternalBase.smethod_6(text, <Module>.smethod_23<string>(1755715821U), JsonSerializerInternalBase.smethod_5(ex));
				if (!(ex is JsonException))
				{
					text = JsonPosition.FormatMessage(lineInfo, path, text);
				}
				this.TraceWriter.Trace(TraceLevel.Error, text, ex);
			}
			if (contract != null && currentObject != null)
			{
				contract.InvokeOnError(currentObject, this.Serializer.Context, errorContext);
			}
			if (!errorContext.Handled)
			{
				this.Serializer.OnError(new ErrorEventArgs(currentObject, errorContext));
			}
			return errorContext.Handled;
		}

		// Token: 0x06002509 RID: 9481 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_0(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x0600250A RID: 9482 RVA: 0x0001040D File Offset: 0x0000E60D
		static Type smethod_1(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x0600250B RID: 9483 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_2(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x0600250C RID: 9484 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_3(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x0600250D RID: 9485 RVA: 0x00016271 File Offset: 0x00014471
		static string smethod_4(object object_0, object object_1, object object_2)
		{
			return object_0 + object_1 + object_2;
		}

		// Token: 0x0600250E RID: 9486 RVA: 0x0000D3E3 File Offset: 0x0000B5E3
		static string smethod_5(Exception exception_0)
		{
			return exception_0.Message;
		}

		// Token: 0x0600250F RID: 9487 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_6(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x04000D4B RID: 3403
		private ErrorContext _currentErrorContext;

		// Token: 0x04000D4C RID: 3404
		private BidirectionalDictionary<string, object> _mappings;

		// Token: 0x04000D4D RID: 3405
		internal readonly JsonSerializer Serializer;

		// Token: 0x04000D4E RID: 3406
		internal readonly ITraceWriter TraceWriter;

		// Token: 0x04000D4F RID: 3407
		protected JsonSerializerProxy InternalSerializer;

		// Token: 0x02000277 RID: 631
		private class ReferenceEqualsEqualityComparer : IEqualityComparer<object>
		{
			// Token: 0x06002510 RID: 9488 RVA: 0x0001D91E File Offset: 0x0001BB1E
			bool IEqualityComparer<object>.Equals(object x, object y)
			{
				return JsonSerializerInternalBase.ReferenceEqualsEqualityComparer.smethod_0(x, y);
			}

			// Token: 0x06002511 RID: 9489 RVA: 0x0001D927 File Offset: 0x0001BB27
			int IEqualityComparer<object>.GetHashCode(object obj)
			{
				return JsonSerializerInternalBase.ReferenceEqualsEqualityComparer.smethod_1(obj);
			}

			// Token: 0x06002513 RID: 9491 RVA: 0x0000F49D File Offset: 0x0000D69D
			static bool smethod_0(object object_0, object object_1)
			{
				return object.ReferenceEquals(object_0, object_1);
			}

			// Token: 0x06002514 RID: 9492 RVA: 0x0001D92F File Offset: 0x0001BB2F
			static int smethod_1(object object_0)
			{
				return RuntimeHelpers.GetHashCode(object_0);
			}
		}
	}
}
