﻿using System;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x0200025B RID: 603
	public class CamelCasePropertyNamesContractResolver : DefaultContractResolver
	{
		// Token: 0x06002389 RID: 9097 RVA: 0x0001CBAD File Offset: 0x0001ADAD
		public CamelCasePropertyNamesContractResolver()
			: base(true)
		{
		}

		// Token: 0x0600238A RID: 9098 RVA: 0x0001CBB6 File Offset: 0x0001ADB6
		protected override string ResolvePropertyName(string propertyName)
		{
			return StringUtils.ToCamelCase(propertyName);
		}
	}
}
