﻿using System;
using System.Globalization;
using System.Reflection;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001DB RID: 475
	public class ExpressionValueProvider : IValueProvider
	{
		// Token: 0x06001AB0 RID: 6832 RVA: 0x00018107 File Offset: 0x00016307
		public ExpressionValueProvider(MemberInfo memberInfo)
		{
			ValidationUtils.ArgumentNotNull(memberInfo, <Module>.smethod_25<string>(3720340912U));
			this._memberInfo = memberInfo;
		}

		// Token: 0x06001AB1 RID: 6833 RVA: 0x0007AC6C File Offset: 0x00078E6C
		public void SetValue(object target, object value)
		{
			try
			{
				if (this._setter == null)
				{
					this._setter = ExpressionReflectionDelegateFactory.Instance.CreateSet<object>(this._memberInfo);
				}
				this._setter(target, value);
			}
			catch (Exception ex)
			{
				throw new JsonSerializationException(<Module>.smethod_24<string>(1126899354U).FormatWith(ExpressionValueProvider.smethod_0(), ExpressionValueProvider.smethod_1(this._memberInfo), ExpressionValueProvider.smethod_2(target)), ex);
			}
		}

		// Token: 0x06001AB2 RID: 6834 RVA: 0x0007ACE4 File Offset: 0x00078EE4
		public object GetValue(object target)
		{
			object obj;
			try
			{
				if (this._getter == null)
				{
					this._getter = ExpressionReflectionDelegateFactory.Instance.CreateGet<object>(this._memberInfo);
				}
				obj = this._getter(target);
			}
			catch (Exception ex)
			{
				throw new JsonSerializationException(<Module>.smethod_25<string>(3789938365U).FormatWith(ExpressionValueProvider.smethod_0(), ExpressionValueProvider.smethod_1(this._memberInfo), ExpressionValueProvider.smethod_2(target)), ex);
			}
			return obj;
		}

		// Token: 0x06001AB3 RID: 6835 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_0()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001AB4 RID: 6836 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_1(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x06001AB5 RID: 6837 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_2(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x04000A6D RID: 2669
		private readonly MemberInfo _memberInfo;

		// Token: 0x04000A6E RID: 2670
		private Func<object, object> _getter;

		// Token: 0x04000A6F RID: 2671
		private Action<object, object> _setter;
	}
}
