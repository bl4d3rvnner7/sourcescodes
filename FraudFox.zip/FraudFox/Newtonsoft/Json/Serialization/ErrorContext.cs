﻿using System;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000260 RID: 608
	public class ErrorContext
	{
		// Token: 0x060023A9 RID: 9129 RVA: 0x0001CD44 File Offset: 0x0001AF44
		internal ErrorContext(object originalObject, object member, string path, Exception error)
		{
			this.OriginalObject = originalObject;
			this.Member = member;
			this.Error = error;
			this.Path = path;
		}

		// Token: 0x1700053B RID: 1339
		// (get) Token: 0x060023AA RID: 9130 RVA: 0x0001CD69 File Offset: 0x0001AF69
		// (set) Token: 0x060023AB RID: 9131 RVA: 0x0001CD71 File Offset: 0x0001AF71
		internal bool Traced { get; set; }

		// Token: 0x1700053C RID: 1340
		// (get) Token: 0x060023AC RID: 9132 RVA: 0x0001CD7A File Offset: 0x0001AF7A
		// (set) Token: 0x060023AD RID: 9133 RVA: 0x0001CD82 File Offset: 0x0001AF82
		public Exception Error { get; private set; }

		// Token: 0x1700053D RID: 1341
		// (get) Token: 0x060023AE RID: 9134 RVA: 0x0001CD8B File Offset: 0x0001AF8B
		// (set) Token: 0x060023AF RID: 9135 RVA: 0x0001CD93 File Offset: 0x0001AF93
		public object OriginalObject { get; private set; }

		// Token: 0x1700053E RID: 1342
		// (get) Token: 0x060023B0 RID: 9136 RVA: 0x0001CD9C File Offset: 0x0001AF9C
		// (set) Token: 0x060023B1 RID: 9137 RVA: 0x0001CDA4 File Offset: 0x0001AFA4
		public object Member { get; private set; }

		// Token: 0x1700053F RID: 1343
		// (get) Token: 0x060023B2 RID: 9138 RVA: 0x0001CDAD File Offset: 0x0001AFAD
		// (set) Token: 0x060023B3 RID: 9139 RVA: 0x0001CDB5 File Offset: 0x0001AFB5
		public string Path { get; private set; }

		// Token: 0x17000540 RID: 1344
		// (get) Token: 0x060023B4 RID: 9140 RVA: 0x0001CDBE File Offset: 0x0001AFBE
		// (set) Token: 0x060023B5 RID: 9141 RVA: 0x0001CDC6 File Offset: 0x0001AFC6
		public bool Handled { get; set; }
	}
}
