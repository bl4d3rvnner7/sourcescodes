﻿using System;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x0200025C RID: 604
	internal struct ResolverContractKey : IEquatable<ResolverContractKey>
	{
		// Token: 0x0600238B RID: 9099 RVA: 0x0001CBBE File Offset: 0x0001ADBE
		public ResolverContractKey(Type resolverType, Type contractType)
		{
			this._resolverType = resolverType;
			this._contractType = contractType;
		}

		// Token: 0x0600238C RID: 9100 RVA: 0x0001CBCE File Offset: 0x0001ADCE
		public override int GetHashCode()
		{
			return ResolverContractKey.smethod_0(this._resolverType) ^ ResolverContractKey.smethod_0(this._contractType);
		}

		// Token: 0x0600238D RID: 9101 RVA: 0x0001CBE7 File Offset: 0x0001ADE7
		public override bool Equals(object obj)
		{
			return obj is ResolverContractKey && this.Equals((ResolverContractKey)obj);
		}

		// Token: 0x0600238E RID: 9102 RVA: 0x0001CBFF File Offset: 0x0001ADFF
		public bool Equals(ResolverContractKey other)
		{
			return ResolverContractKey.smethod_1(this._resolverType, other._resolverType) && ResolverContractKey.smethod_1(this._contractType, other._contractType);
		}

		// Token: 0x0600238F RID: 9103 RVA: 0x0000CF7A File Offset: 0x0000B17A
		static int smethod_0(object object_0)
		{
			return object_0.GetHashCode();
		}

		// Token: 0x06002390 RID: 9104 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_1(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x04000C89 RID: 3209
		private readonly Type _resolverType;

		// Token: 0x04000C8A RID: 3210
		private readonly Type _contractType;
	}
}
