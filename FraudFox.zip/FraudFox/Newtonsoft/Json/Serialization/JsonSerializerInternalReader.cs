﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic;
using System.Globalization;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Runtime.Serialization;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000278 RID: 632
	internal class JsonSerializerInternalReader : JsonSerializerInternalBase
	{
		// Token: 0x06002515 RID: 9493 RVA: 0x0001D937 File Offset: 0x0001BB37
		public JsonSerializerInternalReader(JsonSerializer serializer)
			: base(serializer)
		{
		}

		// Token: 0x06002516 RID: 9494 RVA: 0x0008F1EC File Offset: 0x0008D3EC
		public void Populate(JsonReader reader, object target)
		{
			ValidationUtils.ArgumentNotNull(target, <Module>.smethod_23<string>(1711199186U));
			Type type = JsonSerializerInternalReader.smethod_7(target);
			JsonContract jsonContract = this.Serializer._contractResolver.ResolveContract(type);
			if (reader.TokenType == JsonToken.None)
			{
				reader.Read();
			}
			if (reader.TokenType == JsonToken.StartArray)
			{
				if (jsonContract.ContractType != JsonContractType.Array)
				{
					throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(1450415588U).FormatWith(JsonSerializerInternalReader.smethod_8(), type));
				}
				JsonArrayContract jsonArrayContract = (JsonArrayContract)jsonContract;
				this.PopulateList(jsonArrayContract.ShouldCreateWrapper ? jsonArrayContract.CreateWrapper(target) : ((IList)target), reader, jsonArrayContract, null, null);
				return;
			}
			else
			{
				if (reader.TokenType != JsonToken.StartObject)
				{
					throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(3639956026U).FormatWith(JsonSerializerInternalReader.smethod_8(), reader.TokenType));
				}
				this.CheckedRead(reader);
				string text = null;
				if (this.Serializer.MetadataPropertyHandling != MetadataPropertyHandling.Ignore && reader.TokenType == JsonToken.PropertyName && JsonSerializerInternalReader.smethod_10(JsonSerializerInternalReader.smethod_9(reader.Value), <Module>.smethod_25<string>(3282608689U), StringComparison.Ordinal))
				{
					this.CheckedRead(reader);
					text = ((reader.Value != null) ? JsonSerializerInternalReader.smethod_9(reader.Value) : null);
					this.CheckedRead(reader);
				}
				if (jsonContract.ContractType == JsonContractType.Dictionary)
				{
					JsonDictionaryContract jsonDictionaryContract = (JsonDictionaryContract)jsonContract;
					this.PopulateDictionary(jsonDictionaryContract.ShouldCreateWrapper ? jsonDictionaryContract.CreateWrapper(target) : ((IDictionary)target), reader, jsonDictionaryContract, null, text);
					return;
				}
				if (jsonContract.ContractType == JsonContractType.Object)
				{
					this.PopulateObject(target, reader, (JsonObjectContract)jsonContract, null, text);
					return;
				}
				throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(3057165590U).FormatWith(JsonSerializerInternalReader.smethod_8(), type));
			}
		}

		// Token: 0x06002517 RID: 9495 RVA: 0x0001D940 File Offset: 0x0001BB40
		private JsonContract GetContractSafe(Type type)
		{
			if (JsonSerializerInternalReader.smethod_11(type, null))
			{
				return null;
			}
			return this.Serializer._contractResolver.ResolveContract(type);
		}

		// Token: 0x06002518 RID: 9496 RVA: 0x0008F38C File Offset: 0x0008D58C
		public object Deserialize(JsonReader reader, Type objectType, bool checkAdditionalContent)
		{
			if (reader == null)
			{
				throw JsonSerializerInternalReader.smethod_12(<Module>.smethod_26<string>(3313616177U));
			}
			JsonContract contractSafe = this.GetContractSafe(objectType);
			object obj;
			try
			{
				JsonConverter converter = this.GetConverter(contractSafe, null, null, null);
				if (reader.TokenType == JsonToken.None && !this.ReadForType(reader, contractSafe, converter != null))
				{
					if (contractSafe != null && !contractSafe.IsNullable)
					{
						throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(3556834466U).FormatWith(JsonSerializerInternalReader.smethod_8(), contractSafe.UnderlyingType));
					}
					obj = null;
				}
				else
				{
					object obj2;
					if (converter != null && converter.CanRead)
					{
						obj2 = this.DeserializeConvertable(converter, reader, objectType, null);
					}
					else
					{
						obj2 = this.CreateValueInternal(reader, objectType, contractSafe, null, null, null, null);
					}
					if (checkAdditionalContent && reader.Read() && reader.TokenType != JsonToken.Comment)
					{
						throw new JsonSerializationException(<Module>.smethod_27<string>(2182898325U));
					}
					obj = obj2;
				}
			}
			catch (Exception ex)
			{
				if (!base.IsErrorHandled(null, contractSafe, null, reader as IJsonLineInfo, reader.Path, ex))
				{
					base.ClearErrorContext();
					throw;
				}
				this.HandleError(reader, false, 0);
				obj = null;
			}
			return obj;
		}

		// Token: 0x06002519 RID: 9497 RVA: 0x0001D95E File Offset: 0x0001BB5E
		private JsonSerializerProxy GetInternalSerializer()
		{
			if (this.InternalSerializer == null)
			{
				this.InternalSerializer = new JsonSerializerProxy(this);
			}
			return this.InternalSerializer;
		}

		// Token: 0x0600251A RID: 9498 RVA: 0x0008F498 File Offset: 0x0008D698
		private JToken CreateJToken(JsonReader reader, JsonContract contract)
		{
			ValidationUtils.ArgumentNotNull(reader, <Module>.smethod_27<string>(3246799795U));
			if (contract != null)
			{
				if (JsonSerializerInternalReader.smethod_11(contract.UnderlyingType, JsonSerializerInternalReader.smethod_13(typeof(JRaw).TypeHandle)))
				{
					return JRaw.Create(reader);
				}
				if (reader.TokenType == JsonToken.Null && !JsonSerializerInternalReader.smethod_11(contract.UnderlyingType, JsonSerializerInternalReader.smethod_13(typeof(JValue).TypeHandle)) && !JsonSerializerInternalReader.smethod_11(contract.UnderlyingType, JsonSerializerInternalReader.smethod_13(typeof(JToken).TypeHandle)))
				{
					return null;
				}
			}
			JTokenWriter jtokenWriter = new JTokenWriter();
			JToken token;
			try
			{
				jtokenWriter.WriteToken(reader);
				token = jtokenWriter.Token;
			}
			finally
			{
				if (jtokenWriter != null)
				{
					JsonSerializerInternalReader.smethod_14(jtokenWriter);
				}
			}
			return token;
		}

		// Token: 0x0600251B RID: 9499 RVA: 0x0008F544 File Offset: 0x0008D744
		private JToken CreateJObject(JsonReader reader)
		{
			ValidationUtils.ArgumentNotNull(reader, <Module>.smethod_24<string>(1458178418U));
			JTokenWriter jtokenWriter = new JTokenWriter();
			JToken token;
			try
			{
				jtokenWriter.WriteStartObject();
				do
				{
					if (reader.TokenType == JsonToken.PropertyName)
					{
						string text = (string)reader.Value;
						while (reader.Read() && reader.TokenType == JsonToken.Comment)
						{
						}
						if (!this.CheckPropertyName(reader, text))
						{
							jtokenWriter.WritePropertyName(text);
							jtokenWriter.WriteToken(reader, true, true);
						}
					}
					else if (reader.TokenType != JsonToken.Comment)
					{
						goto IL_0088;
					}
				}
				while (reader.Read());
				throw JsonSerializationException.Create(reader, <Module>.smethod_26<string>(1316892615U));
				IL_0088:
				jtokenWriter.WriteEndObject();
				token = jtokenWriter.Token;
			}
			finally
			{
				if (jtokenWriter != null)
				{
					JsonSerializerInternalReader.smethod_14(jtokenWriter);
				}
			}
			return token;
		}

		// Token: 0x0600251C RID: 9500 RVA: 0x0008F604 File Offset: 0x0008D804
		private object CreateValueInternal(JsonReader reader, Type objectType, JsonContract contract, JsonProperty member, JsonContainerContract containerContract, JsonProperty containerMember, object existingValue)
		{
			if (contract != null && contract.ContractType == JsonContractType.Linq)
			{
				return this.CreateJToken(reader, contract);
			}
			for (;;)
			{
				switch (reader.TokenType)
				{
				case JsonToken.StartObject:
					goto IL_0078;
				case JsonToken.StartArray:
					goto IL_008A;
				case JsonToken.StartConstructor:
					goto IL_0099;
				case JsonToken.Comment:
					if (reader.Read())
					{
						continue;
					}
					goto IL_00B5;
				case JsonToken.Raw:
					goto IL_00C6;
				case JsonToken.Integer:
				case JsonToken.Float:
				case JsonToken.Boolean:
				case JsonToken.Date:
				case JsonToken.Bytes:
					goto IL_0166;
				case JsonToken.String:
					goto IL_00D7;
				case JsonToken.Null:
				case JsonToken.Undefined:
					goto IL_0118;
				}
				break;
			}
			goto IL_0145;
			IL_0078:
			return this.CreateObject(reader, objectType, contract, member, containerContract, containerMember, existingValue);
			IL_008A:
			return this.CreateList(reader, objectType, contract, member, existingValue, null);
			IL_0099:
			string text = JsonSerializerInternalReader.smethod_9(reader.Value);
			return this.EnsureType(reader, text, JsonSerializerInternalReader.smethod_8(), contract, objectType);
			IL_00B5:
			throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(1430340798U));
			IL_00C6:
			return new JRaw((string)reader.Value);
			IL_00D7:
			string text2 = (string)reader.Value;
			if (JsonSerializerInternalReader.CoerceEmptyStringToNull(objectType, contract, text2))
			{
				return null;
			}
			if (JsonSerializerInternalReader.smethod_11(objectType, JsonSerializerInternalReader.smethod_13(typeof(byte[]).TypeHandle)))
			{
				return JsonSerializerInternalReader.smethod_15(text2);
			}
			return this.EnsureType(reader, text2, JsonSerializerInternalReader.smethod_8(), contract, objectType);
			IL_0118:
			if (JsonSerializerInternalReader.smethod_11(objectType, JsonSerializerInternalReader.smethod_13(typeof(DBNull).TypeHandle)))
			{
				return DBNull.Value;
			}
			return this.EnsureType(reader, reader.Value, JsonSerializerInternalReader.smethod_8(), contract, objectType);
			IL_0145:
			throw JsonSerializationException.Create(reader, JsonSerializerInternalReader.smethod_16(<Module>.smethod_26<string>(1336045403U), reader.TokenType));
			IL_0166:
			return this.EnsureType(reader, reader.Value, JsonSerializerInternalReader.smethod_8(), contract, objectType);
		}

		// Token: 0x0600251D RID: 9501 RVA: 0x0008F78C File Offset: 0x0008D98C
		private static bool CoerceEmptyStringToNull(Type objectType, JsonContract contract, string s)
		{
			return JsonSerializerInternalReader.smethod_17(s) && JsonSerializerInternalReader.smethod_18(objectType, null) && JsonSerializerInternalReader.smethod_18(objectType, JsonSerializerInternalReader.smethod_13(typeof(string).TypeHandle)) && JsonSerializerInternalReader.smethod_18(objectType, JsonSerializerInternalReader.smethod_13(typeof(object).TypeHandle)) && contract != null && contract.IsNullable;
		}

		// Token: 0x0600251E RID: 9502 RVA: 0x0008F7DC File Offset: 0x0008D9DC
		internal string GetExpectedDescription(JsonContract contract)
		{
			switch (contract.ContractType)
			{
			case JsonContractType.Object:
			case JsonContractType.Dictionary:
			case JsonContractType.Dynamic:
			case JsonContractType.Serializable:
				return <Module>.smethod_24<string>(2568883371U);
			case JsonContractType.Array:
				return <Module>.smethod_24<string>(3842181365U);
			case JsonContractType.Primitive:
				return <Module>.smethod_23<string>(2578293672U);
			case JsonContractType.String:
				return <Module>.smethod_27<string>(1048011192U);
			default:
				throw JsonSerializerInternalReader.smethod_19();
			}
		}

		// Token: 0x0600251F RID: 9503 RVA: 0x0008F848 File Offset: 0x0008DA48
		private JsonConverter GetConverter(JsonContract contract, JsonConverter memberConverter, JsonContainerContract containerContract, JsonProperty containerProperty)
		{
			JsonConverter jsonConverter = null;
			if (memberConverter != null)
			{
				jsonConverter = memberConverter;
			}
			else if (containerProperty != null && containerProperty.ItemConverter != null)
			{
				jsonConverter = containerProperty.ItemConverter;
			}
			else if (containerContract != null && containerContract.ItemConverter != null)
			{
				jsonConverter = containerContract.ItemConverter;
			}
			else if (contract != null)
			{
				JsonConverter matchingConverter;
				if (contract.Converter != null)
				{
					jsonConverter = contract.Converter;
				}
				else if ((matchingConverter = this.Serializer.GetMatchingConverter(contract.UnderlyingType)) != null)
				{
					jsonConverter = matchingConverter;
				}
				else if (contract.InternalConverter != null)
				{
					jsonConverter = contract.InternalConverter;
				}
			}
			return jsonConverter;
		}

		// Token: 0x06002520 RID: 9504 RVA: 0x0008F8C8 File Offset: 0x0008DAC8
		private object CreateObject(JsonReader reader, Type objectType, JsonContract contract, JsonProperty member, JsonContainerContract containerContract, JsonProperty containerMember, object existingValue)
		{
			Type type = objectType;
			string text;
			if (this.Serializer.MetadataPropertyHandling != MetadataPropertyHandling.Ignore)
			{
				if (this.Serializer.MetadataPropertyHandling == MetadataPropertyHandling.ReadAhead)
				{
					JTokenReader jtokenReader = reader as JTokenReader;
					if (jtokenReader == null)
					{
						JToken jtoken = JToken.ReadFrom(reader);
						jtokenReader = (JTokenReader)jtoken.CreateReader();
						jtokenReader.Culture = reader.Culture;
						jtokenReader.DateFormatString = reader.DateFormatString;
						jtokenReader.DateParseHandling = reader.DateParseHandling;
						jtokenReader.DateTimeZoneHandling = reader.DateTimeZoneHandling;
						jtokenReader.FloatParseHandling = reader.FloatParseHandling;
						jtokenReader.SupportMultipleContent = reader.SupportMultipleContent;
						this.CheckedRead(jtokenReader);
						reader = jtokenReader;
					}
					object obj;
					if (this.ReadMetadataPropertiesToken(jtokenReader, ref type, ref contract, member, containerContract, containerMember, existingValue, out obj, out text))
					{
						return obj;
					}
				}
				else
				{
					this.CheckedRead(reader);
					object obj2;
					if (this.ReadMetadataProperties(reader, ref type, ref contract, member, containerContract, containerMember, existingValue, out obj2, out text))
					{
						return obj2;
					}
				}
			}
			else
			{
				this.CheckedRead(reader);
				text = null;
			}
			if (this.HasNoDefinedType(contract))
			{
				return this.CreateJObject(reader);
			}
			switch (contract.ContractType)
			{
			case JsonContractType.Object:
			{
				bool flag = false;
				JsonObjectContract jsonObjectContract = (JsonObjectContract)contract;
				object obj3;
				if (existingValue != null && (JsonSerializerInternalReader.smethod_11(type, objectType) || JsonSerializerInternalReader.smethod_20(type, JsonSerializerInternalReader.smethod_7(existingValue))))
				{
					obj3 = existingValue;
				}
				else
				{
					obj3 = this.CreateNewObject(reader, jsonObjectContract, member, containerMember, text, out flag);
				}
				if (flag)
				{
					return obj3;
				}
				return this.PopulateObject(obj3, reader, jsonObjectContract, member, text);
			}
			case JsonContractType.Primitive:
			{
				JsonPrimitiveContract jsonPrimitiveContract = (JsonPrimitiveContract)contract;
				if (this.Serializer.MetadataPropertyHandling != MetadataPropertyHandling.Ignore && reader.TokenType == JsonToken.PropertyName && JsonSerializerInternalReader.smethod_10(JsonSerializerInternalReader.smethod_9(reader.Value), <Module>.smethod_24<string>(2163420918U), StringComparison.Ordinal))
				{
					this.CheckedRead(reader);
					if (reader.TokenType == JsonToken.StartObject)
					{
						throw JsonSerializationException.Create(reader, JsonSerializerInternalReader.smethod_16(<Module>.smethod_26<string>(2752515838U), reader.TokenType));
					}
					object obj4 = this.CreateValueInternal(reader, type, jsonPrimitiveContract, member, null, null, existingValue);
					this.CheckedRead(reader);
					return obj4;
				}
				break;
			}
			case JsonContractType.Dictionary:
			{
				JsonDictionaryContract jsonDictionaryContract = (JsonDictionaryContract)contract;
				object obj5;
				if (existingValue == null)
				{
					bool flag2;
					IDictionary dictionary = this.CreateNewDictionary(reader, jsonDictionaryContract, out flag2);
					if (flag2)
					{
						if (text != null)
						{
							throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(1264427982U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType));
						}
						if (contract.OnSerializingCallbacks.Count > 0)
						{
							throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(2656377042U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType));
						}
						if (contract.OnErrorCallbacks.Count > 0)
						{
							throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(3881304984U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType));
						}
						if (!jsonDictionaryContract.HasParametrizedCreator)
						{
							throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(253772146U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType));
						}
					}
					this.PopulateDictionary(dictionary, reader, jsonDictionaryContract, member, text);
					if (flag2)
					{
						return jsonDictionaryContract.ParametrizedCreator(new object[] { dictionary });
					}
					if (dictionary is IWrappedDictionary)
					{
						return ((IWrappedDictionary)dictionary).UnderlyingDictionary;
					}
					obj5 = dictionary;
				}
				else
				{
					obj5 = this.PopulateDictionary(jsonDictionaryContract.ShouldCreateWrapper ? jsonDictionaryContract.CreateWrapper(existingValue) : ((IDictionary)existingValue), reader, jsonDictionaryContract, member, text);
				}
				return obj5;
			}
			case JsonContractType.Dynamic:
			{
				JsonDynamicContract jsonDynamicContract = (JsonDynamicContract)contract;
				return this.CreateDynamic(reader, jsonDynamicContract, member, text);
			}
			case JsonContractType.Serializable:
			{
				JsonISerializableContract jsonISerializableContract = (JsonISerializableContract)contract;
				return this.CreateISerializable(reader, jsonISerializableContract, member, text);
			}
			}
			string text2 = JsonSerializerInternalReader.smethod_22(<Module>.smethod_24<string>(2999751859U), JsonSerializerInternalReader.smethod_21(), <Module>.smethod_26<string>(2076589597U), JsonSerializerInternalReader.smethod_21());
			text2 = text2.FormatWith(JsonSerializerInternalReader.smethod_8(), type, this.GetExpectedDescription(contract));
			throw JsonSerializationException.Create(reader, text2);
		}

		// Token: 0x06002521 RID: 9505 RVA: 0x0008FC88 File Offset: 0x0008DE88
		private bool ReadMetadataPropertiesToken(JTokenReader reader, ref Type objectType, ref JsonContract contract, JsonProperty member, JsonContainerContract containerContract, JsonProperty containerMember, object existingValue, out object newValue, out string id)
		{
			id = null;
			newValue = null;
			if (reader.TokenType == JsonToken.StartObject)
			{
				JObject jobject = (JObject)reader.CurrentToken;
				JToken jtoken = jobject[<Module>.smethod_27<string>(2500852707U)];
				if (jtoken != null)
				{
					if (jtoken.Type != JTokenType.String && jtoken.Type != JTokenType.Null)
					{
						throw JsonSerializationException.Create(jtoken, jtoken.Path, <Module>.smethod_23<string>(2140428295U).FormatWith(JsonSerializerInternalReader.smethod_8(), <Module>.smethod_25<string>(2099451988U)), null);
					}
					JToken parent = jtoken.Parent;
					JToken jtoken2 = null;
					if (parent.Next != null)
					{
						jtoken2 = parent.Next;
					}
					else if (parent.Previous != null)
					{
						jtoken2 = parent.Previous;
					}
					string text = (string)jtoken;
					if (text != null)
					{
						if (jtoken2 != null)
						{
							throw JsonSerializationException.Create(jtoken2, jtoken2.Path, <Module>.smethod_24<string>(3073426569U).FormatWith(JsonSerializerInternalReader.smethod_8(), <Module>.smethod_27<string>(2500852707U)), null);
						}
						newValue = this.Serializer.GetReferenceResolver().ResolveReference(this, text);
						if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Info)
						{
							this.TraceWriter.Trace(TraceLevel.Info, JsonPosition.FormatMessage(reader, reader.Path, <Module>.smethod_24<string>(1447507325U).FormatWith(JsonSerializerInternalReader.smethod_8(), text, JsonSerializerInternalReader.smethod_7(newValue))), null);
						}
						reader.Skip();
						return true;
					}
				}
				JToken jtoken3 = jobject[<Module>.smethod_27<string>(3998518423U)];
				if (jtoken3 != null)
				{
					string text2 = (string)jtoken3;
					JsonReader jsonReader = jtoken3.CreateReader();
					this.CheckedRead(jsonReader);
					this.ResolveTypeName(jsonReader, ref objectType, ref contract, member, containerContract, containerMember, text2);
					JToken jtoken4 = jobject[<Module>.smethod_27<string>(3625544879U)];
					if (jtoken4 != null)
					{
						for (;;)
						{
							this.CheckedRead(reader);
							if (reader.TokenType == JsonToken.PropertyName && JsonSerializerInternalReader.smethod_23((string)reader.Value, <Module>.smethod_27<string>(3625544879U)))
							{
								break;
							}
							this.CheckedRead(reader);
							reader.Skip();
						}
						return false;
					}
				}
				JToken jtoken5 = jobject[<Module>.smethod_24<string>(3598294595U)];
				if (jtoken5 != null)
				{
					id = (string)jtoken5;
				}
				JToken jtoken6 = jobject[<Module>.smethod_24<string>(1501365886U)];
				if (jtoken6 != null)
				{
					JsonReader jsonReader2 = jtoken6.CreateReader();
					this.CheckedRead(jsonReader2);
					newValue = this.CreateList(jsonReader2, objectType, contract, member, existingValue, id);
					reader.Skip();
					return true;
				}
			}
			this.CheckedRead(reader);
			return false;
		}

		// Token: 0x06002522 RID: 9506 RVA: 0x0008FEE8 File Offset: 0x0008E0E8
		private bool ReadMetadataProperties(JsonReader reader, ref Type objectType, ref JsonContract contract, JsonProperty member, JsonContainerContract containerContract, JsonProperty containerMember, object existingValue, out object newValue, out string id)
		{
			id = null;
			newValue = null;
			if (reader.TokenType == JsonToken.PropertyName)
			{
				string text = JsonSerializerInternalReader.smethod_9(reader.Value);
				if (JsonSerializerInternalReader.smethod_24(text) > 0 && JsonSerializerInternalReader.smethod_25(text, 0) == '$')
				{
					string text3;
					for (;;)
					{
						text = JsonSerializerInternalReader.smethod_9(reader.Value);
						bool flag;
						if (!JsonSerializerInternalReader.smethod_10(text, <Module>.smethod_27<string>(2500852707U), StringComparison.Ordinal))
						{
							if (JsonSerializerInternalReader.smethod_10(text, <Module>.smethod_24<string>(3329001790U), StringComparison.Ordinal))
							{
								this.CheckedRead(reader);
								string text2 = JsonSerializerInternalReader.smethod_9(reader.Value);
								this.ResolveTypeName(reader, ref objectType, ref contract, member, containerContract, containerMember, text2);
								this.CheckedRead(reader);
								flag = true;
							}
							else if (JsonSerializerInternalReader.smethod_10(text, <Module>.smethod_24<string>(3598294595U), StringComparison.Ordinal))
							{
								this.CheckedRead(reader);
								id = ((reader.Value != null) ? JsonSerializerInternalReader.smethod_9(reader.Value) : null);
								this.CheckedRead(reader);
								flag = true;
							}
							else
							{
								if (JsonSerializerInternalReader.smethod_10(text, <Module>.smethod_27<string>(3594889687U), StringComparison.Ordinal))
								{
									goto IL_0161;
								}
								flag = false;
							}
						}
						else
						{
							this.CheckedRead(reader);
							if (reader.TokenType != JsonToken.String && reader.TokenType != JsonToken.Null)
							{
								break;
							}
							text3 = ((reader.Value != null) ? JsonSerializerInternalReader.smethod_9(reader.Value) : null);
							this.CheckedRead(reader);
							if (text3 != null)
							{
								goto IL_01AF;
							}
							flag = true;
						}
						if (!flag || reader.TokenType != JsonToken.PropertyName)
						{
							return false;
						}
					}
					throw JsonSerializationException.Create(reader, <Module>.smethod_26<string>(3035809925U).FormatWith(JsonSerializerInternalReader.smethod_8(), <Module>.smethod_26<string>(475841697U)));
					IL_0161:
					this.CheckedRead(reader);
					object obj = this.CreateList(reader, objectType, contract, member, existingValue, id);
					this.CheckedRead(reader);
					newValue = obj;
					return true;
					IL_01AF:
					if (reader.TokenType == JsonToken.PropertyName)
					{
						throw JsonSerializationException.Create(reader, <Module>.smethod_26<string>(3778770924U).FormatWith(JsonSerializerInternalReader.smethod_8(), <Module>.smethod_27<string>(2500852707U)));
					}
					newValue = this.Serializer.GetReferenceResolver().ResolveReference(this, text3);
					if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Info)
					{
						this.TraceWriter.Trace(TraceLevel.Info, JsonPosition.FormatMessage(reader as IJsonLineInfo, reader.Path, <Module>.smethod_24<string>(1447507325U).FormatWith(JsonSerializerInternalReader.smethod_8(), text3, JsonSerializerInternalReader.smethod_7(newValue))), null);
					}
					return true;
				}
			}
			return false;
		}

		// Token: 0x06002523 RID: 9507 RVA: 0x0009013C File Offset: 0x0008E33C
		private void ResolveTypeName(JsonReader reader, ref Type objectType, ref JsonContract contract, JsonProperty member, JsonContainerContract containerContract, JsonProperty containerMember, string qualifiedTypeName)
		{
			TypeNameHandling? typeNameHandling;
			if (member != null)
			{
				typeNameHandling = member.TypeNameHandling;
				goto IL_0039;
			}
			goto IL_0102;
			int num;
			TypeNameHandling? typeNameHandling2;
			TypeNameHandling typeNameHandling4;
			for (;;)
			{
				IL_00D1:
				TypeNameHandling? typeNameHandling3;
				switch (num ^ 396110954)
				{
				case 0:
					if (typeNameHandling2 == null)
					{
						num = 396110959;
						continue;
					}
					goto IL_00C8;
				case 1:
					typeNameHandling3 = null;
					goto IL_0025;
				case 2:
					goto IL_0102;
				case 3:
					if (typeNameHandling4 != TypeNameHandling.None)
					{
						num = 396110956;
						continue;
					}
					return;
				case 4:
					goto IL_0090;
				case 5:
					if (containerMember == null)
					{
						num = 396110958;
						continue;
					}
					goto IL_0068;
				case 7:
					goto IL_0030;
				case 8:
					if (containerContract == null)
					{
						num = 396110955;
						continue;
					}
					typeNameHandling3 = containerContract.ItemTypeNameHandling;
					goto IL_0025;
				}
				goto Block_8;
				IL_0025:
				typeNameHandling2 = typeNameHandling3;
				num = 396110954;
			}
			IL_0030:
			typeNameHandling = null;
			goto IL_0039;
			IL_0068:
			TypeNameHandling? typeNameHandling5 = containerMember.ItemTypeNameHandling;
			IL_006F:
			TypeNameHandling typeNameHandling6 = typeNameHandling5 ?? this.Serializer._typeNameHandling;
			goto IL_0054;
			IL_0090:
			typeNameHandling5 = null;
			goto IL_006F;
			IL_00C8:
			typeNameHandling6 = typeNameHandling2.GetValueOrDefault();
			goto IL_0054;
			Block_8:
			string text;
			string text2;
			ReflectionUtils.SplitFullyQualifiedTypeName(qualifiedTypeName, out text, out text2);
			Type type;
			try
			{
				type = JsonSerializerInternalReader.smethod_26(this.Serializer._binder, text2, text);
			}
			catch (Exception ex)
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(2508177674U).FormatWith(JsonSerializerInternalReader.smethod_8(), qualifiedTypeName), ex);
			}
			if (JsonSerializerInternalReader.smethod_11(type, null))
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(787456031U).FormatWith(JsonSerializerInternalReader.smethod_8(), qualifiedTypeName));
			}
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Verbose)
			{
				this.TraceWriter.Trace(TraceLevel.Verbose, JsonPosition.FormatMessage(reader as IJsonLineInfo, reader.Path, <Module>.smethod_27<string>(2709077520U).FormatWith(JsonSerializerInternalReader.smethod_8(), qualifiedTypeName, type)), null);
			}
			if (JsonSerializerInternalReader.smethod_18(objectType, null) && JsonSerializerInternalReader.smethod_18(objectType, JsonSerializerInternalReader.smethod_13(typeof(IDynamicMetaObjectProvider).TypeHandle)) && !JsonSerializerInternalReader.smethod_20(objectType, type))
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(2336103976U).FormatWith(JsonSerializerInternalReader.smethod_8(), JsonSerializerInternalReader.smethod_27(type), JsonSerializerInternalReader.smethod_27(objectType)));
			}
			objectType = type;
			contract = this.GetContractSafe(type);
			return;
			IL_0039:
			TypeNameHandling? typeNameHandling7 = typeNameHandling;
			if (typeNameHandling7 == null)
			{
				num = 396110946;
				goto IL_00D1;
			}
			typeNameHandling6 = typeNameHandling7.GetValueOrDefault();
			IL_0054:
			typeNameHandling4 = typeNameHandling6;
			num = 396110953;
			goto IL_00D1;
			IL_0102:
			num = 396110957;
			goto IL_00D1;
		}

		// Token: 0x06002524 RID: 9508 RVA: 0x00090378 File Offset: 0x0008E578
		private JsonArrayContract EnsureArrayContract(JsonReader reader, Type objectType, JsonContract contract)
		{
			if (contract == null)
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(816066767U).FormatWith(JsonSerializerInternalReader.smethod_8(), objectType));
			}
			JsonArrayContract jsonArrayContract = contract as JsonArrayContract;
			if (jsonArrayContract == null)
			{
				string text = JsonSerializerInternalReader.smethod_22(<Module>.smethod_25<string>(2138418374U), JsonSerializerInternalReader.smethod_21(), <Module>.smethod_27<string>(978303339U), JsonSerializerInternalReader.smethod_21());
				text = text.FormatWith(JsonSerializerInternalReader.smethod_8(), objectType, this.GetExpectedDescription(contract));
				throw JsonSerializationException.Create(reader, text);
			}
			return jsonArrayContract;
		}

		// Token: 0x06002525 RID: 9509 RVA: 0x0001D97A File Offset: 0x0001BB7A
		private void CheckedRead(JsonReader reader)
		{
			if (!reader.Read())
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(4208011520U));
			}
		}

		// Token: 0x06002526 RID: 9510 RVA: 0x000903F0 File Offset: 0x0008E5F0
		private object CreateList(JsonReader reader, Type objectType, JsonContract contract, JsonProperty member, object existingValue, string id)
		{
			if (this.HasNoDefinedType(contract))
			{
				return this.CreateJToken(reader, contract);
			}
			JsonArrayContract jsonArrayContract = this.EnsureArrayContract(reader, objectType, contract);
			object obj;
			if (existingValue == null)
			{
				bool flag;
				IList list = this.CreateNewList(reader, jsonArrayContract, out flag);
				if (flag)
				{
					if (id != null)
					{
						throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(497527375U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType));
					}
					if (contract.OnSerializingCallbacks.Count > 0)
					{
						throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(4177597444U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType));
					}
					if (contract.OnErrorCallbacks.Count > 0)
					{
						throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(3501196928U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType));
					}
					if (!jsonArrayContract.HasParametrizedCreator && !jsonArrayContract.IsArray)
					{
						throw JsonSerializationException.Create(reader, <Module>.smethod_26<string>(2727784389U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType));
					}
				}
				if (jsonArrayContract.IsMultidimensionalArray)
				{
					this.PopulateMultidimensionalArray(list, reader, jsonArrayContract, member, id);
				}
				else
				{
					this.PopulateList(list, reader, jsonArrayContract, member, id);
				}
				if (flag)
				{
					if (!jsonArrayContract.IsMultidimensionalArray)
					{
						if (!jsonArrayContract.IsArray)
						{
							return jsonArrayContract.ParametrizedCreator(new object[] { list });
						}
						Array array = JsonSerializerInternalReader.smethod_30(jsonArrayContract.CollectionItemType, JsonSerializerInternalReader.smethod_29(list));
						JsonSerializerInternalReader.smethod_31(list, array, 0);
						list = array;
					}
					else
					{
						list = CollectionUtils.ToMultidimensionalArray(list, jsonArrayContract.CollectionItemType, JsonSerializerInternalReader.smethod_28(contract.CreatedType));
					}
				}
				else if (list is IWrappedCollection)
				{
					return ((IWrappedCollection)list).UnderlyingCollection;
				}
				obj = list;
			}
			else
			{
				if (!jsonArrayContract.CanDeserialize)
				{
					throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(1085232340U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.CreatedType));
				}
				obj = this.PopulateList(jsonArrayContract.ShouldCreateWrapper ? jsonArrayContract.CreateWrapper(existingValue) : ((IList)existingValue), reader, jsonArrayContract, member, id);
			}
			return obj;
		}

		// Token: 0x06002527 RID: 9511 RVA: 0x0001D995 File Offset: 0x0001BB95
		private bool HasNoDefinedType(JsonContract contract)
		{
			return contract == null || JsonSerializerInternalReader.smethod_11(contract.UnderlyingType, JsonSerializerInternalReader.smethod_13(typeof(object).TypeHandle)) || contract.ContractType == JsonContractType.Linq || JsonSerializerInternalReader.smethod_11(contract.UnderlyingType, JsonSerializerInternalReader.smethod_13(typeof(IDynamicMetaObjectProvider).TypeHandle));
		}

		// Token: 0x06002528 RID: 9512 RVA: 0x000905E0 File Offset: 0x0008E7E0
		private object EnsureType(JsonReader reader, object value, CultureInfo culture, JsonContract contract, Type targetType)
		{
			if (JsonSerializerInternalReader.smethod_11(targetType, null))
			{
				return value;
			}
			Type objectType = ReflectionUtils.GetObjectType(value);
			if (!JsonSerializerInternalReader.smethod_18(objectType, targetType))
			{
				return value;
			}
			if (value == null && contract.IsNullable)
			{
				return null;
			}
			object obj;
			try
			{
				if (contract.IsConvertable)
				{
					JsonPrimitiveContract jsonPrimitiveContract = (JsonPrimitiveContract)contract;
					for (;;)
					{
						IL_010E:
						int num = 218405973;
						for (;;)
						{
							switch (num ^ 218405970)
							{
							case 0:
								if (value is string)
								{
									goto Block_10;
								}
								goto IL_00A4;
							case 2:
								goto IL_010E;
							case 3:
								goto IL_00A4;
							case 4:
								goto IL_012B;
							case 5:
								goto IL_012D;
							case 6:
								goto IL_008E;
							case 7:
								num = ((!contract.IsEnum) ? 218405972 : 218405970);
								continue;
							case 8:
								goto IL_012F;
							case 9:
								obj = JsonSerializerInternalReader.smethod_34(value, contract.NonNullableUnderlyingType, culture);
								num = 218405974;
								continue;
							case 10:
								obj = ConvertUtils.FromBigInteger((BigInteger)value, contract.NonNullableUnderlyingType);
								num = 218405975;
								continue;
							}
							goto Block_11;
							IL_008E:
							num = ((!(value is BigInteger)) ? 218405979 : 218405976);
							continue;
							IL_00A4:
							if (!ConvertUtils.IsInteger(jsonPrimitiveContract.TypeCode))
							{
								goto IL_008E;
							}
							obj = JsonSerializerInternalReader.smethod_33(contract.NonNullableUnderlyingType, value);
							num = 218405978;
						}
					}
					Block_10:
					return JsonSerializerInternalReader.smethod_32(contract.NonNullableUnderlyingType, JsonSerializerInternalReader.smethod_9(value), true);
					Block_11:
					goto IL_0131;
					IL_012B:
					IL_012D:
					IL_012F:
					return obj;
				}
				IL_0131:
				obj = ConvertUtils.ConvertOrCast(value, culture, contract.NonNullableUnderlyingType);
			}
			catch (Exception ex)
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(1611626403U).FormatWith(JsonSerializerInternalReader.smethod_8(), MiscellaneousUtils.FormatValueForPrint(value), targetType), ex);
			}
			return obj;
		}

		// Token: 0x06002529 RID: 9513 RVA: 0x00090774 File Offset: 0x0008E974
		private bool SetPropertyValue(JsonProperty property, JsonConverter propertyConverter, JsonContainerContract containerContract, JsonProperty containerProperty, JsonReader reader, object target)
		{
			bool flag;
			object value;
			JsonContract jsonContract;
			bool flag2;
			if (this.CalculatePropertyDetails(property, ref propertyConverter, containerContract, containerProperty, reader, target, out flag, out value, out jsonContract, out flag2))
			{
				return false;
			}
			object obj;
			if (propertyConverter != null && propertyConverter.CanRead)
			{
				if (!flag2 && target != null && property.Readable)
				{
					value = property.ValueProvider.GetValue(target);
				}
				obj = this.DeserializeConvertable(propertyConverter, reader, property.PropertyType, value);
			}
			else
			{
				obj = this.CreateValueInternal(reader, property.PropertyType, jsonContract, property, containerContract, containerProperty, (!flag) ? null : value);
			}
			if ((!flag || obj != value) && this.ShouldSetPropertyValue(property, obj))
			{
				property.ValueProvider.SetValue(target, obj);
				if (property.SetIsSpecified != null)
				{
					if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Verbose)
					{
						this.TraceWriter.Trace(TraceLevel.Verbose, JsonPosition.FormatMessage(reader as IJsonLineInfo, reader.Path, <Module>.smethod_26<string>(2042281754U).FormatWith(JsonSerializerInternalReader.smethod_8(), property.PropertyName, property.DeclaringType)), null);
					}
					property.SetIsSpecified(target, true);
				}
				return true;
			}
			return flag;
		}

		// Token: 0x0600252A RID: 9514 RVA: 0x00090894 File Offset: 0x0008EA94
		private bool CalculatePropertyDetails(JsonProperty property, ref JsonConverter propertyConverter, JsonContainerContract containerContract, JsonProperty containerProperty, JsonReader reader, object target, out bool useExistingValue, out object currentValue, out JsonContract propertyContract, out bool gottenCurrentValue)
		{
			currentValue = null;
			useExistingValue = false;
			propertyContract = null;
			gottenCurrentValue = false;
			if (property.Ignored)
			{
				return true;
			}
			JsonToken tokenType = reader.TokenType;
			if (property.PropertyContract == null)
			{
				property.PropertyContract = this.GetContractSafe(property.PropertyType);
			}
			ObjectCreationHandling valueOrDefault = property.ObjectCreationHandling.GetValueOrDefault(this.Serializer._objectCreationHandling);
			if (valueOrDefault != ObjectCreationHandling.Replace && (tokenType == JsonToken.StartArray || tokenType == JsonToken.StartObject) && property.Readable)
			{
				currentValue = property.ValueProvider.GetValue(target);
				gottenCurrentValue = true;
				if (currentValue != null)
				{
					propertyContract = this.GetContractSafe(JsonSerializerInternalReader.smethod_7(currentValue));
					useExistingValue = !propertyContract.IsReadOnlyOrFixedSize && !propertyContract.UnderlyingType.IsValueType();
				}
			}
			if (!property.Writable && !useExistingValue)
			{
				return true;
			}
			if (property.NullValueHandling.GetValueOrDefault(this.Serializer._nullValueHandling) == NullValueHandling.Ignore && tokenType == JsonToken.Null)
			{
				return true;
			}
			if (this.HasFlag(property.DefaultValueHandling.GetValueOrDefault(this.Serializer._defaultValueHandling), DefaultValueHandling.Ignore) && !this.HasFlag(property.DefaultValueHandling.GetValueOrDefault(this.Serializer._defaultValueHandling), DefaultValueHandling.Populate) && JsonTokenUtils.IsPrimitiveToken(tokenType) && MiscellaneousUtils.ValueEquals(reader.Value, property.GetResolvedDefaultValue()))
			{
				return true;
			}
			if (currentValue == null)
			{
				propertyContract = property.PropertyContract;
			}
			else
			{
				propertyContract = this.GetContractSafe(JsonSerializerInternalReader.smethod_7(currentValue));
				if (propertyContract != property.PropertyContract)
				{
					propertyConverter = this.GetConverter(propertyContract, property.MemberConverter, containerContract, containerProperty);
				}
			}
			return false;
		}

		// Token: 0x0600252B RID: 9515 RVA: 0x00090A30 File Offset: 0x0008EC30
		private void AddReference(JsonReader reader, string id, object value)
		{
			try
			{
				if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Verbose)
				{
					this.TraceWriter.Trace(TraceLevel.Verbose, JsonPosition.FormatMessage(reader as IJsonLineInfo, reader.Path, <Module>.smethod_27<string>(2190017984U).FormatWith(JsonSerializerInternalReader.smethod_8(), id, JsonSerializerInternalReader.smethod_7(value))), null);
				}
				this.Serializer.GetReferenceResolver().AddReference(this, id, value);
			}
			catch (Exception ex)
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(1210962431U).FormatWith(JsonSerializerInternalReader.smethod_8(), id), ex);
			}
		}

		// Token: 0x0600252C RID: 9516 RVA: 0x00017878 File Offset: 0x00015A78
		private bool HasFlag(DefaultValueHandling value, DefaultValueHandling flag)
		{
			return (value & flag) == flag;
		}

		// Token: 0x0600252D RID: 9517 RVA: 0x00090AD0 File Offset: 0x0008ECD0
		private bool ShouldSetPropertyValue(JsonProperty property, object value)
		{
			return (property.NullValueHandling.GetValueOrDefault(this.Serializer._nullValueHandling) != NullValueHandling.Ignore || value != null) && (!this.HasFlag(property.DefaultValueHandling.GetValueOrDefault(this.Serializer._defaultValueHandling), DefaultValueHandling.Ignore) || this.HasFlag(property.DefaultValueHandling.GetValueOrDefault(this.Serializer._defaultValueHandling), DefaultValueHandling.Populate) || !MiscellaneousUtils.ValueEquals(value, property.GetResolvedDefaultValue())) && property.Writable;
		}

		// Token: 0x0600252E RID: 9518 RVA: 0x00090B60 File Offset: 0x0008ED60
		private IList CreateNewList(JsonReader reader, JsonArrayContract contract, out bool createdFromNonDefaultCreator)
		{
			if (!contract.CanDeserialize)
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(961923658U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.CreatedType));
			}
			if (contract.IsReadOnlyOrFixedSize)
			{
				createdFromNonDefaultCreator = true;
				IList list = contract.CreateTemporaryCollection();
				if (contract.ShouldCreateWrapper)
				{
					list = contract.CreateWrapper(list);
				}
				return list;
			}
			if (contract.DefaultCreator != null && (!contract.DefaultCreatorNonPublic || this.Serializer._constructorHandling == ConstructorHandling.AllowNonPublicDefaultConstructor))
			{
				object obj = contract.DefaultCreator();
				if (contract.ShouldCreateWrapper)
				{
					obj = contract.CreateWrapper(obj);
				}
				createdFromNonDefaultCreator = false;
				return (IList)obj;
			}
			if (contract.HasParametrizedCreator)
			{
				createdFromNonDefaultCreator = true;
				return contract.CreateTemporaryCollection();
			}
			if (!contract.IsInstantiable)
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(1710131949U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType));
			}
			throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(3130791682U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType));
		}

		// Token: 0x0600252F RID: 9519 RVA: 0x00090C5C File Offset: 0x0008EE5C
		private IDictionary CreateNewDictionary(JsonReader reader, JsonDictionaryContract contract, out bool createdFromNonDefaultCreator)
		{
			if (contract.IsReadOnlyOrFixedSize)
			{
				createdFromNonDefaultCreator = true;
				return contract.CreateTemporaryDictionary();
			}
			if (contract.DefaultCreator != null && (!contract.DefaultCreatorNonPublic || this.Serializer._constructorHandling == ConstructorHandling.AllowNonPublicDefaultConstructor))
			{
				object obj = contract.DefaultCreator();
				if (contract.ShouldCreateWrapper)
				{
					obj = contract.CreateWrapper(obj);
				}
				createdFromNonDefaultCreator = false;
				return (IDictionary)obj;
			}
			if (contract.HasParametrizedCreator)
			{
				createdFromNonDefaultCreator = true;
				return contract.CreateTemporaryDictionary();
			}
			if (contract.IsInstantiable)
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(2395292924U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType));
			}
			throw JsonSerializationException.Create(reader, <Module>.smethod_26<string>(891533546U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType));
		}

		// Token: 0x06002530 RID: 9520 RVA: 0x00090D20 File Offset: 0x0008EF20
		private void OnDeserializing(JsonReader reader, JsonContract contract, object value)
		{
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Info)
			{
				this.TraceWriter.Trace(TraceLevel.Info, JsonPosition.FormatMessage(reader as IJsonLineInfo, reader.Path, <Module>.smethod_24<string>(1232073081U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType)), null);
			}
			contract.InvokeOnDeserializing(value, this.Serializer._context);
		}

		// Token: 0x06002531 RID: 9521 RVA: 0x00090D90 File Offset: 0x0008EF90
		private void OnDeserialized(JsonReader reader, JsonContract contract, object value)
		{
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Info)
			{
				this.TraceWriter.Trace(TraceLevel.Info, JsonPosition.FormatMessage(reader as IJsonLineInfo, reader.Path, <Module>.smethod_24<string>(188944273U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType)), null);
			}
			contract.InvokeOnDeserialized(value, this.Serializer._context);
		}

		// Token: 0x06002532 RID: 9522 RVA: 0x00090E00 File Offset: 0x0008F000
		private object PopulateDictionary(IDictionary dictionary, JsonReader reader, JsonDictionaryContract contract, JsonProperty containerProperty, string id)
		{
			IWrappedDictionary wrappedDictionary = dictionary as IWrappedDictionary;
			object obj = ((wrappedDictionary != null) ? wrappedDictionary.UnderlyingDictionary : dictionary);
			if (id != null)
			{
				this.AddReference(reader, id, obj);
			}
			this.OnDeserializing(reader, contract, obj);
			int depth = reader.Depth;
			if (contract.KeyContract == null)
			{
				contract.KeyContract = this.GetContractSafe(contract.DictionaryKeyType);
			}
			if (contract.ItemContract == null)
			{
				contract.ItemContract = this.GetContractSafe(contract.DictionaryValueType);
			}
			JsonConverter jsonConverter = contract.ItemConverter ?? this.GetConverter(contract.ItemContract, null, contract, containerProperty);
			PrimitiveTypeCode primitiveTypeCode = ((contract.KeyContract is JsonPrimitiveContract) ? ((JsonPrimitiveContract)contract.KeyContract).TypeCode : PrimitiveTypeCode.Empty);
			bool flag = false;
			for (;;)
			{
				JsonToken tokenType = reader.TokenType;
				switch (tokenType)
				{
				case JsonToken.PropertyName:
				{
					object obj2 = reader.Value;
					if (!this.CheckPropertyName(reader, JsonSerializerInternalReader.smethod_9(obj2)))
					{
						try
						{
							try
							{
								DateParseHandling dateParseHandling;
								switch (primitiveTypeCode)
								{
								case PrimitiveTypeCode.DateTime:
								case PrimitiveTypeCode.DateTimeNullable:
									dateParseHandling = DateParseHandling.DateTime;
									break;
								case PrimitiveTypeCode.DateTimeOffset:
								case PrimitiveTypeCode.DateTimeOffsetNullable:
									dateParseHandling = DateParseHandling.DateTimeOffset;
									break;
								default:
									dateParseHandling = DateParseHandling.None;
									break;
								}
								object obj3;
								if (dateParseHandling != DateParseHandling.None && DateTimeUtils.TryParseDateTime(JsonSerializerInternalReader.smethod_9(obj2), dateParseHandling, reader.DateTimeZoneHandling, reader.DateFormatString, reader.Culture, out obj3))
								{
									obj2 = obj3;
								}
								else
								{
									obj2 = this.EnsureType(reader, obj2, JsonSerializerInternalReader.smethod_8(), contract.KeyContract, contract.DictionaryKeyType);
								}
							}
							catch (Exception ex)
							{
								throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(3082006219U).FormatWith(JsonSerializerInternalReader.smethod_8(), reader.Value, contract.DictionaryKeyType), ex);
							}
							if (!this.ReadForType(reader, contract.ItemContract, jsonConverter != null))
							{
								throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(1430340798U));
							}
							object obj4;
							if (jsonConverter != null && jsonConverter.CanRead)
							{
								obj4 = this.DeserializeConvertable(jsonConverter, reader, contract.DictionaryValueType, null);
							}
							else
							{
								obj4 = this.CreateValueInternal(reader, contract.DictionaryValueType, contract.ItemContract, null, contract, containerProperty, null);
							}
							JsonSerializerInternalReader.smethod_35(dictionary, obj2, obj4);
							break;
						}
						catch (Exception ex2)
						{
							if (base.IsErrorHandled(obj, contract, obj2, reader as IJsonLineInfo, reader.Path, ex2))
							{
								for (;;)
								{
									IL_024F:
									int num = 1661020773;
									for (;;)
									{
										switch (num ^ 1661020772)
										{
										case 1:
											this.HandleError(reader, true, depth);
											num = 1661020775;
											continue;
										case 2:
											goto IL_0256;
										case 3:
											num = 1661020772;
											continue;
										case 4:
											goto IL_024F;
										}
										goto Block_24;
									}
								}
								Block_24:
								break;
							}
							IL_0256:
							throw;
						}
						goto IL_025A;
					}
					break;
				}
				case JsonToken.Comment:
					break;
				default:
					goto IL_025A;
				}
				IL_0265:
				if (flag)
				{
					break;
				}
				if (!reader.Read())
				{
					break;
				}
				continue;
				IL_025A:
				if (tokenType != JsonToken.EndObject)
				{
					goto Block_10;
				}
				flag = true;
				goto IL_0265;
			}
			goto IL_028F;
			Block_10:
			throw JsonSerializationException.Create(reader, JsonSerializerInternalReader.smethod_16(<Module>.smethod_23<string>(1570864043U), reader.TokenType));
			IL_028F:
			if (!flag)
			{
				this.ThrowUnexpectedEndException(reader, contract, obj, <Module>.smethod_24<string>(4208011520U));
			}
			this.OnDeserialized(reader, contract, obj);
			return obj;
		}

		// Token: 0x06002533 RID: 9523 RVA: 0x000910F4 File Offset: 0x0008F2F4
		private object PopulateMultidimensionalArray(IList list, JsonReader reader, JsonArrayContract contract, JsonProperty containerProperty, string id)
		{
			int num = JsonSerializerInternalReader.smethod_28(contract.UnderlyingType);
			if (id != null)
			{
				this.AddReference(reader, id, list);
			}
			this.OnDeserializing(reader, contract, list);
			JsonContract contractSafe = this.GetContractSafe(contract.CollectionItemType);
			JsonConverter converter = this.GetConverter(contractSafe, null, contract, containerProperty);
			int? num2 = null;
			Stack<IList> stack = new Stack<IList>();
			stack.Push(list);
			IList list2 = list;
			bool flag = false;
			for (;;)
			{
				int depth = reader.Depth;
				if (stack.Count == num)
				{
					try
					{
						if (!this.ReadForType(reader, contractSafe, converter != null))
						{
							goto IL_02B3;
						}
						JsonToken tokenType = reader.TokenType;
						if (tokenType != JsonToken.Comment)
						{
							if (tokenType == JsonToken.EndArray)
							{
								stack.Pop();
								list2 = stack.Peek();
								num2 = null;
							}
							else
							{
								object obj;
								if (converter != null && converter.CanRead)
								{
									obj = this.DeserializeConvertable(converter, reader, contract.CollectionItemType, null);
								}
								else
								{
									obj = this.CreateValueInternal(reader, contract.CollectionItemType, contractSafe, null, contract, containerProperty, null);
								}
								JsonSerializerInternalReader.smethod_36(list2, obj);
							}
						}
					}
					catch (Exception ex)
					{
						JsonPosition position = reader.GetPosition(depth);
						if (base.IsErrorHandled(list, contract, position.Position, reader as IJsonLineInfo, reader.Path, ex))
						{
							for (;;)
							{
								IL_0268:
								int num3 = -777505534;
								for (;;)
								{
									bool flag2;
									switch (num3 ^ -777505535)
									{
									case 0:
									{
										int? num4 = num2;
										num3 = -777505536;
										continue;
									}
									case 1:
									{
										int position2 = position.Position;
										num3 = -777505525;
										continue;
									}
									case 2:
										goto IL_0268;
									case 3:
										this.HandleError(reader, true, depth);
										num3 = ((num2 != null) ? (-777505535) : (-777505532));
										continue;
									case 4:
										goto IL_0285;
									case 5:
										IL_01FC:
										num2 = new int?(position.Position);
										num3 = -777505527;
										continue;
									case 6:
										goto IL_0272;
									case 8:
										num3 = -777505530;
										continue;
									case 9:
									{
										int? num4;
										flag2 = num4 != null;
										goto IL_01F3;
									}
									case 10:
									{
										int? num4;
										int position2;
										if (num4.GetValueOrDefault() == position2)
										{
											num3 = -777505528;
											continue;
										}
										flag2 = false;
										goto IL_01F3;
									}
									}
									goto Block_19;
									IL_01F3:
									if (!flag2)
									{
										goto IL_01FC;
									}
									num3 = -777505529;
								}
							}
							Block_19:
							goto IL_0287;
							IL_0272:
							throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(1878774728U), ex);
							IL_0287:
							goto IL_0289;
						}
						IL_0285:
						throw;
					}
				}
				else
				{
					if (!reader.Read())
					{
						goto IL_02B3;
					}
					JsonToken tokenType2 = reader.TokenType;
					if (tokenType2 != JsonToken.StartArray)
					{
						if (tokenType2 != JsonToken.Comment)
						{
							if (tokenType2 != JsonToken.EndArray)
							{
								break;
							}
							stack.Pop();
							if (stack.Count > 0)
							{
								list2 = stack.Peek();
							}
							else
							{
								flag = true;
							}
						}
					}
					else
					{
						IList list3 = new List<object>();
						JsonSerializerInternalReader.smethod_36(list2, list3);
						stack.Push(list3);
						list2 = list3;
					}
				}
				IL_0289:
				if (flag)
				{
					goto Block_9;
				}
			}
			throw JsonSerializationException.Create(reader, JsonSerializerInternalReader.smethod_16(<Module>.smethod_27<string>(1951137979U), reader.TokenType));
			Block_9:
			IL_02B3:
			if (!flag)
			{
				this.ThrowUnexpectedEndException(reader, contract, list, <Module>.smethod_25<string>(3270723788U));
			}
			this.OnDeserialized(reader, contract, list);
			return list;
		}

		// Token: 0x06002534 RID: 9524 RVA: 0x000913F4 File Offset: 0x0008F5F4
		private void ThrowUnexpectedEndException(JsonReader reader, JsonContract contract, object currentObject, string message)
		{
			try
			{
				throw JsonSerializationException.Create(reader, message);
			}
			catch (Exception ex)
			{
				if (base.IsErrorHandled(currentObject, contract, null, reader as IJsonLineInfo, reader.Path, ex))
				{
					for (;;)
					{
						IL_005C:
						int num = -1116294392;
						for (;;)
						{
							switch (num ^ -1116294391)
							{
							case 1:
								this.HandleError(reader, false, 0);
								num = -1116294389;
								continue;
							case 2:
								num = -1116294391;
								continue;
							case 3:
								goto IL_0063;
							case 4:
								goto IL_005C;
							}
							goto Block_4;
						}
					}
					Block_4:
					return;
				}
				IL_0063:
				throw;
			}
		}

		// Token: 0x06002535 RID: 9525 RVA: 0x00091478 File Offset: 0x0008F678
		private object PopulateList(IList list, JsonReader reader, JsonArrayContract contract, JsonProperty containerProperty, string id)
		{
			IWrappedCollection wrappedCollection = list as IWrappedCollection;
			object obj = ((wrappedCollection != null) ? wrappedCollection.UnderlyingCollection : list);
			if (id != null)
			{
				this.AddReference(reader, id, obj);
			}
			if (JsonSerializerInternalReader.smethod_37(list))
			{
				reader.Skip();
				return obj;
			}
			this.OnDeserializing(reader, contract, obj);
			int depth = reader.Depth;
			if (contract.ItemContract == null)
			{
				contract.ItemContract = this.GetContractSafe(contract.CollectionItemType);
			}
			JsonConverter converter = this.GetConverter(contract.ItemContract, null, contract, containerProperty);
			int? num = null;
			bool flag = false;
			do
			{
				try
				{
					if (!this.ReadForType(reader, contract.ItemContract, converter != null))
					{
						break;
					}
					JsonToken tokenType = reader.TokenType;
					if (tokenType != JsonToken.Comment)
					{
						if (tokenType != JsonToken.EndArray)
						{
							object obj2;
							if (converter != null && converter.CanRead)
							{
								obj2 = this.DeserializeConvertable(converter, reader, contract.CollectionItemType, null);
							}
							else
							{
								obj2 = this.CreateValueInternal(reader, contract.CollectionItemType, contract.ItemContract, null, contract, containerProperty, null);
							}
							JsonSerializerInternalReader.smethod_36(list, obj2);
						}
						else
						{
							flag = true;
						}
					}
				}
				catch (Exception ex)
				{
					for (;;)
					{
						IL_01DA:
						int num2 = -2046659350;
						for (;;)
						{
							bool flag2;
							JsonPosition position2;
							switch (num2 ^ -2046659345)
							{
							case 0:
							{
								int? num3;
								flag2 = num3 != null;
								goto IL_01CA;
							}
							case 1:
							{
								if (num == null)
								{
									goto IL_0135;
								}
								int? num3 = num;
								int position = position2.Position;
								if (num3.GetValueOrDefault() == position)
								{
									num2 = -2046659345;
									continue;
								}
								flag2 = false;
								goto IL_01CA;
							}
							case 3:
								goto IL_01F7;
							case 4:
								this.HandleError(reader, true, depth);
								num2 = -2046659346;
								continue;
							case 5:
								position2 = reader.GetPosition(depth);
								num2 = (base.IsErrorHandled(obj, contract, position2.Position, reader as IJsonLineInfo, reader.Path, ex) ? (-2046659349) : (-2046659348));
								continue;
							case 6:
								goto IL_01DA;
							case 7:
								goto IL_0135;
							case 8:
								num2 = -2046659347;
								continue;
							}
							goto Block_13;
							IL_0135:
							num = new int?(position2.Position);
							num2 = -2046659353;
							continue;
							IL_01CA:
							if (flag2)
							{
								goto Block_17;
							}
							goto IL_0135;
						}
					}
					Block_13:
					goto IL_01F9;
					Block_17:
					throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(2137624751U), ex);
					IL_01F7:
					throw;
					IL_01F9:;
				}
			}
			while (!flag);
			if (!flag)
			{
				this.ThrowUnexpectedEndException(reader, contract, obj, <Module>.smethod_25<string>(3270723788U));
			}
			this.OnDeserialized(reader, contract, obj);
			return obj;
		}

		// Token: 0x06002536 RID: 9526 RVA: 0x000916C4 File Offset: 0x0008F8C4
		private object CreateISerializable(JsonReader reader, JsonISerializableContract contract, JsonProperty member, string id)
		{
			Type underlyingType = contract.UnderlyingType;
			if (!JsonTypeReflector.FullyTrusted)
			{
				string text = JsonSerializerInternalReader.smethod_22(<Module>.smethod_26<string>(125422026U), JsonSerializerInternalReader.smethod_21(), <Module>.smethod_24<string>(3338146846U), JsonSerializerInternalReader.smethod_21());
				text = text.FormatWith(JsonSerializerInternalReader.smethod_8(), underlyingType);
				throw JsonSerializationException.Create(reader, text);
			}
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Info)
			{
				this.TraceWriter.Trace(TraceLevel.Info, JsonPosition.FormatMessage(reader as IJsonLineInfo, reader.Path, <Module>.smethod_25<string>(3260022081U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType)), null);
			}
			SerializationInfo serializationInfo = JsonSerializerInternalReader.smethod_38(contract.UnderlyingType, new JsonFormatterConverter(this, contract, member));
			bool flag = false;
			string text2;
			do
			{
				JsonToken tokenType = reader.TokenType;
				switch (tokenType)
				{
				case JsonToken.PropertyName:
					text2 = JsonSerializerInternalReader.smethod_9(reader.Value);
					if (!reader.Read())
					{
						goto IL_012D;
					}
					JsonSerializerInternalReader.smethod_39(serializationInfo, text2, JToken.ReadFrom(reader));
					break;
				case JsonToken.Comment:
					break;
				default:
					if (tokenType != JsonToken.EndObject)
					{
						goto Block_7;
					}
					flag = true;
					break;
				}
				if (flag)
				{
					break;
				}
			}
			while (reader.Read());
			goto IL_014A;
			Block_7:
			throw JsonSerializationException.Create(reader, JsonSerializerInternalReader.smethod_16(<Module>.smethod_23<string>(1570864043U), reader.TokenType));
			IL_012D:
			throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(217808939U).FormatWith(JsonSerializerInternalReader.smethod_8(), text2));
			IL_014A:
			if (!flag)
			{
				this.ThrowUnexpectedEndException(reader, contract, serializationInfo, <Module>.smethod_23<string>(209461805U));
			}
			if (contract.ISerializableCreator != null)
			{
				object obj = contract.ISerializableCreator(new object[]
				{
					serializationInfo,
					this.Serializer._context
				});
				if (id != null)
				{
					this.AddReference(reader, id, obj);
				}
				this.OnDeserializing(reader, contract, obj);
				this.OnDeserialized(reader, contract, obj);
				return obj;
			}
			throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(301742602U).FormatWith(JsonSerializerInternalReader.smethod_8(), underlyingType));
		}

		// Token: 0x06002537 RID: 9527 RVA: 0x000918AC File Offset: 0x0008FAAC
		internal object CreateISerializableItem(JToken token, Type type, JsonISerializableContract contract, JsonProperty member)
		{
			JsonContract contractSafe = this.GetContractSafe(type);
			JsonConverter converter = this.GetConverter(contractSafe, null, contract, member);
			JsonReader jsonReader = token.CreateReader();
			this.CheckedRead(jsonReader);
			object obj;
			if (converter != null && converter.CanRead)
			{
				obj = this.DeserializeConvertable(converter, jsonReader, type, null);
			}
			else
			{
				obj = this.CreateValueInternal(jsonReader, type, contractSafe, null, contract, member, null);
			}
			return obj;
		}

		// Token: 0x06002538 RID: 9528 RVA: 0x00091904 File Offset: 0x0008FB04
		private object CreateDynamic(JsonReader reader, JsonDynamicContract contract, JsonProperty member, string id)
		{
			if (!contract.IsInstantiable)
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(604880422U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType));
			}
			if (contract.DefaultCreator != null && (!contract.DefaultCreatorNonPublic || this.Serializer._constructorHandling == ConstructorHandling.AllowNonPublicDefaultConstructor))
			{
				IDynamicMetaObjectProvider dynamicMetaObjectProvider = (IDynamicMetaObjectProvider)contract.DefaultCreator();
				if (id != null)
				{
					this.AddReference(reader, id, dynamicMetaObjectProvider);
				}
				this.OnDeserializing(reader, contract, dynamicMetaObjectProvider);
				int depth = reader.Depth;
				bool flag = false;
				for (;;)
				{
					JsonToken tokenType = reader.TokenType;
					if (tokenType != JsonToken.PropertyName)
					{
						if (tokenType != JsonToken.EndObject)
						{
							goto Block_8;
						}
						flag = true;
						goto IL_0212;
					}
					else
					{
						string text = JsonSerializerInternalReader.smethod_9(reader.Value);
						try
						{
							if (!reader.Read())
							{
								throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(505244156U).FormatWith(JsonSerializerInternalReader.smethod_8(), text));
							}
							JsonProperty closestMatchProperty = contract.Properties.GetClosestMatchProperty(text);
							if (closestMatchProperty != null && closestMatchProperty.Writable && !closestMatchProperty.Ignored)
							{
								if (closestMatchProperty.PropertyContract == null)
								{
									closestMatchProperty.PropertyContract = this.GetContractSafe(closestMatchProperty.PropertyType);
								}
								JsonConverter converter = this.GetConverter(closestMatchProperty.PropertyContract, closestMatchProperty.MemberConverter, null, null);
								if (!this.SetPropertyValue(closestMatchProperty, converter, null, member, reader, dynamicMetaObjectProvider))
								{
									reader.Skip();
								}
							}
							else
							{
								Type type = (JsonTokenUtils.IsPrimitiveToken(reader.TokenType) ? reader.ValueType : JsonSerializerInternalReader.smethod_13(typeof(IDynamicMetaObjectProvider).TypeHandle));
								JsonContract contractSafe = this.GetContractSafe(type);
								JsonConverter converter2 = this.GetConverter(contractSafe, null, null, member);
								object obj;
								if (converter2 != null && converter2.CanRead)
								{
									obj = this.DeserializeConvertable(converter2, reader, type, null);
								}
								else
								{
									obj = this.CreateValueInternal(reader, type, contractSafe, null, null, member, null);
								}
								contract.TrySetMember(dynamicMetaObjectProvider, text, obj);
							}
							goto IL_0212;
						}
						catch (Exception ex)
						{
							for (;;)
							{
								IL_01F1:
								int num = -941248267;
								for (;;)
								{
									switch (num ^ -941248266)
									{
									case 0:
										goto IL_01F1;
									case 1:
										goto IL_01F8;
									case 3:
										if (base.IsErrorHandled(dynamicMetaObjectProvider, contract, text, reader as IJsonLineInfo, reader.Path, ex))
										{
											this.HandleError(reader, true, depth);
											num = -941248268;
											continue;
										}
										goto IL_01F8;
									}
									goto Block_22;
								}
							}
							Block_22:
							goto IL_01FA;
							IL_01F8:
							throw;
							IL_01FA:
							goto IL_0212;
						}
					}
					IL_01FC:
					if (!reader.Read())
					{
						break;
					}
					continue;
					IL_0212:
					if (!flag)
					{
						goto IL_01FC;
					}
					break;
				}
				goto IL_0238;
				Block_8:
				throw JsonSerializationException.Create(reader, JsonSerializerInternalReader.smethod_16(<Module>.smethod_23<string>(1570864043U), reader.TokenType));
				IL_0238:
				if (!flag)
				{
					this.ThrowUnexpectedEndException(reader, contract, dynamicMetaObjectProvider, <Module>.smethod_23<string>(209461805U));
				}
				this.OnDeserialized(reader, contract, dynamicMetaObjectProvider);
				return dynamicMetaObjectProvider;
			}
			throw JsonSerializationException.Create(reader, <Module>.smethod_26<string>(3623967692U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType));
		}

		// Token: 0x06002539 RID: 9529 RVA: 0x00091BA8 File Offset: 0x0008FDA8
		private object CreateObjectUsingCreatorWithParameters(JsonReader reader, JsonObjectContract contract, JsonProperty containerProperty, ObjectConstructor<object> creator, string id)
		{
			ValidationUtils.ArgumentNotNull(creator, <Module>.smethod_23<string>(3221469688U));
			Dictionary<JsonProperty, JsonSerializerInternalReader.PropertyPresence> dictionary;
			if (!contract.HasRequiredOrDefaultValueProperties && !this.HasFlag(this.Serializer._defaultValueHandling, DefaultValueHandling.Populate))
			{
				dictionary = null;
			}
			else
			{
				dictionary = contract.Properties.ToDictionary((JsonProperty m) => m, (JsonProperty m) => JsonSerializerInternalReader.PropertyPresence.None);
			}
			Dictionary<JsonProperty, JsonSerializerInternalReader.PropertyPresence> dictionary2 = dictionary;
			Type underlyingType = contract.UnderlyingType;
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Info)
			{
				string text = JsonSerializerInternalReader.smethod_40(<Module>.smethod_23<string>(4214096693U), contract.CreatorParameters.Select((JsonProperty p) => p.PropertyName).ToArray<string>());
				this.TraceWriter.Trace(TraceLevel.Info, JsonPosition.FormatMessage(reader as IJsonLineInfo, reader.Path, <Module>.smethod_24<string>(2186283558U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType, text)), null);
			}
			IDictionary<string, object> dictionary4;
			IDictionary<JsonProperty, object> dictionary3 = this.ResolvePropertyAndCreatorValues(contract, containerProperty, reader, underlyingType, out dictionary4);
			object[] array = new object[contract.CreatorParameters.Count];
			IDictionary<JsonProperty, object> dictionary5 = new Dictionary<JsonProperty, object>();
			IEnumerator<KeyValuePair<JsonProperty, object>> enumerator = dictionary3.GetEnumerator();
			try
			{
				while (JsonSerializerInternalReader.smethod_41(enumerator))
				{
					KeyValuePair<JsonProperty, object> keyValuePair = enumerator.Current;
					JsonProperty key = keyValuePair.Key;
					JsonProperty jsonProperty;
					if (!contract.CreatorParameters.Contains(key))
					{
						jsonProperty = contract.CreatorParameters.ForgivingCaseSensitiveFind((JsonProperty p) => p.PropertyName, key.UnderlyingName);
					}
					else
					{
						jsonProperty = key;
					}
					if (jsonProperty == null)
					{
						dictionary5.Add(keyValuePair);
					}
					else
					{
						int num = contract.CreatorParameters.IndexOf(jsonProperty);
						array[num] = keyValuePair.Value;
					}
					if (dictionary2 != null)
					{
						JsonProperty jsonProperty2 = dictionary2.Keys.ForgivingCaseSensitiveFind((JsonProperty p) => p.PropertyName, key.PropertyName);
						if (jsonProperty2 != null)
						{
							object value = keyValuePair.Value;
							JsonSerializerInternalReader.PropertyPresence propertyPresence;
							if (value != null)
							{
								if (!(value is string))
								{
									propertyPresence = JsonSerializerInternalReader.PropertyPresence.Value;
								}
								else
								{
									propertyPresence = (JsonSerializerInternalReader.CoerceEmptyStringToNull(key.PropertyType, key.PropertyContract, (string)value) ? JsonSerializerInternalReader.PropertyPresence.Null : JsonSerializerInternalReader.PropertyPresence.Value);
								}
							}
							else
							{
								propertyPresence = JsonSerializerInternalReader.PropertyPresence.Null;
							}
							dictionary2[jsonProperty2] = propertyPresence;
						}
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JsonSerializerInternalReader.smethod_14(enumerator);
				}
			}
			if (dictionary2 != null)
			{
				foreach (KeyValuePair<JsonProperty, JsonSerializerInternalReader.PropertyPresence> keyValuePair2 in dictionary2)
				{
					JsonProperty property = keyValuePair2.Key;
					JsonSerializerInternalReader.PropertyPresence value2 = keyValuePair2.Value;
					if (!property.Ignored)
					{
						if (value2 == JsonSerializerInternalReader.PropertyPresence.None || value2 == JsonSerializerInternalReader.PropertyPresence.Null)
						{
							if (property.PropertyContract == null)
							{
								property.PropertyContract = this.GetContractSafe(property.PropertyType);
							}
							if (this.HasFlag(property.DefaultValueHandling.GetValueOrDefault(this.Serializer._defaultValueHandling), DefaultValueHandling.Populate))
							{
								int num2 = contract.CreatorParameters.IndexOf((JsonProperty p) => JsonSerializerInternalReader.<>c__DisplayClassc.smethod_0(p.PropertyName, property.PropertyName));
								if (num2 != -1)
								{
									array[num2] = this.EnsureType(reader, property.GetResolvedDefaultValue(), JsonSerializerInternalReader.smethod_8(), property.PropertyContract, property.PropertyType);
								}
							}
						}
					}
				}
			}
			object obj = creator(array);
			if (id != null)
			{
				this.AddReference(reader, id, obj);
			}
			this.OnDeserializing(reader, contract, obj);
			foreach (KeyValuePair<JsonProperty, object> keyValuePair3 in dictionary5)
			{
				JsonProperty key2 = keyValuePair3.Key;
				object value3 = keyValuePair3.Value;
				if (this.ShouldSetPropertyValue(key2, value3))
				{
					key2.ValueProvider.SetValue(obj, value3);
				}
				else if (!key2.Writable && value3 != null)
				{
					JsonContract jsonContract = this.Serializer._contractResolver.ResolveContract(key2.PropertyType);
					if (jsonContract.ContractType == JsonContractType.Array)
					{
						JsonArrayContract jsonArrayContract = (JsonArrayContract)jsonContract;
						object value4 = key2.ValueProvider.GetValue(obj);
						if (value4 == null)
						{
							continue;
						}
						IWrappedCollection wrappedCollection = jsonArrayContract.CreateWrapper(value4);
						IWrappedCollection wrappedCollection2 = jsonArrayContract.CreateWrapper(value3);
						IEnumerator enumerator4 = JsonSerializerInternalReader.smethod_42(wrappedCollection2);
						try
						{
							while (JsonSerializerInternalReader.smethod_41(enumerator4))
							{
								object obj2 = JsonSerializerInternalReader.smethod_43(enumerator4);
								JsonSerializerInternalReader.smethod_36(wrappedCollection, obj2);
							}
							continue;
						}
						finally
						{
							IDisposable disposable = enumerator4 as IDisposable;
							if (disposable != null)
							{
								JsonSerializerInternalReader.smethod_14(disposable);
							}
						}
					}
					if (jsonContract.ContractType == JsonContractType.Dictionary)
					{
						JsonDictionaryContract jsonDictionaryContract = (JsonDictionaryContract)jsonContract;
						object value5 = key2.ValueProvider.GetValue(obj);
						if (value5 != null)
						{
							IDictionary dictionary6 = (jsonDictionaryContract.ShouldCreateWrapper ? jsonDictionaryContract.CreateWrapper(value5) : ((IDictionary)value5));
							IDictionary dictionary7 = (jsonDictionaryContract.ShouldCreateWrapper ? jsonDictionaryContract.CreateWrapper(value3) : ((IDictionary)value3));
							using (IDictionaryEnumerator dictionaryEnumerator = JsonSerializerInternalReader.smethod_44(dictionary7))
							{
								while (dictionaryEnumerator.MoveNext())
								{
									DictionaryEntry dictionaryEntry = (DictionaryEntry)JsonSerializerInternalReader.smethod_43(dictionaryEnumerator);
									dictionary6.Add(dictionaryEntry.Key, dictionaryEntry.Value);
								}
							}
						}
					}
				}
			}
			if (dictionary4 != null)
			{
				foreach (KeyValuePair<string, object> keyValuePair4 in dictionary4)
				{
					contract.ExtensionDataSetter(obj, keyValuePair4.Key, keyValuePair4.Value);
				}
			}
			this.EndObject(obj, reader, contract, reader.Depth, dictionary2);
			this.OnDeserialized(reader, contract, obj);
			return obj;
		}

		// Token: 0x0600253A RID: 9530 RVA: 0x00092230 File Offset: 0x00090430
		private object DeserializeConvertable(JsonConverter converter, JsonReader reader, Type objectType, object existingValue)
		{
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Info)
			{
				this.TraceWriter.Trace(TraceLevel.Info, JsonPosition.FormatMessage(reader as IJsonLineInfo, reader.Path, <Module>.smethod_23<string>(435128158U).FormatWith(JsonSerializerInternalReader.smethod_8(), objectType, JsonSerializerInternalReader.smethod_7(converter))), null);
			}
			object obj = converter.ReadJson(reader, objectType, existingValue, this.GetInternalSerializer());
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Info)
			{
				this.TraceWriter.Trace(TraceLevel.Info, JsonPosition.FormatMessage(reader as IJsonLineInfo, reader.Path, <Module>.smethod_26<string>(1829184281U).FormatWith(JsonSerializerInternalReader.smethod_8(), objectType, JsonSerializerInternalReader.smethod_7(converter))), null);
			}
			return obj;
		}

		// Token: 0x0600253B RID: 9531 RVA: 0x000922F0 File Offset: 0x000904F0
		private IDictionary<JsonProperty, object> ResolvePropertyAndCreatorValues(JsonObjectContract contract, JsonProperty containerProperty, JsonReader reader, Type objectType, out IDictionary<string, object> extensionData)
		{
			extensionData = ((contract.ExtensionDataSetter != null) ? new Dictionary<string, object>() : null);
			IDictionary<JsonProperty, object> dictionary = new Dictionary<JsonProperty, object>();
			bool flag = false;
			string text;
			do
			{
				JsonToken tokenType = reader.TokenType;
				switch (tokenType)
				{
				case JsonToken.PropertyName:
				{
					text = JsonSerializerInternalReader.smethod_9(reader.Value);
					JsonProperty jsonProperty = contract.CreatorParameters.GetClosestMatchProperty(text) ?? contract.Properties.GetClosestMatchProperty(text);
					if (jsonProperty != null)
					{
						if (jsonProperty.PropertyContract == null)
						{
							jsonProperty.PropertyContract = this.GetContractSafe(jsonProperty.PropertyType);
						}
						JsonConverter converter = this.GetConverter(jsonProperty.PropertyContract, jsonProperty.MemberConverter, contract, containerProperty);
						if (!this.ReadForType(reader, jsonProperty.PropertyContract, converter != null))
						{
							goto IL_01F4;
						}
						if (!jsonProperty.Ignored)
						{
							object obj;
							if (converter != null && converter.CanRead)
							{
								obj = this.DeserializeConvertable(converter, reader, jsonProperty.PropertyType, null);
							}
							else
							{
								obj = this.CreateValueInternal(reader, jsonProperty.PropertyType, jsonProperty.PropertyContract, jsonProperty, contract, containerProperty, null);
							}
							dictionary[jsonProperty] = obj;
							break;
						}
					}
					else
					{
						if (!reader.Read())
						{
							goto IL_0233;
						}
						if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Verbose)
						{
							this.TraceWriter.Trace(TraceLevel.Verbose, JsonPosition.FormatMessage(reader as IJsonLineInfo, reader.Path, <Module>.smethod_27<string>(611550708U).FormatWith(JsonSerializerInternalReader.smethod_8(), text, contract.UnderlyingType)), null);
						}
						if (this.Serializer._missingMemberHandling == MissingMemberHandling.Error)
						{
							goto Block_14;
						}
					}
					if (extensionData == null)
					{
						reader.Skip();
					}
					else
					{
						object obj2 = this.CreateValueInternal(reader, null, null, null, contract, containerProperty, null);
						extensionData[text] = obj2;
					}
					break;
				}
				case JsonToken.Comment:
					break;
				default:
					if (tokenType != JsonToken.EndObject)
					{
						goto Block_16;
					}
					flag = true;
					break;
				}
				if (flag)
				{
					break;
				}
			}
			while (reader.Read());
			return dictionary;
			Block_14:
			throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(553153410U).FormatWith(JsonSerializerInternalReader.smethod_8(), text, JsonSerializerInternalReader.smethod_45(objectType)));
			Block_16:
			throw JsonSerializationException.Create(reader, JsonSerializerInternalReader.smethod_16(<Module>.smethod_25<string>(486825668U), reader.TokenType));
			IL_01F4:
			throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(505244156U).FormatWith(JsonSerializerInternalReader.smethod_8(), text));
			IL_0233:
			throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(3291623996U).FormatWith(JsonSerializerInternalReader.smethod_8(), text));
		}

		// Token: 0x0600253C RID: 9532 RVA: 0x00092550 File Offset: 0x00090750
		private bool ReadForType(JsonReader reader, JsonContract contract, bool hasConverter)
		{
			if (!hasConverter)
			{
				switch ((contract != null) ? contract.InternalReadType : ReadType.Read)
				{
				case ReadType.Read:
					while (reader.Read())
					{
						if (reader.TokenType != JsonToken.Comment)
						{
							return true;
						}
					}
					return false;
				case ReadType.ReadAsInt32:
					reader.ReadAsInt32();
					break;
				case ReadType.ReadAsBytes:
					reader.ReadAsBytes();
					break;
				case ReadType.ReadAsString:
					reader.ReadAsString();
					break;
				case ReadType.ReadAsDecimal:
					reader.ReadAsDecimal();
					break;
				case ReadType.ReadAsDateTime:
					reader.ReadAsDateTime();
					break;
				case ReadType.ReadAsDateTimeOffset:
					reader.ReadAsDateTimeOffset();
					break;
				default:
					throw JsonSerializerInternalReader.smethod_19();
				}
				return reader.TokenType != JsonToken.None;
			}
			return reader.Read();
		}

		// Token: 0x0600253D RID: 9533 RVA: 0x000925F8 File Offset: 0x000907F8
		public object CreateNewObject(JsonReader reader, JsonObjectContract objectContract, JsonProperty containerMember, JsonProperty containerProperty, string id, out bool createdFromNonDefaultCreator)
		{
			object obj = null;
			if (objectContract.OverrideCreator == null)
			{
				if (objectContract.DefaultCreator != null && (!objectContract.DefaultCreatorNonPublic || this.Serializer._constructorHandling == ConstructorHandling.AllowNonPublicDefaultConstructor || objectContract.ParametrizedCreator == null))
				{
					obj = objectContract.DefaultCreator();
				}
				else if (objectContract.ParametrizedCreator != null)
				{
					createdFromNonDefaultCreator = true;
					return this.CreateObjectUsingCreatorWithParameters(reader, objectContract, containerMember, objectContract.ParametrizedCreator, id);
				}
			}
			else
			{
				if (objectContract.CreatorParameters.Count > 0)
				{
					createdFromNonDefaultCreator = true;
					return this.CreateObjectUsingCreatorWithParameters(reader, objectContract, containerMember, objectContract.OverrideCreator, id);
				}
				obj = objectContract.OverrideCreator(new object[0]);
			}
			if (obj != null)
			{
				createdFromNonDefaultCreator = false;
				return obj;
			}
			if (!objectContract.IsInstantiable)
			{
				throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(604880422U).FormatWith(JsonSerializerInternalReader.smethod_8(), objectContract.UnderlyingType));
			}
			throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(700932523U).FormatWith(JsonSerializerInternalReader.smethod_8(), objectContract.UnderlyingType));
		}

		// Token: 0x0600253E RID: 9534 RVA: 0x000926EC File Offset: 0x000908EC
		private object PopulateObject(object newObject, JsonReader reader, JsonObjectContract contract, JsonProperty member, string id)
		{
			this.OnDeserializing(reader, contract, newObject);
			Dictionary<JsonProperty, JsonSerializerInternalReader.PropertyPresence> dictionary;
			if (!contract.HasRequiredOrDefaultValueProperties && !this.HasFlag(this.Serializer._defaultValueHandling, DefaultValueHandling.Populate))
			{
				dictionary = null;
			}
			else
			{
				dictionary = contract.Properties.ToDictionary((JsonProperty m) => m, (JsonProperty m) => JsonSerializerInternalReader.PropertyPresence.None);
			}
			Dictionary<JsonProperty, JsonSerializerInternalReader.PropertyPresence> dictionary2 = dictionary;
			if (id != null)
			{
				this.AddReference(reader, id, newObject);
			}
			int depth = reader.Depth;
			bool flag = false;
			for (;;)
			{
				JsonToken tokenType = reader.TokenType;
				switch (tokenType)
				{
				case JsonToken.PropertyName:
				{
					string text = JsonSerializerInternalReader.smethod_9(reader.Value);
					if (!this.CheckPropertyName(reader, text))
					{
						try
						{
							JsonProperty closestMatchProperty = contract.Properties.GetClosestMatchProperty(text);
							if (closestMatchProperty == null)
							{
								if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Verbose)
								{
									this.TraceWriter.Trace(TraceLevel.Verbose, JsonPosition.FormatMessage(reader as IJsonLineInfo, reader.Path, <Module>.smethod_26<string>(3391717431U).FormatWith(JsonSerializerInternalReader.smethod_8(), text, contract.UnderlyingType)), null);
								}
								if (this.Serializer._missingMemberHandling == MissingMemberHandling.Error)
								{
									throw JsonSerializationException.Create(reader, <Module>.smethod_24<string>(3743609299U).FormatWith(JsonSerializerInternalReader.smethod_8(), text, JsonSerializerInternalReader.smethod_45(contract.UnderlyingType)));
								}
								if (reader.Read())
								{
									this.SetExtensionData(contract, member, reader, text, newObject);
									break;
								}
								break;
							}
							else
							{
								if (closestMatchProperty.PropertyContract == null)
								{
									closestMatchProperty.PropertyContract = this.GetContractSafe(closestMatchProperty.PropertyType);
								}
								JsonConverter jsonConverter = null;
								if (!closestMatchProperty.Ignored)
								{
									jsonConverter = this.GetConverter(closestMatchProperty.PropertyContract, closestMatchProperty.MemberConverter, contract, member);
								}
								if (!this.ReadForType(reader, closestMatchProperty.PropertyContract, jsonConverter != null))
								{
									throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(3291623996U).FormatWith(JsonSerializerInternalReader.smethod_8(), text));
								}
								this.SetPropertyPresence(reader, closestMatchProperty, dictionary2);
								if (!this.SetPropertyValue(closestMatchProperty, jsonConverter, contract, member, reader, newObject))
								{
									this.SetExtensionData(contract, member, reader, text, newObject);
								}
								break;
							}
						}
						catch (Exception ex)
						{
							if (!base.IsErrorHandled(newObject, contract, text, reader as IJsonLineInfo, reader.Path, ex))
							{
								throw;
							}
							this.HandleError(reader, true, depth);
							break;
						}
						goto IL_024E;
					}
					break;
				}
				case JsonToken.Comment:
					break;
				default:
					goto IL_024E;
				}
				IL_0257:
				if (flag)
				{
					break;
				}
				if (!reader.Read())
				{
					break;
				}
				continue;
				IL_024E:
				if (tokenType != JsonToken.EndObject)
				{
					goto Block_9;
				}
				flag = true;
				goto IL_0257;
			}
			goto IL_0280;
			Block_9:
			throw JsonSerializationException.Create(reader, JsonSerializerInternalReader.smethod_16(<Module>.smethod_26<string>(2402186993U), reader.TokenType));
			IL_0280:
			if (!flag)
			{
				this.ThrowUnexpectedEndException(reader, contract, newObject, <Module>.smethod_26<string>(1316892615U));
			}
			this.EndObject(newObject, reader, contract, depth, dictionary2);
			this.OnDeserialized(reader, contract, newObject);
			return newObject;
		}

		// Token: 0x0600253F RID: 9535 RVA: 0x000929C0 File Offset: 0x00090BC0
		private bool CheckPropertyName(JsonReader reader, string memberName)
		{
			if (this.Serializer.MetadataPropertyHandling == MetadataPropertyHandling.ReadAhead && memberName != null && (JsonSerializerInternalReader.smethod_23(memberName, <Module>.smethod_27<string>(1521797154U)) || JsonSerializerInternalReader.smethod_23(memberName, <Module>.smethod_25<string>(2099451988U)) || JsonSerializerInternalReader.smethod_23(memberName, <Module>.smethod_26<string>(1990492877U)) || JsonSerializerInternalReader.smethod_23(memberName, <Module>.smethod_27<string>(3594889687U))))
			{
				reader.Skip();
				return true;
			}
			return false;
		}

		// Token: 0x06002540 RID: 9536 RVA: 0x00092A34 File Offset: 0x00090C34
		private void SetExtensionData(JsonObjectContract contract, JsonProperty member, JsonReader reader, string memberName, object o)
		{
			if (contract.ExtensionDataSetter != null)
			{
				try
				{
					object obj = this.CreateValueInternal(reader, null, null, null, contract, member, null);
					contract.ExtensionDataSetter(o, memberName, obj);
					return;
				}
				catch (Exception ex)
				{
					throw JsonSerializationException.Create(reader, <Module>.smethod_25<string>(4071058140U).FormatWith(JsonSerializerInternalReader.smethod_8(), contract.UnderlyingType), ex);
				}
			}
			reader.Skip();
		}

		// Token: 0x06002541 RID: 9537 RVA: 0x00092AA4 File Offset: 0x00090CA4
		private void EndObject(object newObject, JsonReader reader, JsonObjectContract contract, int initialDepth, Dictionary<JsonProperty, JsonSerializerInternalReader.PropertyPresence> propertiesPresence)
		{
			if (propertiesPresence != null)
			{
				foreach (KeyValuePair<JsonProperty, JsonSerializerInternalReader.PropertyPresence> keyValuePair in propertiesPresence)
				{
					JsonProperty key = keyValuePair.Key;
					JsonSerializerInternalReader.PropertyPresence value = keyValuePair.Value;
					if (value != JsonSerializerInternalReader.PropertyPresence.None)
					{
						if (value != JsonSerializerInternalReader.PropertyPresence.Null)
						{
							continue;
						}
					}
					try
					{
						Required? required = key._required;
						Required required2 = ((required == null) ? (contract.ItemRequired ?? Required.Default) : required.GetValueOrDefault());
						switch (value)
						{
						case JsonSerializerInternalReader.PropertyPresence.None:
							if (required2 == Required.AllowNull || required2 == Required.Always)
							{
								throw JsonSerializationException.Create(reader, <Module>.smethod_27<string>(3682810906U).FormatWith(JsonSerializerInternalReader.smethod_8(), key.PropertyName));
							}
							if (!key.Ignored)
							{
								if (key.PropertyContract == null)
								{
									key.PropertyContract = this.GetContractSafe(key.PropertyType);
								}
								if (this.HasFlag(key.DefaultValueHandling.GetValueOrDefault(this.Serializer._defaultValueHandling), DefaultValueHandling.Populate) && key.Writable)
								{
									key.ValueProvider.SetValue(newObject, this.EnsureType(reader, key.GetResolvedDefaultValue(), JsonSerializerInternalReader.smethod_8(), key.PropertyContract, key.PropertyType));
								}
							}
							break;
						case JsonSerializerInternalReader.PropertyPresence.Null:
							if (required2 == Required.Always)
							{
								throw JsonSerializationException.Create(reader, <Module>.smethod_23<string>(2174663926U).FormatWith(JsonSerializerInternalReader.smethod_8(), key.PropertyName));
							}
							break;
						}
					}
					catch (Exception ex)
					{
						if (base.IsErrorHandled(newObject, contract, key.PropertyName, reader as IJsonLineInfo, reader.Path, ex))
						{
							this.HandleError(reader, true, initialDepth);
							for (;;)
							{
								IL_01A7:
								int num = -874890501;
								for (;;)
								{
									switch (num ^ -874890502)
									{
									case 0:
										goto IL_01AE;
									case 1:
										num = -874890504;
										continue;
									case 3:
										goto IL_01A7;
									}
									goto Block_19;
								}
							}
							Block_19:
							continue;
						}
						IL_01AE:
						throw;
					}
				}
			}
		}

		// Token: 0x06002542 RID: 9538 RVA: 0x00092CB4 File Offset: 0x00090EB4
		private void SetPropertyPresence(JsonReader reader, JsonProperty property, Dictionary<JsonProperty, JsonSerializerInternalReader.PropertyPresence> requiredProperties)
		{
			if (property != null && requiredProperties != null)
			{
				JsonSerializerInternalReader.PropertyPresence propertyPresence;
				switch (reader.TokenType)
				{
				case JsonToken.String:
					propertyPresence = (JsonSerializerInternalReader.CoerceEmptyStringToNull(property.PropertyType, property.PropertyContract, (string)reader.Value) ? JsonSerializerInternalReader.PropertyPresence.Null : JsonSerializerInternalReader.PropertyPresence.Value);
					goto IL_0053;
				case JsonToken.Null:
				case JsonToken.Undefined:
					propertyPresence = JsonSerializerInternalReader.PropertyPresence.Null;
					goto IL_0053;
				}
				propertyPresence = JsonSerializerInternalReader.PropertyPresence.Value;
				IL_0053:
				requiredProperties[property] = propertyPresence;
			}
		}

		// Token: 0x06002543 RID: 9539 RVA: 0x0001D9D1 File Offset: 0x0001BBD1
		private void HandleError(JsonReader reader, bool readPastError, int initialDepth)
		{
			base.ClearErrorContext();
			if (readPastError)
			{
				reader.Skip();
				while (reader.Depth > initialDepth + 1)
				{
					if (!reader.Read())
					{
						return;
					}
				}
			}
		}

		// Token: 0x0600254B RID: 9547 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_7(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x0600254C RID: 9548 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_8()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x0600254D RID: 9549 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_9(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x0600254E RID: 9550 RVA: 0x000170FF File Offset: 0x000152FF
		static bool smethod_10(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string.Equals(string_0, string_1, stringComparison_0);
		}

		// Token: 0x0600254F RID: 9551 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_11(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x06002550 RID: 9552 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_12(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x06002551 RID: 9553 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_13(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06002552 RID: 9554 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_14(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06002553 RID: 9555 RVA: 0x0000C86F File Offset: 0x0000AA6F
		static byte[] smethod_15(string string_0)
		{
			return Convert.FromBase64String(string_0);
		}

		// Token: 0x06002554 RID: 9556 RVA: 0x0000EE96 File Offset: 0x0000D096
		static string smethod_16(object object_0, object object_1)
		{
			return object_0 + object_1;
		}

		// Token: 0x06002555 RID: 9557 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_17(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06002556 RID: 9558 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_18(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x06002557 RID: 9559 RVA: 0x00016A1F File Offset: 0x00014C1F
		static ArgumentOutOfRangeException smethod_19()
		{
			return new ArgumentOutOfRangeException();
		}

		// Token: 0x06002558 RID: 9560 RVA: 0x00017625 File Offset: 0x00015825
		static bool smethod_20(Type type_0, Type type_1)
		{
			return type_0.IsAssignableFrom(type_1);
		}

		// Token: 0x06002559 RID: 9561 RVA: 0x0000CD86 File Offset: 0x0000AF86
		static string smethod_21()
		{
			return Environment.NewLine;
		}

		// Token: 0x0600255A RID: 9562 RVA: 0x0001DA02 File Offset: 0x0001BC02
		static string smethod_22(string string_0, string string_1, string string_2, string string_3)
		{
			return string_0 + string_1 + string_2 + string_3;
		}

		// Token: 0x0600255B RID: 9563 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_23(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x0600255C RID: 9564 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_24(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x0600255D RID: 9565 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_25(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x0600255E RID: 9566 RVA: 0x0001DA0D File Offset: 0x0001BC0D
		static Type smethod_26(SerializationBinder serializationBinder_0, string string_0, string string_1)
		{
			return serializationBinder_0.BindToType(string_0, string_1);
		}

		// Token: 0x0600255F RID: 9567 RVA: 0x0001D68F File Offset: 0x0001B88F
		static string smethod_27(Type type_0)
		{
			return type_0.AssemblyQualifiedName;
		}

		// Token: 0x06002560 RID: 9568 RVA: 0x0001CE62 File Offset: 0x0001B062
		static int smethod_28(Type type_0)
		{
			return type_0.GetArrayRank();
		}

		// Token: 0x06002561 RID: 9569 RVA: 0x0001DA17 File Offset: 0x0001BC17
		static int smethod_29(ICollection icollection_0)
		{
			return icollection_0.Count;
		}

		// Token: 0x06002562 RID: 9570 RVA: 0x000162DF File Offset: 0x000144DF
		static Array smethod_30(Type type_0, int int_0)
		{
			return Array.CreateInstance(type_0, int_0);
		}

		// Token: 0x06002563 RID: 9571 RVA: 0x0001DA1F File Offset: 0x0001BC1F
		static void smethod_31(ICollection icollection_0, Array array_0, int int_0)
		{
			icollection_0.CopyTo(array_0, int_0);
		}

		// Token: 0x06002564 RID: 9572 RVA: 0x00013078 File Offset: 0x00011278
		static object smethod_32(Type type_0, string string_0, bool bool_0)
		{
			return Enum.Parse(type_0, string_0, bool_0);
		}

		// Token: 0x06002565 RID: 9573 RVA: 0x0001DA29 File Offset: 0x0001BC29
		static object smethod_33(Type type_0, object object_0)
		{
			return Enum.ToObject(type_0, object_0);
		}

		// Token: 0x06002566 RID: 9574 RVA: 0x000193D1 File Offset: 0x000175D1
		static object smethod_34(object object_0, Type type_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ChangeType(object_0, type_0, iformatProvider_0);
		}

		// Token: 0x06002567 RID: 9575 RVA: 0x0001DA32 File Offset: 0x0001BC32
		static void smethod_35(IDictionary idictionary_0, object object_0, object object_1)
		{
			idictionary_0[object_0] = object_1;
		}

		// Token: 0x06002568 RID: 9576 RVA: 0x00016314 File Offset: 0x00014514
		static int smethod_36(IList ilist_0, object object_0)
		{
			return ilist_0.Add(object_0);
		}

		// Token: 0x06002569 RID: 9577 RVA: 0x0001DA3C File Offset: 0x0001BC3C
		static bool smethod_37(IList ilist_0)
		{
			return ilist_0.IsFixedSize;
		}

		// Token: 0x0600256A RID: 9578 RVA: 0x0001DA44 File Offset: 0x0001BC44
		static SerializationInfo smethod_38(Type type_0, IFormatterConverter iformatterConverter_0)
		{
			return new SerializationInfo(type_0, iformatterConverter_0);
		}

		// Token: 0x0600256B RID: 9579 RVA: 0x0001DA4D File Offset: 0x0001BC4D
		static void smethod_39(SerializationInfo serializationInfo_0, string string_0, object object_0)
		{
			serializationInfo_0.AddValue(string_0, object_0);
		}

		// Token: 0x0600256C RID: 9580 RVA: 0x0000DAF6 File Offset: 0x0000BCF6
		static string smethod_40(string string_0, string[] string_1)
		{
			return string.Join(string_0, string_1);
		}

		// Token: 0x0600256D RID: 9581 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_41(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x0600256E RID: 9582 RVA: 0x0000DAD6 File Offset: 0x0000BCD6
		static IEnumerator smethod_42(IEnumerable ienumerable_0)
		{
			return ienumerable_0.GetEnumerator();
		}

		// Token: 0x0600256F RID: 9583 RVA: 0x0000D8E2 File Offset: 0x0000BAE2
		static object smethod_43(IEnumerator ienumerator_0)
		{
			return ienumerator_0.Current;
		}

		// Token: 0x06002570 RID: 9584 RVA: 0x0001DA57 File Offset: 0x0001BC57
		static IDictionaryEnumerator smethod_44(IDictionary idictionary_0)
		{
			return idictionary_0.GetEnumerator();
		}

		// Token: 0x06002571 RID: 9585 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_45(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x02000279 RID: 633
		internal enum PropertyPresence
		{
			// Token: 0x04000D58 RID: 3416
			None,
			// Token: 0x04000D59 RID: 3417
			Null,
			// Token: 0x04000D5A RID: 3418
			Value
		}
	}
}
