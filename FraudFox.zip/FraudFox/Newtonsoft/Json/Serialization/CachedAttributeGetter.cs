﻿using System;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000280 RID: 640
	internal static class CachedAttributeGetter<T> where T : Attribute
	{
		// Token: 0x0600261E RID: 9758 RVA: 0x0001DFB0 File Offset: 0x0001C1B0
		public static T GetAttribute(object type)
		{
			return CachedAttributeGetter<T>.TypeAttributeCache.Get(type);
		}

		// Token: 0x04000D71 RID: 3441
		private static readonly ThreadSafeStore<object, T> TypeAttributeCache = new ThreadSafeStore<object, T>(new Func<object, T>(JsonTypeReflector.GetAttribute<T>));
	}
}
