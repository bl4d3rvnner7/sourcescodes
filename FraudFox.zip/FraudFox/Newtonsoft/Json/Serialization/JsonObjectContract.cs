﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Runtime.Serialization;
using System.Security;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000275 RID: 629
	public class JsonObjectContract : JsonContainerContract
	{
		// Token: 0x17000598 RID: 1432
		// (get) Token: 0x060024E8 RID: 9448 RVA: 0x0001D702 File Offset: 0x0001B902
		// (set) Token: 0x060024E9 RID: 9449 RVA: 0x0001D70A File Offset: 0x0001B90A
		public MemberSerialization MemberSerialization { get; set; }

		// Token: 0x17000599 RID: 1433
		// (get) Token: 0x060024EA RID: 9450 RVA: 0x0001D713 File Offset: 0x0001B913
		// (set) Token: 0x060024EB RID: 9451 RVA: 0x0001D71B File Offset: 0x0001B91B
		public Required? ItemRequired { get; set; }

		// Token: 0x1700059A RID: 1434
		// (get) Token: 0x060024EC RID: 9452 RVA: 0x0001D724 File Offset: 0x0001B924
		// (set) Token: 0x060024ED RID: 9453 RVA: 0x0001D72C File Offset: 0x0001B92C
		public JsonPropertyCollection Properties { get; private set; }

		// Token: 0x1700059B RID: 1435
		// (get) Token: 0x060024EE RID: 9454 RVA: 0x0001D735 File Offset: 0x0001B935
		[Obsolete("ConstructorParameters is obsolete. Use CreatorParameters instead.")]
		public JsonPropertyCollection ConstructorParameters
		{
			get
			{
				return this.CreatorParameters;
			}
		}

		// Token: 0x1700059C RID: 1436
		// (get) Token: 0x060024EF RID: 9455 RVA: 0x0001D73D File Offset: 0x0001B93D
		// (set) Token: 0x060024F0 RID: 9456 RVA: 0x0001D745 File Offset: 0x0001B945
		public JsonPropertyCollection CreatorParameters { get; private set; }

		// Token: 0x1700059D RID: 1437
		// (get) Token: 0x060024F1 RID: 9457 RVA: 0x0001D74E File Offset: 0x0001B94E
		// (set) Token: 0x060024F2 RID: 9458 RVA: 0x0001D756 File Offset: 0x0001B956
		[Obsolete("OverrideConstructor is obsolete. Use OverrideCreator instead.")]
		public ConstructorInfo OverrideConstructor
		{
			get
			{
				return this._overrideConstructor;
			}
			set
			{
				this._overrideConstructor = value;
				this._overrideCreator = (JsonObjectContract.smethod_6(value, null) ? JsonTypeReflector.ReflectionDelegateFactory.CreateParametrizedConstructor(value) : null);
			}
		}

		// Token: 0x1700059E RID: 1438
		// (get) Token: 0x060024F3 RID: 9459 RVA: 0x0001D77C File Offset: 0x0001B97C
		// (set) Token: 0x060024F4 RID: 9460 RVA: 0x0001D784 File Offset: 0x0001B984
		[Obsolete("ParametrizedConstructor is obsolete. Use OverrideCreator instead.")]
		public ConstructorInfo ParametrizedConstructor
		{
			get
			{
				return this._parametrizedConstructor;
			}
			set
			{
				this._parametrizedConstructor = value;
				this._parametrizedCreator = (JsonObjectContract.smethod_6(value, null) ? JsonTypeReflector.ReflectionDelegateFactory.CreateParametrizedConstructor(value) : null);
			}
		}

		// Token: 0x1700059F RID: 1439
		// (get) Token: 0x060024F5 RID: 9461 RVA: 0x0001D7AA File Offset: 0x0001B9AA
		// (set) Token: 0x060024F6 RID: 9462 RVA: 0x0001D7B2 File Offset: 0x0001B9B2
		public ObjectConstructor<object> OverrideCreator
		{
			get
			{
				return this._overrideCreator;
			}
			set
			{
				this._overrideCreator = value;
				this._overrideConstructor = null;
			}
		}

		// Token: 0x170005A0 RID: 1440
		// (get) Token: 0x060024F7 RID: 9463 RVA: 0x0001D7C2 File Offset: 0x0001B9C2
		internal ObjectConstructor<object> ParametrizedCreator
		{
			get
			{
				return this._parametrizedCreator;
			}
		}

		// Token: 0x170005A1 RID: 1441
		// (get) Token: 0x060024F8 RID: 9464 RVA: 0x0001D7CA File Offset: 0x0001B9CA
		// (set) Token: 0x060024F9 RID: 9465 RVA: 0x0001D7D2 File Offset: 0x0001B9D2
		public ExtensionDataSetter ExtensionDataSetter { get; set; }

		// Token: 0x170005A2 RID: 1442
		// (get) Token: 0x060024FA RID: 9466 RVA: 0x0001D7DB File Offset: 0x0001B9DB
		// (set) Token: 0x060024FB RID: 9467 RVA: 0x0001D7E3 File Offset: 0x0001B9E3
		public ExtensionDataGetter ExtensionDataGetter { get; set; }

		// Token: 0x170005A3 RID: 1443
		// (get) Token: 0x060024FC RID: 9468 RVA: 0x0008EF80 File Offset: 0x0008D180
		internal bool HasRequiredOrDefaultValueProperties
		{
			get
			{
				if (this._hasRequiredOrDefaultValueProperties == null)
				{
					this._hasRequiredOrDefaultValueProperties = new bool?(false);
					if (this.ItemRequired.GetValueOrDefault(Required.Default) != Required.Default)
					{
						this._hasRequiredOrDefaultValueProperties = new bool?(true);
					}
					else
					{
						IEnumerator<JsonProperty> enumerator = this.Properties.GetEnumerator();
						try
						{
							for (;;)
							{
								IL_0126:
								int num = ((!JsonObjectContract.smethod_7(enumerator)) ? (-553742751) : (-553742748));
								for (;;)
								{
									bool flag;
									switch (num ^ -553742747)
									{
									case 0:
									{
										DefaultValueHandling? defaultValueHandling;
										flag = defaultValueHandling != null;
										goto IL_006F;
									}
									case 1:
									{
										JsonProperty jsonProperty = enumerator.Current;
										if (jsonProperty.Required == Required.Default)
										{
											DefaultValueHandling? defaultValueHandling2 = jsonProperty.DefaultValueHandling;
											num = -553742745;
											continue;
										}
										goto IL_007B;
									}
									case 2:
									{
										DefaultValueHandling? defaultValueHandling2;
										DefaultValueHandling? defaultValueHandling = defaultValueHandling2 & DefaultValueHandling.Populate;
										num = -553742739;
										continue;
									}
									case 3:
										num = -553742751;
										continue;
									case 5:
										goto IL_0126;
									case 6:
										num = -553742748;
										continue;
									case 7:
										goto IL_007B;
									case 8:
									{
										DefaultValueHandling? defaultValueHandling;
										if (defaultValueHandling.GetValueOrDefault() == DefaultValueHandling.Populate)
										{
											num = -553742747;
											continue;
										}
										flag = false;
										goto IL_006F;
									}
									}
									goto Block_9;
									IL_006F:
									if (flag)
									{
										num = -553742750;
										continue;
									}
									break;
									IL_007B:
									this._hasRequiredOrDefaultValueProperties = new bool?(true);
									num = -553742746;
								}
							}
							Block_9:;
						}
						finally
						{
							if (enumerator != null)
							{
								JsonObjectContract.smethod_8(enumerator);
							}
						}
					}
				}
				return this._hasRequiredOrDefaultValueProperties.Value;
			}
		}

		// Token: 0x060024FD RID: 9469 RVA: 0x0001D7EC File Offset: 0x0001B9EC
		public JsonObjectContract(Type underlyingType)
			: base(underlyingType)
		{
			this.ContractType = JsonContractType.Object;
			this.Properties = new JsonPropertyCollection(base.UnderlyingType);
			this.CreatorParameters = new JsonPropertyCollection(base.UnderlyingType);
		}

		// Token: 0x060024FE RID: 9470 RVA: 0x0001D81E File Offset: 0x0001BA1E
		[SecuritySafeCritical]
		internal object GetUninitializedObject()
		{
			if (!JsonTypeReflector.FullyTrusted)
			{
				throw new JsonException(<Module>.smethod_23<string>(1624016946U).FormatWith(JsonObjectContract.smethod_9(), this.NonNullableUnderlyingType));
			}
			return JsonObjectContract.smethod_10(this.NonNullableUnderlyingType);
		}

		// Token: 0x060024FF RID: 9471 RVA: 0x0001CA27 File Offset: 0x0001AC27
		static bool smethod_6(ConstructorInfo constructorInfo_0, ConstructorInfo constructorInfo_1)
		{
			return constructorInfo_0 != constructorInfo_1;
		}

		// Token: 0x06002500 RID: 9472 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_7(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06002501 RID: 9473 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_8(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06002502 RID: 9474 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_9()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06002503 RID: 9475 RVA: 0x0001D852 File Offset: 0x0001BA52
		static object smethod_10(Type type_0)
		{
			return FormatterServices.GetUninitializedObject(type_0);
		}

		// Token: 0x04000D40 RID: 3392
		private bool? _hasRequiredOrDefaultValueProperties;

		// Token: 0x04000D41 RID: 3393
		private ConstructorInfo _parametrizedConstructor;

		// Token: 0x04000D42 RID: 3394
		private ConstructorInfo _overrideConstructor;

		// Token: 0x04000D43 RID: 3395
		private ObjectConstructor<object> _overrideCreator;

		// Token: 0x04000D44 RID: 3396
		private ObjectConstructor<object> _parametrizedCreator;
	}
}
