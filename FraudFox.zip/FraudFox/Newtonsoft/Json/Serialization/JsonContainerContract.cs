﻿using System;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001E0 RID: 480
	public class JsonContainerContract : JsonContract
	{
		// Token: 0x170003D8 RID: 984
		// (get) Token: 0x06001AE8 RID: 6888 RVA: 0x000183A8 File Offset: 0x000165A8
		// (set) Token: 0x06001AE9 RID: 6889 RVA: 0x000183B0 File Offset: 0x000165B0
		internal JsonContract ItemContract
		{
			get
			{
				return this._itemContract;
			}
			set
			{
				this._itemContract = value;
				if (this._itemContract != null)
				{
					this._finalItemContract = (this._itemContract.UnderlyingType.IsSealed() ? this._itemContract : null);
					return;
				}
				this._finalItemContract = null;
			}
		}

		// Token: 0x170003D9 RID: 985
		// (get) Token: 0x06001AEA RID: 6890 RVA: 0x000183EA File Offset: 0x000165EA
		internal JsonContract FinalItemContract
		{
			get
			{
				return this._finalItemContract;
			}
		}

		// Token: 0x170003DA RID: 986
		// (get) Token: 0x06001AEB RID: 6891 RVA: 0x000183F2 File Offset: 0x000165F2
		// (set) Token: 0x06001AEC RID: 6892 RVA: 0x000183FA File Offset: 0x000165FA
		public JsonConverter ItemConverter { get; set; }

		// Token: 0x170003DB RID: 987
		// (get) Token: 0x06001AED RID: 6893 RVA: 0x00018403 File Offset: 0x00016603
		// (set) Token: 0x06001AEE RID: 6894 RVA: 0x0001840B File Offset: 0x0001660B
		public bool? ItemIsReference { get; set; }

		// Token: 0x170003DC RID: 988
		// (get) Token: 0x06001AEF RID: 6895 RVA: 0x00018414 File Offset: 0x00016614
		// (set) Token: 0x06001AF0 RID: 6896 RVA: 0x0001841C File Offset: 0x0001661C
		public ReferenceLoopHandling? ItemReferenceLoopHandling { get; set; }

		// Token: 0x170003DD RID: 989
		// (get) Token: 0x06001AF1 RID: 6897 RVA: 0x00018425 File Offset: 0x00016625
		// (set) Token: 0x06001AF2 RID: 6898 RVA: 0x0001842D File Offset: 0x0001662D
		public TypeNameHandling? ItemTypeNameHandling { get; set; }

		// Token: 0x06001AF3 RID: 6899 RVA: 0x0007B1D4 File Offset: 0x000793D4
		internal JsonContainerContract(Type underlyingType)
			: base(underlyingType)
		{
			JsonContainerAttribute cachedAttribute = JsonTypeReflector.GetCachedAttribute<JsonContainerAttribute>(underlyingType);
			if (cachedAttribute != null)
			{
				if (JsonContainerContract.smethod_5(cachedAttribute.ItemConverterType, null))
				{
					this.ItemConverter = JsonTypeReflector.CreateJsonConverterInstance(cachedAttribute.ItemConverterType, cachedAttribute.ItemConverterParameters);
				}
				this.ItemIsReference = cachedAttribute._itemIsReference;
				this.ItemReferenceLoopHandling = cachedAttribute._itemReferenceLoopHandling;
				this.ItemTypeNameHandling = cachedAttribute._itemTypeNameHandling;
			}
		}

		// Token: 0x06001AF4 RID: 6900 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_5(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x04000A87 RID: 2695
		private JsonContract _itemContract;

		// Token: 0x04000A88 RID: 2696
		private JsonContract _finalItemContract;
	}
}
