﻿using System;
using System.Globalization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001FF RID: 511
	internal class DefaultReferenceResolver : IReferenceResolver
	{
		// Token: 0x06001CFE RID: 7422 RVA: 0x0007F7C0 File Offset: 0x0007D9C0
		private BidirectionalDictionary<string, object> GetMappings(object context)
		{
			JsonSerializerInternalBase jsonSerializerInternalBase;
			if (context is JsonSerializerInternalBase)
			{
				jsonSerializerInternalBase = (JsonSerializerInternalBase)context;
			}
			else
			{
				if (!(context is JsonSerializerProxy))
				{
					throw new JsonException(<Module>.smethod_23<string>(3483016408U));
				}
				jsonSerializerInternalBase = ((JsonSerializerProxy)context).GetInternalSerializer();
			}
			return jsonSerializerInternalBase.DefaultReferenceMappings;
		}

		// Token: 0x06001CFF RID: 7423 RVA: 0x0007F808 File Offset: 0x0007DA08
		public object ResolveReference(object context, string reference)
		{
			object obj;
			this.GetMappings(context).TryGetByFirst(reference, out obj);
			return obj;
		}

		// Token: 0x06001D00 RID: 7424 RVA: 0x0007F828 File Offset: 0x0007DA28
		public string GetReference(object context, object value)
		{
			BidirectionalDictionary<string, object> mappings = this.GetMappings(context);
			string text;
			if (!mappings.TryGetBySecond(value, out text))
			{
				this._referenceCount++;
				text = this._referenceCount.ToString(DefaultReferenceResolver.smethod_0());
				mappings.Set(text, value);
			}
			return text;
		}

		// Token: 0x06001D01 RID: 7425 RVA: 0x000194D3 File Offset: 0x000176D3
		public void AddReference(object context, string reference, object value)
		{
			this.GetMappings(context).Set(reference, value);
		}

		// Token: 0x06001D02 RID: 7426 RVA: 0x0007F870 File Offset: 0x0007DA70
		public bool IsReferenced(object context, object value)
		{
			string text;
			return this.GetMappings(context).TryGetBySecond(value, out text);
		}

		// Token: 0x06001D04 RID: 7428 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_0()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x04000B02 RID: 2818
		private int _referenceCount;
	}
}
