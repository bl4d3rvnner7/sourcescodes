﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001E2 RID: 482
	public class ReflectionAttributeProvider : IAttributeProvider
	{
		// Token: 0x06001B01 RID: 6913 RVA: 0x00018469 File Offset: 0x00016669
		public ReflectionAttributeProvider(object attributeProvider)
		{
			ValidationUtils.ArgumentNotNull(attributeProvider, <Module>.smethod_26<string>(1162925260U));
			this._attributeProvider = attributeProvider;
		}

		// Token: 0x06001B02 RID: 6914 RVA: 0x00018488 File Offset: 0x00016688
		public IList<Attribute> GetAttributes(bool inherit)
		{
			return ReflectionUtils.GetAttributes(this._attributeProvider, null, inherit);
		}

		// Token: 0x06001B03 RID: 6915 RVA: 0x00018497 File Offset: 0x00016697
		public IList<Attribute> GetAttributes(Type attributeType, bool inherit)
		{
			return ReflectionUtils.GetAttributes(this._attributeProvider, attributeType, inherit);
		}

		// Token: 0x04000A8F RID: 2703
		private readonly object _attributeProvider;
	}
}
