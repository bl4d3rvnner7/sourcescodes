﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Security;
using System.Security.Permissions;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x0200027E RID: 638
	internal static class JsonTypeReflector
	{
		// Token: 0x060025F6 RID: 9718 RVA: 0x0001DF19 File Offset: 0x0001C119
		public static T GetCachedAttribute<T>(object attributeProvider) where T : Attribute
		{
			return CachedAttributeGetter<T>.GetAttribute(attributeProvider);
		}

		// Token: 0x060025F7 RID: 9719 RVA: 0x00094A70 File Offset: 0x00092C70
		public static DataContractAttribute GetDataContractAttribute(Type type)
		{
			Type type2 = type;
			while (JsonTypeReflector.smethod_0(type2, null))
			{
				DataContractAttribute attribute = CachedAttributeGetter<DataContractAttribute>.GetAttribute(type2);
				if (attribute != null)
				{
					return attribute;
				}
				type2 = type2.BaseType();
			}
			return null;
		}

		// Token: 0x060025F8 RID: 9720 RVA: 0x00094AA0 File Offset: 0x00092CA0
		public static DataMemberAttribute GetDataMemberAttribute(MemberInfo memberInfo)
		{
			if (memberInfo.MemberType() == MemberTypes.Field)
			{
				return CachedAttributeGetter<DataMemberAttribute>.GetAttribute(memberInfo);
			}
			PropertyInfo propertyInfo = (PropertyInfo)memberInfo;
			DataMemberAttribute dataMemberAttribute = CachedAttributeGetter<DataMemberAttribute>.GetAttribute(propertyInfo);
			if (dataMemberAttribute == null && propertyInfo.IsVirtual())
			{
				Type type = JsonTypeReflector.smethod_1(propertyInfo);
				while (dataMemberAttribute == null && JsonTypeReflector.smethod_0(type, null))
				{
					PropertyInfo propertyInfo2 = (PropertyInfo)ReflectionUtils.GetMemberInfoFromType(type, propertyInfo);
					if (JsonTypeReflector.smethod_2(propertyInfo2, null) && propertyInfo2.IsVirtual())
					{
						dataMemberAttribute = CachedAttributeGetter<DataMemberAttribute>.GetAttribute(propertyInfo2);
					}
					type = type.BaseType();
				}
			}
			return dataMemberAttribute;
		}

		// Token: 0x060025F9 RID: 9721 RVA: 0x00094B18 File Offset: 0x00092D18
		public static MemberSerialization GetObjectMemberSerialization(Type objectType, bool ignoreSerializableAttribute)
		{
			JsonObjectAttribute cachedAttribute = JsonTypeReflector.GetCachedAttribute<JsonObjectAttribute>(objectType);
			if (cachedAttribute != null)
			{
				return cachedAttribute.MemberSerialization;
			}
			if (JsonTypeReflector.GetDataContractAttribute(objectType) == null)
			{
				if (!ignoreSerializableAttribute)
				{
					SerializableAttribute cachedAttribute2 = JsonTypeReflector.GetCachedAttribute<SerializableAttribute>(objectType);
					if (cachedAttribute2 != null)
					{
						return MemberSerialization.Fields;
					}
				}
				return MemberSerialization.OptOut;
			}
			return MemberSerialization.OptIn;
		}

		// Token: 0x060025FA RID: 9722 RVA: 0x00094B54 File Offset: 0x00092D54
		public static JsonConverter GetJsonConverter(object attributeProvider)
		{
			JsonConverterAttribute cachedAttribute = JsonTypeReflector.GetCachedAttribute<JsonConverterAttribute>(attributeProvider);
			if (cachedAttribute != null)
			{
				Func<object[], JsonConverter> func = JsonTypeReflector.JsonConverterCreatorCache.Get(cachedAttribute.ConverterType);
				if (func != null)
				{
					return func(cachedAttribute.ConverterParameters);
				}
			}
			return null;
		}

		// Token: 0x060025FB RID: 9723 RVA: 0x00094B90 File Offset: 0x00092D90
		public static JsonConverter CreateJsonConverterInstance(Type converterType, object[] converterArgs)
		{
			Func<object[], JsonConverter> func = JsonTypeReflector.JsonConverterCreatorCache.Get(converterType);
			return func(converterArgs);
		}

		// Token: 0x060025FC RID: 9724 RVA: 0x00094BB0 File Offset: 0x00092DB0
		private static Func<object[], JsonConverter> GetJsonConverterCreator(Type converterType)
		{
			Func<object> defaultConstructor = (ReflectionUtils.HasDefaultConstructor(converterType, false) ? JsonTypeReflector.ReflectionDelegateFactory.CreateDefaultConstructor<object>(converterType) : null);
			return delegate(object[] parameters)
			{
				JsonConverter jsonConverter;
				try
				{
					if (parameters != null)
					{
						Type[] array = parameters.Select((object param) => JsonTypeReflector.<>c__DisplayClass2.smethod_3(param)).ToArray<Type>();
						ConstructorInfo constructorInfo = JsonTypeReflector.<>c__DisplayClass2.smethod_0(converterType, array);
						if (!JsonTypeReflector.<>c__DisplayClass2.smethod_1(null, constructorInfo))
						{
							throw new JsonException(<Module>.smethod_27<string>(1800628566U).FormatWith(JsonTypeReflector.<>c__DisplayClass2.smethod_2(), converterType));
						}
						ObjectConstructor<object> objectConstructor = JsonTypeReflector.ReflectionDelegateFactory.CreateParametrizedConstructor(constructorInfo);
						jsonConverter = (JsonConverter)objectConstructor(parameters);
					}
					else
					{
						if (defaultConstructor == null)
						{
							throw new JsonException(<Module>.smethod_25<string>(2578735130U).FormatWith(JsonTypeReflector.<>c__DisplayClass2.smethod_2(), converterType));
						}
						jsonConverter = (JsonConverter)defaultConstructor();
					}
				}
				catch (Exception ex)
				{
					throw new JsonException(<Module>.smethod_23<string>(2142176178U).FormatWith(JsonTypeReflector.<>c__DisplayClass2.smethod_2(), converterType), ex);
				}
				return jsonConverter;
			};
		}

		// Token: 0x060025FD RID: 9725 RVA: 0x0001DF21 File Offset: 0x0001C121
		public static TypeConverter GetTypeConverter(Type type)
		{
			return JsonTypeReflector.smethod_3(type);
		}

		// Token: 0x060025FE RID: 9726 RVA: 0x0001DF29 File Offset: 0x0001C129
		private static Type GetAssociatedMetadataType(Type type)
		{
			return JsonTypeReflector.AssociatedMetadataTypesCache.Get(type);
		}

		// Token: 0x060025FF RID: 9727 RVA: 0x00094C00 File Offset: 0x00092E00
		private static Type GetAssociateMetadataTypeFromAttribute(Type type)
		{
			Attribute[] attributes = ReflectionUtils.GetAttributes(type, null, true);
			foreach (Attribute attribute in attributes)
			{
				Type type2 = JsonTypeReflector.smethod_4(attribute);
				if (JsonTypeReflector.smethod_6(JsonTypeReflector.smethod_5(type2), <Module>.smethod_26<string>(2323159036U), StringComparison.Ordinal))
				{
					if (JsonTypeReflector._metadataTypeAttributeReflectionObject == null)
					{
						JsonTypeReflector._metadataTypeAttributeReflectionObject = ReflectionObject.Create(type2, new string[] { <Module>.smethod_25<string>(2131702539U) });
					}
					return (Type)JsonTypeReflector._metadataTypeAttributeReflectionObject.GetValue(attribute, <Module>.smethod_27<string>(1707385180U));
				}
			}
			return null;
		}

		// Token: 0x06002600 RID: 9728 RVA: 0x00094CA4 File Offset: 0x00092EA4
		private static T GetAttribute<T>(Type type) where T : Attribute
		{
			Type associatedMetadataType = JsonTypeReflector.GetAssociatedMetadataType(type);
			T t;
			if (JsonTypeReflector.smethod_0(associatedMetadataType, null))
			{
				t = ReflectionUtils.GetAttribute<T>(associatedMetadataType, true);
				if (t != null)
				{
					return t;
				}
			}
			t = ReflectionUtils.GetAttribute<T>(type, true);
			if (t != null)
			{
				return t;
			}
			foreach (Type type2 in JsonTypeReflector.smethod_7(type))
			{
				t = ReflectionUtils.GetAttribute<T>(type2, true);
				if (t != null)
				{
					return t;
				}
			}
			return default(T);
		}

		// Token: 0x06002601 RID: 9729 RVA: 0x00094D28 File Offset: 0x00092F28
		private static T GetAttribute<T>(MemberInfo memberInfo) where T : Attribute
		{
			Type associatedMetadataType = JsonTypeReflector.GetAssociatedMetadataType(JsonTypeReflector.smethod_1(memberInfo));
			T t;
			if (JsonTypeReflector.smethod_0(associatedMetadataType, null))
			{
				MemberInfo memberInfoFromType = ReflectionUtils.GetMemberInfoFromType(associatedMetadataType, memberInfo);
				if (JsonTypeReflector.smethod_8(memberInfoFromType, null))
				{
					t = ReflectionUtils.GetAttribute<T>(memberInfoFromType, true);
					if (t != null)
					{
						return t;
					}
				}
			}
			t = ReflectionUtils.GetAttribute<T>(memberInfo, true);
			if (t != null)
			{
				return t;
			}
			if (JsonTypeReflector.smethod_0(JsonTypeReflector.smethod_1(memberInfo), null))
			{
				foreach (Type type in JsonTypeReflector.smethod_7(JsonTypeReflector.smethod_1(memberInfo)))
				{
					MemberInfo memberInfoFromType2 = ReflectionUtils.GetMemberInfoFromType(type, memberInfo);
					if (JsonTypeReflector.smethod_8(memberInfoFromType2, null))
					{
						t = ReflectionUtils.GetAttribute<T>(memberInfoFromType2, true);
						if (t != null)
						{
							return t;
						}
					}
				}
			}
			return default(T);
		}

		// Token: 0x06002602 RID: 9730 RVA: 0x00094DF0 File Offset: 0x00092FF0
		public static T GetAttribute<T>(object provider) where T : Attribute
		{
			Type type = provider as Type;
			if (JsonTypeReflector.smethod_0(type, null))
			{
				return JsonTypeReflector.GetAttribute<T>(type);
			}
			MemberInfo memberInfo = provider as MemberInfo;
			if (JsonTypeReflector.smethod_8(memberInfo, null))
			{
				return JsonTypeReflector.GetAttribute<T>(memberInfo);
			}
			return ReflectionUtils.GetAttribute<T>(provider, true);
		}

		// Token: 0x170005C1 RID: 1473
		// (get) Token: 0x06002603 RID: 9731 RVA: 0x00094E34 File Offset: 0x00093034
		public static bool DynamicCodeGeneration
		{
			[SecuritySafeCritical]
			get
			{
				if (JsonTypeReflector._dynamicCodeGeneration == null)
				{
					try
					{
						JsonTypeReflector.smethod_9(ReflectionPermissionFlag.MemberAccess).method_0();
						JsonTypeReflector.smethod_9(ReflectionPermissionFlag.RestrictedMemberAccess).method_0();
						JsonTypeReflector.smethod_10(SecurityPermissionFlag.SkipVerification).method_0();
						JsonTypeReflector.smethod_10(SecurityPermissionFlag.UnmanagedCode).method_0();
						JsonTypeReflector.smethod_11(PermissionState.Unrestricted).method_0();
						JsonTypeReflector._dynamicCodeGeneration = new bool?(true);
					}
					catch (Exception)
					{
						JsonTypeReflector._dynamicCodeGeneration = new bool?(false);
					}
				}
				return JsonTypeReflector._dynamicCodeGeneration.Value;
			}
		}

		// Token: 0x170005C2 RID: 1474
		// (get) Token: 0x06002604 RID: 9732 RVA: 0x00094EBC File Offset: 0x000930BC
		public static bool FullyTrusted
		{
			get
			{
				if (JsonTypeReflector._fullyTrusted == null)
				{
					AppDomain appDomain = JsonTypeReflector.smethod_12();
					for (;;)
					{
						IL_005A:
						int num = -1214123023;
						for (;;)
						{
							bool flag;
							switch (num ^ -1214123021)
							{
							case 0:
								goto IL_005A;
							case 2:
								if (JsonTypeReflector.smethod_13(appDomain))
								{
									num = -1214123024;
									continue;
								}
								flag = false;
								goto IL_001A;
							case 3:
								flag = JsonTypeReflector.smethod_14(appDomain);
								goto IL_001A;
							}
							goto Block_3;
							IL_001A:
							JsonTypeReflector._fullyTrusted = new bool?(flag);
							num = -1214123022;
						}
					}
					Block_3:;
				}
				return JsonTypeReflector._fullyTrusted.Value;
			}
		}

		// Token: 0x170005C3 RID: 1475
		// (get) Token: 0x06002605 RID: 9733 RVA: 0x0001DF36 File Offset: 0x0001C136
		public static ReflectionDelegateFactory ReflectionDelegateFactory
		{
			get
			{
				if (JsonTypeReflector.DynamicCodeGeneration)
				{
					return DynamicReflectionDelegateFactory.Instance;
				}
				return LateBoundReflectionDelegateFactory.Instance;
			}
		}

		// Token: 0x06002607 RID: 9735 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_0(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x06002608 RID: 9736 RVA: 0x00014858 File Offset: 0x00012A58
		static Type smethod_1(MemberInfo memberInfo_0)
		{
			return memberInfo_0.DeclaringType;
		}

		// Token: 0x06002609 RID: 9737 RVA: 0x0001CA1E File Offset: 0x0001AC1E
		static bool smethod_2(PropertyInfo propertyInfo_0, PropertyInfo propertyInfo_1)
		{
			return propertyInfo_0 != propertyInfo_1;
		}

		// Token: 0x0600260A RID: 9738 RVA: 0x000162E8 File Offset: 0x000144E8
		static TypeConverter smethod_3(Type type_0)
		{
			return TypeDescriptor.GetConverter(type_0);
		}

		// Token: 0x0600260B RID: 9739 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_4(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x0600260C RID: 9740 RVA: 0x00017761 File Offset: 0x00015961
		static string smethod_5(Type type_0)
		{
			return type_0.FullName;
		}

		// Token: 0x0600260D RID: 9741 RVA: 0x000170FF File Offset: 0x000152FF
		static bool smethod_6(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string.Equals(string_0, string_1, stringComparison_0);
		}

		// Token: 0x0600260E RID: 9742 RVA: 0x0001DF78 File Offset: 0x0001C178
		static Type[] smethod_7(Type type_0)
		{
			return type_0.GetInterfaces();
		}

		// Token: 0x0600260F RID: 9743 RVA: 0x0001CA30 File Offset: 0x0001AC30
		static bool smethod_8(MemberInfo memberInfo_0, MemberInfo memberInfo_1)
		{
			return memberInfo_0 != memberInfo_1;
		}

		// Token: 0x06002610 RID: 9744 RVA: 0x0001DF80 File Offset: 0x0001C180
		static ReflectionPermission smethod_9(ReflectionPermissionFlag reflectionPermissionFlag_0)
		{
			return new ReflectionPermission(reflectionPermissionFlag_0);
		}

		// Token: 0x06002611 RID: 9745 RVA: 0x0001DF88 File Offset: 0x0001C188
		void method_0()
		{
			base.Demand();
		}

		// Token: 0x06002612 RID: 9746 RVA: 0x00013378 File Offset: 0x00011578
		static SecurityPermission smethod_10(SecurityPermissionFlag securityPermissionFlag_0)
		{
			return new SecurityPermission(securityPermissionFlag_0);
		}

		// Token: 0x06002613 RID: 9747 RVA: 0x0001DF90 File Offset: 0x0001C190
		static SecurityPermission smethod_11(PermissionState permissionState_0)
		{
			return new SecurityPermission(permissionState_0);
		}

		// Token: 0x06002614 RID: 9748 RVA: 0x0001CCA3 File Offset: 0x0001AEA3
		static AppDomain smethod_12()
		{
			return AppDomain.CurrentDomain;
		}

		// Token: 0x06002615 RID: 9749 RVA: 0x0001DF98 File Offset: 0x0001C198
		static bool smethod_13(AppDomain appDomain_0)
		{
			return appDomain_0.IsHomogenous;
		}

		// Token: 0x06002616 RID: 9750 RVA: 0x0001DFA0 File Offset: 0x0001C1A0
		static bool smethod_14(AppDomain appDomain_0)
		{
			return appDomain_0.IsFullyTrusted;
		}

		// Token: 0x04000D62 RID: 3426
		public const string IdPropertyName = "$id";

		// Token: 0x04000D63 RID: 3427
		public const string RefPropertyName = "$ref";

		// Token: 0x04000D64 RID: 3428
		public const string TypePropertyName = "$type";

		// Token: 0x04000D65 RID: 3429
		public const string ValuePropertyName = "$value";

		// Token: 0x04000D66 RID: 3430
		public const string ArrayValuesPropertyName = "$values";

		// Token: 0x04000D67 RID: 3431
		public const string ShouldSerializePrefix = "ShouldSerialize";

		// Token: 0x04000D68 RID: 3432
		public const string SpecifiedPostfix = "Specified";

		// Token: 0x04000D69 RID: 3433
		private static bool? _dynamicCodeGeneration;

		// Token: 0x04000D6A RID: 3434
		private static bool? _fullyTrusted;

		// Token: 0x04000D6B RID: 3435
		private static readonly ThreadSafeStore<Type, Func<object[], JsonConverter>> JsonConverterCreatorCache = new ThreadSafeStore<Type, Func<object[], JsonConverter>>(new Func<Type, Func<object[], JsonConverter>>(JsonTypeReflector.GetJsonConverterCreator));

		// Token: 0x04000D6C RID: 3436
		private static readonly ThreadSafeStore<Type, Type> AssociatedMetadataTypesCache = new ThreadSafeStore<Type, Type>(new Func<Type, Type>(JsonTypeReflector.GetAssociateMetadataTypeFromAttribute));

		// Token: 0x04000D6D RID: 3437
		private static ReflectionObject _metadataTypeAttributeReflectionObject;
	}
}
