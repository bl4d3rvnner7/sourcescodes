﻿using System;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001FC RID: 508
	public class ErrorEventArgs : EventArgs
	{
		// Token: 0x17000409 RID: 1033
		// (get) Token: 0x06001CE8 RID: 7400 RVA: 0x00019469 File Offset: 0x00017669
		// (set) Token: 0x06001CE9 RID: 7401 RVA: 0x00019471 File Offset: 0x00017671
		public object CurrentObject { get; private set; }

		// Token: 0x1700040A RID: 1034
		// (get) Token: 0x06001CEA RID: 7402 RVA: 0x0001947A File Offset: 0x0001767A
		// (set) Token: 0x06001CEB RID: 7403 RVA: 0x00019482 File Offset: 0x00017682
		public ErrorContext ErrorContext { get; private set; }

		// Token: 0x06001CEC RID: 7404 RVA: 0x0001948B File Offset: 0x0001768B
		public ErrorEventArgs(object currentObject, ErrorContext errorContext)
		{
			this.CurrentObject = currentObject;
			this.ErrorContext = errorContext;
		}
	}
}
