﻿using System;
using System.Runtime.Serialization;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000264 RID: 612
	// (Invoke) Token: 0x060023D7 RID: 9175
	public delegate void SerializationErrorCallback(object o, StreamingContext context, ErrorContext errorContext);
}
