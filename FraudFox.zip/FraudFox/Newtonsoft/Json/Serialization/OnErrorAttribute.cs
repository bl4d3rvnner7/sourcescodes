﻿using System;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000282 RID: 642
	[AttributeUsage(AttributeTargets.Method, Inherited = false)]
	public sealed class OnErrorAttribute : Attribute
	{
	}
}
