﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000267 RID: 615
	public class JsonDictionaryContract : JsonContainerContract
	{
		// Token: 0x17000548 RID: 1352
		// (get) Token: 0x060023E2 RID: 9186 RVA: 0x0001CE6A File Offset: 0x0001B06A
		// (set) Token: 0x060023E3 RID: 9187 RVA: 0x0001CE72 File Offset: 0x0001B072
		[Obsolete("PropertyNameResolver is obsolete. Use DictionaryKeyResolver instead.")]
		public Func<string, string> PropertyNameResolver
		{
			get
			{
				return this.DictionaryKeyResolver;
			}
			set
			{
				this.DictionaryKeyResolver = value;
			}
		}

		// Token: 0x17000549 RID: 1353
		// (get) Token: 0x060023E4 RID: 9188 RVA: 0x0001CE7B File Offset: 0x0001B07B
		// (set) Token: 0x060023E5 RID: 9189 RVA: 0x0001CE83 File Offset: 0x0001B083
		public Func<string, string> DictionaryKeyResolver { get; set; }

		// Token: 0x1700054A RID: 1354
		// (get) Token: 0x060023E6 RID: 9190 RVA: 0x0001CE8C File Offset: 0x0001B08C
		// (set) Token: 0x060023E7 RID: 9191 RVA: 0x0001CE94 File Offset: 0x0001B094
		public Type DictionaryKeyType { get; private set; }

		// Token: 0x1700054B RID: 1355
		// (get) Token: 0x060023E8 RID: 9192 RVA: 0x0001CE9D File Offset: 0x0001B09D
		// (set) Token: 0x060023E9 RID: 9193 RVA: 0x0001CEA5 File Offset: 0x0001B0A5
		public Type DictionaryValueType { get; private set; }

		// Token: 0x1700054C RID: 1356
		// (get) Token: 0x060023EA RID: 9194 RVA: 0x0001CEAE File Offset: 0x0001B0AE
		// (set) Token: 0x060023EB RID: 9195 RVA: 0x0001CEB6 File Offset: 0x0001B0B6
		internal JsonContract KeyContract { get; set; }

		// Token: 0x1700054D RID: 1357
		// (get) Token: 0x060023EC RID: 9196 RVA: 0x0001CEBF File Offset: 0x0001B0BF
		// (set) Token: 0x060023ED RID: 9197 RVA: 0x0001CEC7 File Offset: 0x0001B0C7
		internal bool ShouldCreateWrapper { get; private set; }

		// Token: 0x1700054E RID: 1358
		// (get) Token: 0x060023EE RID: 9198 RVA: 0x0001CED0 File Offset: 0x0001B0D0
		internal ObjectConstructor<object> ParametrizedCreator
		{
			get
			{
				if (this._parametrizedCreator == null)
				{
					this._parametrizedCreator = JsonTypeReflector.ReflectionDelegateFactory.CreateParametrizedConstructor(this._parametrizedConstructor);
				}
				return this._parametrizedCreator;
			}
		}

		// Token: 0x1700054F RID: 1359
		// (get) Token: 0x060023EF RID: 9199 RVA: 0x0001CEF6 File Offset: 0x0001B0F6
		internal bool HasParametrizedCreator
		{
			get
			{
				return this._parametrizedCreator != null || JsonDictionaryContract.smethod_6(this._parametrizedConstructor, null);
			}
		}

		// Token: 0x060023F0 RID: 9200 RVA: 0x0008CEA8 File Offset: 0x0008B0A8
		public JsonDictionaryContract(Type underlyingType)
			: base(underlyingType)
		{
			this.ContractType = JsonContractType.Dictionary;
			Type type;
			Type type2;
			if (ReflectionUtils.ImplementsGenericDefinition(underlyingType, JsonDictionaryContract.smethod_7(typeof(IDictionary<, >).TypeHandle), out this._genericCollectionDefinitionType))
			{
				type = JsonDictionaryContract.smethod_8(this._genericCollectionDefinitionType)[0];
				type2 = JsonDictionaryContract.smethod_8(this._genericCollectionDefinitionType)[1];
				if (ReflectionUtils.IsGenericDefinition(base.UnderlyingType, JsonDictionaryContract.smethod_7(typeof(IDictionary<, >).TypeHandle)))
				{
					base.CreatedType = JsonDictionaryContract.smethod_9(JsonDictionaryContract.smethod_7(typeof(Dictionary<, >).TypeHandle), new Type[] { type, type2 });
				}
			}
			else
			{
				ReflectionUtils.GetDictionaryKeyValueTypes(base.UnderlyingType, out type, out type2);
				if (JsonDictionaryContract.smethod_10(base.UnderlyingType, JsonDictionaryContract.smethod_7(typeof(IDictionary).TypeHandle)))
				{
					base.CreatedType = JsonDictionaryContract.smethod_7(typeof(Dictionary<object, object>).TypeHandle);
				}
			}
			if (JsonDictionaryContract.smethod_11(type, null) && JsonDictionaryContract.smethod_11(type2, null))
			{
				this._parametrizedConstructor = CollectionUtils.ResolveEnumerableCollectionConstructor(base.CreatedType, JsonDictionaryContract.smethod_9(JsonDictionaryContract.smethod_7(typeof(KeyValuePair<, >).TypeHandle), new Type[] { type, type2 }));
				if (!this.HasParametrizedCreator && JsonDictionaryContract.smethod_13(JsonDictionaryContract.smethod_12(underlyingType), <Module>.smethod_23<string>(4282052220U)))
				{
					FSharpUtils.EnsureInitialized(underlyingType.Assembly());
					this._parametrizedCreator = FSharpUtils.CreateMap(type, type2);
				}
			}
			this.ShouldCreateWrapper = !JsonDictionaryContract.smethod_14(JsonDictionaryContract.smethod_7(typeof(IDictionary).TypeHandle), base.CreatedType);
			this.DictionaryKeyType = type;
			this.DictionaryValueType = type2;
		}

		// Token: 0x060023F1 RID: 9201 RVA: 0x0008D028 File Offset: 0x0008B228
		internal IWrappedDictionary CreateWrapper(object dictionary)
		{
			if (this._genericWrapperCreator == null)
			{
				this._genericWrapperType = JsonDictionaryContract.smethod_9(JsonDictionaryContract.smethod_7(typeof(DictionaryWrapper<, >).TypeHandle), new Type[] { this.DictionaryKeyType, this.DictionaryValueType });
				ConstructorInfo constructorInfo = JsonDictionaryContract.smethod_15(this._genericWrapperType, new Type[] { this._genericCollectionDefinitionType });
				this._genericWrapperCreator = JsonTypeReflector.ReflectionDelegateFactory.CreateParametrizedConstructor(constructorInfo);
			}
			return (IWrappedDictionary)this._genericWrapperCreator(new object[] { dictionary });
		}

		// Token: 0x060023F2 RID: 9202 RVA: 0x0008D0C4 File Offset: 0x0008B2C4
		internal IDictionary CreateTemporaryDictionary()
		{
			if (this._genericTemporaryDictionaryCreator == null)
			{
				Type type = JsonDictionaryContract.smethod_9(JsonDictionaryContract.smethod_7(typeof(Dictionary<, >).TypeHandle), new Type[] { this.DictionaryKeyType, this.DictionaryValueType });
				this._genericTemporaryDictionaryCreator = JsonTypeReflector.ReflectionDelegateFactory.CreateDefaultConstructor<object>(type);
			}
			return (IDictionary)this._genericTemporaryDictionaryCreator();
		}

		// Token: 0x060023F3 RID: 9203 RVA: 0x0001CA27 File Offset: 0x0001AC27
		static bool smethod_6(ConstructorInfo constructorInfo_0, ConstructorInfo constructorInfo_1)
		{
			return constructorInfo_0 != constructorInfo_1;
		}

		// Token: 0x060023F4 RID: 9204 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_7(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060023F5 RID: 9205 RVA: 0x00015F4C File Offset: 0x0001414C
		static Type[] smethod_8(Type type_0)
		{
			return type_0.GetGenericArguments();
		}

		// Token: 0x060023F6 RID: 9206 RVA: 0x00016303 File Offset: 0x00014503
		static Type smethod_9(Type type_0, Type[] type_1)
		{
			return type_0.MakeGenericType(type_1);
		}

		// Token: 0x060023F7 RID: 9207 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_10(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x060023F8 RID: 9208 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_11(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x060023F9 RID: 9209 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_12(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x060023FA RID: 9210 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_13(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x060023FB RID: 9211 RVA: 0x00017625 File Offset: 0x00015825
		static bool smethod_14(Type type_0, Type type_1)
		{
			return type_0.IsAssignableFrom(type_1);
		}

		// Token: 0x060023FC RID: 9212 RVA: 0x000175AD File Offset: 0x000157AD
		static ConstructorInfo smethod_15(Type type_0, Type[] type_1)
		{
			return type_0.GetConstructor(type_1);
		}

		// Token: 0x04000CAC RID: 3244
		private readonly Type _genericCollectionDefinitionType;

		// Token: 0x04000CAD RID: 3245
		private Type _genericWrapperType;

		// Token: 0x04000CAE RID: 3246
		private ObjectConstructor<object> _genericWrapperCreator;

		// Token: 0x04000CAF RID: 3247
		private Func<object> _genericTemporaryDictionaryCreator;

		// Token: 0x04000CB0 RID: 3248
		private readonly ConstructorInfo _parametrizedConstructor;

		// Token: 0x04000CB1 RID: 3249
		private ObjectConstructor<object> _parametrizedCreator;
	}
}
