﻿using System;
using System.Collections;
using System.Globalization;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x0200027C RID: 636
	internal class JsonSerializerProxy : JsonSerializer
	{
		// Token: 0x1400002D RID: 45
		// (add) Token: 0x060025B6 RID: 9654 RVA: 0x0001DB29 File Offset: 0x0001BD29
		// (remove) Token: 0x060025B7 RID: 9655 RVA: 0x0001DB37 File Offset: 0x0001BD37
		public override event EventHandler<ErrorEventArgs> Error
		{
			add
			{
				this._serializer.Error += value;
			}
			remove
			{
				this._serializer.Error -= value;
			}
		}

		// Token: 0x170005A5 RID: 1445
		// (get) Token: 0x060025B8 RID: 9656 RVA: 0x0001DB45 File Offset: 0x0001BD45
		// (set) Token: 0x060025B9 RID: 9657 RVA: 0x0001DB52 File Offset: 0x0001BD52
		public override IReferenceResolver ReferenceResolver
		{
			get
			{
				return this._serializer.ReferenceResolver;
			}
			set
			{
				this._serializer.ReferenceResolver = value;
			}
		}

		// Token: 0x170005A6 RID: 1446
		// (get) Token: 0x060025BA RID: 9658 RVA: 0x0001DB60 File Offset: 0x0001BD60
		// (set) Token: 0x060025BB RID: 9659 RVA: 0x0001DB6D File Offset: 0x0001BD6D
		public override ITraceWriter TraceWriter
		{
			get
			{
				return this._serializer.TraceWriter;
			}
			set
			{
				this._serializer.TraceWriter = value;
			}
		}

		// Token: 0x170005A7 RID: 1447
		// (get) Token: 0x060025BC RID: 9660 RVA: 0x0001DB7B File Offset: 0x0001BD7B
		// (set) Token: 0x060025BD RID: 9661 RVA: 0x0001DB88 File Offset: 0x0001BD88
		public override IEqualityComparer EqualityComparer
		{
			get
			{
				return this._serializer.EqualityComparer;
			}
			set
			{
				this._serializer.EqualityComparer = value;
			}
		}

		// Token: 0x170005A8 RID: 1448
		// (get) Token: 0x060025BE RID: 9662 RVA: 0x0001DB96 File Offset: 0x0001BD96
		public override JsonConverterCollection Converters
		{
			get
			{
				return this._serializer.Converters;
			}
		}

		// Token: 0x170005A9 RID: 1449
		// (get) Token: 0x060025BF RID: 9663 RVA: 0x0001DBA3 File Offset: 0x0001BDA3
		// (set) Token: 0x060025C0 RID: 9664 RVA: 0x0001DBB0 File Offset: 0x0001BDB0
		public override DefaultValueHandling DefaultValueHandling
		{
			get
			{
				return this._serializer.DefaultValueHandling;
			}
			set
			{
				this._serializer.DefaultValueHandling = value;
			}
		}

		// Token: 0x170005AA RID: 1450
		// (get) Token: 0x060025C1 RID: 9665 RVA: 0x0001DBBE File Offset: 0x0001BDBE
		// (set) Token: 0x060025C2 RID: 9666 RVA: 0x0001DBCB File Offset: 0x0001BDCB
		public override IContractResolver ContractResolver
		{
			get
			{
				return this._serializer.ContractResolver;
			}
			set
			{
				this._serializer.ContractResolver = value;
			}
		}

		// Token: 0x170005AB RID: 1451
		// (get) Token: 0x060025C3 RID: 9667 RVA: 0x0001DBD9 File Offset: 0x0001BDD9
		// (set) Token: 0x060025C4 RID: 9668 RVA: 0x0001DBE6 File Offset: 0x0001BDE6
		public override MissingMemberHandling MissingMemberHandling
		{
			get
			{
				return this._serializer.MissingMemberHandling;
			}
			set
			{
				this._serializer.MissingMemberHandling = value;
			}
		}

		// Token: 0x170005AC RID: 1452
		// (get) Token: 0x060025C5 RID: 9669 RVA: 0x0001DBF4 File Offset: 0x0001BDF4
		// (set) Token: 0x060025C6 RID: 9670 RVA: 0x0001DC01 File Offset: 0x0001BE01
		public override NullValueHandling NullValueHandling
		{
			get
			{
				return this._serializer.NullValueHandling;
			}
			set
			{
				this._serializer.NullValueHandling = value;
			}
		}

		// Token: 0x170005AD RID: 1453
		// (get) Token: 0x060025C7 RID: 9671 RVA: 0x0001DC0F File Offset: 0x0001BE0F
		// (set) Token: 0x060025C8 RID: 9672 RVA: 0x0001DC1C File Offset: 0x0001BE1C
		public override ObjectCreationHandling ObjectCreationHandling
		{
			get
			{
				return this._serializer.ObjectCreationHandling;
			}
			set
			{
				this._serializer.ObjectCreationHandling = value;
			}
		}

		// Token: 0x170005AE RID: 1454
		// (get) Token: 0x060025C9 RID: 9673 RVA: 0x0001DC2A File Offset: 0x0001BE2A
		// (set) Token: 0x060025CA RID: 9674 RVA: 0x0001DC37 File Offset: 0x0001BE37
		public override ReferenceLoopHandling ReferenceLoopHandling
		{
			get
			{
				return this._serializer.ReferenceLoopHandling;
			}
			set
			{
				this._serializer.ReferenceLoopHandling = value;
			}
		}

		// Token: 0x170005AF RID: 1455
		// (get) Token: 0x060025CB RID: 9675 RVA: 0x0001DC45 File Offset: 0x0001BE45
		// (set) Token: 0x060025CC RID: 9676 RVA: 0x0001DC52 File Offset: 0x0001BE52
		public override PreserveReferencesHandling PreserveReferencesHandling
		{
			get
			{
				return this._serializer.PreserveReferencesHandling;
			}
			set
			{
				this._serializer.PreserveReferencesHandling = value;
			}
		}

		// Token: 0x170005B0 RID: 1456
		// (get) Token: 0x060025CD RID: 9677 RVA: 0x0001DC60 File Offset: 0x0001BE60
		// (set) Token: 0x060025CE RID: 9678 RVA: 0x0001DC6D File Offset: 0x0001BE6D
		public override TypeNameHandling TypeNameHandling
		{
			get
			{
				return this._serializer.TypeNameHandling;
			}
			set
			{
				this._serializer.TypeNameHandling = value;
			}
		}

		// Token: 0x170005B1 RID: 1457
		// (get) Token: 0x060025CF RID: 9679 RVA: 0x0001DC7B File Offset: 0x0001BE7B
		// (set) Token: 0x060025D0 RID: 9680 RVA: 0x0001DC88 File Offset: 0x0001BE88
		public override MetadataPropertyHandling MetadataPropertyHandling
		{
			get
			{
				return this._serializer.MetadataPropertyHandling;
			}
			set
			{
				this._serializer.MetadataPropertyHandling = value;
			}
		}

		// Token: 0x170005B2 RID: 1458
		// (get) Token: 0x060025D1 RID: 9681 RVA: 0x0001DC96 File Offset: 0x0001BE96
		// (set) Token: 0x060025D2 RID: 9682 RVA: 0x0001DCA3 File Offset: 0x0001BEA3
		public override FormatterAssemblyStyle TypeNameAssemblyFormat
		{
			get
			{
				return this._serializer.TypeNameAssemblyFormat;
			}
			set
			{
				this._serializer.TypeNameAssemblyFormat = value;
			}
		}

		// Token: 0x170005B3 RID: 1459
		// (get) Token: 0x060025D3 RID: 9683 RVA: 0x0001DCB1 File Offset: 0x0001BEB1
		// (set) Token: 0x060025D4 RID: 9684 RVA: 0x0001DCBE File Offset: 0x0001BEBE
		public override ConstructorHandling ConstructorHandling
		{
			get
			{
				return this._serializer.ConstructorHandling;
			}
			set
			{
				this._serializer.ConstructorHandling = value;
			}
		}

		// Token: 0x170005B4 RID: 1460
		// (get) Token: 0x060025D5 RID: 9685 RVA: 0x0001DCCC File Offset: 0x0001BECC
		// (set) Token: 0x060025D6 RID: 9686 RVA: 0x0001DCD9 File Offset: 0x0001BED9
		public override SerializationBinder Binder
		{
			get
			{
				return this._serializer.Binder;
			}
			set
			{
				this._serializer.Binder = value;
			}
		}

		// Token: 0x170005B5 RID: 1461
		// (get) Token: 0x060025D7 RID: 9687 RVA: 0x0001DCE7 File Offset: 0x0001BEE7
		// (set) Token: 0x060025D8 RID: 9688 RVA: 0x0001DCF4 File Offset: 0x0001BEF4
		public override StreamingContext Context
		{
			get
			{
				return this._serializer.Context;
			}
			set
			{
				this._serializer.Context = value;
			}
		}

		// Token: 0x170005B6 RID: 1462
		// (get) Token: 0x060025D9 RID: 9689 RVA: 0x0001DD02 File Offset: 0x0001BF02
		// (set) Token: 0x060025DA RID: 9690 RVA: 0x0001DD0F File Offset: 0x0001BF0F
		public override Formatting Formatting
		{
			get
			{
				return this._serializer.Formatting;
			}
			set
			{
				this._serializer.Formatting = value;
			}
		}

		// Token: 0x170005B7 RID: 1463
		// (get) Token: 0x060025DB RID: 9691 RVA: 0x0001DD1D File Offset: 0x0001BF1D
		// (set) Token: 0x060025DC RID: 9692 RVA: 0x0001DD2A File Offset: 0x0001BF2A
		public override DateFormatHandling DateFormatHandling
		{
			get
			{
				return this._serializer.DateFormatHandling;
			}
			set
			{
				this._serializer.DateFormatHandling = value;
			}
		}

		// Token: 0x170005B8 RID: 1464
		// (get) Token: 0x060025DD RID: 9693 RVA: 0x0001DD38 File Offset: 0x0001BF38
		// (set) Token: 0x060025DE RID: 9694 RVA: 0x0001DD45 File Offset: 0x0001BF45
		public override DateTimeZoneHandling DateTimeZoneHandling
		{
			get
			{
				return this._serializer.DateTimeZoneHandling;
			}
			set
			{
				this._serializer.DateTimeZoneHandling = value;
			}
		}

		// Token: 0x170005B9 RID: 1465
		// (get) Token: 0x060025DF RID: 9695 RVA: 0x0001DD53 File Offset: 0x0001BF53
		// (set) Token: 0x060025E0 RID: 9696 RVA: 0x0001DD60 File Offset: 0x0001BF60
		public override DateParseHandling DateParseHandling
		{
			get
			{
				return this._serializer.DateParseHandling;
			}
			set
			{
				this._serializer.DateParseHandling = value;
			}
		}

		// Token: 0x170005BA RID: 1466
		// (get) Token: 0x060025E1 RID: 9697 RVA: 0x0001DD6E File Offset: 0x0001BF6E
		// (set) Token: 0x060025E2 RID: 9698 RVA: 0x0001DD7B File Offset: 0x0001BF7B
		public override FloatFormatHandling FloatFormatHandling
		{
			get
			{
				return this._serializer.FloatFormatHandling;
			}
			set
			{
				this._serializer.FloatFormatHandling = value;
			}
		}

		// Token: 0x170005BB RID: 1467
		// (get) Token: 0x060025E3 RID: 9699 RVA: 0x0001DD89 File Offset: 0x0001BF89
		// (set) Token: 0x060025E4 RID: 9700 RVA: 0x0001DD96 File Offset: 0x0001BF96
		public override FloatParseHandling FloatParseHandling
		{
			get
			{
				return this._serializer.FloatParseHandling;
			}
			set
			{
				this._serializer.FloatParseHandling = value;
			}
		}

		// Token: 0x170005BC RID: 1468
		// (get) Token: 0x060025E5 RID: 9701 RVA: 0x0001DDA4 File Offset: 0x0001BFA4
		// (set) Token: 0x060025E6 RID: 9702 RVA: 0x0001DDB1 File Offset: 0x0001BFB1
		public override StringEscapeHandling StringEscapeHandling
		{
			get
			{
				return this._serializer.StringEscapeHandling;
			}
			set
			{
				this._serializer.StringEscapeHandling = value;
			}
		}

		// Token: 0x170005BD RID: 1469
		// (get) Token: 0x060025E7 RID: 9703 RVA: 0x0001DDBF File Offset: 0x0001BFBF
		// (set) Token: 0x060025E8 RID: 9704 RVA: 0x0001DDCC File Offset: 0x0001BFCC
		public override string DateFormatString
		{
			get
			{
				return this._serializer.DateFormatString;
			}
			set
			{
				this._serializer.DateFormatString = value;
			}
		}

		// Token: 0x170005BE RID: 1470
		// (get) Token: 0x060025E9 RID: 9705 RVA: 0x0001DDDA File Offset: 0x0001BFDA
		// (set) Token: 0x060025EA RID: 9706 RVA: 0x0001DDE7 File Offset: 0x0001BFE7
		public override CultureInfo Culture
		{
			get
			{
				return this._serializer.Culture;
			}
			set
			{
				this._serializer.Culture = value;
			}
		}

		// Token: 0x170005BF RID: 1471
		// (get) Token: 0x060025EB RID: 9707 RVA: 0x0001DDF5 File Offset: 0x0001BFF5
		// (set) Token: 0x060025EC RID: 9708 RVA: 0x0001DE02 File Offset: 0x0001C002
		public override int? MaxDepth
		{
			get
			{
				return this._serializer.MaxDepth;
			}
			set
			{
				this._serializer.MaxDepth = value;
			}
		}

		// Token: 0x170005C0 RID: 1472
		// (get) Token: 0x060025ED RID: 9709 RVA: 0x0001DE10 File Offset: 0x0001C010
		// (set) Token: 0x060025EE RID: 9710 RVA: 0x0001DE1D File Offset: 0x0001C01D
		public override bool CheckAdditionalContent
		{
			get
			{
				return this._serializer.CheckAdditionalContent;
			}
			set
			{
				this._serializer.CheckAdditionalContent = value;
			}
		}

		// Token: 0x060025EF RID: 9711 RVA: 0x0001DE2B File Offset: 0x0001C02B
		internal JsonSerializerInternalBase GetInternalSerializer()
		{
			if (this._serializerReader != null)
			{
				return this._serializerReader;
			}
			return this._serializerWriter;
		}

		// Token: 0x060025F0 RID: 9712 RVA: 0x0001DE42 File Offset: 0x0001C042
		public JsonSerializerProxy(JsonSerializerInternalReader serializerReader)
		{
			ValidationUtils.ArgumentNotNull(serializerReader, <Module>.smethod_27<string>(3292522742U));
			this._serializerReader = serializerReader;
			this._serializer = serializerReader.Serializer;
		}

		// Token: 0x060025F1 RID: 9713 RVA: 0x0001DE6D File Offset: 0x0001C06D
		public JsonSerializerProxy(JsonSerializerInternalWriter serializerWriter)
		{
			ValidationUtils.ArgumentNotNull(serializerWriter, <Module>.smethod_25<string>(252571308U));
			this._serializerWriter = serializerWriter;
			this._serializer = serializerWriter.Serializer;
		}

		// Token: 0x060025F2 RID: 9714 RVA: 0x0001DE98 File Offset: 0x0001C098
		internal override object DeserializeInternal(JsonReader reader, Type objectType)
		{
			if (this._serializerReader != null)
			{
				return this._serializerReader.Deserialize(reader, objectType, false);
			}
			return this._serializer.Deserialize(reader, objectType);
		}

		// Token: 0x060025F3 RID: 9715 RVA: 0x0001DEBE File Offset: 0x0001C0BE
		internal override void PopulateInternal(JsonReader reader, object target)
		{
			if (this._serializerReader != null)
			{
				this._serializerReader.Populate(reader, target);
				return;
			}
			this._serializer.Populate(reader, target);
		}

		// Token: 0x060025F4 RID: 9716 RVA: 0x0001DEE3 File Offset: 0x0001C0E3
		internal override void SerializeInternal(JsonWriter jsonWriter, object value, Type rootType)
		{
			if (this._serializerWriter != null)
			{
				this._serializerWriter.Serialize(jsonWriter, value, rootType);
				return;
			}
			this._serializer.Serialize(jsonWriter, value);
		}

		// Token: 0x04000D5F RID: 3423
		private readonly JsonSerializerInternalReader _serializerReader;

		// Token: 0x04000D60 RID: 3424
		private readonly JsonSerializerInternalWriter _serializerWriter;

		// Token: 0x04000D61 RID: 3425
		private readonly JsonSerializer _serializer;
	}
}
