﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Dynamic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Security;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x0200027B RID: 635
	internal class JsonSerializerInternalWriter : JsonSerializerInternalBase
	{
		// Token: 0x06002575 RID: 9589 RVA: 0x0001DA77 File Offset: 0x0001BC77
		public JsonSerializerInternalWriter(JsonSerializer serializer)
			: base(serializer)
		{
		}

		// Token: 0x06002576 RID: 9590 RVA: 0x00092D1C File Offset: 0x00090F1C
		public void Serialize(JsonWriter jsonWriter, object value, Type objectType)
		{
			if (jsonWriter != null)
			{
				this._rootContract = ((!JsonSerializerInternalWriter.smethod_8(objectType, null)) ? null : this.Serializer._contractResolver.ResolveContract(objectType));
				this._rootLevel = this._serializeStack.Count + 1;
				JsonContract contractSafe = this.GetContractSafe(value);
				try
				{
					try
					{
						if (this.ShouldWriteReference(value, null, contractSafe, null, null))
						{
							this.WriteReference(jsonWriter, value);
						}
						else
						{
							this.SerializeValue(jsonWriter, value, contractSafe, null, null, null);
						}
					}
					catch (Exception ex)
					{
						for (;;)
						{
							IL_00C8:
							int num = 1168345828;
							for (;;)
							{
								switch (num ^ 1168345829)
								{
								case 0:
									goto IL_00CF;
								case 1:
									num = ((!base.IsErrorHandled(null, contractSafe, null, null, jsonWriter.Path, ex)) ? 1168345829 : 1168345824);
									continue;
								case 2:
									goto IL_00C8;
								case 3:
									num = 1168345825;
									continue;
								case 5:
									this.HandleError(jsonWriter, 0);
									num = 1168345830;
									continue;
								}
								goto Block_8;
							}
						}
						Block_8:
						goto IL_00D7;
						IL_00CF:
						base.ClearErrorContext();
						throw;
						IL_00D7:;
					}
					return;
				}
				finally
				{
					this._rootContract = null;
				}
			}
			throw JsonSerializerInternalWriter.smethod_7(<Module>.smethod_24<string>(672653964U));
		}

		// Token: 0x06002577 RID: 9591 RVA: 0x0001DA8B File Offset: 0x0001BC8B
		private JsonSerializerProxy GetInternalSerializer()
		{
			if (this.InternalSerializer == null)
			{
				this.InternalSerializer = new JsonSerializerProxy(this);
			}
			return this.InternalSerializer;
		}

		// Token: 0x06002578 RID: 9592 RVA: 0x0001DAA7 File Offset: 0x0001BCA7
		private JsonContract GetContractSafe(object value)
		{
			if (value == null)
			{
				return null;
			}
			return this.Serializer._contractResolver.ResolveContract(JsonSerializerInternalWriter.smethod_9(value));
		}

		// Token: 0x06002579 RID: 9593 RVA: 0x00092E38 File Offset: 0x00091038
		private void SerializePrimitive(JsonWriter writer, object value, JsonPrimitiveContract contract, JsonProperty member, JsonContainerContract containerContract, JsonProperty containerProperty)
		{
			if (contract.TypeCode == PrimitiveTypeCode.Bytes && this.ShouldWriteType(TypeNameHandling.Objects, contract, member, containerContract, containerProperty))
			{
				writer.WriteStartObject();
				this.WriteTypeProperty(writer, contract.CreatedType);
				writer.WritePropertyName(<Module>.smethod_24<string>(2163420918U), false);
				JsonWriter.WriteValue(writer, contract.TypeCode, value);
				writer.WriteEndObject();
				return;
			}
			JsonWriter.WriteValue(writer, contract.TypeCode, value);
		}

		// Token: 0x0600257A RID: 9594 RVA: 0x00092EA4 File Offset: 0x000910A4
		private void SerializeValue(JsonWriter writer, object value, JsonContract valueContract, JsonProperty member, JsonContainerContract containerContract, JsonProperty containerProperty)
		{
			if (value == null)
			{
				writer.WriteNull();
				return;
			}
			JsonConverter jsonConverter;
			if (member != null)
			{
				if ((jsonConverter = member.Converter) != null)
				{
					goto IL_0065;
				}
			}
			if (containerProperty != null)
			{
				if ((jsonConverter = containerProperty.ItemConverter) != null)
				{
					goto IL_0065;
				}
			}
			if (containerContract != null)
			{
				if ((jsonConverter = containerContract.ItemConverter) != null)
				{
					goto IL_0065;
				}
			}
			if ((jsonConverter = valueContract.Converter) == null)
			{
				jsonConverter = this.Serializer.GetMatchingConverter(valueContract.UnderlyingType) ?? valueContract.InternalConverter;
			}
			IL_0065:
			JsonConverter jsonConverter2 = jsonConverter;
			if (jsonConverter2 != null && jsonConverter2.CanWrite)
			{
				this.SerializeConvertable(writer, jsonConverter2, value, valueContract, containerContract, containerProperty);
				return;
			}
			switch (valueContract.ContractType)
			{
			case JsonContractType.Object:
				this.SerializeObject(writer, value, (JsonObjectContract)valueContract, member, containerContract, containerProperty);
				return;
			case JsonContractType.Array:
			{
				JsonArrayContract jsonArrayContract = (JsonArrayContract)valueContract;
				if (!jsonArrayContract.IsMultidimensionalArray)
				{
					this.SerializeList(writer, (IEnumerable)value, jsonArrayContract, member, containerContract, containerProperty);
					return;
				}
				this.SerializeMultidimensionalArray(writer, (Array)value, jsonArrayContract, member, containerContract, containerProperty);
				return;
			}
			case JsonContractType.Primitive:
				this.SerializePrimitive(writer, value, (JsonPrimitiveContract)valueContract, member, containerContract, containerProperty);
				return;
			case JsonContractType.String:
				this.SerializeString(writer, value, (JsonStringContract)valueContract);
				return;
			case JsonContractType.Dictionary:
			{
				JsonDictionaryContract jsonDictionaryContract = (JsonDictionaryContract)valueContract;
				this.SerializeDictionary(writer, (value is IDictionary) ? ((IDictionary)value) : jsonDictionaryContract.CreateWrapper(value), jsonDictionaryContract, member, containerContract, containerProperty);
				return;
			}
			case JsonContractType.Dynamic:
				this.SerializeDynamic(writer, (IDynamicMetaObjectProvider)value, (JsonDynamicContract)valueContract, member, containerContract, containerProperty);
				return;
			case JsonContractType.Serializable:
				this.SerializeISerializable(writer, (ISerializable)value, (JsonISerializableContract)valueContract, member, containerContract, containerProperty);
				return;
			case JsonContractType.Linq:
				((JToken)value).WriteTo(writer, this.Serializer.Converters.ToArray<JsonConverter>());
				return;
			default:
				return;
			}
		}

		// Token: 0x0600257B RID: 9595 RVA: 0x00093050 File Offset: 0x00091250
		private bool? ResolveIsReference(JsonContract contract, JsonProperty property, JsonContainerContract collectionContract, JsonProperty containerProperty)
		{
			bool? flag = null;
			if (property != null)
			{
				flag = property.IsReference;
			}
			if (flag == null && containerProperty != null)
			{
				flag = containerProperty.ItemIsReference;
			}
			if (flag == null && collectionContract != null)
			{
				flag = collectionContract.ItemIsReference;
			}
			if (flag == null)
			{
				flag = contract.IsReference;
			}
			return flag;
		}

		// Token: 0x0600257C RID: 9596 RVA: 0x000930A8 File Offset: 0x000912A8
		private bool ShouldWriteReference(object value, JsonProperty property, JsonContract valueContract, JsonContainerContract collectionContract, JsonProperty containerProperty)
		{
			if (value != null)
			{
				if (valueContract.ContractType != JsonContractType.Primitive)
				{
					if (valueContract.ContractType != JsonContractType.String)
					{
						bool? flag = this.ResolveIsReference(valueContract, property, collectionContract, containerProperty);
						if (flag == null)
						{
							if (valueContract.ContractType != JsonContractType.Array)
							{
								flag = new bool?(this.HasFlag(this.Serializer._preserveReferencesHandling, PreserveReferencesHandling.Objects));
							}
							else
							{
								flag = new bool?(this.HasFlag(this.Serializer._preserveReferencesHandling, PreserveReferencesHandling.Arrays));
							}
						}
						return flag.Value && this.Serializer.GetReferenceResolver().IsReferenced(this, value);
					}
				}
				return false;
			}
			return false;
		}

		// Token: 0x0600257D RID: 9597 RVA: 0x00093144 File Offset: 0x00091344
		private bool ShouldWriteProperty(object memberValue, JsonProperty property)
		{
			return (property.NullValueHandling.GetValueOrDefault(this.Serializer._nullValueHandling) != NullValueHandling.Ignore || memberValue != null) && (!this.HasFlag(property.DefaultValueHandling.GetValueOrDefault(this.Serializer._defaultValueHandling), DefaultValueHandling.Ignore) || !MiscellaneousUtils.ValueEquals(memberValue, property.GetResolvedDefaultValue()));
		}

		// Token: 0x0600257E RID: 9598 RVA: 0x000931A8 File Offset: 0x000913A8
		private bool CheckForCircularReference(JsonWriter writer, object value, JsonProperty property, JsonContract contract, JsonContainerContract containerContract, JsonProperty containerProperty)
		{
			if (value != null && contract.ContractType != JsonContractType.Primitive)
			{
				if (contract.ContractType != JsonContractType.String)
				{
					ReferenceLoopHandling? referenceLoopHandling = null;
					if (property != null)
					{
						referenceLoopHandling = property.ReferenceLoopHandling;
					}
					if (referenceLoopHandling == null && containerProperty != null)
					{
						referenceLoopHandling = containerProperty.ItemReferenceLoopHandling;
					}
					if (referenceLoopHandling == null && containerContract != null)
					{
						referenceLoopHandling = containerContract.ItemReferenceLoopHandling;
					}
					if ((this.Serializer._equalityComparer != null) ? this._serializeStack.Contains(value, this.Serializer._equalityComparer) : this._serializeStack.Contains(value))
					{
						string text = <Module>.smethod_26<string>(611401315U);
						if (property != null)
						{
							text = JsonSerializerInternalWriter.smethod_11(text, <Module>.smethod_27<string>(2377403502U).FormatWith(JsonSerializerInternalWriter.smethod_10(), property.PropertyName));
						}
						text = JsonSerializerInternalWriter.smethod_11(text, <Module>.smethod_26<string>(1153258040U).FormatWith(JsonSerializerInternalWriter.smethod_10(), JsonSerializerInternalWriter.smethod_9(value)));
						switch (referenceLoopHandling.GetValueOrDefault(this.Serializer._referenceLoopHandling))
						{
						case ReferenceLoopHandling.Error:
							throw JsonSerializationException.Create(null, writer.ContainerPath, text, null);
						case ReferenceLoopHandling.Ignore:
							if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Verbose)
							{
								this.TraceWriter.Trace(TraceLevel.Verbose, JsonPosition.FormatMessage(null, writer.Path, JsonSerializerInternalWriter.smethod_11(text, <Module>.smethod_23<string>(3838943194U))), null);
							}
							return false;
						case ReferenceLoopHandling.Serialize:
							if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Verbose)
							{
								this.TraceWriter.Trace(TraceLevel.Verbose, JsonPosition.FormatMessage(null, writer.Path, JsonSerializerInternalWriter.smethod_11(text, <Module>.smethod_27<string>(2418253655U))), null);
							}
							return true;
						}
					}
					return true;
				}
			}
			return true;
		}

		// Token: 0x0600257F RID: 9599 RVA: 0x00093358 File Offset: 0x00091558
		private void WriteReference(JsonWriter writer, object value)
		{
			string reference = this.GetReference(writer, value);
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Info)
			{
				this.TraceWriter.Trace(TraceLevel.Info, JsonPosition.FormatMessage(null, writer.Path, <Module>.smethod_23<string>(3433565565U).FormatWith(JsonSerializerInternalWriter.smethod_10(), reference, JsonSerializerInternalWriter.smethod_9(value))), null);
			}
			writer.WriteStartObject();
			writer.WritePropertyName(<Module>.smethod_25<string>(2099451988U), false);
			writer.WriteValue(reference);
			writer.WriteEndObject();
		}

		// Token: 0x06002580 RID: 9600 RVA: 0x000933DC File Offset: 0x000915DC
		private string GetReference(JsonWriter writer, object value)
		{
			string text;
			try
			{
				string reference = this.Serializer.GetReferenceResolver().GetReference(this, value);
				text = reference;
			}
			catch (Exception ex)
			{
				throw JsonSerializationException.Create(null, writer.ContainerPath, <Module>.smethod_24<string>(3714139415U).FormatWith(JsonSerializerInternalWriter.smethod_10(), JsonSerializerInternalWriter.smethod_9(value)), ex);
			}
			return text;
		}

		// Token: 0x06002581 RID: 9601 RVA: 0x0009343C File Offset: 0x0009163C
		internal static bool TryConvertToString(object value, Type type, out string s)
		{
			TypeConverter converter = ConvertUtils.GetConverter(type);
			if (converter != null && !(converter is ComponentConverter) && JsonSerializerInternalWriter.smethod_8(JsonSerializerInternalWriter.smethod_9(converter), JsonSerializerInternalWriter.smethod_12(typeof(TypeConverter).TypeHandle)) && JsonSerializerInternalWriter.smethod_13(converter, JsonSerializerInternalWriter.smethod_12(typeof(string).TypeHandle)))
			{
				s = JsonSerializerInternalWriter.smethod_14(converter, value);
				return true;
			}
			if (value is Type)
			{
				s = JsonSerializerInternalWriter.smethod_15((Type)value);
				return true;
			}
			s = null;
			return false;
		}

		// Token: 0x06002582 RID: 9602 RVA: 0x000934AC File Offset: 0x000916AC
		private void SerializeString(JsonWriter writer, object value, JsonStringContract contract)
		{
			this.OnSerializing(writer, contract, value);
			string text;
			JsonSerializerInternalWriter.TryConvertToString(value, contract.UnderlyingType, out text);
			writer.WriteValue(text);
			this.OnSerialized(writer, contract, value);
		}

		// Token: 0x06002583 RID: 9603 RVA: 0x000934E4 File Offset: 0x000916E4
		private void OnSerializing(JsonWriter writer, JsonContract contract, object value)
		{
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Info)
			{
				this.TraceWriter.Trace(TraceLevel.Info, JsonPosition.FormatMessage(null, writer.Path, <Module>.smethod_27<string>(879737786U).FormatWith(JsonSerializerInternalWriter.smethod_10(), contract.UnderlyingType)), null);
			}
			contract.InvokeOnSerializing(value, this.Serializer._context);
		}

		// Token: 0x06002584 RID: 9604 RVA: 0x0009354C File Offset: 0x0009174C
		private void OnSerialized(JsonWriter writer, JsonContract contract, object value)
		{
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Info)
			{
				this.TraceWriter.Trace(TraceLevel.Info, JsonPosition.FormatMessage(null, writer.Path, <Module>.smethod_23<string>(770389789U).FormatWith(JsonSerializerInternalWriter.smethod_10(), contract.UnderlyingType)), null);
			}
			contract.InvokeOnSerialized(value, this.Serializer._context);
		}

		// Token: 0x06002585 RID: 9605 RVA: 0x000935B4 File Offset: 0x000917B4
		private void SerializeObject(JsonWriter writer, object value, JsonObjectContract contract, JsonProperty member, JsonContainerContract collectionContract, JsonProperty containerProperty)
		{
			this.OnSerializing(writer, contract, value);
			this._serializeStack.Add(value);
			this.WriteObjectStart(writer, value, contract, member, collectionContract, containerProperty);
			int top = writer.Top;
			for (int i = 0; i < contract.Properties.Count; i++)
			{
				JsonProperty jsonProperty = contract.Properties[i];
				try
				{
					JsonContract jsonContract;
					object obj;
					if (this.CalculatePropertyValues(writer, value, contract, member, jsonProperty, out jsonContract, out obj))
					{
						jsonProperty.WritePropertyName(writer);
						this.SerializeValue(writer, obj, jsonContract, jsonProperty, contract, member);
					}
				}
				catch (Exception ex)
				{
					for (;;)
					{
						IL_00D1:
						int num = 568296289;
						for (;;)
						{
							switch (num ^ 568296293)
							{
							case 0:
								this.HandleError(writer, top);
								num = 568296292;
								continue;
							case 2:
								goto IL_00D8;
							case 3:
								goto IL_00D1;
							case 4:
								num = (base.IsErrorHandled(value, contract, jsonProperty.PropertyName, null, writer.ContainerPath, ex) ? 568296293 : 568296295);
								continue;
							}
							goto Block_9;
						}
					}
					Block_9:
					goto IL_00DA;
					IL_00D8:
					throw;
					IL_00DA:;
				}
			}
			if (contract.ExtensionDataGetter != null)
			{
				IEnumerable<KeyValuePair<object, object>> enumerable = contract.ExtensionDataGetter(value);
				if (enumerable != null)
				{
					IEnumerator<KeyValuePair<object, object>> enumerator = enumerable.GetEnumerator();
					try
					{
						while (JsonSerializerInternalWriter.smethod_16(enumerator))
						{
							KeyValuePair<object, object> keyValuePair = enumerator.Current;
							JsonContract contractSafe = this.GetContractSafe(keyValuePair.Key);
							JsonContract contractSafe2 = this.GetContractSafe(keyValuePair.Value);
							bool flag;
							string propertyName = this.GetPropertyName(writer, keyValuePair.Key, contractSafe, out flag);
							if (this.ShouldWriteReference(keyValuePair.Value, null, contractSafe2, contract, member))
							{
								writer.WritePropertyName(propertyName);
								this.WriteReference(writer, keyValuePair.Value);
							}
							else if (this.CheckForCircularReference(writer, keyValuePair.Value, null, contractSafe2, contract, member))
							{
								writer.WritePropertyName(propertyName);
								this.SerializeValue(writer, keyValuePair.Value, contractSafe2, null, contract, member);
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							JsonSerializerInternalWriter.smethod_17(enumerator);
						}
					}
				}
			}
			writer.WriteEndObject();
			this._serializeStack.RemoveAt(this._serializeStack.Count - 1);
			this.OnSerialized(writer, contract, value);
		}

		// Token: 0x06002586 RID: 9606 RVA: 0x000937CC File Offset: 0x000919CC
		private bool CalculatePropertyValues(JsonWriter writer, object value, JsonContainerContract contract, JsonProperty member, JsonProperty property, out JsonContract memberContract, out object memberValue)
		{
			if (!property.Ignored && property.Readable && this.ShouldSerialize(writer, property, value) && this.IsSpecified(writer, property, value))
			{
				if (property.PropertyContract == null)
				{
					property.PropertyContract = this.Serializer._contractResolver.ResolveContract(property.PropertyType);
				}
				memberValue = property.ValueProvider.GetValue(value);
				memberContract = (property.PropertyContract.IsSealed ? property.PropertyContract : this.GetContractSafe(memberValue));
				if (this.ShouldWriteProperty(memberValue, property))
				{
					if (this.ShouldWriteReference(memberValue, property, memberContract, contract, member))
					{
						property.WritePropertyName(writer);
						this.WriteReference(writer, memberValue);
						return false;
					}
					if (this.CheckForCircularReference(writer, memberValue, property, memberContract, contract, member))
					{
						if (memberValue == null)
						{
							JsonObjectContract jsonObjectContract = contract as JsonObjectContract;
							Required required = property._required ?? ((jsonObjectContract != null) ? jsonObjectContract.ItemRequired : null) ?? Required.Default;
							if (required == Required.Always)
							{
								throw JsonSerializationException.Create(null, writer.ContainerPath, <Module>.smethod_26<string>(3512212820U).FormatWith(JsonSerializerInternalWriter.smethod_10(), property.PropertyName), null);
							}
						}
						return true;
					}
					return false;
				}
			}
			memberContract = null;
			memberValue = null;
			return false;
		}

		// Token: 0x06002587 RID: 9607 RVA: 0x00093944 File Offset: 0x00091B44
		private void WriteObjectStart(JsonWriter writer, object value, JsonContract contract, JsonProperty member, JsonContainerContract collectionContract, JsonProperty containerProperty)
		{
			writer.WriteStartObject();
			if (this.ResolveIsReference(contract, member, collectionContract, containerProperty) ?? this.HasFlag(this.Serializer._preserveReferencesHandling, PreserveReferencesHandling.Objects))
			{
				632458588;
			}
			else
			{
				632458591;
			}
		}

		// Token: 0x06002588 RID: 9608 RVA: 0x00093998 File Offset: 0x00091B98
		private void WriteReferenceIdProperty(JsonWriter writer, Type type, object value)
		{
			string reference = this.GetReference(writer, value);
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Verbose)
			{
				this.TraceWriter.Trace(TraceLevel.Verbose, JsonPosition.FormatMessage(null, writer.Path, <Module>.smethod_27<string>(1293561483U).FormatWith(JsonSerializerInternalWriter.smethod_10(), reference, type)), null);
			}
			writer.WritePropertyName(<Module>.smethod_26<string>(1209226302U), false);
			writer.WriteValue(reference);
		}

		// Token: 0x06002589 RID: 9609 RVA: 0x00093A0C File Offset: 0x00091C0C
		private void WriteTypeProperty(JsonWriter writer, Type type)
		{
			string typeName = ReflectionUtils.GetTypeName(type, this.Serializer._typeNameAssemblyFormat, this.Serializer._binder);
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Verbose)
			{
				this.TraceWriter.Trace(TraceLevel.Verbose, JsonPosition.FormatMessage(null, writer.Path, <Module>.smethod_26<string>(2845862973U).FormatWith(JsonSerializerInternalWriter.smethod_10(), typeName, type)), null);
			}
			writer.WritePropertyName(<Module>.smethod_27<string>(3998518423U), false);
			writer.WriteValue(typeName);
		}

		// Token: 0x0600258A RID: 9610 RVA: 0x00017878 File Offset: 0x00015A78
		private bool HasFlag(DefaultValueHandling value, DefaultValueHandling flag)
		{
			return (value & flag) == flag;
		}

		// Token: 0x0600258B RID: 9611 RVA: 0x00017878 File Offset: 0x00015A78
		private bool HasFlag(PreserveReferencesHandling value, PreserveReferencesHandling flag)
		{
			return (value & flag) == flag;
		}

		// Token: 0x0600258C RID: 9612 RVA: 0x00017878 File Offset: 0x00015A78
		private bool HasFlag(TypeNameHandling value, TypeNameHandling flag)
		{
			return (value & flag) == flag;
		}

		// Token: 0x0600258D RID: 9613 RVA: 0x00093A94 File Offset: 0x00091C94
		private void SerializeConvertable(JsonWriter writer, JsonConverter converter, object value, JsonContract contract, JsonContainerContract collectionContract, JsonProperty containerProperty)
		{
			if (this.ShouldWriteReference(value, null, contract, collectionContract, containerProperty))
			{
				this.WriteReference(writer, value);
				return;
			}
			if (!this.CheckForCircularReference(writer, value, null, contract, collectionContract, containerProperty))
			{
				return;
			}
			this._serializeStack.Add(value);
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Info)
			{
				this.TraceWriter.Trace(TraceLevel.Info, JsonPosition.FormatMessage(null, writer.Path, <Module>.smethod_24<string>(3449927817U).FormatWith(JsonSerializerInternalWriter.smethod_10(), JsonSerializerInternalWriter.smethod_9(value), JsonSerializerInternalWriter.smethod_9(converter))), null);
			}
			converter.WriteJson(writer, value, this.GetInternalSerializer());
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Info)
			{
				this.TraceWriter.Trace(TraceLevel.Info, JsonPosition.FormatMessage(null, writer.Path, <Module>.smethod_25<string>(2728631743U).FormatWith(JsonSerializerInternalWriter.smethod_10(), JsonSerializerInternalWriter.smethod_9(value), JsonSerializerInternalWriter.smethod_9(converter))), null);
			}
			this._serializeStack.RemoveAt(this._serializeStack.Count - 1);
		}

		// Token: 0x0600258E RID: 9614 RVA: 0x00093B9C File Offset: 0x00091D9C
		private void SerializeList(JsonWriter writer, IEnumerable values, JsonArrayContract contract, JsonProperty member, JsonContainerContract collectionContract, JsonProperty containerProperty)
		{
			IWrappedCollection wrappedCollection = values as IWrappedCollection;
			object obj = ((wrappedCollection == null) ? values : wrappedCollection.UnderlyingCollection);
			this.OnSerializing(writer, contract, obj);
			this._serializeStack.Add(obj);
			bool flag = this.WriteStartArray(writer, obj, contract, member, collectionContract, containerProperty);
			writer.WriteStartArray();
			int top = writer.Top;
			int num = 0;
			IEnumerator enumerator = JsonSerializerInternalWriter.smethod_18(values);
			try
			{
				while (JsonSerializerInternalWriter.smethod_16(enumerator))
				{
					object obj2 = JsonSerializerInternalWriter.smethod_19(enumerator);
					try
					{
						JsonContract jsonContract = contract.FinalItemContract ?? this.GetContractSafe(obj2);
						if (this.ShouldWriteReference(obj2, null, jsonContract, contract, member))
						{
							this.WriteReference(writer, obj2);
						}
						else if (this.CheckForCircularReference(writer, obj2, null, jsonContract, contract, member))
						{
							this.SerializeValue(writer, obj2, jsonContract, null, contract, member);
						}
					}
					catch (Exception ex)
					{
						for (;;)
						{
							IL_0106:
							int num2 = 500879855;
							for (;;)
							{
								switch (num2 ^ 500879852)
								{
								case 0:
									num2 = 500879854;
									continue;
								case 1:
									goto IL_010D;
								case 3:
									if (base.IsErrorHandled(obj, contract, num, null, writer.ContainerPath, ex))
									{
										this.HandleError(writer, top);
										num2 = 500879852;
										continue;
									}
									goto IL_010D;
								case 4:
									goto IL_0106;
								}
								goto Block_13;
							}
						}
						Block_13:
						continue;
						IL_010D:
						throw;
					}
					finally
					{
						num++;
					}
				}
			}
			finally
			{
				IDisposable disposable = enumerator as IDisposable;
				if (disposable != null)
				{
					JsonSerializerInternalWriter.smethod_17(disposable);
				}
			}
			writer.WriteEndArray();
			if (flag)
			{
				writer.WriteEndObject();
			}
			this._serializeStack.RemoveAt(this._serializeStack.Count - 1);
			this.OnSerialized(writer, contract, obj);
		}

		// Token: 0x0600258F RID: 9615 RVA: 0x00093D40 File Offset: 0x00091F40
		private void SerializeMultidimensionalArray(JsonWriter writer, Array values, JsonArrayContract contract, JsonProperty member, JsonContainerContract collectionContract, JsonProperty containerProperty)
		{
			this.OnSerializing(writer, contract, values);
			this._serializeStack.Add(values);
			bool flag = this.WriteStartArray(writer, values, contract, member, collectionContract, containerProperty);
			this.SerializeMultidimensionalArray(writer, values, contract, member, writer.Top, new int[0]);
			if (flag)
			{
				writer.WriteEndObject();
			}
			this._serializeStack.RemoveAt(this._serializeStack.Count - 1);
			this.OnSerialized(writer, contract, values);
		}

		// Token: 0x06002590 RID: 9616 RVA: 0x00093DB4 File Offset: 0x00091FB4
		private void SerializeMultidimensionalArray(JsonWriter writer, Array values, JsonArrayContract contract, JsonProperty member, int initialDepth, int[] indices)
		{
			int num = indices.Length;
			int[] array = new int[num + 1];
			for (int i = 0; i < num; i++)
			{
				array[i] = indices[i];
			}
			writer.WriteStartArray();
			int j = 0;
			while (j < JsonSerializerInternalWriter.smethod_22(values, num))
			{
				array[num] = j;
				if (array.Length == JsonSerializerInternalWriter.smethod_20(values))
				{
					object obj = JsonSerializerInternalWriter.smethod_21(values, array);
					try
					{
						JsonContract jsonContract = contract.FinalItemContract ?? this.GetContractSafe(obj);
						if (this.ShouldWriteReference(obj, null, jsonContract, contract, member))
						{
							this.WriteReference(writer, obj);
						}
						else if (this.CheckForCircularReference(writer, obj, null, jsonContract, contract, member))
						{
							this.SerializeValue(writer, obj, jsonContract, null, contract, member);
						}
						goto IL_010B;
					}
					catch (Exception ex)
					{
						if (base.IsErrorHandled(values, contract, j, null, writer.ContainerPath, ex))
						{
							this.HandleError(writer, initialDepth + 1);
							for (;;)
							{
								IL_00F0:
								int num2 = -1900409211;
								for (;;)
								{
									switch (num2 ^ -1900409212)
									{
									case 0:
										goto IL_00F7;
									case 1:
										num2 = -1900409209;
										continue;
									case 2:
										goto IL_00F0;
									}
									goto Block_11;
								}
							}
							Block_11:
							goto IL_010B;
						}
						IL_00F7:
						throw;
					}
					goto IL_00FB;
				}
				goto IL_00FB;
				IL_010B:
				j++;
				continue;
				IL_00FB:
				this.SerializeMultidimensionalArray(writer, values, contract, member, initialDepth + 1, array);
				goto IL_010B;
			}
			writer.WriteEndArray();
		}

		// Token: 0x06002591 RID: 9617 RVA: 0x00093EEC File Offset: 0x000920EC
		private bool WriteStartArray(JsonWriter writer, object values, JsonArrayContract contract, JsonProperty member, JsonContainerContract containerContract, JsonProperty containerProperty)
		{
			bool? flag = this.ResolveIsReference(contract, member, containerContract, containerProperty);
			bool flag2;
			if (flag != null)
			{
				flag2 = flag.GetValueOrDefault();
				goto IL_0107;
			}
			goto IL_01BA;
			int num;
			bool flag5;
			for (;;)
			{
				IL_016D:
				bool flag3;
				bool flag4;
				bool flag6;
				bool flag7;
				switch (num ^ -1621088337)
				{
				case 0:
					if (member != null)
					{
						num = -1621088351;
						continue;
					}
					flag3 = true;
					goto IL_0044;
				case 1:
					if (flag4)
					{
						this.WriteTypeProperty(writer, JsonSerializerInternalWriter.smethod_9(values));
						num = -1621088346;
						continue;
					}
					goto IL_00A9;
				case 2:
					writer.WriteStartObject();
					num = -1621088352;
					continue;
				case 3:
					num = ((contract.ItemContract == null) ? (-1621088345) : (-1621088341));
					continue;
				case 5:
					if (flag5)
					{
						num = -1621088337;
						continue;
					}
					flag3 = false;
					goto IL_0044;
				case 6:
					goto IL_01BA;
				case 7:
					goto IL_00F5;
				case 8:
					contract.ItemContract = this.Serializer._contractResolver.ResolveContract(contract.CollectionItemType ?? JsonSerializerInternalWriter.smethod_12(typeof(object).TypeHandle));
					num = -1621088341;
					continue;
				case 9:
					goto IL_00A9;
				case 10:
					num = (flag6 ? (-1621088339) : (-1621088340));
					continue;
				case 11:
					this.WriteReferenceIdProperty(writer, contract.UnderlyingType, values);
					num = -1621088338;
					continue;
				case 12:
					if (!flag5)
					{
						num = -1621088350;
						continue;
					}
					flag7 = true;
					goto IL_005F;
				case 13:
					flag7 = flag4;
					goto IL_005F;
				case 14:
					flag3 = member.Writable;
					goto IL_0044;
				case 15:
					num = (flag5 ? (-1621088348) : (-1621088338));
					continue;
				}
				return flag6;
				IL_0044:
				flag5 = flag3;
				flag4 = this.ShouldWriteType(TypeNameHandling.Arrays, contract, member, containerContract, containerProperty);
				num = -1621088349;
				continue;
				IL_005F:
				flag6 = flag7;
				num = -1621088347;
				continue;
				IL_00A9:
				writer.WritePropertyName(<Module>.smethod_26<string>(2920893197U), false);
				num = -1621088340;
			}
			IL_00F5:
			flag2 = this.HasFlag(this.Serializer._preserveReferencesHandling, PreserveReferencesHandling.Arrays);
			IL_0107:
			flag5 = flag2;
			num = -1621088342;
			goto IL_016D;
			IL_01BA:
			num = -1621088344;
			goto IL_016D;
		}

		// Token: 0x06002592 RID: 9618 RVA: 0x000940BC File Offset: 0x000922BC
		[SecuritySafeCritical]
		private void SerializeISerializable(JsonWriter writer, ISerializable value, JsonISerializableContract contract, JsonProperty member, JsonContainerContract collectionContract, JsonProperty containerProperty)
		{
			if (!JsonTypeReflector.FullyTrusted)
			{
				string text = JsonSerializerInternalWriter.smethod_24(<Module>.smethod_24<string>(198089329U), JsonSerializerInternalWriter.smethod_23(), <Module>.smethod_24<string>(3338146846U), JsonSerializerInternalWriter.smethod_23());
				text = text.FormatWith(JsonSerializerInternalWriter.smethod_10(), JsonSerializerInternalWriter.smethod_9(value));
				throw JsonSerializationException.Create(null, writer.ContainerPath, text, null);
			}
			this.OnSerializing(writer, contract, value);
			this._serializeStack.Add(value);
			this.WriteObjectStart(writer, value, contract, member, collectionContract, containerProperty);
			SerializationInfo serializationInfo = JsonSerializerInternalWriter.smethod_26(contract.UnderlyingType, JsonSerializerInternalWriter.smethod_25());
			JsonSerializerInternalWriter.smethod_27(value, serializationInfo, this.Serializer._context);
			SerializationInfoEnumerator serializationInfoEnumerator = JsonSerializerInternalWriter.smethod_28(serializationInfo);
			while (serializationInfoEnumerator.MoveNext())
			{
				SerializationEntry serializationEntry = JsonSerializerInternalWriter.smethod_29(serializationInfoEnumerator);
				JsonContract contractSafe = this.GetContractSafe(serializationEntry.Value);
				if (this.ShouldWriteReference(serializationEntry.Value, null, contractSafe, contract, member))
				{
					writer.WritePropertyName(serializationEntry.Name);
					this.WriteReference(writer, serializationEntry.Value);
				}
				else if (this.CheckForCircularReference(writer, serializationEntry.Value, null, contractSafe, contract, member))
				{
					writer.WritePropertyName(serializationEntry.Name);
					this.SerializeValue(writer, serializationEntry.Value, contractSafe, null, contract, member);
				}
			}
			writer.WriteEndObject();
			this._serializeStack.RemoveAt(this._serializeStack.Count - 1);
			this.OnSerialized(writer, contract, value);
		}

		// Token: 0x06002593 RID: 9619 RVA: 0x00094218 File Offset: 0x00092418
		private void SerializeDynamic(JsonWriter writer, IDynamicMetaObjectProvider value, JsonDynamicContract contract, JsonProperty member, JsonContainerContract collectionContract, JsonProperty containerProperty)
		{
			this.OnSerializing(writer, contract, value);
			this._serializeStack.Add(value);
			this.WriteObjectStart(writer, value, contract, member, collectionContract, containerProperty);
			int top = writer.Top;
			for (int i = 0; i < contract.Properties.Count; i++)
			{
				JsonProperty jsonProperty = contract.Properties[i];
				if (jsonProperty.HasMemberAttribute)
				{
					try
					{
						JsonContract jsonContract;
						object obj;
						if (this.CalculatePropertyValues(writer, value, contract, member, jsonProperty, out jsonContract, out obj))
						{
							jsonProperty.WritePropertyName(writer);
							this.SerializeValue(writer, obj, jsonContract, jsonProperty, contract, member);
						}
					}
					catch (Exception ex)
					{
						for (;;)
						{
							IL_00D5:
							int num = 1842793960;
							for (;;)
							{
								switch (num ^ 1842793963)
								{
								case 0:
									num = 1842793967;
									continue;
								case 1:
									goto IL_00DC;
								case 2:
									goto IL_00D5;
								case 3:
									if (base.IsErrorHandled(value, contract, jsonProperty.PropertyName, null, writer.ContainerPath, ex))
									{
										this.HandleError(writer, top);
										num = 1842793963;
										continue;
									}
									goto IL_00DC;
								}
								goto Block_7;
							}
						}
						Block_7:
						goto IL_00DE;
						IL_00DC:
						throw;
						IL_00DE:;
					}
				}
			}
			IEnumerator<string> enumerator = value.GetDynamicMemberNames().GetEnumerator();
			try
			{
				while (JsonSerializerInternalWriter.smethod_16(enumerator))
				{
					string text = enumerator.Current;
					object obj2;
					if (contract.TryGetMember(value, text, out obj2))
					{
						try
						{
							JsonContract contractSafe = this.GetContractSafe(obj2);
							for (;;)
							{
								IL_01B4:
								int num2 = 1842793962;
								for (;;)
								{
									switch (num2 ^ 1842793963)
									{
									case 1:
										if (this.ShouldWriteDynamicProperty(obj2))
										{
											goto IL_0124;
										}
										break;
									case 2:
										goto IL_01B4;
									case 3:
									{
										string text2 = ((contract.PropertyNameResolver != null) ? contract.PropertyNameResolver(text) : text);
										writer.WritePropertyName(text2);
										num2 = 1842793967;
										continue;
									}
									case 4:
										this.SerializeValue(writer, obj2, contractSafe, null, contract, member);
										num2 = 1842793963;
										continue;
									case 5:
										goto IL_0124;
									}
									goto Block_16;
									IL_0124:
									num2 = (this.CheckForCircularReference(writer, obj2, null, contractSafe, contract, member) ? 1842793960 : 1842793963);
								}
							}
							Block_16:;
						}
						catch (Exception ex2)
						{
							for (;;)
							{
								IL_0221:
								int num3 = 1842793962;
								for (;;)
								{
									switch (num3 ^ 1842793963)
									{
									case 0:
										num3 = 1842793960;
										continue;
									case 1:
										num3 = ((!base.IsErrorHandled(value, contract, text, null, writer.ContainerPath, ex2)) ? 1842793967 : 1842793961);
										continue;
									case 2:
										this.HandleError(writer, top);
										num3 = 1842793963;
										continue;
									case 4:
										goto IL_0228;
									case 5:
										goto IL_0221;
									}
									goto Block_18;
								}
							}
							Block_18:
							continue;
							IL_0228:
							throw;
						}
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JsonSerializerInternalWriter.smethod_17(enumerator);
				}
			}
			writer.WriteEndObject();
			this._serializeStack.RemoveAt(this._serializeStack.Count - 1);
			this.OnSerialized(writer, contract, value);
		}

		// Token: 0x06002594 RID: 9620 RVA: 0x000944E0 File Offset: 0x000926E0
		private bool ShouldWriteDynamicProperty(object memberValue)
		{
			return (this.Serializer._nullValueHandling != NullValueHandling.Ignore || memberValue != null) && (!this.HasFlag(this.Serializer._defaultValueHandling, DefaultValueHandling.Ignore) || (memberValue != null && !MiscellaneousUtils.ValueEquals(memberValue, ReflectionUtils.GetDefaultValue(JsonSerializerInternalWriter.smethod_9(memberValue)))));
		}

		// Token: 0x06002595 RID: 9621 RVA: 0x00094530 File Offset: 0x00092730
		private bool ShouldWriteType(TypeNameHandling typeNameHandlingFlag, JsonContract contract, JsonProperty member, JsonContainerContract containerContract, JsonProperty containerProperty)
		{
			TypeNameHandling typeNameHandling = ((member == null) ? null : member.TypeNameHandling) ?? ((containerProperty != null) ? containerProperty.ItemTypeNameHandling : null) ?? ((containerContract != null) ? containerContract.ItemTypeNameHandling : null) ?? this.Serializer._typeNameHandling;
			if (this.HasFlag(typeNameHandling, typeNameHandlingFlag))
			{
				return true;
			}
			if (this.HasFlag(typeNameHandling, TypeNameHandling.Auto))
			{
				if (member != null)
				{
					if (JsonSerializerInternalWriter.smethod_8(contract.UnderlyingType, member.PropertyContract.CreatedType))
					{
						return true;
					}
				}
				else if (containerContract != null)
				{
					if (containerContract.ItemContract == null || JsonSerializerInternalWriter.smethod_8(contract.UnderlyingType, containerContract.ItemContract.CreatedType))
					{
						return true;
					}
				}
				else if (this._rootContract != null && this._serializeStack.Count == this._rootLevel && JsonSerializerInternalWriter.smethod_8(contract.UnderlyingType, this._rootContract.CreatedType))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x06002596 RID: 9622 RVA: 0x00094658 File Offset: 0x00092858
		private void SerializeDictionary(JsonWriter writer, IDictionary values, JsonDictionaryContract contract, JsonProperty member, JsonContainerContract collectionContract, JsonProperty containerProperty)
		{
			IWrappedDictionary wrappedDictionary = values as IWrappedDictionary;
			object obj = ((wrappedDictionary != null) ? wrappedDictionary.UnderlyingDictionary : values);
			this.OnSerializing(writer, contract, obj);
			this._serializeStack.Add(obj);
			this.WriteObjectStart(writer, obj, contract, member, collectionContract, containerProperty);
			if (contract.ItemContract == null)
			{
				contract.ItemContract = this.Serializer._contractResolver.ResolveContract(contract.DictionaryValueType ?? JsonSerializerInternalWriter.smethod_12(typeof(object).TypeHandle));
			}
			if (contract.KeyContract == null)
			{
				contract.KeyContract = this.Serializer._contractResolver.ResolveContract(contract.DictionaryKeyType ?? JsonSerializerInternalWriter.smethod_12(typeof(object).TypeHandle));
			}
			int top = writer.Top;
			using (IDictionaryEnumerator dictionaryEnumerator = JsonSerializerInternalWriter.smethod_30(values))
			{
				while (dictionaryEnumerator.MoveNext())
				{
					DictionaryEntry dictionaryEntry = (DictionaryEntry)JsonSerializerInternalWriter.smethod_19(dictionaryEnumerator);
					bool flag;
					string text = this.GetPropertyName(writer, dictionaryEntry.Key, contract.KeyContract, out flag);
					text = ((contract.DictionaryKeyResolver != null) ? contract.DictionaryKeyResolver(text) : text);
					try
					{
						object value = dictionaryEntry.Value;
						JsonContract jsonContract = contract.FinalItemContract ?? this.GetContractSafe(value);
						if (this.ShouldWriteReference(value, null, jsonContract, contract, member))
						{
							writer.WritePropertyName(text, flag);
							this.WriteReference(writer, value);
						}
						else if (this.CheckForCircularReference(writer, value, null, jsonContract, contract, member))
						{
							writer.WritePropertyName(text, flag);
							this.SerializeValue(writer, value, jsonContract, null, contract, member);
						}
					}
					catch (Exception ex)
					{
						if (base.IsErrorHandled(obj, contract, text, null, writer.ContainerPath, ex))
						{
							for (;;)
							{
								IL_01A5:
								int num = 1891002437;
								for (;;)
								{
									switch (num ^ 1891002438)
									{
									case 0:
										goto IL_01A5;
									case 2:
										goto IL_01AC;
									case 3:
										this.HandleError(writer, top);
										num = 1891002439;
										continue;
									}
									goto Block_17;
								}
							}
							Block_17:
							continue;
						}
						IL_01AC:
						throw;
					}
				}
			}
			writer.WriteEndObject();
			this._serializeStack.RemoveAt(this._serializeStack.Count - 1);
			this.OnSerialized(writer, contract, obj);
		}

		// Token: 0x06002597 RID: 9623 RVA: 0x00094894 File Offset: 0x00092A94
		private string GetPropertyName(JsonWriter writer, object name, JsonContract contract, out bool escape)
		{
			if (contract.ContractType == JsonContractType.Primitive)
			{
				JsonPrimitiveContract jsonPrimitiveContract = (JsonPrimitiveContract)contract;
				if (jsonPrimitiveContract.TypeCode != PrimitiveTypeCode.DateTime)
				{
					if (jsonPrimitiveContract.TypeCode != PrimitiveTypeCode.DateTimeNullable)
					{
						if (jsonPrimitiveContract.TypeCode != PrimitiveTypeCode.DateTimeOffset)
						{
							if (jsonPrimitiveContract.TypeCode != PrimitiveTypeCode.DateTimeOffsetNullable)
							{
								escape = true;
								return JsonSerializerInternalWriter.smethod_33(name, JsonSerializerInternalWriter.smethod_10());
							}
						}
						escape = false;
						StringWriter stringWriter = JsonSerializerInternalWriter.smethod_31(JsonSerializerInternalWriter.smethod_10());
						DateTimeUtils.WriteDateTimeOffsetString(stringWriter, (DateTimeOffset)name, writer.DateFormatHandling, writer.DateFormatString, writer.Culture);
						return JsonSerializerInternalWriter.smethod_32(stringWriter);
					}
				}
				escape = false;
				StringWriter stringWriter2 = JsonSerializerInternalWriter.smethod_31(JsonSerializerInternalWriter.smethod_10());
				DateTimeUtils.WriteDateTimeString(stringWriter2, (DateTime)name, writer.DateFormatHandling, writer.DateFormatString, writer.Culture);
				return JsonSerializerInternalWriter.smethod_32(stringWriter2);
			}
			string text;
			if (JsonSerializerInternalWriter.TryConvertToString(name, JsonSerializerInternalWriter.smethod_9(name), out text))
			{
				escape = true;
				return text;
			}
			escape = true;
			return JsonSerializerInternalWriter.smethod_32(name);
		}

		// Token: 0x06002598 RID: 9624 RVA: 0x0001DAC4 File Offset: 0x0001BCC4
		private void HandleError(JsonWriter writer, int initialDepth)
		{
			base.ClearErrorContext();
			if (writer.WriteState == WriteState.Property)
			{
				writer.WriteNull();
			}
			while (writer.Top > initialDepth)
			{
				writer.WriteEnd();
			}
		}

		// Token: 0x06002599 RID: 9625 RVA: 0x00094978 File Offset: 0x00092B78
		private bool ShouldSerialize(JsonWriter writer, JsonProperty property, object target)
		{
			if (property.ShouldSerialize != null)
			{
				bool flag = property.ShouldSerialize(target);
				if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Verbose)
				{
					this.TraceWriter.Trace(TraceLevel.Verbose, JsonPosition.FormatMessage(null, writer.Path, <Module>.smethod_23<string>(3325821317U).FormatWith(JsonSerializerInternalWriter.smethod_10(), property.PropertyName, property.DeclaringType, flag)), null);
				}
				return flag;
			}
			return true;
		}

		// Token: 0x0600259A RID: 9626 RVA: 0x000949F4 File Offset: 0x00092BF4
		private bool IsSpecified(JsonWriter writer, JsonProperty property, object target)
		{
			if (property.GetIsSpecified == null)
			{
				return true;
			}
			bool flag = property.GetIsSpecified(target);
			if (this.TraceWriter != null && this.TraceWriter.LevelFilter >= TraceLevel.Verbose)
			{
				this.TraceWriter.Trace(TraceLevel.Verbose, JsonPosition.FormatMessage(null, writer.Path, <Module>.smethod_25<string>(3642771715U).FormatWith(JsonSerializerInternalWriter.smethod_10(), property.PropertyName, property.DeclaringType, flag)), null);
			}
			return flag;
		}

		// Token: 0x0600259B RID: 9627 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_7(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x0600259C RID: 9628 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_8(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x0600259D RID: 9629 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_9(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x0600259E RID: 9630 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_10()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x0600259F RID: 9631 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_11(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x060025A0 RID: 9632 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_12(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060025A1 RID: 9633 RVA: 0x0001CAAC File Offset: 0x0001ACAC
		static bool smethod_13(TypeConverter typeConverter_0, Type type_0)
		{
			return typeConverter_0.CanConvertTo(type_0);
		}

		// Token: 0x060025A2 RID: 9634 RVA: 0x0001DAEE File Offset: 0x0001BCEE
		static string smethod_14(TypeConverter typeConverter_0, object object_0)
		{
			return typeConverter_0.ConvertToInvariantString(object_0);
		}

		// Token: 0x060025A3 RID: 9635 RVA: 0x0001D68F File Offset: 0x0001B88F
		static string smethod_15(Type type_0)
		{
			return type_0.AssemblyQualifiedName;
		}

		// Token: 0x060025A4 RID: 9636 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_16(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060025A5 RID: 9637 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_17(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060025A6 RID: 9638 RVA: 0x0000DAD6 File Offset: 0x0000BCD6
		static IEnumerator smethod_18(IEnumerable ienumerable_0)
		{
			return ienumerable_0.GetEnumerator();
		}

		// Token: 0x060025A7 RID: 9639 RVA: 0x0000D8E2 File Offset: 0x0000BAE2
		static object smethod_19(IEnumerator ienumerator_0)
		{
			return ienumerator_0.Current;
		}

		// Token: 0x060025A8 RID: 9640 RVA: 0x0001DAF7 File Offset: 0x0001BCF7
		static int smethod_20(Array array_0)
		{
			return array_0.Rank;
		}

		// Token: 0x060025A9 RID: 9641 RVA: 0x0001DAFF File Offset: 0x0001BCFF
		static object smethod_21(Array array_0, int[] int_0)
		{
			return array_0.GetValue(int_0);
		}

		// Token: 0x060025AA RID: 9642 RVA: 0x00010011 File Offset: 0x0000E211
		static int smethod_22(Array array_0, int int_0)
		{
			return array_0.GetLength(int_0);
		}

		// Token: 0x060025AB RID: 9643 RVA: 0x0000CD86 File Offset: 0x0000AF86
		static string smethod_23()
		{
			return Environment.NewLine;
		}

		// Token: 0x060025AC RID: 9644 RVA: 0x0001DA02 File Offset: 0x0001BC02
		static string smethod_24(string string_0, string string_1, string string_2, string string_3)
		{
			return string_0 + string_1 + string_2 + string_3;
		}

		// Token: 0x060025AD RID: 9645 RVA: 0x0001DB08 File Offset: 0x0001BD08
		static FormatterConverter smethod_25()
		{
			return new FormatterConverter();
		}

		// Token: 0x060025AE RID: 9646 RVA: 0x0001DA44 File Offset: 0x0001BC44
		static SerializationInfo smethod_26(Type type_0, IFormatterConverter iformatterConverter_0)
		{
			return new SerializationInfo(type_0, iformatterConverter_0);
		}

		// Token: 0x060025AF RID: 9647 RVA: 0x0001DB0F File Offset: 0x0001BD0F
		static void smethod_27(ISerializable iserializable_0, SerializationInfo serializationInfo_0, StreamingContext streamingContext_0)
		{
			iserializable_0.GetObjectData(serializationInfo_0, streamingContext_0);
		}

		// Token: 0x060025B0 RID: 9648 RVA: 0x0001DB19 File Offset: 0x0001BD19
		static SerializationInfoEnumerator smethod_28(SerializationInfo serializationInfo_0)
		{
			return serializationInfo_0.GetEnumerator();
		}

		// Token: 0x060025B1 RID: 9649 RVA: 0x0001DB21 File Offset: 0x0001BD21
		static SerializationEntry smethod_29(SerializationInfoEnumerator serializationInfoEnumerator_0)
		{
			return serializationInfoEnumerator_0.Current;
		}

		// Token: 0x060025B2 RID: 9650 RVA: 0x0001DA57 File Offset: 0x0001BC57
		static IDictionaryEnumerator smethod_30(IDictionary idictionary_0)
		{
			return idictionary_0.GetEnumerator();
		}

		// Token: 0x060025B3 RID: 9651 RVA: 0x00016261 File Offset: 0x00014461
		static StringWriter smethod_31(IFormatProvider iformatProvider_0)
		{
			return new StringWriter(iformatProvider_0);
		}

		// Token: 0x060025B4 RID: 9652 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_32(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x060025B5 RID: 9653 RVA: 0x00018E7F File Offset: 0x0001707F
		static string smethod_33(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToString(object_0, iformatProvider_0);
		}

		// Token: 0x04000D5C RID: 3420
		private JsonContract _rootContract;

		// Token: 0x04000D5D RID: 3421
		private int _rootLevel;

		// Token: 0x04000D5E RID: 3422
		private readonly List<object> _serializeStack = new List<object>();
	}
}
