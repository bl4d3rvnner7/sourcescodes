﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Dynamic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Threading;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000256 RID: 598
	public class DefaultContractResolver : IContractResolver
	{
		// Token: 0x17000533 RID: 1331
		// (get) Token: 0x06002301 RID: 8961 RVA: 0x0001C8F8 File Offset: 0x0001AAF8
		internal static IContractResolver Instance
		{
			get
			{
				return DefaultContractResolver._instance;
			}
		}

		// Token: 0x17000534 RID: 1332
		// (get) Token: 0x06002302 RID: 8962 RVA: 0x0001C8FF File Offset: 0x0001AAFF
		public bool DynamicCodeGeneration
		{
			get
			{
				return JsonTypeReflector.DynamicCodeGeneration;
			}
		}

		// Token: 0x17000535 RID: 1333
		// (get) Token: 0x06002303 RID: 8963 RVA: 0x0001C906 File Offset: 0x0001AB06
		// (set) Token: 0x06002304 RID: 8964 RVA: 0x0001C90E File Offset: 0x0001AB0E
		[Obsolete("DefaultMembersSearchFlags is obsolete. To modify the members serialized inherit from DefaultContractResolver and override the GetSerializableMembers method instead.")]
		public BindingFlags DefaultMembersSearchFlags { get; set; }

		// Token: 0x17000536 RID: 1334
		// (get) Token: 0x06002305 RID: 8965 RVA: 0x0001C917 File Offset: 0x0001AB17
		// (set) Token: 0x06002306 RID: 8966 RVA: 0x0001C91F File Offset: 0x0001AB1F
		public bool SerializeCompilerGeneratedMembers { get; set; }

		// Token: 0x17000537 RID: 1335
		// (get) Token: 0x06002307 RID: 8967 RVA: 0x0001C928 File Offset: 0x0001AB28
		// (set) Token: 0x06002308 RID: 8968 RVA: 0x0001C930 File Offset: 0x0001AB30
		public bool IgnoreSerializableInterface { get; set; }

		// Token: 0x17000538 RID: 1336
		// (get) Token: 0x06002309 RID: 8969 RVA: 0x0001C939 File Offset: 0x0001AB39
		// (set) Token: 0x0600230A RID: 8970 RVA: 0x0001C941 File Offset: 0x0001AB41
		public bool IgnoreSerializableAttribute { get; set; }

		// Token: 0x0600230B RID: 8971 RVA: 0x0001C94A File Offset: 0x0001AB4A
		public DefaultContractResolver()
		{
			this.DefaultMembersSearchFlags = BindingFlags.Instance | BindingFlags.Public;
			this.IgnoreSerializableAttribute = true;
		}

		// Token: 0x0600230C RID: 8972 RVA: 0x0001C96C File Offset: 0x0001AB6C
		[Obsolete("DefaultContractResolver(bool) is obsolete. Use the parameterless constructor and cache instances of the contract resolver within your application for optimal performance.")]
		public DefaultContractResolver(bool shareCache)
			: this()
		{
			this._sharedCache = shareCache;
		}

		// Token: 0x0600230D RID: 8973 RVA: 0x0001C97B File Offset: 0x0001AB7B
		internal DefaultContractResolverState GetState()
		{
			if (this._sharedCache)
			{
				return DefaultContractResolver._sharedState;
			}
			return this._instanceState;
		}

		// Token: 0x0600230E RID: 8974 RVA: 0x0008AC5C File Offset: 0x00088E5C
		public virtual JsonContract ResolveContract(Type type)
		{
			if (DefaultContractResolver.smethod_0(type, null))
			{
				throw DefaultContractResolver.smethod_1(<Module>.smethod_23<string>(2780933721U));
			}
			DefaultContractResolverState state = this.GetState();
			ResolverContractKey resolverContractKey = new ResolverContractKey(DefaultContractResolver.smethod_2(this), type);
			Dictionary<ResolverContractKey, JsonContract> dictionary = state.ContractCache;
			JsonContract jsonContract;
			if (dictionary == null || !dictionary.TryGetValue(resolverContractKey, out jsonContract))
			{
				jsonContract = this.CreateContract(type);
				bool flag = false;
				try
				{
					object typeContractCacheLock;
					DefaultContractResolver.smethod_3(typeContractCacheLock = DefaultContractResolver.TypeContractCacheLock, ref flag);
					dictionary = state.ContractCache;
					Dictionary<ResolverContractKey, JsonContract> dictionary2 = ((dictionary != null) ? new Dictionary<ResolverContractKey, JsonContract>(dictionary) : new Dictionary<ResolverContractKey, JsonContract>());
					dictionary2[resolverContractKey] = jsonContract;
					state.ContractCache = dictionary2;
				}
				finally
				{
					if (flag)
					{
						object typeContractCacheLock;
						DefaultContractResolver.smethod_4(typeContractCacheLock);
					}
				}
			}
			return jsonContract;
		}

		// Token: 0x0600230F RID: 8975 RVA: 0x0008AD10 File Offset: 0x00088F10
		protected virtual List<MemberInfo> GetSerializableMembers(Type objectType)
		{
			bool ignoreSerializableAttribute = this.IgnoreSerializableAttribute;
			MemberSerialization objectMemberSerialization = JsonTypeReflector.GetObjectMemberSerialization(objectType, ignoreSerializableAttribute);
			List<MemberInfo> list = (from m in ReflectionUtils.GetFieldsAndProperties(objectType, BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)
				where !ReflectionUtils.IsIndexedProperty(m)
				select m).ToList<MemberInfo>();
			List<MemberInfo> list2 = new List<MemberInfo>();
			if (objectMemberSerialization != MemberSerialization.Fields)
			{
				DataContractAttribute dataContractAttribute = JsonTypeReflector.GetDataContractAttribute(objectType);
				List<MemberInfo> list3 = (from m in ReflectionUtils.GetFieldsAndProperties(objectType, this.DefaultMembersSearchFlags)
					where !ReflectionUtils.IsIndexedProperty(m)
					select m).ToList<MemberInfo>();
				foreach (MemberInfo memberInfo in list)
				{
					if (this.SerializeCompilerGeneratedMembers || !DefaultContractResolver.smethod_6(memberInfo, DefaultContractResolver.smethod_5(typeof(CompilerGeneratedAttribute).TypeHandle), true))
					{
						if (list3.Contains(memberInfo))
						{
							list2.Add(memberInfo);
						}
						else if (JsonTypeReflector.GetAttribute<JsonPropertyAttribute>(memberInfo) != null)
						{
							list2.Add(memberInfo);
						}
						else if (JsonTypeReflector.GetAttribute<JsonRequiredAttribute>(memberInfo) != null)
						{
							list2.Add(memberInfo);
						}
						else if (dataContractAttribute != null && JsonTypeReflector.GetAttribute<DataMemberAttribute>(memberInfo) != null)
						{
							list2.Add(memberInfo);
						}
						else if (objectMemberSerialization == MemberSerialization.Fields && memberInfo.MemberType() == MemberTypes.Field)
						{
							list2.Add(memberInfo);
						}
					}
				}
				Type type;
				if (objectType.AssignableToTypeName(<Module>.smethod_23<string>(2985522331U), out type))
				{
					list2 = list2.Where(new Func<MemberInfo, bool>(this.ShouldSerializeEntityMember)).ToList<MemberInfo>();
				}
			}
			else
			{
				foreach (MemberInfo memberInfo2 in list)
				{
					FieldInfo fieldInfo = memberInfo2 as FieldInfo;
					if (DefaultContractResolver.smethod_7(fieldInfo, null) && !DefaultContractResolver.smethod_8(fieldInfo))
					{
						list2.Add(memberInfo2);
					}
				}
			}
			return list2;
		}

		// Token: 0x06002310 RID: 8976 RVA: 0x0008AEFC File Offset: 0x000890FC
		private bool ShouldSerializeEntityMember(MemberInfo memberInfo)
		{
			PropertyInfo propertyInfo = memberInfo as PropertyInfo;
			return !DefaultContractResolver.smethod_9(propertyInfo, null) || !DefaultContractResolver.smethod_10(propertyInfo).IsGenericType() || !DefaultContractResolver.smethod_13(DefaultContractResolver.smethod_12(DefaultContractResolver.smethod_11(DefaultContractResolver.smethod_10(propertyInfo))), <Module>.smethod_23<string>(1321243063U));
		}

		// Token: 0x06002311 RID: 8977 RVA: 0x0008AF4C File Offset: 0x0008914C
		protected virtual JsonObjectContract CreateObjectContract(Type objectType)
		{
			JsonObjectContract jsonObjectContract = new JsonObjectContract(objectType);
			this.InitializeContract(jsonObjectContract);
			bool ignoreSerializableAttribute = this.IgnoreSerializableAttribute;
			jsonObjectContract.MemberSerialization = JsonTypeReflector.GetObjectMemberSerialization(jsonObjectContract.NonNullableUnderlyingType, ignoreSerializableAttribute);
			jsonObjectContract.Properties.AddRange(this.CreateProperties(jsonObjectContract.NonNullableUnderlyingType, jsonObjectContract.MemberSerialization));
			JsonObjectAttribute cachedAttribute = JsonTypeReflector.GetCachedAttribute<JsonObjectAttribute>(jsonObjectContract.NonNullableUnderlyingType);
			if (cachedAttribute != null)
			{
				jsonObjectContract.ItemRequired = cachedAttribute._itemRequired;
			}
			if (jsonObjectContract.IsInstantiable)
			{
				ConstructorInfo attributeConstructor = this.GetAttributeConstructor(jsonObjectContract.NonNullableUnderlyingType);
				if (!DefaultContractResolver.smethod_14(attributeConstructor, null))
				{
					if (jsonObjectContract.MemberSerialization == MemberSerialization.Fields)
					{
						if (JsonTypeReflector.FullyTrusted)
						{
							jsonObjectContract.DefaultCreator = new Func<object>(jsonObjectContract.GetUninitializedObject);
						}
					}
					else if (jsonObjectContract.DefaultCreator == null || jsonObjectContract.DefaultCreatorNonPublic)
					{
						ConstructorInfo parametrizedConstructor = this.GetParametrizedConstructor(jsonObjectContract.NonNullableUnderlyingType);
						if (DefaultContractResolver.smethod_14(parametrizedConstructor, null))
						{
							jsonObjectContract.ParametrizedConstructor = parametrizedConstructor;
							jsonObjectContract.CreatorParameters.AddRange(this.CreateConstructorParameters(parametrizedConstructor, jsonObjectContract.Properties));
						}
					}
				}
				else
				{
					jsonObjectContract.OverrideConstructor = attributeConstructor;
					jsonObjectContract.CreatorParameters.AddRange(this.CreateConstructorParameters(attributeConstructor, jsonObjectContract.Properties));
				}
			}
			MemberInfo extensionDataMemberForType = this.GetExtensionDataMemberForType(jsonObjectContract.NonNullableUnderlyingType);
			if (DefaultContractResolver.smethod_15(extensionDataMemberForType, null))
			{
				DefaultContractResolver.SetExtensionDataDelegates(jsonObjectContract, extensionDataMemberForType);
			}
			return jsonObjectContract;
		}

		// Token: 0x06002312 RID: 8978 RVA: 0x0008B088 File Offset: 0x00089288
		private MemberInfo GetExtensionDataMemberForType(Type type)
		{
			IEnumerable<MemberInfo> enumerable = this.GetClassHierarchyForType(type).SelectMany(delegate(Type baseType)
			{
				IList<MemberInfo> list = new List<MemberInfo>();
				list.AddRange(DefaultContractResolver.smethod_56(baseType, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic));
				list.AddRange(DefaultContractResolver.smethod_57(baseType, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic));
				return list;
			});
			return enumerable.LastOrDefault(delegate(MemberInfo m)
			{
				MemberTypes memberTypes = m.MemberType();
				if (memberTypes != MemberTypes.Property && memberTypes != MemberTypes.Field)
				{
					return false;
				}
				if (!DefaultContractResolver.smethod_6(m, DefaultContractResolver.smethod_5(typeof(JsonExtensionDataAttribute).TypeHandle), false))
				{
					return false;
				}
				if (!ReflectionUtils.CanReadMemberValue(m, true))
				{
					throw new JsonException(<Module>.smethod_25<string>(2286913648U).FormatWith(DefaultContractResolver.smethod_41(), DefaultContractResolver.GetClrTypeFullName(DefaultContractResolver.smethod_24(m)), DefaultContractResolver.smethod_34(m)));
				}
				Type memberUnderlyingType = ReflectionUtils.GetMemberUnderlyingType(m);
				Type type2;
				if (ReflectionUtils.ImplementsGenericDefinition(memberUnderlyingType, DefaultContractResolver.smethod_5(typeof(IDictionary<, >).TypeHandle), out type2))
				{
					Type type3 = DefaultContractResolver.smethod_16(type2)[0];
					Type type4 = DefaultContractResolver.smethod_16(type2)[1];
					if (DefaultContractResolver.smethod_17(type3, DefaultContractResolver.smethod_5(typeof(string).TypeHandle)) && DefaultContractResolver.smethod_17(type4, DefaultContractResolver.smethod_5(typeof(JToken).TypeHandle)))
					{
						return true;
					}
				}
				throw new JsonException(<Module>.smethod_27<string>(3466118315U).FormatWith(DefaultContractResolver.smethod_41(), DefaultContractResolver.GetClrTypeFullName(DefaultContractResolver.smethod_24(m)), DefaultContractResolver.smethod_34(m)));
			});
		}

		// Token: 0x06002313 RID: 8979 RVA: 0x0008B0E4 File Offset: 0x000892E4
		private static void SetExtensionDataDelegates(JsonObjectContract contract, MemberInfo member)
		{
			JsonExtensionDataAttribute attribute = ReflectionUtils.GetAttribute<JsonExtensionDataAttribute>(member);
			if (attribute == null)
			{
				return;
			}
			Type memberUnderlyingType = ReflectionUtils.GetMemberUnderlyingType(member);
			Type type;
			ReflectionUtils.ImplementsGenericDefinition(memberUnderlyingType, DefaultContractResolver.smethod_5(typeof(IDictionary<, >).TypeHandle), out type);
			Type type2 = DefaultContractResolver.smethod_16(type)[0];
			Type type3 = DefaultContractResolver.smethod_16(type)[1];
			bool isJTokenValueType = DefaultContractResolver.smethod_17(DefaultContractResolver.smethod_5(typeof(JToken).TypeHandle), type3);
			Type type4;
			if (ReflectionUtils.IsGenericDefinition(memberUnderlyingType, DefaultContractResolver.smethod_5(typeof(IDictionary<, >).TypeHandle)))
			{
				type4 = DefaultContractResolver.smethod_18(DefaultContractResolver.smethod_5(typeof(Dictionary<, >).TypeHandle), new Type[] { type2, type3 });
			}
			else
			{
				type4 = memberUnderlyingType;
			}
			Func<object, object> getExtensionDataDictionary = JsonTypeReflector.ReflectionDelegateFactory.CreateGet<object>(member);
			Action<object, object> setExtensionDataDictionary = (ReflectionUtils.CanSetMemberValue(member, true, false) ? JsonTypeReflector.ReflectionDelegateFactory.CreateSet<object>(member) : null);
			Func<object> createExtensionDataDictionary = JsonTypeReflector.ReflectionDelegateFactory.CreateDefaultConstructor<object>(type4);
			MethodInfo methodInfo = DefaultContractResolver.smethod_19(memberUnderlyingType, <Module>.smethod_23<string>(350209536U), new Type[] { type2, type3 });
			MethodCall<object, object> setExtensionDataDictionaryValue = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>(methodInfo);
			ExtensionDataSetter extensionDataSetter = delegate(object o, string key, object value)
			{
				object obj = getExtensionDataDictionary(o);
				if (obj == null)
				{
					if (setExtensionDataDictionary == null)
					{
						throw new JsonSerializationException(<Module>.smethod_24<string>(1822991215U).FormatWith(DefaultContractResolver.<>c__DisplayClassb.smethod_0(), DefaultContractResolver.<>c__DisplayClassb.smethod_1(member)));
					}
					obj = createExtensionDataDictionary();
					setExtensionDataDictionary(o, obj);
				}
				if (isJTokenValueType && !(value is JToken))
				{
					value = ((value != null) ? JToken.FromObject(value) : JValue.CreateNull());
				}
				setExtensionDataDictionaryValue(obj, new object[] { key, value });
			};
			Type type5 = DefaultContractResolver.smethod_18(DefaultContractResolver.smethod_5(typeof(DefaultContractResolver.DictionaryEnumerator<, >).TypeHandle), new Type[] { type2, type3 });
			ConstructorInfo constructorInfo = DefaultContractResolver.smethod_20(type5).First<ConstructorInfo>();
			ObjectConstructor<object> createEnumerableWrapper = JsonTypeReflector.ReflectionDelegateFactory.CreateParametrizedConstructor(constructorInfo);
			ExtensionDataGetter extensionDataGetter = delegate(object o)
			{
				object obj2 = getExtensionDataDictionary(o);
				if (obj2 == null)
				{
					return null;
				}
				return (IEnumerable<KeyValuePair<object, object>>)createEnumerableWrapper(new object[] { obj2 });
			};
			if (attribute.ReadData)
			{
				contract.ExtensionDataSetter = extensionDataSetter;
			}
			if (attribute.WriteData)
			{
				contract.ExtensionDataGetter = extensionDataGetter;
			}
		}

		// Token: 0x06002314 RID: 8980 RVA: 0x0008B2C4 File Offset: 0x000894C4
		private ConstructorInfo GetAttributeConstructor(Type objectType)
		{
			IList<ConstructorInfo> list = (from c in DefaultContractResolver.smethod_21(objectType, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
				where DefaultContractResolver.smethod_6(c, DefaultContractResolver.smethod_5(typeof(JsonConstructorAttribute).TypeHandle), true)
				select c).ToList<ConstructorInfo>();
			if (list.Count > 1)
			{
				throw new JsonException(<Module>.smethod_23<string>(392462553U));
			}
			if (list.Count == 1)
			{
				return list[0];
			}
			if (DefaultContractResolver.smethod_0(objectType, DefaultContractResolver.smethod_5(typeof(Version).TypeHandle)))
			{
				return DefaultContractResolver.smethod_22(objectType, new Type[]
				{
					DefaultContractResolver.smethod_5(typeof(int).TypeHandle),
					DefaultContractResolver.smethod_5(typeof(int).TypeHandle),
					DefaultContractResolver.smethod_5(typeof(int).TypeHandle),
					DefaultContractResolver.smethod_5(typeof(int).TypeHandle)
				});
			}
			return null;
		}

		// Token: 0x06002315 RID: 8981 RVA: 0x0008B394 File Offset: 0x00089594
		private ConstructorInfo GetParametrizedConstructor(Type objectType)
		{
			IList<ConstructorInfo> list = DefaultContractResolver.smethod_21(objectType, BindingFlags.Instance | BindingFlags.Public).ToList<ConstructorInfo>();
			if (list.Count == 1)
			{
				return list[0];
			}
			return null;
		}

		// Token: 0x06002316 RID: 8982 RVA: 0x0008B3C4 File Offset: 0x000895C4
		protected virtual IList<JsonProperty> CreateConstructorParameters(ConstructorInfo constructor, JsonPropertyCollection memberProperties)
		{
			ParameterInfo[] array = DefaultContractResolver.smethod_23(constructor);
			JsonPropertyCollection jsonPropertyCollection = new JsonPropertyCollection(DefaultContractResolver.smethod_24(constructor));
			foreach (ParameterInfo parameterInfo in array)
			{
				JsonProperty jsonProperty = ((DefaultContractResolver.smethod_25(parameterInfo) != null) ? memberProperties.GetClosestMatchProperty(DefaultContractResolver.smethod_25(parameterInfo)) : null);
				if (jsonProperty != null && DefaultContractResolver.smethod_27(jsonProperty.PropertyType, DefaultContractResolver.smethod_26(parameterInfo)))
				{
					jsonProperty = null;
				}
				if (jsonProperty != null || DefaultContractResolver.smethod_25(parameterInfo) != null)
				{
					JsonProperty jsonProperty2 = this.CreatePropertyFromConstructorParameter(jsonProperty, parameterInfo);
					if (jsonProperty2 != null)
					{
						jsonPropertyCollection.AddProperty(jsonProperty2);
					}
				}
			}
			return jsonPropertyCollection;
		}

		// Token: 0x06002317 RID: 8983 RVA: 0x0008B45C File Offset: 0x0008965C
		protected virtual JsonProperty CreatePropertyFromConstructorParameter(JsonProperty matchingMemberProperty, ParameterInfo parameterInfo)
		{
			JsonProperty jsonProperty = new JsonProperty();
			jsonProperty.PropertyType = DefaultContractResolver.smethod_26(parameterInfo);
			jsonProperty.AttributeProvider = new ReflectionAttributeProvider(parameterInfo);
			bool flag;
			this.SetPropertySettingsFromAttributes(jsonProperty, parameterInfo, DefaultContractResolver.smethod_25(parameterInfo), DefaultContractResolver.smethod_24(DefaultContractResolver.smethod_28(parameterInfo)), MemberSerialization.OptOut, out flag);
			jsonProperty.Readable = false;
			jsonProperty.Writable = true;
			if (matchingMemberProperty != null)
			{
				jsonProperty.PropertyName = (DefaultContractResolver.smethod_29(jsonProperty.PropertyName, DefaultContractResolver.smethod_25(parameterInfo)) ? jsonProperty.PropertyName : matchingMemberProperty.PropertyName);
				jsonProperty.Converter = jsonProperty.Converter ?? matchingMemberProperty.Converter;
				jsonProperty.MemberConverter = jsonProperty.MemberConverter ?? matchingMemberProperty.MemberConverter;
				if (!jsonProperty._hasExplicitDefaultValue && matchingMemberProperty._hasExplicitDefaultValue)
				{
					jsonProperty.DefaultValue = matchingMemberProperty.DefaultValue;
				}
				JsonProperty jsonProperty2 = jsonProperty;
				Required? required = jsonProperty._required;
				jsonProperty2._required = ((required != null) ? new Required?(required.GetValueOrDefault()) : matchingMemberProperty._required);
				JsonProperty jsonProperty3 = jsonProperty;
				bool? isReference = jsonProperty.IsReference;
				jsonProperty3.IsReference = ((isReference != null) ? new bool?(isReference.GetValueOrDefault()) : matchingMemberProperty.IsReference);
				JsonProperty jsonProperty4 = jsonProperty;
				NullValueHandling? nullValueHandling = jsonProperty.NullValueHandling;
				jsonProperty4.NullValueHandling = ((nullValueHandling != null) ? new NullValueHandling?(nullValueHandling.GetValueOrDefault()) : matchingMemberProperty.NullValueHandling);
				JsonProperty jsonProperty5 = jsonProperty;
				DefaultValueHandling? defaultValueHandling = jsonProperty.DefaultValueHandling;
				jsonProperty5.DefaultValueHandling = ((defaultValueHandling != null) ? new DefaultValueHandling?(defaultValueHandling.GetValueOrDefault()) : matchingMemberProperty.DefaultValueHandling);
				JsonProperty jsonProperty6 = jsonProperty;
				ReferenceLoopHandling? referenceLoopHandling = jsonProperty.ReferenceLoopHandling;
				jsonProperty6.ReferenceLoopHandling = ((referenceLoopHandling != null) ? new ReferenceLoopHandling?(referenceLoopHandling.GetValueOrDefault()) : matchingMemberProperty.ReferenceLoopHandling);
				JsonProperty jsonProperty7 = jsonProperty;
				ObjectCreationHandling? objectCreationHandling = jsonProperty.ObjectCreationHandling;
				jsonProperty7.ObjectCreationHandling = ((objectCreationHandling != null) ? new ObjectCreationHandling?(objectCreationHandling.GetValueOrDefault()) : matchingMemberProperty.ObjectCreationHandling);
				JsonProperty jsonProperty8 = jsonProperty;
				TypeNameHandling? typeNameHandling = jsonProperty.TypeNameHandling;
				jsonProperty8.TypeNameHandling = ((typeNameHandling != null) ? new TypeNameHandling?(typeNameHandling.GetValueOrDefault()) : matchingMemberProperty.TypeNameHandling);
			}
			return jsonProperty;
		}

		// Token: 0x06002318 RID: 8984 RVA: 0x0001C991 File Offset: 0x0001AB91
		protected virtual JsonConverter ResolveContractConverter(Type objectType)
		{
			return JsonTypeReflector.GetJsonConverter(objectType);
		}

		// Token: 0x06002319 RID: 8985 RVA: 0x0001C999 File Offset: 0x0001AB99
		private Func<object> GetDefaultCreator(Type createdType)
		{
			return JsonTypeReflector.ReflectionDelegateFactory.CreateDefaultConstructor<object>(createdType);
		}

		// Token: 0x0600231A RID: 8986 RVA: 0x0008B654 File Offset: 0x00089854
		[SuppressMessage("Microsoft.Portability", "CA1903:UseOnlyApiFromTargetedFramework", MessageId = "System.Runtime.Serialization.DataContractAttribute.#get_IsReference()")]
		private void InitializeContract(JsonContract contract)
		{
			JsonContainerAttribute cachedAttribute = JsonTypeReflector.GetCachedAttribute<JsonContainerAttribute>(contract.NonNullableUnderlyingType);
			if (cachedAttribute != null)
			{
				contract.IsReference = cachedAttribute._isReference;
			}
			else
			{
				DataContractAttribute dataContractAttribute = JsonTypeReflector.GetDataContractAttribute(contract.NonNullableUnderlyingType);
				if (dataContractAttribute != null && DefaultContractResolver.smethod_30(dataContractAttribute))
				{
					contract.IsReference = new bool?(true);
				}
			}
			contract.Converter = this.ResolveContractConverter(contract.NonNullableUnderlyingType);
			contract.InternalConverter = JsonSerializer.GetMatchingConverter(DefaultContractResolver.BuiltInConverters, contract.NonNullableUnderlyingType);
			if (contract.IsInstantiable && (ReflectionUtils.HasDefaultConstructor(contract.CreatedType, true) || contract.CreatedType.IsValueType()))
			{
				contract.DefaultCreator = this.GetDefaultCreator(contract.CreatedType);
				contract.DefaultCreatorNonPublic = !contract.CreatedType.IsValueType() && DefaultContractResolver.smethod_31(ReflectionUtils.GetDefaultConstructor(contract.CreatedType), null);
			}
			this.ResolveCallbackMethods(contract, contract.NonNullableUnderlyingType);
		}

		// Token: 0x0600231B RID: 8987 RVA: 0x0008B734 File Offset: 0x00089934
		private void ResolveCallbackMethods(JsonContract contract, Type t)
		{
			List<SerializationCallback> list;
			List<SerializationCallback> list2;
			List<SerializationCallback> list3;
			List<SerializationCallback> list4;
			List<SerializationErrorCallback> list5;
			this.GetCallbackMethodsForType(t, out list, out list2, out list3, out list4, out list5);
			if (list != null)
			{
				contract.OnSerializingCallbacks.AddRange(list);
			}
			if (list2 != null)
			{
				contract.OnSerializedCallbacks.AddRange(list2);
			}
			if (list3 != null)
			{
				contract.OnDeserializingCallbacks.AddRange(list3);
			}
			if (list4 != null)
			{
				contract.OnDeserializedCallbacks.AddRange(list4);
			}
			if (list5 != null)
			{
				contract.OnErrorCallbacks.AddRange(list5);
			}
		}

		// Token: 0x0600231C RID: 8988 RVA: 0x0008B7A0 File Offset: 0x000899A0
		private void GetCallbackMethodsForType(Type type, out List<SerializationCallback> onSerializing, out List<SerializationCallback> onSerialized, out List<SerializationCallback> onDeserializing, out List<SerializationCallback> onDeserialized, out List<SerializationErrorCallback> onError)
		{
			onSerializing = null;
			onSerialized = null;
			onDeserializing = null;
			onDeserialized = null;
			onError = null;
			foreach (Type type2 in this.GetClassHierarchyForType(type))
			{
				MethodInfo methodInfo = null;
				MethodInfo methodInfo2 = null;
				MethodInfo methodInfo3 = null;
				MethodInfo methodInfo4 = null;
				MethodInfo methodInfo5 = null;
				bool flag = DefaultContractResolver.ShouldSkipSerializing(type2);
				bool flag2 = DefaultContractResolver.ShouldSkipDeserialized(type2);
				foreach (MethodInfo methodInfo6 in DefaultContractResolver.smethod_32(type2, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
				{
					if (!DefaultContractResolver.smethod_33(methodInfo6))
					{
						Type type3 = null;
						ParameterInfo[] array2 = DefaultContractResolver.smethod_23(methodInfo6);
						if (!flag && DefaultContractResolver.IsValidCallback(methodInfo6, array2, DefaultContractResolver.smethod_5(typeof(OnSerializingAttribute).TypeHandle), methodInfo, ref type3))
						{
							onSerializing = onSerializing ?? new List<SerializationCallback>();
							onSerializing.Add(JsonContract.CreateSerializationCallback(methodInfo6));
							methodInfo = methodInfo6;
						}
						if (DefaultContractResolver.IsValidCallback(methodInfo6, array2, DefaultContractResolver.smethod_5(typeof(OnSerializedAttribute).TypeHandle), methodInfo2, ref type3))
						{
							onSerialized = onSerialized ?? new List<SerializationCallback>();
							onSerialized.Add(JsonContract.CreateSerializationCallback(methodInfo6));
							methodInfo2 = methodInfo6;
						}
						if (DefaultContractResolver.IsValidCallback(methodInfo6, array2, DefaultContractResolver.smethod_5(typeof(OnDeserializingAttribute).TypeHandle), methodInfo3, ref type3))
						{
							onDeserializing = onDeserializing ?? new List<SerializationCallback>();
							onDeserializing.Add(JsonContract.CreateSerializationCallback(methodInfo6));
							methodInfo3 = methodInfo6;
						}
						if (!flag2 && DefaultContractResolver.IsValidCallback(methodInfo6, array2, DefaultContractResolver.smethod_5(typeof(OnDeserializedAttribute).TypeHandle), methodInfo4, ref type3))
						{
							onDeserialized = onDeserialized ?? new List<SerializationCallback>();
							onDeserialized.Add(JsonContract.CreateSerializationCallback(methodInfo6));
							methodInfo4 = methodInfo6;
						}
						if (DefaultContractResolver.IsValidCallback(methodInfo6, array2, DefaultContractResolver.smethod_5(typeof(OnErrorAttribute).TypeHandle), methodInfo5, ref type3))
						{
							onError = onError ?? new List<SerializationErrorCallback>();
							onError.Add(JsonContract.CreateSerializationErrorCallback(methodInfo6));
							methodInfo5 = methodInfo6;
						}
					}
				}
			}
		}

		// Token: 0x0600231D RID: 8989 RVA: 0x0008B99C File Offset: 0x00089B9C
		private static bool ShouldSkipDeserialized(Type t)
		{
			return (t.IsGenericType() && DefaultContractResolver.smethod_0(DefaultContractResolver.smethod_11(t), DefaultContractResolver.smethod_5(typeof(ConcurrentDictionary<, >).TypeHandle))) || DefaultContractResolver.smethod_13(DefaultContractResolver.smethod_34(t), <Module>.smethod_26<string>(958568304U)) || DefaultContractResolver.smethod_13(DefaultContractResolver.smethod_34(t), <Module>.smethod_25<string>(865516715U));
		}

		// Token: 0x0600231E RID: 8990 RVA: 0x0001C9A6 File Offset: 0x0001ABA6
		private static bool ShouldSkipSerializing(Type t)
		{
			return DefaultContractResolver.smethod_13(DefaultContractResolver.smethod_34(t), <Module>.smethod_26<string>(958568304U)) || DefaultContractResolver.smethod_13(DefaultContractResolver.smethod_34(t), <Module>.smethod_25<string>(865516715U));
		}

		// Token: 0x0600231F RID: 8991 RVA: 0x0008B9FC File Offset: 0x00089BFC
		private List<Type> GetClassHierarchyForType(Type type)
		{
			List<Type> list = new List<Type>();
			Type type2 = type;
			while (DefaultContractResolver.smethod_27(type2, null) && DefaultContractResolver.smethod_27(type2, DefaultContractResolver.smethod_5(typeof(object).TypeHandle)))
			{
				list.Add(type2);
				type2 = type2.BaseType();
			}
			list.Reverse();
			return list;
		}

		// Token: 0x06002320 RID: 8992 RVA: 0x0008BA44 File Offset: 0x00089C44
		protected virtual JsonDictionaryContract CreateDictionaryContract(Type objectType)
		{
			JsonDictionaryContract jsonDictionaryContract = new JsonDictionaryContract(objectType);
			this.InitializeContract(jsonDictionaryContract);
			jsonDictionaryContract.DictionaryKeyResolver = new Func<string, string>(this.ResolveDictionaryKey);
			return jsonDictionaryContract;
		}

		// Token: 0x06002321 RID: 8993 RVA: 0x0008BA74 File Offset: 0x00089C74
		protected virtual JsonArrayContract CreateArrayContract(Type objectType)
		{
			JsonArrayContract jsonArrayContract = new JsonArrayContract(objectType);
			this.InitializeContract(jsonArrayContract);
			return jsonArrayContract;
		}

		// Token: 0x06002322 RID: 8994 RVA: 0x0008BA90 File Offset: 0x00089C90
		protected virtual JsonPrimitiveContract CreatePrimitiveContract(Type objectType)
		{
			JsonPrimitiveContract jsonPrimitiveContract = new JsonPrimitiveContract(objectType);
			this.InitializeContract(jsonPrimitiveContract);
			return jsonPrimitiveContract;
		}

		// Token: 0x06002323 RID: 8995 RVA: 0x0008BAAC File Offset: 0x00089CAC
		protected virtual JsonLinqContract CreateLinqContract(Type objectType)
		{
			JsonLinqContract jsonLinqContract = new JsonLinqContract(objectType);
			this.InitializeContract(jsonLinqContract);
			return jsonLinqContract;
		}

		// Token: 0x06002324 RID: 8996 RVA: 0x0008BAC8 File Offset: 0x00089CC8
		protected virtual JsonISerializableContract CreateISerializableContract(Type objectType)
		{
			JsonISerializableContract jsonISerializableContract = new JsonISerializableContract(objectType);
			this.InitializeContract(jsonISerializableContract);
			ConstructorInfo constructorInfo = DefaultContractResolver.smethod_35(jsonISerializableContract.NonNullableUnderlyingType, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, new Type[]
			{
				DefaultContractResolver.smethod_5(typeof(SerializationInfo).TypeHandle),
				DefaultContractResolver.smethod_5(typeof(StreamingContext).TypeHandle)
			}, null);
			if (DefaultContractResolver.smethod_14(constructorInfo, null))
			{
				ObjectConstructor<object> objectConstructor = JsonTypeReflector.ReflectionDelegateFactory.CreateParametrizedConstructor(constructorInfo);
				jsonISerializableContract.ISerializableCreator = objectConstructor;
			}
			return jsonISerializableContract;
		}

		// Token: 0x06002325 RID: 8997 RVA: 0x0008BB3C File Offset: 0x00089D3C
		protected virtual JsonDynamicContract CreateDynamicContract(Type objectType)
		{
			JsonDynamicContract jsonDynamicContract = new JsonDynamicContract(objectType);
			this.InitializeContract(jsonDynamicContract);
			jsonDynamicContract.PropertyNameResolver = new Func<string, string>(this.ResolvePropertyName);
			jsonDynamicContract.Properties.AddRange(this.CreateProperties(objectType, MemberSerialization.OptOut));
			return jsonDynamicContract;
		}

		// Token: 0x06002326 RID: 8998 RVA: 0x0008BB80 File Offset: 0x00089D80
		protected virtual JsonStringContract CreateStringContract(Type objectType)
		{
			JsonStringContract jsonStringContract = new JsonStringContract(objectType);
			this.InitializeContract(jsonStringContract);
			return jsonStringContract;
		}

		// Token: 0x06002327 RID: 8999 RVA: 0x0008BB9C File Offset: 0x00089D9C
		protected virtual JsonContract CreateContract(Type objectType)
		{
			if (DefaultContractResolver.IsJsonPrimitiveType(objectType))
			{
				return this.CreatePrimitiveContract(objectType);
			}
			Type type = ReflectionUtils.EnsureNotNullableType(objectType);
			JsonContainerAttribute cachedAttribute = JsonTypeReflector.GetCachedAttribute<JsonContainerAttribute>(type);
			if (cachedAttribute is JsonObjectAttribute)
			{
				return this.CreateObjectContract(objectType);
			}
			if (cachedAttribute is JsonArrayAttribute)
			{
				return this.CreateArrayContract(objectType);
			}
			if (cachedAttribute is JsonDictionaryAttribute)
			{
				return this.CreateDictionaryContract(objectType);
			}
			if (DefaultContractResolver.smethod_0(type, DefaultContractResolver.smethod_5(typeof(JToken).TypeHandle)) || DefaultContractResolver.smethod_36(type, DefaultContractResolver.smethod_5(typeof(JToken).TypeHandle)))
			{
				return this.CreateLinqContract(objectType);
			}
			if (CollectionUtils.IsDictionaryType(type))
			{
				return this.CreateDictionaryContract(objectType);
			}
			if (DefaultContractResolver.smethod_17(DefaultContractResolver.smethod_5(typeof(IEnumerable).TypeHandle), type))
			{
				return this.CreateArrayContract(objectType);
			}
			if (DefaultContractResolver.CanConvertToString(type))
			{
				return this.CreateStringContract(objectType);
			}
			if (!this.IgnoreSerializableInterface && DefaultContractResolver.smethod_17(DefaultContractResolver.smethod_5(typeof(ISerializable).TypeHandle), type))
			{
				return this.CreateISerializableContract(objectType);
			}
			if (DefaultContractResolver.smethod_17(DefaultContractResolver.smethod_5(typeof(IDynamicMetaObjectProvider).TypeHandle), type))
			{
				return this.CreateDynamicContract(objectType);
			}
			if (DefaultContractResolver.IsIConvertible(type))
			{
				return this.CreatePrimitiveContract(type);
			}
			return this.CreateObjectContract(objectType);
		}

		// Token: 0x06002328 RID: 9000 RVA: 0x0008BCBC File Offset: 0x00089EBC
		internal static bool IsJsonPrimitiveType(Type t)
		{
			PrimitiveTypeCode typeCode = ConvertUtils.GetTypeCode(t);
			return typeCode != PrimitiveTypeCode.Empty && typeCode != PrimitiveTypeCode.Object;
		}

		// Token: 0x06002329 RID: 9001 RVA: 0x0008BCDC File Offset: 0x00089EDC
		internal static bool IsIConvertible(Type t)
		{
			return (DefaultContractResolver.smethod_17(DefaultContractResolver.smethod_5(typeof(IConvertible).TypeHandle), t) || (ReflectionUtils.IsNullableType(t) && DefaultContractResolver.smethod_17(DefaultContractResolver.smethod_5(typeof(IConvertible).TypeHandle), DefaultContractResolver.smethod_37(t)))) && !DefaultContractResolver.smethod_17(DefaultContractResolver.smethod_5(typeof(JToken).TypeHandle), t);
		}

		// Token: 0x0600232A RID: 9002 RVA: 0x0008BD30 File Offset: 0x00089F30
		internal static bool CanConvertToString(Type type)
		{
			TypeConverter converter = ConvertUtils.GetConverter(type);
			return (converter != null && !(converter is ComponentConverter) && !(converter is ReferenceConverter) && DefaultContractResolver.smethod_27(DefaultContractResolver.smethod_38(converter), DefaultContractResolver.smethod_5(typeof(TypeConverter).TypeHandle)) && DefaultContractResolver.smethod_39(converter, DefaultContractResolver.smethod_5(typeof(string).TypeHandle))) || DefaultContractResolver.smethod_0(type, DefaultContractResolver.smethod_5(typeof(Type).TypeHandle)) || DefaultContractResolver.smethod_36(type, DefaultContractResolver.smethod_5(typeof(Type).TypeHandle));
		}

		// Token: 0x0600232B RID: 9003 RVA: 0x0008BDAC File Offset: 0x00089FAC
		private static bool IsValidCallback(MethodInfo method, ParameterInfo[] parameters, Type attributeType, MethodInfo currentCallback, ref Type prevAttributeType)
		{
			if (!DefaultContractResolver.smethod_6(method, attributeType, false))
			{
				return false;
			}
			if (DefaultContractResolver.smethod_40(currentCallback, null))
			{
				throw new JsonException(<Module>.smethod_27<string>(3704998320U).FormatWith(DefaultContractResolver.smethod_41(), method, currentCallback, DefaultContractResolver.GetClrTypeFullName(DefaultContractResolver.smethod_24(method)), attributeType));
			}
			if (DefaultContractResolver.smethod_27(prevAttributeType, null))
			{
				throw new JsonException(<Module>.smethod_25<string>(1561491245U).FormatWith(DefaultContractResolver.smethod_41(), prevAttributeType, attributeType, DefaultContractResolver.GetClrTypeFullName(DefaultContractResolver.smethod_24(method)), method));
			}
			if (DefaultContractResolver.smethod_42(method))
			{
				throw new JsonException(<Module>.smethod_23<string>(1090333061U).FormatWith(DefaultContractResolver.smethod_41(), method, DefaultContractResolver.GetClrTypeFullName(DefaultContractResolver.smethod_24(method)), attributeType));
			}
			if (!DefaultContractResolver.smethod_27(DefaultContractResolver.smethod_43(method), DefaultContractResolver.smethod_5(typeof(void).TypeHandle)))
			{
				if (DefaultContractResolver.smethod_0(attributeType, DefaultContractResolver.smethod_5(typeof(OnErrorAttribute).TypeHandle)))
				{
					if (parameters != null)
					{
						if (parameters.Length == 2)
						{
							if (!DefaultContractResolver.smethod_27(DefaultContractResolver.smethod_26(parameters[0]), DefaultContractResolver.smethod_5(typeof(StreamingContext).TypeHandle)) && !DefaultContractResolver.smethod_27(DefaultContractResolver.smethod_26(parameters[1]), DefaultContractResolver.smethod_5(typeof(ErrorContext).TypeHandle)))
							{
								goto IL_01CE;
							}
						}
					}
					throw new JsonException(<Module>.smethod_25<string>(915039378U).FormatWith(DefaultContractResolver.smethod_41(), DefaultContractResolver.GetClrTypeFullName(DefaultContractResolver.smethod_24(method)), method, DefaultContractResolver.smethod_5(typeof(StreamingContext).TypeHandle), DefaultContractResolver.smethod_5(typeof(ErrorContext).TypeHandle)));
				}
				if (parameters == null || parameters.Length != 1 || DefaultContractResolver.smethod_27(DefaultContractResolver.smethod_26(parameters[0]), DefaultContractResolver.smethod_5(typeof(StreamingContext).TypeHandle)))
				{
					throw new JsonException(<Module>.smethod_25<string>(3559742592U).FormatWith(DefaultContractResolver.smethod_41(), DefaultContractResolver.GetClrTypeFullName(DefaultContractResolver.smethod_24(method)), method, DefaultContractResolver.smethod_5(typeof(StreamingContext).TypeHandle)));
				}
				IL_01CE:
				prevAttributeType = attributeType;
				return true;
			}
			throw new JsonException(<Module>.smethod_25<string>(4096447426U).FormatWith(DefaultContractResolver.smethod_41(), DefaultContractResolver.GetClrTypeFullName(DefaultContractResolver.smethod_24(method)), method));
		}

		// Token: 0x0600232C RID: 9004 RVA: 0x0008BF8C File Offset: 0x0008A18C
		internal static string GetClrTypeFullName(Type type)
		{
			if (!type.IsGenericTypeDefinition() && type.ContainsGenericParameters())
			{
				return DefaultContractResolver.smethod_45(DefaultContractResolver.smethod_41(), <Module>.smethod_23<string>(1764248942U), new object[]
				{
					DefaultContractResolver.smethod_44(type),
					DefaultContractResolver.smethod_34(type)
				});
			}
			return DefaultContractResolver.smethod_12(type);
		}

		// Token: 0x0600232D RID: 9005 RVA: 0x0008BFE0 File Offset: 0x0008A1E0
		protected virtual IList<JsonProperty> CreateProperties(Type type, MemberSerialization memberSerialization)
		{
			List<MemberInfo> serializableMembers = this.GetSerializableMembers(type);
			if (serializableMembers != null)
			{
				JsonPropertyCollection jsonPropertyCollection = new JsonPropertyCollection(type);
				foreach (MemberInfo memberInfo in serializableMembers)
				{
					JsonProperty jsonProperty = this.CreateProperty(memberInfo, memberSerialization);
					if (jsonProperty != null)
					{
						DefaultContractResolverState state = this.GetState();
						bool flag = false;
						try
						{
							PropertyNameTable nameTable;
							DefaultContractResolver.smethod_3(nameTable = state.NameTable, ref flag);
							jsonProperty.PropertyName = state.NameTable.Add(jsonProperty.PropertyName);
						}
						finally
						{
							if (flag)
							{
								PropertyNameTable nameTable;
								DefaultContractResolver.smethod_4(nameTable);
							}
						}
						jsonPropertyCollection.AddProperty(jsonProperty);
					}
				}
				return jsonPropertyCollection.OrderBy(delegate(JsonProperty p)
				{
					int? order = p.Order;
					if (order == null)
					{
						return -1;
					}
					return order.GetValueOrDefault();
				}).ToList<JsonProperty>();
			}
			throw new JsonSerializationException(<Module>.smethod_24<string>(2371230560U));
		}

		// Token: 0x0600232E RID: 9006 RVA: 0x0008C0E4 File Offset: 0x0008A2E4
		protected virtual IValueProvider CreateMemberValueProvider(MemberInfo member)
		{
			IValueProvider valueProvider;
			if (this.DynamicCodeGeneration)
			{
				valueProvider = new DynamicValueProvider(member);
			}
			else
			{
				valueProvider = new ReflectionValueProvider(member);
			}
			return valueProvider;
		}

		// Token: 0x0600232F RID: 9007 RVA: 0x0008C10C File Offset: 0x0008A30C
		protected virtual JsonProperty CreateProperty(MemberInfo member, MemberSerialization memberSerialization)
		{
			JsonProperty jsonProperty = new JsonProperty();
			jsonProperty.PropertyType = ReflectionUtils.GetMemberUnderlyingType(member);
			jsonProperty.DeclaringType = DefaultContractResolver.smethod_24(member);
			jsonProperty.ValueProvider = this.CreateMemberValueProvider(member);
			jsonProperty.AttributeProvider = new ReflectionAttributeProvider(member);
			bool flag;
			this.SetPropertySettingsFromAttributes(jsonProperty, member, DefaultContractResolver.smethod_34(member), DefaultContractResolver.smethod_24(member), memberSerialization, out flag);
			if (memberSerialization != MemberSerialization.Fields)
			{
				jsonProperty.Readable = ReflectionUtils.CanReadMemberValue(member, flag);
				jsonProperty.Writable = ReflectionUtils.CanSetMemberValue(member, flag, jsonProperty.HasMemberAttribute);
			}
			else
			{
				jsonProperty.Readable = true;
				jsonProperty.Writable = true;
			}
			jsonProperty.ShouldSerialize = this.CreateShouldSerializeTest(member);
			this.SetIsSpecifiedActions(jsonProperty, member, flag);
			return jsonProperty;
		}

		// Token: 0x06002330 RID: 9008 RVA: 0x0008C1B4 File Offset: 0x0008A3B4
		private void SetPropertySettingsFromAttributes(JsonProperty property, object attributeProvider, string name, Type declaringType, MemberSerialization memberSerialization, out bool allowNonPublicAccess)
		{
			DataContractAttribute dataContractAttribute = JsonTypeReflector.GetDataContractAttribute(declaringType);
			MemberInfo memberInfo = attributeProvider as MemberInfo;
			DataMemberAttribute dataMemberAttribute;
			if (dataContractAttribute != null && DefaultContractResolver.smethod_15(memberInfo, null))
			{
				dataMemberAttribute = JsonTypeReflector.GetDataMemberAttribute(memberInfo);
			}
			else
			{
				dataMemberAttribute = null;
			}
			JsonPropertyAttribute attribute = JsonTypeReflector.GetAttribute<JsonPropertyAttribute>(attributeProvider);
			JsonRequiredAttribute attribute2 = JsonTypeReflector.GetAttribute<JsonRequiredAttribute>(attributeProvider);
			string text;
			if (attribute != null && attribute.PropertyName != null)
			{
				text = attribute.PropertyName;
			}
			else if (dataMemberAttribute != null && DefaultContractResolver.smethod_46(dataMemberAttribute) != null)
			{
				text = DefaultContractResolver.smethod_46(dataMemberAttribute);
			}
			else
			{
				text = name;
			}
			property.PropertyName = this.ResolvePropertyName(text);
			property.UnderlyingName = name;
			bool flag = false;
			if (attribute == null)
			{
				if (dataMemberAttribute != null)
				{
					property._required = new Required?(DefaultContractResolver.smethod_47(dataMemberAttribute) ? Required.AllowNull : Required.Default);
					property.Order = ((DefaultContractResolver.smethod_48(dataMemberAttribute) != -1) ? new int?(DefaultContractResolver.smethod_48(dataMemberAttribute)) : null);
					property.DefaultValueHandling = ((!DefaultContractResolver.smethod_49(dataMemberAttribute)) ? new DefaultValueHandling?(DefaultValueHandling.Ignore) : null);
					flag = true;
				}
			}
			else
			{
				property._required = attribute._required;
				property.Order = attribute._order;
				property.DefaultValueHandling = attribute._defaultValueHandling;
				flag = true;
			}
			if (attribute2 != null)
			{
				property._required = new Required?(Required.Always);
				flag = true;
			}
			property.HasMemberAttribute = flag;
			bool flag2 = JsonTypeReflector.GetAttribute<JsonIgnoreAttribute>(attributeProvider) != null || JsonTypeReflector.GetAttribute<JsonExtensionDataAttribute>(attributeProvider) != null || JsonTypeReflector.GetAttribute<NonSerializedAttribute>(attributeProvider) != null;
			if (memberSerialization == MemberSerialization.OptIn)
			{
				property.Ignored = flag2 || !flag;
			}
			else
			{
				bool flag3 = JsonTypeReflector.GetAttribute<IgnoreDataMemberAttribute>(attributeProvider) != null;
				property.Ignored = flag2 || flag3;
			}
			property.Converter = JsonTypeReflector.GetJsonConverter(attributeProvider);
			property.MemberConverter = JsonTypeReflector.GetJsonConverter(attributeProvider);
			DefaultValueAttribute attribute3 = JsonTypeReflector.GetAttribute<DefaultValueAttribute>(attributeProvider);
			if (attribute3 != null)
			{
				property.DefaultValue = DefaultContractResolver.smethod_50(attribute3);
			}
			property.NullValueHandling = ((attribute != null) ? attribute._nullValueHandling : null);
			property.ReferenceLoopHandling = ((attribute != null) ? attribute._referenceLoopHandling : null);
			property.ObjectCreationHandling = ((attribute != null) ? attribute._objectCreationHandling : null);
			property.TypeNameHandling = ((attribute != null) ? attribute._typeNameHandling : null);
			property.IsReference = ((attribute != null) ? attribute._isReference : null);
			property.ItemIsReference = ((attribute != null) ? attribute._itemIsReference : null);
			property.ItemConverter = ((attribute == null || !DefaultContractResolver.smethod_27(attribute.ItemConverterType, null)) ? null : JsonTypeReflector.CreateJsonConverterInstance(attribute.ItemConverterType, attribute.ItemConverterParameters));
			property.ItemReferenceLoopHandling = ((attribute != null) ? attribute._itemReferenceLoopHandling : null);
			property.ItemTypeNameHandling = ((attribute != null) ? attribute._itemTypeNameHandling : null);
			allowNonPublicAccess = false;
			if ((this.DefaultMembersSearchFlags & BindingFlags.NonPublic) == BindingFlags.NonPublic)
			{
				allowNonPublicAccess = true;
			}
			if (flag)
			{
				allowNonPublicAccess = true;
			}
			if (memberSerialization == MemberSerialization.Fields)
			{
				allowNonPublicAccess = true;
			}
		}

		// Token: 0x06002331 RID: 9009 RVA: 0x0008C49C File Offset: 0x0008A69C
		private Predicate<object> CreateShouldSerializeTest(MemberInfo member)
		{
			MethodInfo methodInfo = DefaultContractResolver.smethod_19(DefaultContractResolver.smethod_24(member), DefaultContractResolver.smethod_51(<Module>.smethod_24<string>(3360500807U), DefaultContractResolver.smethod_34(member)), ReflectionUtils.EmptyTypes);
			if (!DefaultContractResolver.smethod_52(methodInfo, null) && !DefaultContractResolver.smethod_27(DefaultContractResolver.smethod_43(methodInfo), DefaultContractResolver.smethod_5(typeof(bool).TypeHandle)))
			{
				MethodCall<object, object> shouldSerializeCall = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>(methodInfo);
				return (object o) => (bool)shouldSerializeCall(o, new object[0]);
			}
			return null;
		}

		// Token: 0x06002332 RID: 9010 RVA: 0x0008C514 File Offset: 0x0008A714
		private void SetIsSpecifiedActions(JsonProperty property, MemberInfo member, bool allowNonPublicAccess)
		{
			MemberInfo memberInfo = DefaultContractResolver.smethod_53(DefaultContractResolver.smethod_24(member), DefaultContractResolver.smethod_51(DefaultContractResolver.smethod_34(member), <Module>.smethod_25<string>(1451744212U)));
			if (DefaultContractResolver.smethod_54(memberInfo, null))
			{
				memberInfo = DefaultContractResolver.smethod_55(DefaultContractResolver.smethod_24(member), DefaultContractResolver.smethod_51(DefaultContractResolver.smethod_34(member), <Module>.smethod_24<string>(2601399746U)));
			}
			if (!DefaultContractResolver.smethod_54(memberInfo, null) && !DefaultContractResolver.smethod_27(ReflectionUtils.GetMemberUnderlyingType(memberInfo), DefaultContractResolver.smethod_5(typeof(bool).TypeHandle)))
			{
				Func<object, object> specifiedPropertyGet = JsonTypeReflector.ReflectionDelegateFactory.CreateGet<object>(memberInfo);
				property.GetIsSpecified = (object o) => (bool)specifiedPropertyGet(o);
				if (ReflectionUtils.CanSetMemberValue(memberInfo, allowNonPublicAccess, false))
				{
					property.SetIsSpecified = JsonTypeReflector.ReflectionDelegateFactory.CreateSet<object>(memberInfo);
				}
				return;
			}
		}

		// Token: 0x06002333 RID: 9011 RVA: 0x0001C9D9 File Offset: 0x0001ABD9
		protected virtual string ResolvePropertyName(string propertyName)
		{
			return propertyName;
		}

		// Token: 0x06002334 RID: 9012 RVA: 0x0001C9DC File Offset: 0x0001ABDC
		protected virtual string ResolveDictionaryKey(string dictionaryKey)
		{
			return this.ResolvePropertyName(dictionaryKey);
		}

		// Token: 0x06002335 RID: 9013 RVA: 0x0001C9DC File Offset: 0x0001ABDC
		public string GetResolvedPropertyName(string propertyName)
		{
			return this.ResolvePropertyName(propertyName);
		}

		// Token: 0x0600233D RID: 9021 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_0(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x0600233E RID: 9022 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_1(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x0600233F RID: 9023 RVA: 0x0001040D File Offset: 0x0000E60D
		static Type smethod_2(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06002340 RID: 9024 RVA: 0x0000DBD7 File Offset: 0x0000BDD7
		static void smethod_3(object object_0, ref bool bool_0)
		{
			Monitor.Enter(object_0, ref bool_0);
		}

		// Token: 0x06002341 RID: 9025 RVA: 0x0000DBEF File Offset: 0x0000BDEF
		static void smethod_4(object object_0)
		{
			Monitor.Exit(object_0);
		}

		// Token: 0x06002342 RID: 9026 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_5(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06002343 RID: 9027 RVA: 0x0001CA03 File Offset: 0x0001AC03
		static bool smethod_6(MemberInfo memberInfo_0, Type type_0, bool bool_0)
		{
			return memberInfo_0.IsDefined(type_0, bool_0);
		}

		// Token: 0x06002344 RID: 9028 RVA: 0x0001CA0D File Offset: 0x0001AC0D
		static bool smethod_7(FieldInfo fieldInfo_0, FieldInfo fieldInfo_1)
		{
			return fieldInfo_0 != fieldInfo_1;
		}

		// Token: 0x06002345 RID: 9029 RVA: 0x0001CA16 File Offset: 0x0001AC16
		static bool smethod_8(FieldInfo fieldInfo_0)
		{
			return fieldInfo_0.IsStatic;
		}

		// Token: 0x06002346 RID: 9030 RVA: 0x0001CA1E File Offset: 0x0001AC1E
		static bool smethod_9(PropertyInfo propertyInfo_0, PropertyInfo propertyInfo_1)
		{
			return propertyInfo_0 != propertyInfo_1;
		}

		// Token: 0x06002347 RID: 9031 RVA: 0x000162CE File Offset: 0x000144CE
		static Type smethod_10(PropertyInfo propertyInfo_0)
		{
			return propertyInfo_0.PropertyType;
		}

		// Token: 0x06002348 RID: 9032 RVA: 0x00015F44 File Offset: 0x00014144
		static Type smethod_11(Type type_0)
		{
			return type_0.GetGenericTypeDefinition();
		}

		// Token: 0x06002349 RID: 9033 RVA: 0x00017761 File Offset: 0x00015961
		static string smethod_12(Type type_0)
		{
			return type_0.FullName;
		}

		// Token: 0x0600234A RID: 9034 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_13(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x0600234B RID: 9035 RVA: 0x0001CA27 File Offset: 0x0001AC27
		static bool smethod_14(ConstructorInfo constructorInfo_0, ConstructorInfo constructorInfo_1)
		{
			return constructorInfo_0 != constructorInfo_1;
		}

		// Token: 0x0600234C RID: 9036 RVA: 0x0001CA30 File Offset: 0x0001AC30
		static bool smethod_15(MemberInfo memberInfo_0, MemberInfo memberInfo_1)
		{
			return memberInfo_0 != memberInfo_1;
		}

		// Token: 0x0600234D RID: 9037 RVA: 0x00015F4C File Offset: 0x0001414C
		static Type[] smethod_16(Type type_0)
		{
			return type_0.GetGenericArguments();
		}

		// Token: 0x0600234E RID: 9038 RVA: 0x00017625 File Offset: 0x00015825
		static bool smethod_17(Type type_0, Type type_1)
		{
			return type_0.IsAssignableFrom(type_1);
		}

		// Token: 0x0600234F RID: 9039 RVA: 0x00016303 File Offset: 0x00014503
		static Type smethod_18(Type type_0, Type[] type_1)
		{
			return type_0.MakeGenericType(type_1);
		}

		// Token: 0x06002350 RID: 9040 RVA: 0x0001CA39 File Offset: 0x0001AC39
		static MethodInfo smethod_19(Type type_0, string string_0, Type[] type_1)
		{
			return type_0.GetMethod(string_0, type_1);
		}

		// Token: 0x06002351 RID: 9041 RVA: 0x0001CA43 File Offset: 0x0001AC43
		static ConstructorInfo[] smethod_20(Type type_0)
		{
			return type_0.GetConstructors();
		}

		// Token: 0x06002352 RID: 9042 RVA: 0x0001CA4B File Offset: 0x0001AC4B
		static ConstructorInfo[] smethod_21(Type type_0, BindingFlags bindingFlags_0)
		{
			return type_0.GetConstructors(bindingFlags_0);
		}

		// Token: 0x06002353 RID: 9043 RVA: 0x000175AD File Offset: 0x000157AD
		static ConstructorInfo smethod_22(Type type_0, Type[] type_1)
		{
			return type_0.GetConstructor(type_1);
		}

		// Token: 0x06002354 RID: 9044 RVA: 0x0001CA54 File Offset: 0x0001AC54
		static ParameterInfo[] smethod_23(MethodBase methodBase_0)
		{
			return methodBase_0.GetParameters();
		}

		// Token: 0x06002355 RID: 9045 RVA: 0x00014858 File Offset: 0x00012A58
		static Type smethod_24(MemberInfo memberInfo_0)
		{
			return memberInfo_0.DeclaringType;
		}

		// Token: 0x06002356 RID: 9046 RVA: 0x0001CA5C File Offset: 0x0001AC5C
		static string smethod_25(ParameterInfo parameterInfo_0)
		{
			return parameterInfo_0.Name;
		}

		// Token: 0x06002357 RID: 9047 RVA: 0x0001CA64 File Offset: 0x0001AC64
		static Type smethod_26(ParameterInfo parameterInfo_0)
		{
			return parameterInfo_0.ParameterType;
		}

		// Token: 0x06002358 RID: 9048 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_27(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x06002359 RID: 9049 RVA: 0x0001CA6C File Offset: 0x0001AC6C
		static MemberInfo smethod_28(ParameterInfo parameterInfo_0)
		{
			return parameterInfo_0.Member;
		}

		// Token: 0x0600235A RID: 9050 RVA: 0x0000CDA1 File Offset: 0x0000AFA1
		static bool smethod_29(string string_0, string string_1)
		{
			return string_0 != string_1;
		}

		// Token: 0x0600235B RID: 9051 RVA: 0x0001CA74 File Offset: 0x0001AC74
		static bool smethod_30(DataContractAttribute dataContractAttribute_0)
		{
			return dataContractAttribute_0.IsReference;
		}

		// Token: 0x0600235C RID: 9052 RVA: 0x0001CA7C File Offset: 0x0001AC7C
		static bool smethod_31(ConstructorInfo constructorInfo_0, ConstructorInfo constructorInfo_1)
		{
			return constructorInfo_0 == constructorInfo_1;
		}

		// Token: 0x0600235D RID: 9053 RVA: 0x0001CA85 File Offset: 0x0001AC85
		static MethodInfo[] smethod_32(Type type_0, BindingFlags bindingFlags_0)
		{
			return type_0.GetMethods(bindingFlags_0);
		}

		// Token: 0x0600235E RID: 9054 RVA: 0x0001CA8E File Offset: 0x0001AC8E
		static bool smethod_33(MethodBase methodBase_0)
		{
			return methodBase_0.ContainsGenericParameters;
		}

		// Token: 0x0600235F RID: 9055 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_34(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x06002360 RID: 9056 RVA: 0x0001CA96 File Offset: 0x0001AC96
		static ConstructorInfo smethod_35(Type type_0, BindingFlags bindingFlags_0, Binder binder_0, Type[] type_1, ParameterModifier[] parameterModifier_0)
		{
			return type_0.GetConstructor(bindingFlags_0, binder_0, type_1, parameterModifier_0);
		}

		// Token: 0x06002361 RID: 9057 RVA: 0x0001CAA3 File Offset: 0x0001ACA3
		static bool smethod_36(Type type_0, Type type_1)
		{
			return type_0.IsSubclassOf(type_1);
		}

		// Token: 0x06002362 RID: 9058 RVA: 0x000175B6 File Offset: 0x000157B6
		static Type smethod_37(Type type_0)
		{
			return Nullable.GetUnderlyingType(type_0);
		}

		// Token: 0x06002363 RID: 9059 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_38(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06002364 RID: 9060 RVA: 0x0001CAAC File Offset: 0x0001ACAC
		static bool smethod_39(TypeConverter typeConverter_0, Type type_0)
		{
			return typeConverter_0.CanConvertTo(type_0);
		}

		// Token: 0x06002365 RID: 9061 RVA: 0x0001CAB5 File Offset: 0x0001ACB5
		static bool smethod_40(MethodInfo methodInfo_0, MethodInfo methodInfo_1)
		{
			return methodInfo_0 != methodInfo_1;
		}

		// Token: 0x06002366 RID: 9062 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_41()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06002367 RID: 9063 RVA: 0x0001CABE File Offset: 0x0001ACBE
		static bool smethod_42(MethodBase methodBase_0)
		{
			return methodBase_0.IsVirtual;
		}

		// Token: 0x06002368 RID: 9064 RVA: 0x0001CAC6 File Offset: 0x0001ACC6
		static Type smethod_43(MethodInfo methodInfo_0)
		{
			return methodInfo_0.ReturnType;
		}

		// Token: 0x06002369 RID: 9065 RVA: 0x0001CACE File Offset: 0x0001ACCE
		static string smethod_44(Type type_0)
		{
			return type_0.Namespace;
		}

		// Token: 0x0600236A RID: 9066 RVA: 0x0000EAE8 File Offset: 0x0000CCE8
		static string smethod_45(IFormatProvider iformatProvider_0, string string_0, object[] object_0)
		{
			return string.Format(iformatProvider_0, string_0, object_0);
		}

		// Token: 0x0600236B RID: 9067 RVA: 0x0001CAD6 File Offset: 0x0001ACD6
		static string smethod_46(DataMemberAttribute dataMemberAttribute_0)
		{
			return dataMemberAttribute_0.Name;
		}

		// Token: 0x0600236C RID: 9068 RVA: 0x0001CADE File Offset: 0x0001ACDE
		static bool smethod_47(DataMemberAttribute dataMemberAttribute_0)
		{
			return dataMemberAttribute_0.IsRequired;
		}

		// Token: 0x0600236D RID: 9069 RVA: 0x0001CAE6 File Offset: 0x0001ACE6
		static int smethod_48(DataMemberAttribute dataMemberAttribute_0)
		{
			return dataMemberAttribute_0.Order;
		}

		// Token: 0x0600236E RID: 9070 RVA: 0x0001CAEE File Offset: 0x0001ACEE
		static bool smethod_49(DataMemberAttribute dataMemberAttribute_0)
		{
			return dataMemberAttribute_0.EmitDefaultValue;
		}

		// Token: 0x0600236F RID: 9071 RVA: 0x0001CAF6 File Offset: 0x0001ACF6
		static object smethod_50(DefaultValueAttribute defaultValueAttribute_0)
		{
			return defaultValueAttribute_0.Value;
		}

		// Token: 0x06002370 RID: 9072 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_51(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x06002371 RID: 9073 RVA: 0x0001CAFE File Offset: 0x0001ACFE
		static bool smethod_52(MethodInfo methodInfo_0, MethodInfo methodInfo_1)
		{
			return methodInfo_0 == methodInfo_1;
		}

		// Token: 0x06002372 RID: 9074 RVA: 0x0001CB07 File Offset: 0x0001AD07
		static PropertyInfo smethod_53(Type type_0, string string_0)
		{
			return type_0.GetProperty(string_0);
		}

		// Token: 0x06002373 RID: 9075 RVA: 0x0001CB10 File Offset: 0x0001AD10
		static bool smethod_54(MemberInfo memberInfo_0, MemberInfo memberInfo_1)
		{
			return memberInfo_0 == memberInfo_1;
		}

		// Token: 0x06002374 RID: 9076 RVA: 0x000130E3 File Offset: 0x000112E3
		static FieldInfo smethod_55(Type type_0, string string_0)
		{
			return type_0.GetField(string_0);
		}

		// Token: 0x06002375 RID: 9077 RVA: 0x00016369 File Offset: 0x00014569
		static PropertyInfo[] smethod_56(Type type_0, BindingFlags bindingFlags_0)
		{
			return type_0.GetProperties(bindingFlags_0);
		}

		// Token: 0x06002376 RID: 9078 RVA: 0x0001CB19 File Offset: 0x0001AD19
		static FieldInfo[] smethod_57(Type type_0, BindingFlags bindingFlags_0)
		{
			return type_0.GetFields(bindingFlags_0);
		}

		// Token: 0x06002377 RID: 9079 RVA: 0x00013209 File Offset: 0x00011409
		static object smethod_58()
		{
			return new object();
		}

		// Token: 0x04000C6F RID: 3183
		private static readonly IContractResolver _instance = new DefaultContractResolver(true);

		// Token: 0x04000C70 RID: 3184
		private static readonly JsonConverter[] BuiltInConverters = new JsonConverter[]
		{
			new EntityKeyMemberConverter(),
			new ExpandoObjectConverter(),
			new XmlNodeConverter(),
			new BinaryConverter(),
			new DataSetConverter(),
			new DataTableConverter(),
			new DiscriminatedUnionConverter(),
			new KeyValuePairConverter(),
			new BsonObjectIdConverter(),
			new RegexConverter()
		};

		// Token: 0x04000C71 RID: 3185
		private static readonly object TypeContractCacheLock = DefaultContractResolver.smethod_58();

		// Token: 0x04000C72 RID: 3186
		private static readonly DefaultContractResolverState _sharedState = new DefaultContractResolverState();

		// Token: 0x04000C73 RID: 3187
		private readonly DefaultContractResolverState _instanceState = new DefaultContractResolverState();

		// Token: 0x04000C74 RID: 3188
		private readonly bool _sharedCache;

		// Token: 0x02000257 RID: 599
		internal struct DictionaryEnumerator<TEnumeratorKey, TEnumeratorValue> : IEnumerable<KeyValuePair<object, object>>, IEnumerator<KeyValuePair<object, object>>, IEnumerator, IEnumerable, IDisposable
		{
			// Token: 0x06002378 RID: 9080 RVA: 0x0001CB22 File Offset: 0x0001AD22
			public DictionaryEnumerator(IEnumerable<KeyValuePair<TEnumeratorKey, TEnumeratorValue>> e)
			{
				ValidationUtils.ArgumentNotNull(e, <Module>.smethod_24<string>(3101375999U));
				this._e = e.GetEnumerator();
			}

			// Token: 0x06002379 RID: 9081 RVA: 0x0001CB40 File Offset: 0x0001AD40
			public bool MoveNext()
			{
				return DefaultContractResolver.DictionaryEnumerator<TEnumeratorKey, TEnumeratorValue>.smethod_0(this._e);
			}

			// Token: 0x0600237A RID: 9082 RVA: 0x0001CB4D File Offset: 0x0001AD4D
			public void Reset()
			{
				DefaultContractResolver.DictionaryEnumerator<TEnumeratorKey, TEnumeratorValue>.smethod_1(this._e);
			}

			// Token: 0x17000539 RID: 1337
			// (get) Token: 0x0600237B RID: 9083 RVA: 0x0008C7D0 File Offset: 0x0008A9D0
			public KeyValuePair<object, object> Current
			{
				get
				{
					KeyValuePair<TEnumeratorKey, TEnumeratorValue> keyValuePair = this._e.Current;
					object obj = keyValuePair.Key;
					KeyValuePair<TEnumeratorKey, TEnumeratorValue> keyValuePair2 = this._e.Current;
					return new KeyValuePair<object, object>(obj, keyValuePair2.Value);
				}
			}

			// Token: 0x0600237C RID: 9084 RVA: 0x0001CB5A File Offset: 0x0001AD5A
			public void Dispose()
			{
				DefaultContractResolver.DictionaryEnumerator<TEnumeratorKey, TEnumeratorValue>.smethod_2(this._e);
			}

			// Token: 0x1700053A RID: 1338
			// (get) Token: 0x0600237D RID: 9085 RVA: 0x0001CB67 File Offset: 0x0001AD67
			object IEnumerator.Current
			{
				get
				{
					return this.Current;
				}
			}

			// Token: 0x0600237E RID: 9086 RVA: 0x0001CB74 File Offset: 0x0001AD74
			public IEnumerator<KeyValuePair<object, object>> GetEnumerator()
			{
				return this;
			}

			// Token: 0x0600237F RID: 9087 RVA: 0x0001CB74 File Offset: 0x0001AD74
			IEnumerator IEnumerable.GetEnumerator()
			{
				return this;
			}

			// Token: 0x04000C7F RID: 3199
			private readonly IEnumerator<KeyValuePair<TEnumeratorKey, TEnumeratorValue>> _e;
		}
	}
}
