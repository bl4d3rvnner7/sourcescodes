﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000261 RID: 609
	public class JsonArrayContract : JsonContainerContract
	{
		// Token: 0x17000541 RID: 1345
		// (get) Token: 0x060023B6 RID: 9142 RVA: 0x0001CDCF File Offset: 0x0001AFCF
		// (set) Token: 0x060023B7 RID: 9143 RVA: 0x0001CDD7 File Offset: 0x0001AFD7
		public Type CollectionItemType { get; private set; }

		// Token: 0x17000542 RID: 1346
		// (get) Token: 0x060023B8 RID: 9144 RVA: 0x0001CDE0 File Offset: 0x0001AFE0
		// (set) Token: 0x060023B9 RID: 9145 RVA: 0x0001CDE8 File Offset: 0x0001AFE8
		public bool IsMultidimensionalArray { get; private set; }

		// Token: 0x17000543 RID: 1347
		// (get) Token: 0x060023BA RID: 9146 RVA: 0x0001CDF1 File Offset: 0x0001AFF1
		// (set) Token: 0x060023BB RID: 9147 RVA: 0x0001CDF9 File Offset: 0x0001AFF9
		internal bool IsArray { get; private set; }

		// Token: 0x17000544 RID: 1348
		// (get) Token: 0x060023BC RID: 9148 RVA: 0x0001CE02 File Offset: 0x0001B002
		// (set) Token: 0x060023BD RID: 9149 RVA: 0x0001CE0A File Offset: 0x0001B00A
		internal bool ShouldCreateWrapper { get; private set; }

		// Token: 0x17000545 RID: 1349
		// (get) Token: 0x060023BE RID: 9150 RVA: 0x0001CE13 File Offset: 0x0001B013
		// (set) Token: 0x060023BF RID: 9151 RVA: 0x0001CE1B File Offset: 0x0001B01B
		internal bool CanDeserialize { get; private set; }

		// Token: 0x17000546 RID: 1350
		// (get) Token: 0x060023C0 RID: 9152 RVA: 0x0001CE24 File Offset: 0x0001B024
		internal ObjectConstructor<object> ParametrizedCreator
		{
			get
			{
				if (this._parametrizedCreator == null)
				{
					this._parametrizedCreator = JsonTypeReflector.ReflectionDelegateFactory.CreateParametrizedConstructor(this._parametrizedConstructor);
				}
				return this._parametrizedCreator;
			}
		}

		// Token: 0x17000547 RID: 1351
		// (get) Token: 0x060023C1 RID: 9153 RVA: 0x0001CE4A File Offset: 0x0001B04A
		internal bool HasParametrizedCreator
		{
			get
			{
				return this._parametrizedCreator != null || JsonArrayContract.smethod_6(this._parametrizedConstructor, null);
			}
		}

		// Token: 0x060023C2 RID: 9154 RVA: 0x0008C9C8 File Offset: 0x0008ABC8
		public JsonArrayContract(Type underlyingType)
			: base(underlyingType)
		{
			this.ContractType = JsonContractType.Array;
			this.IsArray = JsonArrayContract.smethod_7(base.CreatedType);
			bool flag;
			if (this.IsArray)
			{
				this.CollectionItemType = ReflectionUtils.GetCollectionItemType(base.UnderlyingType);
				this.IsReadOnlyOrFixedSize = true;
				this._genericCollectionDefinitionType = JsonArrayContract.smethod_9(JsonArrayContract.smethod_8(typeof(List<>).TypeHandle), new Type[] { this.CollectionItemType });
				flag = true;
				this.IsMultidimensionalArray = this.IsArray && JsonArrayContract.smethod_10(base.UnderlyingType) > 1;
			}
			else if (JsonArrayContract.smethod_11(JsonArrayContract.smethod_8(typeof(IList).TypeHandle), underlyingType))
			{
				if (!ReflectionUtils.ImplementsGenericDefinition(underlyingType, JsonArrayContract.smethod_8(typeof(ICollection<>).TypeHandle), out this._genericCollectionDefinitionType))
				{
					this.CollectionItemType = ReflectionUtils.GetCollectionItemType(underlyingType);
				}
				else
				{
					this.CollectionItemType = JsonArrayContract.smethod_12(this._genericCollectionDefinitionType)[0];
				}
				if (JsonArrayContract.smethod_13(underlyingType, JsonArrayContract.smethod_8(typeof(IList).TypeHandle)))
				{
					base.CreatedType = JsonArrayContract.smethod_8(typeof(List<object>).TypeHandle);
				}
				if (JsonArrayContract.smethod_14(this.CollectionItemType, null))
				{
					this._parametrizedConstructor = CollectionUtils.ResolveEnumerableCollectionConstructor(underlyingType, this.CollectionItemType);
				}
				this.IsReadOnlyOrFixedSize = ReflectionUtils.InheritsGenericDefinition(underlyingType, JsonArrayContract.smethod_8(typeof(ReadOnlyCollection<>).TypeHandle));
				flag = true;
			}
			else if (!ReflectionUtils.ImplementsGenericDefinition(underlyingType, JsonArrayContract.smethod_8(typeof(ICollection<>).TypeHandle), out this._genericCollectionDefinitionType))
			{
				Type type;
				if (ReflectionUtils.ImplementsGenericDefinition(underlyingType, JsonArrayContract.smethod_8(typeof(IEnumerable<>).TypeHandle), out type))
				{
					this.CollectionItemType = JsonArrayContract.smethod_12(type)[0];
					if (ReflectionUtils.IsGenericDefinition(base.UnderlyingType, JsonArrayContract.smethod_8(typeof(IEnumerable<>).TypeHandle)))
					{
						base.CreatedType = JsonArrayContract.smethod_9(JsonArrayContract.smethod_8(typeof(List<>).TypeHandle), new Type[] { this.CollectionItemType });
					}
					this._parametrizedConstructor = CollectionUtils.ResolveEnumerableCollectionConstructor(underlyingType, this.CollectionItemType);
					if (!this.HasParametrizedCreator && JsonArrayContract.smethod_16(JsonArrayContract.smethod_15(underlyingType), <Module>.smethod_26<string>(746306708U)))
					{
						FSharpUtils.EnsureInitialized(underlyingType.Assembly());
						this._parametrizedCreator = FSharpUtils.CreateSeq(this.CollectionItemType);
					}
					if (underlyingType.IsGenericType() && JsonArrayContract.smethod_13(JsonArrayContract.smethod_17(underlyingType), JsonArrayContract.smethod_8(typeof(IEnumerable<>).TypeHandle)))
					{
						this._genericCollectionDefinitionType = type;
						this.IsReadOnlyOrFixedSize = false;
						this.ShouldCreateWrapper = false;
						flag = true;
					}
					else
					{
						this._genericCollectionDefinitionType = JsonArrayContract.smethod_9(JsonArrayContract.smethod_8(typeof(List<>).TypeHandle), new Type[] { this.CollectionItemType });
						this.IsReadOnlyOrFixedSize = true;
						this.ShouldCreateWrapper = true;
						flag = this.HasParametrizedCreator;
					}
				}
				else
				{
					flag = false;
					this.ShouldCreateWrapper = true;
				}
			}
			else
			{
				this.CollectionItemType = JsonArrayContract.smethod_12(this._genericCollectionDefinitionType)[0];
				if (ReflectionUtils.IsGenericDefinition(underlyingType, JsonArrayContract.smethod_8(typeof(ICollection<>).TypeHandle)) || ReflectionUtils.IsGenericDefinition(underlyingType, JsonArrayContract.smethod_8(typeof(IList<>).TypeHandle)))
				{
					base.CreatedType = JsonArrayContract.smethod_9(JsonArrayContract.smethod_8(typeof(List<>).TypeHandle), new Type[] { this.CollectionItemType });
				}
				if (ReflectionUtils.IsGenericDefinition(underlyingType, JsonArrayContract.smethod_8(typeof(ISet<>).TypeHandle)))
				{
					base.CreatedType = JsonArrayContract.smethod_9(JsonArrayContract.smethod_8(typeof(HashSet<>).TypeHandle), new Type[] { this.CollectionItemType });
				}
				this._parametrizedConstructor = CollectionUtils.ResolveEnumerableCollectionConstructor(underlyingType, this.CollectionItemType);
				flag = true;
				this.ShouldCreateWrapper = true;
			}
			this.CanDeserialize = flag;
		}

		// Token: 0x060023C3 RID: 9155 RVA: 0x0008CD40 File Offset: 0x0008AF40
		internal IWrappedCollection CreateWrapper(object list)
		{
			if (this._genericWrapperCreator == null)
			{
				this._genericWrapperType = JsonArrayContract.smethod_9(JsonArrayContract.smethod_8(typeof(CollectionWrapper<>).TypeHandle), new Type[] { this.CollectionItemType });
				Type type;
				if (!ReflectionUtils.InheritsGenericDefinition(this._genericCollectionDefinitionType, JsonArrayContract.smethod_8(typeof(List<>).TypeHandle)) && !JsonArrayContract.smethod_13(JsonArrayContract.smethod_17(this._genericCollectionDefinitionType), JsonArrayContract.smethod_8(typeof(IEnumerable<>).TypeHandle)))
				{
					type = this._genericCollectionDefinitionType;
				}
				else
				{
					type = JsonArrayContract.smethod_9(JsonArrayContract.smethod_8(typeof(ICollection<>).TypeHandle), new Type[] { this.CollectionItemType });
				}
				ConstructorInfo constructorInfo = JsonArrayContract.smethod_18(this._genericWrapperType, new Type[] { type });
				this._genericWrapperCreator = JsonTypeReflector.ReflectionDelegateFactory.CreateParametrizedConstructor(constructorInfo);
			}
			return (IWrappedCollection)this._genericWrapperCreator(new object[] { list });
		}

		// Token: 0x060023C4 RID: 9156 RVA: 0x0008CE34 File Offset: 0x0008B034
		internal IList CreateTemporaryCollection()
		{
			if (this._genericTemporaryCollectionCreator == null)
			{
				Type type = (this.IsMultidimensionalArray ? JsonArrayContract.smethod_8(typeof(object).TypeHandle) : this.CollectionItemType);
				Type type2 = JsonArrayContract.smethod_9(JsonArrayContract.smethod_8(typeof(List<>).TypeHandle), new Type[] { type });
				this._genericTemporaryCollectionCreator = JsonTypeReflector.ReflectionDelegateFactory.CreateDefaultConstructor<object>(type2);
			}
			return (IList)this._genericTemporaryCollectionCreator();
		}

		// Token: 0x060023C5 RID: 9157 RVA: 0x0001CA27 File Offset: 0x0001AC27
		static bool smethod_6(ConstructorInfo constructorInfo_0, ConstructorInfo constructorInfo_1)
		{
			return constructorInfo_0 != constructorInfo_1;
		}

		// Token: 0x060023C6 RID: 9158 RVA: 0x00015F2C File Offset: 0x0001412C
		static bool smethod_7(Type type_0)
		{
			return type_0.IsArray;
		}

		// Token: 0x060023C7 RID: 9159 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_8(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060023C8 RID: 9160 RVA: 0x00016303 File Offset: 0x00014503
		static Type smethod_9(Type type_0, Type[] type_1)
		{
			return type_0.MakeGenericType(type_1);
		}

		// Token: 0x060023C9 RID: 9161 RVA: 0x0001CE62 File Offset: 0x0001B062
		static int smethod_10(Type type_0)
		{
			return type_0.GetArrayRank();
		}

		// Token: 0x060023CA RID: 9162 RVA: 0x00017625 File Offset: 0x00015825
		static bool smethod_11(Type type_0, Type type_1)
		{
			return type_0.IsAssignableFrom(type_1);
		}

		// Token: 0x060023CB RID: 9163 RVA: 0x00015F4C File Offset: 0x0001414C
		static Type[] smethod_12(Type type_0)
		{
			return type_0.GetGenericArguments();
		}

		// Token: 0x060023CC RID: 9164 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_13(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x060023CD RID: 9165 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_14(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x060023CE RID: 9166 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_15(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x060023CF RID: 9167 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_16(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x060023D0 RID: 9168 RVA: 0x00015F44 File Offset: 0x00014144
		static Type smethod_17(Type type_0)
		{
			return type_0.GetGenericTypeDefinition();
		}

		// Token: 0x060023D1 RID: 9169 RVA: 0x000175AD File Offset: 0x000157AD
		static ConstructorInfo smethod_18(Type type_0, Type[] type_1)
		{
			return type_0.GetConstructor(type_1);
		}

		// Token: 0x04000C97 RID: 3223
		private readonly Type _genericCollectionDefinitionType;

		// Token: 0x04000C98 RID: 3224
		private Type _genericWrapperType;

		// Token: 0x04000C99 RID: 3225
		private ObjectConstructor<object> _genericWrapperCreator;

		// Token: 0x04000C9A RID: 3226
		private Func<object> _genericTemporaryCollectionCreator;

		// Token: 0x04000C9B RID: 3227
		private readonly ConstructorInfo _parametrizedConstructor;

		// Token: 0x04000C9C RID: 3228
		private ObjectConstructor<object> _parametrizedCreator;
	}
}
