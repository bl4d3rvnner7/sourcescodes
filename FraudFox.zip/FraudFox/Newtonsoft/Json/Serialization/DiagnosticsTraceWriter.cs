﻿using System;
using System.Collections;
using System.Diagnostics;
using System.Threading;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001D9 RID: 473
	public class DiagnosticsTraceWriter : ITraceWriter
	{
		// Token: 0x170003C6 RID: 966
		// (get) Token: 0x06001A9C RID: 6812 RVA: 0x000180BA File Offset: 0x000162BA
		// (set) Token: 0x06001A9D RID: 6813 RVA: 0x000180C2 File Offset: 0x000162C2
		public TraceLevel LevelFilter { get; set; }

		// Token: 0x06001A9E RID: 6814 RVA: 0x0007AB60 File Offset: 0x00078D60
		private TraceEventType GetTraceEventType(TraceLevel level)
		{
			switch (level)
			{
			case TraceLevel.Error:
				return TraceEventType.Error;
			case TraceLevel.Warning:
				return TraceEventType.Warning;
			case TraceLevel.Info:
				return TraceEventType.Information;
			case TraceLevel.Verbose:
				return TraceEventType.Verbose;
			default:
				throw DiagnosticsTraceWriter.smethod_0(<Module>.smethod_27<string>(1499160367U));
			}
		}

		// Token: 0x06001A9F RID: 6815 RVA: 0x0007ABA0 File Offset: 0x00078DA0
		public void Trace(TraceLevel level, string message, Exception ex)
		{
			if (level == TraceLevel.Off)
			{
				return;
			}
			TraceEventCache traceEventCache = DiagnosticsTraceWriter.smethod_1();
			TraceEventType traceEventType = this.GetTraceEventType(level);
			IEnumerator enumerator = DiagnosticsTraceWriter.smethod_3(DiagnosticsTraceWriter.smethod_2());
			try
			{
				while (DiagnosticsTraceWriter.smethod_11(enumerator))
				{
					TraceListener traceListener = (TraceListener)DiagnosticsTraceWriter.smethod_4(enumerator);
					if (!DiagnosticsTraceWriter.smethod_5(traceListener))
					{
						bool flag = false;
						try
						{
							TraceListener traceListener2;
							DiagnosticsTraceWriter.smethod_6(traceListener2 = traceListener, ref flag);
							DiagnosticsTraceWriter.smethod_7(traceListener, traceEventCache, <Module>.smethod_27<string>(1452538674U), traceEventType, 0, message);
							goto IL_0078;
						}
						finally
						{
							if (flag)
							{
								TraceListener traceListener2;
								DiagnosticsTraceWriter.smethod_8(traceListener2);
							}
						}
						goto IL_0064;
					}
					goto IL_0064;
					IL_0078:
					if (DiagnosticsTraceWriter.smethod_9())
					{
						DiagnosticsTraceWriter.smethod_10(traceListener);
						continue;
					}
					continue;
					IL_0064:
					DiagnosticsTraceWriter.smethod_7(traceListener, traceEventCache, <Module>.smethod_24<string>(137629107U), traceEventType, 0, message);
					goto IL_0078;
				}
			}
			finally
			{
				IDisposable disposable = enumerator as IDisposable;
				if (disposable != null)
				{
					DiagnosticsTraceWriter.smethod_12(disposable);
				}
			}
		}

		// Token: 0x06001AA1 RID: 6817 RVA: 0x0000F870 File Offset: 0x0000DA70
		static ArgumentOutOfRangeException smethod_0(string string_0)
		{
			return new ArgumentOutOfRangeException(string_0);
		}

		// Token: 0x06001AA2 RID: 6818 RVA: 0x000180CB File Offset: 0x000162CB
		static TraceEventCache smethod_1()
		{
			return new TraceEventCache();
		}

		// Token: 0x06001AA3 RID: 6819 RVA: 0x000180D2 File Offset: 0x000162D2
		static TraceListenerCollection smethod_2()
		{
			return global::System.Diagnostics.Trace.Listeners;
		}

		// Token: 0x06001AA4 RID: 6820 RVA: 0x000180D9 File Offset: 0x000162D9
		static IEnumerator smethod_3(TraceListenerCollection traceListenerCollection_0)
		{
			return traceListenerCollection_0.GetEnumerator();
		}

		// Token: 0x06001AA5 RID: 6821 RVA: 0x0000D8E2 File Offset: 0x0000BAE2
		static object smethod_4(IEnumerator ienumerator_0)
		{
			return ienumerator_0.Current;
		}

		// Token: 0x06001AA6 RID: 6822 RVA: 0x000180E1 File Offset: 0x000162E1
		static bool smethod_5(TraceListener traceListener_0)
		{
			return traceListener_0.IsThreadSafe;
		}

		// Token: 0x06001AA7 RID: 6823 RVA: 0x0000DBD7 File Offset: 0x0000BDD7
		static void smethod_6(object object_0, ref bool bool_0)
		{
			Monitor.Enter(object_0, ref bool_0);
		}

		// Token: 0x06001AA8 RID: 6824 RVA: 0x000180E9 File Offset: 0x000162E9
		static void smethod_7(TraceListener traceListener_0, TraceEventCache traceEventCache_0, string string_0, TraceEventType traceEventType_0, int int_0, string string_1)
		{
			traceListener_0.TraceEvent(traceEventCache_0, string_0, traceEventType_0, int_0, string_1);
		}

		// Token: 0x06001AA9 RID: 6825 RVA: 0x0000DBEF File Offset: 0x0000BDEF
		static void smethod_8(object object_0)
		{
			Monitor.Exit(object_0);
		}

		// Token: 0x06001AAA RID: 6826 RVA: 0x000180F8 File Offset: 0x000162F8
		static bool smethod_9()
		{
			return global::System.Diagnostics.Trace.AutoFlush;
		}

		// Token: 0x06001AAB RID: 6827 RVA: 0x000180FF File Offset: 0x000162FF
		static void smethod_10(TraceListener traceListener_0)
		{
			traceListener_0.Flush();
		}

		// Token: 0x06001AAC RID: 6828 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_11(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06001AAD RID: 6829 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_12(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}
	}
}
