﻿using System;
using System.Dynamic;
using System.Runtime.CompilerServices;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001F6 RID: 502
	public class JsonDynamicContract : JsonContainerContract
	{
		// Token: 0x17000405 RID: 1029
		// (get) Token: 0x06001CB8 RID: 7352 RVA: 0x000192B8 File Offset: 0x000174B8
		// (set) Token: 0x06001CB9 RID: 7353 RVA: 0x000192C0 File Offset: 0x000174C0
		public JsonPropertyCollection Properties { get; private set; }

		// Token: 0x17000406 RID: 1030
		// (get) Token: 0x06001CBA RID: 7354 RVA: 0x000192C9 File Offset: 0x000174C9
		// (set) Token: 0x06001CBB RID: 7355 RVA: 0x000192D1 File Offset: 0x000174D1
		public Func<string, string> PropertyNameResolver { get; set; }

		// Token: 0x06001CBC RID: 7356 RVA: 0x0007F46C File Offset: 0x0007D66C
		private static CallSite<Func<CallSite, object, object>> CreateCallSiteGetter(string name)
		{
			GetMemberBinder getMemberBinder = (GetMemberBinder)DynamicUtils.BinderWrapper.GetMember(name, JsonDynamicContract.smethod_6(typeof(DynamicUtils).TypeHandle));
			return CallSite<Func<CallSite, object, object>>.Create(new NoThrowGetBinderMember(getMemberBinder));
		}

		// Token: 0x06001CBD RID: 7357 RVA: 0x0007F49C File Offset: 0x0007D69C
		private static CallSite<Func<CallSite, object, object, object>> CreateCallSiteSetter(string name)
		{
			SetMemberBinder setMemberBinder = (SetMemberBinder)DynamicUtils.BinderWrapper.SetMember(name, JsonDynamicContract.smethod_6(typeof(DynamicUtils).TypeHandle));
			return CallSite<Func<CallSite, object, object, object>>.Create(new NoThrowSetBinderMember(setMemberBinder));
		}

		// Token: 0x06001CBE RID: 7358 RVA: 0x0007F4CC File Offset: 0x0007D6CC
		public JsonDynamicContract(Type underlyingType)
			: base(underlyingType)
		{
			this.ContractType = JsonContractType.Dynamic;
			this.Properties = new JsonPropertyCollection(base.UnderlyingType);
		}

		// Token: 0x06001CBF RID: 7359 RVA: 0x0007F528 File Offset: 0x0007D728
		internal bool TryGetMember(IDynamicMetaObjectProvider dynamicProvider, string name, out object value)
		{
			ValidationUtils.ArgumentNotNull(dynamicProvider, <Module>.smethod_26<string>(662535967U));
			CallSite<Func<CallSite, object, object>> callSite = this._callSiteGetters.Get(name);
			object obj = callSite.Target(callSite, dynamicProvider);
			if (JsonDynamicContract.smethod_7(obj, NoThrowExpressionVisitor.ErrorResult))
			{
				value = null;
				return false;
			}
			value = obj;
			return true;
		}

		// Token: 0x06001CC0 RID: 7360 RVA: 0x0007F578 File Offset: 0x0007D778
		internal bool TrySetMember(IDynamicMetaObjectProvider dynamicProvider, string name, object value)
		{
			ValidationUtils.ArgumentNotNull(dynamicProvider, <Module>.smethod_27<string>(1686545885U));
			CallSite<Func<CallSite, object, object, object>> callSite = this._callSiteSetters.Get(name);
			object obj = callSite.Target(callSite, dynamicProvider, value);
			return !JsonDynamicContract.smethod_7(obj, NoThrowExpressionVisitor.ErrorResult);
		}

		// Token: 0x06001CC1 RID: 7361 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_6(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001CC2 RID: 7362 RVA: 0x0000F49D File Offset: 0x0000D69D
		static bool smethod_7(object object_0, object object_1)
		{
			return object.ReferenceEquals(object_0, object_1);
		}

		// Token: 0x04000AF4 RID: 2804
		private readonly ThreadSafeStore<string, CallSite<Func<CallSite, object, object>>> _callSiteGetters = new ThreadSafeStore<string, CallSite<Func<CallSite, object, object>>>(new Func<string, CallSite<Func<CallSite, object, object>>>(JsonDynamicContract.CreateCallSiteGetter));

		// Token: 0x04000AF5 RID: 2805
		private readonly ThreadSafeStore<string, CallSite<Func<CallSite, object, object, object>>> _callSiteSetters = new ThreadSafeStore<string, CallSite<Func<CallSite, object, object, object>>>(new Func<string, CallSite<Func<CallSite, object, object, object>>>(JsonDynamicContract.CreateCallSiteSetter));
	}
}
