﻿using System;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000265 RID: 613
	// (Invoke) Token: 0x060023DB RID: 9179
	public delegate void ExtensionDataSetter(object o, string key, object value);
}
