﻿using System;
using System.Globalization;
using System.IO;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001E4 RID: 484
	internal class TraceJsonReader : JsonReader, IJsonLineInfo
	{
		// Token: 0x06001B07 RID: 6919 RVA: 0x0007B35C File Offset: 0x0007955C
		public TraceJsonReader(JsonReader innerReader)
		{
			this._innerReader = innerReader;
			this._sw = TraceJsonReader.smethod_13(TraceJsonReader.smethod_12());
			TraceJsonReader.smethod_16(this._sw, TraceJsonReader.smethod_15(<Module>.smethod_26<string>(4029428922U), TraceJsonReader.smethod_14()));
			this._textWriter = new JsonTextWriter(this._sw);
			this._textWriter.Formatting = Formatting.Indented;
		}

		// Token: 0x06001B08 RID: 6920 RVA: 0x000184A6 File Offset: 0x000166A6
		public string GetDeserializedJsonMessage()
		{
			return TraceJsonReader.smethod_17(this._sw);
		}

		// Token: 0x06001B09 RID: 6921 RVA: 0x0007B3C4 File Offset: 0x000795C4
		public override bool Read()
		{
			bool flag = this._innerReader.Read();
			this._textWriter.WriteToken(this._innerReader, false, false);
			return flag;
		}

		// Token: 0x06001B0A RID: 6922 RVA: 0x0007B3F4 File Offset: 0x000795F4
		public override int? ReadAsInt32()
		{
			int? num = this._innerReader.ReadAsInt32();
			this._textWriter.WriteToken(this._innerReader, false, false);
			return num;
		}

		// Token: 0x06001B0B RID: 6923 RVA: 0x0007B424 File Offset: 0x00079624
		public override string ReadAsString()
		{
			string text = this._innerReader.ReadAsString();
			this._textWriter.WriteToken(this._innerReader, false, false);
			return text;
		}

		// Token: 0x06001B0C RID: 6924 RVA: 0x0007B454 File Offset: 0x00079654
		public override byte[] ReadAsBytes()
		{
			byte[] array = this._innerReader.ReadAsBytes();
			this._textWriter.WriteToken(this._innerReader, false, false);
			return array;
		}

		// Token: 0x06001B0D RID: 6925 RVA: 0x0007B484 File Offset: 0x00079684
		public override decimal? ReadAsDecimal()
		{
			decimal? num = this._innerReader.ReadAsDecimal();
			this._textWriter.WriteToken(this._innerReader, false, false);
			return num;
		}

		// Token: 0x06001B0E RID: 6926 RVA: 0x0007B4B4 File Offset: 0x000796B4
		public override DateTime? ReadAsDateTime()
		{
			DateTime? dateTime = this._innerReader.ReadAsDateTime();
			this._textWriter.WriteToken(this._innerReader, false, false);
			return dateTime;
		}

		// Token: 0x06001B0F RID: 6927 RVA: 0x0007B4E4 File Offset: 0x000796E4
		public override DateTimeOffset? ReadAsDateTimeOffset()
		{
			DateTimeOffset? dateTimeOffset = this._innerReader.ReadAsDateTimeOffset();
			this._textWriter.WriteToken(this._innerReader, false, false);
			return dateTimeOffset;
		}

		// Token: 0x170003E1 RID: 993
		// (get) Token: 0x06001B10 RID: 6928 RVA: 0x000184B3 File Offset: 0x000166B3
		public override int Depth
		{
			get
			{
				return this._innerReader.Depth;
			}
		}

		// Token: 0x170003E2 RID: 994
		// (get) Token: 0x06001B11 RID: 6929 RVA: 0x000184C0 File Offset: 0x000166C0
		public override string Path
		{
			get
			{
				return this._innerReader.Path;
			}
		}

		// Token: 0x170003E3 RID: 995
		// (get) Token: 0x06001B12 RID: 6930 RVA: 0x000184CD File Offset: 0x000166CD
		// (set) Token: 0x06001B13 RID: 6931 RVA: 0x000184DA File Offset: 0x000166DA
		public override char QuoteChar
		{
			get
			{
				return this._innerReader.QuoteChar;
			}
			protected internal set
			{
				this._innerReader.QuoteChar = value;
			}
		}

		// Token: 0x170003E4 RID: 996
		// (get) Token: 0x06001B14 RID: 6932 RVA: 0x000184E8 File Offset: 0x000166E8
		public override JsonToken TokenType
		{
			get
			{
				return this._innerReader.TokenType;
			}
		}

		// Token: 0x170003E5 RID: 997
		// (get) Token: 0x06001B15 RID: 6933 RVA: 0x000184F5 File Offset: 0x000166F5
		public override object Value
		{
			get
			{
				return this._innerReader.Value;
			}
		}

		// Token: 0x170003E6 RID: 998
		// (get) Token: 0x06001B16 RID: 6934 RVA: 0x00018502 File Offset: 0x00016702
		public override Type ValueType
		{
			get
			{
				return this._innerReader.ValueType;
			}
		}

		// Token: 0x06001B17 RID: 6935 RVA: 0x0001850F File Offset: 0x0001670F
		public override void Close()
		{
			this._innerReader.Close();
		}

		// Token: 0x06001B18 RID: 6936 RVA: 0x0007B514 File Offset: 0x00079714
		bool IJsonLineInfo.HasLineInfo()
		{
			IJsonLineInfo jsonLineInfo = this._innerReader as IJsonLineInfo;
			return jsonLineInfo != null && jsonLineInfo.HasLineInfo();
		}

		// Token: 0x170003E7 RID: 999
		// (get) Token: 0x06001B19 RID: 6937 RVA: 0x0007B538 File Offset: 0x00079738
		int IJsonLineInfo.LineNumber
		{
			get
			{
				IJsonLineInfo jsonLineInfo = this._innerReader as IJsonLineInfo;
				if (jsonLineInfo == null)
				{
					return 0;
				}
				return jsonLineInfo.LineNumber;
			}
		}

		// Token: 0x170003E8 RID: 1000
		// (get) Token: 0x06001B1A RID: 6938 RVA: 0x0007B55C File Offset: 0x0007975C
		int IJsonLineInfo.LinePosition
		{
			get
			{
				IJsonLineInfo jsonLineInfo = this._innerReader as IJsonLineInfo;
				if (jsonLineInfo == null)
				{
					return 0;
				}
				return jsonLineInfo.LinePosition;
			}
		}

		// Token: 0x06001B1B RID: 6939 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_12()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001B1C RID: 6940 RVA: 0x00016261 File Offset: 0x00014461
		static StringWriter smethod_13(IFormatProvider iformatProvider_0)
		{
			return new StringWriter(iformatProvider_0);
		}

		// Token: 0x06001B1D RID: 6941 RVA: 0x0000CD86 File Offset: 0x0000AF86
		static string smethod_14()
		{
			return Environment.NewLine;
		}

		// Token: 0x06001B1E RID: 6942 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_15(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x06001B1F RID: 6943 RVA: 0x000146E8 File Offset: 0x000128E8
		static void smethod_16(TextWriter textWriter_0, string string_0)
		{
			textWriter_0.Write(string_0);
		}

		// Token: 0x06001B20 RID: 6944 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_17(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x04000A90 RID: 2704
		private readonly JsonReader _innerReader;

		// Token: 0x04000A91 RID: 2705
		private readonly JsonTextWriter _textWriter;

		// Token: 0x04000A92 RID: 2706
		private readonly StringWriter _sw;
	}
}
