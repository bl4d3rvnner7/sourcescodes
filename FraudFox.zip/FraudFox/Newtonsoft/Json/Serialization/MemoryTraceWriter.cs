﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Text;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001E1 RID: 481
	public class MemoryTraceWriter : ITraceWriter
	{
		// Token: 0x170003DE RID: 990
		// (get) Token: 0x06001AF5 RID: 6901 RVA: 0x00018436 File Offset: 0x00016636
		// (set) Token: 0x06001AF6 RID: 6902 RVA: 0x0001843E File Offset: 0x0001663E
		public TraceLevel LevelFilter { get; set; }

		// Token: 0x06001AF7 RID: 6903 RVA: 0x00018447 File Offset: 0x00016647
		public MemoryTraceWriter()
		{
			this.LevelFilter = TraceLevel.Verbose;
			this._traceMessages = new Queue<string>();
		}

		// Token: 0x06001AF8 RID: 6904 RVA: 0x0007B23C File Offset: 0x0007943C
		public void Trace(TraceLevel level, string message, Exception ex)
		{
			if (this._traceMessages.Count >= 1000)
			{
				this._traceMessages.Dequeue();
			}
			StringBuilder stringBuilder = MemoryTraceWriter.smethod_0();
			stringBuilder.Append(DateTime.Now.ToString(<Module>.smethod_27<string>(1819740678U), MemoryTraceWriter.smethod_1()));
			stringBuilder.Append(<Module>.smethod_26<string>(2342675128U));
			stringBuilder.Append(level.ToString(<Module>.smethod_23<string>(3774896021U)));
			stringBuilder.Append(<Module>.smethod_27<string>(2931232896U));
			stringBuilder.Append(message);
			this._traceMessages.Enqueue(stringBuilder.ToString());
		}

		// Token: 0x06001AF9 RID: 6905 RVA: 0x00018461 File Offset: 0x00016661
		public IEnumerable<string> GetTraceMessages()
		{
			return this._traceMessages;
		}

		// Token: 0x06001AFA RID: 6906 RVA: 0x0007B2E8 File Offset: 0x000794E8
		public override string ToString()
		{
			StringBuilder stringBuilder = MemoryTraceWriter.smethod_0();
			foreach (string text in this._traceMessages)
			{
				if (MemoryTraceWriter.smethod_2(stringBuilder) > 0)
				{
					MemoryTraceWriter.smethod_3(stringBuilder);
				}
				MemoryTraceWriter.smethod_4(stringBuilder, text);
			}
			return MemoryTraceWriter.smethod_5(stringBuilder);
		}

		// Token: 0x06001AFB RID: 6907 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_0()
		{
			return new StringBuilder();
		}

		// Token: 0x06001AFC RID: 6908 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_1()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001AFD RID: 6909 RVA: 0x00010084 File Offset: 0x0000E284
		static int smethod_2(StringBuilder stringBuilder_0)
		{
			return stringBuilder_0.Length;
		}

		// Token: 0x06001AFE RID: 6910 RVA: 0x0001009E File Offset: 0x0000E29E
		static StringBuilder smethod_3(StringBuilder stringBuilder_0)
		{
			return stringBuilder_0.AppendLine();
		}

		// Token: 0x06001AFF RID: 6911 RVA: 0x0000DB11 File Offset: 0x0000BD11
		static StringBuilder smethod_4(StringBuilder stringBuilder_0, string string_0)
		{
			return stringBuilder_0.Append(string_0);
		}

		// Token: 0x06001B00 RID: 6912 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_5(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x04000A8D RID: 2701
		private readonly Queue<string> _traceMessages;
	}
}
