﻿using System;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000262 RID: 610
	internal enum JsonContractType
	{
		// Token: 0x04000CA3 RID: 3235
		None,
		// Token: 0x04000CA4 RID: 3236
		Object,
		// Token: 0x04000CA5 RID: 3237
		Array,
		// Token: 0x04000CA6 RID: 3238
		Primitive,
		// Token: 0x04000CA7 RID: 3239
		String,
		// Token: 0x04000CA8 RID: 3240
		Dictionary,
		// Token: 0x04000CA9 RID: 3241
		Dynamic,
		// Token: 0x04000CAA RID: 3242
		Serializable,
		// Token: 0x04000CAB RID: 3243
		Linq
	}
}
