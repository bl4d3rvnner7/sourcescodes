﻿using System;
using System.Diagnostics;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001D8 RID: 472
	public interface ITraceWriter
	{
		// Token: 0x170003C5 RID: 965
		// (get) Token: 0x06001A9A RID: 6810
		TraceLevel LevelFilter { get; }

		// Token: 0x06001A9B RID: 6811
		void Trace(TraceLevel level, string message, Exception ex);
	}
}
