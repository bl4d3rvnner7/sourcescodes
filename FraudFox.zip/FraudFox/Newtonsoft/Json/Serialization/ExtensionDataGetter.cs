﻿using System;
using System.Collections.Generic;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000266 RID: 614
	// (Invoke) Token: 0x060023DF RID: 9183
	public delegate IEnumerable<KeyValuePair<object, object>> ExtensionDataGetter(object o);
}
