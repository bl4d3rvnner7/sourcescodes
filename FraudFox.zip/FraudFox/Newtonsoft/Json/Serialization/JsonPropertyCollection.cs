﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000269 RID: 617
	public class JsonPropertyCollection : KeyedCollection<string, JsonProperty>
	{
		// Token: 0x0600243D RID: 9277 RVA: 0x0001D1A3 File Offset: 0x0001B3A3
		public JsonPropertyCollection(Type type)
			: base(JsonPropertyCollection.smethod_0())
		{
			ValidationUtils.ArgumentNotNull(type, <Module>.smethod_24<string>(1347420388U));
			this._type = type;
		}

		// Token: 0x0600243E RID: 9278 RVA: 0x0001D1C7 File Offset: 0x0001B3C7
		protected override string GetKeyForItem(JsonProperty item)
		{
			return item.PropertyName;
		}

		// Token: 0x0600243F RID: 9279 RVA: 0x0008D154 File Offset: 0x0008B354
		public void AddProperty(JsonProperty property)
		{
			if (base.Contains(property.PropertyName))
			{
				if (property.Ignored)
				{
					return;
				}
				JsonProperty jsonProperty = base[property.PropertyName];
				bool flag = true;
				if (!jsonProperty.Ignored)
				{
					if (JsonPropertyCollection.smethod_1(property.DeclaringType, null) && JsonPropertyCollection.smethod_1(jsonProperty.DeclaringType, null))
					{
						if (JsonPropertyCollection.smethod_2(property.DeclaringType, jsonProperty.DeclaringType))
						{
							base.Remove(jsonProperty);
							flag = false;
						}
						if (JsonPropertyCollection.smethod_2(jsonProperty.DeclaringType, property.DeclaringType))
						{
							return;
						}
					}
				}
				else
				{
					base.Remove(jsonProperty);
					flag = false;
				}
				if (flag)
				{
					throw new JsonSerializationException(<Module>.smethod_27<string>(2632250008U).FormatWith(JsonPropertyCollection.smethod_3(), property.PropertyName, this._type));
				}
			}
			base.Add(property);
		}

		// Token: 0x06002440 RID: 9280 RVA: 0x0008D21C File Offset: 0x0008B41C
		public JsonProperty GetClosestMatchProperty(string propertyName)
		{
			JsonProperty jsonProperty = this.GetProperty(propertyName, StringComparison.Ordinal);
			if (jsonProperty == null)
			{
				jsonProperty = this.GetProperty(propertyName, StringComparison.OrdinalIgnoreCase);
			}
			return jsonProperty;
		}

		// Token: 0x06002441 RID: 9281 RVA: 0x0001D1CF File Offset: 0x0001B3CF
		private bool TryGetValue(string key, out JsonProperty item)
		{
			if (base.Dictionary == null)
			{
				item = null;
				return false;
			}
			return base.Dictionary.TryGetValue(key, out item);
		}

		// Token: 0x06002442 RID: 9282 RVA: 0x0008D240 File Offset: 0x0008B440
		public JsonProperty GetProperty(string propertyName, StringComparison comparisonType)
		{
			if (comparisonType != StringComparison.Ordinal)
			{
				IEnumerator<JsonProperty> enumerator = base.GetEnumerator();
				try
				{
					while (JsonPropertyCollection.smethod_5(enumerator))
					{
						JsonProperty jsonProperty = enumerator.Current;
						if (JsonPropertyCollection.smethod_4(propertyName, jsonProperty.PropertyName, comparisonType))
						{
							return jsonProperty;
						}
					}
					goto IL_004D;
				}
				finally
				{
					if (enumerator != null)
					{
						JsonPropertyCollection.smethod_6(enumerator);
					}
				}
				JsonProperty jsonProperty2;
				return jsonProperty2;
				IL_004D:
				return null;
			}
			JsonProperty jsonProperty3;
			if (this.TryGetValue(propertyName, out jsonProperty3))
			{
				return jsonProperty3;
			}
			return null;
		}

		// Token: 0x06002443 RID: 9283 RVA: 0x0001283F File Offset: 0x00010A3F
		static StringComparer smethod_0()
		{
			return StringComparer.Ordinal;
		}

		// Token: 0x06002444 RID: 9284 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_1(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x06002445 RID: 9285 RVA: 0x0001CAA3 File Offset: 0x0001ACA3
		static bool smethod_2(Type type_0, Type type_1)
		{
			return type_0.IsSubclassOf(type_1);
		}

		// Token: 0x06002446 RID: 9286 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_3()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06002447 RID: 9287 RVA: 0x000170FF File Offset: 0x000152FF
		static bool smethod_4(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string.Equals(string_0, string_1, stringComparison_0);
		}

		// Token: 0x06002448 RID: 9288 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_5(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06002449 RID: 9289 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_6(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x04000CD7 RID: 3287
		private readonly Type _type;
	}
}
