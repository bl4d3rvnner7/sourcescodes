﻿using System;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000268 RID: 616
	public class JsonProperty
	{
		// Token: 0x17000550 RID: 1360
		// (get) Token: 0x060023FD RID: 9213 RVA: 0x0001CF0E File Offset: 0x0001B10E
		// (set) Token: 0x060023FE RID: 9214 RVA: 0x0001CF16 File Offset: 0x0001B116
		internal JsonContract PropertyContract { get; set; }

		// Token: 0x17000551 RID: 1361
		// (get) Token: 0x060023FF RID: 9215 RVA: 0x0001CF1F File Offset: 0x0001B11F
		// (set) Token: 0x06002400 RID: 9216 RVA: 0x0001CF27 File Offset: 0x0001B127
		public string PropertyName
		{
			get
			{
				return this._propertyName;
			}
			set
			{
				this._propertyName = value;
				this._skipPropertyNameEscape = !JavaScriptUtils.ShouldEscapeJavaScriptString(this._propertyName, JavaScriptUtils.HtmlCharEscapeFlags);
			}
		}

		// Token: 0x17000552 RID: 1362
		// (get) Token: 0x06002401 RID: 9217 RVA: 0x0001CF49 File Offset: 0x0001B149
		// (set) Token: 0x06002402 RID: 9218 RVA: 0x0001CF51 File Offset: 0x0001B151
		public Type DeclaringType { get; set; }

		// Token: 0x17000553 RID: 1363
		// (get) Token: 0x06002403 RID: 9219 RVA: 0x0001CF5A File Offset: 0x0001B15A
		// (set) Token: 0x06002404 RID: 9220 RVA: 0x0001CF62 File Offset: 0x0001B162
		public int? Order { get; set; }

		// Token: 0x17000554 RID: 1364
		// (get) Token: 0x06002405 RID: 9221 RVA: 0x0001CF6B File Offset: 0x0001B16B
		// (set) Token: 0x06002406 RID: 9222 RVA: 0x0001CF73 File Offset: 0x0001B173
		public string UnderlyingName { get; set; }

		// Token: 0x17000555 RID: 1365
		// (get) Token: 0x06002407 RID: 9223 RVA: 0x0001CF7C File Offset: 0x0001B17C
		// (set) Token: 0x06002408 RID: 9224 RVA: 0x0001CF84 File Offset: 0x0001B184
		public IValueProvider ValueProvider { get; set; }

		// Token: 0x17000556 RID: 1366
		// (get) Token: 0x06002409 RID: 9225 RVA: 0x0001CF8D File Offset: 0x0001B18D
		// (set) Token: 0x0600240A RID: 9226 RVA: 0x0001CF95 File Offset: 0x0001B195
		public IAttributeProvider AttributeProvider { get; set; }

		// Token: 0x17000557 RID: 1367
		// (get) Token: 0x0600240B RID: 9227 RVA: 0x0001CF9E File Offset: 0x0001B19E
		// (set) Token: 0x0600240C RID: 9228 RVA: 0x0001CFA6 File Offset: 0x0001B1A6
		public Type PropertyType
		{
			get
			{
				return this._propertyType;
			}
			set
			{
				if (JsonProperty.smethod_0(this._propertyType, value))
				{
					this._propertyType = value;
					this._hasGeneratedDefaultValue = false;
				}
			}
		}

		// Token: 0x17000558 RID: 1368
		// (get) Token: 0x0600240D RID: 9229 RVA: 0x0001CFC4 File Offset: 0x0001B1C4
		// (set) Token: 0x0600240E RID: 9230 RVA: 0x0001CFCC File Offset: 0x0001B1CC
		public JsonConverter Converter { get; set; }

		// Token: 0x17000559 RID: 1369
		// (get) Token: 0x0600240F RID: 9231 RVA: 0x0001CFD5 File Offset: 0x0001B1D5
		// (set) Token: 0x06002410 RID: 9232 RVA: 0x0001CFDD File Offset: 0x0001B1DD
		public JsonConverter MemberConverter { get; set; }

		// Token: 0x1700055A RID: 1370
		// (get) Token: 0x06002411 RID: 9233 RVA: 0x0001CFE6 File Offset: 0x0001B1E6
		// (set) Token: 0x06002412 RID: 9234 RVA: 0x0001CFEE File Offset: 0x0001B1EE
		public bool Ignored { get; set; }

		// Token: 0x1700055B RID: 1371
		// (get) Token: 0x06002413 RID: 9235 RVA: 0x0001CFF7 File Offset: 0x0001B1F7
		// (set) Token: 0x06002414 RID: 9236 RVA: 0x0001CFFF File Offset: 0x0001B1FF
		public bool Readable { get; set; }

		// Token: 0x1700055C RID: 1372
		// (get) Token: 0x06002415 RID: 9237 RVA: 0x0001D008 File Offset: 0x0001B208
		// (set) Token: 0x06002416 RID: 9238 RVA: 0x0001D010 File Offset: 0x0001B210
		public bool Writable { get; set; }

		// Token: 0x1700055D RID: 1373
		// (get) Token: 0x06002417 RID: 9239 RVA: 0x0001D019 File Offset: 0x0001B219
		// (set) Token: 0x06002418 RID: 9240 RVA: 0x0001D021 File Offset: 0x0001B221
		public bool HasMemberAttribute { get; set; }

		// Token: 0x1700055E RID: 1374
		// (get) Token: 0x06002419 RID: 9241 RVA: 0x0001D02A File Offset: 0x0001B22A
		// (set) Token: 0x0600241A RID: 9242 RVA: 0x0001D03C File Offset: 0x0001B23C
		public object DefaultValue
		{
			get
			{
				if (!this._hasExplicitDefaultValue)
				{
					return null;
				}
				return this._defaultValue;
			}
			set
			{
				this._hasExplicitDefaultValue = true;
				this._defaultValue = value;
			}
		}

		// Token: 0x0600241B RID: 9243 RVA: 0x0001D04C File Offset: 0x0001B24C
		internal object GetResolvedDefaultValue()
		{
			if (JsonProperty.smethod_1(this._propertyType, null))
			{
				return null;
			}
			if (!this._hasExplicitDefaultValue && !this._hasGeneratedDefaultValue)
			{
				this._defaultValue = ReflectionUtils.GetDefaultValue(this.PropertyType);
				this._hasGeneratedDefaultValue = true;
			}
			return this._defaultValue;
		}

		// Token: 0x1700055F RID: 1375
		// (get) Token: 0x0600241C RID: 9244 RVA: 0x0008D12C File Offset: 0x0008B32C
		// (set) Token: 0x0600241D RID: 9245 RVA: 0x0001D08C File Offset: 0x0001B28C
		public Required Required
		{
			get
			{
				Required? required = this._required;
				if (required == null)
				{
					return Required.Default;
				}
				return required.GetValueOrDefault();
			}
			set
			{
				this._required = new Required?(value);
			}
		}

		// Token: 0x17000560 RID: 1376
		// (get) Token: 0x0600241E RID: 9246 RVA: 0x0001D09A File Offset: 0x0001B29A
		// (set) Token: 0x0600241F RID: 9247 RVA: 0x0001D0A2 File Offset: 0x0001B2A2
		public bool? IsReference { get; set; }

		// Token: 0x17000561 RID: 1377
		// (get) Token: 0x06002420 RID: 9248 RVA: 0x0001D0AB File Offset: 0x0001B2AB
		// (set) Token: 0x06002421 RID: 9249 RVA: 0x0001D0B3 File Offset: 0x0001B2B3
		public NullValueHandling? NullValueHandling { get; set; }

		// Token: 0x17000562 RID: 1378
		// (get) Token: 0x06002422 RID: 9250 RVA: 0x0001D0BC File Offset: 0x0001B2BC
		// (set) Token: 0x06002423 RID: 9251 RVA: 0x0001D0C4 File Offset: 0x0001B2C4
		public DefaultValueHandling? DefaultValueHandling { get; set; }

		// Token: 0x17000563 RID: 1379
		// (get) Token: 0x06002424 RID: 9252 RVA: 0x0001D0CD File Offset: 0x0001B2CD
		// (set) Token: 0x06002425 RID: 9253 RVA: 0x0001D0D5 File Offset: 0x0001B2D5
		public ReferenceLoopHandling? ReferenceLoopHandling { get; set; }

		// Token: 0x17000564 RID: 1380
		// (get) Token: 0x06002426 RID: 9254 RVA: 0x0001D0DE File Offset: 0x0001B2DE
		// (set) Token: 0x06002427 RID: 9255 RVA: 0x0001D0E6 File Offset: 0x0001B2E6
		public ObjectCreationHandling? ObjectCreationHandling { get; set; }

		// Token: 0x17000565 RID: 1381
		// (get) Token: 0x06002428 RID: 9256 RVA: 0x0001D0EF File Offset: 0x0001B2EF
		// (set) Token: 0x06002429 RID: 9257 RVA: 0x0001D0F7 File Offset: 0x0001B2F7
		public TypeNameHandling? TypeNameHandling { get; set; }

		// Token: 0x17000566 RID: 1382
		// (get) Token: 0x0600242A RID: 9258 RVA: 0x0001D100 File Offset: 0x0001B300
		// (set) Token: 0x0600242B RID: 9259 RVA: 0x0001D108 File Offset: 0x0001B308
		public Predicate<object> ShouldSerialize { get; set; }

		// Token: 0x17000567 RID: 1383
		// (get) Token: 0x0600242C RID: 9260 RVA: 0x0001D111 File Offset: 0x0001B311
		// (set) Token: 0x0600242D RID: 9261 RVA: 0x0001D119 File Offset: 0x0001B319
		public Predicate<object> GetIsSpecified { get; set; }

		// Token: 0x17000568 RID: 1384
		// (get) Token: 0x0600242E RID: 9262 RVA: 0x0001D122 File Offset: 0x0001B322
		// (set) Token: 0x0600242F RID: 9263 RVA: 0x0001D12A File Offset: 0x0001B32A
		public Action<object, object> SetIsSpecified { get; set; }

		// Token: 0x06002430 RID: 9264 RVA: 0x0001D133 File Offset: 0x0001B333
		public override string ToString()
		{
			return this.PropertyName;
		}

		// Token: 0x17000569 RID: 1385
		// (get) Token: 0x06002431 RID: 9265 RVA: 0x0001D13B File Offset: 0x0001B33B
		// (set) Token: 0x06002432 RID: 9266 RVA: 0x0001D143 File Offset: 0x0001B343
		public JsonConverter ItemConverter { get; set; }

		// Token: 0x1700056A RID: 1386
		// (get) Token: 0x06002433 RID: 9267 RVA: 0x0001D14C File Offset: 0x0001B34C
		// (set) Token: 0x06002434 RID: 9268 RVA: 0x0001D154 File Offset: 0x0001B354
		public bool? ItemIsReference { get; set; }

		// Token: 0x1700056B RID: 1387
		// (get) Token: 0x06002435 RID: 9269 RVA: 0x0001D15D File Offset: 0x0001B35D
		// (set) Token: 0x06002436 RID: 9270 RVA: 0x0001D165 File Offset: 0x0001B365
		public TypeNameHandling? ItemTypeNameHandling { get; set; }

		// Token: 0x1700056C RID: 1388
		// (get) Token: 0x06002437 RID: 9271 RVA: 0x0001D16E File Offset: 0x0001B36E
		// (set) Token: 0x06002438 RID: 9272 RVA: 0x0001D176 File Offset: 0x0001B376
		public ReferenceLoopHandling? ItemReferenceLoopHandling { get; set; }

		// Token: 0x06002439 RID: 9273 RVA: 0x0001D17F File Offset: 0x0001B37F
		internal void WritePropertyName(JsonWriter writer)
		{
			if (this._skipPropertyNameEscape)
			{
				writer.WritePropertyName(this.PropertyName, false);
				return;
			}
			writer.WritePropertyName(this.PropertyName);
		}

		// Token: 0x0600243B RID: 9275 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_0(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x0600243C RID: 9276 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_1(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x04000CB7 RID: 3255
		internal Required? _required;

		// Token: 0x04000CB8 RID: 3256
		internal bool _hasExplicitDefaultValue;

		// Token: 0x04000CB9 RID: 3257
		private object _defaultValue;

		// Token: 0x04000CBA RID: 3258
		private bool _hasGeneratedDefaultValue;

		// Token: 0x04000CBB RID: 3259
		private string _propertyName;

		// Token: 0x04000CBC RID: 3260
		internal bool _skipPropertyNameEscape;

		// Token: 0x04000CBD RID: 3261
		private Type _propertyType;
	}
}
