﻿using System;
using System.Globalization;
using System.Reflection;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000281 RID: 641
	public class ReflectionValueProvider : IValueProvider
	{
		// Token: 0x06002620 RID: 9760 RVA: 0x0001DFD5 File Offset: 0x0001C1D5
		public ReflectionValueProvider(MemberInfo memberInfo)
		{
			ValidationUtils.ArgumentNotNull(memberInfo, <Module>.smethod_25<string>(3720340912U));
			this._memberInfo = memberInfo;
		}

		// Token: 0x06002621 RID: 9761 RVA: 0x00095030 File Offset: 0x00093230
		public void SetValue(object target, object value)
		{
			try
			{
				ReflectionUtils.SetMemberValue(this._memberInfo, target, value);
			}
			catch (Exception ex)
			{
				throw new JsonSerializationException(<Module>.smethod_26<string>(592339353U).FormatWith(ReflectionValueProvider.smethod_0(), ReflectionValueProvider.smethod_1(this._memberInfo), ReflectionValueProvider.smethod_2(target)), ex);
			}
		}

		// Token: 0x06002622 RID: 9762 RVA: 0x0009508C File Offset: 0x0009328C
		public object GetValue(object target)
		{
			object memberValue;
			try
			{
				memberValue = ReflectionUtils.GetMemberValue(this._memberInfo, target);
			}
			catch (Exception ex)
			{
				throw new JsonSerializationException(<Module>.smethod_24<string>(3849805967U).FormatWith(ReflectionValueProvider.smethod_0(), ReflectionValueProvider.smethod_1(this._memberInfo), ReflectionValueProvider.smethod_2(target)), ex);
			}
			return memberValue;
		}

		// Token: 0x06002623 RID: 9763 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_0()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06002624 RID: 9764 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_1(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x06002625 RID: 9765 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_2(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x04000D72 RID: 3442
		private readonly MemberInfo _memberInfo;
	}
}
