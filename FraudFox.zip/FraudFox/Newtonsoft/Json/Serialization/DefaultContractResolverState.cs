﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x0200025D RID: 605
	internal class DefaultContractResolverState
	{
		// Token: 0x04000C8B RID: 3211
		public Dictionary<ResolverContractKey, JsonContract> ContractCache;

		// Token: 0x04000C8C RID: 3212
		public PropertyNameTable NameTable = new PropertyNameTable();
	}
}
