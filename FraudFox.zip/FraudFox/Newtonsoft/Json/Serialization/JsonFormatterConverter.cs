﻿using System;
using System.Globalization;
using System.Runtime.Serialization;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001F7 RID: 503
	internal class JsonFormatterConverter : IFormatterConverter
	{
		// Token: 0x06001CC3 RID: 7363 RVA: 0x000192DA File Offset: 0x000174DA
		public JsonFormatterConverter(JsonSerializerInternalReader reader, JsonISerializableContract contract, JsonProperty member)
		{
			ValidationUtils.ArgumentNotNull(reader, <Module>.smethod_27<string>(1919654350U));
			ValidationUtils.ArgumentNotNull(contract, <Module>.smethod_23<string>(2360954146U));
			this._reader = reader;
			this._contract = contract;
			this._member = member;
		}

		// Token: 0x06001CC4 RID: 7364 RVA: 0x0007F5C0 File Offset: 0x0007D7C0
		private T GetTokenValue<T>(object value)
		{
			ValidationUtils.ArgumentNotNull(value, <Module>.smethod_24<string>(4014942403U));
			JValue jvalue = (JValue)value;
			return (T)((object)JsonFormatterConverter.smethod_2(jvalue.Value, JsonFormatterConverter.smethod_0(typeof(T).TypeHandle), JsonFormatterConverter.smethod_1()));
		}

		// Token: 0x06001CC5 RID: 7365 RVA: 0x0007F604 File Offset: 0x0007D804
		public object Convert(object value, Type type)
		{
			ValidationUtils.ArgumentNotNull(value, <Module>.smethod_26<string>(1806306238U));
			JToken jtoken = value as JToken;
			if (jtoken == null)
			{
				throw JsonFormatterConverter.smethod_3(<Module>.smethod_24<string>(19240892U), <Module>.smethod_23<string>(2033612370U));
			}
			return this._reader.CreateISerializableItem(jtoken, type, this._contract, this._member);
		}

		// Token: 0x06001CC6 RID: 7366 RVA: 0x00019317 File Offset: 0x00017517
		public object Convert(object value, TypeCode typeCode)
		{
			ValidationUtils.ArgumentNotNull(value, <Module>.smethod_23<string>(2033612370U));
			if (value is JValue)
			{
				value = ((JValue)value).Value;
			}
			return JsonFormatterConverter.smethod_4(value, typeCode, JsonFormatterConverter.smethod_1());
		}

		// Token: 0x06001CC7 RID: 7367 RVA: 0x0001934A File Offset: 0x0001754A
		public bool ToBoolean(object value)
		{
			return this.GetTokenValue<bool>(value);
		}

		// Token: 0x06001CC8 RID: 7368 RVA: 0x00019353 File Offset: 0x00017553
		public byte ToByte(object value)
		{
			return this.GetTokenValue<byte>(value);
		}

		// Token: 0x06001CC9 RID: 7369 RVA: 0x0001935C File Offset: 0x0001755C
		public char ToChar(object value)
		{
			return this.GetTokenValue<char>(value);
		}

		// Token: 0x06001CCA RID: 7370 RVA: 0x00019365 File Offset: 0x00017565
		public DateTime ToDateTime(object value)
		{
			return this.GetTokenValue<DateTime>(value);
		}

		// Token: 0x06001CCB RID: 7371 RVA: 0x0001936E File Offset: 0x0001756E
		public decimal ToDecimal(object value)
		{
			return this.GetTokenValue<decimal>(value);
		}

		// Token: 0x06001CCC RID: 7372 RVA: 0x00019377 File Offset: 0x00017577
		public double ToDouble(object value)
		{
			return this.GetTokenValue<double>(value);
		}

		// Token: 0x06001CCD RID: 7373 RVA: 0x00019380 File Offset: 0x00017580
		public short ToInt16(object value)
		{
			return this.GetTokenValue<short>(value);
		}

		// Token: 0x06001CCE RID: 7374 RVA: 0x00019389 File Offset: 0x00017589
		public int ToInt32(object value)
		{
			return this.GetTokenValue<int>(value);
		}

		// Token: 0x06001CCF RID: 7375 RVA: 0x00019392 File Offset: 0x00017592
		public long ToInt64(object value)
		{
			return this.GetTokenValue<long>(value);
		}

		// Token: 0x06001CD0 RID: 7376 RVA: 0x0001939B File Offset: 0x0001759B
		public sbyte ToSByte(object value)
		{
			return this.GetTokenValue<sbyte>(value);
		}

		// Token: 0x06001CD1 RID: 7377 RVA: 0x000193A4 File Offset: 0x000175A4
		public float ToSingle(object value)
		{
			return this.GetTokenValue<float>(value);
		}

		// Token: 0x06001CD2 RID: 7378 RVA: 0x000193AD File Offset: 0x000175AD
		public string ToString(object value)
		{
			return this.GetTokenValue<string>(value);
		}

		// Token: 0x06001CD3 RID: 7379 RVA: 0x000193B6 File Offset: 0x000175B6
		public ushort ToUInt16(object value)
		{
			return this.GetTokenValue<ushort>(value);
		}

		// Token: 0x06001CD4 RID: 7380 RVA: 0x000193BF File Offset: 0x000175BF
		public uint ToUInt32(object value)
		{
			return this.GetTokenValue<uint>(value);
		}

		// Token: 0x06001CD5 RID: 7381 RVA: 0x000193C8 File Offset: 0x000175C8
		public ulong ToUInt64(object value)
		{
			return this.GetTokenValue<ulong>(value);
		}

		// Token: 0x06001CD6 RID: 7382 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_0(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001CD7 RID: 7383 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_1()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001CD8 RID: 7384 RVA: 0x000193D1 File Offset: 0x000175D1
		static object smethod_2(object object_0, Type type_0, IFormatProvider iformatProvider_0)
		{
			return global::System.Convert.ChangeType(object_0, type_0, iformatProvider_0);
		}

		// Token: 0x06001CD9 RID: 7385 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_3(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}

		// Token: 0x06001CDA RID: 7386 RVA: 0x000193DB File Offset: 0x000175DB
		static object smethod_4(object object_0, TypeCode typeCode_0, IFormatProvider iformatProvider_0)
		{
			return global::System.Convert.ChangeType(object_0, typeCode_0, iformatProvider_0);
		}

		// Token: 0x04000AF8 RID: 2808
		private readonly JsonSerializerInternalReader _reader;

		// Token: 0x04000AF9 RID: 2809
		private readonly JsonISerializableContract _contract;

		// Token: 0x04000AFA RID: 2810
		private readonly JsonProperty _member;
	}
}
