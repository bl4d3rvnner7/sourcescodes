﻿using System;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x0200027D RID: 637
	public class JsonStringContract : JsonPrimitiveContract
	{
		// Token: 0x060025F5 RID: 9717 RVA: 0x0001DF09 File Offset: 0x0001C109
		public JsonStringContract(Type underlyingType)
			: base(underlyingType)
		{
			this.ContractType = JsonContractType.String;
		}
	}
}
