﻿using System;
using System.Runtime.Serialization;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000263 RID: 611
	// (Invoke) Token: 0x060023D3 RID: 9171
	public delegate void SerializationCallback(object o, StreamingContext context);
}
