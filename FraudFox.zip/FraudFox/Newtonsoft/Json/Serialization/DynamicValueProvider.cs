﻿using System;
using System.Globalization;
using System.Reflection;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001FB RID: 507
	public class DynamicValueProvider : IValueProvider
	{
		// Token: 0x06001CE2 RID: 7394 RVA: 0x0001944A File Offset: 0x0001764A
		public DynamicValueProvider(MemberInfo memberInfo)
		{
			ValidationUtils.ArgumentNotNull(memberInfo, <Module>.smethod_25<string>(3720340912U));
			this._memberInfo = memberInfo;
		}

		// Token: 0x06001CE3 RID: 7395 RVA: 0x0007F660 File Offset: 0x0007D860
		public void SetValue(object target, object value)
		{
			try
			{
				if (this._setter == null)
				{
					this._setter = DynamicReflectionDelegateFactory.Instance.CreateSet<object>(this._memberInfo);
				}
				this._setter(target, value);
			}
			catch (Exception ex)
			{
				throw new JsonSerializationException(<Module>.smethod_25<string>(3441951100U).FormatWith(DynamicValueProvider.smethod_0(), DynamicValueProvider.smethod_1(this._memberInfo), DynamicValueProvider.smethod_2(target)), ex);
			}
		}

		// Token: 0x06001CE4 RID: 7396 RVA: 0x0007F6D8 File Offset: 0x0007D8D8
		public object GetValue(object target)
		{
			object obj;
			try
			{
				if (this._getter == null)
				{
					this._getter = DynamicReflectionDelegateFactory.Instance.CreateGet<object>(this._memberInfo);
				}
				obj = this._getter(target);
			}
			catch (Exception ex)
			{
				throw new JsonSerializationException(<Module>.smethod_23<string>(332318118U).FormatWith(DynamicValueProvider.smethod_0(), DynamicValueProvider.smethod_1(this._memberInfo), DynamicValueProvider.smethod_2(target)), ex);
			}
			return obj;
		}

		// Token: 0x06001CE5 RID: 7397 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_0()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001CE6 RID: 7398 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_1(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x06001CE7 RID: 7399 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_2(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x04000AFD RID: 2813
		private readonly MemberInfo _memberInfo;

		// Token: 0x04000AFE RID: 2814
		private Func<object, object> _getter;

		// Token: 0x04000AFF RID: 2815
		private Action<object, object> _setter;
	}
}
