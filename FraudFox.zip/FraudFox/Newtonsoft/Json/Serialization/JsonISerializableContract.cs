﻿using System;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001F8 RID: 504
	public class JsonISerializableContract : JsonContainerContract
	{
		// Token: 0x17000407 RID: 1031
		// (get) Token: 0x06001CDB RID: 7387 RVA: 0x000193E5 File Offset: 0x000175E5
		// (set) Token: 0x06001CDC RID: 7388 RVA: 0x000193ED File Offset: 0x000175ED
		public ObjectConstructor<object> ISerializableCreator { get; set; }

		// Token: 0x06001CDD RID: 7389 RVA: 0x000193F6 File Offset: 0x000175F6
		public JsonISerializableContract(Type underlyingType)
			: base(underlyingType)
		{
			this.ContractType = JsonContractType.Serializable;
		}
	}
}
