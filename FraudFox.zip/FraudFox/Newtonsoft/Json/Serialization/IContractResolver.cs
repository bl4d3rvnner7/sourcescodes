﻿using System;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x02000255 RID: 597
	public interface IContractResolver
	{
		// Token: 0x06002300 RID: 8960
		JsonContract ResolveContract(Type type);
	}
}
