﻿using System;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001FE RID: 510
	public interface IReferenceResolver
	{
		// Token: 0x06001CFA RID: 7418
		object ResolveReference(object context, string reference);

		// Token: 0x06001CFB RID: 7419
		string GetReference(object context, object value);

		// Token: 0x06001CFC RID: 7420
		bool IsReferenced(object context, object value);

		// Token: 0x06001CFD RID: 7421
		void AddReference(object context, string reference, object value);
	}
}
