﻿using System;

namespace Newtonsoft.Json.Serialization
{
	// Token: 0x020001F9 RID: 505
	public class JsonLinqContract : JsonContract
	{
		// Token: 0x06001CDE RID: 7390 RVA: 0x00019406 File Offset: 0x00017606
		public JsonLinqContract(Type underlyingType)
			: base(underlyingType)
		{
			this.ContractType = JsonContractType.Linq;
		}
	}
}
