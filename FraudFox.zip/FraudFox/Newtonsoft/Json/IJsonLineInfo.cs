﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001E3 RID: 483
	public interface IJsonLineInfo
	{
		// Token: 0x06001B04 RID: 6916
		bool HasLineInfo();

		// Token: 0x170003DF RID: 991
		// (get) Token: 0x06001B05 RID: 6917
		int LineNumber { get; }

		// Token: 0x170003E0 RID: 992
		// (get) Token: 0x06001B06 RID: 6918
		int LinePosition { get; }
	}
}
