﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001B7 RID: 439
	public enum DateFormatHandling
	{
		// Token: 0x040009CF RID: 2511
		IsoDateFormat,
		// Token: 0x040009D0 RID: 2512
		MicrosoftDateFormat
	}
}
