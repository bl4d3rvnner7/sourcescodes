﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001D7 RID: 471
	public enum MetadataPropertyHandling
	{
		// Token: 0x04000A69 RID: 2665
		Default,
		// Token: 0x04000A6A RID: 2666
		ReadAhead,
		// Token: 0x04000A6B RID: 2667
		Ignore
	}
}
