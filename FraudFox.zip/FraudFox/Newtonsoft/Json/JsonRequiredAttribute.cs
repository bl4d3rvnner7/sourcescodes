﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001BF RID: 447
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
	public sealed class JsonRequiredAttribute : Attribute
	{
	}
}
