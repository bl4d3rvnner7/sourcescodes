﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020002C9 RID: 713
	public enum JsonToken
	{
		// Token: 0x04000E4B RID: 3659
		None,
		// Token: 0x04000E4C RID: 3660
		StartObject,
		// Token: 0x04000E4D RID: 3661
		StartArray,
		// Token: 0x04000E4E RID: 3662
		StartConstructor,
		// Token: 0x04000E4F RID: 3663
		PropertyName,
		// Token: 0x04000E50 RID: 3664
		Comment,
		// Token: 0x04000E51 RID: 3665
		Raw,
		// Token: 0x04000E52 RID: 3666
		Integer,
		// Token: 0x04000E53 RID: 3667
		Float,
		// Token: 0x04000E54 RID: 3668
		String,
		// Token: 0x04000E55 RID: 3669
		Boolean,
		// Token: 0x04000E56 RID: 3670
		Null,
		// Token: 0x04000E57 RID: 3671
		Undefined,
		// Token: 0x04000E58 RID: 3672
		EndObject,
		// Token: 0x04000E59 RID: 3673
		EndArray,
		// Token: 0x04000E5A RID: 3674
		EndConstructor,
		// Token: 0x04000E5B RID: 3675
		Date,
		// Token: 0x04000E5C RID: 3676
		Bytes
	}
}
