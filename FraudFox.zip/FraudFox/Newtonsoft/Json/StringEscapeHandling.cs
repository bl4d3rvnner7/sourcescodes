﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001E6 RID: 486
	public enum StringEscapeHandling
	{
		// Token: 0x04000A97 RID: 2711
		Default,
		// Token: 0x04000A98 RID: 2712
		EscapeNonAscii,
		// Token: 0x04000A99 RID: 2713
		EscapeHtml
	}
}
