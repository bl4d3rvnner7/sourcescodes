﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001B8 RID: 440
	public enum DateParseHandling
	{
		// Token: 0x040009D2 RID: 2514
		None,
		// Token: 0x040009D3 RID: 2515
		DateTime,
		// Token: 0x040009D4 RID: 2516
		DateTimeOffset
	}
}
