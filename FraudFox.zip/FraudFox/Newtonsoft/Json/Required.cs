﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001F5 RID: 501
	public enum Required
	{
		// Token: 0x04000AF1 RID: 2801
		Default,
		// Token: 0x04000AF2 RID: 2802
		AllowNull,
		// Token: 0x04000AF3 RID: 2803
		Always
	}
}
