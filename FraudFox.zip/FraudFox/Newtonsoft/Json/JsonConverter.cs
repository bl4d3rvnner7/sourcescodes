﻿using System;
using Newtonsoft.Json.Schema;

namespace Newtonsoft.Json
{
	// Token: 0x0200019F RID: 415
	public abstract class JsonConverter
	{
		// Token: 0x060018A9 RID: 6313
		public abstract void WriteJson(JsonWriter writer, object value, JsonSerializer serializer);

		// Token: 0x060018AA RID: 6314
		public abstract object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer);

		// Token: 0x060018AB RID: 6315
		public abstract bool CanConvert(Type objectType);

		// Token: 0x060018AC RID: 6316 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		[Obsolete("JSON Schema validation has been moved to its own package. It is strongly recommended that you do not override GetSchema() in your own converter. It is not used by Json.NET and will be removed at some point in the future. Converter's that override GetSchema() will stop working when it is removed.")]
		public virtual JsonSchema GetSchema()
		{
			return null;
		}

		// Token: 0x17000393 RID: 915
		// (get) Token: 0x060018AD RID: 6317 RVA: 0x0000ED8C File Offset: 0x0000CF8C
		public virtual bool CanRead
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000394 RID: 916
		// (get) Token: 0x060018AE RID: 6318 RVA: 0x0000ED8C File Offset: 0x0000CF8C
		public virtual bool CanWrite
		{
			get
			{
				return true;
			}
		}
	}
}
