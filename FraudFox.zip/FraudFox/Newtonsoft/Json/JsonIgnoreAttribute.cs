﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000229 RID: 553
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
	public sealed class JsonIgnoreAttribute : Attribute
	{
	}
}
