﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200026C RID: 620
	public enum ReferenceLoopHandling
	{
		// Token: 0x04000CDF RID: 3295
		Error,
		// Token: 0x04000CE0 RID: 3296
		Ignore,
		// Token: 0x04000CE1 RID: 3297
		Serialize
	}
}
