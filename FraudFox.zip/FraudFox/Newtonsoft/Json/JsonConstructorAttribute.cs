﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001BB RID: 443
	[AttributeUsage(AttributeTargets.Constructor, AllowMultiple = false)]
	public sealed class JsonConstructorAttribute : Attribute
	{
	}
}
