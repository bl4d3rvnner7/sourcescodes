﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001B2 RID: 434
	public enum FloatFormatHandling
	{
		// Token: 0x040009BF RID: 2495
		String,
		// Token: 0x040009C0 RID: 2496
		Symbol,
		// Token: 0x040009C1 RID: 2497
		DefaultValue
	}
}
