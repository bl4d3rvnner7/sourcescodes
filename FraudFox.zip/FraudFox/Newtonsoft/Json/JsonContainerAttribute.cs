﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001B4 RID: 436
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Interface, AllowMultiple = false)]
	public abstract class JsonContainerAttribute : Attribute
	{
		// Token: 0x1700039A RID: 922
		// (get) Token: 0x0600197A RID: 6522 RVA: 0x00017957 File Offset: 0x00015B57
		// (set) Token: 0x0600197B RID: 6523 RVA: 0x0001795F File Offset: 0x00015B5F
		public string Id { get; set; }

		// Token: 0x1700039B RID: 923
		// (get) Token: 0x0600197C RID: 6524 RVA: 0x00017968 File Offset: 0x00015B68
		// (set) Token: 0x0600197D RID: 6525 RVA: 0x00017970 File Offset: 0x00015B70
		public string Title { get; set; }

		// Token: 0x1700039C RID: 924
		// (get) Token: 0x0600197E RID: 6526 RVA: 0x00017979 File Offset: 0x00015B79
		// (set) Token: 0x0600197F RID: 6527 RVA: 0x00017981 File Offset: 0x00015B81
		public string Description { get; set; }

		// Token: 0x1700039D RID: 925
		// (get) Token: 0x06001980 RID: 6528 RVA: 0x0001798A File Offset: 0x00015B8A
		// (set) Token: 0x06001981 RID: 6529 RVA: 0x00017992 File Offset: 0x00015B92
		public Type ItemConverterType { get; set; }

		// Token: 0x1700039E RID: 926
		// (get) Token: 0x06001982 RID: 6530 RVA: 0x0001799B File Offset: 0x00015B9B
		// (set) Token: 0x06001983 RID: 6531 RVA: 0x000179A3 File Offset: 0x00015BA3
		public object[] ItemConverterParameters { get; set; }

		// Token: 0x1700039F RID: 927
		// (get) Token: 0x06001984 RID: 6532 RVA: 0x00077AAC File Offset: 0x00075CAC
		// (set) Token: 0x06001985 RID: 6533 RVA: 0x000179AC File Offset: 0x00015BAC
		public bool IsReference
		{
			get
			{
				return this._isReference ?? false;
			}
			set
			{
				this._isReference = new bool?(value);
			}
		}

		// Token: 0x170003A0 RID: 928
		// (get) Token: 0x06001986 RID: 6534 RVA: 0x00077AD4 File Offset: 0x00075CD4
		// (set) Token: 0x06001987 RID: 6535 RVA: 0x000179BA File Offset: 0x00015BBA
		public bool ItemIsReference
		{
			get
			{
				return this._itemIsReference ?? false;
			}
			set
			{
				this._itemIsReference = new bool?(value);
			}
		}

		// Token: 0x170003A1 RID: 929
		// (get) Token: 0x06001988 RID: 6536 RVA: 0x00077AFC File Offset: 0x00075CFC
		// (set) Token: 0x06001989 RID: 6537 RVA: 0x000179C8 File Offset: 0x00015BC8
		public ReferenceLoopHandling ItemReferenceLoopHandling
		{
			get
			{
				ReferenceLoopHandling? itemReferenceLoopHandling = this._itemReferenceLoopHandling;
				if (itemReferenceLoopHandling == null)
				{
					return ReferenceLoopHandling.Error;
				}
				return itemReferenceLoopHandling.GetValueOrDefault();
			}
			set
			{
				this._itemReferenceLoopHandling = new ReferenceLoopHandling?(value);
			}
		}

		// Token: 0x170003A2 RID: 930
		// (get) Token: 0x0600198A RID: 6538 RVA: 0x00077B24 File Offset: 0x00075D24
		// (set) Token: 0x0600198B RID: 6539 RVA: 0x000179D6 File Offset: 0x00015BD6
		public TypeNameHandling ItemTypeNameHandling
		{
			get
			{
				TypeNameHandling? itemTypeNameHandling = this._itemTypeNameHandling;
				if (itemTypeNameHandling == null)
				{
					return TypeNameHandling.None;
				}
				return itemTypeNameHandling.GetValueOrDefault();
			}
			set
			{
				this._itemTypeNameHandling = new TypeNameHandling?(value);
			}
		}

		// Token: 0x0600198C RID: 6540 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		protected JsonContainerAttribute()
		{
		}

		// Token: 0x0600198D RID: 6541 RVA: 0x000179E4 File Offset: 0x00015BE4
		protected JsonContainerAttribute(string id)
		{
			this.Id = id;
		}

		// Token: 0x040009C5 RID: 2501
		internal bool? _isReference;

		// Token: 0x040009C6 RID: 2502
		internal bool? _itemIsReference;

		// Token: 0x040009C7 RID: 2503
		internal ReferenceLoopHandling? _itemReferenceLoopHandling;

		// Token: 0x040009C8 RID: 2504
		internal TypeNameHandling? _itemTypeNameHandling;
	}
}
