﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000201 RID: 513
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Interface, AllowMultiple = false)]
	public sealed class JsonArrayAttribute : JsonContainerAttribute
	{
		// Token: 0x1700040F RID: 1039
		// (get) Token: 0x06001D05 RID: 7429 RVA: 0x000194E3 File Offset: 0x000176E3
		// (set) Token: 0x06001D06 RID: 7430 RVA: 0x000194EB File Offset: 0x000176EB
		public bool AllowNullItems
		{
			get
			{
				return this._allowNullItems;
			}
			set
			{
				this._allowNullItems = value;
			}
		}

		// Token: 0x06001D07 RID: 7431 RVA: 0x000179F3 File Offset: 0x00015BF3
		public JsonArrayAttribute()
		{
		}

		// Token: 0x06001D08 RID: 7432 RVA: 0x000194F4 File Offset: 0x000176F4
		public JsonArrayAttribute(bool allowNullItems)
		{
			this._allowNullItems = allowNullItems;
		}

		// Token: 0x06001D09 RID: 7433 RVA: 0x000179FB File Offset: 0x00015BFB
		public JsonArrayAttribute(string id)
			: base(id)
		{
		}

		// Token: 0x04000B08 RID: 2824
		private bool _allowNullItems;
	}
}
