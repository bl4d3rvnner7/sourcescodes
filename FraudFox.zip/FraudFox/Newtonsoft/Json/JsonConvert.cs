﻿using System;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json
{
	// Token: 0x0200022E RID: 558
	public static class JsonConvert
	{
		// Token: 0x170004B4 RID: 1204
		// (get) Token: 0x06001FD1 RID: 8145 RVA: 0x0001AD54 File Offset: 0x00018F54
		// (set) Token: 0x06001FD2 RID: 8146 RVA: 0x0001AD5B File Offset: 0x00018F5B
		public static Func<JsonSerializerSettings> DefaultSettings { get; set; }

		// Token: 0x06001FD3 RID: 8147 RVA: 0x0001AD63 File Offset: 0x00018F63
		public static string ToString(DateTime value)
		{
			return JsonConvert.ToString(value, DateFormatHandling.IsoDateFormat, DateTimeZoneHandling.RoundtripKind);
		}

		// Token: 0x06001FD4 RID: 8148 RVA: 0x00085AE0 File Offset: 0x00083CE0
		public static string ToString(DateTime value, DateFormatHandling format, DateTimeZoneHandling timeZoneHandling)
		{
			DateTime dateTime = DateTimeUtils.EnsureDateTime(value, timeZoneHandling);
			StringWriter stringWriter = StringUtils.CreateStringWriter(64);
			string text;
			try
			{
				JsonConvert.smethod_0(stringWriter, '"');
				DateTimeUtils.WriteDateTimeString(stringWriter, dateTime, format, null, JsonConvert.smethod_1());
				JsonConvert.smethod_0(stringWriter, '"');
				text = JsonConvert.smethod_2(stringWriter);
			}
			finally
			{
				if (stringWriter != null)
				{
					JsonConvert.smethod_3(stringWriter);
				}
			}
			return text;
		}

		// Token: 0x06001FD5 RID: 8149 RVA: 0x0001AD6D File Offset: 0x00018F6D
		public static string ToString(DateTimeOffset value)
		{
			return JsonConvert.ToString(value, DateFormatHandling.IsoDateFormat);
		}

		// Token: 0x06001FD6 RID: 8150 RVA: 0x00085B40 File Offset: 0x00083D40
		public static string ToString(DateTimeOffset value, DateFormatHandling format)
		{
			StringWriter stringWriter = StringUtils.CreateStringWriter(64);
			string text;
			try
			{
				JsonConvert.smethod_0(stringWriter, '"');
				DateTimeUtils.WriteDateTimeOffsetString(stringWriter, value, format, null, JsonConvert.smethod_1());
				JsonConvert.smethod_0(stringWriter, '"');
				text = JsonConvert.smethod_2(stringWriter);
			}
			finally
			{
				if (stringWriter != null)
				{
					JsonConvert.smethod_3(stringWriter);
				}
			}
			return text;
		}

		// Token: 0x06001FD7 RID: 8151 RVA: 0x0001AD76 File Offset: 0x00018F76
		public static string ToString(bool value)
		{
			if (!value)
			{
				return JsonConvert.False;
			}
			return JsonConvert.True;
		}

		// Token: 0x06001FD8 RID: 8152 RVA: 0x0001AD86 File Offset: 0x00018F86
		public static string ToString(char value)
		{
			return JsonConvert.ToString(char.ToString(value));
		}

		// Token: 0x06001FD9 RID: 8153 RVA: 0x0001AD93 File Offset: 0x00018F93
		public static string ToString(Enum value)
		{
			return JsonConvert.smethod_4(value, <Module>.smethod_24<string>(293111808U));
		}

		// Token: 0x06001FDA RID: 8154 RVA: 0x0001ADA5 File Offset: 0x00018FA5
		public static string ToString(int value)
		{
			return value.ToString(null, JsonConvert.smethod_1());
		}

		// Token: 0x06001FDB RID: 8155 RVA: 0x0001ADB4 File Offset: 0x00018FB4
		public static string ToString(short value)
		{
			return value.ToString(null, JsonConvert.smethod_1());
		}

		// Token: 0x06001FDC RID: 8156 RVA: 0x0001ADC3 File Offset: 0x00018FC3
		[CLSCompliant(false)]
		public static string ToString(ushort value)
		{
			return value.ToString(null, JsonConvert.smethod_1());
		}

		// Token: 0x06001FDD RID: 8157 RVA: 0x0001ADD2 File Offset: 0x00018FD2
		[CLSCompliant(false)]
		public static string ToString(uint value)
		{
			return value.ToString(null, JsonConvert.smethod_1());
		}

		// Token: 0x06001FDE RID: 8158 RVA: 0x0001ADE1 File Offset: 0x00018FE1
		public static string ToString(long value)
		{
			return value.ToString(null, JsonConvert.smethod_1());
		}

		// Token: 0x06001FDF RID: 8159 RVA: 0x0001ADF0 File Offset: 0x00018FF0
		private static string ToStringInternal(BigInteger value)
		{
			return value.ToString(null, JsonConvert.smethod_1());
		}

		// Token: 0x06001FE0 RID: 8160 RVA: 0x0001ADFF File Offset: 0x00018FFF
		[CLSCompliant(false)]
		public static string ToString(ulong value)
		{
			return value.ToString(null, JsonConvert.smethod_1());
		}

		// Token: 0x06001FE1 RID: 8161 RVA: 0x0001AE0E File Offset: 0x0001900E
		public static string ToString(float value)
		{
			return JsonConvert.EnsureDecimalPlace((double)value, value.ToString(<Module>.smethod_25<string>(985601880U), JsonConvert.smethod_1()));
		}

		// Token: 0x06001FE2 RID: 8162 RVA: 0x0001AE2D File Offset: 0x0001902D
		internal static string ToString(float value, FloatFormatHandling floatFormatHandling, char quoteChar, bool nullable)
		{
			return JsonConvert.EnsureFloatFormat((double)value, JsonConvert.EnsureDecimalPlace((double)value, value.ToString(<Module>.smethod_23<string>(3365919479U), JsonConvert.smethod_1())), floatFormatHandling, quoteChar, nullable);
		}

		// Token: 0x06001FE3 RID: 8163 RVA: 0x00085B98 File Offset: 0x00083D98
		private static string EnsureFloatFormat(double value, string text, FloatFormatHandling floatFormatHandling, char quoteChar, bool nullable)
		{
			if (floatFormatHandling == FloatFormatHandling.Symbol || (!double.IsInfinity(value) && !double.IsNaN(value)))
			{
				return text;
			}
			if (floatFormatHandling != FloatFormatHandling.DefaultValue)
			{
				return JsonConvert.smethod_5(quoteChar, text, quoteChar);
			}
			if (nullable)
			{
				return JsonConvert.Null;
			}
			return <Module>.smethod_26<string>(2838139985U);
		}

		// Token: 0x06001FE4 RID: 8164 RVA: 0x0001AE56 File Offset: 0x00019056
		public static string ToString(double value)
		{
			return JsonConvert.EnsureDecimalPlace(value, value.ToString(<Module>.smethod_27<string>(1325635103U), JsonConvert.smethod_1()));
		}

		// Token: 0x06001FE5 RID: 8165 RVA: 0x0001AE74 File Offset: 0x00019074
		internal static string ToString(double value, FloatFormatHandling floatFormatHandling, char quoteChar, bool nullable)
		{
			return JsonConvert.EnsureFloatFormat(value, JsonConvert.EnsureDecimalPlace(value, value.ToString(<Module>.smethod_27<string>(1325635103U), JsonConvert.smethod_1())), floatFormatHandling, quoteChar, nullable);
		}

		// Token: 0x06001FE6 RID: 8166 RVA: 0x00085BE8 File Offset: 0x00083DE8
		private static string EnsureDecimalPlace(double value, string text)
		{
			if (!double.IsNaN(value) && !double.IsInfinity(value) && JsonConvert.smethod_6(text, '.') == -1 && JsonConvert.smethod_6(text, 'E') == -1)
			{
				if (JsonConvert.smethod_6(text, 'e') == -1)
				{
					return JsonConvert.smethod_7(text, <Module>.smethod_23<string>(2696422071U));
				}
			}
			return text;
		}

		// Token: 0x06001FE7 RID: 8167 RVA: 0x0001AE9B File Offset: 0x0001909B
		private static string EnsureDecimalPlace(string text)
		{
			if (JsonConvert.smethod_6(text, '.') != -1)
			{
				return text;
			}
			return JsonConvert.smethod_7(text, <Module>.smethod_24<string>(104598470U));
		}

		// Token: 0x06001FE8 RID: 8168 RVA: 0x0001AEBA File Offset: 0x000190BA
		public static string ToString(byte value)
		{
			return value.ToString(null, JsonConvert.smethod_1());
		}

		// Token: 0x06001FE9 RID: 8169 RVA: 0x0001AEC9 File Offset: 0x000190C9
		[CLSCompliant(false)]
		public static string ToString(sbyte value)
		{
			return value.ToString(null, JsonConvert.smethod_1());
		}

		// Token: 0x06001FEA RID: 8170 RVA: 0x0001AED8 File Offset: 0x000190D8
		public static string ToString(decimal value)
		{
			return JsonConvert.EnsureDecimalPlace(value.ToString(null, JsonConvert.smethod_1()));
		}

		// Token: 0x06001FEB RID: 8171 RVA: 0x0001AEEC File Offset: 0x000190EC
		public static string ToString(Guid value)
		{
			return JsonConvert.ToString(value, '"');
		}

		// Token: 0x06001FEC RID: 8172 RVA: 0x00085C3C File Offset: 0x00083E3C
		internal static string ToString(Guid value, char quoteChar)
		{
			string text = value.ToString(<Module>.smethod_25<string>(3054924734U), JsonConvert.smethod_1());
			string text2 = quoteChar.ToString(CultureInfo.InvariantCulture);
			return text2 + text + text2;
		}

		// Token: 0x06001FED RID: 8173 RVA: 0x0001AEF6 File Offset: 0x000190F6
		public static string ToString(TimeSpan value)
		{
			return JsonConvert.ToString(value, '"');
		}

		// Token: 0x06001FEE RID: 8174 RVA: 0x0001AF00 File Offset: 0x00019100
		internal static string ToString(TimeSpan value, char quoteChar)
		{
			return JsonConvert.ToString(value.ToString(), quoteChar);
		}

		// Token: 0x06001FEF RID: 8175 RVA: 0x0001AF15 File Offset: 0x00019115
		public static string ToString(Uri value)
		{
			if (JsonConvert.smethod_8(value, null))
			{
				return JsonConvert.Null;
			}
			return JsonConvert.ToString(value, '"');
		}

		// Token: 0x06001FF0 RID: 8176 RVA: 0x0001AF2E File Offset: 0x0001912E
		internal static string ToString(Uri value, char quoteChar)
		{
			return JsonConvert.ToString(JsonConvert.smethod_9(value), quoteChar);
		}

		// Token: 0x06001FF1 RID: 8177 RVA: 0x0001AF3C File Offset: 0x0001913C
		public static string ToString(string value)
		{
			return JsonConvert.ToString(value, '"');
		}

		// Token: 0x06001FF2 RID: 8178 RVA: 0x0001AF46 File Offset: 0x00019146
		public static string ToString(string value, char delimiter)
		{
			return JsonConvert.ToString(value, delimiter, StringEscapeHandling.Default);
		}

		// Token: 0x06001FF3 RID: 8179 RVA: 0x0001AF50 File Offset: 0x00019150
		public static string ToString(string value, char delimiter, StringEscapeHandling stringEscapeHandling)
		{
			if (delimiter != '"' && delimiter != '\'')
			{
				throw JsonConvert.smethod_10(<Module>.smethod_23<string>(3818484333U), <Module>.smethod_25<string>(275303346U));
			}
			return JavaScriptUtils.ToEscapedJavaScriptString(value, delimiter, true, stringEscapeHandling);
		}

		// Token: 0x06001FF4 RID: 8180 RVA: 0x00085C78 File Offset: 0x00083E78
		public static string ToString(object value)
		{
			if (value != null)
			{
				switch (ConvertUtils.GetTypeCode(JsonConvert.smethod_11(value)))
				{
				case PrimitiveTypeCode.Char:
					return JsonConvert.ToString((char)value);
				case PrimitiveTypeCode.Boolean:
					return JsonConvert.ToString((bool)value);
				case PrimitiveTypeCode.SByte:
					return JsonConvert.ToString((sbyte)value);
				case PrimitiveTypeCode.Int16:
					return JsonConvert.ToString((short)value);
				case PrimitiveTypeCode.UInt16:
					return JsonConvert.ToString((ushort)value);
				case PrimitiveTypeCode.Int32:
					return JsonConvert.ToString((int)value);
				case PrimitiveTypeCode.Byte:
					return JsonConvert.ToString((byte)value);
				case PrimitiveTypeCode.UInt32:
					return JsonConvert.ToString((uint)value);
				case PrimitiveTypeCode.Int64:
					return JsonConvert.ToString((long)value);
				case PrimitiveTypeCode.UInt64:
					return JsonConvert.ToString((ulong)value);
				case PrimitiveTypeCode.Single:
					return JsonConvert.ToString((float)value);
				case PrimitiveTypeCode.Double:
					return JsonConvert.ToString((double)value);
				case PrimitiveTypeCode.DateTime:
					return JsonConvert.ToString((DateTime)value);
				case PrimitiveTypeCode.DateTimeOffset:
					return JsonConvert.ToString((DateTimeOffset)value);
				case PrimitiveTypeCode.Decimal:
					return JsonConvert.ToString((decimal)value);
				case PrimitiveTypeCode.Guid:
					return JsonConvert.ToString((Guid)value);
				case PrimitiveTypeCode.TimeSpan:
					return JsonConvert.ToString((TimeSpan)value);
				case PrimitiveTypeCode.BigInteger:
					return JsonConvert.ToStringInternal((BigInteger)value);
				case PrimitiveTypeCode.Uri:
					return JsonConvert.ToString((Uri)value);
				case PrimitiveTypeCode.String:
					return JsonConvert.ToString((string)value);
				case PrimitiveTypeCode.DBNull:
					return JsonConvert.Null;
				}
				throw JsonConvert.smethod_12(<Module>.smethod_23<string>(2561021136U).FormatWith(JsonConvert.smethod_1(), JsonConvert.smethod_11(value)));
			}
			return JsonConvert.Null;
		}

		// Token: 0x06001FF5 RID: 8181 RVA: 0x0001AF7F File Offset: 0x0001917F
		public static string SerializeObject(object value)
		{
			return JsonConvert.SerializeObject(value, null, null);
		}

		// Token: 0x06001FF6 RID: 8182 RVA: 0x0001AF89 File Offset: 0x00019189
		public static string SerializeObject(object value, Formatting formatting)
		{
			return JsonConvert.SerializeObject(value, formatting, null);
		}

		// Token: 0x06001FF7 RID: 8183 RVA: 0x00085E64 File Offset: 0x00084064
		public static string SerializeObject(object value, params JsonConverter[] converters)
		{
			JsonSerializerSettings jsonSerializerSettings = ((converters == null || converters.Length <= 0) ? null : new JsonSerializerSettings
			{
				Converters = converters
			});
			return JsonConvert.SerializeObject(value, null, jsonSerializerSettings);
		}

		// Token: 0x06001FF8 RID: 8184 RVA: 0x00085E94 File Offset: 0x00084094
		public static string SerializeObject(object value, Formatting formatting, params JsonConverter[] converters)
		{
			JsonSerializerSettings jsonSerializerSettings = ((converters == null || converters.Length <= 0) ? null : new JsonSerializerSettings
			{
				Converters = converters
			});
			return JsonConvert.SerializeObject(value, null, formatting, jsonSerializerSettings);
		}

		// Token: 0x06001FF9 RID: 8185 RVA: 0x0001AF93 File Offset: 0x00019193
		public static string SerializeObject(object value, JsonSerializerSettings settings)
		{
			return JsonConvert.SerializeObject(value, null, settings);
		}

		// Token: 0x06001FFA RID: 8186 RVA: 0x00085EC8 File Offset: 0x000840C8
		public static string SerializeObject(object value, Type type, JsonSerializerSettings settings)
		{
			JsonSerializer jsonSerializer = JsonSerializer.CreateDefault(settings);
			return JsonConvert.SerializeObjectInternal(value, type, jsonSerializer);
		}

		// Token: 0x06001FFB RID: 8187 RVA: 0x0001AF9D File Offset: 0x0001919D
		public static string SerializeObject(object value, Formatting formatting, JsonSerializerSettings settings)
		{
			return JsonConvert.SerializeObject(value, null, formatting, settings);
		}

		// Token: 0x06001FFC RID: 8188 RVA: 0x00085EE4 File Offset: 0x000840E4
		public static string SerializeObject(object value, Type type, Formatting formatting, JsonSerializerSettings settings)
		{
			JsonSerializer jsonSerializer = JsonSerializer.CreateDefault(settings);
			jsonSerializer.Formatting = formatting;
			return JsonConvert.SerializeObjectInternal(value, type, jsonSerializer);
		}

		// Token: 0x06001FFD RID: 8189 RVA: 0x00085F08 File Offset: 0x00084108
		private static string SerializeObjectInternal(object value, Type type, JsonSerializer jsonSerializer)
		{
			StringBuilder stringBuilder = JsonConvert.smethod_13(256);
			StringWriter stringWriter = JsonConvert.smethod_14(stringBuilder, JsonConvert.smethod_1());
			JsonTextWriter jsonTextWriter = new JsonTextWriter(stringWriter);
			try
			{
				jsonTextWriter.Formatting = jsonSerializer.Formatting;
				jsonSerializer.Serialize(jsonTextWriter, value, type);
			}
			finally
			{
				if (jsonTextWriter != null)
				{
					JsonConvert.smethod_3(jsonTextWriter);
				}
			}
			return JsonConvert.smethod_2(stringWriter);
		}

		// Token: 0x06001FFE RID: 8190 RVA: 0x0001AFA8 File Offset: 0x000191A8
		[Obsolete("SerializeObjectAsync is obsolete. Use the Task.Factory.StartNew method to serialize JSON asynchronously: Task.Factory.StartNew(() => JsonConvert.SerializeObject(value))")]
		public static Task<string> SerializeObjectAsync(object value)
		{
			return JsonConvert.SerializeObjectAsync(value, Formatting.None, null);
		}

		// Token: 0x06001FFF RID: 8191 RVA: 0x0001AFB2 File Offset: 0x000191B2
		[Obsolete("SerializeObjectAsync is obsolete. Use the Task.Factory.StartNew method to serialize JSON asynchronously: Task.Factory.StartNew(() => JsonConvert.SerializeObject(value, formatting))")]
		public static Task<string> SerializeObjectAsync(object value, Formatting formatting)
		{
			return JsonConvert.SerializeObjectAsync(value, formatting, null);
		}

		// Token: 0x06002000 RID: 8192 RVA: 0x00085F6C File Offset: 0x0008416C
		[Obsolete("SerializeObjectAsync is obsolete. Use the Task.Factory.StartNew method to serialize JSON asynchronously: Task.Factory.StartNew(() => JsonConvert.SerializeObject(value, formatting, settings))")]
		public static Task<string> SerializeObjectAsync(object value, Formatting formatting, JsonSerializerSettings settings)
		{
			return JsonConvert.smethod_15().StartNew<string>(() => JsonConvert.SerializeObject(value, formatting, settings));
		}

		// Token: 0x06002001 RID: 8193 RVA: 0x0001AFBC File Offset: 0x000191BC
		public static object DeserializeObject(string value)
		{
			return JsonConvert.DeserializeObject(value, null, null);
		}

		// Token: 0x06002002 RID: 8194 RVA: 0x0001AFC6 File Offset: 0x000191C6
		public static object DeserializeObject(string value, JsonSerializerSettings settings)
		{
			return JsonConvert.DeserializeObject(value, null, settings);
		}

		// Token: 0x06002003 RID: 8195 RVA: 0x0001AFD0 File Offset: 0x000191D0
		public static object DeserializeObject(string value, Type type)
		{
			return JsonConvert.DeserializeObject(value, type, null);
		}

		// Token: 0x06002004 RID: 8196 RVA: 0x0001AFDA File Offset: 0x000191DA
		public static T DeserializeObject<T>(string value)
		{
			return JsonConvert.DeserializeObject<T>(value, null);
		}

		// Token: 0x06002005 RID: 8197 RVA: 0x0001AFE3 File Offset: 0x000191E3
		public static T DeserializeAnonymousType<T>(string value, T anonymousTypeObject)
		{
			return JsonConvert.DeserializeObject<T>(value);
		}

		// Token: 0x06002006 RID: 8198 RVA: 0x0001AFEB File Offset: 0x000191EB
		public static T DeserializeAnonymousType<T>(string value, T anonymousTypeObject, JsonSerializerSettings settings)
		{
			return JsonConvert.DeserializeObject<T>(value, settings);
		}

		// Token: 0x06002007 RID: 8199 RVA: 0x0001AFF4 File Offset: 0x000191F4
		public static T DeserializeObject<T>(string value, params JsonConverter[] converters)
		{
			return (T)((object)JsonConvert.DeserializeObject(value, JsonConvert.smethod_16(typeof(T).TypeHandle), converters));
		}

		// Token: 0x06002008 RID: 8200 RVA: 0x0001B00C File Offset: 0x0001920C
		public static T DeserializeObject<T>(string value, JsonSerializerSettings settings)
		{
			return (T)((object)JsonConvert.DeserializeObject(value, JsonConvert.smethod_16(typeof(T).TypeHandle), settings));
		}

		// Token: 0x06002009 RID: 8201 RVA: 0x00085FAC File Offset: 0x000841AC
		public static object DeserializeObject(string value, Type type, params JsonConverter[] converters)
		{
			JsonSerializerSettings jsonSerializerSettings = ((converters == null || converters.Length <= 0) ? null : new JsonSerializerSettings
			{
				Converters = converters
			});
			return JsonConvert.DeserializeObject(value, type, jsonSerializerSettings);
		}

		// Token: 0x0600200A RID: 8202 RVA: 0x00085FDC File Offset: 0x000841DC
		public static object DeserializeObject(string value, Type type, JsonSerializerSettings settings)
		{
			ValidationUtils.ArgumentNotNull(value, <Module>.smethod_27<string>(2371252898U));
			JsonSerializer jsonSerializer = JsonSerializer.CreateDefault(settings);
			if (!jsonSerializer.IsCheckAdditionalContentSet())
			{
				jsonSerializer.CheckAdditionalContent = true;
			}
			JsonTextReader jsonTextReader = new JsonTextReader(JsonConvert.smethod_17(value));
			object obj;
			try
			{
				obj = jsonSerializer.Deserialize(jsonTextReader, type);
			}
			finally
			{
				if (jsonTextReader != null)
				{
					JsonConvert.smethod_3(jsonTextReader);
				}
			}
			return obj;
		}

		// Token: 0x0600200B RID: 8203 RVA: 0x0001B024 File Offset: 0x00019224
		[Obsolete("DeserializeObjectAsync is obsolete. Use the Task.Factory.StartNew method to deserialize JSON asynchronously: Task.Factory.StartNew(() => JsonConvert.DeserializeObject<T>(value))")]
		public static Task<T> DeserializeObjectAsync<T>(string value)
		{
			return JsonConvert.DeserializeObjectAsync<T>(value, null);
		}

		// Token: 0x0600200C RID: 8204 RVA: 0x00086044 File Offset: 0x00084244
		[Obsolete("DeserializeObjectAsync is obsolete. Use the Task.Factory.StartNew method to deserialize JSON asynchronously: Task.Factory.StartNew(() => JsonConvert.DeserializeObject<T>(value, settings))")]
		public static Task<T> DeserializeObjectAsync<T>(string value, JsonSerializerSettings settings)
		{
			return JsonConvert.smethod_15().StartNew<T>(() => JsonConvert.DeserializeObject<T>(value, settings));
		}

		// Token: 0x0600200D RID: 8205 RVA: 0x0001B02D File Offset: 0x0001922D
		[Obsolete("DeserializeObjectAsync is obsolete. Use the Task.Factory.StartNew method to deserialize JSON asynchronously: Task.Factory.StartNew(() => JsonConvert.DeserializeObject(value))")]
		public static Task<object> DeserializeObjectAsync(string value)
		{
			return JsonConvert.DeserializeObjectAsync(value, null, null);
		}

		// Token: 0x0600200E RID: 8206 RVA: 0x0008607C File Offset: 0x0008427C
		[Obsolete("DeserializeObjectAsync is obsolete. Use the Task.Factory.StartNew method to deserialize JSON asynchronously: Task.Factory.StartNew(() => JsonConvert.DeserializeObject(value, type, settings))")]
		public static Task<object> DeserializeObjectAsync(string value, Type type, JsonSerializerSettings settings)
		{
			return JsonConvert.smethod_15().StartNew<object>(() => JsonConvert.DeserializeObject(value, type, settings));
		}

		// Token: 0x0600200F RID: 8207 RVA: 0x0001B037 File Offset: 0x00019237
		public static void PopulateObject(string value, object target)
		{
			JsonConvert.PopulateObject(value, target, null);
		}

		// Token: 0x06002010 RID: 8208 RVA: 0x000860BC File Offset: 0x000842BC
		public static void PopulateObject(string value, object target, JsonSerializerSettings settings)
		{
			JsonSerializer jsonSerializer = JsonSerializer.CreateDefault(settings);
			JsonReader jsonReader = new JsonTextReader(JsonConvert.smethod_17(value));
			try
			{
				jsonSerializer.Populate(jsonReader, target);
				if (jsonReader.Read() && jsonReader.TokenType != JsonToken.Comment)
				{
					throw new JsonSerializationException(<Module>.smethod_24<string>(1377896464U));
				}
			}
			finally
			{
				if (jsonReader != null)
				{
					JsonConvert.smethod_3(jsonReader);
				}
			}
		}

		// Token: 0x06002011 RID: 8209 RVA: 0x00086124 File Offset: 0x00084324
		[Obsolete("PopulateObjectAsync is obsolete. Use the Task.Factory.StartNew method to populate an object with JSON values asynchronously: Task.Factory.StartNew(() => JsonConvert.PopulateObject(value, target, settings))")]
		public static Task PopulateObjectAsync(string value, object target, JsonSerializerSettings settings)
		{
			return JsonConvert.smethod_18(JsonConvert.smethod_15(), delegate
			{
				JsonConvert.PopulateObject(value, target, settings);
			});
		}

		// Token: 0x06002012 RID: 8210 RVA: 0x0001B041 File Offset: 0x00019241
		public static string SerializeXmlNode(XmlNode node)
		{
			return JsonConvert.SerializeXmlNode(node, Formatting.None);
		}

		// Token: 0x06002013 RID: 8211 RVA: 0x00086164 File Offset: 0x00084364
		public static string SerializeXmlNode(XmlNode node, Formatting formatting)
		{
			XmlNodeConverter xmlNodeConverter = new XmlNodeConverter();
			return JsonConvert.SerializeObject(node, formatting, new JsonConverter[] { xmlNodeConverter });
		}

		// Token: 0x06002014 RID: 8212 RVA: 0x00086190 File Offset: 0x00084390
		public static string SerializeXmlNode(XmlNode node, Formatting formatting, bool omitRootObject)
		{
			XmlNodeConverter xmlNodeConverter = new XmlNodeConverter
			{
				OmitRootObject = omitRootObject
			};
			return JsonConvert.SerializeObject(node, formatting, new JsonConverter[] { xmlNodeConverter });
		}

		// Token: 0x06002015 RID: 8213 RVA: 0x0001B04A File Offset: 0x0001924A
		public static XmlDocument DeserializeXmlNode(string value)
		{
			return JsonConvert.DeserializeXmlNode(value, null);
		}

		// Token: 0x06002016 RID: 8214 RVA: 0x0001B053 File Offset: 0x00019253
		public static XmlDocument DeserializeXmlNode(string value, string deserializeRootElementName)
		{
			return JsonConvert.DeserializeXmlNode(value, deserializeRootElementName, false);
		}

		// Token: 0x06002017 RID: 8215 RVA: 0x000861C4 File Offset: 0x000843C4
		public static XmlDocument DeserializeXmlNode(string value, string deserializeRootElementName, bool writeArrayAttribute)
		{
			XmlNodeConverter xmlNodeConverter = new XmlNodeConverter();
			xmlNodeConverter.DeserializeRootElementName = deserializeRootElementName;
			xmlNodeConverter.WriteArrayAttribute = writeArrayAttribute;
			return (XmlDocument)JsonConvert.DeserializeObject(value, JsonConvert.smethod_16(typeof(XmlDocument).TypeHandle), new JsonConverter[] { xmlNodeConverter });
		}

		// Token: 0x06002018 RID: 8216 RVA: 0x0001B05D File Offset: 0x0001925D
		public static string SerializeXNode(XObject node)
		{
			return JsonConvert.SerializeXNode(node, Formatting.None);
		}

		// Token: 0x06002019 RID: 8217 RVA: 0x0001B066 File Offset: 0x00019266
		public static string SerializeXNode(XObject node, Formatting formatting)
		{
			return JsonConvert.SerializeXNode(node, formatting, false);
		}

		// Token: 0x0600201A RID: 8218 RVA: 0x00086190 File Offset: 0x00084390
		public static string SerializeXNode(XObject node, Formatting formatting, bool omitRootObject)
		{
			XmlNodeConverter xmlNodeConverter = new XmlNodeConverter
			{
				OmitRootObject = omitRootObject
			};
			return JsonConvert.SerializeObject(node, formatting, new JsonConverter[] { xmlNodeConverter });
		}

		// Token: 0x0600201B RID: 8219 RVA: 0x0001B070 File Offset: 0x00019270
		public static XDocument DeserializeXNode(string value)
		{
			return JsonConvert.DeserializeXNode(value, null);
		}

		// Token: 0x0600201C RID: 8220 RVA: 0x0001B079 File Offset: 0x00019279
		public static XDocument DeserializeXNode(string value, string deserializeRootElementName)
		{
			return JsonConvert.DeserializeXNode(value, deserializeRootElementName, false);
		}

		// Token: 0x0600201D RID: 8221 RVA: 0x0008620C File Offset: 0x0008440C
		public static XDocument DeserializeXNode(string value, string deserializeRootElementName, bool writeArrayAttribute)
		{
			XmlNodeConverter xmlNodeConverter = new XmlNodeConverter();
			xmlNodeConverter.DeserializeRootElementName = deserializeRootElementName;
			xmlNodeConverter.WriteArrayAttribute = writeArrayAttribute;
			return (XDocument)JsonConvert.DeserializeObject(value, JsonConvert.smethod_16(typeof(XDocument).TypeHandle), new JsonConverter[] { xmlNodeConverter });
		}

		// Token: 0x0600201F RID: 8223 RVA: 0x0001AC4B File Offset: 0x00018E4B
		static void smethod_0(TextWriter textWriter_0, char char_0)
		{
			textWriter_0.Write(char_0);
		}

		// Token: 0x06002020 RID: 8224 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_1()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06002021 RID: 8225 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_2(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06002022 RID: 8226 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_3(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06002023 RID: 8227 RVA: 0x00017904 File Offset: 0x00015B04
		static string smethod_4(Enum enum_0, string string_0)
		{
			return enum_0.ToString(string_0);
		}

		// Token: 0x06002024 RID: 8228 RVA: 0x00016271 File Offset: 0x00014471
		static string smethod_5(object object_0, object object_1, object object_2)
		{
			return object_0 + object_1 + object_2;
		}

		// Token: 0x06002025 RID: 8229 RVA: 0x0000FABD File Offset: 0x0000DCBD
		static int smethod_6(string string_0, char char_0)
		{
			return string_0.IndexOf(char_0);
		}

		// Token: 0x06002026 RID: 8230 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_7(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x06002027 RID: 8231 RVA: 0x0000FCA7 File Offset: 0x0000DEA7
		static bool smethod_8(Uri uri_0, Uri uri_1)
		{
			return uri_0 == uri_1;
		}

		// Token: 0x06002028 RID: 8232 RVA: 0x0001AC67 File Offset: 0x00018E67
		static string smethod_9(Uri uri_0)
		{
			return uri_0.OriginalString;
		}

		// Token: 0x06002029 RID: 8233 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_10(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}

		// Token: 0x0600202A RID: 8234 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_11(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x0600202B RID: 8235 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_12(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x0600202C RID: 8236 RVA: 0x0000FD8A File Offset: 0x0000DF8A
		static StringBuilder smethod_13(int int_0)
		{
			return new StringBuilder(int_0);
		}

		// Token: 0x0600202D RID: 8237 RVA: 0x0001B083 File Offset: 0x00019283
		static StringWriter smethod_14(StringBuilder stringBuilder_0, IFormatProvider iformatProvider_0)
		{
			return new StringWriter(stringBuilder_0, iformatProvider_0);
		}

		// Token: 0x0600202E RID: 8238 RVA: 0x0000D01D File Offset: 0x0000B21D
		static TaskFactory smethod_15()
		{
			return Task.Factory;
		}

		// Token: 0x0600202F RID: 8239 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_16(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06002030 RID: 8240 RVA: 0x000161BD File Offset: 0x000143BD
		static StringReader smethod_17(string string_0)
		{
			return new StringReader(string_0);
		}

		// Token: 0x06002031 RID: 8241 RVA: 0x0000D024 File Offset: 0x0000B224
		static Task smethod_18(TaskFactory taskFactory_0, Action action_0)
		{
			return taskFactory_0.StartNew(action_0);
		}

		// Token: 0x04000BB6 RID: 2998
		public static readonly string True = <Module>.smethod_25<string>(3949208061U);

		// Token: 0x04000BB7 RID: 2999
		public static readonly string False = <Module>.smethod_23<string>(1303867380U);

		// Token: 0x04000BB8 RID: 3000
		public static readonly string Null = <Module>.smethod_24<string>(3239580363U);

		// Token: 0x04000BB9 RID: 3001
		public static readonly string Undefined = <Module>.smethod_26<string>(3019346420U);

		// Token: 0x04000BBA RID: 3002
		public static readonly string PositiveInfinity = <Module>.smethod_24<string>(795106028U);

		// Token: 0x04000BBB RID: 3003
		public static readonly string NegativeInfinity = <Module>.smethod_27<string>(1203842772U);

		// Token: 0x04000BBC RID: 3004
		public static readonly string NaN = <Module>.smethod_23<string>(3606388456U);
	}
}
