﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Numerics;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json
{
	// Token: 0x02000227 RID: 551
	public class JsonTextReader : JsonReader, IJsonLineInfo
	{
		// Token: 0x06001F12 RID: 7954 RVA: 0x00083540 File Offset: 0x00081740
		public JsonTextReader(TextReader reader)
		{
			for (;;)
			{
				IL_0038:
				int num = -1873748022;
				for (;;)
				{
					switch (num ^ -1873748021)
					{
					case 0:
						goto IL_0038;
					case 1:
						if (reader == null)
						{
							goto Block_1;
						}
						goto IL_0008;
					case 3:
						goto IL_0008;
					}
					goto Block_2;
					IL_0008:
					this._reader = reader;
					num = -1873748023;
				}
			}
			Block_1:
			throw JsonTextReader.smethod_12(<Module>.smethod_26<string>(3313616177U));
			Block_2:
			this._lineNumber = 1;
			this._chars = new char[1025];
		}

		// Token: 0x06001F13 RID: 7955 RVA: 0x0001A4DD File Offset: 0x000186DD
		private StringBuffer GetBuffer()
		{
			if (this._buffer == null)
			{
				this._buffer = new StringBuffer(1025);
			}
			else
			{
				this._buffer.Position = 0;
			}
			return this._buffer;
		}

		// Token: 0x06001F14 RID: 7956 RVA: 0x0001A50B File Offset: 0x0001870B
		private void OnNewLine(int pos)
		{
			this._lineNumber++;
			this._lineStartPos = pos - 1;
		}

		// Token: 0x06001F15 RID: 7957 RVA: 0x000835B4 File Offset: 0x000817B4
		private void ParseString(char quote)
		{
			this._charPos++;
			this.ShiftBufferIfNeeded();
			this.ReadStringIntoBuffer(quote);
			base.SetPostValueState(true);
			if (this._readType == ReadType.ReadAsBytes)
			{
				byte[] array;
				Guid guid;
				if (this._stringReference.Length == 0)
				{
					array = new byte[0];
				}
				else if (this._stringReference.Length == 36 && ConvertUtils.TryConvertGuid(this._stringReference.ToString(), out guid))
				{
					array = guid.ToByteArray();
				}
				else
				{
					array = Convert.FromBase64CharArray(this._stringReference.Chars, this._stringReference.StartIndex, this._stringReference.Length);
				}
				base.SetToken(JsonToken.Bytes, array, false);
				return;
			}
			if (this._readType == ReadType.ReadAsString)
			{
				string text = this._stringReference.ToString();
				base.SetToken(JsonToken.String, text, false);
				this._quoteChar = quote;
				return;
			}
			string text2 = this._stringReference.ToString();
			if (this._dateParseHandling != DateParseHandling.None)
			{
				DateParseHandling dateParseHandling;
				if (this._readType == ReadType.ReadAsDateTime)
				{
					dateParseHandling = DateParseHandling.DateTime;
				}
				else if (this._readType == ReadType.ReadAsDateTimeOffset)
				{
					dateParseHandling = DateParseHandling.DateTimeOffset;
				}
				else
				{
					dateParseHandling = this._dateParseHandling;
				}
				object obj;
				if (DateTimeUtils.TryParseDateTime(text2, dateParseHandling, base.DateTimeZoneHandling, base.DateFormatString, base.Culture, out obj))
				{
					base.SetToken(JsonToken.Date, obj, false);
					return;
				}
			}
			base.SetToken(JsonToken.String, text2, false);
			this._quoteChar = quote;
		}

		// Token: 0x06001F16 RID: 7958 RVA: 0x0001A524 File Offset: 0x00018724
		private static void BlockCopyChars(char[] src, int srcOffset, char[] dst, int dstOffset, int count)
		{
			JsonTextReader.smethod_13(src, srcOffset * 2, dst, dstOffset * 2, count * 2);
		}

		// Token: 0x06001F17 RID: 7959 RVA: 0x00083710 File Offset: 0x00081910
		private void ShiftBufferIfNeeded()
		{
			int num = this._chars.Length;
			if ((double)(num - this._charPos) <= (double)num * 0.1)
			{
				int num2 = this._charsUsed - this._charPos;
				if (num2 > 0)
				{
					JsonTextReader.BlockCopyChars(this._chars, this._charPos, this._chars, 0, num2);
				}
				this._lineStartPos -= this._charPos;
				this._charPos = 0;
				this._charsUsed = num2;
				this._chars[this._charsUsed] = '\0';
			}
		}

		// Token: 0x06001F18 RID: 7960 RVA: 0x0001A537 File Offset: 0x00018737
		private int ReadData(bool append)
		{
			return this.ReadData(append, 0);
		}

		// Token: 0x06001F19 RID: 7961 RVA: 0x00083798 File Offset: 0x00081998
		private int ReadData(bool append, int charsRequired)
		{
			if (!this._isEndOfFile)
			{
				if (this._charsUsed + charsRequired >= this._chars.Length - 1)
				{
					if (!append)
					{
						int num = this._charsUsed - this._charPos;
						if (num + charsRequired + 1 >= this._chars.Length)
						{
							char[] array = new char[num + charsRequired + 1];
							if (num > 0)
							{
								JsonTextReader.BlockCopyChars(this._chars, this._charPos, array, 0, num);
							}
							this._chars = array;
						}
						else if (num > 0)
						{
							JsonTextReader.BlockCopyChars(this._chars, this._charPos, this._chars, 0, num);
						}
						this._lineStartPos -= this._charPos;
						this._charPos = 0;
						this._charsUsed = num;
					}
					else
					{
						int num2 = JsonTextReader.smethod_14(this._chars.Length * 2, this._charsUsed + charsRequired + 1);
						char[] array2 = new char[num2];
						JsonTextReader.BlockCopyChars(this._chars, 0, array2, 0, this._chars.Length);
						this._chars = array2;
					}
				}
				int num3 = this._chars.Length - this._charsUsed - 1;
				int num4 = JsonTextReader.smethod_15(this._reader, this._chars, this._charsUsed, num3);
				this._charsUsed += num4;
				if (num4 == 0)
				{
					this._isEndOfFile = true;
				}
				this._chars[this._charsUsed] = '\0';
				return num4;
			}
			return 0;
		}

		// Token: 0x06001F1A RID: 7962 RVA: 0x0001A541 File Offset: 0x00018741
		private bool EnsureChars(int relativePosition, bool append)
		{
			return this._charPos + relativePosition < this._charsUsed || this.ReadChars(relativePosition, append);
		}

		// Token: 0x06001F1B RID: 7963 RVA: 0x000838F0 File Offset: 0x00081AF0
		private bool ReadChars(int relativePosition, bool append)
		{
			if (!this._isEndOfFile)
			{
				int num = this._charPos + relativePosition - this._charsUsed + 1;
				int num2 = 0;
				do
				{
					int num3 = this.ReadData(append, num - num2);
					if (num3 == 0)
					{
						break;
					}
					num2 += num3;
				}
				while (num2 < num);
				return num2 >= num;
			}
			return false;
		}

		// Token: 0x06001F1C RID: 7964 RVA: 0x0001A55D File Offset: 0x0001875D
		[DebuggerStepThrough]
		public override bool Read()
		{
			this._readType = ReadType.Read;
			if (!this.ReadInternal())
			{
				base.SetToken(JsonToken.None);
				return false;
			}
			return true;
		}

		// Token: 0x06001F1D RID: 7965 RVA: 0x0001690A File Offset: 0x00014B0A
		public override byte[] ReadAsBytes()
		{
			return base.ReadAsBytesInternal();
		}

		// Token: 0x06001F1E RID: 7966 RVA: 0x00016912 File Offset: 0x00014B12
		public override decimal? ReadAsDecimal()
		{
			return base.ReadAsDecimalInternal();
		}

		// Token: 0x06001F1F RID: 7967 RVA: 0x0001691A File Offset: 0x00014B1A
		public override int? ReadAsInt32()
		{
			return base.ReadAsInt32Internal();
		}

		// Token: 0x06001F20 RID: 7968 RVA: 0x00016922 File Offset: 0x00014B22
		public override string ReadAsString()
		{
			return base.ReadAsStringInternal();
		}

		// Token: 0x06001F21 RID: 7969 RVA: 0x0001692A File Offset: 0x00014B2A
		public override DateTime? ReadAsDateTime()
		{
			return base.ReadAsDateTimeInternal();
		}

		// Token: 0x06001F22 RID: 7970 RVA: 0x00016932 File Offset: 0x00014B32
		public override DateTimeOffset? ReadAsDateTimeOffset()
		{
			return base.ReadAsDateTimeOffsetInternal();
		}

		// Token: 0x06001F23 RID: 7971 RVA: 0x0008393C File Offset: 0x00081B3C
		internal override bool ReadInternal()
		{
			for (;;)
			{
				switch (this._currentState)
				{
				case JsonReader.State.Start:
				case JsonReader.State.Property:
				case JsonReader.State.ArrayStart:
				case JsonReader.State.Array:
				case JsonReader.State.ConstructorStart:
				case JsonReader.State.Constructor:
					goto IL_0056;
				case JsonReader.State.ObjectStart:
				case JsonReader.State.Object:
					goto IL_004D;
				case JsonReader.State.PostValue:
					if (this.ParsePostValue())
					{
						return true;
					}
					continue;
				case JsonReader.State.Finished:
					goto IL_0083;
				}
				break;
			}
			goto IL_005D;
			IL_004D:
			return this.ParseObject();
			IL_0056:
			return this.ParseValue();
			IL_005D:
			throw JsonReaderException.Create(this, <Module>.smethod_24<string>(216888120U).FormatWith(JsonTextReader.smethod_16(), base.CurrentState));
			IL_0083:
			if (!this.EnsureChars(0, false))
			{
				return false;
			}
			this.EatWhitespace(false);
			if (this._isEndOfFile)
			{
				return false;
			}
			if (this._chars[this._charPos] == '/')
			{
				this.ParseComment();
				return true;
			}
			throw JsonReaderException.Create(this, <Module>.smethod_26<string>(428704778U).FormatWith(JsonTextReader.smethod_16(), this._chars[this._charPos]));
		}

		// Token: 0x06001F24 RID: 7972 RVA: 0x00083A30 File Offset: 0x00081C30
		private void ReadStringIntoBuffer(char quote)
		{
			int num = this._charPos;
			int charPos = this._charPos;
			int num2 = this._charPos;
			StringBuffer stringBuffer = null;
			char c2;
			for (;;)
			{
				char c = this._chars[num++];
				if (c > '\r')
				{
					if (c != '"' && c != '\'')
					{
						if (c == '\\')
						{
							this._charPos = num;
							if (!this.EnsureChars(0, true))
							{
								goto IL_02F1;
							}
							int num3 = num - 1;
							c2 = this._chars[num];
							char c3 = c2;
							char c4;
							if (c3 <= '\\')
							{
								if (c3 > '\'')
								{
									if (c3 != '/')
									{
										if (c3 != '\\')
										{
											goto Block_13;
										}
										num++;
										c4 = '\\';
										goto IL_026F;
									}
								}
								else if (c3 != '"' && c3 != '\'')
								{
									goto IL_02B5;
								}
								c4 = c2;
								num++;
							}
							else if (c3 <= 'f')
							{
								if (c3 != 'b')
								{
									if (c3 != 'f')
									{
										goto IL_02B5;
									}
									num++;
									c4 = '\f';
								}
								else
								{
									num++;
									c4 = '\b';
								}
							}
							else
							{
								if (c3 != 'n')
								{
									switch (c3)
									{
									case 'r':
										num++;
										c4 = '\r';
										goto IL_026F;
									case 't':
										num++;
										c4 = '\t';
										goto IL_026F;
									case 'u':
										num++;
										this._charPos = num;
										c4 = this.ParseUnicode();
										if (!StringUtils.IsLowSurrogate(c4))
										{
											if (StringUtils.IsHighSurrogate(c4))
											{
												for (;;)
												{
													bool flag = false;
													if (!this.EnsureChars(2, true))
													{
														goto IL_023A;
													}
													if (this._chars[this._charPos] != '\\' || this._chars[this._charPos + 1] != 'u')
													{
														goto IL_023A;
													}
													char c5 = c4;
													this._charPos += 2;
													c4 = this.ParseUnicode();
													if (!StringUtils.IsLowSurrogate(c4))
													{
														if (StringUtils.IsHighSurrogate(c4))
														{
															c5 = '\ufffd';
															flag = true;
														}
														else
														{
															c5 = '\ufffd';
														}
													}
													if (stringBuffer == null)
													{
														stringBuffer = this.GetBuffer();
													}
													this.WriteCharToBuffer(stringBuffer, c5, num2, num3);
													num2 = this._charPos;
													IL_0241:
													if (flag)
													{
														continue;
													}
													break;
													IL_023A:
													c4 = '\ufffd';
													goto IL_0241;
												}
											}
										}
										else
										{
											c4 = '\ufffd';
										}
										num = this._charPos;
										goto IL_026F;
									}
									goto Block_19;
								}
								num++;
								c4 = '\n';
							}
							IL_026F:
							if (stringBuffer == null)
							{
								stringBuffer = this.GetBuffer();
							}
							this.WriteCharToBuffer(stringBuffer, c4, num2, num3);
							num2 = num;
						}
					}
					else if (this._chars[num - 1] == quote)
					{
						goto IL_0319;
					}
				}
				else if (c != '\0')
				{
					if (c == '\n')
					{
						this._charPos = num - 1;
						this.ProcessLineFeed();
						num = this._charPos;
					}
					else if (c == '\r')
					{
						this._charPos = num - 1;
						this.ProcessCarriageReturn(true);
						num = this._charPos;
					}
				}
				else if (this._charsUsed == num - 1)
				{
					num--;
					if (this.ReadData(true) == 0)
					{
						break;
					}
				}
			}
			this._charPos = num;
			throw JsonReaderException.Create(this, <Module>.smethod_23<string>(31498412U).FormatWith(JsonTextReader.smethod_16(), quote));
			Block_13:
			Block_19:
			IL_02B5:
			num++;
			this._charPos = num;
			throw JsonReaderException.Create(this, <Module>.smethod_23<string>(3958716329U).FormatWith(JsonTextReader.smethod_16(), JsonTextReader.smethod_17(<Module>.smethod_23<string>(1896772993U), c2)));
			IL_02F1:
			this._charPos = num;
			throw JsonReaderException.Create(this, <Module>.smethod_27<string>(1915160620U).FormatWith(JsonTextReader.smethod_16(), quote));
			IL_0319:
			num--;
			if (charPos == num2)
			{
				this._stringReference = new StringReference(this._chars, charPos, num - charPos);
			}
			else
			{
				if (stringBuffer == null)
				{
					stringBuffer = this.GetBuffer();
				}
				if (num > num2)
				{
					stringBuffer.Append(this._chars, num2, num - num2);
				}
				this._stringReference = new StringReference(stringBuffer.GetInternalBuffer(), 0, stringBuffer.Position);
			}
			num++;
			this._charPos = num;
		}

		// Token: 0x06001F25 RID: 7973 RVA: 0x0001A578 File Offset: 0x00018778
		private void WriteCharToBuffer(StringBuffer buffer, char writeChar, int lastWritePosition, int writeToPosition)
		{
			if (writeToPosition > lastWritePosition)
			{
				buffer.Append(this._chars, lastWritePosition, writeToPosition - lastWritePosition);
			}
			buffer.Append(writeChar);
		}

		// Token: 0x06001F26 RID: 7974 RVA: 0x00083DE0 File Offset: 0x00081FE0
		private char ParseUnicode()
		{
			if (!this.EnsureChars(4, true))
			{
				throw JsonReaderException.Create(this, <Module>.smethod_25<string>(604544445U));
			}
			string text = JsonTextReader.smethod_18(this._chars, this._charPos, 4);
			char c = JsonTextReader.smethod_20(int.Parse(text, NumberStyles.HexNumber, JsonTextReader.smethod_19()));
			char c2 = c;
			this._charPos += 4;
			return c2;
		}

		// Token: 0x06001F27 RID: 7975 RVA: 0x00083E44 File Offset: 0x00082044
		private void ReadNumberIntoBuffer()
		{
			int num = this._charPos;
			for (;;)
			{
				char c = this._chars[num];
				if (c <= 'F')
				{
					if (c != '\0')
					{
						switch (c)
						{
						case '+':
						case '-':
						case '.':
						case '0':
						case '1':
						case '2':
						case '3':
						case '4':
						case '5':
						case '6':
						case '7':
						case '8':
						case '9':
						case 'A':
						case 'B':
						case 'C':
						case 'D':
						case 'E':
						case 'F':
							goto IL_003A;
						}
						break;
					}
					this._charPos = num;
					if (this._charsUsed == num && this.ReadData(true) != 0)
					{
						continue;
					}
					return;
				}
				else if (c != 'X')
				{
					switch (c)
					{
					case 'a':
					case 'b':
					case 'c':
					case 'd':
					case 'e':
					case 'f':
						break;
					default:
						if (c != 'x')
						{
							goto IL_00F2;
						}
						break;
					}
				}
				IL_003A:
				num++;
			}
			IL_00F2:
			this._charPos = num;
			char c2 = this._chars[this._charPos];
			if (!char.IsWhiteSpace(c2) && c2 != ',' && c2 != '}' && c2 != ']' && c2 != ')')
			{
				if (c2 != '/')
				{
					throw JsonReaderException.Create(this, <Module>.smethod_27<string>(2235740931U).FormatWith(JsonTextReader.smethod_16(), c2));
				}
			}
		}

		// Token: 0x06001F28 RID: 7976 RVA: 0x0001A597 File Offset: 0x00018797
		private void ClearRecentString()
		{
			if (this._buffer != null)
			{
				this._buffer.Position = 0;
			}
			this._stringReference = default(StringReference);
		}

		// Token: 0x06001F29 RID: 7977 RVA: 0x00083F9C File Offset: 0x0008219C
		private bool ParsePostValue()
		{
			char c;
			for (;;)
			{
				c = this._chars[this._charPos];
				char c2 = c;
				if (c2 <= ')')
				{
					if (c2 <= '\r')
					{
						if (c2 != '\0')
						{
							switch (c2)
							{
							case '\t':
								break;
							case '\n':
								this.ProcessLineFeed();
								continue;
							case '\v':
							case '\f':
								goto IL_008A;
							case '\r':
								this.ProcessCarriageReturn(false);
								continue;
							default:
								goto IL_008A;
							}
						}
						else
						{
							if (this._charsUsed != this._charPos)
							{
								this._charPos++;
								continue;
							}
							if (this.ReadData(false) == 0)
							{
								break;
							}
							continue;
						}
					}
					else if (c2 != ' ')
					{
						if (c2 != ')')
						{
							goto IL_008A;
						}
						goto IL_0151;
					}
					this._charPos++;
					continue;
				}
				if (c2 <= '/')
				{
					if (c2 == ',')
					{
						goto IL_00E0;
					}
					if (c2 == '/')
					{
						goto IL_00D8;
					}
				}
				else
				{
					if (c2 == ']')
					{
						goto IL_010E;
					}
					if (c2 == '}')
					{
						goto IL_00F6;
					}
				}
				IL_008A:
				if (!char.IsWhiteSpace(c))
				{
					goto IL_0130;
				}
				this._charPos++;
			}
			this._currentState = JsonReader.State.Finished;
			return false;
			IL_00D8:
			this.ParseComment();
			return true;
			IL_00E0:
			this._charPos++;
			base.SetStateBasedOnCurrent();
			return false;
			IL_00F6:
			this._charPos++;
			base.SetToken(JsonToken.EndObject);
			return true;
			IL_010E:
			this._charPos++;
			base.SetToken(JsonToken.EndArray);
			return true;
			IL_0130:
			throw JsonReaderException.Create(this, <Module>.smethod_26<string>(3932829105U).FormatWith(JsonTextReader.smethod_16(), c));
			IL_0151:
			this._charPos++;
			base.SetToken(JsonToken.EndConstructor);
			return true;
		}

		// Token: 0x06001F2A RID: 7978 RVA: 0x00084114 File Offset: 0x00082314
		private bool ParseObject()
		{
			for (;;)
			{
				char c = this._chars[this._charPos];
				char c2 = c;
				if (c2 <= '\r')
				{
					if (c2 == '\0')
					{
						if (this._charsUsed != this._charPos)
						{
							this._charPos++;
							continue;
						}
						if (this.ReadData(false) == 0)
						{
							break;
						}
						continue;
					}
					else
					{
						switch (c2)
						{
						case '\t':
							break;
						case '\n':
							this.ProcessLineFeed();
							continue;
						case '\v':
						case '\f':
							goto IL_007F;
						case '\r':
							this.ProcessCarriageReturn(false);
							continue;
						default:
							goto IL_007F;
						}
					}
				}
				else if (c2 != ' ')
				{
					if (c2 == '/')
					{
						goto IL_00CF;
					}
					if (c2 != '}')
					{
						goto IL_007F;
					}
					goto IL_00B7;
				}
				this._charPos++;
				continue;
				IL_007F:
				if (!char.IsWhiteSpace(c))
				{
					goto IL_00D9;
				}
				this._charPos++;
			}
			return false;
			IL_00B7:
			base.SetToken(JsonToken.EndObject);
			this._charPos++;
			return true;
			IL_00CF:
			this.ParseComment();
			return true;
			IL_00D9:
			return this.ParseProperty();
		}

		// Token: 0x06001F2B RID: 7979 RVA: 0x00084200 File Offset: 0x00082400
		private bool ParseProperty()
		{
			char c = this._chars[this._charPos];
			char c2;
			if (c != '"' && c != '\'')
			{
				if (!this.ValidIdentifierChar(c))
				{
					throw JsonReaderException.Create(this, <Module>.smethod_27<string>(650603369U).FormatWith(JsonTextReader.smethod_16(), this._chars[this._charPos]));
				}
				c2 = '\0';
				this.ShiftBufferIfNeeded();
				this.ParseUnquotedProperty();
			}
			else
			{
				this._charPos++;
				c2 = c;
				this.ShiftBufferIfNeeded();
				this.ReadStringIntoBuffer(c2);
			}
			string text;
			if (this.NameTable == null)
			{
				text = this._stringReference.ToString();
			}
			else
			{
				text = this.NameTable.Get(this._stringReference.Chars, this._stringReference.StartIndex, this._stringReference.Length);
				if (text == null)
				{
					text = this._stringReference.ToString();
				}
			}
			this.EatWhitespace(false);
			if (this._chars[this._charPos] == ':')
			{
				this._charPos++;
				base.SetToken(JsonToken.PropertyName, text);
				this._quoteChar = c2;
				this.ClearRecentString();
				return true;
			}
			throw JsonReaderException.Create(this, <Module>.smethod_24<string>(892660736U).FormatWith(JsonTextReader.smethod_16(), this._chars[this._charPos]));
		}

		// Token: 0x06001F2C RID: 7980 RVA: 0x0001A5B9 File Offset: 0x000187B9
		private bool ValidIdentifierChar(char value)
		{
			return char.IsLetterOrDigit(value) || value == '_' || value == '$';
		}

		// Token: 0x06001F2D RID: 7981 RVA: 0x00084354 File Offset: 0x00082554
		private void ParseUnquotedProperty()
		{
			int charPos = this._charPos;
			char c2;
			for (;;)
			{
				char c = this._chars[this._charPos];
				if (c == '\0')
				{
					if (this._charsUsed != this._charPos)
					{
						goto IL_006C;
					}
					if (this.ReadData(true) == 0)
					{
						break;
					}
				}
				else
				{
					c2 = this._chars[this._charPos];
					if (!this.ValidIdentifierChar(c2))
					{
						goto IL_0087;
					}
					this._charPos++;
				}
			}
			throw JsonReaderException.Create(this, <Module>.smethod_25<string>(1309892058U));
			IL_006C:
			this._stringReference = new StringReference(this._chars, charPos, this._charPos - charPos);
			return;
			IL_0087:
			if (!char.IsWhiteSpace(c2) && c2 != ':')
			{
				throw JsonReaderException.Create(this, <Module>.smethod_25<string>(2562646212U).FormatWith(JsonTextReader.smethod_16(), c2));
			}
			this._stringReference = new StringReference(this._chars, charPos, this._charPos - charPos);
		}

		// Token: 0x06001F2E RID: 7982 RVA: 0x00084430 File Offset: 0x00082630
		private bool ParseValue()
		{
			char c;
			for (;;)
			{
				c = this._chars[this._charPos];
				char c2 = c;
				if (c2 <= 'I')
				{
					if (c2 <= '\r')
					{
						if (c2 != '\0')
						{
							switch (c2)
							{
							case '\t':
								break;
							case '\n':
								this.ProcessLineFeed();
								continue;
							case '\v':
							case '\f':
								goto IL_0062;
							case '\r':
								this.ProcessCarriageReturn(false);
								continue;
							default:
								goto IL_0062;
							}
						}
						else
						{
							if (this._charsUsed != this._charPos)
							{
								this._charPos++;
								continue;
							}
							if (this.ReadData(false) == 0)
							{
								break;
							}
							continue;
						}
					}
					else
					{
						switch (c2)
						{
						case ' ':
							break;
						case '!':
							goto IL_0062;
						case '"':
							goto IL_01AB;
						default:
							switch (c2)
							{
							case '\'':
								goto IL_01AB;
							case '(':
							case '*':
							case '+':
							case '.':
								goto IL_0062;
							case ')':
								goto IL_0154;
							case ',':
								goto IL_016C;
							case '-':
								goto IL_0176;
							case '/':
								goto IL_01A3;
							default:
								if (c2 != 'I')
								{
									goto IL_0062;
								}
								goto IL_014C;
							}
							break;
						}
					}
					this._charPos++;
					continue;
				}
				if (c2 <= 'f')
				{
					if (c2 == 'N')
					{
						goto IL_01EB;
					}
					switch (c2)
					{
					case '[':
						goto IL_01BC;
					case '\\':
						break;
					case ']':
						goto IL_01D3;
					default:
						if (c2 == 'f')
						{
							goto IL_01B4;
						}
						break;
					}
				}
				else
				{
					if (c2 == 'n')
					{
						goto IL_0257;
					}
					switch (c2)
					{
					case 't':
						goto IL_0247;
					case 'u':
						goto IL_024F;
					default:
						if (c2 == '{')
						{
							goto IL_0230;
						}
						break;
					}
				}
				IL_0062:
				if (!char.IsWhiteSpace(c))
				{
					goto IL_01F3;
				}
				this._charPos++;
			}
			return false;
			IL_014C:
			this.ParseNumberPositiveInfinity();
			return true;
			IL_0154:
			this._charPos++;
			base.SetToken(JsonToken.EndConstructor);
			return true;
			IL_016C:
			base.SetToken(JsonToken.Undefined);
			return true;
			IL_0176:
			if (this.EnsureChars(1, true) && this._chars[this._charPos + 1] == 'I')
			{
				this.ParseNumberNegativeInfinity();
			}
			else
			{
				this.ParseNumber();
			}
			return true;
			IL_01A3:
			this.ParseComment();
			return true;
			IL_01AB:
			this.ParseString(c);
			return true;
			IL_01B4:
			this.ParseFalse();
			return true;
			IL_01BC:
			this._charPos++;
			base.SetToken(JsonToken.StartArray);
			return true;
			IL_01D3:
			this._charPos++;
			base.SetToken(JsonToken.EndArray);
			return true;
			IL_01EB:
			this.ParseNumberNaN();
			return true;
			IL_01F3:
			if (!char.IsNumber(c) && c != '-')
			{
				if (c != '.')
				{
					throw JsonReaderException.Create(this, <Module>.smethod_25<string>(3745802913U).FormatWith(JsonTextReader.smethod_16(), c));
				}
			}
			this.ParseNumber();
			return true;
			IL_0230:
			this._charPos++;
			base.SetToken(JsonToken.StartObject);
			return true;
			IL_0247:
			this.ParseTrue();
			return true;
			IL_024F:
			this.ParseUndefined();
			return true;
			IL_0257:
			if (this.EnsureChars(1, true))
			{
				char c3 = this._chars[this._charPos + 1];
				if (c3 == 'u')
				{
					this.ParseNull();
				}
				else
				{
					if (c3 != 'e')
					{
						throw JsonReaderException.Create(this, <Module>.smethod_25<string>(3745802913U).FormatWith(JsonTextReader.smethod_16(), this._chars[this._charPos]));
					}
					this.ParseConstructor();
				}
				return true;
			}
			throw JsonReaderException.Create(this, <Module>.smethod_25<string>(2886500100U));
		}

		// Token: 0x06001F2F RID: 7983 RVA: 0x0001A5CF File Offset: 0x000187CF
		private void ProcessLineFeed()
		{
			this._charPos++;
			this.OnNewLine(this._charPos);
		}

		// Token: 0x06001F30 RID: 7984 RVA: 0x00084708 File Offset: 0x00082908
		private void ProcessCarriageReturn(bool append)
		{
			this._charPos++;
			if (this.EnsureChars(1, append) && this._chars[this._charPos] == '\n')
			{
				this._charPos++;
			}
			this.OnNewLine(this._charPos);
		}

		// Token: 0x06001F31 RID: 7985 RVA: 0x00084758 File Offset: 0x00082958
		private bool EatWhitespace(bool oneOrMore)
		{
			bool flag = false;
			bool flag2 = false;
			while (!flag)
			{
				char c = this._chars[this._charPos];
				char c2 = c;
				if (c2 != '\0')
				{
					if (c2 != '\n')
					{
						if (c2 != '\r')
						{
							if (c != ' ' && !char.IsWhiteSpace(c))
							{
								flag = true;
							}
							else
							{
								flag2 = true;
								this._charPos++;
							}
						}
						else
						{
							this.ProcessCarriageReturn(false);
						}
					}
					else
					{
						this.ProcessLineFeed();
					}
				}
				else if (this._charsUsed != this._charPos)
				{
					this._charPos++;
				}
				else if (this.ReadData(false) == 0)
				{
					flag = true;
				}
			}
			return !oneOrMore || flag2;
		}

		// Token: 0x06001F32 RID: 7986 RVA: 0x000847F0 File Offset: 0x000829F0
		private void ParseConstructor()
		{
			if (!this.MatchValueWithTrailingSeparator(<Module>.smethod_27<string>(2748579554U)))
			{
				throw JsonReaderException.Create(this, <Module>.smethod_24<string>(1387550199U));
			}
			this.EatWhitespace(false);
			int charPos = this._charPos;
			char c;
			for (;;)
			{
				c = this._chars[this._charPos];
				if (c == '\0')
				{
					if (this._charsUsed != this._charPos)
					{
						goto IL_0079;
					}
					if (this.ReadData(true) == 0)
					{
						break;
					}
				}
				else
				{
					if (!char.IsLetterOrDigit(c))
					{
						goto IL_0090;
					}
					this._charPos++;
				}
			}
			throw JsonReaderException.Create(this, <Module>.smethod_25<string>(425199959U));
			IL_0079:
			int num = this._charPos;
			this._charPos++;
			goto IL_0105;
			IL_0090:
			if (c != '\r')
			{
				if (c == '\n')
				{
					num = this._charPos;
					this.ProcessLineFeed();
				}
				else if (char.IsWhiteSpace(c))
				{
					num = this._charPos;
					this._charPos++;
				}
				else
				{
					if (c != '(')
					{
						throw JsonReaderException.Create(this, <Module>.smethod_27<string>(3768485260U).FormatWith(JsonTextReader.smethod_16(), c));
					}
					num = this._charPos;
				}
			}
			else
			{
				num = this._charPos;
				this.ProcessCarriageReturn(true);
			}
			IL_0105:
			this._stringReference = new StringReference(this._chars, charPos, num - charPos);
			string text = this._stringReference.ToString();
			this.EatWhitespace(false);
			if (this._chars[this._charPos] != '(')
			{
				throw JsonReaderException.Create(this, <Module>.smethod_25<string>(1498609627U).FormatWith(JsonTextReader.smethod_16(), this._chars[this._charPos]));
			}
			this._charPos++;
			this.ClearRecentString();
			base.SetToken(JsonToken.StartConstructor, text);
		}

		// Token: 0x06001F33 RID: 7987 RVA: 0x0008499C File Offset: 0x00082B9C
		private void ParseNumber()
		{
			this.ShiftBufferIfNeeded();
			char c = this._chars[this._charPos];
			int charPos = this._charPos;
			this.ReadNumberIntoBuffer();
			base.SetPostValueState(true);
			this._stringReference = new StringReference(this._chars, charPos, this._charPos - charPos);
			bool flag = char.IsDigit(c) && this._stringReference.Length == 1;
			bool flag2 = c == '0' && this._stringReference.Length > 1 && this._stringReference.Chars[this._stringReference.StartIndex + 1] != '.' && this._stringReference.Chars[this._stringReference.StartIndex + 1] != 'e' && this._stringReference.Chars[this._stringReference.StartIndex + 1] != 'E';
			object obj;
			JsonToken jsonToken;
			if (this._readType == ReadType.ReadAsInt32)
			{
				if (flag)
				{
					obj = (int)(c - '0');
				}
				else
				{
					if (flag2)
					{
						string text = this._stringReference.ToString();
						try
						{
							int num = (JsonTextReader.smethod_21(text, <Module>.smethod_25<string>(3099351046U), StringComparison.OrdinalIgnoreCase) ? JsonTextReader.smethod_22(text, 16) : JsonTextReader.smethod_22(text, 8));
							obj = num;
							goto IL_018F;
						}
						catch (Exception ex)
						{
							throw JsonReaderException.Create(this, <Module>.smethod_25<string>(2960156140U).FormatWith(JsonTextReader.smethod_16(), text), ex);
						}
					}
					int num2;
					ParseResult parseResult = ConvertUtils.Int32TryParse(this._stringReference.Chars, this._stringReference.StartIndex, this._stringReference.Length, out num2);
					if (parseResult == ParseResult.Success)
					{
						obj = num2;
					}
					else
					{
						if (parseResult == ParseResult.Overflow)
						{
							throw JsonReaderException.Create(this, <Module>.smethod_25<string>(57137904U).FormatWith(JsonTextReader.smethod_16(), this._stringReference.ToString()));
						}
						throw JsonReaderException.Create(this, <Module>.smethod_25<string>(2960156140U).FormatWith(JsonTextReader.smethod_16(), this._stringReference.ToString()));
					}
				}
				IL_018F:
				jsonToken = JsonToken.Integer;
			}
			else if (this._readType == ReadType.ReadAsDecimal)
			{
				if (flag)
				{
					obj = c - 48m;
				}
				else
				{
					if (flag2)
					{
						string text2 = this._stringReference.ToString();
						try
						{
							long num3 = ((!text2.StartsWith(<Module>.smethod_25<string>(3099351046U), StringComparison.OrdinalIgnoreCase)) ? Convert.ToInt64(text2, 8) : Convert.ToInt64(text2, 16));
							obj = Convert.ToDecimal(num3);
							goto IL_02EE;
						}
						catch (Exception ex2)
						{
							throw JsonReaderException.Create(this, <Module>.smethod_26<string>(3367821859U).FormatWith(CultureInfo.InvariantCulture, text2), ex2);
						}
					}
					string text3 = this._stringReference.ToString();
					decimal num4;
					if (!decimal.TryParse(text3, NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite | NumberStyles.AllowLeadingSign | NumberStyles.AllowTrailingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands | NumberStyles.AllowExponent, CultureInfo.InvariantCulture, out num4))
					{
						throw JsonReaderException.Create(this, <Module>.smethod_24<string>(3988004748U).FormatWith(CultureInfo.InvariantCulture, this._stringReference.ToString()));
					}
					obj = num4;
				}
				IL_02EE:
				jsonToken = JsonToken.Float;
			}
			else if (flag)
			{
				obj = (long)((ulong)c - 48UL);
				jsonToken = JsonToken.Integer;
			}
			else if (flag2)
			{
				string text4 = this._stringReference.ToString();
				try
				{
					obj = (text4.StartsWith(<Module>.smethod_26<string>(1891476255U), StringComparison.OrdinalIgnoreCase) ? Convert.ToInt64(text4, 16) : Convert.ToInt64(text4, 8));
				}
				catch (Exception ex3)
				{
					throw JsonReaderException.Create(this, <Module>.smethod_26<string>(2159615287U).FormatWith(CultureInfo.InvariantCulture, text4), ex3);
				}
				jsonToken = JsonToken.Integer;
			}
			else
			{
				long num5;
				ParseResult parseResult2 = ConvertUtils.Int64TryParse(this._stringReference.Chars, this._stringReference.StartIndex, this._stringReference.Length, out num5);
				if (parseResult2 == ParseResult.Success)
				{
					obj = num5;
					jsonToken = JsonToken.Integer;
				}
				else if (parseResult2 == ParseResult.Overflow)
				{
					string text5 = this._stringReference.ToString();
					if (text5.Length > 380)
					{
						throw JsonReaderException.Create(this, <Module>.smethod_24<string>(736166260U).FormatWith(CultureInfo.InvariantCulture, this._stringReference.ToString()));
					}
					obj = JsonTextReader.BigIntegerParse(text5, CultureInfo.InvariantCulture);
					jsonToken = JsonToken.Integer;
				}
				else
				{
					string text6 = this._stringReference.ToString();
					if (this._floatParseHandling == FloatParseHandling.Decimal)
					{
						decimal num6;
						if (!decimal.TryParse(text6, NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite | NumberStyles.AllowLeadingSign | NumberStyles.AllowTrailingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands | NumberStyles.AllowExponent, CultureInfo.InvariantCulture, out num6))
						{
							throw JsonReaderException.Create(this, <Module>.smethod_24<string>(3988004748U).FormatWith(CultureInfo.InvariantCulture, text6));
						}
						obj = num6;
					}
					else
					{
						double num7;
						if (!double.TryParse(text6, NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite | NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands | NumberStyles.AllowExponent, CultureInfo.InvariantCulture, out num7))
						{
							throw JsonReaderException.Create(this, <Module>.smethod_26<string>(2159615287U).FormatWith(CultureInfo.InvariantCulture, text6));
						}
						obj = num7;
					}
					jsonToken = JsonToken.Float;
				}
			}
			this.ClearRecentString();
			base.SetToken(jsonToken, obj, false);
		}

		// Token: 0x06001F34 RID: 7988 RVA: 0x0001A5EB File Offset: 0x000187EB
		private static object BigIntegerParse(string number, CultureInfo culture)
		{
			return BigInteger.Parse(number, culture);
		}

		// Token: 0x06001F35 RID: 7989 RVA: 0x00084EA8 File Offset: 0x000830A8
		private void ParseComment()
		{
			this._charPos++;
			if (!this.EnsureChars(1, false))
			{
				throw JsonReaderException.Create(this, <Module>.smethod_27<string>(1338385684U));
			}
			bool flag;
			if (this._chars[this._charPos] == '*')
			{
				flag = false;
			}
			else
			{
				if (this._chars[this._charPos] != '/')
				{
					throw JsonReaderException.Create(this, <Module>.smethod_24<string>(2469802626U).FormatWith(JsonTextReader.smethod_16(), this._chars[this._charPos]));
				}
				flag = true;
			}
			this._charPos++;
			int charPos = this._charPos;
			bool flag2 = false;
			while (!flag2)
			{
				char c = this._chars[this._charPos];
				if (c <= '\n')
				{
					if (c == '\0')
					{
						if (this._charsUsed != this._charPos)
						{
							this._charPos++;
							continue;
						}
						if (this.ReadData(true) != 0)
						{
							continue;
						}
						if (flag)
						{
							this._stringReference = new StringReference(this._chars, charPos, this._charPos - charPos);
							flag2 = true;
							continue;
						}
						throw JsonReaderException.Create(this, <Module>.smethod_24<string>(2415944065U));
					}
					else if (c == '\n')
					{
						if (flag)
						{
							this._stringReference = new StringReference(this._chars, charPos, this._charPos - charPos);
							flag2 = true;
						}
						this.ProcessLineFeed();
						continue;
					}
				}
				else
				{
					if (c == '\r')
					{
						if (flag)
						{
							this._stringReference = new StringReference(this._chars, charPos, this._charPos - charPos);
							flag2 = true;
						}
						this.ProcessCarriageReturn(true);
						continue;
					}
					if (c == '*')
					{
						this._charPos++;
						if (!flag && this.EnsureChars(0, true) && this._chars[this._charPos] == '/')
						{
							this._stringReference = new StringReference(this._chars, charPos, this._charPos - charPos - 1);
							this._charPos++;
							flag2 = true;
							continue;
						}
						continue;
					}
				}
				this._charPos++;
			}
			base.SetToken(JsonToken.Comment, this._stringReference.ToString());
			this.ClearRecentString();
		}

		// Token: 0x06001F36 RID: 7990 RVA: 0x000850C0 File Offset: 0x000832C0
		private bool MatchValue(string value)
		{
			if (!this.EnsureChars(JsonTextReader.smethod_23(value) - 1, true))
			{
				return false;
			}
			for (int i = 0; i < JsonTextReader.smethod_23(value); i++)
			{
				if (this._chars[this._charPos + i] != JsonTextReader.smethod_24(value, i))
				{
					return false;
				}
			}
			this._charPos += JsonTextReader.smethod_23(value);
			return true;
		}

		// Token: 0x06001F37 RID: 7991 RVA: 0x0001A5F9 File Offset: 0x000187F9
		private bool MatchValueWithTrailingSeparator(string value)
		{
			return this.MatchValue(value) && (!this.EnsureChars(0, false) || this.IsSeparator(this._chars[this._charPos]) || this._chars[this._charPos] == '\0');
		}

		// Token: 0x06001F38 RID: 7992 RVA: 0x00085124 File Offset: 0x00083324
		private bool IsSeparator(char c)
		{
			if (c <= ')')
			{
				switch (c)
				{
				case '\t':
				case '\n':
				case '\r':
					break;
				case '\v':
				case '\f':
					goto IL_0092;
				default:
					if (c != ' ')
					{
						if (c != ')')
						{
							goto IL_0092;
						}
						if (base.CurrentState == JsonReader.State.Constructor || base.CurrentState == JsonReader.State.ConstructorStart)
						{
							return true;
						}
						return false;
					}
					break;
				}
				return true;
			}
			if (c <= '/')
			{
				if (c != ',')
				{
					if (c != '/')
					{
						goto IL_0092;
					}
					if (this.EnsureChars(1, false))
					{
						char c2 = this._chars[this._charPos + 1];
						return c2 == '*' || c2 == '/';
					}
					return false;
				}
			}
			else if (c != ']')
			{
				if (c != '}')
				{
					goto IL_0092;
				}
			}
			return true;
			IL_0092:
			if (char.IsWhiteSpace(c))
			{
				return true;
			}
			return false;
		}

		// Token: 0x06001F39 RID: 7993 RVA: 0x0001A639 File Offset: 0x00018839
		private void ParseTrue()
		{
			if (!this.MatchValueWithTrailingSeparator(JsonConvert.True))
			{
				throw JsonReaderException.Create(this, <Module>.smethod_25<string>(454647832U));
			}
			base.SetToken(JsonToken.Boolean, true);
		}

		// Token: 0x06001F3A RID: 7994 RVA: 0x0001A667 File Offset: 0x00018867
		private void ParseNull()
		{
			if (!this.MatchValueWithTrailingSeparator(JsonConvert.Null))
			{
				throw JsonReaderException.Create(this, <Module>.smethod_25<string>(1011427456U));
			}
			base.SetToken(JsonToken.Null);
		}

		// Token: 0x06001F3B RID: 7995 RVA: 0x0001A68F File Offset: 0x0001888F
		private void ParseUndefined()
		{
			if (!this.MatchValueWithTrailingSeparator(JsonConvert.Undefined))
			{
				throw JsonReaderException.Create(this, <Module>.smethod_24<string>(721431318U));
			}
			base.SetToken(JsonToken.Undefined);
		}

		// Token: 0x06001F3C RID: 7996 RVA: 0x0001A6B7 File Offset: 0x000188B7
		private void ParseFalse()
		{
			if (!this.MatchValueWithTrailingSeparator(JsonConvert.False))
			{
				throw JsonReaderException.Create(this, <Module>.smethod_26<string>(807762805U));
			}
			base.SetToken(JsonToken.Boolean, false);
		}

		// Token: 0x06001F3D RID: 7997 RVA: 0x000851D0 File Offset: 0x000833D0
		private void ParseNumberNegativeInfinity()
		{
			if (this.MatchValueWithTrailingSeparator(JsonConvert.NegativeInfinity))
			{
				for (;;)
				{
					IL_0057:
					int num = 519040669;
					for (;;)
					{
						switch (num ^ 519040668)
						{
						case 0:
							return;
						case 1:
							if (this._floatParseHandling == FloatParseHandling.Decimal)
							{
								goto Block_2;
							}
							goto IL_000F;
						case 3:
							goto IL_000F;
						case 4:
							goto IL_0057;
						}
						goto Block_3;
						IL_000F:
						base.SetToken(JsonToken.Float, double.NegativeInfinity);
						num = 519040668;
					}
				}
				Block_2:
				throw new JsonReaderException(<Module>.smethod_23<string>(1856571684U));
				Block_3:;
			}
			throw JsonReaderException.Create(this, <Module>.smethod_27<string>(306936898U));
		}

		// Token: 0x06001F3E RID: 7998 RVA: 0x0008525C File Offset: 0x0008345C
		private void ParseNumberPositiveInfinity()
		{
			if (!this.MatchValueWithTrailingSeparator(JsonConvert.PositiveInfinity))
			{
				throw JsonReaderException.Create(this, <Module>.smethod_27<string>(3529605255U));
			}
			if (this._floatParseHandling == FloatParseHandling.Decimal)
			{
				throw new JsonReaderException(<Module>.smethod_25<string>(2502421842U));
			}
			base.SetToken(JsonToken.Float, double.PositiveInfinity);
		}

		// Token: 0x06001F3F RID: 7999 RVA: 0x000852B8 File Offset: 0x000834B8
		private void ParseNumberNaN()
		{
			if (this.MatchValueWithTrailingSeparator(JsonConvert.NaN))
			{
				for (;;)
				{
					IL_0057:
					int num = 1697183456;
					for (;;)
					{
						switch (num ^ 1697183457)
						{
						case 0:
							return;
						case 1:
							if (this._floatParseHandling == FloatParseHandling.Decimal)
							{
								goto Block_2;
							}
							goto IL_000F;
						case 3:
							goto IL_000F;
						case 4:
							goto IL_0057;
						}
						goto Block_3;
						IL_000F:
						base.SetToken(JsonToken.Float, double.NaN);
						num = 1697183457;
					}
				}
				Block_2:
				throw new JsonReaderException(<Module>.smethod_26<string>(4283157950U));
				Block_3:;
			}
			throw JsonReaderException.Create(this, <Module>.smethod_23<string>(4081882083U));
		}

		// Token: 0x06001F40 RID: 8000 RVA: 0x0001A6E5 File Offset: 0x000188E5
		public override void Close()
		{
			base.Close();
			if (base.CloseInput && this._reader != null)
			{
				JsonTextReader.smethod_25(this._reader);
			}
			if (this._buffer != null)
			{
				this._buffer.Clear();
			}
		}

		// Token: 0x06001F41 RID: 8001 RVA: 0x0000ED8C File Offset: 0x0000CF8C
		public bool HasLineInfo()
		{
			return true;
		}

		// Token: 0x1700049B RID: 1179
		// (get) Token: 0x06001F42 RID: 8002 RVA: 0x0001A71B File Offset: 0x0001891B
		public int LineNumber
		{
			get
			{
				if (base.CurrentState == JsonReader.State.Start && this.LinePosition == 0)
				{
					return 0;
				}
				return this._lineNumber;
			}
		}

		// Token: 0x1700049C RID: 1180
		// (get) Token: 0x06001F43 RID: 8003 RVA: 0x0001A735 File Offset: 0x00018935
		public int LinePosition
		{
			get
			{
				return this._charPos - this._lineStartPos;
			}
		}

		// Token: 0x06001F44 RID: 8004 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_12(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x06001F45 RID: 8005 RVA: 0x00013254 File Offset: 0x00011454
		static void smethod_13(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Buffer.BlockCopy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x06001F46 RID: 8006 RVA: 0x0000F02D File Offset: 0x0000D22D
		static int smethod_14(int int_0, int int_1)
		{
			return Math.Max(int_0, int_1);
		}

		// Token: 0x06001F47 RID: 8007 RVA: 0x000153DC File Offset: 0x000135DC
		static int smethod_15(TextReader textReader_0, char[] char_0, int int_0, int int_1)
		{
			return textReader_0.Read(char_0, int_0, int_1);
		}

		// Token: 0x06001F48 RID: 8008 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_16()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001F49 RID: 8009 RVA: 0x0000EE96 File Offset: 0x0000D096
		static string smethod_17(object object_0, object object_1)
		{
			return object_0 + object_1;
		}

		// Token: 0x06001F4A RID: 8010 RVA: 0x00016A3D File Offset: 0x00014C3D
		static string smethod_18(char[] char_0, int int_0, int int_1)
		{
			return new string(char_0, int_0, int_1);
		}

		// Token: 0x06001F4B RID: 8011 RVA: 0x0000EAE1 File Offset: 0x0000CCE1
		static NumberFormatInfo smethod_19()
		{
			return NumberFormatInfo.InvariantInfo;
		}

		// Token: 0x06001F4C RID: 8012 RVA: 0x000100CF File Offset: 0x0000E2CF
		static char smethod_20(int int_0)
		{
			return Convert.ToChar(int_0);
		}

		// Token: 0x06001F4D RID: 8013 RVA: 0x0000F8C5 File Offset: 0x0000DAC5
		static bool smethod_21(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.StartsWith(string_1, stringComparison_0);
		}

		// Token: 0x06001F4E RID: 8014 RVA: 0x0001A744 File Offset: 0x00018944
		static int smethod_22(string string_0, int int_0)
		{
			return Convert.ToInt32(string_0, int_0);
		}

		// Token: 0x06001F4F RID: 8015 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_23(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06001F50 RID: 8016 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_24(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x06001F51 RID: 8017 RVA: 0x0001A74D File Offset: 0x0001894D
		static void smethod_25(TextReader textReader_0)
		{
			textReader_0.Close();
		}

		// Token: 0x04000B8F RID: 2959
		private const char UnicodeReplacementChar = '\ufffd';

		// Token: 0x04000B90 RID: 2960
		private const int MaximumJavascriptIntegerCharacterLength = 380;

		// Token: 0x04000B91 RID: 2961
		private readonly TextReader _reader;

		// Token: 0x04000B92 RID: 2962
		private char[] _chars;

		// Token: 0x04000B93 RID: 2963
		private int _charsUsed;

		// Token: 0x04000B94 RID: 2964
		private int _charPos;

		// Token: 0x04000B95 RID: 2965
		private int _lineStartPos;

		// Token: 0x04000B96 RID: 2966
		private int _lineNumber;

		// Token: 0x04000B97 RID: 2967
		private bool _isEndOfFile;

		// Token: 0x04000B98 RID: 2968
		private StringBuffer _buffer;

		// Token: 0x04000B99 RID: 2969
		private StringReference _stringReference;

		// Token: 0x04000B9A RID: 2970
		internal PropertyNameTable NameTable;
	}
}
