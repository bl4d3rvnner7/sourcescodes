﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001B3 RID: 435
	public enum FloatParseHandling
	{
		// Token: 0x040009C3 RID: 2499
		Double,
		// Token: 0x040009C4 RID: 2500
		Decimal
	}
}
