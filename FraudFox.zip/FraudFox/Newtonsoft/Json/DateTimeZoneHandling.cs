﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001B9 RID: 441
	public enum DateTimeZoneHandling
	{
		// Token: 0x040009D6 RID: 2518
		Local,
		// Token: 0x040009D7 RID: 2519
		Utc,
		// Token: 0x040009D8 RID: 2520
		Unspecified,
		// Token: 0x040009D9 RID: 2521
		RoundtripKind
	}
}
