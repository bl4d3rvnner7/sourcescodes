﻿using System;
using System.Collections.Generic;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002B8 RID: 696
	internal class BidirectionalDictionary<TFirst, TSecond>
	{
		// Token: 0x060027C6 RID: 10182 RVA: 0x0001E9FB File Offset: 0x0001CBFB
		public BidirectionalDictionary()
			: this(EqualityComparer<TFirst>.Default, EqualityComparer<TSecond>.Default)
		{
		}

		// Token: 0x060027C7 RID: 10183 RVA: 0x0001EA0D File Offset: 0x0001CC0D
		public BidirectionalDictionary(IEqualityComparer<TFirst> firstEqualityComparer, IEqualityComparer<TSecond> secondEqualityComparer)
			: this(firstEqualityComparer, secondEqualityComparer, <Module>.smethod_26<string>(946575105U), <Module>.smethod_27<string>(1689621187U))
		{
		}

		// Token: 0x060027C8 RID: 10184 RVA: 0x0001EA2B File Offset: 0x0001CC2B
		public BidirectionalDictionary(IEqualityComparer<TFirst> firstEqualityComparer, IEqualityComparer<TSecond> secondEqualityComparer, string duplicateFirstErrorMessage, string duplicateSecondErrorMessage)
		{
			this._firstToSecond = new Dictionary<TFirst, TSecond>(firstEqualityComparer);
			this._secondToFirst = new Dictionary<TSecond, TFirst>(secondEqualityComparer);
			this._duplicateFirstErrorMessage = duplicateFirstErrorMessage;
			this._duplicateSecondErrorMessage = duplicateSecondErrorMessage;
		}

		// Token: 0x060027C9 RID: 10185 RVA: 0x00097E54 File Offset: 0x00096054
		public void Set(TFirst first, TSecond second)
		{
			TSecond tsecond;
			if (this._firstToSecond.TryGetValue(first, out tsecond) && !tsecond.Equals(second))
			{
				throw BidirectionalDictionary<TFirst, TSecond>.smethod_1(this._duplicateFirstErrorMessage.FormatWith(BidirectionalDictionary<TFirst, TSecond>.smethod_0(), first));
			}
			TFirst tfirst;
			if (this._secondToFirst.TryGetValue(second, out tfirst) && !tfirst.Equals(first))
			{
				throw BidirectionalDictionary<TFirst, TSecond>.smethod_1(this._duplicateSecondErrorMessage.FormatWith(BidirectionalDictionary<TFirst, TSecond>.smethod_0(), second));
			}
			this._firstToSecond.Add(first, second);
			this._secondToFirst.Add(second, first);
		}

		// Token: 0x060027CA RID: 10186 RVA: 0x0001EA5A File Offset: 0x0001CC5A
		public bool TryGetByFirst(TFirst first, out TSecond second)
		{
			return this._firstToSecond.TryGetValue(first, out second);
		}

		// Token: 0x060027CB RID: 10187 RVA: 0x0001EA69 File Offset: 0x0001CC69
		public bool TryGetBySecond(TSecond second, out TFirst first)
		{
			return this._secondToFirst.TryGetValue(second, out first);
		}

		// Token: 0x04000DEF RID: 3567
		private readonly IDictionary<TFirst, TSecond> _firstToSecond;

		// Token: 0x04000DF0 RID: 3568
		private readonly IDictionary<TSecond, TFirst> _secondToFirst;

		// Token: 0x04000DF1 RID: 3569
		private readonly string _duplicateFirstErrorMessage;

		// Token: 0x04000DF2 RID: 3570
		private readonly string _duplicateSecondErrorMessage;
	}
}
