﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002B0 RID: 688
	internal class ReflectionMember
	{
		// Token: 0x170005D1 RID: 1489
		// (get) Token: 0x0600279B RID: 10139 RVA: 0x0001E8BA File Offset: 0x0001CABA
		// (set) Token: 0x0600279C RID: 10140 RVA: 0x0001E8C2 File Offset: 0x0001CAC2
		public Type MemberType { get; set; }

		// Token: 0x170005D2 RID: 1490
		// (get) Token: 0x0600279D RID: 10141 RVA: 0x0001E8CB File Offset: 0x0001CACB
		// (set) Token: 0x0600279E RID: 10142 RVA: 0x0001E8D3 File Offset: 0x0001CAD3
		public Func<object, object> Getter { get; set; }

		// Token: 0x170005D3 RID: 1491
		// (get) Token: 0x0600279F RID: 10143 RVA: 0x0001E8DC File Offset: 0x0001CADC
		// (set) Token: 0x060027A0 RID: 10144 RVA: 0x0001E8E4 File Offset: 0x0001CAE4
		public Action<object, object> Setter { get; set; }
	}
}
