﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x02000284 RID: 644
	internal sealed class DynamicProxyMetaObject<T> : DynamicMetaObject
	{
		// Token: 0x0600262F RID: 9775 RVA: 0x0001E03D File Offset: 0x0001C23D
		internal DynamicProxyMetaObject(Expression expression, T value, DynamicProxy<T> proxy, bool dontFallbackFirst)
			: base(expression, BindingRestrictions.Empty, value)
		{
			this._proxy = proxy;
			this._dontFallbackFirst = dontFallbackFirst;
		}

		// Token: 0x170005C4 RID: 1476
		// (get) Token: 0x06002630 RID: 9776 RVA: 0x0001E060 File Offset: 0x0001C260
		private new T Value
		{
			get
			{
				return (T)((object)DynamicProxyMetaObject<T>.smethod_0(this));
			}
		}

		// Token: 0x06002631 RID: 9777 RVA: 0x0001E06D File Offset: 0x0001C26D
		private bool IsOverridden(string method)
		{
			return ReflectionUtils.IsMethodOverridden(DynamicProxyMetaObject<T>.smethod_1(this._proxy), DynamicProxyMetaObject<T>.smethod_2(typeof(DynamicProxy<T>).TypeHandle), method);
		}

		// Token: 0x06002632 RID: 9778 RVA: 0x0009528C File Offset: 0x0009348C
		public override DynamicMetaObject BindGetMember(GetMemberBinder binder)
		{
			if (!this.IsOverridden(<Module>.smethod_24<string>(575099256U)))
			{
				return this.method_0(binder);
			}
			return this.CallMethodWithResult(<Module>.smethod_24<string>(575099256U), binder, DynamicProxyMetaObject<T>.NoArgs, (DynamicMetaObject e) => DynamicProxyMetaObject<T>.<>c__DisplayClass1.smethod_0(binder, this, e), null);
		}

		// Token: 0x06002633 RID: 9779 RVA: 0x000952F4 File Offset: 0x000934F4
		public override DynamicMetaObject BindSetMember(SetMemberBinder binder, DynamicMetaObject value)
		{
			if (!this.IsOverridden(<Module>.smethod_26<string>(1494010491U)))
			{
				return this.method_1(binder, value);
			}
			return this.CallMethodReturnLast(<Module>.smethod_27<string>(1561748561U), binder, DynamicProxyMetaObject<T>.GetArgs(new DynamicMetaObject[] { value }), (DynamicMetaObject e) => DynamicProxyMetaObject<T>.<>c__DisplayClass4.smethod_0(binder, this, value, e));
		}

		// Token: 0x06002634 RID: 9780 RVA: 0x00095380 File Offset: 0x00093580
		public override DynamicMetaObject BindDeleteMember(DeleteMemberBinder binder)
		{
			if (!this.IsOverridden(<Module>.smethod_27<string>(1002288245U)))
			{
				return this.method_2(binder);
			}
			return this.CallMethodNoResult(<Module>.smethod_25<string>(789276142U), binder, DynamicProxyMetaObject<T>.NoArgs, (DynamicMetaObject e) => DynamicProxyMetaObject<T>.<>c__DisplayClass7.smethod_0(binder, this, e));
		}

		// Token: 0x06002635 RID: 9781 RVA: 0x000953E8 File Offset: 0x000935E8
		public override DynamicMetaObject BindConvert(ConvertBinder binder)
		{
			if (!this.IsOverridden(<Module>.smethod_26<string>(3655858730U)))
			{
				return this.method_3(binder);
			}
			return this.CallMethodWithResult(<Module>.smethod_25<string>(441288877U), binder, DynamicProxyMetaObject<T>.NoArgs, (DynamicMetaObject e) => DynamicProxyMetaObject<T>.<>c__DisplayClassa.smethod_0(binder, this, e), null);
		}

		// Token: 0x06002636 RID: 9782 RVA: 0x00095450 File Offset: 0x00093650
		public override DynamicMetaObject BindInvokeMember(InvokeMemberBinder binder, DynamicMetaObject[] args)
		{
			if (!this.IsOverridden(<Module>.smethod_27<string>(675936394U)))
			{
				return this.method_4(binder, args);
			}
			DynamicProxyMetaObject<T>.Fallback fallback = (DynamicMetaObject e) => DynamicProxyMetaObject<T>.<>c__DisplayClasse.smethod_0(binder, this, args, e);
			DynamicMetaObject dynamicMetaObject = this.BuildCallMethodWithResult(<Module>.smethod_23<string>(1175767418U), binder, DynamicProxyMetaObject<T>.GetArgArray(args), this.BuildCallMethodWithResult(<Module>.smethod_26<string>(55970463U), new DynamicProxyMetaObject<T>.GetBinderAdapter(binder), DynamicProxyMetaObject<T>.NoArgs, fallback(null), (DynamicMetaObject e) => DynamicProxyMetaObject<T>.<>c__DisplayClasse.smethod_1(binder, e, args, null)), null);
			if (!this._dontFallbackFirst)
			{
				return fallback(dynamicMetaObject);
			}
			return dynamicMetaObject;
		}

		// Token: 0x06002637 RID: 9783 RVA: 0x00095514 File Offset: 0x00093714
		public override DynamicMetaObject BindCreateInstance(CreateInstanceBinder binder, DynamicMetaObject[] args)
		{
			if (!this.IsOverridden(<Module>.smethod_25<string>(2042030296U)))
			{
				return this.method_5(binder, args);
			}
			return this.CallMethodWithResult(<Module>.smethod_26<string>(2960779701U), binder, DynamicProxyMetaObject<T>.GetArgArray(args), (DynamicMetaObject e) => DynamicProxyMetaObject<T>.<>c__DisplayClass11.smethod_0(binder, this, args, e), null);
		}

		// Token: 0x06002638 RID: 9784 RVA: 0x00095590 File Offset: 0x00093790
		public override DynamicMetaObject BindInvoke(InvokeBinder binder, DynamicMetaObject[] args)
		{
			if (!this.IsOverridden(<Module>.smethod_27<string>(442827929U)))
			{
				return this.method_6(binder, args);
			}
			return this.CallMethodWithResult(<Module>.smethod_25<string>(1624445578U), binder, DynamicProxyMetaObject<T>.GetArgArray(args), (DynamicMetaObject e) => DynamicProxyMetaObject<T>.<>c__DisplayClass14.smethod_0(binder, this, args, e), null);
		}

		// Token: 0x06002639 RID: 9785 RVA: 0x0009560C File Offset: 0x0009380C
		public override DynamicMetaObject BindBinaryOperation(BinaryOperationBinder binder, DynamicMetaObject arg)
		{
			if (!this.IsOverridden(<Module>.smethod_24<string>(452647192U)))
			{
				return this.method_7(binder, arg);
			}
			return this.CallMethodWithResult(<Module>.smethod_23<string>(2123362053U), binder, DynamicProxyMetaObject<T>.GetArgs(new DynamicMetaObject[] { arg }), (DynamicMetaObject e) => DynamicProxyMetaObject<T>.<>c__DisplayClass17.smethod_0(binder, this, arg, e), null);
		}

		// Token: 0x0600263A RID: 9786 RVA: 0x00095698 File Offset: 0x00093898
		public override DynamicMetaObject BindUnaryOperation(UnaryOperationBinder binder)
		{
			if (!this.IsOverridden(<Module>.smethod_23<string>(2053246055U)))
			{
				return this.method_8(binder);
			}
			return this.CallMethodWithResult(<Module>.smethod_24<string>(2059258966U), binder, DynamicProxyMetaObject<T>.NoArgs, (DynamicMetaObject e) => DynamicProxyMetaObject<T>.<>c__DisplayClass1a.smethod_0(binder, this, e), null);
		}

		// Token: 0x0600263B RID: 9787 RVA: 0x00095700 File Offset: 0x00093900
		public override DynamicMetaObject BindGetIndex(GetIndexBinder binder, DynamicMetaObject[] indexes)
		{
			if (!this.IsOverridden(<Module>.smethod_25<string>(2419465434U)))
			{
				return this.method_9(binder, indexes);
			}
			return this.CallMethodWithResult(<Module>.smethod_24<string>(2872218588U), binder, DynamicProxyMetaObject<T>.GetArgArray(indexes), (DynamicMetaObject e) => DynamicProxyMetaObject<T>.<>c__DisplayClass1d.smethod_0(binder, this, indexes, e), null);
		}

		// Token: 0x0600263C RID: 9788 RVA: 0x0009577C File Offset: 0x0009397C
		public override DynamicMetaObject BindSetIndex(SetIndexBinder binder, DynamicMetaObject[] indexes, DynamicMetaObject value)
		{
			if (!this.IsOverridden(<Module>.smethod_23<string>(3368590069U)))
			{
				return this.method_10(binder, indexes, value);
			}
			return this.CallMethodReturnLast(<Module>.smethod_27<string>(314056557U), binder, DynamicProxyMetaObject<T>.GetArgArray(indexes, value), (DynamicMetaObject e) => DynamicProxyMetaObject<T>.<>c__DisplayClass20.smethod_0(binder, this, indexes, value, e));
		}

		// Token: 0x0600263D RID: 9789 RVA: 0x0009580C File Offset: 0x00093A0C
		public override DynamicMetaObject BindDeleteIndex(DeleteIndexBinder binder, DynamicMetaObject[] indexes)
		{
			if (!this.IsOverridden(<Module>.smethod_25<string>(2976245058U)))
			{
				return this.method_11(binder, indexes);
			}
			return this.CallMethodNoResult(<Module>.smethod_27<string>(500543329U), binder, DynamicProxyMetaObject<T>.GetArgArray(indexes), (DynamicMetaObject e) => DynamicProxyMetaObject<T>.<>c__DisplayClass23.smethod_0(binder, this, indexes, e));
		}

		// Token: 0x0600263E RID: 9790 RVA: 0x0001E08A File Offset: 0x0001C28A
		private static Expression[] GetArgs(params DynamicMetaObject[] args)
		{
			return args.Select((DynamicMetaObject arg) => DynamicProxyMetaObject<T>.smethod_5(DynamicProxyMetaObject<T>.smethod_4(arg), DynamicProxyMetaObject<T>.smethod_2(typeof(object).TypeHandle))).ToArray<UnaryExpression>();
		}

		// Token: 0x0600263F RID: 9791 RVA: 0x00095888 File Offset: 0x00093A88
		private static Expression[] GetArgArray(DynamicMetaObject[] args)
		{
			return new NewArrayExpression[] { DynamicProxyMetaObject<T>.smethod_3(DynamicProxyMetaObject<T>.smethod_2(typeof(object).TypeHandle), DynamicProxyMetaObject<T>.GetArgs(args)) };
		}

		// Token: 0x06002640 RID: 9792 RVA: 0x000958BC File Offset: 0x00093ABC
		private static Expression[] GetArgArray(DynamicMetaObject[] args, DynamicMetaObject value)
		{
			return new Expression[]
			{
				DynamicProxyMetaObject<T>.smethod_3(DynamicProxyMetaObject<T>.smethod_2(typeof(object).TypeHandle), DynamicProxyMetaObject<T>.GetArgs(args)),
				DynamicProxyMetaObject<T>.smethod_5(DynamicProxyMetaObject<T>.smethod_4(value), DynamicProxyMetaObject<T>.smethod_2(typeof(object).TypeHandle))
			};
		}

		// Token: 0x06002641 RID: 9793 RVA: 0x0009590C File Offset: 0x00093B0C
		private static ConstantExpression Constant(DynamicMetaObjectBinder binder)
		{
			Type type = DynamicProxyMetaObject<T>.smethod_1(binder);
			while (!type.IsVisible())
			{
				type = type.BaseType();
			}
			return DynamicProxyMetaObject<T>.smethod_6(binder, type);
		}

		// Token: 0x06002642 RID: 9794 RVA: 0x00095938 File Offset: 0x00093B38
		private DynamicMetaObject CallMethodWithResult(string methodName, DynamicMetaObjectBinder binder, Expression[] args, DynamicProxyMetaObject<T>.Fallback fallback, DynamicProxyMetaObject<T>.Fallback fallbackInvoke = null)
		{
			DynamicMetaObject dynamicMetaObject = fallback(null);
			DynamicMetaObject dynamicMetaObject2 = this.BuildCallMethodWithResult(methodName, binder, args, dynamicMetaObject, fallbackInvoke);
			if (!this._dontFallbackFirst)
			{
				return fallback(dynamicMetaObject2);
			}
			return dynamicMetaObject2;
		}

		// Token: 0x06002643 RID: 9795 RVA: 0x00095970 File Offset: 0x00093B70
		private DynamicMetaObject BuildCallMethodWithResult(string methodName, DynamicMetaObjectBinder binder, Expression[] args, DynamicMetaObject fallbackResult, DynamicProxyMetaObject<T>.Fallback fallbackInvoke)
		{
			ParameterExpression parameterExpression = DynamicProxyMetaObject<T>.smethod_7(DynamicProxyMetaObject<T>.smethod_2(typeof(object).TypeHandle), null);
			IList<Expression> list = new List<Expression>();
			list.Add(DynamicProxyMetaObject<T>.smethod_5(DynamicProxyMetaObject<T>.smethod_8(this), DynamicProxyMetaObject<T>.smethod_2(typeof(T).TypeHandle)));
			list.Add(DynamicProxyMetaObject<T>.Constant(binder));
			list.AddRange(args);
			list.Add(parameterExpression);
			DynamicMetaObject dynamicMetaObject = DynamicProxyMetaObject<T>.smethod_9(parameterExpression, BindingRestrictions.Empty);
			if (DynamicProxyMetaObject<T>.smethod_11(DynamicProxyMetaObject<T>.smethod_10(binder), DynamicProxyMetaObject<T>.smethod_2(typeof(object).TypeHandle)))
			{
				UnaryExpression unaryExpression = DynamicProxyMetaObject<T>.smethod_5(DynamicProxyMetaObject<T>.smethod_4(dynamicMetaObject), DynamicProxyMetaObject<T>.smethod_10(binder));
				dynamicMetaObject = DynamicProxyMetaObject<T>.smethod_9(unaryExpression, DynamicProxyMetaObject<T>.smethod_12(dynamicMetaObject));
			}
			if (fallbackInvoke != null)
			{
				dynamicMetaObject = fallbackInvoke(dynamicMetaObject);
			}
			return DynamicProxyMetaObject<T>.smethod_9(DynamicProxyMetaObject<T>.smethod_16(new ParameterExpression[] { parameterExpression }, new Expression[] { DynamicProxyMetaObject<T>.smethod_15(DynamicProxyMetaObject<T>.smethod_14(DynamicProxyMetaObject<T>.smethod_13(this._proxy), DynamicProxyMetaObject<T>.smethod_2(typeof(DynamicProxy<T>).TypeHandle).method_12(methodName), list), DynamicProxyMetaObject<T>.smethod_4(dynamicMetaObject), DynamicProxyMetaObject<T>.smethod_4(fallbackResult), DynamicProxyMetaObject<T>.smethod_10(binder)) }), DynamicProxyMetaObject<T>.smethod_17(DynamicProxyMetaObject<T>.smethod_17(this.GetRestrictions(), DynamicProxyMetaObject<T>.smethod_12(dynamicMetaObject)), DynamicProxyMetaObject<T>.smethod_12(fallbackResult)));
		}

		// Token: 0x06002644 RID: 9796 RVA: 0x00095AA4 File Offset: 0x00093CA4
		private DynamicMetaObject CallMethodReturnLast(string methodName, DynamicMetaObjectBinder binder, Expression[] args, DynamicProxyMetaObject<T>.Fallback fallback)
		{
			DynamicMetaObject dynamicMetaObject = fallback(null);
			ParameterExpression parameterExpression = DynamicProxyMetaObject<T>.smethod_7(DynamicProxyMetaObject<T>.smethod_2(typeof(object).TypeHandle), null);
			IList<Expression> list = new List<Expression>();
			list.Add(DynamicProxyMetaObject<T>.smethod_5(DynamicProxyMetaObject<T>.smethod_8(this), DynamicProxyMetaObject<T>.smethod_2(typeof(T).TypeHandle)));
			list.Add(DynamicProxyMetaObject<T>.Constant(binder));
			list.AddRange(args);
			list[args.Length + 1] = DynamicProxyMetaObject<T>.smethod_18(parameterExpression, list[args.Length + 1]);
			DynamicMetaObject dynamicMetaObject2 = DynamicProxyMetaObject<T>.smethod_9(DynamicProxyMetaObject<T>.smethod_16(new ParameterExpression[] { parameterExpression }, new Expression[] { DynamicProxyMetaObject<T>.smethod_15(DynamicProxyMetaObject<T>.smethod_14(DynamicProxyMetaObject<T>.smethod_13(this._proxy), DynamicProxyMetaObject<T>.smethod_2(typeof(DynamicProxy<T>).TypeHandle).method_12(methodName), list), parameterExpression, DynamicProxyMetaObject<T>.smethod_4(dynamicMetaObject), DynamicProxyMetaObject<T>.smethod_2(typeof(object).TypeHandle)) }), DynamicProxyMetaObject<T>.smethod_17(this.GetRestrictions(), DynamicProxyMetaObject<T>.smethod_12(dynamicMetaObject)));
			if (!this._dontFallbackFirst)
			{
				return fallback(dynamicMetaObject2);
			}
			return dynamicMetaObject2;
		}

		// Token: 0x06002645 RID: 9797 RVA: 0x00095BA8 File Offset: 0x00093DA8
		private DynamicMetaObject CallMethodNoResult(string methodName, DynamicMetaObjectBinder binder, Expression[] args, DynamicProxyMetaObject<T>.Fallback fallback)
		{
			DynamicMetaObject dynamicMetaObject = fallback(null);
			IList<Expression> list = new List<Expression>();
			list.Add(DynamicProxyMetaObject<T>.smethod_5(DynamicProxyMetaObject<T>.smethod_8(this), DynamicProxyMetaObject<T>.smethod_2(typeof(T).TypeHandle)));
			list.Add(DynamicProxyMetaObject<T>.Constant(binder));
			list.AddRange(args);
			DynamicMetaObject dynamicMetaObject2 = DynamicProxyMetaObject<T>.smethod_9(DynamicProxyMetaObject<T>.smethod_15(DynamicProxyMetaObject<T>.smethod_14(DynamicProxyMetaObject<T>.smethod_13(this._proxy), DynamicProxyMetaObject<T>.smethod_2(typeof(DynamicProxy<T>).TypeHandle).method_12(methodName), list), DynamicProxyMetaObject<T>.smethod_19(), DynamicProxyMetaObject<T>.smethod_4(dynamicMetaObject), DynamicProxyMetaObject<T>.smethod_2(typeof(void).TypeHandle)), DynamicProxyMetaObject<T>.smethod_17(this.GetRestrictions(), DynamicProxyMetaObject<T>.smethod_12(dynamicMetaObject)));
			if (!this._dontFallbackFirst)
			{
				return fallback(dynamicMetaObject2);
			}
			return dynamicMetaObject2;
		}

		// Token: 0x06002646 RID: 9798 RVA: 0x0001E0B4 File Offset: 0x0001C2B4
		private BindingRestrictions GetRestrictions()
		{
			if (this.Value == null && DynamicProxyMetaObject<T>.smethod_20(this))
			{
				return DynamicProxyMetaObject<T>.smethod_23(DynamicProxyMetaObject<T>.smethod_8(this), null);
			}
			return DynamicProxyMetaObject<T>.smethod_22(DynamicProxyMetaObject<T>.smethod_8(this), DynamicProxyMetaObject<T>.smethod_21(this));
		}

		// Token: 0x06002647 RID: 9799 RVA: 0x0001E0E9 File Offset: 0x0001C2E9
		public override IEnumerable<string> GetDynamicMemberNames()
		{
			return this._proxy.GetDynamicMemberNames(this.Value);
		}

		// Token: 0x0600264A RID: 9802 RVA: 0x0001E120 File Offset: 0x0001C320
		DynamicMetaObject method_0(GetMemberBinder getMemberBinder_0)
		{
			return base.BindGetMember(getMemberBinder_0);
		}

		// Token: 0x0600264B RID: 9803 RVA: 0x0001E129 File Offset: 0x0001C329
		DynamicMetaObject method_1(SetMemberBinder setMemberBinder_0, DynamicMetaObject dynamicMetaObject_0)
		{
			return base.BindSetMember(setMemberBinder_0, dynamicMetaObject_0);
		}

		// Token: 0x0600264C RID: 9804 RVA: 0x0001E133 File Offset: 0x0001C333
		DynamicMetaObject method_2(DeleteMemberBinder deleteMemberBinder_0)
		{
			return base.BindDeleteMember(deleteMemberBinder_0);
		}

		// Token: 0x0600264D RID: 9805 RVA: 0x0001E13C File Offset: 0x0001C33C
		DynamicMetaObject method_3(ConvertBinder convertBinder_0)
		{
			return base.BindConvert(convertBinder_0);
		}

		// Token: 0x0600264E RID: 9806 RVA: 0x0001E145 File Offset: 0x0001C345
		DynamicMetaObject method_4(InvokeMemberBinder invokeMemberBinder_0, DynamicMetaObject[] dynamicMetaObject_0)
		{
			return base.BindInvokeMember(invokeMemberBinder_0, dynamicMetaObject_0);
		}

		// Token: 0x0600264F RID: 9807 RVA: 0x0001E14F File Offset: 0x0001C34F
		DynamicMetaObject method_5(CreateInstanceBinder createInstanceBinder_0, DynamicMetaObject[] dynamicMetaObject_0)
		{
			return base.BindCreateInstance(createInstanceBinder_0, dynamicMetaObject_0);
		}

		// Token: 0x06002650 RID: 9808 RVA: 0x0001E159 File Offset: 0x0001C359
		DynamicMetaObject method_6(InvokeBinder invokeBinder_0, DynamicMetaObject[] dynamicMetaObject_0)
		{
			return base.BindInvoke(invokeBinder_0, dynamicMetaObject_0);
		}

		// Token: 0x06002651 RID: 9809 RVA: 0x0001E163 File Offset: 0x0001C363
		DynamicMetaObject method_7(BinaryOperationBinder binaryOperationBinder_0, DynamicMetaObject dynamicMetaObject_0)
		{
			return base.BindBinaryOperation(binaryOperationBinder_0, dynamicMetaObject_0);
		}

		// Token: 0x06002652 RID: 9810 RVA: 0x0001E16D File Offset: 0x0001C36D
		DynamicMetaObject method_8(UnaryOperationBinder unaryOperationBinder_0)
		{
			return base.BindUnaryOperation(unaryOperationBinder_0);
		}

		// Token: 0x06002653 RID: 9811 RVA: 0x0001E176 File Offset: 0x0001C376
		DynamicMetaObject method_9(GetIndexBinder getIndexBinder_0, DynamicMetaObject[] dynamicMetaObject_0)
		{
			return base.BindGetIndex(getIndexBinder_0, dynamicMetaObject_0);
		}

		// Token: 0x06002654 RID: 9812 RVA: 0x0001E180 File Offset: 0x0001C380
		DynamicMetaObject method_10(SetIndexBinder setIndexBinder_0, DynamicMetaObject[] dynamicMetaObject_0, DynamicMetaObject dynamicMetaObject_1)
		{
			return base.BindSetIndex(setIndexBinder_0, dynamicMetaObject_0, dynamicMetaObject_1);
		}

		// Token: 0x06002655 RID: 9813 RVA: 0x0001E18B File Offset: 0x0001C38B
		DynamicMetaObject method_11(DeleteIndexBinder deleteIndexBinder_0, DynamicMetaObject[] dynamicMetaObject_0)
		{
			return base.BindDeleteIndex(deleteIndexBinder_0, dynamicMetaObject_0);
		}

		// Token: 0x06002656 RID: 9814 RVA: 0x0001E195 File Offset: 0x0001C395
		MethodInfo method_12(string string_0)
		{
			return base.GetMethod(string_0);
		}

		// Token: 0x04000D79 RID: 3449
		private readonly DynamicProxy<T> _proxy;

		// Token: 0x04000D7A RID: 3450
		private readonly bool _dontFallbackFirst;

		// Token: 0x04000D7B RID: 3451
		private static readonly Expression[] NoArgs = new Expression[0];

		// Token: 0x02000285 RID: 645
		// (Invoke) Token: 0x06002658 RID: 9816
		private delegate DynamicMetaObject Fallback(DynamicMetaObject errorSuggestion);

		// Token: 0x02000286 RID: 646
		private sealed class GetBinderAdapter : GetMemberBinder
		{
			// Token: 0x0600265B RID: 9819 RVA: 0x0001E19E File Offset: 0x0001C39E
			internal GetBinderAdapter(InvokeMemberBinder binder)
				: base(DynamicProxyMetaObject<T>.GetBinderAdapter.smethod_0(binder), DynamicProxyMetaObject<T>.GetBinderAdapter.smethod_1(binder))
			{
			}

			// Token: 0x0600265C RID: 9820 RVA: 0x0001E1B2 File Offset: 0x0001C3B2
			public override DynamicMetaObject FallbackGetMember(DynamicMetaObject target, DynamicMetaObject errorSuggestion)
			{
				throw DynamicProxyMetaObject<T>.GetBinderAdapter.smethod_2();
			}
		}
	}
}
