﻿using System;
using System.Globalization;
using System.Reflection;
using Newtonsoft.Json.Serialization;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x02000298 RID: 664
	internal abstract class ReflectionDelegateFactory
	{
		// Token: 0x060026A6 RID: 9894 RVA: 0x00095FEC File Offset: 0x000941EC
		public Func<T, object> CreateGet<T>(MemberInfo memberInfo)
		{
			PropertyInfo propertyInfo = memberInfo as PropertyInfo;
			if (ReflectionDelegateFactory.smethod_0(propertyInfo, null))
			{
				return this.CreateGet<T>(propertyInfo);
			}
			FieldInfo fieldInfo = memberInfo as FieldInfo;
			if (ReflectionDelegateFactory.smethod_1(fieldInfo, null))
			{
				return this.CreateGet<T>(fieldInfo);
			}
			throw ReflectionDelegateFactory.smethod_3(<Module>.smethod_24<string>(2137506204U).FormatWith(ReflectionDelegateFactory.smethod_2(), memberInfo));
		}

		// Token: 0x060026A7 RID: 9895 RVA: 0x00096044 File Offset: 0x00094244
		public Action<T, object> CreateSet<T>(MemberInfo memberInfo)
		{
			PropertyInfo propertyInfo = memberInfo as PropertyInfo;
			if (ReflectionDelegateFactory.smethod_0(propertyInfo, null))
			{
				return this.CreateSet<T>(propertyInfo);
			}
			FieldInfo fieldInfo = memberInfo as FieldInfo;
			if (!ReflectionDelegateFactory.smethod_1(fieldInfo, null))
			{
				throw ReflectionDelegateFactory.smethod_3(<Module>.smethod_23<string>(2109688430U).FormatWith(ReflectionDelegateFactory.smethod_2(), memberInfo));
			}
			return this.CreateSet<T>(fieldInfo);
		}

		// Token: 0x060026A8 RID: 9896
		public abstract MethodCall<T, object> CreateMethodCall<T>(MethodBase method);

		// Token: 0x060026A9 RID: 9897
		public abstract ObjectConstructor<object> CreateParametrizedConstructor(MethodBase method);

		// Token: 0x060026AA RID: 9898
		public abstract Func<T> CreateDefaultConstructor<T>(Type type);

		// Token: 0x060026AB RID: 9899
		public abstract Func<T, object> CreateGet<T>(PropertyInfo propertyInfo);

		// Token: 0x060026AC RID: 9900
		public abstract Func<T, object> CreateGet<T>(FieldInfo fieldInfo);

		// Token: 0x060026AD RID: 9901
		public abstract Action<T, object> CreateSet<T>(FieldInfo fieldInfo);

		// Token: 0x060026AE RID: 9902
		public abstract Action<T, object> CreateSet<T>(PropertyInfo propertyInfo);

		// Token: 0x060026B0 RID: 9904 RVA: 0x0001CA1E File Offset: 0x0001AC1E
		static bool smethod_0(PropertyInfo propertyInfo_0, PropertyInfo propertyInfo_1)
		{
			return propertyInfo_0 != propertyInfo_1;
		}

		// Token: 0x060026B1 RID: 9905 RVA: 0x0001CA0D File Offset: 0x0001AC0D
		static bool smethod_1(FieldInfo fieldInfo_0, FieldInfo fieldInfo_1)
		{
			return fieldInfo_0 != fieldInfo_1;
		}

		// Token: 0x060026B2 RID: 9906 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_2()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060026B3 RID: 9907 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_3(string string_0)
		{
			return new Exception(string_0);
		}
	}
}
