﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020001E7 RID: 487
	internal enum ParserTimeZone
	{
		// Token: 0x04000A9B RID: 2715
		Unspecified,
		// Token: 0x04000A9C RID: 2716
		Utc,
		// Token: 0x04000A9D RID: 2717
		LocalWestOfUtc,
		// Token: 0x04000A9E RID: 2718
		LocalEastOfUtc
	}
}
