﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002CC RID: 716
	internal static class MathUtils
	{
		// Token: 0x060028E2 RID: 10466 RVA: 0x0009ACDC File Offset: 0x00098EDC
		public static int IntLength(ulong i)
		{
			if (i >= 10000000000UL)
			{
				if (i < 100000000000UL)
				{
					return 11;
				}
				if (i < 1000000000000UL)
				{
					return 12;
				}
				if (i < 10000000000000UL)
				{
					return 13;
				}
				if (i < 100000000000000UL)
				{
					return 14;
				}
				if (i < 1000000000000000UL)
				{
					return 15;
				}
				if (i < 10000000000000000UL)
				{
					return 16;
				}
				if (i < 100000000000000000UL)
				{
					return 17;
				}
				if (i < 1000000000000000000UL)
				{
					return 18;
				}
				if (i < 10000000000000000000UL)
				{
					return 19;
				}
				return 20;
			}
			else
			{
				if (i < 10UL)
				{
					return 1;
				}
				if (i < 100UL)
				{
					return 2;
				}
				if (i < 1000UL)
				{
					return 3;
				}
				if (i < 10000UL)
				{
					return 4;
				}
				if (i < 100000UL)
				{
					return 5;
				}
				if (i < 1000000UL)
				{
					return 6;
				}
				if (i < 10000000UL)
				{
					return 7;
				}
				if (i < 100000000UL)
				{
					return 8;
				}
				if (i < 1000000000UL)
				{
					return 9;
				}
				return 10;
			}
		}

		// Token: 0x060028E3 RID: 10467 RVA: 0x0001F63D File Offset: 0x0001D83D
		public static char IntToHex(int n)
		{
			if (n <= 9)
			{
				return (char)(n + 48);
			}
			return (char)(n - 10 + 97);
		}

		// Token: 0x060028E4 RID: 10468 RVA: 0x0009AE04 File Offset: 0x00099004
		public static int? Min(int? val1, int? val2)
		{
			if (val1 == null)
			{
				goto IL_004B;
			}
			if (val2 != null)
			{
				return new int?(MathUtils.smethod_0(val1.Value, val2.Value));
			}
			int num = -143951759;
			IL_0032:
			switch (num ^ -143951757)
			{
			case 0:
				IL_004B:
				num = -143951758;
				goto IL_0032;
			case 1:
				return val2;
			}
			return val1;
		}

		// Token: 0x060028E5 RID: 10469 RVA: 0x0009AE68 File Offset: 0x00099068
		public static int? Max(int? val1, int? val2)
		{
			if (val1 == null)
			{
				goto IL_004B;
			}
			if (val2 != null)
			{
				return new int?(MathUtils.smethod_1(val1.Value, val2.Value));
			}
			int num = 53753581;
			IL_0032:
			switch (num ^ 53753580)
			{
			case 0:
				IL_004B:
				num = 53753582;
				goto IL_0032;
			case 2:
				return val2;
			}
			return val1;
		}

		// Token: 0x060028E6 RID: 10470 RVA: 0x0009AECC File Offset: 0x000990CC
		public static double? Max(double? val1, double? val2)
		{
			if (val1 == null)
			{
				goto IL_004B;
			}
			if (val2 != null)
			{
				return new double?(MathUtils.smethod_2(val1.Value, val2.Value));
			}
			int num = -1143124883;
			IL_0032:
			switch (num ^ -1143124881)
			{
			case 0:
				IL_004B:
				num = -1143124882;
				goto IL_0032;
			case 1:
				return val2;
			}
			return val1;
		}

		// Token: 0x060028E7 RID: 10471 RVA: 0x0009AF30 File Offset: 0x00099130
		public static bool ApproxEquals(double d1, double d2)
		{
			if (d1 == d2)
			{
				return true;
			}
			double num = (MathUtils.smethod_3(d1) + MathUtils.smethod_3(d2) + 10.0) * 2.2204460492503131E-16;
			double num2 = d1 - d2;
			return -num < num2 && num > num2;
		}

		// Token: 0x060028E8 RID: 10472 RVA: 0x0000F046 File Offset: 0x0000D246
		static int smethod_0(int int_0, int int_1)
		{
			return Math.Min(int_0, int_1);
		}

		// Token: 0x060028E9 RID: 10473 RVA: 0x0000F02D File Offset: 0x0000D22D
		static int smethod_1(int int_0, int int_1)
		{
			return Math.Max(int_0, int_1);
		}

		// Token: 0x060028EA RID: 10474 RVA: 0x0000ED6A File Offset: 0x0000CF6A
		static double smethod_2(double double_0, double double_1)
		{
			return Math.Max(double_0, double_1);
		}

		// Token: 0x060028EB RID: 10475 RVA: 0x0000FC9F File Offset: 0x0000DE9F
		static double smethod_3(double double_0)
		{
			return Math.Abs(double_0);
		}
	}
}
