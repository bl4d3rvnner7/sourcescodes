﻿using System;
using System.Collections;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002C0 RID: 704
	internal interface IWrappedCollection : IEnumerable, IList, ICollection
	{
		// Token: 0x170005DD RID: 1501
		// (get) Token: 0x06002805 RID: 10245
		object UnderlyingCollection { get; }
	}
}
