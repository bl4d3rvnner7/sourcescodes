﻿using System;
using System.Reflection;
using Newtonsoft.Json.Serialization;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002A7 RID: 679
	internal class LateBoundReflectionDelegateFactory : ReflectionDelegateFactory
	{
		// Token: 0x170005D0 RID: 1488
		// (get) Token: 0x06002779 RID: 10105 RVA: 0x0001E7F8 File Offset: 0x0001C9F8
		internal static ReflectionDelegateFactory Instance
		{
			get
			{
				return LateBoundReflectionDelegateFactory._instance;
			}
		}

		// Token: 0x0600277A RID: 10106 RVA: 0x00097870 File Offset: 0x00095A70
		public override ObjectConstructor<object> CreateParametrizedConstructor(MethodBase method)
		{
			ValidationUtils.ArgumentNotNull(method, <Module>.smethod_24<string>(2835135268U));
			ConstructorInfo c = method as ConstructorInfo;
			if (LateBoundReflectionDelegateFactory.smethod_4(c, null))
			{
				return (object[] a) => LateBoundReflectionDelegateFactory.<>c__DisplayClass3.smethod_0(c, a);
			}
			return (object[] a) => LateBoundReflectionDelegateFactory.<>c__DisplayClass3.smethod_1(method, null, a);
		}

		// Token: 0x0600277B RID: 10107 RVA: 0x000978E0 File Offset: 0x00095AE0
		public override MethodCall<T, object> CreateMethodCall<T>(MethodBase method)
		{
			ValidationUtils.ArgumentNotNull(method, <Module>.smethod_25<string>(2059156978U));
			ConstructorInfo c = method as ConstructorInfo;
			if (LateBoundReflectionDelegateFactory.smethod_4(c, null))
			{
				return (T o, object[] a) => LateBoundReflectionDelegateFactory.<>c__DisplayClass7<T>.smethod_0(c, a);
			}
			return (T o, object[] a) => LateBoundReflectionDelegateFactory.<>c__DisplayClass7<T>.smethod_1(method, o, a);
		}

		// Token: 0x0600277C RID: 10108 RVA: 0x00097948 File Offset: 0x00095B48
		public override Func<T> CreateDefaultConstructor<T>(Type type)
		{
			ValidationUtils.ArgumentNotNull(type, <Module>.smethod_24<string>(1347420388U));
			if (type.IsValueType())
			{
				return () => (T)((object)LateBoundReflectionDelegateFactory.<>c__DisplayClassb<T>.smethod_0(type));
			}
			ConstructorInfo constructorInfo = ReflectionUtils.GetDefaultConstructor(type, true);
			return () => (T)((object)LateBoundReflectionDelegateFactory.<>c__DisplayClassb<T>.smethod_1(constructorInfo, null));
		}

		// Token: 0x0600277D RID: 10109 RVA: 0x000979B0 File Offset: 0x00095BB0
		public override Func<T, object> CreateGet<T>(PropertyInfo propertyInfo)
		{
			ValidationUtils.ArgumentNotNull(propertyInfo, <Module>.smethod_26<string>(605822654U));
			return (T o) => LateBoundReflectionDelegateFactory.<>c__DisplayClasse<T>.smethod_0(propertyInfo, o, null);
		}

		// Token: 0x0600277E RID: 10110 RVA: 0x000979EC File Offset: 0x00095BEC
		public override Func<T, object> CreateGet<T>(FieldInfo fieldInfo)
		{
			ValidationUtils.ArgumentNotNull(fieldInfo, <Module>.smethod_26<string>(4196134527U));
			return (T o) => LateBoundReflectionDelegateFactory.<>c__DisplayClass11<T>.smethod_0(fieldInfo, o);
		}

		// Token: 0x0600277F RID: 10111 RVA: 0x00097A28 File Offset: 0x00095C28
		public override Action<T, object> CreateSet<T>(FieldInfo fieldInfo)
		{
			ValidationUtils.ArgumentNotNull(fieldInfo, <Module>.smethod_26<string>(4196134527U));
			return delegate(T o, object v)
			{
				LateBoundReflectionDelegateFactory.<>c__DisplayClass14<T>.smethod_0(fieldInfo, o, v);
			};
		}

		// Token: 0x06002780 RID: 10112 RVA: 0x00097A64 File Offset: 0x00095C64
		public override Action<T, object> CreateSet<T>(PropertyInfo propertyInfo)
		{
			ValidationUtils.ArgumentNotNull(propertyInfo, <Module>.smethod_25<string>(1196159153U));
			return delegate(T o, object v)
			{
				LateBoundReflectionDelegateFactory.<>c__DisplayClass17<T>.smethod_0(propertyInfo, o, v, null);
			};
		}

		// Token: 0x06002783 RID: 10115 RVA: 0x0001CA27 File Offset: 0x0001AC27
		static bool smethod_4(ConstructorInfo constructorInfo_0, ConstructorInfo constructorInfo_1)
		{
			return constructorInfo_0 != constructorInfo_1;
		}

		// Token: 0x04000DD0 RID: 3536
		private static readonly LateBoundReflectionDelegateFactory _instance = new LateBoundReflectionDelegateFactory();
	}
}
