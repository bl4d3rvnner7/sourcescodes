﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002CD RID: 717
	// (Invoke) Token: 0x060028ED RID: 10477
	internal delegate T Creator<T>();
}
