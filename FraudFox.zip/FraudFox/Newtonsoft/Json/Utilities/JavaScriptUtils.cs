﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002C8 RID: 712
	internal static class JavaScriptUtils
	{
		// Token: 0x0600289D RID: 10397 RVA: 0x0009A2F8 File Offset: 0x000984F8
		static JavaScriptUtils()
		{
			IList<char> list = new List<char> { '\n', '\r', '\t', '\\', '\f', '\b' };
			for (int i = 0; i < 32; i++)
			{
				list.Add((char)i);
			}
			IEnumerator<char> enumerator = list.Union(new char[] { '\'' }).GetEnumerator();
			try
			{
				while (JavaScriptUtils.smethod_0(enumerator))
				{
					char c = enumerator.Current;
					JavaScriptUtils.SingleQuoteCharEscapeFlags[(int)c] = true;
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JavaScriptUtils.smethod_1(enumerator);
				}
			}
			IEnumerator<char> enumerator2 = list.Union(new char[] { '"' }).GetEnumerator();
			try
			{
				while (JavaScriptUtils.smethod_0(enumerator2))
				{
					char c2 = enumerator2.Current;
					JavaScriptUtils.DoubleQuoteCharEscapeFlags[(int)c2] = true;
				}
			}
			finally
			{
				if (enumerator2 != null)
				{
					JavaScriptUtils.smethod_1(enumerator2);
				}
			}
			IEnumerable<char> enumerable = list;
			char[] array = new char[5];
			JavaScriptUtils.smethod_2(array, fieldof(<PrivateImplementationDetails>{2050F94B-4B51-45A2-913D-663F8B3DB301}.$$method0x6000b6e-1).FieldHandle);
			IEnumerator<char> enumerator3 = enumerable.Union(array).GetEnumerator();
			try
			{
				while (JavaScriptUtils.smethod_0(enumerator3))
				{
					char c3 = enumerator3.Current;
					JavaScriptUtils.HtmlCharEscapeFlags[(int)c3] = true;
				}
			}
			finally
			{
				if (enumerator3 != null)
				{
					JavaScriptUtils.smethod_1(enumerator3);
				}
			}
		}

		// Token: 0x0600289E RID: 10398 RVA: 0x0001F4BC File Offset: 0x0001D6BC
		public static bool[] GetCharEscapeFlags(StringEscapeHandling stringEscapeHandling, char quoteChar)
		{
			if (stringEscapeHandling == StringEscapeHandling.EscapeHtml)
			{
				return JavaScriptUtils.HtmlCharEscapeFlags;
			}
			if (quoteChar == '"')
			{
				return JavaScriptUtils.DoubleQuoteCharEscapeFlags;
			}
			return JavaScriptUtils.SingleQuoteCharEscapeFlags;
		}

		// Token: 0x0600289F RID: 10399 RVA: 0x0009A480 File Offset: 0x00098680
		public static bool ShouldEscapeJavaScriptString(string s, bool[] charEscapeFlags)
		{
			if (s == null)
			{
				return false;
			}
			for (int i = 0; i < JavaScriptUtils.smethod_4(s); i++)
			{
				char c = JavaScriptUtils.smethod_3(s, i);
				if ((int)c >= charEscapeFlags.Length || charEscapeFlags[(int)c])
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060028A0 RID: 10400 RVA: 0x0009A4C4 File Offset: 0x000986C4
		public static void WriteEscapedJavaScriptString(TextWriter writer, string s, char delimiter, bool appendDelimiters, bool[] charEscapeFlags, StringEscapeHandling stringEscapeHandling, ref char[] writeBuffer)
		{
			if (appendDelimiters)
			{
				JavaScriptUtils.smethod_5(writer, delimiter);
			}
			if (s != null)
			{
				int num = 0;
				for (int i = 0; i < JavaScriptUtils.smethod_4(s); i++)
				{
					char c = JavaScriptUtils.smethod_3(s, i);
					if ((int)c >= charEscapeFlags.Length || charEscapeFlags[(int)c])
					{
						char c2 = c;
						string text;
						if (c2 > '\\')
						{
							if (c2 != '\u0085')
							{
								switch (c2)
								{
								case '\u2028':
									text = <Module>.smethod_23<string>(2118427845U);
									break;
								case '\u2029':
									text = <Module>.smethod_26<string>(2573726208U);
									break;
								default:
									goto IL_00F7;
								}
							}
							else
							{
								text = <Module>.smethod_24<string>(381001615U);
							}
						}
						else
						{
							switch (c2)
							{
							case '\b':
								text = <Module>.smethod_25<string>(3435380695U);
								break;
							case '\t':
								text = <Module>.smethod_23<string>(3221675982U);
								break;
							case '\n':
								text = <Module>.smethod_23<string>(4217901900U);
								break;
							case '\v':
								goto IL_00F7;
							case '\f':
								text = <Module>.smethod_23<string>(1364114962U);
								break;
							case '\r':
								text = <Module>.smethod_26<string>(2554573420U);
								break;
							default:
								if (c2 != '\\')
								{
									goto IL_00F7;
								}
								text = <Module>.smethod_24<string>(312413695U);
								break;
							}
						}
						IL_017B:
						if (text == null)
						{
							goto IL_021A;
						}
						bool flag = JavaScriptUtils.smethod_6(text, <Module>.smethod_27<string>(2234013748U));
						if (i > num)
						{
							int num2 = i - num + (flag ? 6 : 0);
							int num3 = (flag ? 6 : 0);
							if (writeBuffer == null || writeBuffer.Length < num2)
							{
								char[] array = new char[num2];
								if (flag)
								{
									JavaScriptUtils.smethod_7(writeBuffer, array, 6);
								}
								writeBuffer = array;
							}
							JavaScriptUtils.smethod_8(s, num, writeBuffer, num3, num2 - num3);
							JavaScriptUtils.smethod_9(writer, writeBuffer, num3, num2 - num3);
						}
						num = i + 1;
						if (!flag)
						{
							JavaScriptUtils.smethod_10(writer, text);
							goto IL_021A;
						}
						JavaScriptUtils.smethod_9(writer, writeBuffer, 0, 6);
						goto IL_021A;
						IL_00F7:
						if ((int)c >= charEscapeFlags.Length)
						{
							if (stringEscapeHandling != StringEscapeHandling.EscapeNonAscii)
							{
								text = null;
								goto IL_017B;
							}
						}
						if (c == '\'')
						{
							if (stringEscapeHandling != StringEscapeHandling.EscapeHtml)
							{
								text = <Module>.smethod_24<string>(1247819798U);
								goto IL_017B;
							}
						}
						if (c == '"' && stringEscapeHandling != StringEscapeHandling.EscapeHtml)
						{
							text = <Module>.smethod_25<string>(1658917087U);
							goto IL_017B;
						}
						if (writeBuffer == null)
						{
							writeBuffer = new char[6];
						}
						StringUtils.ToCharAsUnicode(c, writeBuffer);
						text = <Module>.smethod_27<string>(2234013748U);
						goto IL_017B;
					}
					IL_021A:;
				}
				if (num == 0)
				{
					JavaScriptUtils.smethod_10(writer, s);
				}
				else
				{
					int num4 = JavaScriptUtils.smethod_4(s) - num;
					if (writeBuffer == null || writeBuffer.Length < num4)
					{
						writeBuffer = new char[num4];
					}
					JavaScriptUtils.smethod_8(s, num, writeBuffer, 0, num4);
					JavaScriptUtils.smethod_9(writer, writeBuffer, 0, num4);
				}
			}
			if (appendDelimiters)
			{
				JavaScriptUtils.smethod_5(writer, delimiter);
			}
		}

		// Token: 0x060028A1 RID: 10401 RVA: 0x0001F4D8 File Offset: 0x0001D6D8
		public static string ToEscapedJavaScriptString(string value, char delimiter, bool appendDelimiters)
		{
			return JavaScriptUtils.ToEscapedJavaScriptString(value, delimiter, appendDelimiters, StringEscapeHandling.Default);
		}

		// Token: 0x060028A2 RID: 10402 RVA: 0x0009A74C File Offset: 0x0009894C
		public static string ToEscapedJavaScriptString(string value, char delimiter, bool appendDelimiters, StringEscapeHandling stringEscapeHandling)
		{
			bool[] charEscapeFlags = JavaScriptUtils.GetCharEscapeFlags(stringEscapeHandling, delimiter);
			StringWriter stringWriter = StringUtils.CreateStringWriter(StringUtils.GetLength(value) ?? 16);
			string text;
			try
			{
				char[] array = null;
				JavaScriptUtils.WriteEscapedJavaScriptString(stringWriter, value, delimiter, appendDelimiters, charEscapeFlags, stringEscapeHandling, ref array);
				text = JavaScriptUtils.smethod_11(stringWriter);
			}
			finally
			{
				if (stringWriter != null)
				{
					JavaScriptUtils.smethod_1(stringWriter);
				}
			}
			return text;
		}

		// Token: 0x060028A3 RID: 10403 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_0(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060028A4 RID: 10404 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_1(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060028A5 RID: 10405 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_2(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x060028A6 RID: 10406 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_3(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x060028A7 RID: 10407 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_4(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x060028A8 RID: 10408 RVA: 0x0001AC4B File Offset: 0x00018E4B
		static void smethod_5(TextWriter textWriter_0, char char_0)
		{
			textWriter_0.Write(char_0);
		}

		// Token: 0x060028A9 RID: 10409 RVA: 0x0001F4E3 File Offset: 0x0001D6E3
		static bool smethod_6(string string_0, string string_1)
		{
			return string.Equals(string_0, string_1);
		}

		// Token: 0x060028AA RID: 10410 RVA: 0x000176C9 File Offset: 0x000158C9
		static void smethod_7(Array array_0, Array array_1, int int_0)
		{
			Array.Copy(array_0, array_1, int_0);
		}

		// Token: 0x060028AB RID: 10411 RVA: 0x0001EF89 File Offset: 0x0001D189
		static void smethod_8(string string_0, int int_0, char[] char_0, int int_1, int int_2)
		{
			string_0.CopyTo(int_0, char_0, int_1, int_2);
		}

		// Token: 0x060028AC RID: 10412 RVA: 0x0001AC5C File Offset: 0x00018E5C
		static void smethod_9(TextWriter textWriter_0, char[] char_0, int int_0, int int_1)
		{
			textWriter_0.Write(char_0, int_0, int_1);
		}

		// Token: 0x060028AD RID: 10413 RVA: 0x000146E8 File Offset: 0x000128E8
		static void smethod_10(TextWriter textWriter_0, string string_0)
		{
			textWriter_0.Write(string_0);
		}

		// Token: 0x060028AE RID: 10414 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_11(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x04000E46 RID: 3654
		private const string EscapedUnicodeText = "!";

		// Token: 0x04000E47 RID: 3655
		internal static readonly bool[] SingleQuoteCharEscapeFlags = new bool[128];

		// Token: 0x04000E48 RID: 3656
		internal static readonly bool[] DoubleQuoteCharEscapeFlags = new bool[128];

		// Token: 0x04000E49 RID: 3657
		internal static readonly bool[] HtmlCharEscapeFlags = new bool[128];
	}
}
