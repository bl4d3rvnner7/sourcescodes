﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002B5 RID: 693
	internal struct StringReference
	{
		// Token: 0x170005D6 RID: 1494
		// (get) Token: 0x060027BD RID: 10173 RVA: 0x0001E97B File Offset: 0x0001CB7B
		public char[] Chars
		{
			get
			{
				return this._chars;
			}
		}

		// Token: 0x170005D7 RID: 1495
		// (get) Token: 0x060027BE RID: 10174 RVA: 0x0001E983 File Offset: 0x0001CB83
		public int StartIndex
		{
			get
			{
				return this._startIndex;
			}
		}

		// Token: 0x170005D8 RID: 1496
		// (get) Token: 0x060027BF RID: 10175 RVA: 0x0001E98B File Offset: 0x0001CB8B
		public int Length
		{
			get
			{
				return this._length;
			}
		}

		// Token: 0x060027C0 RID: 10176 RVA: 0x0001E993 File Offset: 0x0001CB93
		public StringReference(char[] chars, int startIndex, int length)
		{
			this._chars = chars;
			this._startIndex = startIndex;
			this._length = length;
		}

		// Token: 0x060027C1 RID: 10177 RVA: 0x0001E9AA File Offset: 0x0001CBAA
		public override string ToString()
		{
			return StringReference.smethod_0(this._chars, this._startIndex, this._length);
		}

		// Token: 0x060027C2 RID: 10178 RVA: 0x00016A3D File Offset: 0x00014C3D
		static string smethod_0(char[] char_0, int int_0, int int_1)
		{
			return new string(char_0, int_0, int_1);
		}

		// Token: 0x04000DE3 RID: 3555
		private readonly char[] _chars;

		// Token: 0x04000DE4 RID: 3556
		private readonly int _startIndex;

		// Token: 0x04000DE5 RID: 3557
		private readonly int _length;
	}
}
