﻿using System;
using System.Collections.Generic;
using System.Dynamic;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020001E9 RID: 489
	internal class DynamicProxy<T>
	{
		// Token: 0x06001B5B RID: 7003 RVA: 0x00018A3D File Offset: 0x00016C3D
		public virtual IEnumerable<string> GetDynamicMemberNames(T instance)
		{
			return new string[0];
		}

		// Token: 0x06001B5C RID: 7004 RVA: 0x00018A45 File Offset: 0x00016C45
		public virtual bool TryBinaryOperation(T instance, BinaryOperationBinder binder, object arg, out object result)
		{
			result = null;
			return false;
		}

		// Token: 0x06001B5D RID: 7005 RVA: 0x00018A4C File Offset: 0x00016C4C
		public virtual bool TryConvert(T instance, ConvertBinder binder, out object result)
		{
			result = null;
			return false;
		}

		// Token: 0x06001B5E RID: 7006 RVA: 0x00018A45 File Offset: 0x00016C45
		public virtual bool TryCreateInstance(T instance, CreateInstanceBinder binder, object[] args, out object result)
		{
			result = null;
			return false;
		}

		// Token: 0x06001B5F RID: 7007 RVA: 0x0000C17A File Offset: 0x0000A37A
		public virtual bool TryDeleteIndex(T instance, DeleteIndexBinder binder, object[] indexes)
		{
			return false;
		}

		// Token: 0x06001B60 RID: 7008 RVA: 0x0000C17A File Offset: 0x0000A37A
		public virtual bool TryDeleteMember(T instance, DeleteMemberBinder binder)
		{
			return false;
		}

		// Token: 0x06001B61 RID: 7009 RVA: 0x00018A45 File Offset: 0x00016C45
		public virtual bool TryGetIndex(T instance, GetIndexBinder binder, object[] indexes, out object result)
		{
			result = null;
			return false;
		}

		// Token: 0x06001B62 RID: 7010 RVA: 0x00018A4C File Offset: 0x00016C4C
		public virtual bool TryGetMember(T instance, GetMemberBinder binder, out object result)
		{
			result = null;
			return false;
		}

		// Token: 0x06001B63 RID: 7011 RVA: 0x00018A45 File Offset: 0x00016C45
		public virtual bool TryInvoke(T instance, InvokeBinder binder, object[] args, out object result)
		{
			result = null;
			return false;
		}

		// Token: 0x06001B64 RID: 7012 RVA: 0x00018A45 File Offset: 0x00016C45
		public virtual bool TryInvokeMember(T instance, InvokeMemberBinder binder, object[] args, out object result)
		{
			result = null;
			return false;
		}

		// Token: 0x06001B65 RID: 7013 RVA: 0x0000C17A File Offset: 0x0000A37A
		public virtual bool TrySetIndex(T instance, SetIndexBinder binder, object[] indexes, object value)
		{
			return false;
		}

		// Token: 0x06001B66 RID: 7014 RVA: 0x0000C17A File Offset: 0x0000A37A
		public virtual bool TrySetMember(T instance, SetMemberBinder binder, object value)
		{
			return false;
		}

		// Token: 0x06001B67 RID: 7015 RVA: 0x00018A4C File Offset: 0x00016C4C
		public virtual bool TryUnaryOperation(T instance, UnaryOperationBinder binder, out object result)
		{
			result = null;
			return false;
		}
	}
}
