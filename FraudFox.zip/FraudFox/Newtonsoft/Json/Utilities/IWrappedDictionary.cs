﻿using System;
using System.Collections;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002C3 RID: 707
	internal interface IWrappedDictionary : IEnumerable, ICollection, IDictionary
	{
		// Token: 0x170005E5 RID: 1509
		// (get) Token: 0x06002846 RID: 10310
		object UnderlyingDictionary { get; }
	}
}
