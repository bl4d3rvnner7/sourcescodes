﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002C7 RID: 711
	internal class EnumValue<T> where T : struct
	{
		// Token: 0x170005F6 RID: 1526
		// (get) Token: 0x0600289A RID: 10394 RVA: 0x0001F496 File Offset: 0x0001D696
		public string Name
		{
			get
			{
				return this._name;
			}
		}

		// Token: 0x170005F7 RID: 1527
		// (get) Token: 0x0600289B RID: 10395 RVA: 0x0001F49E File Offset: 0x0001D69E
		public T Value
		{
			get
			{
				return this._value;
			}
		}

		// Token: 0x0600289C RID: 10396 RVA: 0x0001F4A6 File Offset: 0x0001D6A6
		public EnumValue(string name, T value)
		{
			this._name = name;
			this._value = value;
		}

		// Token: 0x04000E44 RID: 3652
		private readonly string _name;

		// Token: 0x04000E45 RID: 3653
		private readonly T _value;
	}
}
