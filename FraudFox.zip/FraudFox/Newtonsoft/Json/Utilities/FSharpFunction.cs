﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x0200029F RID: 671
	internal class FSharpFunction
	{
		// Token: 0x0600272D RID: 10029 RVA: 0x0001E5D2 File Offset: 0x0001C7D2
		public FSharpFunction(object instance, MethodCall<object, object> invoker)
		{
			this._instance = instance;
			this._invoker = invoker;
		}

		// Token: 0x0600272E RID: 10030 RVA: 0x000970CC File Offset: 0x000952CC
		public object Invoke(params object[] args)
		{
			return this._invoker(this._instance, args);
		}

		// Token: 0x04000DB2 RID: 3506
		private readonly object _instance;

		// Token: 0x04000DB3 RID: 3507
		private readonly MethodCall<object, object> _invoker;
	}
}
