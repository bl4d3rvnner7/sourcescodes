﻿using System;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using Newtonsoft.Json.Serialization;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x02000299 RID: 665
	internal class DynamicReflectionDelegateFactory : ReflectionDelegateFactory
	{
		// Token: 0x060026B4 RID: 9908 RVA: 0x0009609C File Offset: 0x0009429C
		private static DynamicMethod CreateDynamicMethod(string name, Type returnType, Type[] parameterTypes, Type owner)
		{
			return (!owner.IsInterface()) ? DynamicReflectionDelegateFactory.smethod_6(name, returnType, parameterTypes, owner, true) : DynamicReflectionDelegateFactory.smethod_5(name, returnType, parameterTypes, DynamicReflectionDelegateFactory.smethod_4(owner), true);
		}

		// Token: 0x060026B5 RID: 9909 RVA: 0x000960D0 File Offset: 0x000942D0
		public override ObjectConstructor<object> CreateParametrizedConstructor(MethodBase method)
		{
			DynamicMethod dynamicMethod = DynamicReflectionDelegateFactory.CreateDynamicMethod(DynamicReflectionDelegateFactory.smethod_7(method), DynamicReflectionDelegateFactory.smethod_8(typeof(object).TypeHandle), new Type[] { DynamicReflectionDelegateFactory.smethod_8(typeof(object[]).TypeHandle) }, DynamicReflectionDelegateFactory.smethod_9(method));
			ILGenerator ilgenerator = DynamicReflectionDelegateFactory.smethod_10(dynamicMethod);
			this.GenerateCreateMethodCallIL(method, ilgenerator, 0);
			return (ObjectConstructor<object>)DynamicReflectionDelegateFactory.smethod_11(dynamicMethod, DynamicReflectionDelegateFactory.smethod_8(typeof(ObjectConstructor<object>).TypeHandle));
		}

		// Token: 0x060026B6 RID: 9910 RVA: 0x00096138 File Offset: 0x00094338
		public override MethodCall<T, object> CreateMethodCall<T>(MethodBase method)
		{
			DynamicMethod dynamicMethod = DynamicReflectionDelegateFactory.CreateDynamicMethod(DynamicReflectionDelegateFactory.smethod_7(method), DynamicReflectionDelegateFactory.smethod_8(typeof(object).TypeHandle), new Type[]
			{
				DynamicReflectionDelegateFactory.smethod_8(typeof(object).TypeHandle),
				DynamicReflectionDelegateFactory.smethod_8(typeof(object[]).TypeHandle)
			}, DynamicReflectionDelegateFactory.smethod_9(method));
			ILGenerator ilgenerator = DynamicReflectionDelegateFactory.smethod_10(dynamicMethod);
			this.GenerateCreateMethodCallIL(method, ilgenerator, 1);
			return (MethodCall<T, object>)DynamicReflectionDelegateFactory.smethod_11(dynamicMethod, DynamicReflectionDelegateFactory.smethod_8(typeof(MethodCall<T, object>).TypeHandle));
		}

		// Token: 0x060026B7 RID: 9911 RVA: 0x000961B0 File Offset: 0x000943B0
		private void GenerateCreateMethodCallIL(MethodBase method, ILGenerator generator, int argsIndex)
		{
			ParameterInfo[] array = DynamicReflectionDelegateFactory.smethod_12(method);
			Label label = DynamicReflectionDelegateFactory.smethod_13(generator);
			DynamicReflectionDelegateFactory.smethod_14(generator, OpCodes.Ldarg, argsIndex);
			DynamicReflectionDelegateFactory.smethod_15(generator, OpCodes.Ldlen);
			DynamicReflectionDelegateFactory.smethod_14(generator, OpCodes.Ldc_I4, array.Length);
			DynamicReflectionDelegateFactory.smethod_16(generator, OpCodes.Beq, label);
			DynamicReflectionDelegateFactory.smethod_17(generator, OpCodes.Newobj, DynamicReflectionDelegateFactory.smethod_8(typeof(TargetParameterCountException).TypeHandle).method_0(ReflectionUtils.EmptyTypes));
			DynamicReflectionDelegateFactory.smethod_15(generator, OpCodes.Throw);
			DynamicReflectionDelegateFactory.smethod_18(generator, label);
			if (!DynamicReflectionDelegateFactory.smethod_19(method) && !DynamicReflectionDelegateFactory.smethod_20(method))
			{
				generator.PushInstance(DynamicReflectionDelegateFactory.smethod_9(method));
			}
			int num = 0;
			for (int i = 0; i < array.Length; i++)
			{
				ParameterInfo parameterInfo = array[i];
				Type type = DynamicReflectionDelegateFactory.smethod_21(parameterInfo);
				if (DynamicReflectionDelegateFactory.smethod_22(type))
				{
					type = DynamicReflectionDelegateFactory.smethod_23(type);
					LocalBuilder localBuilder = DynamicReflectionDelegateFactory.smethod_24(generator, type);
					if (!DynamicReflectionDelegateFactory.smethod_25(parameterInfo))
					{
						generator.PushArrayInstance(argsIndex, i);
						if (type.IsValueType())
						{
							Label label2 = DynamicReflectionDelegateFactory.smethod_13(generator);
							Label label3 = DynamicReflectionDelegateFactory.smethod_13(generator);
							DynamicReflectionDelegateFactory.smethod_16(generator, OpCodes.Brtrue_S, label2);
							DynamicReflectionDelegateFactory.smethod_26(generator, OpCodes.Ldloca_S, localBuilder);
							DynamicReflectionDelegateFactory.smethod_27(generator, OpCodes.Initobj, type);
							DynamicReflectionDelegateFactory.smethod_16(generator, OpCodes.Br_S, label3);
							DynamicReflectionDelegateFactory.smethod_18(generator, label2);
							generator.PushArrayInstance(argsIndex, i);
							generator.UnboxIfNeeded(type);
							DynamicReflectionDelegateFactory.smethod_14(generator, OpCodes.Stloc, num);
							DynamicReflectionDelegateFactory.smethod_18(generator, label3);
						}
						else
						{
							generator.UnboxIfNeeded(type);
							DynamicReflectionDelegateFactory.smethod_14(generator, OpCodes.Stloc, num);
						}
					}
					DynamicReflectionDelegateFactory.smethod_26(generator, OpCodes.Ldloca_S, localBuilder);
					num++;
				}
				else if (!type.IsValueType())
				{
					generator.PushArrayInstance(argsIndex, i);
					generator.UnboxIfNeeded(type);
				}
				else
				{
					generator.PushArrayInstance(argsIndex, i);
					Label label4 = DynamicReflectionDelegateFactory.smethod_13(generator);
					Label label5 = DynamicReflectionDelegateFactory.smethod_13(generator);
					DynamicReflectionDelegateFactory.smethod_16(generator, OpCodes.Brtrue_S, label4);
					LocalBuilder localBuilder2 = DynamicReflectionDelegateFactory.smethod_24(generator, type);
					DynamicReflectionDelegateFactory.smethod_26(generator, OpCodes.Ldloca_S, localBuilder2);
					DynamicReflectionDelegateFactory.smethod_27(generator, OpCodes.Initobj, type);
					DynamicReflectionDelegateFactory.smethod_14(generator, OpCodes.Ldloc, num);
					DynamicReflectionDelegateFactory.smethod_16(generator, OpCodes.Br_S, label5);
					DynamicReflectionDelegateFactory.smethod_18(generator, label4);
					generator.PushArrayInstance(argsIndex, i);
					generator.UnboxIfNeeded(type);
					DynamicReflectionDelegateFactory.smethod_18(generator, label5);
					num++;
				}
			}
			if (DynamicReflectionDelegateFactory.smethod_19(method))
			{
				DynamicReflectionDelegateFactory.smethod_17(generator, OpCodes.Newobj, (ConstructorInfo)method);
			}
			else
			{
				generator.CallMethod((MethodInfo)method);
			}
			Type type2 = (DynamicReflectionDelegateFactory.smethod_19(method) ? DynamicReflectionDelegateFactory.smethod_9(method) : DynamicReflectionDelegateFactory.smethod_28((MethodInfo)method));
			if (DynamicReflectionDelegateFactory.smethod_29(type2, DynamicReflectionDelegateFactory.smethod_8(typeof(void).TypeHandle)))
			{
				generator.BoxIfNeeded(type2);
			}
			else
			{
				DynamicReflectionDelegateFactory.smethod_15(generator, OpCodes.Ldnull);
			}
			generator.Return();
		}

		// Token: 0x060026B8 RID: 9912 RVA: 0x00096460 File Offset: 0x00094660
		public override Func<T> CreateDefaultConstructor<T>(Type type)
		{
			DynamicMethod dynamicMethod = DynamicReflectionDelegateFactory.CreateDynamicMethod(DynamicReflectionDelegateFactory.smethod_31(<Module>.smethod_25<string>(4188849632U), DynamicReflectionDelegateFactory.smethod_30(type)), DynamicReflectionDelegateFactory.smethod_8(typeof(T).TypeHandle), ReflectionUtils.EmptyTypes, type);
			DynamicReflectionDelegateFactory.smethod_32(dynamicMethod, true);
			ILGenerator ilgenerator = DynamicReflectionDelegateFactory.smethod_10(dynamicMethod);
			this.GenerateCreateDefaultConstructorIL(type, ilgenerator);
			return (Func<T>)DynamicReflectionDelegateFactory.smethod_11(dynamicMethod, DynamicReflectionDelegateFactory.smethod_8(typeof(Func<T>).TypeHandle));
		}

		// Token: 0x060026B9 RID: 9913 RVA: 0x000964C4 File Offset: 0x000946C4
		private void GenerateCreateDefaultConstructorIL(Type type, ILGenerator generator)
		{
			if (type.IsValueType())
			{
				DynamicReflectionDelegateFactory.smethod_24(generator, type);
				DynamicReflectionDelegateFactory.smethod_15(generator, OpCodes.Ldloc_0);
				DynamicReflectionDelegateFactory.smethod_27(generator, OpCodes.Box, type);
			}
			else
			{
				ConstructorInfo constructorInfo = DynamicReflectionDelegateFactory.smethod_33(type, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, ReflectionUtils.EmptyTypes, null);
				if (DynamicReflectionDelegateFactory.smethod_34(constructorInfo, null))
				{
					throw DynamicReflectionDelegateFactory.smethod_36(<Module>.smethod_24<string>(2367675390U).FormatWith(DynamicReflectionDelegateFactory.smethod_35(), type));
				}
				DynamicReflectionDelegateFactory.smethod_17(generator, OpCodes.Newobj, constructorInfo);
			}
			generator.Return();
		}

		// Token: 0x060026BA RID: 9914 RVA: 0x00096540 File Offset: 0x00094740
		public override Func<T, object> CreateGet<T>(PropertyInfo propertyInfo)
		{
			DynamicMethod dynamicMethod = DynamicReflectionDelegateFactory.CreateDynamicMethod(DynamicReflectionDelegateFactory.smethod_31(<Module>.smethod_23<string>(3948435325U), DynamicReflectionDelegateFactory.smethod_37(propertyInfo)), DynamicReflectionDelegateFactory.smethod_8(typeof(T).TypeHandle), new Type[] { DynamicReflectionDelegateFactory.smethod_8(typeof(object).TypeHandle) }, DynamicReflectionDelegateFactory.smethod_9(propertyInfo));
			ILGenerator ilgenerator = DynamicReflectionDelegateFactory.smethod_10(dynamicMethod);
			this.GenerateCreateGetPropertyIL(propertyInfo, ilgenerator);
			return (Func<T, object>)DynamicReflectionDelegateFactory.smethod_11(dynamicMethod, DynamicReflectionDelegateFactory.smethod_8(typeof(Func<T, object>).TypeHandle));
		}

		// Token: 0x060026BB RID: 9915 RVA: 0x000965B8 File Offset: 0x000947B8
		private void GenerateCreateGetPropertyIL(PropertyInfo propertyInfo, ILGenerator generator)
		{
			MethodInfo methodInfo = DynamicReflectionDelegateFactory.smethod_38(propertyInfo, true);
			for (;;)
			{
				IL_005F:
				int num = 1938153782;
				for (;;)
				{
					switch (num ^ 1938153783)
					{
					case 1:
						if (DynamicReflectionDelegateFactory.smethod_39(methodInfo, null))
						{
							goto Block_2;
						}
						goto IL_000A;
					case 2:
						goto IL_0025;
					case 3:
						goto IL_000A;
					case 4:
						goto IL_005F;
					}
					goto Block_3;
					IL_000A:
					if (!DynamicReflectionDelegateFactory.smethod_20(methodInfo))
					{
						generator.PushInstance(DynamicReflectionDelegateFactory.smethod_9(propertyInfo));
						num = 1938153781;
						continue;
					}
					IL_0025:
					generator.CallMethod(methodInfo);
					num = 1938153783;
				}
			}
			Block_2:
			throw DynamicReflectionDelegateFactory.smethod_36(<Module>.smethod_27<string>(4131263843U).FormatWith(DynamicReflectionDelegateFactory.smethod_35(), DynamicReflectionDelegateFactory.smethod_37(propertyInfo)));
			Block_3:
			generator.BoxIfNeeded(DynamicReflectionDelegateFactory.smethod_40(propertyInfo));
			generator.Return();
		}

		// Token: 0x060026BC RID: 9916 RVA: 0x00096660 File Offset: 0x00094860
		public override Func<T, object> CreateGet<T>(FieldInfo fieldInfo)
		{
			if (!DynamicReflectionDelegateFactory.smethod_41(fieldInfo))
			{
				DynamicMethod dynamicMethod = DynamicReflectionDelegateFactory.CreateDynamicMethod(DynamicReflectionDelegateFactory.smethod_31(<Module>.smethod_23<string>(3948435325U), DynamicReflectionDelegateFactory.smethod_37(fieldInfo)), DynamicReflectionDelegateFactory.smethod_8(typeof(T).TypeHandle), new Type[] { DynamicReflectionDelegateFactory.smethod_8(typeof(object).TypeHandle) }, DynamicReflectionDelegateFactory.smethod_9(fieldInfo));
				ILGenerator ilgenerator = DynamicReflectionDelegateFactory.smethod_10(dynamicMethod);
				this.GenerateCreateGetFieldIL(fieldInfo, ilgenerator);
				return (Func<T, object>)DynamicReflectionDelegateFactory.smethod_11(dynamicMethod, DynamicReflectionDelegateFactory.smethod_8(typeof(Func<T, object>).TypeHandle));
			}
			object constantValue = DynamicReflectionDelegateFactory.smethod_42(fieldInfo, null);
			return (T o) => constantValue;
		}

		// Token: 0x060026BD RID: 9917 RVA: 0x00096704 File Offset: 0x00094904
		private void GenerateCreateGetFieldIL(FieldInfo fieldInfo, ILGenerator generator)
		{
			if (!DynamicReflectionDelegateFactory.smethod_43(fieldInfo))
			{
				generator.PushInstance(DynamicReflectionDelegateFactory.smethod_9(fieldInfo));
				DynamicReflectionDelegateFactory.smethod_44(generator, OpCodes.Ldfld, fieldInfo);
			}
			else
			{
				DynamicReflectionDelegateFactory.smethod_44(generator, OpCodes.Ldsfld, fieldInfo);
			}
			generator.BoxIfNeeded(DynamicReflectionDelegateFactory.smethod_45(fieldInfo));
			generator.Return();
		}

		// Token: 0x060026BE RID: 9918 RVA: 0x00096754 File Offset: 0x00094954
		public override Action<T, object> CreateSet<T>(FieldInfo fieldInfo)
		{
			DynamicMethod dynamicMethod = DynamicReflectionDelegateFactory.CreateDynamicMethod(DynamicReflectionDelegateFactory.smethod_31(<Module>.smethod_23<string>(1336561422U), DynamicReflectionDelegateFactory.smethod_37(fieldInfo)), null, new Type[]
			{
				DynamicReflectionDelegateFactory.smethod_8(typeof(T).TypeHandle),
				DynamicReflectionDelegateFactory.smethod_8(typeof(object).TypeHandle)
			}, DynamicReflectionDelegateFactory.smethod_9(fieldInfo));
			ILGenerator ilgenerator = DynamicReflectionDelegateFactory.smethod_10(dynamicMethod);
			DynamicReflectionDelegateFactory.GenerateCreateSetFieldIL(fieldInfo, ilgenerator);
			return (Action<T, object>)DynamicReflectionDelegateFactory.smethod_11(dynamicMethod, DynamicReflectionDelegateFactory.smethod_8(typeof(Action<T, object>).TypeHandle));
		}

		// Token: 0x060026BF RID: 9919 RVA: 0x000967D0 File Offset: 0x000949D0
		internal static void GenerateCreateSetFieldIL(FieldInfo fieldInfo, ILGenerator generator)
		{
			if (!DynamicReflectionDelegateFactory.smethod_43(fieldInfo))
			{
				generator.PushInstance(DynamicReflectionDelegateFactory.smethod_9(fieldInfo));
			}
			DynamicReflectionDelegateFactory.smethod_15(generator, OpCodes.Ldarg_1);
			generator.UnboxIfNeeded(DynamicReflectionDelegateFactory.smethod_45(fieldInfo));
			if (!DynamicReflectionDelegateFactory.smethod_43(fieldInfo))
			{
				DynamicReflectionDelegateFactory.smethod_44(generator, OpCodes.Stfld, fieldInfo);
			}
			else
			{
				DynamicReflectionDelegateFactory.smethod_44(generator, OpCodes.Stsfld, fieldInfo);
			}
			generator.Return();
		}

		// Token: 0x060026C0 RID: 9920 RVA: 0x00096830 File Offset: 0x00094A30
		public override Action<T, object> CreateSet<T>(PropertyInfo propertyInfo)
		{
			DynamicMethod dynamicMethod = DynamicReflectionDelegateFactory.CreateDynamicMethod(DynamicReflectionDelegateFactory.smethod_31(<Module>.smethod_24<string>(1378405143U), DynamicReflectionDelegateFactory.smethod_37(propertyInfo)), null, new Type[]
			{
				DynamicReflectionDelegateFactory.smethod_8(typeof(T).TypeHandle),
				DynamicReflectionDelegateFactory.smethod_8(typeof(object).TypeHandle)
			}, DynamicReflectionDelegateFactory.smethod_9(propertyInfo));
			ILGenerator ilgenerator = DynamicReflectionDelegateFactory.smethod_10(dynamicMethod);
			DynamicReflectionDelegateFactory.GenerateCreateSetPropertyIL(propertyInfo, ilgenerator);
			return (Action<T, object>)DynamicReflectionDelegateFactory.smethod_11(dynamicMethod, DynamicReflectionDelegateFactory.smethod_8(typeof(Action<T, object>).TypeHandle));
		}

		// Token: 0x060026C1 RID: 9921 RVA: 0x000968AC File Offset: 0x00094AAC
		internal static void GenerateCreateSetPropertyIL(PropertyInfo propertyInfo, ILGenerator generator)
		{
			MethodInfo methodInfo = DynamicReflectionDelegateFactory.smethod_46(propertyInfo, true);
			if (!DynamicReflectionDelegateFactory.smethod_20(methodInfo))
			{
				generator.PushInstance(DynamicReflectionDelegateFactory.smethod_9(propertyInfo));
			}
			DynamicReflectionDelegateFactory.smethod_15(generator, OpCodes.Ldarg_1);
			generator.UnboxIfNeeded(DynamicReflectionDelegateFactory.smethod_40(propertyInfo));
			generator.CallMethod(methodInfo);
			generator.Return();
		}

		// Token: 0x060026C4 RID: 9924 RVA: 0x0001E40E File Offset: 0x0001C60E
		static Module smethod_4(Type type_0)
		{
			return type_0.Module;
		}

		// Token: 0x060026C5 RID: 9925 RVA: 0x0001E416 File Offset: 0x0001C616
		static DynamicMethod smethod_5(string string_0, Type type_0, Type[] type_1, Module module_0, bool bool_0)
		{
			return new DynamicMethod(string_0, type_0, type_1, module_0, bool_0);
		}

		// Token: 0x060026C6 RID: 9926 RVA: 0x0001E423 File Offset: 0x0001C623
		static DynamicMethod smethod_6(string string_0, Type type_0, Type[] type_1, Type type_2, bool bool_0)
		{
			return new DynamicMethod(string_0, type_0, type_1, type_2, bool_0);
		}

		// Token: 0x060026C7 RID: 9927 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_7(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x060026C8 RID: 9928 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_8(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060026C9 RID: 9929 RVA: 0x00014858 File Offset: 0x00012A58
		static Type smethod_9(MemberInfo memberInfo_0)
		{
			return memberInfo_0.DeclaringType;
		}

		// Token: 0x060026CA RID: 9930 RVA: 0x0001E430 File Offset: 0x0001C630
		static ILGenerator smethod_10(DynamicMethod dynamicMethod_0)
		{
			return dynamicMethod_0.GetILGenerator();
		}

		// Token: 0x060026CB RID: 9931 RVA: 0x0001E438 File Offset: 0x0001C638
		static Delegate smethod_11(DynamicMethod dynamicMethod_0, Type type_0)
		{
			return dynamicMethod_0.CreateDelegate(type_0);
		}

		// Token: 0x060026CC RID: 9932 RVA: 0x0001CA54 File Offset: 0x0001AC54
		static ParameterInfo[] smethod_12(MethodBase methodBase_0)
		{
			return methodBase_0.GetParameters();
		}

		// Token: 0x060026CD RID: 9933 RVA: 0x0001E441 File Offset: 0x0001C641
		static Label smethod_13(ILGenerator ilgenerator_0)
		{
			return ilgenerator_0.DefineLabel();
		}

		// Token: 0x060026CE RID: 9934 RVA: 0x0001E449 File Offset: 0x0001C649
		static void smethod_14(ILGenerator ilgenerator_0, OpCode opCode_0, int int_0)
		{
			ilgenerator_0.Emit(opCode_0, int_0);
		}

		// Token: 0x060026CF RID: 9935 RVA: 0x0001E453 File Offset: 0x0001C653
		static void smethod_15(ILGenerator ilgenerator_0, OpCode opCode_0)
		{
			ilgenerator_0.Emit(opCode_0);
		}

		// Token: 0x060026D0 RID: 9936 RVA: 0x0001E45C File Offset: 0x0001C65C
		static void smethod_16(ILGenerator ilgenerator_0, OpCode opCode_0, Label label_0)
		{
			ilgenerator_0.Emit(opCode_0, label_0);
		}

		// Token: 0x060026D1 RID: 9937 RVA: 0x0001E466 File Offset: 0x0001C666
		ConstructorInfo method_0(Type[] type_0)
		{
			return base.GetConstructor(type_0);
		}

		// Token: 0x060026D2 RID: 9938 RVA: 0x0001E46F File Offset: 0x0001C66F
		static void smethod_17(ILGenerator ilgenerator_0, OpCode opCode_0, ConstructorInfo constructorInfo_0)
		{
			ilgenerator_0.Emit(opCode_0, constructorInfo_0);
		}

		// Token: 0x060026D3 RID: 9939 RVA: 0x0001E479 File Offset: 0x0001C679
		static void smethod_18(ILGenerator ilgenerator_0, Label label_0)
		{
			ilgenerator_0.MarkLabel(label_0);
		}

		// Token: 0x060026D4 RID: 9940 RVA: 0x0001E482 File Offset: 0x0001C682
		static bool smethod_19(MethodBase methodBase_0)
		{
			return methodBase_0.IsConstructor;
		}

		// Token: 0x060026D5 RID: 9941 RVA: 0x0001E48A File Offset: 0x0001C68A
		static bool smethod_20(MethodBase methodBase_0)
		{
			return methodBase_0.IsStatic;
		}

		// Token: 0x060026D6 RID: 9942 RVA: 0x0001CA64 File Offset: 0x0001AC64
		static Type smethod_21(ParameterInfo parameterInfo_0)
		{
			return parameterInfo_0.ParameterType;
		}

		// Token: 0x060026D7 RID: 9943 RVA: 0x0001E492 File Offset: 0x0001C692
		static bool smethod_22(Type type_0)
		{
			return type_0.IsByRef;
		}

		// Token: 0x060026D8 RID: 9944 RVA: 0x00015F34 File Offset: 0x00014134
		static Type smethod_23(Type type_0)
		{
			return type_0.GetElementType();
		}

		// Token: 0x060026D9 RID: 9945 RVA: 0x0001E49A File Offset: 0x0001C69A
		static LocalBuilder smethod_24(ILGenerator ilgenerator_0, Type type_0)
		{
			return ilgenerator_0.DeclareLocal(type_0);
		}

		// Token: 0x060026DA RID: 9946 RVA: 0x0001E4A3 File Offset: 0x0001C6A3
		static bool smethod_25(ParameterInfo parameterInfo_0)
		{
			return parameterInfo_0.IsOut;
		}

		// Token: 0x060026DB RID: 9947 RVA: 0x0001E4AB File Offset: 0x0001C6AB
		static void smethod_26(ILGenerator ilgenerator_0, OpCode opCode_0, LocalBuilder localBuilder_0)
		{
			ilgenerator_0.Emit(opCode_0, localBuilder_0);
		}

		// Token: 0x060026DC RID: 9948 RVA: 0x0001E4B5 File Offset: 0x0001C6B5
		static void smethod_27(ILGenerator ilgenerator_0, OpCode opCode_0, Type type_0)
		{
			ilgenerator_0.Emit(opCode_0, type_0);
		}

		// Token: 0x060026DD RID: 9949 RVA: 0x0001CAC6 File Offset: 0x0001ACC6
		static Type smethod_28(MethodInfo methodInfo_0)
		{
			return methodInfo_0.ReturnType;
		}

		// Token: 0x060026DE RID: 9950 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_29(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x060026DF RID: 9951 RVA: 0x00017761 File Offset: 0x00015961
		static string smethod_30(Type type_0)
		{
			return type_0.FullName;
		}

		// Token: 0x060026E0 RID: 9952 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_31(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x060026E1 RID: 9953 RVA: 0x0001E4BF File Offset: 0x0001C6BF
		static void smethod_32(DynamicMethod dynamicMethod_0, bool bool_0)
		{
			dynamicMethod_0.InitLocals = bool_0;
		}

		// Token: 0x060026E2 RID: 9954 RVA: 0x0001CA96 File Offset: 0x0001AC96
		static ConstructorInfo smethod_33(Type type_0, BindingFlags bindingFlags_0, Binder binder_0, Type[] type_1, ParameterModifier[] parameterModifier_0)
		{
			return type_0.GetConstructor(bindingFlags_0, binder_0, type_1, parameterModifier_0);
		}

		// Token: 0x060026E3 RID: 9955 RVA: 0x0001CA7C File Offset: 0x0001AC7C
		static bool smethod_34(ConstructorInfo constructorInfo_0, ConstructorInfo constructorInfo_1)
		{
			return constructorInfo_0 == constructorInfo_1;
		}

		// Token: 0x060026E4 RID: 9956 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_35()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060026E5 RID: 9957 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_36(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x060026E6 RID: 9958 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_37(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x060026E7 RID: 9959 RVA: 0x0001E4C8 File Offset: 0x0001C6C8
		static MethodInfo smethod_38(PropertyInfo propertyInfo_0, bool bool_0)
		{
			return propertyInfo_0.GetGetMethod(bool_0);
		}

		// Token: 0x060026E8 RID: 9960 RVA: 0x0001CAFE File Offset: 0x0001ACFE
		static bool smethod_39(MethodInfo methodInfo_0, MethodInfo methodInfo_1)
		{
			return methodInfo_0 == methodInfo_1;
		}

		// Token: 0x060026E9 RID: 9961 RVA: 0x000162CE File Offset: 0x000144CE
		static Type smethod_40(PropertyInfo propertyInfo_0)
		{
			return propertyInfo_0.PropertyType;
		}

		// Token: 0x060026EA RID: 9962 RVA: 0x0001E4D1 File Offset: 0x0001C6D1
		static bool smethod_41(FieldInfo fieldInfo_0)
		{
			return fieldInfo_0.IsLiteral;
		}

		// Token: 0x060026EB RID: 9963 RVA: 0x0001E4D9 File Offset: 0x0001C6D9
		static object smethod_42(FieldInfo fieldInfo_0, object object_0)
		{
			return fieldInfo_0.GetValue(object_0);
		}

		// Token: 0x060026EC RID: 9964 RVA: 0x0001CA16 File Offset: 0x0001AC16
		static bool smethod_43(FieldInfo fieldInfo_0)
		{
			return fieldInfo_0.IsStatic;
		}

		// Token: 0x060026ED RID: 9965 RVA: 0x0001E4E2 File Offset: 0x0001C6E2
		static void smethod_44(ILGenerator ilgenerator_0, OpCode opCode_0, FieldInfo fieldInfo_0)
		{
			ilgenerator_0.Emit(opCode_0, fieldInfo_0);
		}

		// Token: 0x060026EE RID: 9966 RVA: 0x0001E4EC File Offset: 0x0001C6EC
		static Type smethod_45(FieldInfo fieldInfo_0)
		{
			return fieldInfo_0.FieldType;
		}

		// Token: 0x060026EF RID: 9967 RVA: 0x0001E4F4 File Offset: 0x0001C6F4
		static MethodInfo smethod_46(PropertyInfo propertyInfo_0, bool bool_0)
		{
			return propertyInfo_0.GetSetMethod(bool_0);
		}

		// Token: 0x04000DAB RID: 3499
		public static DynamicReflectionDelegateFactory Instance = new DynamicReflectionDelegateFactory();
	}
}
