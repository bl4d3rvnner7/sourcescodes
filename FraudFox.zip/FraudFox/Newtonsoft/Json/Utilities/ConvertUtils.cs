﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlTypes;
using System.Globalization;
using System.Numerics;
using System.Reflection;
using Newtonsoft.Json.Serialization;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002BC RID: 700
	internal static class ConvertUtils
	{
		// Token: 0x060027D1 RID: 10193 RVA: 0x00097F00 File Offset: 0x00096100
		public static PrimitiveTypeCode GetTypeCode(Type t)
		{
			bool flag;
			return ConvertUtils.GetTypeCode(t, out flag);
		}

		// Token: 0x060027D2 RID: 10194 RVA: 0x00097F18 File Offset: 0x00096118
		public static PrimitiveTypeCode GetTypeCode(Type t, out bool isEnum)
		{
			PrimitiveTypeCode primitiveTypeCode;
			if (ConvertUtils.TypeCodeMap.TryGetValue(t, out primitiveTypeCode))
			{
				isEnum = false;
				return primitiveTypeCode;
			}
			if (t.IsEnum())
			{
				isEnum = true;
				return ConvertUtils.GetTypeCode(ConvertUtils.smethod_0(t));
			}
			if (ReflectionUtils.IsNullableType(t))
			{
				Type type = ConvertUtils.smethod_1(t);
				if (type.IsEnum())
				{
					Type type2 = ConvertUtils.smethod_3(ConvertUtils.smethod_2(typeof(Nullable<>).TypeHandle), new Type[] { ConvertUtils.smethod_0(type) });
					isEnum = true;
					return ConvertUtils.GetTypeCode(type2);
				}
			}
			isEnum = false;
			return PrimitiveTypeCode.Object;
		}

		// Token: 0x060027D3 RID: 10195 RVA: 0x00097F9C File Offset: 0x0009619C
		public static TypeInformation GetTypeInformation(IConvertible convertable)
		{
			return ConvertUtils.PrimitiveTypeCodes[(int)ConvertUtils.smethod_4(convertable)];
		}

		// Token: 0x060027D4 RID: 10196 RVA: 0x0001EA9A File Offset: 0x0001CC9A
		public static bool IsConvertible(Type t)
		{
			return ConvertUtils.smethod_5(ConvertUtils.smethod_2(typeof(IConvertible).TypeHandle), t);
		}

		// Token: 0x060027D5 RID: 10197 RVA: 0x0001EAAC File Offset: 0x0001CCAC
		public static TimeSpan ParseTimeSpan(string input)
		{
			return TimeSpan.Parse(input, ConvertUtils.smethod_6());
		}

		// Token: 0x060027D6 RID: 10198 RVA: 0x00097FBC File Offset: 0x000961BC
		private static Func<object, object> CreateCastConverter(ConvertUtils.TypeConvertKey t)
		{
			MethodInfo methodInfo = ConvertUtils.smethod_7(t.TargetType, <Module>.smethod_24<string>(2725377847U), new Type[] { t.InitialType });
			if (ConvertUtils.smethod_8(methodInfo, null))
			{
				methodInfo = ConvertUtils.smethod_7(t.TargetType, <Module>.smethod_26<string>(1679959710U), new Type[] { t.InitialType });
			}
			if (ConvertUtils.smethod_8(methodInfo, null))
			{
				return null;
			}
			MethodCall<object, object> call = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>(methodInfo);
			return (object o) => call(null, new object[] { o });
		}

		// Token: 0x060027D7 RID: 10199 RVA: 0x0009805C File Offset: 0x0009625C
		internal static BigInteger ToBigInteger(object value)
		{
			if (value is BigInteger)
			{
				return (BigInteger)value;
			}
			if (value is string)
			{
				return BigInteger.Parse((string)value, ConvertUtils.smethod_6());
			}
			if (value is float)
			{
				return new BigInteger((float)value);
			}
			if (value is double)
			{
				return new BigInteger((double)value);
			}
			if (value is decimal)
			{
				return new BigInteger((decimal)value);
			}
			if (value is int)
			{
				return new BigInteger((int)value);
			}
			if (value is long)
			{
				return new BigInteger((long)value);
			}
			if (value is uint)
			{
				return new BigInteger((uint)value);
			}
			if (value is ulong)
			{
				return new BigInteger((ulong)value);
			}
			if (value is byte[])
			{
				return new BigInteger((byte[])value);
			}
			throw new InvalidCastException(<Module>.smethod_23<string>(1959175430U).FormatWith(CultureInfo.InvariantCulture, value.GetType()));
		}

		// Token: 0x060027D8 RID: 10200 RVA: 0x00098154 File Offset: 0x00096354
		public static object FromBigInteger(BigInteger i, Type targetType)
		{
			if (ConvertUtils.smethod_9(targetType, ConvertUtils.smethod_2(typeof(decimal).TypeHandle)))
			{
				return (decimal)i;
			}
			if (ConvertUtils.smethod_9(targetType, ConvertUtils.smethod_2(typeof(double).TypeHandle)))
			{
				return (double)i;
			}
			if (ConvertUtils.smethod_9(targetType, ConvertUtils.smethod_2(typeof(float).TypeHandle)))
			{
				return (float)i;
			}
			if (ConvertUtils.smethod_9(targetType, ConvertUtils.smethod_2(typeof(ulong).TypeHandle)))
			{
				return (ulong)i;
			}
			object obj;
			try
			{
				obj = ConvertUtils.smethod_10((long)i, targetType, ConvertUtils.smethod_6());
			}
			catch (Exception ex)
			{
				throw ConvertUtils.smethod_11(<Module>.smethod_26<string>(1708688892U).FormatWith(ConvertUtils.smethod_6(), targetType), ex);
			}
			return obj;
		}

		// Token: 0x060027D9 RID: 10201 RVA: 0x00098228 File Offset: 0x00096428
		public static object Convert(object initialValue, CultureInfo culture, Type targetType)
		{
			object obj;
			switch (ConvertUtils.TryConvertInternal(initialValue, culture, targetType, out obj))
			{
			case ConvertUtils.ConvertResult.Success:
				return obj;
			case ConvertUtils.ConvertResult.CannotConvertNull:
				throw ConvertUtils.smethod_13(<Module>.smethod_23<string>(431735539U).FormatWith(ConvertUtils.smethod_6(), ConvertUtils.smethod_12(initialValue), targetType));
			case ConvertUtils.ConvertResult.NotInstantiableType:
				throw ConvertUtils.smethod_14(<Module>.smethod_25<string>(1414324595U).FormatWith(ConvertUtils.smethod_6(), targetType), <Module>.smethod_25<string>(2209344451U));
			case ConvertUtils.ConvertResult.NoValidConversion:
				throw ConvertUtils.smethod_15(<Module>.smethod_23<string>(3392544696U).FormatWith(ConvertUtils.smethod_6(), ConvertUtils.smethod_12(initialValue), targetType));
			default:
				throw ConvertUtils.smethod_15(<Module>.smethod_27<string>(3834219065U));
			}
		}

		// Token: 0x060027DA RID: 10202 RVA: 0x000982D0 File Offset: 0x000964D0
		private static bool TryConvert(object initialValue, CultureInfo culture, Type targetType, out object value)
		{
			bool flag;
			try
			{
				if (ConvertUtils.TryConvertInternal(initialValue, culture, targetType, out value) == ConvertUtils.ConvertResult.Success)
				{
					flag = true;
				}
				else
				{
					value = null;
					flag = false;
				}
			}
			catch
			{
				for (;;)
				{
					IL_0049:
					int num = 1206769052;
					for (;;)
					{
						switch (num ^ 1206769054)
						{
						case 0:
							goto IL_0049;
						case 1:
							flag = false;
							num = 1206769053;
							continue;
						case 2:
							value = null;
							num = 1206769055;
							continue;
						}
						goto Block_4;
					}
				}
				Block_4:;
			}
			return flag;
		}

		// Token: 0x060027DB RID: 10203 RVA: 0x00098340 File Offset: 0x00096540
		private static ConvertUtils.ConvertResult TryConvertInternal(object initialValue, CultureInfo culture, Type targetType, out object value)
		{
			if (initialValue == null)
			{
				throw ConvertUtils.smethod_16(<Module>.smethod_26<string>(165308530U));
			}
			if (ReflectionUtils.IsNullableType(targetType))
			{
				targetType = ConvertUtils.smethod_1(targetType);
			}
			Type type = ConvertUtils.smethod_12(initialValue);
			if (ConvertUtils.smethod_9(targetType, type))
			{
				value = initialValue;
				return ConvertUtils.ConvertResult.Success;
			}
			if (ConvertUtils.IsConvertible(ConvertUtils.smethod_12(initialValue)) && ConvertUtils.IsConvertible(targetType))
			{
				if (targetType.IsEnum())
				{
					if (initialValue is string)
					{
						value = ConvertUtils.smethod_18(targetType, ConvertUtils.smethod_17(initialValue), true);
						return ConvertUtils.ConvertResult.Success;
					}
					if (ConvertUtils.IsInteger(initialValue))
					{
						value = ConvertUtils.smethod_19(targetType, initialValue);
						return ConvertUtils.ConvertResult.Success;
					}
				}
				value = ConvertUtils.smethod_10(initialValue, targetType, culture);
				return ConvertUtils.ConvertResult.Success;
			}
			if (initialValue is DateTime && ConvertUtils.smethod_9(targetType, ConvertUtils.smethod_2(typeof(DateTimeOffset).TypeHandle)))
			{
				value = new DateTimeOffset((DateTime)initialValue);
				return ConvertUtils.ConvertResult.Success;
			}
			if (initialValue is byte[] && targetType == typeof(Guid))
			{
				value = new Guid((byte[])initialValue);
				return ConvertUtils.ConvertResult.Success;
			}
			if (initialValue is Guid && targetType == typeof(byte[]))
			{
				value = ((Guid)initialValue).ToByteArray();
				return ConvertUtils.ConvertResult.Success;
			}
			if (initialValue is string)
			{
				if (targetType == typeof(Guid))
				{
					value = new Guid((string)initialValue);
					return ConvertUtils.ConvertResult.Success;
				}
				if (targetType == typeof(Uri))
				{
					value = new Uri((string)initialValue, UriKind.RelativeOrAbsolute);
					return ConvertUtils.ConvertResult.Success;
				}
				if (targetType == typeof(TimeSpan))
				{
					value = ConvertUtils.ParseTimeSpan((string)initialValue);
					return ConvertUtils.ConvertResult.Success;
				}
				if (targetType == typeof(byte[]))
				{
					value = global::System.Convert.FromBase64String((string)initialValue);
					return ConvertUtils.ConvertResult.Success;
				}
				if (typeof(Type).IsAssignableFrom(targetType))
				{
					value = Type.GetType((string)initialValue, true);
					return ConvertUtils.ConvertResult.Success;
				}
			}
			if (targetType == typeof(BigInteger))
			{
				value = ConvertUtils.ToBigInteger(initialValue);
				return ConvertUtils.ConvertResult.Success;
			}
			if (initialValue is BigInteger)
			{
				value = ConvertUtils.FromBigInteger((BigInteger)initialValue, targetType);
				return ConvertUtils.ConvertResult.Success;
			}
			TypeConverter converter = ConvertUtils.GetConverter(type);
			if (converter != null && converter.CanConvertTo(targetType))
			{
				value = converter.ConvertTo(null, culture, initialValue, targetType);
				return ConvertUtils.ConvertResult.Success;
			}
			TypeConverter converter2 = ConvertUtils.GetConverter(targetType);
			if (converter2 != null && converter2.CanConvertFrom(type))
			{
				value = converter2.ConvertFrom(null, culture, initialValue);
				return ConvertUtils.ConvertResult.Success;
			}
			if (initialValue == DBNull.Value)
			{
				if (ReflectionUtils.IsNullable(targetType))
				{
					value = ConvertUtils.EnsureTypeAssignable(null, type, targetType);
					return ConvertUtils.ConvertResult.Success;
				}
				value = null;
				return ConvertUtils.ConvertResult.CannotConvertNull;
			}
			else
			{
				if (initialValue is INullable)
				{
					value = ConvertUtils.EnsureTypeAssignable(ConvertUtils.ToValue((INullable)initialValue), type, targetType);
					return ConvertUtils.ConvertResult.Success;
				}
				if (!targetType.IsInterface() && !targetType.IsGenericTypeDefinition() && !targetType.IsAbstract())
				{
					value = null;
					return ConvertUtils.ConvertResult.NoValidConversion;
				}
				value = null;
				return ConvertUtils.ConvertResult.NotInstantiableType;
			}
		}

		// Token: 0x060027DC RID: 10204 RVA: 0x000985F8 File Offset: 0x000967F8
		public static object ConvertOrCast(object initialValue, CultureInfo culture, Type targetType)
		{
			if (ConvertUtils.smethod_9(targetType, ConvertUtils.smethod_2(typeof(object).TypeHandle)))
			{
				return initialValue;
			}
			if (initialValue == null && ReflectionUtils.IsNullable(targetType))
			{
				return null;
			}
			object obj;
			if (ConvertUtils.TryConvert(initialValue, culture, targetType, out obj))
			{
				return obj;
			}
			return ConvertUtils.EnsureTypeAssignable(initialValue, ReflectionUtils.GetObjectType(initialValue), targetType);
		}

		// Token: 0x060027DD RID: 10205 RVA: 0x00098644 File Offset: 0x00096844
		private static object EnsureTypeAssignable(object value, Type initialType, Type targetType)
		{
			Type type = ((value == null) ? null : ConvertUtils.smethod_12(value));
			if (value != null)
			{
				if (ConvertUtils.smethod_5(targetType, type))
				{
					return value;
				}
				Func<object, object> func = ConvertUtils.CastConverters.Get(new ConvertUtils.TypeConvertKey(type, targetType));
				if (func != null)
				{
					return func(value);
				}
			}
			else if (ReflectionUtils.IsNullable(targetType))
			{
				return null;
			}
			throw ConvertUtils.smethod_21(<Module>.smethod_24<string>(1775231219U).FormatWith(ConvertUtils.smethod_6(), ConvertUtils.smethod_20(initialType, null) ? ConvertUtils.smethod_17(initialType) : <Module>.smethod_26<string>(1622501346U), targetType));
		}

		// Token: 0x060027DE RID: 10206 RVA: 0x000986C8 File Offset: 0x000968C8
		public static object ToValue(INullable nullableValue)
		{
			if (nullableValue == null)
			{
				return null;
			}
			if (nullableValue is SqlInt32)
			{
				return ConvertUtils.ToValue((SqlInt32)nullableValue);
			}
			if (nullableValue is SqlInt64)
			{
				return ConvertUtils.ToValue((SqlInt64)nullableValue);
			}
			if (nullableValue is SqlBoolean)
			{
				return ConvertUtils.ToValue((SqlBoolean)nullableValue);
			}
			if (nullableValue is SqlString)
			{
				return ConvertUtils.ToValue((SqlString)nullableValue);
			}
			if (!(nullableValue is SqlDateTime))
			{
				throw ConvertUtils.smethod_21(<Module>.smethod_27<string>(2155838117U).FormatWith(ConvertUtils.smethod_6(), ConvertUtils.smethod_12(nullableValue)));
			}
			return ConvertUtils.ToValue((SqlDateTime)nullableValue);
		}

		// Token: 0x060027DF RID: 10207 RVA: 0x0001EAB9 File Offset: 0x0001CCB9
		internal static TypeConverter GetConverter(Type t)
		{
			return JsonTypeReflector.GetTypeConverter(t);
		}

		// Token: 0x060027E0 RID: 10208 RVA: 0x0009877C File Offset: 0x0009697C
		public static bool IsInteger(object value)
		{
			switch (ConvertUtils.GetTypeCode(ConvertUtils.smethod_12(value)))
			{
			case PrimitiveTypeCode.SByte:
			case PrimitiveTypeCode.Int16:
			case PrimitiveTypeCode.UInt16:
			case PrimitiveTypeCode.Int32:
			case PrimitiveTypeCode.Byte:
			case PrimitiveTypeCode.UInt32:
			case PrimitiveTypeCode.Int64:
			case PrimitiveTypeCode.UInt64:
				return true;
			default:
				return false;
			}
		}

		// Token: 0x060027E1 RID: 10209 RVA: 0x000987DC File Offset: 0x000969DC
		public static ParseResult Int32TryParse(char[] chars, int start, int length, out int value)
		{
			value = 0;
			if (length == 0)
			{
				return ParseResult.Invalid;
			}
			bool flag;
			if (flag = chars[start] == '-')
			{
				if (length == 1)
				{
					return ParseResult.Invalid;
				}
				start++;
				length--;
			}
			int num = start + length;
			for (int i = start; i < num; i++)
			{
				int num2 = (int)(chars[i] - '0');
				if (num2 < 0 || num2 > 9)
				{
					return ParseResult.Invalid;
				}
				int num3 = 10 * value - num2;
				if (num3 > value)
				{
					for (i++; i < num; i++)
					{
						num2 = (int)(chars[i] - '0');
						if (num2 < 0 || num2 > 9)
						{
							return ParseResult.Invalid;
						}
					}
					return ParseResult.Overflow;
				}
				value = num3;
			}
			if (!flag)
			{
				if (value == -2147483648)
				{
					return ParseResult.Overflow;
				}
				value = -value;
			}
			return ParseResult.Success;
		}

		// Token: 0x060027E2 RID: 10210 RVA: 0x0009887C File Offset: 0x00096A7C
		public static ParseResult Int64TryParse(char[] chars, int start, int length, out long value)
		{
			value = 0L;
			if (length != 0)
			{
				bool flag;
				if (flag = chars[start] == '-')
				{
					if (length == 1)
					{
						return ParseResult.Invalid;
					}
					start++;
					length--;
				}
				int num = start + length;
				for (int i = start; i < num; i++)
				{
					int num2 = (int)(chars[i] - '0');
					if (num2 < 0 || num2 > 9)
					{
						return ParseResult.Invalid;
					}
					long num3 = 10L * value - (long)num2;
					if (num3 > value)
					{
						for (i++; i < num; i++)
						{
							num2 = (int)(chars[i] - '0');
							if (num2 < 0 || num2 > 9)
							{
								return ParseResult.Invalid;
							}
						}
						return ParseResult.Overflow;
					}
					value = num3;
				}
				if (!flag)
				{
					if (value == -9223372036854775808L)
					{
						return ParseResult.Overflow;
					}
					value = -value;
				}
				return ParseResult.Success;
			}
			return ParseResult.Invalid;
		}

		// Token: 0x060027E3 RID: 10211 RVA: 0x0001EAC1 File Offset: 0x0001CCC1
		public static bool TryConvertGuid(string s, out Guid g)
		{
			return Guid.TryParseExact(s, <Module>.smethod_23<string>(2940082989U), out g);
		}

		// Token: 0x060027E5 RID: 10213 RVA: 0x0001EAD4 File Offset: 0x0001CCD4
		static Type smethod_0(Type type_0)
		{
			return Enum.GetUnderlyingType(type_0);
		}

		// Token: 0x060027E6 RID: 10214 RVA: 0x000175B6 File Offset: 0x000157B6
		static Type smethod_1(Type type_0)
		{
			return Nullable.GetUnderlyingType(type_0);
		}

		// Token: 0x060027E7 RID: 10215 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_2(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060027E8 RID: 10216 RVA: 0x00016303 File Offset: 0x00014503
		static Type smethod_3(Type type_0, Type[] type_1)
		{
			return type_0.MakeGenericType(type_1);
		}

		// Token: 0x060027E9 RID: 10217 RVA: 0x0001EADC File Offset: 0x0001CCDC
		static TypeCode smethod_4(IConvertible iconvertible_0)
		{
			return iconvertible_0.GetTypeCode();
		}

		// Token: 0x060027EA RID: 10218 RVA: 0x00017625 File Offset: 0x00015825
		static bool smethod_5(Type type_0, Type type_1)
		{
			return type_0.IsAssignableFrom(type_1);
		}

		// Token: 0x060027EB RID: 10219 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_6()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060027EC RID: 10220 RVA: 0x0001CA39 File Offset: 0x0001AC39
		static MethodInfo smethod_7(Type type_0, string string_0, Type[] type_1)
		{
			return type_0.GetMethod(string_0, type_1);
		}

		// Token: 0x060027ED RID: 10221 RVA: 0x0001CAFE File Offset: 0x0001ACFE
		static bool smethod_8(MethodInfo methodInfo_0, MethodInfo methodInfo_1)
		{
			return methodInfo_0 == methodInfo_1;
		}

		// Token: 0x060027EE RID: 10222 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_9(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x060027EF RID: 10223 RVA: 0x000193D1 File Offset: 0x000175D1
		static object smethod_10(object object_0, Type type_0, IFormatProvider iformatProvider_0)
		{
			return global::System.Convert.ChangeType(object_0, type_0, iformatProvider_0);
		}

		// Token: 0x060027F0 RID: 10224 RVA: 0x0000DF95 File Offset: 0x0000C195
		static InvalidOperationException smethod_11(string string_0, Exception exception_0)
		{
			return new InvalidOperationException(string_0, exception_0);
		}

		// Token: 0x060027F1 RID: 10225 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_12(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x060027F2 RID: 10226 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_13(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x060027F3 RID: 10227 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_14(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}

		// Token: 0x060027F4 RID: 10228 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_15(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x060027F5 RID: 10229 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_16(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x060027F6 RID: 10230 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_17(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x060027F7 RID: 10231 RVA: 0x00013078 File Offset: 0x00011278
		static object smethod_18(Type type_0, string string_0, bool bool_0)
		{
			return Enum.Parse(type_0, string_0, bool_0);
		}

		// Token: 0x060027F8 RID: 10232 RVA: 0x0001DA29 File Offset: 0x0001BC29
		static object smethod_19(Type type_0, object object_0)
		{
			return Enum.ToObject(type_0, object_0);
		}

		// Token: 0x060027F9 RID: 10233 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_20(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x060027FA RID: 10234 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_21(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x04000E25 RID: 3621
		private static readonly Dictionary<Type, PrimitiveTypeCode> TypeCodeMap = new Dictionary<Type, PrimitiveTypeCode>
		{
			{
				ConvertUtils.smethod_2(typeof(char).TypeHandle),
				PrimitiveTypeCode.Char
			},
			{
				ConvertUtils.smethod_2(typeof(char?).TypeHandle),
				PrimitiveTypeCode.CharNullable
			},
			{
				ConvertUtils.smethod_2(typeof(bool).TypeHandle),
				PrimitiveTypeCode.Boolean
			},
			{
				ConvertUtils.smethod_2(typeof(bool?).TypeHandle),
				PrimitiveTypeCode.BooleanNullable
			},
			{
				ConvertUtils.smethod_2(typeof(sbyte).TypeHandle),
				PrimitiveTypeCode.SByte
			},
			{
				ConvertUtils.smethod_2(typeof(sbyte?).TypeHandle),
				PrimitiveTypeCode.SByteNullable
			},
			{
				ConvertUtils.smethod_2(typeof(short).TypeHandle),
				PrimitiveTypeCode.Int16
			},
			{
				ConvertUtils.smethod_2(typeof(short?).TypeHandle),
				PrimitiveTypeCode.Int16Nullable
			},
			{
				ConvertUtils.smethod_2(typeof(ushort).TypeHandle),
				PrimitiveTypeCode.UInt16
			},
			{
				ConvertUtils.smethod_2(typeof(ushort?).TypeHandle),
				PrimitiveTypeCode.UInt16Nullable
			},
			{
				ConvertUtils.smethod_2(typeof(int).TypeHandle),
				PrimitiveTypeCode.Int32
			},
			{
				ConvertUtils.smethod_2(typeof(int?).TypeHandle),
				PrimitiveTypeCode.Int32Nullable
			},
			{
				ConvertUtils.smethod_2(typeof(byte).TypeHandle),
				PrimitiveTypeCode.Byte
			},
			{
				ConvertUtils.smethod_2(typeof(byte?).TypeHandle),
				PrimitiveTypeCode.ByteNullable
			},
			{
				ConvertUtils.smethod_2(typeof(uint).TypeHandle),
				PrimitiveTypeCode.UInt32
			},
			{
				ConvertUtils.smethod_2(typeof(uint?).TypeHandle),
				PrimitiveTypeCode.UInt32Nullable
			},
			{
				ConvertUtils.smethod_2(typeof(long).TypeHandle),
				PrimitiveTypeCode.Int64
			},
			{
				ConvertUtils.smethod_2(typeof(long?).TypeHandle),
				PrimitiveTypeCode.Int64Nullable
			},
			{
				ConvertUtils.smethod_2(typeof(ulong).TypeHandle),
				PrimitiveTypeCode.UInt64
			},
			{
				ConvertUtils.smethod_2(typeof(ulong?).TypeHandle),
				PrimitiveTypeCode.UInt64Nullable
			},
			{
				ConvertUtils.smethod_2(typeof(float).TypeHandle),
				PrimitiveTypeCode.Single
			},
			{
				ConvertUtils.smethod_2(typeof(float?).TypeHandle),
				PrimitiveTypeCode.SingleNullable
			},
			{
				ConvertUtils.smethod_2(typeof(double).TypeHandle),
				PrimitiveTypeCode.Double
			},
			{
				ConvertUtils.smethod_2(typeof(double?).TypeHandle),
				PrimitiveTypeCode.DoubleNullable
			},
			{
				ConvertUtils.smethod_2(typeof(DateTime).TypeHandle),
				PrimitiveTypeCode.DateTime
			},
			{
				ConvertUtils.smethod_2(typeof(DateTime?).TypeHandle),
				PrimitiveTypeCode.DateTimeNullable
			},
			{
				ConvertUtils.smethod_2(typeof(DateTimeOffset).TypeHandle),
				PrimitiveTypeCode.DateTimeOffset
			},
			{
				ConvertUtils.smethod_2(typeof(DateTimeOffset?).TypeHandle),
				PrimitiveTypeCode.DateTimeOffsetNullable
			},
			{
				ConvertUtils.smethod_2(typeof(decimal).TypeHandle),
				PrimitiveTypeCode.Decimal
			},
			{
				ConvertUtils.smethod_2(typeof(decimal?).TypeHandle),
				PrimitiveTypeCode.DecimalNullable
			},
			{
				ConvertUtils.smethod_2(typeof(Guid).TypeHandle),
				PrimitiveTypeCode.Guid
			},
			{
				ConvertUtils.smethod_2(typeof(Guid?).TypeHandle),
				PrimitiveTypeCode.GuidNullable
			},
			{
				ConvertUtils.smethod_2(typeof(TimeSpan).TypeHandle),
				PrimitiveTypeCode.TimeSpan
			},
			{
				ConvertUtils.smethod_2(typeof(TimeSpan?).TypeHandle),
				PrimitiveTypeCode.TimeSpanNullable
			},
			{
				ConvertUtils.smethod_2(typeof(BigInteger).TypeHandle),
				PrimitiveTypeCode.BigInteger
			},
			{
				ConvertUtils.smethod_2(typeof(BigInteger?).TypeHandle),
				PrimitiveTypeCode.BigIntegerNullable
			},
			{
				ConvertUtils.smethod_2(typeof(Uri).TypeHandle),
				PrimitiveTypeCode.Uri
			},
			{
				ConvertUtils.smethod_2(typeof(string).TypeHandle),
				PrimitiveTypeCode.String
			},
			{
				ConvertUtils.smethod_2(typeof(byte[]).TypeHandle),
				PrimitiveTypeCode.Bytes
			},
			{
				ConvertUtils.smethod_2(typeof(DBNull).TypeHandle),
				PrimitiveTypeCode.DBNull
			}
		};

		// Token: 0x04000E26 RID: 3622
		private static readonly TypeInformation[] PrimitiveTypeCodes = new TypeInformation[]
		{
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(object).TypeHandle),
				TypeCode = PrimitiveTypeCode.Empty
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(object).TypeHandle),
				TypeCode = PrimitiveTypeCode.Object
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(object).TypeHandle),
				TypeCode = PrimitiveTypeCode.DBNull
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(bool).TypeHandle),
				TypeCode = PrimitiveTypeCode.Boolean
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(char).TypeHandle),
				TypeCode = PrimitiveTypeCode.Char
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(sbyte).TypeHandle),
				TypeCode = PrimitiveTypeCode.SByte
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(byte).TypeHandle),
				TypeCode = PrimitiveTypeCode.Byte
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(short).TypeHandle),
				TypeCode = PrimitiveTypeCode.Int16
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(ushort).TypeHandle),
				TypeCode = PrimitiveTypeCode.UInt16
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(int).TypeHandle),
				TypeCode = PrimitiveTypeCode.Int32
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(uint).TypeHandle),
				TypeCode = PrimitiveTypeCode.UInt32
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(long).TypeHandle),
				TypeCode = PrimitiveTypeCode.Int64
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(ulong).TypeHandle),
				TypeCode = PrimitiveTypeCode.UInt64
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(float).TypeHandle),
				TypeCode = PrimitiveTypeCode.Single
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(double).TypeHandle),
				TypeCode = PrimitiveTypeCode.Double
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(decimal).TypeHandle),
				TypeCode = PrimitiveTypeCode.Decimal
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(DateTime).TypeHandle),
				TypeCode = PrimitiveTypeCode.DateTime
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(object).TypeHandle),
				TypeCode = PrimitiveTypeCode.Empty
			},
			new TypeInformation
			{
				Type = ConvertUtils.smethod_2(typeof(string).TypeHandle),
				TypeCode = PrimitiveTypeCode.String
			}
		};

		// Token: 0x04000E27 RID: 3623
		private static readonly ThreadSafeStore<ConvertUtils.TypeConvertKey, Func<object, object>> CastConverters = new ThreadSafeStore<ConvertUtils.TypeConvertKey, Func<object, object>>(new Func<ConvertUtils.TypeConvertKey, Func<object, object>>(ConvertUtils.CreateCastConverter));

		// Token: 0x020002BD RID: 701
		internal struct TypeConvertKey : IEquatable<ConvertUtils.TypeConvertKey>
		{
			// Token: 0x170005DB RID: 1499
			// (get) Token: 0x060027FB RID: 10235 RVA: 0x0001EAE4 File Offset: 0x0001CCE4
			public Type InitialType
			{
				get
				{
					return this._initialType;
				}
			}

			// Token: 0x170005DC RID: 1500
			// (get) Token: 0x060027FC RID: 10236 RVA: 0x0001EAEC File Offset: 0x0001CCEC
			public Type TargetType
			{
				get
				{
					return this._targetType;
				}
			}

			// Token: 0x060027FD RID: 10237 RVA: 0x0001EAF4 File Offset: 0x0001CCF4
			public TypeConvertKey(Type initialType, Type targetType)
			{
				this._initialType = initialType;
				this._targetType = targetType;
			}

			// Token: 0x060027FE RID: 10238 RVA: 0x0001EB04 File Offset: 0x0001CD04
			public override int GetHashCode()
			{
				return ConvertUtils.TypeConvertKey.smethod_0(this._initialType) ^ ConvertUtils.TypeConvertKey.smethod_0(this._targetType);
			}

			// Token: 0x060027FF RID: 10239 RVA: 0x0001EB1D File Offset: 0x0001CD1D
			public override bool Equals(object obj)
			{
				return obj is ConvertUtils.TypeConvertKey && this.Equals((ConvertUtils.TypeConvertKey)obj);
			}

			// Token: 0x06002800 RID: 10240 RVA: 0x0001EB35 File Offset: 0x0001CD35
			public bool Equals(ConvertUtils.TypeConvertKey other)
			{
				return ConvertUtils.TypeConvertKey.smethod_1(this._initialType, other._initialType) && ConvertUtils.TypeConvertKey.smethod_1(this._targetType, other._targetType);
			}

			// Token: 0x06002801 RID: 10241 RVA: 0x0000CF7A File Offset: 0x0000B17A
			static int smethod_0(object object_0)
			{
				return object_0.GetHashCode();
			}

			// Token: 0x06002802 RID: 10242 RVA: 0x000108AF File Offset: 0x0000EAAF
			static bool smethod_1(Type type_0, Type type_1)
			{
				return type_0 == type_1;
			}

			// Token: 0x04000E28 RID: 3624
			private readonly Type _initialType;

			// Token: 0x04000E29 RID: 3625
			private readonly Type _targetType;
		}

		// Token: 0x020002BE RID: 702
		internal enum ConvertResult
		{
			// Token: 0x04000E2B RID: 3627
			Success,
			// Token: 0x04000E2C RID: 3628
			CannotConvertNull,
			// Token: 0x04000E2D RID: 3629
			NotInstantiableType,
			// Token: 0x04000E2E RID: 3630
			NoValidConversion
		}
	}
}
