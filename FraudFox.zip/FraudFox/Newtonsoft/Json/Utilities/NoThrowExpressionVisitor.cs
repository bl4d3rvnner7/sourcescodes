﻿using System;
using System.Linq.Expressions;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x02000297 RID: 663
	internal class NoThrowExpressionVisitor : ExpressionVisitor
	{
		// Token: 0x0600269C RID: 9884 RVA: 0x0001E388 File Offset: 0x0001C588
		protected override Expression VisitConditional(ConditionalExpression node)
		{
			if (NoThrowExpressionVisitor.smethod_1(NoThrowExpressionVisitor.smethod_0(node)) == ExpressionType.Throw)
			{
				return NoThrowExpressionVisitor.smethod_5(NoThrowExpressionVisitor.smethod_2(node), NoThrowExpressionVisitor.smethod_3(node), NoThrowExpressionVisitor.smethod_4(NoThrowExpressionVisitor.ErrorResult));
			}
			return base.VisitConditional(node);
		}

		// Token: 0x0600269F RID: 9887 RVA: 0x0001E3D0 File Offset: 0x0001C5D0
		static Expression smethod_0(ConditionalExpression conditionalExpression_0)
		{
			return conditionalExpression_0.IfFalse;
		}

		// Token: 0x060026A0 RID: 9888 RVA: 0x0001E3D8 File Offset: 0x0001C5D8
		static ExpressionType smethod_1(Expression expression_0)
		{
			return expression_0.NodeType;
		}

		// Token: 0x060026A1 RID: 9889 RVA: 0x0001E3E0 File Offset: 0x0001C5E0
		static Expression smethod_2(ConditionalExpression conditionalExpression_0)
		{
			return conditionalExpression_0.Test;
		}

		// Token: 0x060026A2 RID: 9890 RVA: 0x0001E3E8 File Offset: 0x0001C5E8
		static Expression smethod_3(ConditionalExpression conditionalExpression_0)
		{
			return conditionalExpression_0.IfTrue;
		}

		// Token: 0x060026A3 RID: 9891 RVA: 0x0001E2F4 File Offset: 0x0001C4F4
		static ConstantExpression smethod_4(object object_0)
		{
			return Expression.Constant(object_0);
		}

		// Token: 0x060026A4 RID: 9892 RVA: 0x0001E3F0 File Offset: 0x0001C5F0
		static ConditionalExpression smethod_5(Expression expression_0, Expression expression_1, Expression expression_2)
		{
			return Expression.Condition(expression_0, expression_1, expression_2);
		}

		// Token: 0x060026A5 RID: 9893 RVA: 0x00013209 File Offset: 0x00011409
		static object smethod_6()
		{
			return new object();
		}

		// Token: 0x04000DAA RID: 3498
		internal static readonly object ErrorResult = NoThrowExpressionVisitor.smethod_6();
	}
}
