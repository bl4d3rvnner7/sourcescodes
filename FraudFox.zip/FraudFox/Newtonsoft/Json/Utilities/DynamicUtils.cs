﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using Newtonsoft.Json.Serialization;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x02000293 RID: 659
	internal static class DynamicUtils
	{
		// Token: 0x06002676 RID: 9846 RVA: 0x00095C58 File Offset: 0x00093E58
		public static IEnumerable<string> GetDynamicMemberNames(this IDynamicMetaObjectProvider dynamicProvider)
		{
			DynamicMetaObject dynamicMetaObject = DynamicUtils.smethod_1(dynamicProvider, DynamicUtils.smethod_0(dynamicProvider));
			return DynamicUtils.smethod_2(dynamicMetaObject);
		}

		// Token: 0x06002677 RID: 9847 RVA: 0x0001E2F4 File Offset: 0x0001C4F4
		static ConstantExpression smethod_0(object object_0)
		{
			return Expression.Constant(object_0);
		}

		// Token: 0x06002678 RID: 9848 RVA: 0x0001E2FC File Offset: 0x0001C4FC
		static DynamicMetaObject smethod_1(IDynamicMetaObjectProvider idynamicMetaObjectProvider_0, Expression expression_0)
		{
			return idynamicMetaObjectProvider_0.GetMetaObject(expression_0);
		}

		// Token: 0x06002679 RID: 9849 RVA: 0x0001E305 File Offset: 0x0001C505
		static IEnumerable<string> smethod_2(DynamicMetaObject dynamicMetaObject_0)
		{
			return dynamicMetaObject_0.GetDynamicMemberNames();
		}

		// Token: 0x02000294 RID: 660
		internal static class BinderWrapper
		{
			// Token: 0x0600267A RID: 9850 RVA: 0x00095C78 File Offset: 0x00093E78
			private static void Init()
			{
				if (!DynamicUtils.BinderWrapper._init)
				{
					Type type = DynamicUtils.BinderWrapper.smethod_0(<Module>.smethod_23<string>(3000840690U), false);
					if (DynamicUtils.BinderWrapper.smethod_1(type, null))
					{
						throw DynamicUtils.BinderWrapper.smethod_3(<Module>.smethod_26<string>(3366985982U).FormatWith(DynamicUtils.BinderWrapper.smethod_2(), <Module>.smethod_23<string>(3000840690U)));
					}
					int[] array = new int[1];
					DynamicUtils.BinderWrapper._getCSharpArgumentInfoArray = DynamicUtils.BinderWrapper.CreateSharpArgumentInfoArray(array);
					DynamicUtils.BinderWrapper._setCSharpArgumentInfoArray = DynamicUtils.BinderWrapper.CreateSharpArgumentInfoArray(new int[] { 0, 3 });
					DynamicUtils.BinderWrapper.CreateMemberCalls();
					DynamicUtils.BinderWrapper._init = true;
				}
			}

			// Token: 0x0600267B RID: 9851 RVA: 0x00095D00 File Offset: 0x00093F00
			private static object CreateSharpArgumentInfoArray(params int[] values)
			{
				Type type = DynamicUtils.BinderWrapper.smethod_4(<Module>.smethod_25<string>(3721742251U));
				Type type2 = DynamicUtils.BinderWrapper.smethod_4(<Module>.smethod_25<string>(1445101092U));
				Array array = DynamicUtils.BinderWrapper.smethod_5(type, values.Length);
				for (int i = 0; i < values.Length; i++)
				{
					MethodInfo methodInfo = DynamicUtils.BinderWrapper.smethod_7(type, <Module>.smethod_24<string>(2612579518U), new Type[]
					{
						type2,
						DynamicUtils.BinderWrapper.smethod_6(typeof(string).TypeHandle)
					});
					MethodBase methodBase = methodInfo;
					object obj = null;
					object[] array2 = new object[2];
					array2[0] = 0;
					object obj2 = DynamicUtils.BinderWrapper.smethod_8(methodBase, obj, array2);
					DynamicUtils.BinderWrapper.smethod_9(array, obj2, i);
				}
				return array;
			}

			// Token: 0x0600267C RID: 9852 RVA: 0x00095DA4 File Offset: 0x00093FA4
			private static void CreateMemberCalls()
			{
				Type type = DynamicUtils.BinderWrapper.smethod_0(<Module>.smethod_24<string>(12124969U), true);
				Type type2 = DynamicUtils.BinderWrapper.smethod_0(<Module>.smethod_24<string>(2206099707U), true);
				Type type3 = DynamicUtils.BinderWrapper.smethod_0(<Module>.smethod_23<string>(3000840690U), true);
				Type type4 = DynamicUtils.BinderWrapper.smethod_10(DynamicUtils.BinderWrapper.smethod_6(typeof(IEnumerable<>).TypeHandle), new Type[] { type });
				MethodInfo methodInfo = DynamicUtils.BinderWrapper.smethod_7(type3, <Module>.smethod_25<string>(1703416114U), new Type[]
				{
					type2,
					DynamicUtils.BinderWrapper.smethod_6(typeof(string).TypeHandle),
					DynamicUtils.BinderWrapper.smethod_6(typeof(Type).TypeHandle),
					type4
				});
				DynamicUtils.BinderWrapper._getMemberCall = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>(methodInfo);
				MethodInfo methodInfo2 = DynamicUtils.BinderWrapper.smethod_7(type3, <Module>.smethod_26<string>(1243443319U), new Type[]
				{
					type2,
					DynamicUtils.BinderWrapper.smethod_6(typeof(string).TypeHandle),
					DynamicUtils.BinderWrapper.smethod_6(typeof(Type).TypeHandle),
					type4
				});
				DynamicUtils.BinderWrapper._setMemberCall = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>(methodInfo2);
			}

			// Token: 0x0600267D RID: 9853 RVA: 0x00095ED0 File Offset: 0x000940D0
			public static CallSiteBinder GetMember(string name, Type context)
			{
				DynamicUtils.BinderWrapper.Init();
				return (CallSiteBinder)DynamicUtils.BinderWrapper._getMemberCall(null, new object[]
				{
					0,
					name,
					context,
					DynamicUtils.BinderWrapper._getCSharpArgumentInfoArray
				});
			}

			// Token: 0x0600267E RID: 9854 RVA: 0x00095F14 File Offset: 0x00094114
			public static CallSiteBinder SetMember(string name, Type context)
			{
				DynamicUtils.BinderWrapper.Init();
				return (CallSiteBinder)DynamicUtils.BinderWrapper._setMemberCall(null, new object[]
				{
					0,
					name,
					context,
					DynamicUtils.BinderWrapper._setCSharpArgumentInfoArray
				});
			}

			// Token: 0x0600267F RID: 9855 RVA: 0x0001E30D File Offset: 0x0001C50D
			static Type smethod_0(string string_0, bool bool_0)
			{
				return Type.GetType(string_0, bool_0);
			}

			// Token: 0x06002680 RID: 9856 RVA: 0x000108AF File Offset: 0x0000EAAF
			static bool smethod_1(Type type_0, Type type_1)
			{
				return type_0 == type_1;
			}

			// Token: 0x06002681 RID: 9857 RVA: 0x0000CDAA File Offset: 0x0000AFAA
			static CultureInfo smethod_2()
			{
				return CultureInfo.InvariantCulture;
			}

			// Token: 0x06002682 RID: 9858 RVA: 0x0000D015 File Offset: 0x0000B215
			static InvalidOperationException smethod_3(string string_0)
			{
				return new InvalidOperationException(string_0);
			}

			// Token: 0x06002683 RID: 9859 RVA: 0x00017809 File Offset: 0x00015A09
			static Type smethod_4(string string_0)
			{
				return Type.GetType(string_0);
			}

			// Token: 0x06002684 RID: 9860 RVA: 0x000162DF File Offset: 0x000144DF
			static Array smethod_5(Type type_0, int int_0)
			{
				return Array.CreateInstance(type_0, int_0);
			}

			// Token: 0x06002685 RID: 9861 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
			static Type smethod_6(RuntimeTypeHandle runtimeTypeHandle_0)
			{
				return Type.GetTypeFromHandle(runtimeTypeHandle_0);
			}

			// Token: 0x06002686 RID: 9862 RVA: 0x0001CA39 File Offset: 0x0001AC39
			static MethodInfo smethod_7(Type type_0, string string_0, Type[] type_1)
			{
				return type_0.GetMethod(string_0, type_1);
			}

			// Token: 0x06002687 RID: 9863 RVA: 0x0001839E File Offset: 0x0001659E
			static object smethod_8(MethodBase methodBase_0, object object_0, object[] object_1)
			{
				return methodBase_0.Invoke(object_0, object_1);
			}

			// Token: 0x06002688 RID: 9864 RVA: 0x000162F9 File Offset: 0x000144F9
			static void smethod_9(Array array_0, object object_0, int int_0)
			{
				array_0.SetValue(object_0, int_0);
			}

			// Token: 0x06002689 RID: 9865 RVA: 0x00016303 File Offset: 0x00014503
			static Type smethod_10(Type type_0, Type[] type_1)
			{
				return type_0.MakeGenericType(type_1);
			}

			// Token: 0x04000D9E RID: 3486
			public const string CSharpAssemblyName = "Microsoft.CSharp, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a";

			// Token: 0x04000D9F RID: 3487
			private const string BinderTypeName = "Microsoft.CSharp.RuntimeBinder.Binder, Microsoft.CSharp, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a";

			// Token: 0x04000DA0 RID: 3488
			private const string CSharpArgumentInfoTypeName = "Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo, Microsoft.CSharp, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a";

			// Token: 0x04000DA1 RID: 3489
			private const string CSharpArgumentInfoFlagsTypeName = "Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags, Microsoft.CSharp, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a";

			// Token: 0x04000DA2 RID: 3490
			private const string CSharpBinderFlagsTypeName = "Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags, Microsoft.CSharp, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a";

			// Token: 0x04000DA3 RID: 3491
			private static object _getCSharpArgumentInfoArray;

			// Token: 0x04000DA4 RID: 3492
			private static object _setCSharpArgumentInfoArray;

			// Token: 0x04000DA5 RID: 3493
			private static MethodCall<object, object> _getMemberCall;

			// Token: 0x04000DA6 RID: 3494
			private static MethodCall<object, object> _setMemberCall;

			// Token: 0x04000DA7 RID: 3495
			private static bool _init;
		}
	}
}
