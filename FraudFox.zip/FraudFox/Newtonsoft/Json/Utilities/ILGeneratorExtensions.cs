﻿using System;
using System.Reflection;
using System.Reflection.Emit;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002A3 RID: 675
	internal static class ILGeneratorExtensions
	{
		// Token: 0x0600275D RID: 10077 RVA: 0x0001E6C2 File Offset: 0x0001C8C2
		public static void PushInstance(this ILGenerator generator, Type type)
		{
			ILGeneratorExtensions.smethod_0(generator, OpCodes.Ldarg_0);
			if (type.IsValueType())
			{
				ILGeneratorExtensions.smethod_1(generator, OpCodes.Unbox, type);
				return;
			}
			ILGeneratorExtensions.smethod_1(generator, OpCodes.Castclass, type);
		}

		// Token: 0x0600275E RID: 10078 RVA: 0x0001E6F0 File Offset: 0x0001C8F0
		public static void PushArrayInstance(this ILGenerator generator, int argsIndex, int arrayIndex)
		{
			ILGeneratorExtensions.smethod_2(generator, OpCodes.Ldarg, argsIndex);
			ILGeneratorExtensions.smethod_2(generator, OpCodes.Ldc_I4, arrayIndex);
			ILGeneratorExtensions.smethod_0(generator, OpCodes.Ldelem_Ref);
		}

		// Token: 0x0600275F RID: 10079 RVA: 0x0001E715 File Offset: 0x0001C915
		public static void BoxIfNeeded(this ILGenerator generator, Type type)
		{
			if (type.IsValueType())
			{
				ILGeneratorExtensions.smethod_1(generator, OpCodes.Box, type);
				return;
			}
			ILGeneratorExtensions.smethod_1(generator, OpCodes.Castclass, type);
		}

		// Token: 0x06002760 RID: 10080 RVA: 0x0001E738 File Offset: 0x0001C938
		public static void UnboxIfNeeded(this ILGenerator generator, Type type)
		{
			if (type.IsValueType())
			{
				ILGeneratorExtensions.smethod_1(generator, OpCodes.Unbox_Any, type);
				return;
			}
			ILGeneratorExtensions.smethod_1(generator, OpCodes.Castclass, type);
		}

		// Token: 0x06002761 RID: 10081 RVA: 0x0001E75B File Offset: 0x0001C95B
		public static void CallMethod(this ILGenerator generator, MethodInfo methodInfo)
		{
			if (!ILGeneratorExtensions.smethod_3(methodInfo) && ILGeneratorExtensions.smethod_4(methodInfo))
			{
				ILGeneratorExtensions.smethod_5(generator, OpCodes.Callvirt, methodInfo);
				return;
			}
			ILGeneratorExtensions.smethod_5(generator, OpCodes.Call, methodInfo);
		}

		// Token: 0x06002762 RID: 10082 RVA: 0x0001E786 File Offset: 0x0001C986
		public static void Return(this ILGenerator generator)
		{
			ILGeneratorExtensions.smethod_0(generator, OpCodes.Ret);
		}

		// Token: 0x06002763 RID: 10083 RVA: 0x0001E453 File Offset: 0x0001C653
		static void smethod_0(ILGenerator ilgenerator_0, OpCode opCode_0)
		{
			ilgenerator_0.Emit(opCode_0);
		}

		// Token: 0x06002764 RID: 10084 RVA: 0x0001E4B5 File Offset: 0x0001C6B5
		static void smethod_1(ILGenerator ilgenerator_0, OpCode opCode_0, Type type_0)
		{
			ilgenerator_0.Emit(opCode_0, type_0);
		}

		// Token: 0x06002765 RID: 10085 RVA: 0x0001E449 File Offset: 0x0001C649
		static void smethod_2(ILGenerator ilgenerator_0, OpCode opCode_0, int int_0)
		{
			ilgenerator_0.Emit(opCode_0, int_0);
		}

		// Token: 0x06002766 RID: 10086 RVA: 0x0001E793 File Offset: 0x0001C993
		static bool smethod_3(MethodBase methodBase_0)
		{
			return methodBase_0.IsFinal;
		}

		// Token: 0x06002767 RID: 10087 RVA: 0x0001CABE File Offset: 0x0001ACBE
		static bool smethod_4(MethodBase methodBase_0)
		{
			return methodBase_0.IsVirtual;
		}

		// Token: 0x06002768 RID: 10088 RVA: 0x0001E79B File Offset: 0x0001C99B
		static void smethod_5(ILGenerator ilgenerator_0, OpCode opCode_0, MethodInfo methodInfo_0)
		{
			ilgenerator_0.Emit(opCode_0, methodInfo_0);
		}
	}
}
