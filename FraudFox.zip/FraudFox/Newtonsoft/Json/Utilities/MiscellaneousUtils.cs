﻿using System;
using System.Globalization;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002CE RID: 718
	internal static class MiscellaneousUtils
	{
		// Token: 0x060028F0 RID: 10480 RVA: 0x0009AF74 File Offset: 0x00099174
		public static bool ValueEquals(object objA, object objB)
		{
			if (objA == null && objB == null)
			{
				return true;
			}
			if (objA != null && objB == null)
			{
				return false;
			}
			if (objA == null && objB != null)
			{
				return false;
			}
			if (!MiscellaneousUtils.smethod_1(MiscellaneousUtils.smethod_0(objA), MiscellaneousUtils.smethod_0(objB)))
			{
				return objA.Equals(objB);
			}
			if (ConvertUtils.IsInteger(objA) && ConvertUtils.IsInteger(objB))
			{
				return MiscellaneousUtils.smethod_3(objA, MiscellaneousUtils.smethod_2()).Equals(MiscellaneousUtils.smethod_3(objB, MiscellaneousUtils.smethod_2()));
			}
			return (objA is double || objA is float || objA is decimal) && (objB is double || objB is float || objB is decimal) && MathUtils.ApproxEquals(Convert.ToDouble(objA, CultureInfo.CurrentCulture), Convert.ToDouble(objB, CultureInfo.CurrentCulture));
		}

		// Token: 0x060028F1 RID: 10481 RVA: 0x0009B030 File Offset: 0x00099230
		public static ArgumentOutOfRangeException CreateArgumentOutOfRangeException(string paramName, object actualValue, string message)
		{
			string text = MiscellaneousUtils.smethod_6(message, MiscellaneousUtils.smethod_4(), <Module>.smethod_27<string>(3707624249U).FormatWith(MiscellaneousUtils.smethod_5(), actualValue));
			return MiscellaneousUtils.smethod_7(paramName, text);
		}

		// Token: 0x060028F2 RID: 10482 RVA: 0x0009B068 File Offset: 0x00099268
		public static string ToString(object value)
		{
			if (value == null)
			{
				goto IL_004B;
			}
			if (value is string)
			{
				return MiscellaneousUtils.smethod_6(<Module>.smethod_26<string>(1981843186U), MiscellaneousUtils.smethod_8(value), <Module>.smethod_23<string>(2473225630U));
			}
			int num = -525706585;
			IL_0032:
			switch (num ^ -525706586)
			{
			case 0:
				IL_004B:
				num = -525706588;
				goto IL_0032;
			case 2:
				return <Module>.smethod_26<string>(1622501346U);
			}
			return MiscellaneousUtils.smethod_8(value);
		}

		// Token: 0x060028F3 RID: 10483 RVA: 0x0009B0D8 File Offset: 0x000992D8
		public static int ByteArrayCompare(byte[] a1, byte[] a2)
		{
			int num = a1.Length.CompareTo(a2.Length);
			if (num != 0)
			{
				return num;
			}
			for (int i = 0; i < a1.Length; i++)
			{
				int num2 = a1[i].CompareTo(a2[i]);
				if (num2 != 0)
				{
					return num2;
				}
			}
			return 0;
		}

		// Token: 0x060028F4 RID: 10484 RVA: 0x0009B120 File Offset: 0x00099320
		public static string GetPrefix(string qualifiedName)
		{
			string text;
			string text2;
			MiscellaneousUtils.GetQualifiedNameParts(qualifiedName, out text, out text2);
			return text;
		}

		// Token: 0x060028F5 RID: 10485 RVA: 0x0009B138 File Offset: 0x00099338
		public static string GetLocalName(string qualifiedName)
		{
			string text;
			string text2;
			MiscellaneousUtils.GetQualifiedNameParts(qualifiedName, out text, out text2);
			return text2;
		}

		// Token: 0x060028F6 RID: 10486 RVA: 0x0009B150 File Offset: 0x00099350
		public static void GetQualifiedNameParts(string qualifiedName, out string prefix, out string localName)
		{
			int num = MiscellaneousUtils.smethod_9(qualifiedName, ':');
			if (num != -1 && num != 0)
			{
				if (MiscellaneousUtils.smethod_10(qualifiedName) - 1 != num)
				{
					prefix = MiscellaneousUtils.smethod_11(qualifiedName, 0, num);
					localName = MiscellaneousUtils.smethod_12(qualifiedName, num + 1);
					return;
				}
			}
			prefix = null;
			localName = qualifiedName;
		}

		// Token: 0x060028F7 RID: 10487 RVA: 0x0001F652 File Offset: 0x0001D852
		internal static string FormatValueForPrint(object value)
		{
			if (value == null)
			{
				return <Module>.smethod_24<string>(2358021655U);
			}
			if (value is string)
			{
				return MiscellaneousUtils.smethod_13(<Module>.smethod_23<string>(2473225630U), value, <Module>.smethod_26<string>(1981843186U));
			}
			return MiscellaneousUtils.smethod_8(value);
		}

		// Token: 0x060028F8 RID: 10488 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_0(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x060028F9 RID: 10489 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_1(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x060028FA RID: 10490 RVA: 0x00019275 File Offset: 0x00017475
		static CultureInfo smethod_2()
		{
			return CultureInfo.CurrentCulture;
		}

		// Token: 0x060028FB RID: 10491 RVA: 0x00016830 File Offset: 0x00014A30
		static decimal smethod_3(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToDecimal(object_0, iformatProvider_0);
		}

		// Token: 0x060028FC RID: 10492 RVA: 0x0000CD86 File Offset: 0x0000AF86
		static string smethod_4()
		{
			return Environment.NewLine;
		}

		// Token: 0x060028FD RID: 10493 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_5()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060028FE RID: 10494 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_6(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x060028FF RID: 10495 RVA: 0x0000DECA File Offset: 0x0000C0CA
		static ArgumentOutOfRangeException smethod_7(string string_0, string string_1)
		{
			return new ArgumentOutOfRangeException(string_0, string_1);
		}

		// Token: 0x06002900 RID: 10496 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_8(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06002901 RID: 10497 RVA: 0x0000FABD File Offset: 0x0000DCBD
		static int smethod_9(string string_0, char char_0)
		{
			return string_0.IndexOf(char_0);
		}

		// Token: 0x06002902 RID: 10498 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_10(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06002903 RID: 10499 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_11(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x06002904 RID: 10500 RVA: 0x0000D416 File Offset: 0x0000B616
		static string smethod_12(string string_0, int int_0)
		{
			return string_0.Substring(int_0);
		}

		// Token: 0x06002905 RID: 10501 RVA: 0x00016271 File Offset: 0x00014471
		static string smethod_13(object object_0, object object_1, object object_2)
		{
			return object_0 + object_1 + object_2;
		}
	}
}
