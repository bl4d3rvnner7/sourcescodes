﻿using System;
using System.Reflection;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002D4 RID: 724
	internal static class TypeExtensions
	{
		// Token: 0x060029B4 RID: 10676 RVA: 0x0001F9E3 File Offset: 0x0001DBE3
		public static MethodInfo Method(this Delegate d)
		{
			return TypeExtensions.smethod_0(d);
		}

		// Token: 0x060029B5 RID: 10677 RVA: 0x0001F9EB File Offset: 0x0001DBEB
		public static MemberTypes MemberType(this MemberInfo memberInfo)
		{
			return TypeExtensions.smethod_1(memberInfo);
		}

		// Token: 0x060029B6 RID: 10678 RVA: 0x0001F9F3 File Offset: 0x0001DBF3
		public static bool ContainsGenericParameters(this Type type)
		{
			return TypeExtensions.smethod_2(type);
		}

		// Token: 0x060029B7 RID: 10679 RVA: 0x0001F9FB File Offset: 0x0001DBFB
		public static bool IsInterface(this Type type)
		{
			return TypeExtensions.smethod_3(type);
		}

		// Token: 0x060029B8 RID: 10680 RVA: 0x0001FA03 File Offset: 0x0001DC03
		public static bool IsGenericType(this Type type)
		{
			return TypeExtensions.smethod_4(type);
		}

		// Token: 0x060029B9 RID: 10681 RVA: 0x0001FA0B File Offset: 0x0001DC0B
		public static bool IsGenericTypeDefinition(this Type type)
		{
			return TypeExtensions.smethod_5(type);
		}

		// Token: 0x060029BA RID: 10682 RVA: 0x0001FA13 File Offset: 0x0001DC13
		public static Type BaseType(this Type type)
		{
			return TypeExtensions.smethod_6(type);
		}

		// Token: 0x060029BB RID: 10683 RVA: 0x0001FA1B File Offset: 0x0001DC1B
		public static Assembly Assembly(this Type type)
		{
			return TypeExtensions.smethod_7(type);
		}

		// Token: 0x060029BC RID: 10684 RVA: 0x0001FA23 File Offset: 0x0001DC23
		public static bool IsEnum(this Type type)
		{
			return TypeExtensions.smethod_8(type);
		}

		// Token: 0x060029BD RID: 10685 RVA: 0x0001FA2B File Offset: 0x0001DC2B
		public static bool IsClass(this Type type)
		{
			return TypeExtensions.smethod_9(type);
		}

		// Token: 0x060029BE RID: 10686 RVA: 0x0001FA33 File Offset: 0x0001DC33
		public static bool IsSealed(this Type type)
		{
			return TypeExtensions.smethod_10(type);
		}

		// Token: 0x060029BF RID: 10687 RVA: 0x0001FA3B File Offset: 0x0001DC3B
		public static bool IsAbstract(this Type type)
		{
			return TypeExtensions.smethod_11(type);
		}

		// Token: 0x060029C0 RID: 10688 RVA: 0x0001FA43 File Offset: 0x0001DC43
		public static bool IsVisible(this Type type)
		{
			return TypeExtensions.smethod_12(type);
		}

		// Token: 0x060029C1 RID: 10689 RVA: 0x0001FA4B File Offset: 0x0001DC4B
		public static bool IsValueType(this Type type)
		{
			return TypeExtensions.smethod_13(type);
		}

		// Token: 0x060029C2 RID: 10690 RVA: 0x0009C4E0 File Offset: 0x0009A6E0
		public static bool AssignableToTypeName(this Type type, string fullTypeName, out Type match)
		{
			Type type2 = type;
			while (TypeExtensions.smethod_16(type2, null))
			{
				if (TypeExtensions.smethod_15(TypeExtensions.smethod_14(type2), fullTypeName, StringComparison.Ordinal))
				{
					match = type2;
					return true;
				}
				type2 = type2.BaseType();
			}
			foreach (Type type3 in TypeExtensions.smethod_17(type))
			{
				if (TypeExtensions.smethod_15(TypeExtensions.smethod_18(type3), fullTypeName, StringComparison.Ordinal))
				{
					match = type;
					return true;
				}
			}
			match = null;
			return false;
		}

		// Token: 0x060029C3 RID: 10691 RVA: 0x0009C554 File Offset: 0x0009A754
		public static bool AssignableToTypeName(this Type type, string fullTypeName)
		{
			Type type2;
			return type.AssignableToTypeName(fullTypeName, out type2);
		}

		// Token: 0x060029C4 RID: 10692 RVA: 0x0001FA53 File Offset: 0x0001DC53
		static MethodInfo smethod_0(Delegate delegate_0)
		{
			return delegate_0.Method;
		}

		// Token: 0x060029C5 RID: 10693 RVA: 0x0001FA5B File Offset: 0x0001DC5B
		static MemberTypes smethod_1(MemberInfo memberInfo_0)
		{
			return memberInfo_0.MemberType;
		}

		// Token: 0x060029C6 RID: 10694 RVA: 0x0001FA63 File Offset: 0x0001DC63
		static bool smethod_2(Type type_0)
		{
			return type_0.ContainsGenericParameters;
		}

		// Token: 0x060029C7 RID: 10695 RVA: 0x0001FA6B File Offset: 0x0001DC6B
		static bool smethod_3(Type type_0)
		{
			return type_0.IsInterface;
		}

		// Token: 0x060029C8 RID: 10696 RVA: 0x00015F3C File Offset: 0x0001413C
		static bool smethod_4(Type type_0)
		{
			return type_0.IsGenericType;
		}

		// Token: 0x060029C9 RID: 10697 RVA: 0x0001FA73 File Offset: 0x0001DC73
		static bool smethod_5(Type type_0)
		{
			return type_0.IsGenericTypeDefinition;
		}

		// Token: 0x060029CA RID: 10698 RVA: 0x0001FA7B File Offset: 0x0001DC7B
		static Type smethod_6(Type type_0)
		{
			return type_0.BaseType;
		}

		// Token: 0x060029CB RID: 10699 RVA: 0x0000DD49 File Offset: 0x0000BF49
		static Assembly smethod_7(Type type_0)
		{
			return type_0.Assembly;
		}

		// Token: 0x060029CC RID: 10700 RVA: 0x00015F24 File Offset: 0x00014124
		static bool smethod_8(Type type_0)
		{
			return type_0.IsEnum;
		}

		// Token: 0x060029CD RID: 10701 RVA: 0x0001FA83 File Offset: 0x0001DC83
		static bool smethod_9(Type type_0)
		{
			return type_0.IsClass;
		}

		// Token: 0x060029CE RID: 10702 RVA: 0x0001FA8B File Offset: 0x0001DC8B
		static bool smethod_10(Type type_0)
		{
			return type_0.IsSealed;
		}

		// Token: 0x060029CF RID: 10703 RVA: 0x0001FA93 File Offset: 0x0001DC93
		static bool smethod_11(Type type_0)
		{
			return type_0.IsAbstract;
		}

		// Token: 0x060029D0 RID: 10704 RVA: 0x0001FA9B File Offset: 0x0001DC9B
		static bool smethod_12(Type type_0)
		{
			return type_0.IsVisible;
		}

		// Token: 0x060029D1 RID: 10705 RVA: 0x0001FAA3 File Offset: 0x0001DCA3
		static bool smethod_13(Type type_0)
		{
			return type_0.IsValueType;
		}

		// Token: 0x060029D2 RID: 10706 RVA: 0x00017761 File Offset: 0x00015961
		static string smethod_14(Type type_0)
		{
			return type_0.FullName;
		}

		// Token: 0x060029D3 RID: 10707 RVA: 0x000170FF File Offset: 0x000152FF
		static bool smethod_15(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string.Equals(string_0, string_1, stringComparison_0);
		}

		// Token: 0x060029D4 RID: 10708 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_16(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x060029D5 RID: 10709 RVA: 0x0001DF78 File Offset: 0x0001C178
		static Type[] smethod_17(Type type_0)
		{
			return type_0.GetInterfaces();
		}

		// Token: 0x060029D6 RID: 10710 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_18(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}
	}
}
