﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;
using Newtonsoft.Json.Serialization;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x0200029C RID: 668
	internal class ExpressionReflectionDelegateFactory : ReflectionDelegateFactory
	{
		// Token: 0x170005C5 RID: 1477
		// (get) Token: 0x060026F6 RID: 9974 RVA: 0x0001E505 File Offset: 0x0001C705
		internal static ReflectionDelegateFactory Instance
		{
			get
			{
				return ExpressionReflectionDelegateFactory._instance;
			}
		}

		// Token: 0x060026F7 RID: 9975 RVA: 0x000968FC File Offset: 0x00094AFC
		public override ObjectConstructor<object> CreateParametrizedConstructor(MethodBase method)
		{
			ValidationUtils.ArgumentNotNull(method, <Module>.smethod_26<string>(3771792987U));
			Type type = ExpressionReflectionDelegateFactory.smethod_4(typeof(object).TypeHandle);
			ParameterExpression parameterExpression = ExpressionReflectionDelegateFactory.smethod_5(ExpressionReflectionDelegateFactory.smethod_4(typeof(object[]).TypeHandle), <Module>.smethod_26<string>(3472326316U));
			Expression expression = this.BuildMethodCall(method, type, null, parameterExpression);
			LambdaExpression lambdaExpression = ExpressionReflectionDelegateFactory.smethod_6(ExpressionReflectionDelegateFactory.smethod_4(typeof(ObjectConstructor<object>).TypeHandle), expression, new ParameterExpression[] { parameterExpression });
			return (ObjectConstructor<object>)ExpressionReflectionDelegateFactory.smethod_7(lambdaExpression);
		}

		// Token: 0x060026F8 RID: 9976 RVA: 0x0009697C File Offset: 0x00094B7C
		public override MethodCall<T, object> CreateMethodCall<T>(MethodBase method)
		{
			ValidationUtils.ArgumentNotNull(method, <Module>.smethod_24<string>(2835135268U));
			Type type = ExpressionReflectionDelegateFactory.smethod_4(typeof(object).TypeHandle);
			ParameterExpression parameterExpression = ExpressionReflectionDelegateFactory.smethod_5(type, <Module>.smethod_27<string>(4286646050U));
			ParameterExpression parameterExpression2 = ExpressionReflectionDelegateFactory.smethod_5(ExpressionReflectionDelegateFactory.smethod_4(typeof(object[]).TypeHandle), <Module>.smethod_25<string>(1335354059U));
			Expression expression = this.BuildMethodCall(method, type, parameterExpression, parameterExpression2);
			LambdaExpression lambdaExpression = ExpressionReflectionDelegateFactory.smethod_6(ExpressionReflectionDelegateFactory.smethod_4(typeof(MethodCall<T, object>).TypeHandle), expression, new ParameterExpression[] { parameterExpression, parameterExpression2 });
			return (MethodCall<T, object>)ExpressionReflectionDelegateFactory.smethod_7(lambdaExpression);
		}

		// Token: 0x060026F9 RID: 9977 RVA: 0x00096A18 File Offset: 0x00094C18
		private Expression BuildMethodCall(MethodBase method, Type type, ParameterExpression targetParameterExpression, ParameterExpression argsParameterExpression)
		{
			ParameterInfo[] array = ExpressionReflectionDelegateFactory.smethod_8(method);
			Expression[] array2 = new Expression[array.Length];
			IList<ExpressionReflectionDelegateFactory.ByRefParameter> list = new List<ExpressionReflectionDelegateFactory.ByRefParameter>();
			for (int i = 0; i < array.Length; i++)
			{
				ParameterInfo parameterInfo = array[i];
				Type type2 = ExpressionReflectionDelegateFactory.smethod_9(parameterInfo);
				bool flag = false;
				if (ExpressionReflectionDelegateFactory.smethod_10(type2))
				{
					type2 = ExpressionReflectionDelegateFactory.smethod_11(type2);
					flag = true;
				}
				Expression expression = ExpressionReflectionDelegateFactory.smethod_12(i);
				Expression expression2 = ExpressionReflectionDelegateFactory.smethod_13(argsParameterExpression, expression);
				Expression expression3;
				if (type2.IsValueType())
				{
					BinaryExpression binaryExpression = ExpressionReflectionDelegateFactory.smethod_15(expression2, ExpressionReflectionDelegateFactory.smethod_14(type2));
					expression3 = this.EnsureCastExpression(binaryExpression, type2);
				}
				else
				{
					expression3 = this.EnsureCastExpression(expression2, type2);
				}
				if (flag)
				{
					ParameterExpression parameterExpression = ExpressionReflectionDelegateFactory.smethod_16(type2);
					list.Add(new ExpressionReflectionDelegateFactory.ByRefParameter
					{
						Value = expression3,
						Variable = parameterExpression,
						IsOut = ExpressionReflectionDelegateFactory.smethod_17(parameterInfo)
					});
					expression3 = parameterExpression;
				}
				array2[i] = expression3;
			}
			Expression expression4;
			if (ExpressionReflectionDelegateFactory.smethod_18(method))
			{
				expression4 = ExpressionReflectionDelegateFactory.smethod_19((ConstructorInfo)method, array2);
			}
			else if (ExpressionReflectionDelegateFactory.smethod_20(method))
			{
				expression4 = ExpressionReflectionDelegateFactory.smethod_21((MethodInfo)method, array2);
			}
			else
			{
				Expression expression5 = this.EnsureCastExpression(targetParameterExpression, ExpressionReflectionDelegateFactory.smethod_22(method));
				expression4 = ExpressionReflectionDelegateFactory.smethod_23(expression5, (MethodInfo)method, array2);
			}
			if (method is MethodInfo)
			{
				MethodInfo methodInfo = (MethodInfo)method;
				if (ExpressionReflectionDelegateFactory.smethod_25(ExpressionReflectionDelegateFactory.smethod_24(methodInfo), ExpressionReflectionDelegateFactory.smethod_4(typeof(void).TypeHandle)))
				{
					expression4 = this.EnsureCastExpression(expression4, type);
				}
				else
				{
					expression4 = ExpressionReflectionDelegateFactory.smethod_26(expression4, ExpressionReflectionDelegateFactory.smethod_12(null));
				}
			}
			else
			{
				expression4 = this.EnsureCastExpression(expression4, type);
			}
			if (list.Count > 0)
			{
				IList<ParameterExpression> list2 = new List<ParameterExpression>();
				IList<Expression> list3 = new List<Expression>();
				IEnumerator<ExpressionReflectionDelegateFactory.ByRefParameter> enumerator = list.GetEnumerator();
				try
				{
					while (ExpressionReflectionDelegateFactory.smethod_28(enumerator))
					{
						ExpressionReflectionDelegateFactory.ByRefParameter byRefParameter = enumerator.Current;
						if (!byRefParameter.IsOut)
						{
							list3.Add(ExpressionReflectionDelegateFactory.smethod_27(byRefParameter.Variable, byRefParameter.Value));
						}
						list2.Add(byRefParameter.Variable);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						ExpressionReflectionDelegateFactory.smethod_29(enumerator);
					}
				}
				list3.Add(expression4);
				expression4 = ExpressionReflectionDelegateFactory.smethod_30(list2, list3);
			}
			return expression4;
		}

		// Token: 0x060026FA RID: 9978 RVA: 0x00096C48 File Offset: 0x00094E48
		public override Func<T> CreateDefaultConstructor<T>(Type type)
		{
			Func<T> func = null;
			ValidationUtils.ArgumentNotNull(type, <Module>.smethod_24<string>(1347420388U));
			if (type.IsAbstract())
			{
				return () => (T)((object)ExpressionReflectionDelegateFactory.<>c__DisplayClass4<T>.smethod_0(type));
			}
			Func<T> func3;
			try
			{
				Type type2 = ExpressionReflectionDelegateFactory.smethod_4(typeof(T).TypeHandle);
				Expression expression = ExpressionReflectionDelegateFactory.smethod_14(type);
				expression = this.EnsureCastExpression(expression, type2);
				LambdaExpression lambdaExpression = ExpressionReflectionDelegateFactory.smethod_6(ExpressionReflectionDelegateFactory.smethod_4(typeof(Func<T>).TypeHandle), expression, new ParameterExpression[0]);
				Func<T> func2 = (Func<T>)ExpressionReflectionDelegateFactory.smethod_7(lambdaExpression);
				func3 = func2;
			}
			catch
			{
				for (;;)
				{
					IL_00CF:
					int num = -153794098;
					for (;;)
					{
						switch (num ^ -153794097)
						{
						case 0:
							goto IL_00CF;
						case 1:
							num = ((func == null) ? (-153794100) : (-153794099));
							continue;
						case 3:
							func = () => (T)((object)ExpressionReflectionDelegateFactory.<>c__DisplayClass4<T>.smethod_0(type));
							num = -153794099;
							continue;
						}
						goto Block_4;
					}
				}
				Block_4:
				func3 = func;
			}
			return func3;
		}

		// Token: 0x060026FB RID: 9979 RVA: 0x00096D44 File Offset: 0x00094F44
		public override Func<T, object> CreateGet<T>(PropertyInfo propertyInfo)
		{
			ValidationUtils.ArgumentNotNull(propertyInfo, <Module>.smethod_25<string>(1196159153U));
			Type type = ExpressionReflectionDelegateFactory.smethod_4(typeof(T).TypeHandle);
			Type type2 = ExpressionReflectionDelegateFactory.smethod_4(typeof(object).TypeHandle);
			ParameterExpression parameterExpression = ExpressionReflectionDelegateFactory.smethod_5(type, <Module>.smethod_24<string>(212824271U));
			MethodInfo methodInfo = ExpressionReflectionDelegateFactory.smethod_31(propertyInfo, true);
			Expression expression2;
			if (!ExpressionReflectionDelegateFactory.smethod_20(methodInfo))
			{
				Expression expression = this.EnsureCastExpression(parameterExpression, ExpressionReflectionDelegateFactory.smethod_22(propertyInfo));
				expression2 = ExpressionReflectionDelegateFactory.smethod_32(expression, propertyInfo);
			}
			else
			{
				expression2 = ExpressionReflectionDelegateFactory.smethod_32(null, propertyInfo);
			}
			expression2 = this.EnsureCastExpression(expression2, type2);
			LambdaExpression lambdaExpression = ExpressionReflectionDelegateFactory.smethod_6(ExpressionReflectionDelegateFactory.smethod_4(typeof(Func<T, object>).TypeHandle), expression2, new ParameterExpression[] { parameterExpression });
			return (Func<T, object>)ExpressionReflectionDelegateFactory.smethod_7(lambdaExpression);
		}

		// Token: 0x060026FC RID: 9980 RVA: 0x00096E00 File Offset: 0x00095000
		public override Func<T, object> CreateGet<T>(FieldInfo fieldInfo)
		{
			ValidationUtils.ArgumentNotNull(fieldInfo, <Module>.smethod_25<string>(1822536230U));
			ParameterExpression parameterExpression = ExpressionReflectionDelegateFactory.smethod_5(ExpressionReflectionDelegateFactory.smethod_4(typeof(T).TypeHandle), <Module>.smethod_25<string>(394423462U));
			Expression expression;
			if (ExpressionReflectionDelegateFactory.smethod_33(fieldInfo))
			{
				expression = ExpressionReflectionDelegateFactory.smethod_34(null, fieldInfo);
			}
			else
			{
				Expression expression2 = this.EnsureCastExpression(parameterExpression, ExpressionReflectionDelegateFactory.smethod_22(fieldInfo));
				expression = ExpressionReflectionDelegateFactory.smethod_34(expression2, fieldInfo);
			}
			expression = this.EnsureCastExpression(expression, ExpressionReflectionDelegateFactory.smethod_4(typeof(object).TypeHandle));
			return Expression.Lambda<Func<T, object>>(expression, new ParameterExpression[] { parameterExpression }).Compile();
		}

		// Token: 0x060026FD RID: 9981 RVA: 0x00096E90 File Offset: 0x00095090
		public override Action<T, object> CreateSet<T>(FieldInfo fieldInfo)
		{
			ValidationUtils.ArgumentNotNull(fieldInfo, <Module>.smethod_26<string>(4196134527U));
			if (!ExpressionReflectionDelegateFactory.smethod_22(fieldInfo).IsValueType() && !ExpressionReflectionDelegateFactory.smethod_35(fieldInfo))
			{
				ParameterExpression parameterExpression = ExpressionReflectionDelegateFactory.smethod_5(ExpressionReflectionDelegateFactory.smethod_4(typeof(T).TypeHandle), <Module>.smethod_26<string>(1736673023U));
				ParameterExpression parameterExpression2 = ExpressionReflectionDelegateFactory.smethod_5(ExpressionReflectionDelegateFactory.smethod_4(typeof(object).TypeHandle), <Module>.smethod_26<string>(1806306238U));
				Expression expression;
				if (ExpressionReflectionDelegateFactory.smethod_33(fieldInfo))
				{
					expression = ExpressionReflectionDelegateFactory.smethod_34(null, fieldInfo);
				}
				else
				{
					Expression expression2 = this.EnsureCastExpression(parameterExpression, ExpressionReflectionDelegateFactory.smethod_22(fieldInfo));
					expression = ExpressionReflectionDelegateFactory.smethod_34(expression2, fieldInfo);
				}
				Expression expression3 = this.EnsureCastExpression(parameterExpression2, ExpressionReflectionDelegateFactory.smethod_36(expression));
				BinaryExpression binaryExpression = ExpressionReflectionDelegateFactory.smethod_27(expression, expression3);
				LambdaExpression lambdaExpression = ExpressionReflectionDelegateFactory.smethod_6(ExpressionReflectionDelegateFactory.smethod_4(typeof(Action<T, object>).TypeHandle), binaryExpression, new ParameterExpression[] { parameterExpression, parameterExpression2 });
				return (Action<T, object>)ExpressionReflectionDelegateFactory.smethod_7(lambdaExpression);
			}
			return LateBoundReflectionDelegateFactory.Instance.CreateSet<T>(fieldInfo);
		}

		// Token: 0x060026FE RID: 9982 RVA: 0x00096F88 File Offset: 0x00095188
		public override Action<T, object> CreateSet<T>(PropertyInfo propertyInfo)
		{
			ValidationUtils.ArgumentNotNull(propertyInfo, <Module>.smethod_27<string>(3152208290U));
			if (ExpressionReflectionDelegateFactory.smethod_22(propertyInfo).IsValueType())
			{
				return LateBoundReflectionDelegateFactory.Instance.CreateSet<T>(propertyInfo);
			}
			Type type = ExpressionReflectionDelegateFactory.smethod_4(typeof(T).TypeHandle);
			Type type2 = ExpressionReflectionDelegateFactory.smethod_4(typeof(object).TypeHandle);
			ParameterExpression parameterExpression = ExpressionReflectionDelegateFactory.smethod_5(type, <Module>.smethod_25<string>(917769341U));
			ParameterExpression parameterExpression2 = ExpressionReflectionDelegateFactory.smethod_5(type2, <Module>.smethod_25<string>(3622406065U));
			Expression expression = this.EnsureCastExpression(parameterExpression2, ExpressionReflectionDelegateFactory.smethod_37(propertyInfo));
			MethodInfo methodInfo = ExpressionReflectionDelegateFactory.smethod_38(propertyInfo, true);
			Expression expression3;
			if (!ExpressionReflectionDelegateFactory.smethod_20(methodInfo))
			{
				Expression expression2 = this.EnsureCastExpression(parameterExpression, ExpressionReflectionDelegateFactory.smethod_22(propertyInfo));
				expression3 = ExpressionReflectionDelegateFactory.smethod_23(expression2, methodInfo, new Expression[] { expression });
			}
			else
			{
				expression3 = ExpressionReflectionDelegateFactory.smethod_39(methodInfo, expression);
			}
			LambdaExpression lambdaExpression = ExpressionReflectionDelegateFactory.smethod_6(ExpressionReflectionDelegateFactory.smethod_4(typeof(Action<T, object>).TypeHandle), expression3, new ParameterExpression[] { parameterExpression, parameterExpression2 });
			return (Action<T, object>)ExpressionReflectionDelegateFactory.smethod_7(lambdaExpression);
		}

		// Token: 0x060026FF RID: 9983 RVA: 0x00097094 File Offset: 0x00095294
		private Expression EnsureCastExpression(Expression expression, Type targetType)
		{
			Type type = ExpressionReflectionDelegateFactory.smethod_36(expression);
			if (!ExpressionReflectionDelegateFactory.smethod_40(type, targetType) && (type.IsValueType() || !ExpressionReflectionDelegateFactory.smethod_41(targetType, type)))
			{
				return ExpressionReflectionDelegateFactory.smethod_42(expression, targetType);
			}
			return expression;
		}

		// Token: 0x06002702 RID: 9986 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_4(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06002703 RID: 9987 RVA: 0x0001E518 File Offset: 0x0001C718
		static ParameterExpression smethod_5(Type type_0, string string_0)
		{
			return Expression.Parameter(type_0, string_0);
		}

		// Token: 0x06002704 RID: 9988 RVA: 0x0001E521 File Offset: 0x0001C721
		static LambdaExpression smethod_6(Type type_0, Expression expression_0, ParameterExpression[] parameterExpression_0)
		{
			return Expression.Lambda(type_0, expression_0, parameterExpression_0);
		}

		// Token: 0x06002705 RID: 9989 RVA: 0x0001E52B File Offset: 0x0001C72B
		static Delegate smethod_7(LambdaExpression lambdaExpression_0)
		{
			return lambdaExpression_0.Compile();
		}

		// Token: 0x06002706 RID: 9990 RVA: 0x0001CA54 File Offset: 0x0001AC54
		static ParameterInfo[] smethod_8(MethodBase methodBase_0)
		{
			return methodBase_0.GetParameters();
		}

		// Token: 0x06002707 RID: 9991 RVA: 0x0001CA64 File Offset: 0x0001AC64
		static Type smethod_9(ParameterInfo parameterInfo_0)
		{
			return parameterInfo_0.ParameterType;
		}

		// Token: 0x06002708 RID: 9992 RVA: 0x0001E492 File Offset: 0x0001C692
		static bool smethod_10(Type type_0)
		{
			return type_0.IsByRef;
		}

		// Token: 0x06002709 RID: 9993 RVA: 0x00015F34 File Offset: 0x00014134
		static Type smethod_11(Type type_0)
		{
			return type_0.GetElementType();
		}

		// Token: 0x0600270A RID: 9994 RVA: 0x0001E2F4 File Offset: 0x0001C4F4
		static ConstantExpression smethod_12(object object_0)
		{
			return Expression.Constant(object_0);
		}

		// Token: 0x0600270B RID: 9995 RVA: 0x0001E533 File Offset: 0x0001C733
		static BinaryExpression smethod_13(Expression expression_0, Expression expression_1)
		{
			return Expression.ArrayIndex(expression_0, expression_1);
		}

		// Token: 0x0600270C RID: 9996 RVA: 0x0001E53C File Offset: 0x0001C73C
		static NewExpression smethod_14(Type type_0)
		{
			return Expression.New(type_0);
		}

		// Token: 0x0600270D RID: 9997 RVA: 0x0001E544 File Offset: 0x0001C744
		static BinaryExpression smethod_15(Expression expression_0, Expression expression_1)
		{
			return Expression.Coalesce(expression_0, expression_1);
		}

		// Token: 0x0600270E RID: 9998 RVA: 0x0001E54D File Offset: 0x0001C74D
		static ParameterExpression smethod_16(Type type_0)
		{
			return Expression.Variable(type_0);
		}

		// Token: 0x0600270F RID: 9999 RVA: 0x0001E4A3 File Offset: 0x0001C6A3
		static bool smethod_17(ParameterInfo parameterInfo_0)
		{
			return parameterInfo_0.IsOut;
		}

		// Token: 0x06002710 RID: 10000 RVA: 0x0001E482 File Offset: 0x0001C682
		static bool smethod_18(MethodBase methodBase_0)
		{
			return methodBase_0.IsConstructor;
		}

		// Token: 0x06002711 RID: 10001 RVA: 0x0001E555 File Offset: 0x0001C755
		static NewExpression smethod_19(ConstructorInfo constructorInfo_0, Expression[] expression_0)
		{
			return Expression.New(constructorInfo_0, expression_0);
		}

		// Token: 0x06002712 RID: 10002 RVA: 0x0001E48A File Offset: 0x0001C68A
		static bool smethod_20(MethodBase methodBase_0)
		{
			return methodBase_0.IsStatic;
		}

		// Token: 0x06002713 RID: 10003 RVA: 0x0001E55E File Offset: 0x0001C75E
		static MethodCallExpression smethod_21(MethodInfo methodInfo_0, Expression[] expression_0)
		{
			return Expression.Call(methodInfo_0, expression_0);
		}

		// Token: 0x06002714 RID: 10004 RVA: 0x00014858 File Offset: 0x00012A58
		static Type smethod_22(MemberInfo memberInfo_0)
		{
			return memberInfo_0.DeclaringType;
		}

		// Token: 0x06002715 RID: 10005 RVA: 0x0001E567 File Offset: 0x0001C767
		static MethodCallExpression smethod_23(Expression expression_0, MethodInfo methodInfo_0, Expression[] expression_1)
		{
			return Expression.Call(expression_0, methodInfo_0, expression_1);
		}

		// Token: 0x06002716 RID: 10006 RVA: 0x0001CAC6 File Offset: 0x0001ACC6
		static Type smethod_24(MethodInfo methodInfo_0)
		{
			return methodInfo_0.ReturnType;
		}

		// Token: 0x06002717 RID: 10007 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_25(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x06002718 RID: 10008 RVA: 0x0001E571 File Offset: 0x0001C771
		static BlockExpression smethod_26(Expression expression_0, Expression expression_1)
		{
			return Expression.Block(expression_0, expression_1);
		}

		// Token: 0x06002719 RID: 10009 RVA: 0x0001E57A File Offset: 0x0001C77A
		static BinaryExpression smethod_27(Expression expression_0, Expression expression_1)
		{
			return Expression.Assign(expression_0, expression_1);
		}

		// Token: 0x0600271A RID: 10010 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_28(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x0600271B RID: 10011 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_29(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x0600271C RID: 10012 RVA: 0x0001E583 File Offset: 0x0001C783
		static BlockExpression smethod_30(IEnumerable<ParameterExpression> ienumerable_0, IEnumerable<Expression> ienumerable_1)
		{
			return Expression.Block(ienumerable_0, ienumerable_1);
		}

		// Token: 0x0600271D RID: 10013 RVA: 0x0001E4C8 File Offset: 0x0001C6C8
		static MethodInfo smethod_31(PropertyInfo propertyInfo_0, bool bool_0)
		{
			return propertyInfo_0.GetGetMethod(bool_0);
		}

		// Token: 0x0600271E RID: 10014 RVA: 0x0001E58C File Offset: 0x0001C78C
		static MemberExpression smethod_32(Expression expression_0, MemberInfo memberInfo_0)
		{
			return Expression.MakeMemberAccess(expression_0, memberInfo_0);
		}

		// Token: 0x0600271F RID: 10015 RVA: 0x0001CA16 File Offset: 0x0001AC16
		static bool smethod_33(FieldInfo fieldInfo_0)
		{
			return fieldInfo_0.IsStatic;
		}

		// Token: 0x06002720 RID: 10016 RVA: 0x0001E595 File Offset: 0x0001C795
		static MemberExpression smethod_34(Expression expression_0, FieldInfo fieldInfo_0)
		{
			return Expression.Field(expression_0, fieldInfo_0);
		}

		// Token: 0x06002721 RID: 10017 RVA: 0x0001E59E File Offset: 0x0001C79E
		static bool smethod_35(FieldInfo fieldInfo_0)
		{
			return fieldInfo_0.IsInitOnly;
		}

		// Token: 0x06002722 RID: 10018 RVA: 0x0001E5A6 File Offset: 0x0001C7A6
		static Type smethod_36(Expression expression_0)
		{
			return expression_0.Type;
		}

		// Token: 0x06002723 RID: 10019 RVA: 0x000162CE File Offset: 0x000144CE
		static Type smethod_37(PropertyInfo propertyInfo_0)
		{
			return propertyInfo_0.PropertyType;
		}

		// Token: 0x06002724 RID: 10020 RVA: 0x0001E4F4 File Offset: 0x0001C6F4
		static MethodInfo smethod_38(PropertyInfo propertyInfo_0, bool bool_0)
		{
			return propertyInfo_0.GetSetMethod(bool_0);
		}

		// Token: 0x06002725 RID: 10021 RVA: 0x0001E5AE File Offset: 0x0001C7AE
		static MethodCallExpression smethod_39(MethodInfo methodInfo_0, Expression expression_0)
		{
			return Expression.Call(methodInfo_0, expression_0);
		}

		// Token: 0x06002726 RID: 10022 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_40(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x06002727 RID: 10023 RVA: 0x00017625 File Offset: 0x00015825
		static bool smethod_41(Type type_0, Type type_1)
		{
			return type_0.IsAssignableFrom(type_1);
		}

		// Token: 0x06002728 RID: 10024 RVA: 0x0001E5B7 File Offset: 0x0001C7B7
		static UnaryExpression smethod_42(Expression expression_0, Type type_0)
		{
			return Expression.Convert(expression_0, type_0);
		}

		// Token: 0x04000DAD RID: 3501
		private static readonly ExpressionReflectionDelegateFactory _instance = new ExpressionReflectionDelegateFactory();

		// Token: 0x0200029D RID: 669
		private class ByRefParameter
		{
			// Token: 0x04000DAE RID: 3502
			public Expression Value;

			// Token: 0x04000DAF RID: 3503
			public ParameterExpression Variable;

			// Token: 0x04000DB0 RID: 3504
			public bool IsOut;
		}
	}
}
