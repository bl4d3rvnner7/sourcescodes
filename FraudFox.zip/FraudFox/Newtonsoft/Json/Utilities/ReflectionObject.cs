﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json.Serialization;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002B1 RID: 689
	internal class ReflectionObject
	{
		// Token: 0x170005D4 RID: 1492
		// (get) Token: 0x060027A2 RID: 10146 RVA: 0x0001E8ED File Offset: 0x0001CAED
		// (set) Token: 0x060027A3 RID: 10147 RVA: 0x0001E8F5 File Offset: 0x0001CAF5
		public ObjectConstructor<object> Creator { get; private set; }

		// Token: 0x170005D5 RID: 1493
		// (get) Token: 0x060027A4 RID: 10148 RVA: 0x0001E8FE File Offset: 0x0001CAFE
		// (set) Token: 0x060027A5 RID: 10149 RVA: 0x0001E906 File Offset: 0x0001CB06
		public IDictionary<string, ReflectionMember> Members { get; private set; }

		// Token: 0x060027A6 RID: 10150 RVA: 0x0001E90F File Offset: 0x0001CB0F
		public ReflectionObject()
		{
			this.Members = new Dictionary<string, ReflectionMember>();
		}

		// Token: 0x060027A7 RID: 10151 RVA: 0x00097ABC File Offset: 0x00095CBC
		public object GetValue(object target, string member)
		{
			Func<object, object> getter = this.Members[member].Getter;
			return getter(target);
		}

		// Token: 0x060027A8 RID: 10152 RVA: 0x00097AE4 File Offset: 0x00095CE4
		public void SetValue(object target, string member, object value)
		{
			Action<object, object> setter = this.Members[member].Setter;
			setter(target, value);
		}

		// Token: 0x060027A9 RID: 10153 RVA: 0x0001E922 File Offset: 0x0001CB22
		public Type GetType(string member)
		{
			return this.Members[member].MemberType;
		}

		// Token: 0x060027AA RID: 10154 RVA: 0x0001E935 File Offset: 0x0001CB35
		public static ReflectionObject Create(Type t, params string[] memberNames)
		{
			return ReflectionObject.Create(t, null, memberNames);
		}

		// Token: 0x060027AB RID: 10155 RVA: 0x00097B0C File Offset: 0x00095D0C
		public static ReflectionObject Create(Type t, MethodBase creator, params string[] memberNames)
		{
			ReflectionObject reflectionObject = new ReflectionObject();
			ReflectionDelegateFactory reflectionDelegateFactory = JsonTypeReflector.ReflectionDelegateFactory;
			if (ReflectionObject.smethod_0(creator, null))
			{
				reflectionObject.Creator = reflectionDelegateFactory.CreateParametrizedConstructor(creator);
			}
			else if (ReflectionUtils.HasDefaultConstructor(t, false))
			{
				Func<object> ctor = reflectionDelegateFactory.CreateDefaultConstructor<object>(t);
				reflectionObject.Creator = (object[] args) => ctor();
			}
			int i = 0;
			while (i < memberNames.Length)
			{
				string text = memberNames[i];
				MemberInfo[] array = ReflectionObject.smethod_1(t, text, BindingFlags.Instance | BindingFlags.Public);
				if (array.Length != 1)
				{
					throw ReflectionObject.smethod_3(<Module>.smethod_23<string>(3454127573U).FormatWith(ReflectionObject.smethod_2(), text));
				}
				MemberInfo memberInfo = array.Single<MemberInfo>();
				ReflectionMember reflectionMember = new ReflectionMember();
				MemberTypes memberTypes = memberInfo.MemberType();
				if (memberTypes == MemberTypes.Field)
				{
					goto IL_0163;
				}
				if (memberTypes != MemberTypes.Method)
				{
					if (memberTypes == MemberTypes.Property)
					{
						goto IL_0163;
					}
					throw ReflectionObject.smethod_3(<Module>.smethod_27<string>(716337174U).FormatWith(ReflectionObject.smethod_2(), memberInfo.MemberType(), ReflectionObject.smethod_10(memberInfo)));
				}
				else
				{
					MethodInfo methodInfo = (MethodInfo)memberInfo;
					if (ReflectionObject.smethod_4(methodInfo))
					{
						ParameterInfo[] array2 = ReflectionObject.smethod_5(methodInfo);
						if (array2.Length == 0 && ReflectionObject.smethod_8(ReflectionObject.smethod_6(methodInfo), ReflectionObject.smethod_7(typeof(void).TypeHandle)))
						{
							MethodCall<object, object> call2 = reflectionDelegateFactory.CreateMethodCall<object>(methodInfo);
							reflectionMember.Getter = (object target) => call2(target, new object[0]);
						}
						else if (array2.Length == 1 && ReflectionObject.smethod_9(ReflectionObject.smethod_6(methodInfo), ReflectionObject.smethod_7(typeof(void).TypeHandle)))
						{
							MethodCall<object, object> call = reflectionDelegateFactory.CreateMethodCall<object>(methodInfo);
							reflectionMember.Setter = delegate(object target, object arg)
							{
								call(target, new object[] { arg });
							};
						}
					}
				}
				IL_0196:
				if (ReflectionUtils.CanReadMemberValue(memberInfo, false))
				{
					reflectionMember.Getter = reflectionDelegateFactory.CreateGet<object>(memberInfo);
				}
				if (ReflectionUtils.CanSetMemberValue(memberInfo, false, false))
				{
					reflectionMember.Setter = reflectionDelegateFactory.CreateSet<object>(memberInfo);
				}
				reflectionMember.MemberType = ReflectionUtils.GetMemberUnderlyingType(memberInfo);
				reflectionObject.Members[text] = reflectionMember;
				i++;
				continue;
				IL_0163:
				if (ReflectionUtils.CanReadMemberValue(memberInfo, false))
				{
					reflectionMember.Getter = reflectionDelegateFactory.CreateGet<object>(memberInfo);
				}
				if (ReflectionUtils.CanSetMemberValue(memberInfo, false, false))
				{
					reflectionMember.Setter = reflectionDelegateFactory.CreateSet<object>(memberInfo);
					goto IL_0196;
				}
				goto IL_0196;
			}
			return reflectionObject;
		}

		// Token: 0x060027AC RID: 10156 RVA: 0x0001E93F File Offset: 0x0001CB3F
		static bool smethod_0(MethodBase methodBase_0, MethodBase methodBase_1)
		{
			return methodBase_0 != methodBase_1;
		}

		// Token: 0x060027AD RID: 10157 RVA: 0x0001E948 File Offset: 0x0001CB48
		static MemberInfo[] smethod_1(Type type_0, string string_0, BindingFlags bindingFlags_0)
		{
			return type_0.GetMember(string_0, bindingFlags_0);
		}

		// Token: 0x060027AE RID: 10158 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_2()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060027AF RID: 10159 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_3(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x060027B0 RID: 10160 RVA: 0x0001E952 File Offset: 0x0001CB52
		static bool smethod_4(MethodBase methodBase_0)
		{
			return methodBase_0.IsPublic;
		}

		// Token: 0x060027B1 RID: 10161 RVA: 0x0001CA54 File Offset: 0x0001AC54
		static ParameterInfo[] smethod_5(MethodBase methodBase_0)
		{
			return methodBase_0.GetParameters();
		}

		// Token: 0x060027B2 RID: 10162 RVA: 0x0001CAC6 File Offset: 0x0001ACC6
		static Type smethod_6(MethodInfo methodInfo_0)
		{
			return methodInfo_0.ReturnType;
		}

		// Token: 0x060027B3 RID: 10163 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_7(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060027B4 RID: 10164 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_8(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x060027B5 RID: 10165 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_9(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x060027B6 RID: 10166 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_10(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}
	}
}
