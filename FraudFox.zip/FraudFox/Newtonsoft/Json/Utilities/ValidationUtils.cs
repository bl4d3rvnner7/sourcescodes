﻿using System;
using System.Globalization;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002D5 RID: 725
	internal static class ValidationUtils
	{
		// Token: 0x060029D7 RID: 10711 RVA: 0x0001FAAB File Offset: 0x0001DCAB
		public static void ArgumentNotNullOrEmpty(string value, string parameterName)
		{
			if (value == null)
			{
				throw ValidationUtils.smethod_0(parameterName);
			}
			if (ValidationUtils.smethod_1(value) == 0)
			{
				throw ValidationUtils.smethod_3(<Module>.smethod_26<string>(3950310139U).FormatWith(ValidationUtils.smethod_2(), parameterName), parameterName);
			}
		}

		// Token: 0x060029D8 RID: 10712 RVA: 0x0001FADB File Offset: 0x0001DCDB
		public static void ArgumentTypeIsEnum(Type enumType, string parameterName)
		{
			ValidationUtils.ArgumentNotNull(enumType, <Module>.smethod_24<string>(679764304U));
			if (!enumType.IsEnum())
			{
				throw ValidationUtils.smethod_3(<Module>.smethod_26<string>(388727448U).FormatWith(ValidationUtils.smethod_2(), enumType), parameterName);
			}
		}

		// Token: 0x060029D9 RID: 10713 RVA: 0x0001FB11 File Offset: 0x0001DD11
		public static void ArgumentNotNull(object value, string parameterName)
		{
			if (value == null)
			{
				throw ValidationUtils.smethod_0(parameterName);
			}
		}

		// Token: 0x060029DA RID: 10714 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_0(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x060029DB RID: 10715 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_1(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x060029DC RID: 10716 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_2()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060029DD RID: 10717 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_3(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}
	}
}
