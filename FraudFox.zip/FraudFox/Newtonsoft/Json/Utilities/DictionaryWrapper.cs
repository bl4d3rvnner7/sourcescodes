﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002C4 RID: 708
	internal class DictionaryWrapper<TKey, TValue> : IDictionary<TKey, TValue>, ICollection<KeyValuePair<TKey, TValue>>, IEnumerable<KeyValuePair<TKey, TValue>>, IEnumerable, ICollection, IDictionary, IWrappedDictionary
	{
		// Token: 0x06002847 RID: 10311 RVA: 0x0001EF96 File Offset: 0x0001D196
		public DictionaryWrapper(IDictionary dictionary)
		{
			ValidationUtils.ArgumentNotNull(dictionary, <Module>.smethod_23<string>(2684599478U));
			this._dictionary = dictionary;
		}

		// Token: 0x06002848 RID: 10312 RVA: 0x0001EFB5 File Offset: 0x0001D1B5
		public DictionaryWrapper(IDictionary<TKey, TValue> dictionary)
		{
			ValidationUtils.ArgumentNotNull(dictionary, <Module>.smethod_24<string>(2834615423U));
			this._genericDictionary = dictionary;
		}

		// Token: 0x06002849 RID: 10313 RVA: 0x0001EFD4 File Offset: 0x0001D1D4
		public void Add(TKey key, TValue value)
		{
			if (this._dictionary != null)
			{
				DictionaryWrapper<TKey, TValue>.smethod_0(this._dictionary, key, value);
				return;
			}
			if (this._genericDictionary == null)
			{
				throw DictionaryWrapper<TKey, TValue>.smethod_1();
			}
			this._genericDictionary.Add(key, value);
		}

		// Token: 0x0600284A RID: 10314 RVA: 0x0001F011 File Offset: 0x0001D211
		public bool ContainsKey(TKey key)
		{
			if (this._dictionary != null)
			{
				return DictionaryWrapper<TKey, TValue>.smethod_2(this._dictionary, key);
			}
			return this._genericDictionary.ContainsKey(key);
		}

		// Token: 0x170005E6 RID: 1510
		// (get) Token: 0x0600284B RID: 10315 RVA: 0x0001F039 File Offset: 0x0001D239
		public ICollection<TKey> Keys
		{
			get
			{
				if (this._dictionary != null)
				{
					return DictionaryWrapper<TKey, TValue>.smethod_3(this._dictionary).Cast<TKey>().ToList<TKey>();
				}
				return this._genericDictionary.Keys;
			}
		}

		// Token: 0x0600284C RID: 10316 RVA: 0x0001F064 File Offset: 0x0001D264
		public bool Remove(TKey key)
		{
			if (this._dictionary == null)
			{
				return this._genericDictionary.Remove(key);
			}
			if (DictionaryWrapper<TKey, TValue>.smethod_2(this._dictionary, key))
			{
				DictionaryWrapper<TKey, TValue>.smethod_4(this._dictionary, key);
				return true;
			}
			return false;
		}

		// Token: 0x0600284D RID: 10317 RVA: 0x00099AA4 File Offset: 0x00097CA4
		public bool TryGetValue(TKey key, out TValue value)
		{
			if (this._dictionary == null)
			{
				return this._genericDictionary.TryGetValue(key, out value);
			}
			if (!DictionaryWrapper<TKey, TValue>.smethod_2(this._dictionary, key))
			{
				value = default(TValue);
				return false;
			}
			value = (TValue)((object)DictionaryWrapper<TKey, TValue>.smethod_5(this._dictionary, key));
			return true;
		}

		// Token: 0x170005E7 RID: 1511
		// (get) Token: 0x0600284E RID: 10318 RVA: 0x0001F0A2 File Offset: 0x0001D2A2
		public ICollection<TValue> Values
		{
			get
			{
				if (this._dictionary != null)
				{
					return DictionaryWrapper<TKey, TValue>.smethod_6(this._dictionary).Cast<TValue>().ToList<TValue>();
				}
				return this._genericDictionary.Values;
			}
		}

		// Token: 0x170005E8 RID: 1512
		public TValue this[TKey key]
		{
			get
			{
				if (this._dictionary != null)
				{
					return (TValue)((object)DictionaryWrapper<TKey, TValue>.smethod_5(this._dictionary, key));
				}
				return this._genericDictionary[key];
			}
			set
			{
				if (this._dictionary != null)
				{
					DictionaryWrapper<TKey, TValue>.smethod_7(this._dictionary, key, value);
					return;
				}
				this._genericDictionary[key] = value;
			}
		}

		// Token: 0x06002851 RID: 10321 RVA: 0x0001F129 File Offset: 0x0001D329
		public void Add(KeyValuePair<TKey, TValue> item)
		{
			if (this._dictionary != null)
			{
				DictionaryWrapper<TKey, TValue>.smethod_8((IList)this._dictionary, item);
				return;
			}
			if (this._genericDictionary != null)
			{
				this._genericDictionary.Add(item);
			}
		}

		// Token: 0x06002852 RID: 10322 RVA: 0x0001F15F File Offset: 0x0001D35F
		public void Clear()
		{
			if (this._dictionary != null)
			{
				DictionaryWrapper<TKey, TValue>.smethod_9(this._dictionary);
				return;
			}
			this._genericDictionary.Clear();
		}

		// Token: 0x06002853 RID: 10323 RVA: 0x0001F180 File Offset: 0x0001D380
		public bool Contains(KeyValuePair<TKey, TValue> item)
		{
			if (this._dictionary != null)
			{
				return DictionaryWrapper<TKey, TValue>.smethod_10((IList)this._dictionary, item);
			}
			return this._genericDictionary.Contains(item);
		}

		// Token: 0x06002854 RID: 10324 RVA: 0x00099B00 File Offset: 0x00097D00
		public void CopyTo(KeyValuePair<TKey, TValue>[] array, int arrayIndex)
		{
			if (this._dictionary != null)
			{
				using (IDictionaryEnumerator dictionaryEnumerator = DictionaryWrapper<TKey, TValue>.smethod_11(this._dictionary))
				{
					while (dictionaryEnumerator.MoveNext())
					{
						DictionaryEntry dictionaryEntry = (DictionaryEntry)DictionaryWrapper<TKey, TValue>.smethod_12(dictionaryEnumerator);
						array[arrayIndex++] = new KeyValuePair<TKey, TValue>((TKey)((object)dictionaryEntry.Key), (TValue)((object)dictionaryEntry.Value));
					}
					return;
				}
			}
			this._genericDictionary.CopyTo(array, arrayIndex);
		}

		// Token: 0x170005E9 RID: 1513
		// (get) Token: 0x06002855 RID: 10325 RVA: 0x0001F1AD File Offset: 0x0001D3AD
		public int Count
		{
			get
			{
				if (this._dictionary != null)
				{
					return DictionaryWrapper<TKey, TValue>.smethod_13(this._dictionary);
				}
				return this._genericDictionary.Count;
			}
		}

		// Token: 0x170005EA RID: 1514
		// (get) Token: 0x06002856 RID: 10326 RVA: 0x0001F1CE File Offset: 0x0001D3CE
		public bool IsReadOnly
		{
			get
			{
				if (this._dictionary != null)
				{
					return DictionaryWrapper<TKey, TValue>.smethod_14(this._dictionary);
				}
				return this._genericDictionary.IsReadOnly;
			}
		}

		// Token: 0x06002857 RID: 10327 RVA: 0x00099B98 File Offset: 0x00097D98
		public bool Remove(KeyValuePair<TKey, TValue> item)
		{
			if (this._dictionary == null)
			{
				return this._genericDictionary.Remove(item);
			}
			if (!DictionaryWrapper<TKey, TValue>.smethod_2(this._dictionary, item.Key))
			{
				return true;
			}
			object obj = DictionaryWrapper<TKey, TValue>.smethod_5(this._dictionary, item.Key);
			if (DictionaryWrapper<TKey, TValue>.smethod_15(obj, item.Value))
			{
				DictionaryWrapper<TKey, TValue>.smethod_4(this._dictionary, item.Key);
				return true;
			}
			return false;
		}

		// Token: 0x06002858 RID: 10328 RVA: 0x00099C1C File Offset: 0x00097E1C
		public IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator()
		{
			if (this._dictionary != null)
			{
				return (from DictionaryEntry de in this._dictionary
					select new KeyValuePair<TKey, TValue>((TKey)((object)de.Key), (TValue)((object)de.Value))).GetEnumerator();
			}
			return this._genericDictionary.GetEnumerator();
		}

		// Token: 0x06002859 RID: 10329 RVA: 0x0001F1EF File Offset: 0x0001D3EF
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		// Token: 0x0600285A RID: 10330 RVA: 0x0001F1F7 File Offset: 0x0001D3F7
		void IDictionary.Add(object key, object value)
		{
			if (this._dictionary != null)
			{
				DictionaryWrapper<TKey, TValue>.smethod_0(this._dictionary, key, value);
				return;
			}
			this._genericDictionary.Add((TKey)((object)key), (TValue)((object)value));
		}

		// Token: 0x170005EB RID: 1515
		object IDictionary.this[object key]
		{
			get
			{
				if (this._dictionary != null)
				{
					return DictionaryWrapper<TKey, TValue>.smethod_5(this._dictionary, key);
				}
				return this._genericDictionary[(TKey)((object)key)];
			}
			set
			{
				if (this._dictionary != null)
				{
					DictionaryWrapper<TKey, TValue>.smethod_7(this._dictionary, key, value);
					return;
				}
				this._genericDictionary[(TKey)((object)key)] = (TValue)((object)value);
			}
		}

		// Token: 0x0600285D RID: 10333 RVA: 0x0001F282 File Offset: 0x0001D482
		IDictionaryEnumerator IDictionary.GetEnumerator()
		{
			if (this._dictionary != null)
			{
				return DictionaryWrapper<TKey, TValue>.smethod_11(this._dictionary);
			}
			return new DictionaryWrapper<TKey, TValue>.DictionaryEnumerator<TKey, TValue>(this._genericDictionary.GetEnumerator());
		}

		// Token: 0x0600285E RID: 10334 RVA: 0x0001F2AD File Offset: 0x0001D4AD
		bool IDictionary.Contains(object key)
		{
			if (this._genericDictionary != null)
			{
				return this._genericDictionary.ContainsKey((TKey)((object)key));
			}
			return DictionaryWrapper<TKey, TValue>.smethod_2(this._dictionary, key);
		}

		// Token: 0x170005EC RID: 1516
		// (get) Token: 0x0600285F RID: 10335 RVA: 0x0001F2D5 File Offset: 0x0001D4D5
		bool IDictionary.IsFixedSize
		{
			get
			{
				return this._genericDictionary == null && DictionaryWrapper<TKey, TValue>.smethod_16(this._dictionary);
			}
		}

		// Token: 0x170005ED RID: 1517
		// (get) Token: 0x06002860 RID: 10336 RVA: 0x0001F2EC File Offset: 0x0001D4EC
		ICollection IDictionary.Keys
		{
			get
			{
				if (this._genericDictionary != null)
				{
					return this._genericDictionary.Keys.ToList<TKey>();
				}
				return DictionaryWrapper<TKey, TValue>.smethod_3(this._dictionary);
			}
		}

		// Token: 0x06002861 RID: 10337 RVA: 0x0001F312 File Offset: 0x0001D512
		public void Remove(object key)
		{
			if (this._dictionary != null)
			{
				DictionaryWrapper<TKey, TValue>.smethod_4(this._dictionary, key);
				return;
			}
			this._genericDictionary.Remove((TKey)((object)key));
		}

		// Token: 0x170005EE RID: 1518
		// (get) Token: 0x06002862 RID: 10338 RVA: 0x0001F33B File Offset: 0x0001D53B
		ICollection IDictionary.Values
		{
			get
			{
				if (this._genericDictionary != null)
				{
					return this._genericDictionary.Values.ToList<TValue>();
				}
				return DictionaryWrapper<TKey, TValue>.smethod_6(this._dictionary);
			}
		}

		// Token: 0x06002863 RID: 10339 RVA: 0x0001F361 File Offset: 0x0001D561
		void ICollection.CopyTo(Array array, int index)
		{
			if (this._dictionary != null)
			{
				DictionaryWrapper<TKey, TValue>.smethod_17(this._dictionary, array, index);
				return;
			}
			this._genericDictionary.CopyTo((KeyValuePair<TKey, TValue>[])array, index);
		}

		// Token: 0x170005EF RID: 1519
		// (get) Token: 0x06002864 RID: 10340 RVA: 0x0001F38B File Offset: 0x0001D58B
		bool ICollection.IsSynchronized
		{
			get
			{
				return this._dictionary != null && DictionaryWrapper<TKey, TValue>.smethod_18(this._dictionary);
			}
		}

		// Token: 0x170005F0 RID: 1520
		// (get) Token: 0x06002865 RID: 10341 RVA: 0x0001F3A2 File Offset: 0x0001D5A2
		object ICollection.SyncRoot
		{
			get
			{
				if (this._syncRoot == null)
				{
					DictionaryWrapper<TKey, TValue>.smethod_20(ref this._syncRoot, DictionaryWrapper<TKey, TValue>.smethod_19(), null);
				}
				return this._syncRoot;
			}
		}

		// Token: 0x170005F1 RID: 1521
		// (get) Token: 0x06002866 RID: 10342 RVA: 0x0001F3C4 File Offset: 0x0001D5C4
		public object UnderlyingDictionary
		{
			get
			{
				if (this._dictionary != null)
				{
					return this._dictionary;
				}
				return this._genericDictionary;
			}
		}

		// Token: 0x04000E3B RID: 3643
		private readonly IDictionary _dictionary;

		// Token: 0x04000E3C RID: 3644
		private readonly IDictionary<TKey, TValue> _genericDictionary;

		// Token: 0x04000E3D RID: 3645
		private object _syncRoot;

		// Token: 0x020002C5 RID: 709
		private struct DictionaryEnumerator<TEnumeratorKey, TEnumeratorValue> : IEnumerator, IDictionaryEnumerator
		{
			// Token: 0x06002868 RID: 10344 RVA: 0x0001F3FA File Offset: 0x0001D5FA
			public DictionaryEnumerator(IEnumerator<KeyValuePair<TEnumeratorKey, TEnumeratorValue>> e)
			{
				ValidationUtils.ArgumentNotNull(e, <Module>.smethod_23<string>(3007012662U));
				this._e = e;
			}

			// Token: 0x170005F2 RID: 1522
			// (get) Token: 0x06002869 RID: 10345 RVA: 0x0001F413 File Offset: 0x0001D613
			public DictionaryEntry Entry
			{
				get
				{
					return (DictionaryEntry)this.Current;
				}
			}

			// Token: 0x170005F3 RID: 1523
			// (get) Token: 0x0600286A RID: 10346 RVA: 0x00099C70 File Offset: 0x00097E70
			public object Key
			{
				get
				{
					return this.Entry.Key;
				}
			}

			// Token: 0x170005F4 RID: 1524
			// (get) Token: 0x0600286B RID: 10347 RVA: 0x00099C8C File Offset: 0x00097E8C
			public object Value
			{
				get
				{
					return this.Entry.Value;
				}
			}

			// Token: 0x170005F5 RID: 1525
			// (get) Token: 0x0600286C RID: 10348 RVA: 0x00099CA8 File Offset: 0x00097EA8
			public object Current
			{
				get
				{
					KeyValuePair<TEnumeratorKey, TEnumeratorValue> keyValuePair = this._e.Current;
					object obj = keyValuePair.Key;
					KeyValuePair<TEnumeratorKey, TEnumeratorValue> keyValuePair2 = this._e.Current;
					return new DictionaryEntry(obj, keyValuePair2.Value);
				}
			}

			// Token: 0x0600286D RID: 10349 RVA: 0x0001F420 File Offset: 0x0001D620
			public bool MoveNext()
			{
				return DictionaryWrapper<TKey, TValue>.DictionaryEnumerator<TEnumeratorKey, TEnumeratorValue>.smethod_0(this._e);
			}

			// Token: 0x0600286E RID: 10350 RVA: 0x0001F42D File Offset: 0x0001D62D
			public void Reset()
			{
				DictionaryWrapper<TKey, TValue>.DictionaryEnumerator<TEnumeratorKey, TEnumeratorValue>.smethod_1(this._e);
			}

			// Token: 0x04000E3F RID: 3647
			private readonly IEnumerator<KeyValuePair<TEnumeratorKey, TEnumeratorValue>> _e;
		}
	}
}
