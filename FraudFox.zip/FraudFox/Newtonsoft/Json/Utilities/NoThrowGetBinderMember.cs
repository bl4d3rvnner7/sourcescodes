﻿using System;
using System.Dynamic;
using System.Linq.Expressions;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x02000295 RID: 661
	internal class NoThrowGetBinderMember : GetMemberBinder
	{
		// Token: 0x0600268A RID: 9866 RVA: 0x0001E316 File Offset: 0x0001C516
		public NoThrowGetBinderMember(GetMemberBinder innerBinder)
			: base(NoThrowGetBinderMember.smethod_0(innerBinder), NoThrowGetBinderMember.smethod_1(innerBinder))
		{
			this._innerBinder = innerBinder;
		}

		// Token: 0x0600268B RID: 9867 RVA: 0x00095F58 File Offset: 0x00094158
		public override DynamicMetaObject FallbackGetMember(DynamicMetaObject target, DynamicMetaObject errorSuggestion)
		{
			DynamicMetaObject dynamicMetaObject = NoThrowGetBinderMember.smethod_2(this._innerBinder, target, new DynamicMetaObject[0]);
			NoThrowExpressionVisitor noThrowExpressionVisitor = new NoThrowExpressionVisitor();
			Expression expression = NoThrowGetBinderMember.smethod_4(noThrowExpressionVisitor, NoThrowGetBinderMember.smethod_3(dynamicMetaObject));
			return NoThrowGetBinderMember.smethod_6(expression, NoThrowGetBinderMember.smethod_5(dynamicMetaObject));
		}

		// Token: 0x0600268C RID: 9868 RVA: 0x0001BF2C File Offset: 0x0001A12C
		static string smethod_0(GetMemberBinder getMemberBinder_0)
		{
			return getMemberBinder_0.Name;
		}

		// Token: 0x0600268D RID: 9869 RVA: 0x0001E331 File Offset: 0x0001C531
		static bool smethod_1(GetMemberBinder getMemberBinder_0)
		{
			return getMemberBinder_0.IgnoreCase;
		}

		// Token: 0x0600268E RID: 9870 RVA: 0x0001E339 File Offset: 0x0001C539
		static DynamicMetaObject smethod_2(DynamicMetaObjectBinder dynamicMetaObjectBinder_0, DynamicMetaObject dynamicMetaObject_0, DynamicMetaObject[] dynamicMetaObject_1)
		{
			return dynamicMetaObjectBinder_0.Bind(dynamicMetaObject_0, dynamicMetaObject_1);
		}

		// Token: 0x0600268F RID: 9871 RVA: 0x0001E343 File Offset: 0x0001C543
		static Expression smethod_3(DynamicMetaObject dynamicMetaObject_0)
		{
			return dynamicMetaObject_0.Expression;
		}

		// Token: 0x06002690 RID: 9872 RVA: 0x0001E34B File Offset: 0x0001C54B
		static Expression smethod_4(ExpressionVisitor expressionVisitor_0, Expression expression_0)
		{
			return expressionVisitor_0.Visit(expression_0);
		}

		// Token: 0x06002691 RID: 9873 RVA: 0x0001E354 File Offset: 0x0001C554
		static BindingRestrictions smethod_5(DynamicMetaObject dynamicMetaObject_0)
		{
			return dynamicMetaObject_0.Restrictions;
		}

		// Token: 0x06002692 RID: 9874 RVA: 0x0001E35C File Offset: 0x0001C55C
		static DynamicMetaObject smethod_6(Expression expression_0, BindingRestrictions bindingRestrictions_0)
		{
			return new DynamicMetaObject(expression_0, bindingRestrictions_0);
		}

		// Token: 0x04000DA8 RID: 3496
		private readonly GetMemberBinder _innerBinder;
	}
}
