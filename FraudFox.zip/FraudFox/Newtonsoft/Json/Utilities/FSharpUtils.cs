﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using Newtonsoft.Json.Serialization;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002A0 RID: 672
	internal static class FSharpUtils
	{
		// Token: 0x170005C6 RID: 1478
		// (get) Token: 0x0600272F RID: 10031 RVA: 0x0001E5E8 File Offset: 0x0001C7E8
		// (set) Token: 0x06002730 RID: 10032 RVA: 0x0001E5EF File Offset: 0x0001C7EF
		public static Assembly FSharpCoreAssembly { get; private set; }

		// Token: 0x170005C7 RID: 1479
		// (get) Token: 0x06002731 RID: 10033 RVA: 0x0001E5F7 File Offset: 0x0001C7F7
		// (set) Token: 0x06002732 RID: 10034 RVA: 0x0001E5FE File Offset: 0x0001C7FE
		public static MethodCall<object, object> IsUnion { get; private set; }

		// Token: 0x170005C8 RID: 1480
		// (get) Token: 0x06002733 RID: 10035 RVA: 0x0001E606 File Offset: 0x0001C806
		// (set) Token: 0x06002734 RID: 10036 RVA: 0x0001E60D File Offset: 0x0001C80D
		public static MethodCall<object, object> GetUnionCases { get; private set; }

		// Token: 0x170005C9 RID: 1481
		// (get) Token: 0x06002735 RID: 10037 RVA: 0x0001E615 File Offset: 0x0001C815
		// (set) Token: 0x06002736 RID: 10038 RVA: 0x0001E61C File Offset: 0x0001C81C
		public static MethodCall<object, object> PreComputeUnionTagReader { get; private set; }

		// Token: 0x170005CA RID: 1482
		// (get) Token: 0x06002737 RID: 10039 RVA: 0x0001E624 File Offset: 0x0001C824
		// (set) Token: 0x06002738 RID: 10040 RVA: 0x0001E62B File Offset: 0x0001C82B
		public static MethodCall<object, object> PreComputeUnionReader { get; private set; }

		// Token: 0x170005CB RID: 1483
		// (get) Token: 0x06002739 RID: 10041 RVA: 0x0001E633 File Offset: 0x0001C833
		// (set) Token: 0x0600273A RID: 10042 RVA: 0x0001E63A File Offset: 0x0001C83A
		public static MethodCall<object, object> PreComputeUnionConstructor { get; private set; }

		// Token: 0x170005CC RID: 1484
		// (get) Token: 0x0600273B RID: 10043 RVA: 0x0001E642 File Offset: 0x0001C842
		// (set) Token: 0x0600273C RID: 10044 RVA: 0x0001E649 File Offset: 0x0001C849
		public static Func<object, object> GetUnionCaseInfoDeclaringType { get; private set; }

		// Token: 0x170005CD RID: 1485
		// (get) Token: 0x0600273D RID: 10045 RVA: 0x0001E651 File Offset: 0x0001C851
		// (set) Token: 0x0600273E RID: 10046 RVA: 0x0001E658 File Offset: 0x0001C858
		public static Func<object, object> GetUnionCaseInfoName { get; private set; }

		// Token: 0x170005CE RID: 1486
		// (get) Token: 0x0600273F RID: 10047 RVA: 0x0001E660 File Offset: 0x0001C860
		// (set) Token: 0x06002740 RID: 10048 RVA: 0x0001E667 File Offset: 0x0001C867
		public static Func<object, object> GetUnionCaseInfoTag { get; private set; }

		// Token: 0x170005CF RID: 1487
		// (get) Token: 0x06002741 RID: 10049 RVA: 0x0001E66F File Offset: 0x0001C86F
		// (set) Token: 0x06002742 RID: 10050 RVA: 0x0001E676 File Offset: 0x0001C876
		public static MethodCall<object, object> GetUnionCaseInfoFields { get; private set; }

		// Token: 0x06002743 RID: 10051 RVA: 0x000970F0 File Offset: 0x000952F0
		public static void EnsureInitialized(Assembly fsharpCoreAssembly)
		{
			if (!FSharpUtils._initialized)
			{
				bool flag = false;
				try
				{
					object @lock;
					FSharpUtils.smethod_0(@lock = FSharpUtils.Lock, ref flag);
					if (!FSharpUtils._initialized)
					{
						FSharpUtils.FSharpCoreAssembly = fsharpCoreAssembly;
						Type type = FSharpUtils.smethod_1(fsharpCoreAssembly, <Module>.smethod_26<string>(1339207259U));
						MethodInfo methodInfo = FSharpUtils.smethod_2(type, <Module>.smethod_23<string>(4090415204U), BindingFlags.Static | BindingFlags.Public);
						FSharpUtils.IsUnion = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>(methodInfo);
						MethodInfo methodInfo2 = FSharpUtils.smethod_2(type, <Module>.smethod_27<string>(3939005531U), BindingFlags.Static | BindingFlags.Public);
						FSharpUtils.GetUnionCases = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>(methodInfo2);
						Type type2 = FSharpUtils.smethod_1(fsharpCoreAssembly, <Module>.smethod_27<string>(3426166908U));
						FSharpUtils.PreComputeUnionTagReader = FSharpUtils.CreateFSharpFuncCall(type2, <Module>.smethod_23<string>(2793885315U));
						FSharpUtils.PreComputeUnionReader = FSharpUtils.CreateFSharpFuncCall(type2, <Module>.smethod_27<string>(2586976434U));
						FSharpUtils.PreComputeUnionConstructor = FSharpUtils.CreateFSharpFuncCall(type2, <Module>.smethod_27<string>(2167381197U));
						Type type3 = FSharpUtils.smethod_1(fsharpCoreAssembly, <Module>.smethod_26<string>(2240969223U));
						FSharpUtils.GetUnionCaseInfoName = JsonTypeReflector.ReflectionDelegateFactory.CreateGet<object>(FSharpUtils.smethod_3(type3, <Module>.smethod_27<string>(435778579U)));
						FSharpUtils.GetUnionCaseInfoTag = JsonTypeReflector.ReflectionDelegateFactory.CreateGet<object>(FSharpUtils.smethod_3(type3, <Module>.smethod_26<string>(2260122011U)));
						FSharpUtils.GetUnionCaseInfoDeclaringType = JsonTypeReflector.ReflectionDelegateFactory.CreateGet<object>(FSharpUtils.smethod_3(type3, <Module>.smethod_27<string>(2814313359U)));
						FSharpUtils.GetUnionCaseInfoFields = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>(FSharpUtils.smethod_4(type3, <Module>.smethod_23<string>(106754912U)));
						Type type4 = FSharpUtils.smethod_1(fsharpCoreAssembly, <Module>.smethod_23<string>(2544161188U));
						FSharpUtils._ofSeq = FSharpUtils.smethod_4(type4, <Module>.smethod_25<string>(2875871108U));
						FSharpUtils._mapType = FSharpUtils.smethod_1(fsharpCoreAssembly, <Module>.smethod_23<string>(1615380678U));
						FSharpUtils.smethod_5();
						FSharpUtils._initialized = true;
					}
				}
				finally
				{
					if (flag)
					{
						object @lock;
						FSharpUtils.smethod_6(@lock);
					}
				}
			}
		}

		// Token: 0x06002744 RID: 10052 RVA: 0x000972D8 File Offset: 0x000954D8
		private static MethodCall<object, object> CreateFSharpFuncCall(Type type, string methodName)
		{
			MethodInfo methodInfo = FSharpUtils.smethod_2(type, methodName, BindingFlags.Static | BindingFlags.Public);
			MethodInfo methodInfo2 = FSharpUtils.smethod_2(FSharpUtils.smethod_7(methodInfo), <Module>.smethod_25<string>(4128625262U), BindingFlags.Instance | BindingFlags.Public);
			MethodCall<object, object> call = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>(methodInfo);
			MethodCall<object, object> invoke = JsonTypeReflector.ReflectionDelegateFactory.CreateMethodCall<object>(methodInfo2);
			return delegate(object target, object[] args)
			{
				object obj = call(target, args);
				return new FSharpFunction(obj, invoke);
			};
		}

		// Token: 0x06002745 RID: 10053 RVA: 0x00097340 File Offset: 0x00095540
		public static ObjectConstructor<object> CreateSeq(Type t)
		{
			MethodInfo methodInfo = FSharpUtils.smethod_8(FSharpUtils._ofSeq, new Type[] { t });
			return JsonTypeReflector.ReflectionDelegateFactory.CreateParametrizedConstructor(methodInfo);
		}

		// Token: 0x06002746 RID: 10054 RVA: 0x00097374 File Offset: 0x00095574
		public static ObjectConstructor<object> CreateMap(Type keyType, Type valueType)
		{
			MethodInfo methodInfo = FSharpUtils.smethod_9(typeof(FSharpUtils).TypeHandle).method_0(<Module>.smethod_23<string>(3628595200U));
			MethodInfo methodInfo2 = FSharpUtils.smethod_8(methodInfo, new Type[] { keyType, valueType });
			return (ObjectConstructor<object>)FSharpUtils.smethod_10(methodInfo2, null, null);
		}

		// Token: 0x06002747 RID: 10055 RVA: 0x000973C8 File Offset: 0x000955C8
		public static ObjectConstructor<object> BuildMapCreator<TKey, TValue>()
		{
			Type type = FSharpUtils.smethod_11(FSharpUtils._mapType, new Type[]
			{
				FSharpUtils.smethod_9(typeof(TKey).TypeHandle),
				FSharpUtils.smethod_9(typeof(TValue).TypeHandle)
			});
			ConstructorInfo constructorInfo = FSharpUtils.smethod_12(type, new Type[] { FSharpUtils.smethod_9(typeof(IEnumerable<Tuple<TKey, TValue>>).TypeHandle) });
			ObjectConstructor<object> ctorDelegate = JsonTypeReflector.ReflectionDelegateFactory.CreateParametrizedConstructor(constructorInfo);
			return delegate(object[] args)
			{
				IEnumerable<KeyValuePair<TKey, TValue>> enumerable = (IEnumerable<KeyValuePair<TKey, TValue>>)args[0];
				IEnumerable<Tuple<TKey, TValue>> enumerable2 = enumerable.Select((KeyValuePair<TKey, TValue> kv) => new Tuple<TKey, TValue>(kv.Key, kv.Value));
				return ctorDelegate(new object[] { enumerable2 });
			};
		}

		// Token: 0x06002749 RID: 10057 RVA: 0x0000DBD7 File Offset: 0x0000BDD7
		static void smethod_0(object object_0, ref bool bool_0)
		{
			Monitor.Enter(object_0, ref bool_0);
		}

		// Token: 0x0600274A RID: 10058 RVA: 0x0001CCBA File Offset: 0x0001AEBA
		static Type smethod_1(Assembly assembly_0, string string_0)
		{
			return assembly_0.GetType(string_0);
		}

		// Token: 0x0600274B RID: 10059 RVA: 0x0001E68A File Offset: 0x0001C88A
		static MethodInfo smethod_2(Type type_0, string string_0, BindingFlags bindingFlags_0)
		{
			return type_0.GetMethod(string_0, bindingFlags_0);
		}

		// Token: 0x0600274C RID: 10060 RVA: 0x0001CB07 File Offset: 0x0001AD07
		static PropertyInfo smethod_3(Type type_0, string string_0)
		{
			return type_0.GetProperty(string_0);
		}

		// Token: 0x0600274D RID: 10061 RVA: 0x0001E694 File Offset: 0x0001C894
		static MethodInfo smethod_4(Type type_0, string string_0)
		{
			return type_0.GetMethod(string_0);
		}

		// Token: 0x0600274E RID: 10062 RVA: 0x0001E69D File Offset: 0x0001C89D
		static void smethod_5()
		{
			Thread.MemoryBarrier();
		}

		// Token: 0x0600274F RID: 10063 RVA: 0x0000DBEF File Offset: 0x0000BDEF
		static void smethod_6(object object_0)
		{
			Monitor.Exit(object_0);
		}

		// Token: 0x06002750 RID: 10064 RVA: 0x0001CAC6 File Offset: 0x0001ACC6
		static Type smethod_7(MethodInfo methodInfo_0)
		{
			return methodInfo_0.ReturnType;
		}

		// Token: 0x06002751 RID: 10065 RVA: 0x0001E6A4 File Offset: 0x0001C8A4
		static MethodInfo smethod_8(MethodInfo methodInfo_0, Type[] type_0)
		{
			return methodInfo_0.MakeGenericMethod(type_0);
		}

		// Token: 0x06002752 RID: 10066 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_9(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06002753 RID: 10067 RVA: 0x0001E195 File Offset: 0x0001C395
		MethodInfo method_0(string string_0)
		{
			return base.GetMethod(string_0);
		}

		// Token: 0x06002754 RID: 10068 RVA: 0x0001839E File Offset: 0x0001659E
		static object smethod_10(MethodBase methodBase_0, object object_0, object[] object_1)
		{
			return methodBase_0.Invoke(object_0, object_1);
		}

		// Token: 0x06002755 RID: 10069 RVA: 0x00016303 File Offset: 0x00014503
		static Type smethod_11(Type type_0, Type[] type_1)
		{
			return type_0.MakeGenericType(type_1);
		}

		// Token: 0x06002756 RID: 10070 RVA: 0x000175AD File Offset: 0x000157AD
		static ConstructorInfo smethod_12(Type type_0, Type[] type_1)
		{
			return type_0.GetConstructor(type_1);
		}

		// Token: 0x06002757 RID: 10071 RVA: 0x00013209 File Offset: 0x00011409
		static object smethod_13()
		{
			return new object();
		}

		// Token: 0x04000DB4 RID: 3508
		public const string FSharpSetTypeName = "FSharpSet`1";

		// Token: 0x04000DB5 RID: 3509
		public const string FSharpListTypeName = "FSharpList`1";

		// Token: 0x04000DB6 RID: 3510
		public const string FSharpMapTypeName = "FSharpMap`2";

		// Token: 0x04000DB7 RID: 3511
		private static readonly object Lock = FSharpUtils.smethod_13();

		// Token: 0x04000DB8 RID: 3512
		private static bool _initialized;

		// Token: 0x04000DB9 RID: 3513
		private static MethodInfo _ofSeq;

		// Token: 0x04000DBA RID: 3514
		private static Type _mapType;
	}
}
