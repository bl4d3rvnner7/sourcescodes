﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002C1 RID: 705
	internal class CollectionWrapper<T> : ICollection<T>, IEnumerable<T>, IEnumerable, IList, ICollection, IWrappedCollection
	{
		// Token: 0x06002806 RID: 10246 RVA: 0x0001EB5F File Offset: 0x0001CD5F
		public CollectionWrapper(IList list)
		{
			ValidationUtils.ArgumentNotNull(list, <Module>.smethod_26<string>(1641654134U));
			if (!(list is ICollection<T>))
			{
				this._list = list;
				return;
			}
			this._genericCollection = (ICollection<T>)list;
		}

		// Token: 0x06002807 RID: 10247 RVA: 0x0001EB93 File Offset: 0x0001CD93
		public CollectionWrapper(ICollection<T> list)
		{
			ValidationUtils.ArgumentNotNull(list, <Module>.smethod_27<string>(1829486266U));
			this._genericCollection = list;
		}

		// Token: 0x06002808 RID: 10248 RVA: 0x0001EBB2 File Offset: 0x0001CDB2
		public virtual void Add(T item)
		{
			if (this._genericCollection != null)
			{
				this._genericCollection.Add(item);
				return;
			}
			CollectionWrapper<T>.smethod_0(this._list, item);
		}

		// Token: 0x06002809 RID: 10249 RVA: 0x0001EBDB File Offset: 0x0001CDDB
		public virtual void Clear()
		{
			if (this._genericCollection != null)
			{
				this._genericCollection.Clear();
				return;
			}
			CollectionWrapper<T>.smethod_1(this._list);
		}

		// Token: 0x0600280A RID: 10250 RVA: 0x0001EBFC File Offset: 0x0001CDFC
		public virtual bool Contains(T item)
		{
			if (this._genericCollection != null)
			{
				return this._genericCollection.Contains(item);
			}
			return CollectionWrapper<T>.smethod_2(this._list, item);
		}

		// Token: 0x0600280B RID: 10251 RVA: 0x0001EC24 File Offset: 0x0001CE24
		public virtual void CopyTo(T[] array, int arrayIndex)
		{
			if (this._genericCollection != null)
			{
				this._genericCollection.CopyTo(array, arrayIndex);
				return;
			}
			CollectionWrapper<T>.smethod_3(this._list, array, arrayIndex);
		}

		// Token: 0x170005DE RID: 1502
		// (get) Token: 0x0600280C RID: 10252 RVA: 0x0001EC49 File Offset: 0x0001CE49
		public virtual int Count
		{
			get
			{
				if (this._genericCollection != null)
				{
					return this._genericCollection.Count;
				}
				return CollectionWrapper<T>.smethod_4(this._list);
			}
		}

		// Token: 0x170005DF RID: 1503
		// (get) Token: 0x0600280D RID: 10253 RVA: 0x0001EC6A File Offset: 0x0001CE6A
		public virtual bool IsReadOnly
		{
			get
			{
				if (this._genericCollection != null)
				{
					return this._genericCollection.IsReadOnly;
				}
				return CollectionWrapper<T>.smethod_5(this._list);
			}
		}

		// Token: 0x0600280E RID: 10254 RVA: 0x00098F2C File Offset: 0x0009712C
		public virtual bool Remove(T item)
		{
			if (this._genericCollection == null)
			{
				bool flag;
				if (flag = CollectionWrapper<T>.smethod_2(this._list, item))
				{
					CollectionWrapper<T>.smethod_6(this._list, item);
				}
				return flag;
			}
			return this._genericCollection.Remove(item);
		}

		// Token: 0x0600280F RID: 10255 RVA: 0x0001EC8B File Offset: 0x0001CE8B
		public virtual IEnumerator<T> GetEnumerator()
		{
			if (this._genericCollection != null)
			{
				return this._genericCollection.GetEnumerator();
			}
			return this._list.Cast<T>().GetEnumerator();
		}

		// Token: 0x06002810 RID: 10256 RVA: 0x0001ECB1 File Offset: 0x0001CEB1
		IEnumerator IEnumerable.GetEnumerator()
		{
			if (this._genericCollection != null)
			{
				return this._genericCollection.GetEnumerator();
			}
			return CollectionWrapper<T>.smethod_7(this._list);
		}

		// Token: 0x06002811 RID: 10257 RVA: 0x0001ECD2 File Offset: 0x0001CED2
		int IList.Add(object value)
		{
			CollectionWrapper<T>.VerifyValueType(value);
			this.Add((T)((object)value));
			return this.Count - 1;
		}

		// Token: 0x06002812 RID: 10258 RVA: 0x0001ECEE File Offset: 0x0001CEEE
		bool IList.Contains(object value)
		{
			return CollectionWrapper<T>.IsCompatibleObject(value) && this.Contains((T)((object)value));
		}

		// Token: 0x06002813 RID: 10259 RVA: 0x0001ED06 File Offset: 0x0001CF06
		int IList.IndexOf(object value)
		{
			if (this._genericCollection != null)
			{
				throw CollectionWrapper<T>.smethod_8(<Module>.smethod_23<string>(3005981192U));
			}
			if (CollectionWrapper<T>.IsCompatibleObject(value))
			{
				return CollectionWrapper<T>.smethod_9(this._list, (T)((object)value));
			}
			return -1;
		}

		// Token: 0x06002814 RID: 10260 RVA: 0x0001ED40 File Offset: 0x0001CF40
		void IList.RemoveAt(int index)
		{
			if (this._genericCollection != null)
			{
				throw CollectionWrapper<T>.smethod_8(<Module>.smethod_23<string>(3707450613U));
			}
			CollectionWrapper<T>.smethod_10(this._list, index);
		}

		// Token: 0x06002815 RID: 10261 RVA: 0x0001ED66 File Offset: 0x0001CF66
		void IList.Insert(int index, object value)
		{
			if (this._genericCollection != null)
			{
				throw CollectionWrapper<T>.smethod_8(<Module>.smethod_25<string>(2431568480U));
			}
			CollectionWrapper<T>.VerifyValueType(value);
			CollectionWrapper<T>.smethod_11(this._list, index, (T)((object)value));
		}

		// Token: 0x170005E0 RID: 1504
		// (get) Token: 0x06002816 RID: 10262 RVA: 0x0001ED9D File Offset: 0x0001CF9D
		bool IList.IsFixedSize
		{
			get
			{
				if (this._genericCollection != null)
				{
					return this._genericCollection.IsReadOnly;
				}
				return CollectionWrapper<T>.smethod_12(this._list);
			}
		}

		// Token: 0x06002817 RID: 10263 RVA: 0x0001EDBE File Offset: 0x0001CFBE
		void IList.Remove(object value)
		{
			if (CollectionWrapper<T>.IsCompatibleObject(value))
			{
				this.Remove((T)((object)value));
			}
		}

		// Token: 0x170005E1 RID: 1505
		object IList.this[int index]
		{
			get
			{
				if (this._genericCollection != null)
				{
					throw CollectionWrapper<T>.smethod_8(<Module>.smethod_27<string>(2740111776U));
				}
				return CollectionWrapper<T>.smethod_13(this._list, index);
			}
			set
			{
				if (this._genericCollection != null)
				{
					throw CollectionWrapper<T>.smethod_8(<Module>.smethod_25<string>(2640360839U));
				}
				CollectionWrapper<T>.VerifyValueType(value);
				CollectionWrapper<T>.smethod_14(this._list, index, (T)((object)value));
			}
		}

		// Token: 0x0600281A RID: 10266 RVA: 0x0001EE32 File Offset: 0x0001D032
		void ICollection.CopyTo(Array array, int arrayIndex)
		{
			this.CopyTo((T[])array, arrayIndex);
		}

		// Token: 0x170005E2 RID: 1506
		// (get) Token: 0x0600281B RID: 10267 RVA: 0x0000C17A File Offset: 0x0000A37A
		bool ICollection.IsSynchronized
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170005E3 RID: 1507
		// (get) Token: 0x0600281C RID: 10268 RVA: 0x0001EE41 File Offset: 0x0001D041
		object ICollection.SyncRoot
		{
			get
			{
				if (this._syncRoot == null)
				{
					CollectionWrapper<T>.smethod_16(ref this._syncRoot, CollectionWrapper<T>.smethod_15(), null);
				}
				return this._syncRoot;
			}
		}

		// Token: 0x0600281D RID: 10269 RVA: 0x0001EE63 File Offset: 0x0001D063
		private static void VerifyValueType(object value)
		{
			if (!CollectionWrapper<T>.IsCompatibleObject(value))
			{
				throw CollectionWrapper<T>.smethod_19(<Module>.smethod_26<string>(1629660935U).FormatWith(CollectionWrapper<T>.smethod_17(), value, CollectionWrapper<T>.smethod_18(typeof(T).TypeHandle)), <Module>.smethod_27<string>(2371252898U));
			}
		}

		// Token: 0x0600281E RID: 10270 RVA: 0x0001EE9C File Offset: 0x0001D09C
		private static bool IsCompatibleObject(object value)
		{
			return value is T || (value == null && (!CollectionWrapper<T>.smethod_18(typeof(T).TypeHandle).IsValueType() || ReflectionUtils.IsNullableType(CollectionWrapper<T>.smethod_18(typeof(T).TypeHandle))));
		}

		// Token: 0x170005E4 RID: 1508
		// (get) Token: 0x0600281F RID: 10271 RVA: 0x0001EECE File Offset: 0x0001D0CE
		public object UnderlyingCollection
		{
			get
			{
				if (this._genericCollection != null)
				{
					return this._genericCollection;
				}
				return this._list;
			}
		}

		// Token: 0x04000E30 RID: 3632
		private readonly IList _list;

		// Token: 0x04000E31 RID: 3633
		private readonly ICollection<T> _genericCollection;

		// Token: 0x04000E32 RID: 3634
		private object _syncRoot;
	}
}
