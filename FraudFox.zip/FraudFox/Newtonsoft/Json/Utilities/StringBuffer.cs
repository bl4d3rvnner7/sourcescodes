﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002CA RID: 714
	internal class StringBuffer
	{
		// Token: 0x170005F8 RID: 1528
		// (get) Token: 0x060028AF RID: 10415 RVA: 0x0001F4EC File Offset: 0x0001D6EC
		// (set) Token: 0x060028B0 RID: 10416 RVA: 0x0001F4F4 File Offset: 0x0001D6F4
		public int Position
		{
			get
			{
				return this._position;
			}
			set
			{
				this._position = value;
			}
		}

		// Token: 0x060028B1 RID: 10417 RVA: 0x0001F4FD File Offset: 0x0001D6FD
		public StringBuffer()
		{
			this._buffer = StringBuffer.EmptyBuffer;
		}

		// Token: 0x060028B2 RID: 10418 RVA: 0x0001F510 File Offset: 0x0001D710
		public StringBuffer(int initalSize)
		{
			this._buffer = new char[initalSize];
		}

		// Token: 0x060028B3 RID: 10419 RVA: 0x0009A7B8 File Offset: 0x000989B8
		public void Append(char value)
		{
			if (this._position == this._buffer.Length)
			{
				this.EnsureSize(1);
			}
			this._buffer[this._position++] = value;
		}

		// Token: 0x060028B4 RID: 10420 RVA: 0x0001F524 File Offset: 0x0001D724
		public void Append(char[] buffer, int startIndex, int count)
		{
			if (this._position + count >= this._buffer.Length)
			{
				this.EnsureSize(count);
			}
			StringBuffer.smethod_0(buffer, startIndex, this._buffer, this._position, count);
			this._position += count;
		}

		// Token: 0x060028B5 RID: 10421 RVA: 0x0001F561 File Offset: 0x0001D761
		public void Clear()
		{
			this._buffer = StringBuffer.EmptyBuffer;
			this._position = 0;
		}

		// Token: 0x060028B6 RID: 10422 RVA: 0x0009A7F8 File Offset: 0x000989F8
		private void EnsureSize(int appendLength)
		{
			char[] array = new char[(this._position + appendLength) * 2];
			StringBuffer.smethod_1(this._buffer, array, this._position);
			this._buffer = array;
		}

		// Token: 0x060028B7 RID: 10423 RVA: 0x0001F575 File Offset: 0x0001D775
		public override string ToString()
		{
			return this.ToString(0, this._position);
		}

		// Token: 0x060028B8 RID: 10424 RVA: 0x0001F584 File Offset: 0x0001D784
		public string ToString(int start, int length)
		{
			return StringBuffer.smethod_2(this._buffer, start, length);
		}

		// Token: 0x060028B9 RID: 10425 RVA: 0x0001F593 File Offset: 0x0001D793
		public char[] GetInternalBuffer()
		{
			return this._buffer;
		}

		// Token: 0x060028BB RID: 10427 RVA: 0x0000C3EE File Offset: 0x0000A5EE
		static void smethod_0(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Array.Copy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x060028BC RID: 10428 RVA: 0x000176C9 File Offset: 0x000158C9
		static void smethod_1(Array array_0, Array array_1, int int_0)
		{
			Array.Copy(array_0, array_1, int_0);
		}

		// Token: 0x060028BD RID: 10429 RVA: 0x00016A3D File Offset: 0x00014C3D
		static string smethod_2(char[] char_0, int int_0, int int_1)
		{
			return new string(char_0, int_0, int_1);
		}

		// Token: 0x04000E5D RID: 3677
		private char[] _buffer;

		// Token: 0x04000E5E RID: 3678
		private int _position;

		// Token: 0x04000E5F RID: 3679
		private static readonly char[] EmptyBuffer = new char[0];
	}
}
