﻿using System;
using System.Dynamic;
using System.Linq.Expressions;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x02000296 RID: 662
	internal class NoThrowSetBinderMember : SetMemberBinder
	{
		// Token: 0x06002693 RID: 9875 RVA: 0x0001E365 File Offset: 0x0001C565
		public NoThrowSetBinderMember(SetMemberBinder innerBinder)
			: base(NoThrowSetBinderMember.smethod_0(innerBinder), NoThrowSetBinderMember.smethod_1(innerBinder))
		{
			this._innerBinder = innerBinder;
		}

		// Token: 0x06002694 RID: 9876 RVA: 0x00095F9C File Offset: 0x0009419C
		public override DynamicMetaObject FallbackSetMember(DynamicMetaObject target, DynamicMetaObject value, DynamicMetaObject errorSuggestion)
		{
			DynamicMetaObject dynamicMetaObject = NoThrowSetBinderMember.smethod_2(this._innerBinder, target, new DynamicMetaObject[] { value });
			NoThrowExpressionVisitor noThrowExpressionVisitor = new NoThrowExpressionVisitor();
			Expression expression = NoThrowSetBinderMember.smethod_4(noThrowExpressionVisitor, NoThrowSetBinderMember.smethod_3(dynamicMetaObject));
			return NoThrowSetBinderMember.smethod_6(expression, NoThrowSetBinderMember.smethod_5(dynamicMetaObject));
		}

		// Token: 0x06002695 RID: 9877 RVA: 0x0001BF34 File Offset: 0x0001A134
		static string smethod_0(SetMemberBinder setMemberBinder_0)
		{
			return setMemberBinder_0.Name;
		}

		// Token: 0x06002696 RID: 9878 RVA: 0x0001E380 File Offset: 0x0001C580
		static bool smethod_1(SetMemberBinder setMemberBinder_0)
		{
			return setMemberBinder_0.IgnoreCase;
		}

		// Token: 0x06002697 RID: 9879 RVA: 0x0001E339 File Offset: 0x0001C539
		static DynamicMetaObject smethod_2(DynamicMetaObjectBinder dynamicMetaObjectBinder_0, DynamicMetaObject dynamicMetaObject_0, DynamicMetaObject[] dynamicMetaObject_1)
		{
			return dynamicMetaObjectBinder_0.Bind(dynamicMetaObject_0, dynamicMetaObject_1);
		}

		// Token: 0x06002698 RID: 9880 RVA: 0x0001E343 File Offset: 0x0001C543
		static Expression smethod_3(DynamicMetaObject dynamicMetaObject_0)
		{
			return dynamicMetaObject_0.Expression;
		}

		// Token: 0x06002699 RID: 9881 RVA: 0x0001E34B File Offset: 0x0001C54B
		static Expression smethod_4(ExpressionVisitor expressionVisitor_0, Expression expression_0)
		{
			return expressionVisitor_0.Visit(expression_0);
		}

		// Token: 0x0600269A RID: 9882 RVA: 0x0001E354 File Offset: 0x0001C554
		static BindingRestrictions smethod_5(DynamicMetaObject dynamicMetaObject_0)
		{
			return dynamicMetaObject_0.Restrictions;
		}

		// Token: 0x0600269B RID: 9883 RVA: 0x0001E35C File Offset: 0x0001C55C
		static DynamicMetaObject smethod_6(Expression expression_0, BindingRestrictions bindingRestrictions_0)
		{
			return new DynamicMetaObject(expression_0, bindingRestrictions_0);
		}

		// Token: 0x04000DA9 RID: 3497
		private readonly SetMemberBinder _innerBinder;
	}
}
