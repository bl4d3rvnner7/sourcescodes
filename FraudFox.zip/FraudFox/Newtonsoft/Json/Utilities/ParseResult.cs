﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002BB RID: 699
	internal enum ParseResult
	{
		// Token: 0x04000E21 RID: 3617
		None,
		// Token: 0x04000E22 RID: 3618
		Success,
		// Token: 0x04000E23 RID: 3619
		Overflow,
		// Token: 0x04000E24 RID: 3620
		Invalid
	}
}
