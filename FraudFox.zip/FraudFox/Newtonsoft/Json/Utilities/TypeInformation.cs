﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002BA RID: 698
	internal class TypeInformation
	{
		// Token: 0x170005D9 RID: 1497
		// (get) Token: 0x060027CC RID: 10188 RVA: 0x0001EA78 File Offset: 0x0001CC78
		// (set) Token: 0x060027CD RID: 10189 RVA: 0x0001EA80 File Offset: 0x0001CC80
		public Type Type { get; set; }

		// Token: 0x170005DA RID: 1498
		// (get) Token: 0x060027CE RID: 10190 RVA: 0x0001EA89 File Offset: 0x0001CC89
		// (set) Token: 0x060027CF RID: 10191 RVA: 0x0001EA91 File Offset: 0x0001CC91
		public PrimitiveTypeCode TypeCode { get; set; }
	}
}
