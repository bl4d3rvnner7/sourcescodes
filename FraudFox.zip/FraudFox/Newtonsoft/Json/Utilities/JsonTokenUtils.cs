﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002A4 RID: 676
	internal static class JsonTokenUtils
	{
		// Token: 0x06002769 RID: 10089 RVA: 0x000974D4 File Offset: 0x000956D4
		internal static bool IsEndToken(JsonToken token)
		{
			switch (token)
			{
			case JsonToken.EndObject:
			case JsonToken.EndArray:
			case JsonToken.EndConstructor:
				return true;
			default:
				return false;
			}
		}

		// Token: 0x0600276A RID: 10090 RVA: 0x000974FC File Offset: 0x000956FC
		internal static bool IsStartToken(JsonToken token)
		{
			switch (token)
			{
			case JsonToken.StartObject:
			case JsonToken.StartArray:
			case JsonToken.StartConstructor:
				return true;
			default:
				return false;
			}
		}

		// Token: 0x0600276B RID: 10091 RVA: 0x00097524 File Offset: 0x00095724
		internal static bool IsPrimitiveToken(JsonToken token)
		{
			switch (token)
			{
			case JsonToken.Integer:
			case JsonToken.Float:
			case JsonToken.String:
			case JsonToken.Boolean:
			case JsonToken.Null:
			case JsonToken.Undefined:
			case JsonToken.Date:
			case JsonToken.Bytes:
				return true;
			default:
				return false;
			}
		}
	}
}
