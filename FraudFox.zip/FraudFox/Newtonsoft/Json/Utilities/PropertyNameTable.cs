﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002A5 RID: 677
	internal class PropertyNameTable
	{
		// Token: 0x0600276D RID: 10093 RVA: 0x0001E7B1 File Offset: 0x0001C9B1
		public PropertyNameTable()
		{
			this._entries = new PropertyNameTable.Entry[this._mask + 1];
		}

		// Token: 0x0600276E RID: 10094 RVA: 0x0009756C File Offset: 0x0009576C
		public string Get(char[] key, int start, int length)
		{
			if (length == 0)
			{
				return string.Empty;
			}
			int num = length + PropertyNameTable.HashCodeRandomizer;
			num += (num << 7) ^ (int)key[start];
			int num2 = start + length;
			for (int i = start + 1; i < num2; i++)
			{
				num += (num << 7) ^ (int)key[i];
			}
			num -= num >> 17;
			num -= num >> 11;
			num -= num >> 5;
			for (PropertyNameTable.Entry entry = this._entries[num & this._mask]; entry != null; entry = entry.Next)
			{
				if (entry.HashCode == num && PropertyNameTable.TextEquals(entry.Value, key, start, length))
				{
					return entry.Value;
				}
			}
			return null;
		}

		// Token: 0x0600276F RID: 10095 RVA: 0x00097608 File Offset: 0x00095808
		public string Add(string key)
		{
			if (key == null)
			{
				goto IL_0024;
			}
			goto IL_010A;
			int num;
			PropertyNameTable.Entry entry;
			int num2;
			for (;;)
			{
				IL_00CA:
				int num3;
				switch (num ^ -2062091450)
				{
				case 0:
					if (PropertyNameTable.smethod_4(entry.Value, key))
					{
						goto Block_4;
					}
					goto IL_007B;
				case 1:
					entry = this._entries[num2 & this._mask];
					num = -2062091443;
					continue;
				case 2:
					num2 -= num2 >> 5;
					num = -2062091449;
					continue;
				case 3:
					goto IL_0124;
				case 4:
					goto IL_010A;
				case 5:
					num3 = 0;
					num = -2062091441;
					continue;
				case 6:
					break;
				case 7:
					goto IL_006B;
				case 8:
					goto IL_0065;
				case 9:
					if (num3 >= PropertyNameTable.smethod_2(key))
					{
						num2 -= num2 >> 17;
						num2 -= num2 >> 11;
						num = -2062091452;
						continue;
					}
					break;
				case 10:
					goto IL_0024;
				case 11:
					num = -2062091442;
					continue;
				default:
					goto IL_0065;
				}
				num2 += (num2 << 7) ^ (int)PropertyNameTable.smethod_3(key, num3);
				num3++;
				num = -2062091441;
				continue;
				IL_006B:
				if (entry.HashCode == num2)
				{
					num = -2062091450;
					continue;
				}
				goto IL_007B;
				IL_0065:
				if (entry != null)
				{
					goto IL_006B;
				}
				goto IL_0134;
				IL_007B:
				entry = entry.Next;
				num = -2062091442;
			}
			Block_4:
			return entry.Value;
			IL_0124:
			throw PropertyNameTable.smethod_1(<Module>.smethod_23<string>(2029085134U));
			IL_0134:
			return this.AddEntry(key, num2);
			IL_0024:
			num = -2062091451;
			goto IL_00CA;
			IL_010A:
			int num4 = PropertyNameTable.smethod_2(key);
			if (num4 == 0)
			{
				return string.Empty;
			}
			num2 = num4 + PropertyNameTable.HashCodeRandomizer;
			num = -2062091453;
			goto IL_00CA;
		}

		// Token: 0x06002770 RID: 10096 RVA: 0x00097754 File Offset: 0x00095954
		private string AddEntry(string str, int hashCode)
		{
			int num = hashCode & this._mask;
			PropertyNameTable.Entry entry = new PropertyNameTable.Entry(str, hashCode, this._entries[num]);
			this._entries[num] = entry;
			if (this._count++ == this._mask)
			{
				this.Grow();
			}
			return entry.Value;
		}

		// Token: 0x06002771 RID: 10097 RVA: 0x000977B0 File Offset: 0x000959B0
		private void Grow()
		{
			PropertyNameTable.Entry[] entries = this._entries;
			int num = this._mask * 2 + 1;
			PropertyNameTable.Entry[] array = new PropertyNameTable.Entry[num + 1];
			foreach (PropertyNameTable.Entry entry in entries)
			{
				while (entry != null)
				{
					int num2 = entry.HashCode & num;
					PropertyNameTable.Entry next = entry.Next;
					entry.Next = array[num2];
					array[num2] = entry;
					entry = next;
				}
			}
			this._entries = array;
			this._mask = num;
		}

		// Token: 0x06002772 RID: 10098 RVA: 0x00097834 File Offset: 0x00095A34
		private static bool TextEquals(string str1, char[] str2, int str2Start, int str2Length)
		{
			if (PropertyNameTable.smethod_2(str1) != str2Length)
			{
				return false;
			}
			for (int i = 0; i < PropertyNameTable.smethod_2(str1); i++)
			{
				if (PropertyNameTable.smethod_3(str1, i) != str2[str2Start + i])
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x06002773 RID: 10099 RVA: 0x0001E7D4 File Offset: 0x0001C9D4
		static int smethod_0()
		{
			return Environment.TickCount;
		}

		// Token: 0x06002774 RID: 10100 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_1(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x06002775 RID: 10101 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_2(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06002776 RID: 10102 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_3(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x06002777 RID: 10103 RVA: 0x0000DBC7 File Offset: 0x0000BDC7
		static bool smethod_4(string string_0, string string_1)
		{
			return string_0.Equals(string_1);
		}

		// Token: 0x04000DC9 RID: 3529
		private static readonly int HashCodeRandomizer = PropertyNameTable.smethod_0();

		// Token: 0x04000DCA RID: 3530
		private int _count;

		// Token: 0x04000DCB RID: 3531
		private PropertyNameTable.Entry[] _entries;

		// Token: 0x04000DCC RID: 3532
		private int _mask = 31;

		// Token: 0x020002A6 RID: 678
		private class Entry
		{
			// Token: 0x06002778 RID: 10104 RVA: 0x0001E7DB File Offset: 0x0001C9DB
			internal Entry(string value, int hashCode, PropertyNameTable.Entry next)
			{
				this.Value = value;
				this.HashCode = hashCode;
				this.Next = next;
			}

			// Token: 0x04000DCD RID: 3533
			internal readonly string Value;

			// Token: 0x04000DCE RID: 3534
			internal readonly int HashCode;

			// Token: 0x04000DCF RID: 3535
			internal PropertyNameTable.Entry Next;
		}
	}
}
