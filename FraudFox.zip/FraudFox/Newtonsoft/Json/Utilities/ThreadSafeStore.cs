﻿using System;
using System.Collections.Generic;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002B6 RID: 694
	internal class ThreadSafeStore<TKey, TValue>
	{
		// Token: 0x060027C3 RID: 10179 RVA: 0x0001E9C3 File Offset: 0x0001CBC3
		public ThreadSafeStore(Func<TKey, TValue> creator)
		{
			if (creator == null)
			{
				throw ThreadSafeStore<TKey, TValue>.smethod_1(<Module>.smethod_24<string>(1089296189U));
			}
			this._creator = creator;
			this._store = new Dictionary<TKey, TValue>();
		}

		// Token: 0x060027C4 RID: 10180 RVA: 0x00097D84 File Offset: 0x00095F84
		public TValue Get(TKey key)
		{
			TValue tvalue;
			if (!this._store.TryGetValue(key, out tvalue))
			{
				return this.AddValue(key);
			}
			return tvalue;
		}

		// Token: 0x060027C5 RID: 10181 RVA: 0x00097DAC File Offset: 0x00095FAC
		private TValue AddValue(TKey key)
		{
			TValue tvalue = this._creator(key);
			bool flag = false;
			TValue tvalue3;
			try
			{
				object @lock;
				ThreadSafeStore<TKey, TValue>.smethod_2(@lock = this._lock, ref flag);
				if (this._store == null)
				{
					this._store = new Dictionary<TKey, TValue>();
					this._store[key] = tvalue;
				}
				else
				{
					TValue tvalue2;
					if (this._store.TryGetValue(key, out tvalue2))
					{
						return tvalue2;
					}
					Dictionary<TKey, TValue> dictionary = new Dictionary<TKey, TValue>(this._store);
					dictionary[key] = tvalue;
					ThreadSafeStore<TKey, TValue>.smethod_3();
					this._store = dictionary;
				}
				tvalue3 = tvalue;
			}
			finally
			{
				if (flag)
				{
					object @lock;
					ThreadSafeStore<TKey, TValue>.smethod_4(@lock);
				}
			}
			return tvalue3;
		}

		// Token: 0x04000DE6 RID: 3558
		private readonly object _lock = ThreadSafeStore<TKey, TValue>.smethod_0();

		// Token: 0x04000DE7 RID: 3559
		private Dictionary<TKey, TValue> _store;

		// Token: 0x04000DE8 RID: 3560
		private readonly Func<TKey, TValue> _creator;
	}
}
