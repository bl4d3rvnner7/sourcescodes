﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002C6 RID: 710
	internal static class EnumUtils
	{
		// Token: 0x0600286F RID: 10351 RVA: 0x00099CF0 File Offset: 0x00097EF0
		private static BidirectionalDictionary<string, string> InitializeEnumType(Type type)
		{
			BidirectionalDictionary<string, string> bidirectionalDictionary = new BidirectionalDictionary<string, string>(EnumUtils.smethod_0(), EnumUtils.smethod_0());
			string text;
			for (;;)
			{
				IL_00FF:
				int num = 1051243154;
				for (;;)
				{
					FieldInfo[] array;
					int num2;
					FieldInfo fieldInfo;
					string text3;
					string text4;
					switch (num ^ 1051243153)
					{
					case 0:
						goto IL_00FF;
					case 1:
					{
						string text2;
						if (bidirectionalDictionary.TryGetBySecond(text, out text2))
						{
							goto Block_4;
						}
						goto IL_0081;
					}
					case 2:
						goto IL_00B5;
					case 3:
						array = EnumUtils.smethod_1(type);
						num2 = 0;
						num = 1051243155;
						continue;
					case 4:
						text3 = EnumUtils.smethod_2(fieldInfo);
						num = 1051243159;
						continue;
					case 5:
						goto IL_0081;
					case 6:
						if ((text4 = (from EnumMemberAttribute a in EnumUtils.smethod_4(fieldInfo, EnumUtils.smethod_3(typeof(EnumMemberAttribute).TypeHandle), true)
							select EnumUtils.smethod_27(a)).SingleOrDefault<string>()) == null)
						{
							num = 1051243161;
							continue;
						}
						break;
					case 7:
						goto IL_0027;
					case 8:
						text4 = EnumUtils.smethod_2(fieldInfo);
						break;
					default:
						goto IL_00B5;
					}
					text = text4;
					num = 1051243152;
					continue;
					IL_0027:
					fieldInfo = array[num2];
					num = 1051243157;
					continue;
					IL_00B5:
					if (num2 >= array.Length)
					{
						return bidirectionalDictionary;
					}
					goto IL_0027;
					IL_0081:
					bidirectionalDictionary.Set(text3, text);
					num2++;
					num = 1051243155;
				}
			}
			return bidirectionalDictionary;
			Block_4:
			throw EnumUtils.smethod_6(<Module>.smethod_24<string>(165567371U).FormatWith(EnumUtils.smethod_5(), text, EnumUtils.smethod_2(type)));
		}

		// Token: 0x06002870 RID: 10352 RVA: 0x00099E28 File Offset: 0x00098028
		public static IList<T> GetFlagsValues<T>(T value) where T : struct
		{
			Type type = EnumUtils.smethod_3(typeof(T).TypeHandle);
			if (EnumUtils.smethod_7(type, EnumUtils.smethod_3(typeof(FlagsAttribute).TypeHandle), false))
			{
				Type type2 = EnumUtils.smethod_9(value.GetType());
				ulong num = EnumUtils.smethod_10(value, EnumUtils.smethod_5());
				IList<EnumValue<ulong>> namesAndValues = EnumUtils.GetNamesAndValues<T>();
				IList<T> list = new List<T>();
				IEnumerator<EnumValue<ulong>> enumerator = namesAndValues.GetEnumerator();
				try
				{
					while (EnumUtils.smethod_13(enumerator))
					{
						EnumValue<ulong> enumValue = enumerator.Current;
						if ((num & enumValue.Value) == enumValue.Value && enumValue.Value != 0UL)
						{
							list.Add((T)((object)EnumUtils.smethod_12(enumValue.Value, type2, EnumUtils.smethod_11())));
						}
					}
				}
				finally
				{
					if (enumerator != null)
					{
						EnumUtils.smethod_14(enumerator);
					}
				}
				if (list.Count == 0 && namesAndValues.SingleOrDefault((EnumValue<ulong> v) => v.Value == 0UL) != null)
				{
					list.Add(default(T));
				}
				return list;
			}
			throw EnumUtils.smethod_8(<Module>.smethod_25<string>(204449984U).FormatWith(EnumUtils.smethod_5(), type));
		}

		// Token: 0x06002871 RID: 10353 RVA: 0x0001F43A File Offset: 0x0001D63A
		public static IList<EnumValue<ulong>> GetNamesAndValues<T>() where T : struct
		{
			return EnumUtils.GetNamesAndValues<ulong>(EnumUtils.smethod_3(typeof(T).TypeHandle));
		}

		// Token: 0x06002872 RID: 10354 RVA: 0x00099F58 File Offset: 0x00098158
		public static IList<EnumValue<TUnderlyingType>> GetNamesAndValues<TUnderlyingType>(Type enumType) where TUnderlyingType : struct
		{
			if (EnumUtils.smethod_15(enumType, null))
			{
				throw EnumUtils.smethod_16(<Module>.smethod_24<string>(679764304U));
			}
			ValidationUtils.ArgumentTypeIsEnum(enumType, <Module>.smethod_25<string>(303495310U));
			IList<object> values = EnumUtils.GetValues(enumType);
			IList<string> names = EnumUtils.GetNames(enumType);
			IList<EnumValue<TUnderlyingType>> list = new List<EnumValue<TUnderlyingType>>();
			for (int i = 0; i < values.Count; i++)
			{
				try
				{
					list.Add(new EnumValue<TUnderlyingType>(names[i], (TUnderlyingType)((object)EnumUtils.smethod_12(values[i], EnumUtils.smethod_3(typeof(TUnderlyingType).TypeHandle), EnumUtils.smethod_11()))));
				}
				catch (OverflowException ex)
				{
					throw EnumUtils.smethod_18(EnumUtils.smethod_17(EnumUtils.smethod_5(), <Module>.smethod_24<string>(3525122981U), new object[]
					{
						EnumUtils.smethod_9(enumType),
						EnumUtils.smethod_3(typeof(TUnderlyingType).TypeHandle),
						EnumUtils.smethod_10(values[i], EnumUtils.smethod_5())
					}), ex);
				}
			}
			return list;
		}

		// Token: 0x06002873 RID: 10355 RVA: 0x0009A058 File Offset: 0x00098258
		public static IList<object> GetValues(Type enumType)
		{
			if (!enumType.IsEnum())
			{
				throw EnumUtils.smethod_8(EnumUtils.smethod_19(<Module>.smethod_27<string>(4272856105U), EnumUtils.smethod_2(enumType), <Module>.smethod_26<string>(3973460660U)));
			}
			List<object> list = new List<object>();
			IEnumerable<FieldInfo> enumerable = from f in EnumUtils.smethod_1(enumType)
				where EnumUtils.smethod_28(f)
				select f;
			IEnumerator<FieldInfo> enumerator = enumerable.GetEnumerator();
			try
			{
				while (EnumUtils.smethod_13(enumerator))
				{
					FieldInfo fieldInfo = enumerator.Current;
					object obj = EnumUtils.smethod_20(fieldInfo, enumType);
					list.Add(obj);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					EnumUtils.smethod_14(enumerator);
				}
			}
			return list;
		}

		// Token: 0x06002874 RID: 10356 RVA: 0x0009A108 File Offset: 0x00098308
		public static IList<string> GetNames(Type enumType)
		{
			if (!enumType.IsEnum())
			{
				throw EnumUtils.smethod_8(EnumUtils.smethod_19(<Module>.smethod_24<string>(2183231484U), EnumUtils.smethod_2(enumType), <Module>.smethod_26<string>(3973460660U)));
			}
			List<string> list = new List<string>();
			IEnumerable<FieldInfo> enumerable = from f in EnumUtils.smethod_1(enumType)
				where EnumUtils.smethod_28(f)
				select f;
			IEnumerator<FieldInfo> enumerator = enumerable.GetEnumerator();
			try
			{
				while (EnumUtils.smethod_13(enumerator))
				{
					FieldInfo fieldInfo = enumerator.Current;
					list.Add(EnumUtils.smethod_2(fieldInfo));
				}
			}
			finally
			{
				if (enumerator != null)
				{
					EnumUtils.smethod_14(enumerator);
				}
			}
			return list;
		}

		// Token: 0x06002875 RID: 10357 RVA: 0x0009A1B4 File Offset: 0x000983B4
		public static object ParseEnumName(string enumText, bool isNullable, Type t)
		{
			if (EnumUtils.smethod_21(enumText, string.Empty) && isNullable)
			{
				return null;
			}
			BidirectionalDictionary<string, string> bidirectionalDictionary = EnumUtils.EnumMemberNamesPerType.Get(t);
			string text;
			if (EnumUtils.smethod_22(enumText, ',') == -1)
			{
				text = EnumUtils.ResolvedEnumName(bidirectionalDictionary, enumText);
			}
			else
			{
				string[] array = EnumUtils.smethod_23(enumText, new char[] { ',' });
				for (int i = 0; i < array.Length; i++)
				{
					string text2 = EnumUtils.smethod_24(array[i]);
					array[i] = EnumUtils.ResolvedEnumName(bidirectionalDictionary, text2);
				}
				text = EnumUtils.smethod_25(<Module>.smethod_25<string>(1412486966U), array);
			}
			return EnumUtils.smethod_26(t, text, true);
		}

		// Token: 0x06002876 RID: 10358 RVA: 0x0009A250 File Offset: 0x00098450
		public static string ToEnumName(Type enumType, string enumText, bool camelCaseText)
		{
			BidirectionalDictionary<string, string> bidirectionalDictionary = EnumUtils.EnumMemberNamesPerType.Get(enumType);
			string[] array = EnumUtils.smethod_23(enumText, new char[] { ',' });
			for (int i = 0; i < array.Length; i++)
			{
				string text = EnumUtils.smethod_24(array[i]);
				string text2;
				bidirectionalDictionary.TryGetByFirst(text, out text2);
				text2 = text2 ?? text;
				if (camelCaseText)
				{
					text2 = StringUtils.ToCamelCase(text2);
				}
				array[i] = text2;
			}
			return EnumUtils.smethod_25(<Module>.smethod_26<string>(1625281455U), array);
		}

		// Token: 0x06002877 RID: 10359 RVA: 0x0009A2D8 File Offset: 0x000984D8
		private static string ResolvedEnumName(BidirectionalDictionary<string, string> map, string enumText)
		{
			string text;
			map.TryGetBySecond(enumText, out text);
			text = text ?? enumText;
			return text;
		}

		// Token: 0x0600287D RID: 10365 RVA: 0x00014724 File Offset: 0x00012924
		static StringComparer smethod_0()
		{
			return StringComparer.OrdinalIgnoreCase;
		}

		// Token: 0x0600287E RID: 10366 RVA: 0x0001F486 File Offset: 0x0001D686
		static FieldInfo[] smethod_1(Type type_0)
		{
			return type_0.GetFields();
		}

		// Token: 0x0600287F RID: 10367 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_2(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x06002880 RID: 10368 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_3(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06002881 RID: 10369 RVA: 0x000130EC File Offset: 0x000112EC
		static object[] smethod_4(MemberInfo memberInfo_0, Type type_0, bool bool_0)
		{
			return memberInfo_0.GetCustomAttributes(type_0, bool_0);
		}

		// Token: 0x06002882 RID: 10370 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_5()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06002883 RID: 10371 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_6(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x06002884 RID: 10372 RVA: 0x0001CA03 File Offset: 0x0001AC03
		static bool smethod_7(MemberInfo memberInfo_0, Type type_0, bool bool_0)
		{
			return memberInfo_0.IsDefined(type_0, bool_0);
		}

		// Token: 0x06002885 RID: 10373 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_8(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x06002886 RID: 10374 RVA: 0x0001EAD4 File Offset: 0x0001CCD4
		static Type smethod_9(Type type_0)
		{
			return Enum.GetUnderlyingType(type_0);
		}

		// Token: 0x06002887 RID: 10375 RVA: 0x00018E76 File Offset: 0x00017076
		static ulong smethod_10(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToUInt64(object_0, iformatProvider_0);
		}

		// Token: 0x06002888 RID: 10376 RVA: 0x00019275 File Offset: 0x00017475
		static CultureInfo smethod_11()
		{
			return CultureInfo.CurrentCulture;
		}

		// Token: 0x06002889 RID: 10377 RVA: 0x000193D1 File Offset: 0x000175D1
		static object smethod_12(object object_0, Type type_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ChangeType(object_0, type_0, iformatProvider_0);
		}

		// Token: 0x0600288A RID: 10378 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_13(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x0600288B RID: 10379 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_14(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x0600288C RID: 10380 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_15(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x0600288D RID: 10381 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_16(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x0600288E RID: 10382 RVA: 0x0000EAE8 File Offset: 0x0000CCE8
		static string smethod_17(IFormatProvider iformatProvider_0, string string_0, object[] object_0)
		{
			return string.Format(iformatProvider_0, string_0, object_0);
		}

		// Token: 0x0600288F RID: 10383 RVA: 0x0000DF95 File Offset: 0x0000C195
		static InvalidOperationException smethod_18(string string_0, Exception exception_0)
		{
			return new InvalidOperationException(string_0, exception_0);
		}

		// Token: 0x06002890 RID: 10384 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_19(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x06002891 RID: 10385 RVA: 0x0001E4D9 File Offset: 0x0001C6D9
		static object smethod_20(FieldInfo fieldInfo_0, object object_0)
		{
			return fieldInfo_0.GetValue(object_0);
		}

		// Token: 0x06002892 RID: 10386 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_21(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06002893 RID: 10387 RVA: 0x0000FABD File Offset: 0x0000DCBD
		static int smethod_22(string string_0, char char_0)
		{
			return string_0.IndexOf(char_0);
		}

		// Token: 0x06002894 RID: 10388 RVA: 0x0000C693 File Offset: 0x0000A893
		static string[] smethod_23(string string_0, char[] char_0)
		{
			return string_0.Split(char_0);
		}

		// Token: 0x06002895 RID: 10389 RVA: 0x0000C6B8 File Offset: 0x0000A8B8
		static string smethod_24(string string_0)
		{
			return string_0.Trim();
		}

		// Token: 0x06002896 RID: 10390 RVA: 0x0000DAF6 File Offset: 0x0000BCF6
		static string smethod_25(string string_0, string[] string_1)
		{
			return string.Join(string_0, string_1);
		}

		// Token: 0x06002897 RID: 10391 RVA: 0x00013078 File Offset: 0x00011278
		static object smethod_26(Type type_0, string string_0, bool bool_0)
		{
			return Enum.Parse(type_0, string_0, bool_0);
		}

		// Token: 0x06002898 RID: 10392 RVA: 0x0001F48E File Offset: 0x0001D68E
		static string smethod_27(EnumMemberAttribute enumMemberAttribute_0)
		{
			return enumMemberAttribute_0.Value;
		}

		// Token: 0x06002899 RID: 10393 RVA: 0x0001E4D1 File Offset: 0x0001C6D1
		static bool smethod_28(FieldInfo fieldInfo_0)
		{
			return fieldInfo_0.IsLiteral;
		}

		// Token: 0x04000E40 RID: 3648
		private static readonly ThreadSafeStore<Type, BidirectionalDictionary<string, string>> EnumMemberNamesPerType = new ThreadSafeStore<Type, BidirectionalDictionary<string, string>>(new Func<Type, BidirectionalDictionary<string, string>>(EnumUtils.InitializeEnumType));
	}
}
