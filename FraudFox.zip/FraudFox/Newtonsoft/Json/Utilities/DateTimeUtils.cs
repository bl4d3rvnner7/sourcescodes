﻿using System;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Xml;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002C2 RID: 706
	internal static class DateTimeUtils
	{
		// Token: 0x06002820 RID: 10272 RVA: 0x0001EEE5 File Offset: 0x0001D0E5
		static DateTimeUtils()
		{
			int[] array = new int[13];
			DateTimeUtils.smethod_0(array, fieldof(<PrivateImplementationDetails>{2050F94B-4B51-45A2-913D-663F8B3DB301}.$$method0x6000b21-1).FieldHandle);
			DateTimeUtils.DaysToMonth365 = array;
			int[] array2 = new int[13];
			DateTimeUtils.smethod_0(array2, fieldof(<PrivateImplementationDetails>{2050F94B-4B51-45A2-913D-663F8B3DB301}.$$method0x6000b21-2).FieldHandle);
			DateTimeUtils.DaysToMonth366 = array2;
		}

		// Token: 0x06002821 RID: 10273 RVA: 0x0001EF23 File Offset: 0x0001D123
		public static TimeSpan GetUtcOffset(this DateTime d)
		{
			return DateTimeUtils.smethod_2(DateTimeUtils.smethod_1(), d);
		}

		// Token: 0x06002822 RID: 10274 RVA: 0x00098F78 File Offset: 0x00097178
		public static XmlDateTimeSerializationMode ToSerializationMode(DateTimeKind kind)
		{
			switch (kind)
			{
			case DateTimeKind.Unspecified:
				return XmlDateTimeSerializationMode.Unspecified;
			case DateTimeKind.Utc:
				return XmlDateTimeSerializationMode.Utc;
			case DateTimeKind.Local:
				return XmlDateTimeSerializationMode.Local;
			default:
				throw MiscellaneousUtils.CreateArgumentOutOfRangeException(<Module>.smethod_25<string>(1158739536U), kind, <Module>.smethod_24<string>(4176506920U));
			}
		}

		// Token: 0x06002823 RID: 10275 RVA: 0x00098FC0 File Offset: 0x000971C0
		internal static DateTime EnsureDateTime(DateTime value, DateTimeZoneHandling timeZone)
		{
			switch (timeZone)
			{
			case DateTimeZoneHandling.Local:
				value = DateTimeUtils.SwitchToLocalTime(value);
				break;
			case DateTimeZoneHandling.Utc:
				value = DateTimeUtils.SwitchToUtcTime(value);
				break;
			case DateTimeZoneHandling.Unspecified:
				value = new DateTime(value.Ticks, DateTimeKind.Unspecified);
				break;
			case DateTimeZoneHandling.RoundtripKind:
				break;
			default:
				throw new ArgumentException(<Module>.smethod_27<string>(1895149762U));
			}
			return value;
		}

		// Token: 0x06002824 RID: 10276 RVA: 0x0009901C File Offset: 0x0009721C
		private static DateTime SwitchToLocalTime(DateTime value)
		{
			switch (value.Kind)
			{
			case DateTimeKind.Unspecified:
				return new DateTime(value.Ticks, DateTimeKind.Local);
			case DateTimeKind.Utc:
				return value.ToLocalTime();
			case DateTimeKind.Local:
				return value;
			default:
				return value;
			}
		}

		// Token: 0x06002825 RID: 10277 RVA: 0x0009905C File Offset: 0x0009725C
		private static DateTime SwitchToUtcTime(DateTime value)
		{
			switch (value.Kind)
			{
			case DateTimeKind.Unspecified:
				return new DateTime(value.Ticks, DateTimeKind.Utc);
			case DateTimeKind.Utc:
				return value;
			case DateTimeKind.Local:
				return value.ToUniversalTime();
			default:
				return value;
			}
		}

		// Token: 0x06002826 RID: 10278 RVA: 0x0001EF30 File Offset: 0x0001D130
		private static long ToUniversalTicks(DateTime dateTime)
		{
			if (dateTime.Kind == DateTimeKind.Utc)
			{
				return dateTime.Ticks;
			}
			return DateTimeUtils.ToUniversalTicks(dateTime, dateTime.GetUtcOffset());
		}

		// Token: 0x06002827 RID: 10279 RVA: 0x0009909C File Offset: 0x0009729C
		private static long ToUniversalTicks(DateTime dateTime, TimeSpan offset)
		{
			if (dateTime.Kind == DateTimeKind.Utc || dateTime == DateTime.MaxValue || dateTime == DateTime.MinValue)
			{
				return dateTime.Ticks;
			}
			long num = dateTime.Ticks - offset.Ticks;
			if (num > 3155378975999999999L)
			{
				return 3155378975999999999L;
			}
			if (num < 0L)
			{
				return 0L;
			}
			return num;
		}

		// Token: 0x06002828 RID: 10280 RVA: 0x00099114 File Offset: 0x00097314
		internal static long ConvertDateTimeToJavaScriptTicks(DateTime dateTime, TimeSpan offset)
		{
			long num = DateTimeUtils.ToUniversalTicks(dateTime, offset);
			return DateTimeUtils.UniversialTicksToJavaScriptTicks(num);
		}

		// Token: 0x06002829 RID: 10281 RVA: 0x0001EF50 File Offset: 0x0001D150
		internal static long ConvertDateTimeToJavaScriptTicks(DateTime dateTime)
		{
			return DateTimeUtils.ConvertDateTimeToJavaScriptTicks(dateTime, true);
		}

		// Token: 0x0600282A RID: 10282 RVA: 0x00099130 File Offset: 0x00097330
		internal static long ConvertDateTimeToJavaScriptTicks(DateTime dateTime, bool convertToUtc)
		{
			long num = (convertToUtc ? DateTimeUtils.ToUniversalTicks(dateTime) : dateTime.Ticks);
			return DateTimeUtils.UniversialTicksToJavaScriptTicks(num);
		}

		// Token: 0x0600282B RID: 10283 RVA: 0x00099158 File Offset: 0x00097358
		private static long UniversialTicksToJavaScriptTicks(long universialTicks)
		{
			return (universialTicks - DateTimeUtils.InitialJavaScriptDateTicks) / 10000L;
		}

		// Token: 0x0600282C RID: 10284 RVA: 0x00099178 File Offset: 0x00097378
		internal static DateTime ConvertJavaScriptTicksToDateTime(long javaScriptTicks)
		{
			DateTime dateTime = new DateTime(javaScriptTicks * 10000L + DateTimeUtils.InitialJavaScriptDateTicks, DateTimeKind.Utc);
			return dateTime;
		}

		// Token: 0x0600282D RID: 10285 RVA: 0x000991A0 File Offset: 0x000973A0
		internal static bool TryParseDateIso(string text, DateParseHandling dateParseHandling, DateTimeZoneHandling dateTimeZoneHandling, out object dt)
		{
			DateTimeParser dateTimeParser = default(DateTimeParser);
			if (!dateTimeParser.Parse(text))
			{
				dt = null;
				return false;
			}
			DateTime dateTime = new DateTime(dateTimeParser.Year, dateTimeParser.Month, dateTimeParser.Day, dateTimeParser.Hour, dateTimeParser.Minute, dateTimeParser.Second);
			dateTime = dateTime.AddTicks((long)dateTimeParser.Fraction);
			if (dateParseHandling != DateParseHandling.DateTimeOffset)
			{
				switch (dateTimeParser.Zone)
				{
				case ParserTimeZone.Utc:
					dateTime = new DateTime(dateTime.Ticks, DateTimeKind.Utc);
					break;
				case ParserTimeZone.LocalWestOfUtc:
				{
					TimeSpan timeSpan = new TimeSpan(dateTimeParser.ZoneHour, dateTimeParser.ZoneMinute, 0);
					long num = dateTime.Ticks + timeSpan.Ticks;
					if (num <= DateTime.MaxValue.Ticks)
					{
						dateTime = new DateTime(num, DateTimeKind.Utc).ToLocalTime();
					}
					else
					{
						num += dateTime.GetUtcOffset().Ticks;
						if (num > DateTime.MaxValue.Ticks)
						{
							num = DateTime.MaxValue.Ticks;
						}
						dateTime = new DateTime(num, DateTimeKind.Local);
					}
					break;
				}
				case ParserTimeZone.LocalEastOfUtc:
				{
					TimeSpan timeSpan2 = new TimeSpan(dateTimeParser.ZoneHour, dateTimeParser.ZoneMinute, 0);
					long num = dateTime.Ticks - timeSpan2.Ticks;
					if (num >= DateTime.MinValue.Ticks)
					{
						dateTime = new DateTime(num, DateTimeKind.Utc).ToLocalTime();
					}
					else
					{
						num += dateTime.GetUtcOffset().Ticks;
						if (num < DateTime.MinValue.Ticks)
						{
							num = DateTime.MinValue.Ticks;
						}
						dateTime = new DateTime(num, DateTimeKind.Local);
					}
					break;
				}
				}
				dt = DateTimeUtils.EnsureDateTime(dateTime, dateTimeZoneHandling);
				return true;
			}
			TimeSpan utcOffset;
			switch (dateTimeParser.Zone)
			{
			case ParserTimeZone.Utc:
				utcOffset = new TimeSpan(0L);
				break;
			case ParserTimeZone.LocalWestOfUtc:
				utcOffset = new TimeSpan(-dateTimeParser.ZoneHour, -dateTimeParser.ZoneMinute, 0);
				break;
			case ParserTimeZone.LocalEastOfUtc:
				utcOffset = new TimeSpan(dateTimeParser.ZoneHour, dateTimeParser.ZoneMinute, 0);
				break;
			default:
				utcOffset = TimeZoneInfo.Local.GetUtcOffset(dateTime);
				break;
			}
			long num2 = dateTime.Ticks - utcOffset.Ticks;
			if (num2 >= 0L && num2 <= 3155378975999999999L)
			{
				dt = new DateTimeOffset(dateTime, utcOffset);
				return true;
			}
			dt = null;
			return false;
		}

		// Token: 0x0600282E RID: 10286 RVA: 0x00099420 File Offset: 0x00097620
		internal static bool TryParseDateTime(string s, DateParseHandling dateParseHandling, DateTimeZoneHandling dateTimeZoneHandling, string dateFormatString, CultureInfo culture, out object dt)
		{
			if (DateTimeUtils.smethod_3(s) > 0)
			{
				if (DateTimeUtils.smethod_4(s, 0) == '/')
				{
					if (DateTimeUtils.smethod_5(s, <Module>.smethod_27<string>(1801906376U), StringComparison.Ordinal) && DateTimeUtils.smethod_6(s, <Module>.smethod_25<string>(2829078408U), StringComparison.Ordinal) && DateTimeUtils.TryParseDateMicrosoft(s, dateParseHandling, dateTimeZoneHandling, out dt))
					{
						return true;
					}
				}
				else if (DateTimeUtils.smethod_3(s) >= 19 && DateTimeUtils.smethod_3(s) <= 40 && char.IsDigit(DateTimeUtils.smethod_4(s, 0)) && DateTimeUtils.smethod_4(s, 10) == 'T' && DateTimeUtils.TryParseDateIso(s, dateParseHandling, dateTimeZoneHandling, out dt))
				{
					return true;
				}
				if (!DateTimeUtils.smethod_7(dateFormatString) && DateTimeUtils.TryParseDateExact(s, dateParseHandling, dateTimeZoneHandling, dateFormatString, culture, out dt))
				{
					return true;
				}
			}
			dt = null;
			return false;
		}

		// Token: 0x0600282F RID: 10287 RVA: 0x000994D4 File Offset: 0x000976D4
		private static bool TryParseDateMicrosoft(string text, DateParseHandling dateParseHandling, DateTimeZoneHandling dateTimeZoneHandling, out object dt)
		{
			string text2 = DateTimeUtils.smethod_8(text, 6, DateTimeUtils.smethod_3(text) - 8);
			DateTimeKind dateTimeKind = DateTimeKind.Utc;
			int num = DateTimeUtils.smethod_9(text2, '+', 1);
			if (num == -1)
			{
				num = DateTimeUtils.smethod_9(text2, '-', 1);
			}
			TimeSpan timeSpan = TimeSpan.Zero;
			if (num != -1)
			{
				dateTimeKind = DateTimeKind.Local;
				timeSpan = DateTimeUtils.ReadOffset(DateTimeUtils.smethod_10(text2, num));
				text2 = DateTimeUtils.smethod_8(text2, 0, num);
			}
			long num2;
			if (!long.TryParse(text2, NumberStyles.Integer, DateTimeUtils.smethod_11(), out num2))
			{
				dt = null;
				return false;
			}
			DateTime dateTime = DateTimeUtils.ConvertJavaScriptTicksToDateTime(num2);
			if (dateParseHandling == DateParseHandling.DateTimeOffset)
			{
				dt = new DateTimeOffset(dateTime.Add(timeSpan).Ticks, timeSpan);
				return true;
			}
			DateTime dateTime2;
			switch (dateTimeKind)
			{
			case DateTimeKind.Unspecified:
				dateTime2 = DateTime.SpecifyKind(dateTime.ToLocalTime(), DateTimeKind.Unspecified);
				goto IL_00C3;
			case DateTimeKind.Local:
				dateTime2 = dateTime.ToLocalTime();
				goto IL_00C3;
			}
			dateTime2 = dateTime;
			IL_00C3:
			dt = DateTimeUtils.EnsureDateTime(dateTime2, dateTimeZoneHandling);
			return true;
		}

		// Token: 0x06002830 RID: 10288 RVA: 0x000995BC File Offset: 0x000977BC
		private static bool TryParseDateExact(string text, DateParseHandling dateParseHandling, DateTimeZoneHandling dateTimeZoneHandling, string dateFormatString, CultureInfo culture, out object dt)
		{
			DateTime dateTime;
			if (dateParseHandling == DateParseHandling.DateTimeOffset)
			{
				DateTimeOffset dateTimeOffset;
				if (DateTimeOffset.TryParseExact(text, dateFormatString, culture, DateTimeStyles.RoundtripKind, out dateTimeOffset))
				{
					dt = dateTimeOffset;
					return true;
				}
			}
			else if (DateTime.TryParseExact(text, dateFormatString, culture, DateTimeStyles.RoundtripKind, out dateTime))
			{
				dateTime = DateTimeUtils.EnsureDateTime(dateTime, dateTimeZoneHandling);
				dt = dateTime;
				return true;
			}
			dt = null;
			return false;
		}

		// Token: 0x06002831 RID: 10289 RVA: 0x00099614 File Offset: 0x00097814
		private static TimeSpan ReadOffset(string offsetText)
		{
			bool flag = DateTimeUtils.smethod_4(offsetText, 0) == '-';
			int num = int.Parse(DateTimeUtils.smethod_8(offsetText, 1, 2), NumberStyles.Integer, DateTimeUtils.smethod_11());
			int num2 = 0;
			if (DateTimeUtils.smethod_3(offsetText) >= 5)
			{
				num2 = int.Parse(DateTimeUtils.smethod_8(offsetText, 3, 2), NumberStyles.Integer, DateTimeUtils.smethod_11());
			}
			TimeSpan timeSpan = TimeSpan.FromHours((double)num) + TimeSpan.FromMinutes((double)num2);
			if (flag)
			{
				timeSpan = timeSpan.Negate();
			}
			return timeSpan;
		}

		// Token: 0x06002832 RID: 10290 RVA: 0x00099680 File Offset: 0x00097880
		internal static void WriteDateTimeString(TextWriter writer, DateTime value, DateFormatHandling format, string formatString, CultureInfo culture)
		{
			if (DateTimeUtils.smethod_7(formatString))
			{
				char[] array = new char[64];
				int num = DateTimeUtils.WriteDateTimeString(array, 0, value, null, value.Kind, format);
				writer.Write(array, 0, num);
				return;
			}
			writer.Write(value.ToString(formatString, culture));
		}

		// Token: 0x06002833 RID: 10291 RVA: 0x000996D4 File Offset: 0x000978D4
		internal static int WriteDateTimeString(char[] chars, int start, DateTime value, TimeSpan? offset, DateTimeKind kind, DateFormatHandling format)
		{
			int num2;
			if (format == DateFormatHandling.MicrosoftDateFormat)
			{
				TimeSpan timeSpan = offset ?? value.GetUtcOffset();
				long num = DateTimeUtils.ConvertDateTimeToJavaScriptTicks(value, timeSpan);
				DateTimeUtils.smethod_12(<Module>.smethod_25<string>(2689883502U), 0, chars, start, 7);
				num2 = start + 7;
				string text = num.ToString(DateTimeUtils.smethod_11());
				text.CopyTo(0, chars, num2, text.Length);
				num2 += text.Length;
				switch (kind)
				{
				case DateTimeKind.Unspecified:
					if (value != DateTime.MaxValue && value != DateTime.MinValue)
					{
						num2 = DateTimeUtils.WriteDateTimeOffset(chars, num2, timeSpan, format);
					}
					break;
				case DateTimeKind.Local:
					num2 = DateTimeUtils.WriteDateTimeOffset(chars, num2, timeSpan, format);
					break;
				}
				<Module>.smethod_23<string>(1562537216U).CopyTo(0, chars, num2, 3);
				num2 += 3;
			}
			else
			{
				num2 = DateTimeUtils.WriteDefaultIsoDate(chars, start, value);
				switch (kind)
				{
				case DateTimeKind.Utc:
					chars[num2++] = 'Z';
					break;
				case DateTimeKind.Local:
					num2 = DateTimeUtils.WriteDateTimeOffset(chars, num2, offset ?? value.GetUtcOffset(), format);
					break;
				}
			}
			return num2;
		}

		// Token: 0x06002834 RID: 10292 RVA: 0x00099804 File Offset: 0x00097A04
		internal static int WriteDefaultIsoDate(char[] chars, int start, DateTime dt)
		{
			int num = 19;
			int num2;
			int num3;
			int num4;
			DateTimeUtils.GetDateValues(dt, out num2, out num3, out num4);
			DateTimeUtils.CopyIntToCharArray(chars, start, num2, 4);
			chars[start + 4] = '-';
			DateTimeUtils.CopyIntToCharArray(chars, start + 5, num3, 2);
			chars[start + 7] = '-';
			DateTimeUtils.CopyIntToCharArray(chars, start + 8, num4, 2);
			chars[start + 10] = 'T';
			DateTimeUtils.CopyIntToCharArray(chars, start + 11, dt.Hour, 2);
			chars[start + 13] = ':';
			DateTimeUtils.CopyIntToCharArray(chars, start + 14, dt.Minute, 2);
			chars[start + 16] = ':';
			DateTimeUtils.CopyIntToCharArray(chars, start + 17, dt.Second, 2);
			int num5 = (int)(dt.Ticks % 10000000L);
			if (num5 != 0)
			{
				int num6 = 7;
				while (num5 % 10 == 0)
				{
					num6--;
					num5 /= 10;
				}
				chars[start + 19] = '.';
				DateTimeUtils.CopyIntToCharArray(chars, start + 20, num5, num6);
				num += num6 + 1;
			}
			return start + num;
		}

		// Token: 0x06002835 RID: 10293 RVA: 0x0001EF59 File Offset: 0x0001D159
		private static void CopyIntToCharArray(char[] chars, int start, int value, int digits)
		{
			while (digits-- != 0)
			{
				chars[start + digits] = (char)(value % 10 + 48);
				value /= 10;
			}
		}

		// Token: 0x06002836 RID: 10294 RVA: 0x000998EC File Offset: 0x00097AEC
		internal static int WriteDateTimeOffset(char[] chars, int start, TimeSpan offset, DateFormatHandling format)
		{
			chars[start++] = ((offset.Ticks >= 0L) ? '+' : '-');
			int num = Math.Abs(offset.Hours);
			DateTimeUtils.CopyIntToCharArray(chars, start, num, 2);
			start += 2;
			if (format == DateFormatHandling.IsoDateFormat)
			{
				chars[start++] = ':';
			}
			int num2 = Math.Abs(offset.Minutes);
			DateTimeUtils.CopyIntToCharArray(chars, start, num2, 2);
			start += 2;
			return start;
		}

		// Token: 0x06002837 RID: 10295 RVA: 0x00099960 File Offset: 0x00097B60
		internal static void WriteDateTimeOffsetString(TextWriter writer, DateTimeOffset value, DateFormatHandling format, string formatString, CultureInfo culture)
		{
			if (DateTimeUtils.smethod_7(formatString))
			{
				char[] array = new char[64];
				int num = DateTimeUtils.WriteDateTimeString(array, 0, (format == DateFormatHandling.IsoDateFormat) ? value.DateTime : value.UtcDateTime, new TimeSpan?(value.Offset), DateTimeKind.Local, format);
				writer.Write(array, 0, num);
				return;
			}
			writer.Write(value.ToString(formatString, culture));
		}

		// Token: 0x06002838 RID: 10296 RVA: 0x000999C0 File Offset: 0x00097BC0
		private static void GetDateValues(DateTime td, out int year, out int month, out int day)
		{
			long ticks = td.Ticks;
			int i = (int)(ticks / 864000000000L);
			int num = i / 146097;
			i -= num * 146097;
			int num2 = i / 36524;
			if (num2 == 4)
			{
				num2 = 3;
			}
			i -= num2 * 36524;
			int num3 = i / 1461;
			i -= num3 * 1461;
			int num4 = i / 365;
			if (num4 == 4)
			{
				num4 = 3;
			}
			year = num * 400 + num2 * 100 + num3 * 4 + num4 + 1;
			i -= num4 * 365;
			int[] array = ((num4 == 3 && (num3 != 24 || num2 == 3)) ? DateTimeUtils.DaysToMonth366 : DateTimeUtils.DaysToMonth365);
			int num5 = i >> 6;
			while (i >= array[num5])
			{
				num5++;
			}
			month = num5;
			day = i - array[num5 - 1] + 1;
		}

		// Token: 0x06002839 RID: 10297 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_0(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x0600283A RID: 10298 RVA: 0x0001EF79 File Offset: 0x0001D179
		static TimeZoneInfo smethod_1()
		{
			return TimeZoneInfo.Local;
		}

		// Token: 0x0600283B RID: 10299 RVA: 0x0001EF80 File Offset: 0x0001D180
		static TimeSpan smethod_2(TimeZoneInfo timeZoneInfo_0, DateTime dateTime_0)
		{
			return timeZoneInfo_0.GetUtcOffset(dateTime_0);
		}

		// Token: 0x0600283C RID: 10300 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_3(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x0600283D RID: 10301 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_4(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x0600283E RID: 10302 RVA: 0x0000F8C5 File Offset: 0x0000DAC5
		static bool smethod_5(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.StartsWith(string_1, stringComparison_0);
		}

		// Token: 0x0600283F RID: 10303 RVA: 0x00017AA7 File Offset: 0x00015CA7
		static bool smethod_6(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.EndsWith(string_1, stringComparison_0);
		}

		// Token: 0x06002840 RID: 10304 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_7(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06002841 RID: 10305 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_8(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x06002842 RID: 10306 RVA: 0x0000EE25 File Offset: 0x0000D025
		static int smethod_9(string string_0, char char_0, int int_0)
		{
			return string_0.IndexOf(char_0, int_0);
		}

		// Token: 0x06002843 RID: 10307 RVA: 0x0000D416 File Offset: 0x0000B616
		static string smethod_10(string string_0, int int_0)
		{
			return string_0.Substring(int_0);
		}

		// Token: 0x06002844 RID: 10308 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_11()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06002845 RID: 10309 RVA: 0x0001EF89 File Offset: 0x0001D189
		static void smethod_12(string string_0, int int_0, char[] char_0, int int_1, int int_2)
		{
			string_0.CopyTo(int_0, char_0, int_1, int_2);
		}

		// Token: 0x04000E33 RID: 3635
		private const int DaysPer100Years = 36524;

		// Token: 0x04000E34 RID: 3636
		private const int DaysPer400Years = 146097;

		// Token: 0x04000E35 RID: 3637
		private const int DaysPer4Years = 1461;

		// Token: 0x04000E36 RID: 3638
		private const int DaysPerYear = 365;

		// Token: 0x04000E37 RID: 3639
		private const long TicksPerDay = 864000000000L;

		// Token: 0x04000E38 RID: 3640
		internal static readonly long InitialJavaScriptDateTicks = 621355968000000000L;

		// Token: 0x04000E39 RID: 3641
		private static readonly int[] DaysToMonth365;

		// Token: 0x04000E3A RID: 3642
		private static readonly int[] DaysToMonth366;
	}
}
