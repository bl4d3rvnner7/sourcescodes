﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002D2 RID: 722
	internal static class StringUtils
	{
		// Token: 0x06002997 RID: 10647 RVA: 0x0009C254 File Offset: 0x0009A454
		public static string FormatWith(this string format, IFormatProvider provider, object arg0)
		{
			return format.FormatWith(provider, new object[] { arg0 });
		}

		// Token: 0x06002998 RID: 10648 RVA: 0x0009C274 File Offset: 0x0009A474
		public static string FormatWith(this string format, IFormatProvider provider, object arg0, object arg1)
		{
			return format.FormatWith(provider, new object[] { arg0, arg1 });
		}

		// Token: 0x06002999 RID: 10649 RVA: 0x0009C298 File Offset: 0x0009A498
		public static string FormatWith(this string format, IFormatProvider provider, object arg0, object arg1, object arg2)
		{
			return format.FormatWith(provider, new object[] { arg0, arg1, arg2 });
		}

		// Token: 0x0600299A RID: 10650 RVA: 0x0009C2C4 File Offset: 0x0009A4C4
		public static string FormatWith(this string format, IFormatProvider provider, object arg0, object arg1, object arg2, object arg3)
		{
			return format.FormatWith(provider, new object[] { arg0, arg1, arg2, arg3 });
		}

		// Token: 0x0600299B RID: 10651 RVA: 0x0001F93B File Offset: 0x0001DB3B
		private static string FormatWith(this string format, IFormatProvider provider, params object[] args)
		{
			ValidationUtils.ArgumentNotNull(format, <Module>.smethod_27<string>(581344889U));
			return StringUtils.smethod_0(provider, format, args);
		}

		// Token: 0x0600299C RID: 10652 RVA: 0x0009C2F4 File Offset: 0x0009A4F4
		public static bool IsWhiteSpace(string s)
		{
			if (s == null)
			{
				throw StringUtils.smethod_1(<Module>.smethod_27<string>(1759848722U));
			}
			if (StringUtils.smethod_2(s) == 0)
			{
				return false;
			}
			for (int i = 0; i < StringUtils.smethod_2(s); i++)
			{
				if (!char.IsWhiteSpace(StringUtils.smethod_3(s, i)))
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x0600299D RID: 10653 RVA: 0x0001F955 File Offset: 0x0001DB55
		public static string NullEmptyString(string s)
		{
			if (!StringUtils.smethod_4(s))
			{
				return s;
			}
			return null;
		}

		// Token: 0x0600299E RID: 10654 RVA: 0x0009C340 File Offset: 0x0009A540
		public static StringWriter CreateStringWriter(int capacity)
		{
			StringBuilder stringBuilder = StringUtils.smethod_5(capacity);
			return StringUtils.smethod_7(stringBuilder, StringUtils.smethod_6());
		}

		// Token: 0x0600299F RID: 10655 RVA: 0x0009C364 File Offset: 0x0009A564
		public static int? GetLength(string value)
		{
			if (value == null)
			{
				return null;
			}
			return new int?(StringUtils.smethod_2(value));
		}

		// Token: 0x060029A0 RID: 10656 RVA: 0x0009C38C File Offset: 0x0009A58C
		public static void ToCharAsUnicode(char c, char[] buffer)
		{
			buffer[0] = '\\';
			buffer[1] = 'u';
			buffer[2] = MathUtils.IntToHex((int)((c >> 12) & '\u000f'));
			buffer[3] = MathUtils.IntToHex((int)((c >> 8) & '\u000f'));
			buffer[4] = MathUtils.IntToHex((int)((c >> 4) & '\u000f'));
			buffer[5] = MathUtils.IntToHex((int)(c & '\u000f'));
		}

		// Token: 0x060029A1 RID: 10657 RVA: 0x0009C3DC File Offset: 0x0009A5DC
		public static TSource ForgivingCaseSensitiveFind<TSource>(this IEnumerable<TSource> source, Func<TSource, string> valueSelector, string testValue)
		{
			if (source == null)
			{
				throw StringUtils.smethod_1(<Module>.smethod_26<string>(1736673023U));
			}
			if (valueSelector == null)
			{
				throw StringUtils.smethod_1(<Module>.smethod_23<string>(3269585236U));
			}
			IEnumerable<TSource> enumerable = source.Where((TSource s) => StringUtils.<>c__DisplayClass3<TSource>.smethod_0(valueSelector(s), testValue, StringComparison.OrdinalIgnoreCase));
			if (enumerable.Count<TSource>() <= 1)
			{
				return enumerable.SingleOrDefault<TSource>();
			}
			IEnumerable<TSource> enumerable2 = source.Where((TSource s) => StringUtils.<>c__DisplayClass3<TSource>.smethod_0(valueSelector(s), testValue, StringComparison.Ordinal));
			return enumerable2.SingleOrDefault<TSource>();
		}

		// Token: 0x060029A2 RID: 10658 RVA: 0x0009C470 File Offset: 0x0009A670
		public static string ToCamelCase(string s)
		{
			if (StringUtils.smethod_4(s))
			{
				return s;
			}
			if (!char.IsUpper(StringUtils.smethod_3(s, 0)))
			{
				return s;
			}
			char[] array = StringUtils.smethod_8(s);
			for (int i = 0; i < array.Length; i++)
			{
				bool flag = i + 1 < array.Length;
				if (i > 0 && flag && !char.IsUpper(array[i + 1]))
				{
					break;
				}
				array[i] = char.ToLower(array[i], StringUtils.smethod_6());
			}
			return StringUtils.smethod_9(array);
		}

		// Token: 0x060029A3 RID: 10659 RVA: 0x0001F962 File Offset: 0x0001DB62
		public static bool IsHighSurrogate(char c)
		{
			return char.IsHighSurrogate(c);
		}

		// Token: 0x060029A4 RID: 10660 RVA: 0x0001F96A File Offset: 0x0001DB6A
		public static bool IsLowSurrogate(char c)
		{
			return char.IsLowSurrogate(c);
		}

		// Token: 0x060029A5 RID: 10661 RVA: 0x0001F972 File Offset: 0x0001DB72
		public static bool StartsWith(this string source, char value)
		{
			return StringUtils.smethod_2(source) > 0 && StringUtils.smethod_3(source, 0) == value;
		}

		// Token: 0x060029A6 RID: 10662 RVA: 0x0001F989 File Offset: 0x0001DB89
		public static bool EndsWith(this string source, char value)
		{
			return StringUtils.smethod_2(source) > 0 && StringUtils.smethod_3(source, StringUtils.smethod_2(source) - 1) == value;
		}

		// Token: 0x060029A7 RID: 10663 RVA: 0x0000EAE8 File Offset: 0x0000CCE8
		static string smethod_0(IFormatProvider iformatProvider_0, string string_0, object[] object_0)
		{
			return string.Format(iformatProvider_0, string_0, object_0);
		}

		// Token: 0x060029A8 RID: 10664 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_1(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x060029A9 RID: 10665 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_2(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x060029AA RID: 10666 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_3(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x060029AB RID: 10667 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_4(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x060029AC RID: 10668 RVA: 0x0000FD8A File Offset: 0x0000DF8A
		static StringBuilder smethod_5(int int_0)
		{
			return new StringBuilder(int_0);
		}

		// Token: 0x060029AD RID: 10669 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_6()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060029AE RID: 10670 RVA: 0x0001B083 File Offset: 0x00019283
		static StringWriter smethod_7(StringBuilder stringBuilder_0, IFormatProvider iformatProvider_0)
		{
			return new StringWriter(stringBuilder_0, iformatProvider_0);
		}

		// Token: 0x060029AF RID: 10671 RVA: 0x00014704 File Offset: 0x00012904
		static char[] smethod_8(string string_0)
		{
			return string_0.ToCharArray();
		}

		// Token: 0x060029B0 RID: 10672 RVA: 0x0001F9A7 File Offset: 0x0001DBA7
		static string smethod_9(char[] char_0)
		{
			return new string(char_0);
		}

		// Token: 0x04000E68 RID: 3688
		public const string CarriageReturnLineFeed = "\r\n";

		// Token: 0x04000E69 RID: 3689
		public const string Empty = "";

		// Token: 0x04000E6A RID: 3690
		public const char CarriageReturn = '\r';

		// Token: 0x04000E6B RID: 3691
		public const char LineFeed = '\n';

		// Token: 0x04000E6C RID: 3692
		public const char Tab = '\t';
	}
}
