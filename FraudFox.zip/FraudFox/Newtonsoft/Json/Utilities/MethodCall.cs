﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002AF RID: 687
	// (Invoke) Token: 0x06002798 RID: 10136
	internal delegate TResult MethodCall<T, TResult>(T target, params object[] args);
}
