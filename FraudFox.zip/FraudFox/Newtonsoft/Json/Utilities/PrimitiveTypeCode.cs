﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002B9 RID: 697
	internal enum PrimitiveTypeCode
	{
		// Token: 0x04000DF4 RID: 3572
		Empty,
		// Token: 0x04000DF5 RID: 3573
		Object,
		// Token: 0x04000DF6 RID: 3574
		Char,
		// Token: 0x04000DF7 RID: 3575
		CharNullable,
		// Token: 0x04000DF8 RID: 3576
		Boolean,
		// Token: 0x04000DF9 RID: 3577
		BooleanNullable,
		// Token: 0x04000DFA RID: 3578
		SByte,
		// Token: 0x04000DFB RID: 3579
		SByteNullable,
		// Token: 0x04000DFC RID: 3580
		Int16,
		// Token: 0x04000DFD RID: 3581
		Int16Nullable,
		// Token: 0x04000DFE RID: 3582
		UInt16,
		// Token: 0x04000DFF RID: 3583
		UInt16Nullable,
		// Token: 0x04000E00 RID: 3584
		Int32,
		// Token: 0x04000E01 RID: 3585
		Int32Nullable,
		// Token: 0x04000E02 RID: 3586
		Byte,
		// Token: 0x04000E03 RID: 3587
		ByteNullable,
		// Token: 0x04000E04 RID: 3588
		UInt32,
		// Token: 0x04000E05 RID: 3589
		UInt32Nullable,
		// Token: 0x04000E06 RID: 3590
		Int64,
		// Token: 0x04000E07 RID: 3591
		Int64Nullable,
		// Token: 0x04000E08 RID: 3592
		UInt64,
		// Token: 0x04000E09 RID: 3593
		UInt64Nullable,
		// Token: 0x04000E0A RID: 3594
		Single,
		// Token: 0x04000E0B RID: 3595
		SingleNullable,
		// Token: 0x04000E0C RID: 3596
		Double,
		// Token: 0x04000E0D RID: 3597
		DoubleNullable,
		// Token: 0x04000E0E RID: 3598
		DateTime,
		// Token: 0x04000E0F RID: 3599
		DateTimeNullable,
		// Token: 0x04000E10 RID: 3600
		DateTimeOffset,
		// Token: 0x04000E11 RID: 3601
		DateTimeOffsetNullable,
		// Token: 0x04000E12 RID: 3602
		Decimal,
		// Token: 0x04000E13 RID: 3603
		DecimalNullable,
		// Token: 0x04000E14 RID: 3604
		Guid,
		// Token: 0x04000E15 RID: 3605
		GuidNullable,
		// Token: 0x04000E16 RID: 3606
		TimeSpan,
		// Token: 0x04000E17 RID: 3607
		TimeSpanNullable,
		// Token: 0x04000E18 RID: 3608
		BigInteger,
		// Token: 0x04000E19 RID: 3609
		BigIntegerNullable,
		// Token: 0x04000E1A RID: 3610
		Uri,
		// Token: 0x04000E1B RID: 3611
		String,
		// Token: 0x04000E1C RID: 3612
		Bytes,
		// Token: 0x04000E1D RID: 3613
		DBNull
	}
}
