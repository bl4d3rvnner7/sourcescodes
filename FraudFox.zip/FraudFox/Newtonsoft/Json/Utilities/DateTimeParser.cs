﻿using System;
using System.Runtime.CompilerServices;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020001E8 RID: 488
	internal struct DateTimeParser
	{
		// Token: 0x06001B4F RID: 6991 RVA: 0x0007B690 File Offset: 0x00079890
		static DateTimeParser()
		{
			int[] array = new int[7];
			DateTimeParser.smethod_0(array, fieldof(<PrivateImplementationDetails>{2050F94B-4B51-45A2-913D-663F8B3DB301}.$$method0x6000295-1).FieldHandle);
			DateTimeParser.Power10 = array;
			DateTimeParser.Lzyyyy = DateTimeParser.smethod_1(<Module>.smethod_24<string>(4187692275U));
			DateTimeParser.Lzyyyy_ = DateTimeParser.smethod_1(<Module>.smethod_26<string>(4058158104U));
			DateTimeParser.Lzyyyy_MM = DateTimeParser.smethod_1(<Module>.smethod_25<string>(3561071216U));
			DateTimeParser.Lzyyyy_MM_ = DateTimeParser.smethod_1(<Module>.smethod_26<string>(2629694470U));
			DateTimeParser.Lzyyyy_MM_dd = DateTimeParser.smethod_1(<Module>.smethod_26<string>(3213109453U));
			DateTimeParser.Lzyyyy_MM_ddT = DateTimeParser.smethod_1(<Module>.smethod_26<string>(486999019U));
			DateTimeParser.LzHH = DateTimeParser.smethod_1(<Module>.smethod_23<string>(1591219757U));
			DateTimeParser.LzHH_ = DateTimeParser.smethod_1(<Module>.smethod_26<string>(1934615441U));
			DateTimeParser.LzHH_mm = DateTimeParser.smethod_1(<Module>.smethod_27<string>(3830245017U));
			DateTimeParser.LzHH_mm_ = DateTimeParser.smethod_1(<Module>.smethod_27<string>(3410649780U));
			DateTimeParser.LzHH_mm_ss = DateTimeParser.smethod_1(<Module>.smethod_23<string>(2713282019U));
			DateTimeParser.Lz_ = DateTimeParser.smethod_1(<Module>.smethod_24<string>(1005470231U));
			DateTimeParser.Lz_zz = DateTimeParser.smethod_1(<Module>.smethod_23<string>(3274313150U));
		}

		// Token: 0x06001B50 RID: 6992 RVA: 0x000189CF File Offset: 0x00016BCF
		public bool Parse(string text)
		{
			this._text = text;
			this._length = DateTimeParser.smethod_1(text);
			return this.ParseDate(0) && this.ParseChar(DateTimeParser.Lzyyyy_MM_dd, 'T') && this.ParseTimeAndZoneAndWhitespace(DateTimeParser.Lzyyyy_MM_ddT);
		}

		// Token: 0x06001B51 RID: 6993 RVA: 0x0007B7B8 File Offset: 0x000799B8
		private bool ParseDate(int start)
		{
			return this.Parse4Digit(start, out this.Year) && 1 <= this.Year && this.ParseChar(start + DateTimeParser.Lzyyyy, '-') && this.Parse2Digit(start + DateTimeParser.Lzyyyy_, out this.Month) && 1 <= this.Month && this.Month <= 12 && this.ParseChar(start + DateTimeParser.Lzyyyy_MM, '-') && this.Parse2Digit(start + DateTimeParser.Lzyyyy_MM_, out this.Day) && 1 <= this.Day && this.Day <= DateTime.DaysInMonth(this.Year, this.Month);
		}

		// Token: 0x06001B52 RID: 6994 RVA: 0x00018A0C File Offset: 0x00016C0C
		private bool ParseTimeAndZoneAndWhitespace(int start)
		{
			return this.ParseTime(ref start) && this.ParseZone(start);
		}

		// Token: 0x06001B53 RID: 6995 RVA: 0x0007B86C File Offset: 0x00079A6C
		private bool ParseTime(ref int start)
		{
			if (this.Parse2Digit(start, out this.Hour) && this.Hour < 24 && this.ParseChar(start + DateTimeParser.LzHH, ':') && this.Parse2Digit(start + DateTimeParser.LzHH_, out this.Minute) && this.Minute < 60 && this.ParseChar(start + DateTimeParser.LzHH_mm, ':') && this.Parse2Digit(start + DateTimeParser.LzHH_mm_, out this.Second) && this.Second < 60)
			{
				start += DateTimeParser.LzHH_mm_ss;
				if (this.ParseChar(start, '.'))
				{
					this.Fraction = 0;
					int num = 0;
					while (++start < this._length && num < 7)
					{
						int num2 = (int)(DateTimeParser.smethod_2(this._text, start) - '0');
						if (num2 < 0 || num2 > 9)
						{
							break;
						}
						this.Fraction = this.Fraction * 10 + num2;
						num++;
					}
					if (num < 7)
					{
						if (num == 0)
						{
							return false;
						}
						this.Fraction *= DateTimeParser.Power10[7 - num];
					}
				}
				return true;
			}
			return false;
		}

		// Token: 0x06001B54 RID: 6996 RVA: 0x0007B998 File Offset: 0x00079B98
		private bool ParseZone(int start)
		{
			if (start < this._length)
			{
				char c = DateTimeParser.smethod_2(this._text, start);
				if (c != 'Z' && c != 'z')
				{
					if (start + 2 < this._length && this.Parse2Digit(start + DateTimeParser.Lz_, out this.ZoneHour) && this.ZoneHour <= 99)
					{
						switch (c)
						{
						case '+':
							this.Zone = ParserTimeZone.LocalEastOfUtc;
							start += DateTimeParser.Lz_zz;
							break;
						case '-':
							this.Zone = ParserTimeZone.LocalWestOfUtc;
							start += DateTimeParser.Lz_zz;
							break;
						}
					}
					if (start < this._length)
					{
						if (!this.ParseChar(start, ':'))
						{
							if (start + 1 < this._length && this.Parse2Digit(start, out this.ZoneMinute) && this.ZoneMinute <= 99)
							{
								start += 2;
							}
						}
						else
						{
							start++;
							if (start + 1 < this._length && this.Parse2Digit(start, out this.ZoneMinute) && this.ZoneMinute <= 99)
							{
								start += 2;
							}
						}
					}
				}
				else
				{
					this.Zone = ParserTimeZone.Utc;
					start++;
				}
			}
			return start == this._length;
		}

		// Token: 0x06001B55 RID: 6997 RVA: 0x0007BAB8 File Offset: 0x00079CB8
		private bool Parse4Digit(int start, out int num)
		{
			if (start + 3 < this._length)
			{
				int num2 = (int)(DateTimeParser.smethod_2(this._text, start) - '0');
				int num3 = (int)(DateTimeParser.smethod_2(this._text, start + 1) - '0');
				int num4 = (int)(DateTimeParser.smethod_2(this._text, start + 2) - '0');
				int num5 = (int)(DateTimeParser.smethod_2(this._text, start + 3) - '0');
				if (0 <= num2 && num2 < 10 && 0 <= num3 && num3 < 10 && 0 <= num4 && num4 < 10 && 0 <= num5 && num5 < 10)
				{
					num = ((num2 * 10 + num3) * 10 + num4) * 10 + num5;
					return true;
				}
			}
			num = 0;
			return false;
		}

		// Token: 0x06001B56 RID: 6998 RVA: 0x0007BB54 File Offset: 0x00079D54
		private bool Parse2Digit(int start, out int num)
		{
			if (start + 1 < this._length)
			{
				int num2 = (int)(DateTimeParser.smethod_2(this._text, start) - '0');
				int num3 = (int)(DateTimeParser.smethod_2(this._text, start + 1) - '0');
				if (0 <= num2 && num2 < 10 && 0 <= num3 && num3 < 10)
				{
					num = num2 * 10 + num3;
					return true;
				}
			}
			num = 0;
			return false;
		}

		// Token: 0x06001B57 RID: 6999 RVA: 0x00018A21 File Offset: 0x00016C21
		private bool ParseChar(int start, char ch)
		{
			return start < this._length && DateTimeParser.smethod_2(this._text, start) == ch;
		}

		// Token: 0x06001B58 RID: 7000 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_0(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x06001B59 RID: 7001 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_1(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06001B5A RID: 7002 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_2(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x04000A9F RID: 2719
		private const short MaxFractionDigits = 7;

		// Token: 0x04000AA0 RID: 2720
		public int Year;

		// Token: 0x04000AA1 RID: 2721
		public int Month;

		// Token: 0x04000AA2 RID: 2722
		public int Day;

		// Token: 0x04000AA3 RID: 2723
		public int Hour;

		// Token: 0x04000AA4 RID: 2724
		public int Minute;

		// Token: 0x04000AA5 RID: 2725
		public int Second;

		// Token: 0x04000AA6 RID: 2726
		public int Fraction;

		// Token: 0x04000AA7 RID: 2727
		public int ZoneHour;

		// Token: 0x04000AA8 RID: 2728
		public int ZoneMinute;

		// Token: 0x04000AA9 RID: 2729
		public ParserTimeZone Zone;

		// Token: 0x04000AAA RID: 2730
		private string _text;

		// Token: 0x04000AAB RID: 2731
		private int _length;

		// Token: 0x04000AAC RID: 2732
		private static readonly int[] Power10;

		// Token: 0x04000AAD RID: 2733
		private static readonly int Lzyyyy;

		// Token: 0x04000AAE RID: 2734
		private static readonly int Lzyyyy_;

		// Token: 0x04000AAF RID: 2735
		private static readonly int Lzyyyy_MM;

		// Token: 0x04000AB0 RID: 2736
		private static readonly int Lzyyyy_MM_;

		// Token: 0x04000AB1 RID: 2737
		private static readonly int Lzyyyy_MM_dd;

		// Token: 0x04000AB2 RID: 2738
		private static readonly int Lzyyyy_MM_ddT;

		// Token: 0x04000AB3 RID: 2739
		private static readonly int LzHH;

		// Token: 0x04000AB4 RID: 2740
		private static readonly int LzHH_;

		// Token: 0x04000AB5 RID: 2741
		private static readonly int LzHH_mm;

		// Token: 0x04000AB6 RID: 2742
		private static readonly int LzHH_mm_;

		// Token: 0x04000AB7 RID: 2743
		private static readonly int LzHH_mm_ss;

		// Token: 0x04000AB8 RID: 2744
		private static readonly int Lz_;

		// Token: 0x04000AB9 RID: 2745
		private static readonly int Lz_zz;
	}
}
