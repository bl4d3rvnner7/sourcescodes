﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002CB RID: 715
	internal static class CollectionUtils
	{
		// Token: 0x060028BE RID: 10430 RVA: 0x0001F5A8 File Offset: 0x0001D7A8
		public static bool IsNullOrEmpty<T>(ICollection<T> collection)
		{
			return collection == null || collection.Count == 0;
		}

		// Token: 0x060028BF RID: 10431 RVA: 0x0009A830 File Offset: 0x00098A30
		public static void AddRange<T>(this IList<T> initial, IEnumerable<T> collection)
		{
			if (initial == null)
			{
				throw CollectionUtils.smethod_0(<Module>.smethod_24<string>(434860176U));
			}
			if (collection == null)
			{
				return;
			}
			IEnumerator<T> enumerator = collection.GetEnumerator();
			try
			{
				while (CollectionUtils.smethod_1(enumerator))
				{
					T t = enumerator.Current;
					initial.Add(t);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					CollectionUtils.smethod_2(enumerator);
				}
			}
		}

		// Token: 0x060028C0 RID: 10432 RVA: 0x0001F5B8 File Offset: 0x0001D7B8
		public static bool IsDictionaryType(Type type)
		{
			ValidationUtils.ArgumentNotNull(type, <Module>.smethod_25<string>(965527090U));
			return CollectionUtils.smethod_4(CollectionUtils.smethod_3(typeof(IDictionary).TypeHandle), type) || ReflectionUtils.ImplementsGenericDefinition(type, CollectionUtils.smethod_3(typeof(IDictionary<, >).TypeHandle));
		}

		// Token: 0x060028C1 RID: 10433 RVA: 0x0009A890 File Offset: 0x00098A90
		public static ConstructorInfo ResolveEnumerableCollectionConstructor(Type collectionType, Type collectionItemType)
		{
			Type type = CollectionUtils.smethod_5(CollectionUtils.smethod_3(typeof(IEnumerable<>).TypeHandle), new Type[] { collectionItemType });
			ConstructorInfo constructorInfo = null;
			foreach (ConstructorInfo constructorInfo2 in CollectionUtils.smethod_6(collectionType, BindingFlags.Instance | BindingFlags.Public))
			{
				IList<ParameterInfo> list = CollectionUtils.smethod_7(constructorInfo2);
				if (list.Count == 1)
				{
					if (CollectionUtils.smethod_9(type, CollectionUtils.smethod_8(list[0])))
					{
						constructorInfo = constructorInfo2;
						return constructorInfo;
					}
					if (CollectionUtils.smethod_10(constructorInfo, null) && CollectionUtils.smethod_4(type, CollectionUtils.smethod_8(list[0])))
					{
						constructorInfo = constructorInfo2;
					}
				}
			}
			return constructorInfo;
		}

		// Token: 0x060028C2 RID: 10434 RVA: 0x0001F5F3 File Offset: 0x0001D7F3
		public static bool AddDistinct<T>(this IList<T> list, T value)
		{
			return list.AddDistinct(value, EqualityComparer<T>.Default);
		}

		// Token: 0x060028C3 RID: 10435 RVA: 0x0001F601 File Offset: 0x0001D801
		public static bool AddDistinct<T>(this IList<T> list, T value, IEqualityComparer<T> comparer)
		{
			if (list.ContainsValue(value, comparer))
			{
				return false;
			}
			list.Add(value);
			return true;
		}

		// Token: 0x060028C4 RID: 10436 RVA: 0x0009A938 File Offset: 0x00098B38
		public static bool ContainsValue<TSource>(this IEnumerable<TSource> source, TSource value, IEqualityComparer<TSource> comparer)
		{
			if (comparer == null)
			{
				comparer = EqualityComparer<TSource>.Default;
			}
			if (source == null)
			{
				throw CollectionUtils.smethod_0(<Module>.smethod_23<string>(2465512069U));
			}
			IEnumerator<TSource> enumerator = source.GetEnumerator();
			try
			{
				while (CollectionUtils.smethod_1(enumerator))
				{
					TSource tsource = enumerator.Current;
					if (comparer.Equals(tsource, value))
					{
						return true;
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					CollectionUtils.smethod_2(enumerator);
				}
			}
			return false;
		}

		// Token: 0x060028C5 RID: 10437 RVA: 0x0009A9AC File Offset: 0x00098BAC
		public static bool AddRangeDistinct<T>(this IList<T> list, IEnumerable<T> values, IEqualityComparer<T> comparer)
		{
			bool flag = true;
			IEnumerator<T> enumerator = values.GetEnumerator();
			try
			{
				while (CollectionUtils.smethod_1(enumerator))
				{
					T t = enumerator.Current;
					if (!list.AddDistinct(t, comparer))
					{
						flag = false;
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					CollectionUtils.smethod_2(enumerator);
				}
			}
			return flag;
		}

		// Token: 0x060028C6 RID: 10438 RVA: 0x0009AA00 File Offset: 0x00098C00
		public static int IndexOf<T>(this IEnumerable<T> collection, Func<T, bool> predicate)
		{
			int num = 0;
			IEnumerator<T> enumerator = collection.GetEnumerator();
			try
			{
				while (CollectionUtils.smethod_1(enumerator))
				{
					T t = enumerator.Current;
					if (predicate(t))
					{
						return num;
					}
					num++;
				}
				return -1;
			}
			finally
			{
				if (enumerator != null)
				{
					CollectionUtils.smethod_2(enumerator);
				}
			}
			int num2;
			return num2;
		}

		// Token: 0x060028C7 RID: 10439 RVA: 0x0009AA58 File Offset: 0x00098C58
		public static bool Contains(this IEnumerable list, object value, IEqualityComparer comparer)
		{
			IEnumerator enumerator = CollectionUtils.smethod_11(list);
			try
			{
				while (CollectionUtils.smethod_1(enumerator))
				{
					object obj = CollectionUtils.smethod_12(enumerator);
					if (CollectionUtils.smethod_13(comparer, obj, value))
					{
						return true;
					}
				}
			}
			finally
			{
				IDisposable disposable = enumerator as IDisposable;
				if (disposable != null)
				{
					CollectionUtils.smethod_2(disposable);
				}
			}
			return false;
		}

		// Token: 0x060028C8 RID: 10440 RVA: 0x0009AAB4 File Offset: 0x00098CB4
		public static int IndexOf<TSource>(this IEnumerable<TSource> list, TSource value, IEqualityComparer<TSource> comparer)
		{
			int num = 0;
			IEnumerator<TSource> enumerator = list.GetEnumerator();
			try
			{
				while (CollectionUtils.smethod_1(enumerator))
				{
					TSource tsource = enumerator.Current;
					if (comparer.Equals(tsource, value))
					{
						return num;
					}
					num++;
				}
			}
			finally
			{
				if (enumerator != null)
				{
					CollectionUtils.smethod_2(enumerator);
				}
			}
			return -1;
		}

		// Token: 0x060028C9 RID: 10441 RVA: 0x0009AB10 File Offset: 0x00098D10
		private static IList<int> GetDimensions(IList values, int dimensionsCount)
		{
			IList<int> list = new List<int>();
			IList list2 = values;
			for (;;)
			{
				list.Add(CollectionUtils.smethod_14(list2));
				if (list.Count == dimensionsCount || CollectionUtils.smethod_14(list2) == 0)
				{
					break;
				}
				object obj = CollectionUtils.smethod_15(list2, 0);
				if (!(obj is IList))
				{
					break;
				}
				list2 = (IList)obj;
			}
			return list;
		}

		// Token: 0x060028CA RID: 10442 RVA: 0x0009AB60 File Offset: 0x00098D60
		private static void CopyFromJaggedToMultidimensionalArray(IList values, Array multidimensionalArray, int[] indices)
		{
			int num = indices.Length;
			if (num == CollectionUtils.smethod_16(multidimensionalArray))
			{
				CollectionUtils.smethod_17(multidimensionalArray, CollectionUtils.JaggedArrayGetValue(values, indices), indices);
				return;
			}
			int num2 = CollectionUtils.smethod_18(multidimensionalArray, num);
			IList list = (IList)CollectionUtils.JaggedArrayGetValue(values, indices);
			int num3 = CollectionUtils.smethod_14(list);
			if (num3 == num2)
			{
				int[] array = new int[num + 1];
				for (int i = 0; i < num; i++)
				{
					array[i] = indices[i];
				}
				for (int j = 0; j < CollectionUtils.smethod_18(multidimensionalArray, num); j++)
				{
					array[num] = j;
					CollectionUtils.CopyFromJaggedToMultidimensionalArray(values, multidimensionalArray, array);
				}
				return;
			}
			throw CollectionUtils.smethod_19(<Module>.smethod_26<string>(2382198328U));
		}

		// Token: 0x060028CB RID: 10443 RVA: 0x0009AC04 File Offset: 0x00098E04
		private static object JaggedArrayGetValue(IList values, int[] indices)
		{
			IList list = values;
			int num3;
			for (;;)
			{
				IL_0077:
				int num = 2042803991;
				for (;;)
				{
					int num2;
					switch (num ^ 2042803988)
					{
					case 0:
						goto IL_0046;
					case 1:
						break;
					case 2:
						goto IL_0080;
					case 3:
						num2 = 0;
						num = 2042803985;
						continue;
					case 4:
						num2++;
						num = 2042803988;
						continue;
					case 5:
						num = 2042803988;
						continue;
					case 6:
						goto IL_0077;
					default:
						goto IL_0046;
					}
					IL_001F:
					num3 = indices[num2];
					if (num2 == indices.Length - 1)
					{
						num = 2042803990;
						continue;
					}
					list = (IList)CollectionUtils.smethod_15(list, num3);
					num = 2042803984;
					continue;
					IL_0046:
					if (num2 >= indices.Length)
					{
						return list;
					}
					goto IL_001F;
				}
			}
			return list;
			IL_0080:
			return CollectionUtils.smethod_15(list, num3);
		}

		// Token: 0x060028CC RID: 10444 RVA: 0x0009AC98 File Offset: 0x00098E98
		public static Array ToMultidimensionalArray(IList values, Type type, int rank)
		{
			IList<int> dimensions = CollectionUtils.GetDimensions(values, rank);
			while (dimensions.Count < rank)
			{
				dimensions.Add(0);
			}
			Array array = CollectionUtils.smethod_20(type, dimensions.ToArray<int>());
			CollectionUtils.CopyFromJaggedToMultidimensionalArray(values, array, new int[0]);
			return array;
		}

		// Token: 0x060028CD RID: 10445 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_0(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x060028CE RID: 10446 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_1(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060028CF RID: 10447 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_2(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060028D0 RID: 10448 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_3(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060028D1 RID: 10449 RVA: 0x00017625 File Offset: 0x00015825
		static bool smethod_4(Type type_0, Type type_1)
		{
			return type_0.IsAssignableFrom(type_1);
		}

		// Token: 0x060028D2 RID: 10450 RVA: 0x00016303 File Offset: 0x00014503
		static Type smethod_5(Type type_0, Type[] type_1)
		{
			return type_0.MakeGenericType(type_1);
		}

		// Token: 0x060028D3 RID: 10451 RVA: 0x0001CA4B File Offset: 0x0001AC4B
		static ConstructorInfo[] smethod_6(Type type_0, BindingFlags bindingFlags_0)
		{
			return type_0.GetConstructors(bindingFlags_0);
		}

		// Token: 0x060028D4 RID: 10452 RVA: 0x0001CA54 File Offset: 0x0001AC54
		static ParameterInfo[] smethod_7(MethodBase methodBase_0)
		{
			return methodBase_0.GetParameters();
		}

		// Token: 0x060028D5 RID: 10453 RVA: 0x0001CA64 File Offset: 0x0001AC64
		static Type smethod_8(ParameterInfo parameterInfo_0)
		{
			return parameterInfo_0.ParameterType;
		}

		// Token: 0x060028D6 RID: 10454 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_9(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x060028D7 RID: 10455 RVA: 0x0001CA7C File Offset: 0x0001AC7C
		static bool smethod_10(ConstructorInfo constructorInfo_0, ConstructorInfo constructorInfo_1)
		{
			return constructorInfo_0 == constructorInfo_1;
		}

		// Token: 0x060028D8 RID: 10456 RVA: 0x0000DAD6 File Offset: 0x0000BCD6
		static IEnumerator smethod_11(IEnumerable ienumerable_0)
		{
			return ienumerable_0.GetEnumerator();
		}

		// Token: 0x060028D9 RID: 10457 RVA: 0x0000D8E2 File Offset: 0x0000BAE2
		static object smethod_12(IEnumerator ienumerator_0)
		{
			return ienumerator_0.Current;
		}

		// Token: 0x060028DA RID: 10458 RVA: 0x0001F617 File Offset: 0x0001D817
		static bool smethod_13(IEqualityComparer iequalityComparer_0, object object_0, object object_1)
		{
			return iequalityComparer_0.Equals(object_0, object_1);
		}

		// Token: 0x060028DB RID: 10459 RVA: 0x0001DA17 File Offset: 0x0001BC17
		static int smethod_14(ICollection icollection_0)
		{
			return icollection_0.Count;
		}

		// Token: 0x060028DC RID: 10460 RVA: 0x0001F621 File Offset: 0x0001D821
		static object smethod_15(IList ilist_0, int int_0)
		{
			return ilist_0[int_0];
		}

		// Token: 0x060028DD RID: 10461 RVA: 0x0001DAF7 File Offset: 0x0001BCF7
		static int smethod_16(Array array_0)
		{
			return array_0.Rank;
		}

		// Token: 0x060028DE RID: 10462 RVA: 0x0001F62A File Offset: 0x0001D82A
		static void smethod_17(Array array_0, object object_0, int[] int_0)
		{
			array_0.SetValue(object_0, int_0);
		}

		// Token: 0x060028DF RID: 10463 RVA: 0x00010011 File Offset: 0x0000E211
		static int smethod_18(Array array_0, int int_0)
		{
			return array_0.GetLength(int_0);
		}

		// Token: 0x060028E0 RID: 10464 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_19(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x060028E1 RID: 10465 RVA: 0x0001F634 File Offset: 0x0001D834
		static Array smethod_20(Type type_0, int[] int_0)
		{
			return Array.CreateInstance(type_0, int_0);
		}
	}
}
