﻿using System;
using System.IO;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x02000283 RID: 643
	internal class Base64Encoder
	{
		// Token: 0x06002627 RID: 9767 RVA: 0x0001DFF4 File Offset: 0x0001C1F4
		public Base64Encoder(TextWriter writer)
		{
			ValidationUtils.ArgumentNotNull(writer, <Module>.smethod_24<string>(411494440U));
			this._writer = writer;
		}

		// Token: 0x06002628 RID: 9768 RVA: 0x000950E8 File Offset: 0x000932E8
		public void Encode(byte[] buffer, int index, int count)
		{
			if (buffer == null)
			{
				throw Base64Encoder.smethod_0(<Module>.smethod_25<string>(2270679300U));
			}
			if (index < 0)
			{
				throw Base64Encoder.smethod_1(<Module>.smethod_26<string>(2719043872U));
			}
			if (count < 0)
			{
				throw Base64Encoder.smethod_1(<Module>.smethod_23<string>(3285728771U));
			}
			if (count > buffer.Length - index)
			{
				throw Base64Encoder.smethod_1(<Module>.smethod_26<string>(3423790121U));
			}
			if (this._leftOverBytesCount > 0)
			{
				int leftOverBytesCount = this._leftOverBytesCount;
				while (leftOverBytesCount < 3 && count > 0)
				{
					this._leftOverBytes[leftOverBytesCount++] = buffer[index++];
					count--;
				}
				if (count == 0 && leftOverBytesCount < 3)
				{
					this._leftOverBytesCount = leftOverBytesCount;
					return;
				}
				int num = Base64Encoder.smethod_2(this._leftOverBytes, 0, 3, this._charsLine, 0);
				this.WriteChars(this._charsLine, 0, num);
			}
			this._leftOverBytesCount = count % 3;
			if (this._leftOverBytesCount > 0)
			{
				count -= this._leftOverBytesCount;
				if (this._leftOverBytes == null)
				{
					this._leftOverBytes = new byte[3];
				}
				for (int i = 0; i < this._leftOverBytesCount; i++)
				{
					this._leftOverBytes[i] = buffer[index + count + i];
				}
			}
			int num2 = index + count;
			int num3 = 57;
			while (index < num2)
			{
				if (index + num3 > num2)
				{
					num3 = num2 - index;
				}
				int num4 = Base64Encoder.smethod_2(buffer, index, num3, this._charsLine, 0);
				this.WriteChars(this._charsLine, 0, num4);
				index += num3;
			}
		}

		// Token: 0x06002629 RID: 9769 RVA: 0x00095244 File Offset: 0x00093444
		public void Flush()
		{
			if (this._leftOverBytesCount > 0)
			{
				int num = Base64Encoder.smethod_2(this._leftOverBytes, 0, this._leftOverBytesCount, this._charsLine, 0);
				this.WriteChars(this._charsLine, 0, num);
				this._leftOverBytesCount = 0;
			}
		}

		// Token: 0x0600262A RID: 9770 RVA: 0x0001E020 File Offset: 0x0001C220
		private void WriteChars(char[] chars, int index, int count)
		{
			Base64Encoder.smethod_3(this._writer, chars, index, count);
		}

		// Token: 0x0600262B RID: 9771 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_0(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x0600262C RID: 9772 RVA: 0x0000F870 File Offset: 0x0000DA70
		static ArgumentOutOfRangeException smethod_1(string string_0)
		{
			return new ArgumentOutOfRangeException(string_0);
		}

		// Token: 0x0600262D RID: 9773 RVA: 0x0001E030 File Offset: 0x0001C230
		static int smethod_2(byte[] byte_0, int int_0, int int_1, char[] char_0, int int_2)
		{
			return Convert.ToBase64CharArray(byte_0, int_0, int_1, char_0, int_2);
		}

		// Token: 0x0600262E RID: 9774 RVA: 0x0001AC5C File Offset: 0x00018E5C
		static void smethod_3(TextWriter textWriter_0, char[] char_0, int int_0, int int_1)
		{
			textWriter_0.Write(char_0, int_0, int_1);
		}

		// Token: 0x04000D73 RID: 3443
		private const int Base64LineSize = 76;

		// Token: 0x04000D74 RID: 3444
		private const int LineSizeInBytes = 57;

		// Token: 0x04000D75 RID: 3445
		private readonly char[] _charsLine = new char[76];

		// Token: 0x04000D76 RID: 3446
		private readonly TextWriter _writer;

		// Token: 0x04000D77 RID: 3447
		private byte[] _leftOverBytes;

		// Token: 0x04000D78 RID: 3448
		private int _leftOverBytesCount;
	}
}
