﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Text;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x020002CF RID: 719
	internal static class ReflectionUtils
	{
		// Token: 0x06002907 RID: 10503 RVA: 0x0009B198 File Offset: 0x00099398
		public static bool IsVirtual(this PropertyInfo propertyInfo)
		{
			ValidationUtils.ArgumentNotNull(propertyInfo, <Module>.smethod_24<string>(2881872323U));
			MethodInfo methodInfo = ReflectionUtils.smethod_0(propertyInfo);
			if (ReflectionUtils.smethod_1(methodInfo, null) && ReflectionUtils.smethod_2(methodInfo))
			{
				return true;
			}
			methodInfo = ReflectionUtils.smethod_3(propertyInfo);
			return ReflectionUtils.smethod_1(methodInfo, null) && ReflectionUtils.smethod_2(methodInfo);
		}

		// Token: 0x06002908 RID: 10504 RVA: 0x0009B1EC File Offset: 0x000993EC
		public static MethodInfo GetBaseDefinition(this PropertyInfo propertyInfo)
		{
			ValidationUtils.ArgumentNotNull(propertyInfo, <Module>.smethod_23<string>(3773967698U));
			MethodInfo methodInfo = ReflectionUtils.smethod_0(propertyInfo);
			if (ReflectionUtils.smethod_1(methodInfo, null))
			{
				return ReflectionUtils.smethod_4(methodInfo);
			}
			methodInfo = ReflectionUtils.smethod_3(propertyInfo);
			if (ReflectionUtils.smethod_1(methodInfo, null))
			{
				return ReflectionUtils.smethod_4(methodInfo);
			}
			return null;
		}

		// Token: 0x06002909 RID: 10505 RVA: 0x0001F697 File Offset: 0x0001D897
		public static bool IsPublic(PropertyInfo property)
		{
			return (ReflectionUtils.smethod_1(ReflectionUtils.smethod_0(property), null) && ReflectionUtils.smethod_5(ReflectionUtils.smethod_0(property))) || (ReflectionUtils.smethod_1(ReflectionUtils.smethod_3(property), null) && ReflectionUtils.smethod_5(ReflectionUtils.smethod_3(property)));
		}

		// Token: 0x0600290A RID: 10506 RVA: 0x0001F6D4 File Offset: 0x0001D8D4
		public static Type GetObjectType(object v)
		{
			if (v == null)
			{
				return null;
			}
			return ReflectionUtils.smethod_6(v);
		}

		// Token: 0x0600290B RID: 10507 RVA: 0x0009B238 File Offset: 0x00099438
		public static string GetTypeName(Type t, FormatterAssemblyStyle assemblyFormat, SerializationBinder binder)
		{
			string text3;
			if (binder != null)
			{
				string text;
				string text2;
				ReflectionUtils.smethod_7(binder, t, ref text, ref text2);
				text3 = ReflectionUtils.smethod_8(text2, (text == null) ? "" : ReflectionUtils.smethod_8(<Module>.smethod_24<string>(415060776U), text));
			}
			else
			{
				text3 = ReflectionUtils.smethod_9(t);
			}
			switch (assemblyFormat)
			{
			case FormatterAssemblyStyle.Simple:
				return ReflectionUtils.RemoveAssemblyDetails(text3);
			case FormatterAssemblyStyle.Full:
				return text3;
			default:
				throw ReflectionUtils.smethod_10();
			}
		}

		// Token: 0x0600290C RID: 10508 RVA: 0x0009B29C File Offset: 0x0009949C
		private static string RemoveAssemblyDetails(string fullyQualifiedTypeName)
		{
			StringBuilder stringBuilder = ReflectionUtils.smethod_11();
			bool flag = false;
			bool flag2 = false;
			for (int i = 0; i < ReflectionUtils.smethod_14(fullyQualifiedTypeName); i++)
			{
				char c = ReflectionUtils.smethod_12(fullyQualifiedTypeName, i);
				char c2 = c;
				if (c2 != ',')
				{
					switch (c2)
					{
					case '[':
						flag = false;
						flag2 = false;
						ReflectionUtils.smethod_13(stringBuilder, c);
						goto IL_0077;
					case ']':
						flag = false;
						flag2 = false;
						ReflectionUtils.smethod_13(stringBuilder, c);
						goto IL_0077;
					}
					if (!flag2)
					{
						ReflectionUtils.smethod_13(stringBuilder, c);
					}
				}
				else if (!flag)
				{
					flag = true;
					ReflectionUtils.smethod_13(stringBuilder, c);
				}
				else
				{
					flag2 = true;
				}
				IL_0077:;
			}
			return ReflectionUtils.smethod_15(stringBuilder);
		}

		// Token: 0x0600290D RID: 10509 RVA: 0x0001F6E1 File Offset: 0x0001D8E1
		public static bool HasDefaultConstructor(Type t, bool nonPublic)
		{
			ValidationUtils.ArgumentNotNull(t, <Module>.smethod_24<string>(2212198272U));
			return t.IsValueType() || ReflectionUtils.smethod_16(ReflectionUtils.GetDefaultConstructor(t, nonPublic), null);
		}

		// Token: 0x0600290E RID: 10510 RVA: 0x0001F70A File Offset: 0x0001D90A
		public static ConstructorInfo GetDefaultConstructor(Type t)
		{
			return ReflectionUtils.GetDefaultConstructor(t, false);
		}

		// Token: 0x0600290F RID: 10511 RVA: 0x0009B334 File Offset: 0x00099534
		public static ConstructorInfo GetDefaultConstructor(Type t, bool nonPublic)
		{
			BindingFlags bindingFlags = BindingFlags.Instance | BindingFlags.Public;
			if (nonPublic)
			{
				bindingFlags |= BindingFlags.NonPublic;
			}
			return ReflectionUtils.smethod_17(t, bindingFlags).SingleOrDefault((ConstructorInfo c) => !ReflectionUtils.smethod_76(c).Any<ParameterInfo>());
		}

		// Token: 0x06002910 RID: 10512 RVA: 0x0001F713 File Offset: 0x0001D913
		public static bool IsNullable(Type t)
		{
			ValidationUtils.ArgumentNotNull(t, <Module>.smethod_24<string>(2212198272U));
			return !t.IsValueType() || ReflectionUtils.IsNullableType(t);
		}

		// Token: 0x06002911 RID: 10513 RVA: 0x0001F735 File Offset: 0x0001D935
		public static bool IsNullableType(Type t)
		{
			ValidationUtils.ArgumentNotNull(t, <Module>.smethod_24<string>(2212198272U));
			return t.IsGenericType() && ReflectionUtils.smethod_20(ReflectionUtils.smethod_18(t), ReflectionUtils.smethod_19(typeof(Nullable<>).TypeHandle));
		}

		// Token: 0x06002912 RID: 10514 RVA: 0x0001F766 File Offset: 0x0001D966
		public static Type EnsureNotNullableType(Type t)
		{
			if (!ReflectionUtils.IsNullableType(t))
			{
				return t;
			}
			return ReflectionUtils.smethod_21(t);
		}

		// Token: 0x06002913 RID: 10515 RVA: 0x0009B378 File Offset: 0x00099578
		public static bool IsGenericDefinition(Type type, Type genericInterfaceDefinition)
		{
			if (!type.IsGenericType())
			{
				return false;
			}
			Type type2 = ReflectionUtils.smethod_18(type);
			return ReflectionUtils.smethod_20(type2, genericInterfaceDefinition);
		}

		// Token: 0x06002914 RID: 10516 RVA: 0x0009B3A0 File Offset: 0x000995A0
		public static bool ImplementsGenericDefinition(Type type, Type genericInterfaceDefinition)
		{
			Type type2;
			return ReflectionUtils.ImplementsGenericDefinition(type, genericInterfaceDefinition, out type2);
		}

		// Token: 0x06002915 RID: 10517 RVA: 0x0009B3B8 File Offset: 0x000995B8
		public static bool ImplementsGenericDefinition(Type type, Type genericInterfaceDefinition, out Type implementingType)
		{
			ValidationUtils.ArgumentNotNull(type, <Module>.smethod_25<string>(965527090U));
			ValidationUtils.ArgumentNotNull(genericInterfaceDefinition, <Module>.smethod_27<string>(3474515784U));
			if (genericInterfaceDefinition.IsInterface() && genericInterfaceDefinition.IsGenericTypeDefinition())
			{
				if (type.IsInterface() && type.IsGenericType())
				{
					Type type2 = ReflectionUtils.smethod_18(type);
					if (ReflectionUtils.smethod_20(genericInterfaceDefinition, type2))
					{
						implementingType = type;
						return true;
					}
				}
				foreach (Type type3 in ReflectionUtils.smethod_24(type))
				{
					if (type3.IsGenericType())
					{
						Type type4 = ReflectionUtils.smethod_18(type3);
						if (ReflectionUtils.smethod_20(genericInterfaceDefinition, type4))
						{
							implementingType = type3;
							return true;
						}
					}
				}
				implementingType = null;
				return false;
			}
			throw ReflectionUtils.smethod_23(<Module>.smethod_24<string>(3157766789U).FormatWith(ReflectionUtils.smethod_22(), genericInterfaceDefinition));
		}

		// Token: 0x06002916 RID: 10518 RVA: 0x0009B480 File Offset: 0x00099680
		public static bool InheritsGenericDefinition(Type type, Type genericClassDefinition)
		{
			Type type2;
			return ReflectionUtils.InheritsGenericDefinition(type, genericClassDefinition, out type2);
		}

		// Token: 0x06002917 RID: 10519 RVA: 0x0009B498 File Offset: 0x00099698
		public static bool InheritsGenericDefinition(Type type, Type genericClassDefinition, out Type implementingType)
		{
			ValidationUtils.ArgumentNotNull(type, <Module>.smethod_25<string>(965527090U));
			ValidationUtils.ArgumentNotNull(genericClassDefinition, <Module>.smethod_26<string>(1020769452U));
			if (!genericClassDefinition.IsClass() || !genericClassDefinition.IsGenericTypeDefinition())
			{
				throw ReflectionUtils.smethod_23(<Module>.smethod_27<string>(1749513143U).FormatWith(ReflectionUtils.smethod_22(), genericClassDefinition));
			}
			return ReflectionUtils.InheritsGenericDefinitionInternal(type, genericClassDefinition, out implementingType);
		}

		// Token: 0x06002918 RID: 10520 RVA: 0x0009B4F8 File Offset: 0x000996F8
		private static bool InheritsGenericDefinitionInternal(Type currentType, Type genericClassDefinition, out Type implementingType)
		{
			if (currentType.IsGenericType())
			{
				Type type = ReflectionUtils.smethod_18(currentType);
				if (ReflectionUtils.smethod_20(genericClassDefinition, type))
				{
					implementingType = currentType;
					return true;
				}
			}
			if (ReflectionUtils.smethod_20(currentType.BaseType(), null))
			{
				implementingType = null;
				return false;
			}
			return ReflectionUtils.InheritsGenericDefinitionInternal(currentType.BaseType(), genericClassDefinition, out implementingType);
		}

		// Token: 0x06002919 RID: 10521 RVA: 0x0009B544 File Offset: 0x00099744
		public static Type GetCollectionItemType(Type type)
		{
			ValidationUtils.ArgumentNotNull(type, <Module>.smethod_27<string>(4029693297U));
			if (ReflectionUtils.smethod_25(type))
			{
				return ReflectionUtils.smethod_26(type);
			}
			Type type2;
			if (!ReflectionUtils.ImplementsGenericDefinition(type, ReflectionUtils.smethod_19(typeof(IEnumerable<>).TypeHandle), out type2))
			{
				if (ReflectionUtils.smethod_29(ReflectionUtils.smethod_19(typeof(IEnumerable).TypeHandle), type))
				{
					return null;
				}
				throw ReflectionUtils.smethod_27(<Module>.smethod_24<string>(2555668883U).FormatWith(ReflectionUtils.smethod_22(), type));
			}
			else
			{
				if (type2.IsGenericTypeDefinition())
				{
					throw ReflectionUtils.smethod_27(<Module>.smethod_26<string>(3293536686U).FormatWith(ReflectionUtils.smethod_22(), type));
				}
				return ReflectionUtils.smethod_28(type2)[0];
			}
		}

		// Token: 0x0600291A RID: 10522 RVA: 0x0009B5E4 File Offset: 0x000997E4
		public static void GetDictionaryKeyValueTypes(Type dictionaryType, out Type keyType, out Type valueType)
		{
			ValidationUtils.ArgumentNotNull(dictionaryType, <Module>.smethod_26<string>(1001144091U));
			Type type;
			if (ReflectionUtils.ImplementsGenericDefinition(dictionaryType, ReflectionUtils.smethod_19(typeof(IDictionary<, >).TypeHandle), out type))
			{
				if (!type.IsGenericTypeDefinition())
				{
					Type[] array = ReflectionUtils.smethod_28(type);
					keyType = array[0];
					valueType = array[1];
					return;
				}
				throw ReflectionUtils.smethod_27(<Module>.smethod_26<string>(2598457657U).FormatWith(ReflectionUtils.smethod_22(), dictionaryType));
			}
			else
			{
				if (!ReflectionUtils.smethod_29(ReflectionUtils.smethod_19(typeof(IDictionary).TypeHandle), dictionaryType))
				{
					throw ReflectionUtils.smethod_27(<Module>.smethod_23<string>(2746182355U).FormatWith(ReflectionUtils.smethod_22(), dictionaryType));
				}
				keyType = null;
				valueType = null;
				return;
			}
		}

		// Token: 0x0600291B RID: 10523 RVA: 0x0009B688 File Offset: 0x00099888
		public static Type GetMemberUnderlyingType(MemberInfo member)
		{
			ValidationUtils.ArgumentNotNull(member, <Module>.smethod_25<string>(889722807U));
			MemberTypes memberTypes = member.MemberType();
			switch (memberTypes)
			{
			case MemberTypes.Event:
				return ReflectionUtils.smethod_32((EventInfo)member);
			case MemberTypes.Constructor | MemberTypes.Event:
				break;
			case MemberTypes.Field:
				return ReflectionUtils.smethod_30((FieldInfo)member);
			default:
				if (memberTypes == MemberTypes.Method)
				{
					return ReflectionUtils.smethod_33((MethodInfo)member);
				}
				if (memberTypes == MemberTypes.Property)
				{
					return ReflectionUtils.smethod_31((PropertyInfo)member);
				}
				break;
			}
			throw ReflectionUtils.smethod_34(<Module>.smethod_25<string>(1794489696U), <Module>.smethod_24<string>(2785838069U));
		}

		// Token: 0x0600291C RID: 10524 RVA: 0x0009B714 File Offset: 0x00099914
		public static bool IsIndexedProperty(MemberInfo member)
		{
			ValidationUtils.ArgumentNotNull(member, <Module>.smethod_24<string>(2785838069U));
			PropertyInfo propertyInfo = member as PropertyInfo;
			return ReflectionUtils.smethod_35(propertyInfo, null) && ReflectionUtils.IsIndexedProperty(propertyInfo);
		}

		// Token: 0x0600291D RID: 10525 RVA: 0x0001F778 File Offset: 0x0001D978
		public static bool IsIndexedProperty(PropertyInfo property)
		{
			ValidationUtils.ArgumentNotNull(property, <Module>.smethod_24<string>(1615695835U));
			return ReflectionUtils.smethod_36(property).Length > 0;
		}

		// Token: 0x0600291E RID: 10526 RVA: 0x0009B74C File Offset: 0x0009994C
		public static object GetMemberValue(MemberInfo member, object target)
		{
			ValidationUtils.ArgumentNotNull(member, <Module>.smethod_25<string>(889722807U));
			ValidationUtils.ArgumentNotNull(target, <Module>.smethod_23<string>(1711199186U));
			MemberTypes memberTypes = member.MemberType();
			if (memberTypes == MemberTypes.Field)
			{
				return ReflectionUtils.smethod_37((FieldInfo)member, target);
			}
			if (memberTypes != MemberTypes.Property)
			{
				throw ReflectionUtils.smethod_34(<Module>.smethod_27<string>(951172822U).FormatWith(ReflectionUtils.smethod_22(), ReflectionUtils.smethod_22(), ReflectionUtils.smethod_39(member)), <Module>.smethod_27<string>(2536310384U));
			}
			object obj;
			try
			{
				obj = ReflectionUtils.smethod_38((PropertyInfo)member, target, null);
			}
			catch (TargetParameterCountException ex)
			{
				throw ReflectionUtils.smethod_40(<Module>.smethod_27<string>(1370768059U).FormatWith(ReflectionUtils.smethod_22(), ReflectionUtils.smethod_39(member)), ex);
			}
			return obj;
		}

		// Token: 0x0600291F RID: 10527 RVA: 0x0009B808 File Offset: 0x00099A08
		public static void SetMemberValue(MemberInfo member, object target, object value)
		{
			ValidationUtils.ArgumentNotNull(member, <Module>.smethod_24<string>(2785838069U));
			ValidationUtils.ArgumentNotNull(target, <Module>.smethod_25<string>(4063013681U));
			MemberTypes memberTypes = member.MemberType();
			if (memberTypes == MemberTypes.Field)
			{
				ReflectionUtils.smethod_41((FieldInfo)member, target, value);
				return;
			}
			if (memberTypes == MemberTypes.Property)
			{
				ReflectionUtils.smethod_42((PropertyInfo)member, target, value, null);
				return;
			}
			throw ReflectionUtils.smethod_34(<Module>.smethod_27<string>(1877835142U).FormatWith(ReflectionUtils.smethod_22(), ReflectionUtils.smethod_39(member)), <Module>.smethod_25<string>(889722807U));
		}

		// Token: 0x06002920 RID: 10528 RVA: 0x0009B88C File Offset: 0x00099A8C
		public static bool CanReadMemberValue(MemberInfo member, bool nonPublic)
		{
			MemberTypes memberTypes = member.MemberType();
			if (memberTypes == MemberTypes.Field)
			{
				FieldInfo fieldInfo = (FieldInfo)member;
				return nonPublic || ReflectionUtils.smethod_43(fieldInfo);
			}
			if (memberTypes != MemberTypes.Property)
			{
				return false;
			}
			PropertyInfo propertyInfo = (PropertyInfo)member;
			return ReflectionUtils.smethod_44(propertyInfo) && (nonPublic || ReflectionUtils.smethod_1(ReflectionUtils.smethod_45(propertyInfo, nonPublic), null));
		}

		// Token: 0x06002921 RID: 10529 RVA: 0x0009B8E8 File Offset: 0x00099AE8
		public static bool CanSetMemberValue(MemberInfo member, bool nonPublic, bool canSetReadOnly)
		{
			MemberTypes memberTypes = member.MemberType();
			if (memberTypes == MemberTypes.Field)
			{
				FieldInfo fieldInfo = (FieldInfo)member;
				return !ReflectionUtils.smethod_46(fieldInfo) && (!ReflectionUtils.smethod_47(fieldInfo) || canSetReadOnly) && (nonPublic || ReflectionUtils.smethod_43(fieldInfo));
			}
			if (memberTypes != MemberTypes.Property)
			{
				return false;
			}
			PropertyInfo propertyInfo = (PropertyInfo)member;
			return ReflectionUtils.smethod_48(propertyInfo) && (nonPublic || ReflectionUtils.smethod_1(ReflectionUtils.smethod_49(propertyInfo, nonPublic), null));
		}

		// Token: 0x06002922 RID: 10530 RVA: 0x0009B95C File Offset: 0x00099B5C
		public static List<MemberInfo> GetFieldsAndProperties(Type type, BindingFlags bindingAttr)
		{
			List<MemberInfo> list = new List<MemberInfo>();
			list.AddRange(ReflectionUtils.GetFields(type, bindingAttr));
			list.AddRange(ReflectionUtils.GetProperties(type, bindingAttr));
			List<MemberInfo> list2 = new List<MemberInfo>(list.Count);
			IEnumerator<IGrouping<string, MemberInfo>> enumerator = (from m in list
				group m by ReflectionUtils.smethod_39(m)).GetEnumerator();
			try
			{
				while (ReflectionUtils.smethod_51(enumerator))
				{
					IGrouping<string, MemberInfo> grouping = enumerator.Current;
					int num = grouping.Count<MemberInfo>();
					IList<MemberInfo> list3 = grouping.ToList<MemberInfo>();
					if (num == 1)
					{
						list2.Add(list3.First<MemberInfo>());
					}
					else
					{
						IList<MemberInfo> list4 = new List<MemberInfo>();
						IEnumerator<MemberInfo> enumerator2 = list3.GetEnumerator();
						try
						{
							while (ReflectionUtils.smethod_51(enumerator2))
							{
								MemberInfo memberInfo = enumerator2.Current;
								if (list4.Count == 0)
								{
									list4.Add(memberInfo);
								}
								else if (!ReflectionUtils.IsOverridenGenericMember(memberInfo, bindingAttr) || ReflectionUtils.smethod_50(ReflectionUtils.smethod_39(memberInfo), <Module>.smethod_25<string>(591258205U)))
								{
									list4.Add(memberInfo);
								}
							}
						}
						finally
						{
							if (enumerator2 != null)
							{
								ReflectionUtils.smethod_52(enumerator2);
							}
						}
						list2.AddRange(list4);
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					ReflectionUtils.smethod_52(enumerator);
				}
			}
			return list2;
		}

		// Token: 0x06002923 RID: 10531 RVA: 0x0009BAA0 File Offset: 0x00099CA0
		private static bool IsOverridenGenericMember(MemberInfo memberInfo, BindingFlags bindingAttr)
		{
			if (memberInfo.MemberType() != MemberTypes.Property)
			{
				return false;
			}
			PropertyInfo propertyInfo = (PropertyInfo)memberInfo;
			if (!propertyInfo.IsVirtual())
			{
				return false;
			}
			Type type = ReflectionUtils.smethod_53(propertyInfo);
			if (!type.IsGenericType())
			{
				return false;
			}
			Type type2 = ReflectionUtils.smethod_18(type);
			if (ReflectionUtils.smethod_20(type2, null))
			{
				return false;
			}
			MemberInfo[] array = ReflectionUtils.smethod_54(type2, ReflectionUtils.smethod_39(propertyInfo), bindingAttr);
			if (array.Length != 0)
			{
				Type memberUnderlyingType = ReflectionUtils.GetMemberUnderlyingType(array[0]);
				return ReflectionUtils.smethod_55(memberUnderlyingType);
			}
			return false;
		}

		// Token: 0x06002924 RID: 10532 RVA: 0x0001F795 File Offset: 0x0001D995
		public static T GetAttribute<T>(object attributeProvider) where T : Attribute
		{
			return ReflectionUtils.GetAttribute<T>(attributeProvider, true);
		}

		// Token: 0x06002925 RID: 10533 RVA: 0x0009BB1C File Offset: 0x00099D1C
		public static T GetAttribute<T>(object attributeProvider, bool inherit) where T : Attribute
		{
			T[] attributes = ReflectionUtils.GetAttributes<T>(attributeProvider, inherit);
			if (attributes == null)
			{
				return default(T);
			}
			return attributes.FirstOrDefault<T>();
		}

		// Token: 0x06002926 RID: 10534 RVA: 0x0009BB44 File Offset: 0x00099D44
		public static T[] GetAttributes<T>(object attributeProvider, bool inherit) where T : Attribute
		{
			Attribute[] attributes = ReflectionUtils.GetAttributes(attributeProvider, ReflectionUtils.smethod_19(typeof(T).TypeHandle), inherit);
			T[] array = attributes as T[];
			if (array != null)
			{
				return array;
			}
			return attributes.Cast<T>().ToArray<T>();
		}

		// Token: 0x06002927 RID: 10535 RVA: 0x0009BB7C File Offset: 0x00099D7C
		public static Attribute[] GetAttributes(object attributeProvider, Type attributeType, bool inherit)
		{
			ValidationUtils.ArgumentNotNull(attributeProvider, <Module>.smethod_23<string>(681253372U));
			if (attributeProvider is Type)
			{
				Type type = (Type)attributeProvider;
				object[] array = (ReflectionUtils.smethod_56(attributeType, null) ? ReflectionUtils.smethod_58(type, attributeType, inherit) : ReflectionUtils.smethod_57(type, inherit));
				return array.Cast<Attribute>().ToArray<Attribute>();
			}
			if (attributeProvider is Assembly)
			{
				Assembly assembly = (Assembly)attributeProvider;
				if (!ReflectionUtils.smethod_56(attributeType, null))
				{
					return ReflectionUtils.smethod_59(assembly);
				}
				return ReflectionUtils.smethod_60(assembly, attributeType);
			}
			else if (attributeProvider is MemberInfo)
			{
				MemberInfo memberInfo = (MemberInfo)attributeProvider;
				if (!ReflectionUtils.smethod_56(attributeType, null))
				{
					return ReflectionUtils.smethod_61(memberInfo, inherit);
				}
				return ReflectionUtils.smethod_62(memberInfo, attributeType, inherit);
			}
			else if (attributeProvider is Module)
			{
				Module module = (Module)attributeProvider;
				if (!ReflectionUtils.smethod_56(attributeType, null))
				{
					return ReflectionUtils.smethod_63(module, inherit);
				}
				return ReflectionUtils.smethod_64(module, attributeType, inherit);
			}
			else
			{
				if (!(attributeProvider is ParameterInfo))
				{
					ICustomAttributeProvider customAttributeProvider = (ICustomAttributeProvider)attributeProvider;
					object[] array2 = (ReflectionUtils.smethod_56(attributeType, null) ? ReflectionUtils.smethod_68(customAttributeProvider, attributeType, inherit) : ReflectionUtils.smethod_67(customAttributeProvider, inherit));
					return (Attribute[])array2;
				}
				ParameterInfo parameterInfo = (ParameterInfo)attributeProvider;
				if (!ReflectionUtils.smethod_56(attributeType, null))
				{
					return ReflectionUtils.smethod_65(parameterInfo, inherit);
				}
				return ReflectionUtils.smethod_66(parameterInfo, attributeType, inherit);
			}
		}

		// Token: 0x06002928 RID: 10536 RVA: 0x0009BCB0 File Offset: 0x00099EB0
		public static void SplitFullyQualifiedTypeName(string fullyQualifiedTypeName, out string typeName, out string assemblyName)
		{
			int? assemblyDelimiterIndex = ReflectionUtils.GetAssemblyDelimiterIndex(fullyQualifiedTypeName);
			if (assemblyDelimiterIndex != null)
			{
				typeName = ReflectionUtils.smethod_70(ReflectionUtils.smethod_69(fullyQualifiedTypeName, 0, assemblyDelimiterIndex.Value));
				assemblyName = ReflectionUtils.smethod_70(ReflectionUtils.smethod_69(fullyQualifiedTypeName, assemblyDelimiterIndex.Value + 1, ReflectionUtils.smethod_14(fullyQualifiedTypeName) - assemblyDelimiterIndex.Value - 1));
				return;
			}
			typeName = fullyQualifiedTypeName;
			assemblyName = null;
		}

		// Token: 0x06002929 RID: 10537 RVA: 0x0009BD10 File Offset: 0x00099F10
		private static int? GetAssemblyDelimiterIndex(string fullyQualifiedTypeName)
		{
			int num = 0;
			for (int i = 0; i < ReflectionUtils.smethod_14(fullyQualifiedTypeName); i++)
			{
				char c = ReflectionUtils.smethod_12(fullyQualifiedTypeName, i);
				char c2 = c;
				if (c2 != ',')
				{
					switch (c2)
					{
					case '[':
						num++;
						break;
					case ']':
						num--;
						break;
					}
				}
				else if (num == 0)
				{
					return new int?(i);
				}
			}
			return null;
		}

		// Token: 0x0600292A RID: 10538 RVA: 0x0009BD78 File Offset: 0x00099F78
		public static MemberInfo GetMemberInfoFromType(Type targetType, MemberInfo memberInfo)
		{
			MemberTypes memberTypes = memberInfo.MemberType();
			if (memberTypes == MemberTypes.Property)
			{
				PropertyInfo propertyInfo = (PropertyInfo)memberInfo;
				Type[] array = (from p in ReflectionUtils.smethod_36(propertyInfo)
					select ReflectionUtils.smethod_77(p)).ToArray<Type>();
				return ReflectionUtils.smethod_71(targetType, ReflectionUtils.smethod_39(propertyInfo), BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic, null, ReflectionUtils.smethod_31(propertyInfo), array, null);
			}
			return ReflectionUtils.smethod_72(targetType, ReflectionUtils.smethod_39(memberInfo), memberInfo.MemberType(), BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic).SingleOrDefault<MemberInfo>();
		}

		// Token: 0x0600292B RID: 10539 RVA: 0x0009BDF8 File Offset: 0x00099FF8
		public static IEnumerable<FieldInfo> GetFields(Type targetType, BindingFlags bindingAttr)
		{
			ValidationUtils.ArgumentNotNull(targetType, <Module>.smethod_23<string>(1341701924U));
			List<MemberInfo> list = new List<MemberInfo>(ReflectionUtils.smethod_73(targetType, bindingAttr));
			ReflectionUtils.GetChildPrivateFields(list, targetType, bindingAttr);
			return list.Cast<FieldInfo>();
		}

		// Token: 0x0600292C RID: 10540 RVA: 0x0009BE30 File Offset: 0x0009A030
		private static void GetChildPrivateFields(IList<MemberInfo> initialFields, Type targetType, BindingFlags bindingAttr)
		{
			if ((bindingAttr & BindingFlags.NonPublic) != BindingFlags.Default)
			{
				BindingFlags bindingFlags = bindingAttr.RemoveFlag(BindingFlags.Public);
				while (ReflectionUtils.smethod_56(targetType = targetType.BaseType(), null))
				{
					IEnumerable<MemberInfo> enumerable = (from f in ReflectionUtils.smethod_73(targetType, bindingFlags)
						where ReflectionUtils.smethod_78(f)
						select f).Cast<MemberInfo>();
					initialFields.AddRange(enumerable);
				}
			}
		}

		// Token: 0x0600292D RID: 10541 RVA: 0x0009BE98 File Offset: 0x0009A098
		public static IEnumerable<PropertyInfo> GetProperties(Type targetType, BindingFlags bindingAttr)
		{
			ValidationUtils.ArgumentNotNull(targetType, <Module>.smethod_26<string>(136579348U));
			List<PropertyInfo> list = new List<PropertyInfo>(ReflectionUtils.smethod_74(targetType, bindingAttr));
			if (targetType.IsInterface())
			{
				foreach (Type type in ReflectionUtils.smethod_24(targetType))
				{
					list.AddRange(ReflectionUtils.smethod_74(type, bindingAttr));
				}
			}
			ReflectionUtils.GetChildPrivateProperties(list, targetType, bindingAttr);
			for (int j = 0; j < list.Count; j++)
			{
				PropertyInfo propertyInfo = list[j];
				if (ReflectionUtils.smethod_56(ReflectionUtils.smethod_53(propertyInfo), targetType))
				{
					PropertyInfo propertyInfo2 = (PropertyInfo)ReflectionUtils.GetMemberInfoFromType(ReflectionUtils.smethod_53(propertyInfo), propertyInfo);
					list[j] = propertyInfo2;
				}
			}
			return list;
		}

		// Token: 0x0600292E RID: 10542 RVA: 0x0001F79E File Offset: 0x0001D99E
		public static BindingFlags RemoveFlag(this BindingFlags bindingAttr, BindingFlags flag)
		{
			if ((bindingAttr & flag) != flag)
			{
				return bindingAttr;
			}
			return bindingAttr ^ flag;
		}

		// Token: 0x0600292F RID: 10543 RVA: 0x0009BF4C File Offset: 0x0009A14C
		private static void GetChildPrivateProperties(IList<PropertyInfo> initialProperties, Type targetType, BindingFlags bindingAttr)
		{
			while (ReflectionUtils.smethod_56(targetType = targetType.BaseType(), null))
			{
				PropertyInfo[] array = ReflectionUtils.smethod_74(targetType, bindingAttr);
				for (int i = 0; i < array.Length; i++)
				{
					PropertyInfo propertyInfo = array[i];
					PropertyInfo subTypeProperty = propertyInfo;
					if (!ReflectionUtils.IsPublic(subTypeProperty))
					{
						int num = initialProperties.IndexOf((PropertyInfo p) => ReflectionUtils.<>c__DisplayClasse.smethod_1(ReflectionUtils.<>c__DisplayClasse.smethod_0(p), ReflectionUtils.<>c__DisplayClasse.smethod_0(subTypeProperty)));
						if (num == -1)
						{
							initialProperties.Add(subTypeProperty);
						}
						else
						{
							PropertyInfo propertyInfo2 = initialProperties[num];
							if (!ReflectionUtils.IsPublic(propertyInfo2))
							{
								initialProperties[num] = subTypeProperty;
							}
						}
					}
					else if (!subTypeProperty.IsVirtual())
					{
						int num2 = initialProperties.IndexOf((PropertyInfo p) => ReflectionUtils.<>c__DisplayClasse.smethod_1(ReflectionUtils.<>c__DisplayClasse.smethod_0(p), ReflectionUtils.<>c__DisplayClasse.smethod_0(subTypeProperty)) && ReflectionUtils.<>c__DisplayClasse.smethod_3(ReflectionUtils.<>c__DisplayClasse.smethod_2(p), ReflectionUtils.<>c__DisplayClasse.smethod_2(subTypeProperty)));
						if (num2 == -1)
						{
							initialProperties.Add(subTypeProperty);
						}
					}
					else
					{
						int num3 = initialProperties.IndexOf((PropertyInfo p) => ReflectionUtils.<>c__DisplayClasse.smethod_1(ReflectionUtils.<>c__DisplayClasse.smethod_0(p), ReflectionUtils.<>c__DisplayClasse.smethod_0(subTypeProperty)) && p.IsVirtual() && ReflectionUtils.<>c__DisplayClasse.smethod_4(p.GetBaseDefinition(), null) && ReflectionUtils.<>c__DisplayClasse.smethod_5(ReflectionUtils.<>c__DisplayClasse.smethod_2(p.GetBaseDefinition()), ReflectionUtils.<>c__DisplayClasse.smethod_2(subTypeProperty)));
						if (num3 == -1)
						{
							initialProperties.Add(subTypeProperty);
						}
					}
				}
			}
		}

		// Token: 0x06002930 RID: 10544 RVA: 0x0009C084 File Offset: 0x0009A284
		public static bool IsMethodOverridden(Type currentType, Type methodDeclaringType, string method)
		{
			return ReflectionUtils.smethod_75(currentType, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).Any((MethodInfo info) => ReflectionUtils.<>c__DisplayClass11.smethod_1(ReflectionUtils.<>c__DisplayClass11.smethod_0(info), method) && ReflectionUtils.<>c__DisplayClass11.smethod_3(ReflectionUtils.<>c__DisplayClass11.smethod_2(info), methodDeclaringType) && ReflectionUtils.<>c__DisplayClass11.smethod_5(ReflectionUtils.<>c__DisplayClass11.smethod_2(ReflectionUtils.<>c__DisplayClass11.smethod_4(info)), methodDeclaringType));
		}

		// Token: 0x06002931 RID: 10545 RVA: 0x0009C0C0 File Offset: 0x0009A2C0
		public static object GetDefaultValue(Type type)
		{
			if (!type.IsValueType())
			{
				return null;
			}
			PrimitiveTypeCode typeCode = ConvertUtils.GetTypeCode(type);
			switch (typeCode)
			{
			case PrimitiveTypeCode.Char:
			case PrimitiveTypeCode.SByte:
			case PrimitiveTypeCode.Int16:
			case PrimitiveTypeCode.UInt16:
			case PrimitiveTypeCode.Int32:
			case PrimitiveTypeCode.Byte:
			case PrimitiveTypeCode.UInt32:
				return 0;
			case PrimitiveTypeCode.CharNullable:
			case PrimitiveTypeCode.BooleanNullable:
			case PrimitiveTypeCode.SByteNullable:
			case PrimitiveTypeCode.Int16Nullable:
			case PrimitiveTypeCode.UInt16Nullable:
			case PrimitiveTypeCode.Int32Nullable:
			case PrimitiveTypeCode.ByteNullable:
			case PrimitiveTypeCode.UInt32Nullable:
			case PrimitiveTypeCode.Int64Nullable:
			case PrimitiveTypeCode.UInt64Nullable:
			case PrimitiveTypeCode.SingleNullable:
			case PrimitiveTypeCode.DoubleNullable:
			case PrimitiveTypeCode.DateTimeNullable:
			case PrimitiveTypeCode.DateTimeOffsetNullable:
			case PrimitiveTypeCode.DecimalNullable:
				break;
			case PrimitiveTypeCode.Boolean:
				return false;
			case PrimitiveTypeCode.Int64:
			case PrimitiveTypeCode.UInt64:
				return 0L;
			case PrimitiveTypeCode.Single:
				return 0f;
			case PrimitiveTypeCode.Double:
				return 0.0;
			case PrimitiveTypeCode.DateTime:
				return default(DateTime);
			case PrimitiveTypeCode.DateTimeOffset:
				return default(DateTimeOffset);
			case PrimitiveTypeCode.Decimal:
				return 0m;
			case PrimitiveTypeCode.Guid:
				return default(Guid);
			default:
				if (typeCode == PrimitiveTypeCode.BigInteger)
				{
					return default(BigInteger);
				}
				break;
			}
			if (ReflectionUtils.IsNullable(type))
			{
				return null;
			}
			return Activator.CreateInstance(type);
		}

		// Token: 0x06002936 RID: 10550 RVA: 0x0001F7D3 File Offset: 0x0001D9D3
		static MethodInfo smethod_0(PropertyInfo propertyInfo_0)
		{
			return propertyInfo_0.GetGetMethod();
		}

		// Token: 0x06002937 RID: 10551 RVA: 0x0001CAB5 File Offset: 0x0001ACB5
		static bool smethod_1(MethodInfo methodInfo_0, MethodInfo methodInfo_1)
		{
			return methodInfo_0 != methodInfo_1;
		}

		// Token: 0x06002938 RID: 10552 RVA: 0x0001CABE File Offset: 0x0001ACBE
		static bool smethod_2(MethodBase methodBase_0)
		{
			return methodBase_0.IsVirtual;
		}

		// Token: 0x06002939 RID: 10553 RVA: 0x0001F7DB File Offset: 0x0001D9DB
		static MethodInfo smethod_3(PropertyInfo propertyInfo_0)
		{
			return propertyInfo_0.GetSetMethod();
		}

		// Token: 0x0600293A RID: 10554 RVA: 0x0001F7E3 File Offset: 0x0001D9E3
		static MethodInfo smethod_4(MethodInfo methodInfo_0)
		{
			return methodInfo_0.GetBaseDefinition();
		}

		// Token: 0x0600293B RID: 10555 RVA: 0x0001E952 File Offset: 0x0001CB52
		static bool smethod_5(MethodBase methodBase_0)
		{
			return methodBase_0.IsPublic;
		}

		// Token: 0x0600293C RID: 10556 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_6(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x0600293D RID: 10557 RVA: 0x0001F7EB File Offset: 0x0001D9EB
		static void smethod_7(SerializationBinder serializationBinder_0, Type type_0, ref string string_0, ref string string_1)
		{
			serializationBinder_0.BindToName(type_0, out string_0, out string_1);
		}

		// Token: 0x0600293E RID: 10558 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_8(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x0600293F RID: 10559 RVA: 0x0001D68F File Offset: 0x0001B88F
		static string smethod_9(Type type_0)
		{
			return type_0.AssemblyQualifiedName;
		}

		// Token: 0x06002940 RID: 10560 RVA: 0x00016A1F File Offset: 0x00014C1F
		static ArgumentOutOfRangeException smethod_10()
		{
			return new ArgumentOutOfRangeException();
		}

		// Token: 0x06002941 RID: 10561 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_11()
		{
			return new StringBuilder();
		}

		// Token: 0x06002942 RID: 10562 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_12(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x06002943 RID: 10563 RVA: 0x0001008C File Offset: 0x0000E28C
		static StringBuilder smethod_13(StringBuilder stringBuilder_0, char char_0)
		{
			return stringBuilder_0.Append(char_0);
		}

		// Token: 0x06002944 RID: 10564 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_14(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06002945 RID: 10565 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_15(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06002946 RID: 10566 RVA: 0x0001CA27 File Offset: 0x0001AC27
		static bool smethod_16(ConstructorInfo constructorInfo_0, ConstructorInfo constructorInfo_1)
		{
			return constructorInfo_0 != constructorInfo_1;
		}

		// Token: 0x06002947 RID: 10567 RVA: 0x0001CA4B File Offset: 0x0001AC4B
		static ConstructorInfo[] smethod_17(Type type_0, BindingFlags bindingFlags_0)
		{
			return type_0.GetConstructors(bindingFlags_0);
		}

		// Token: 0x06002948 RID: 10568 RVA: 0x00015F44 File Offset: 0x00014144
		static Type smethod_18(Type type_0)
		{
			return type_0.GetGenericTypeDefinition();
		}

		// Token: 0x06002949 RID: 10569 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_19(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x0600294A RID: 10570 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_20(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x0600294B RID: 10571 RVA: 0x000175B6 File Offset: 0x000157B6
		static Type smethod_21(Type type_0)
		{
			return Nullable.GetUnderlyingType(type_0);
		}

		// Token: 0x0600294C RID: 10572 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_22()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x0600294D RID: 10573 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_23(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x0600294E RID: 10574 RVA: 0x0001DF78 File Offset: 0x0001C178
		static Type[] smethod_24(Type type_0)
		{
			return type_0.GetInterfaces();
		}

		// Token: 0x0600294F RID: 10575 RVA: 0x00015F2C File Offset: 0x0001412C
		static bool smethod_25(Type type_0)
		{
			return type_0.IsArray;
		}

		// Token: 0x06002950 RID: 10576 RVA: 0x00015F34 File Offset: 0x00014134
		static Type smethod_26(Type type_0)
		{
			return type_0.GetElementType();
		}

		// Token: 0x06002951 RID: 10577 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_27(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x06002952 RID: 10578 RVA: 0x00015F4C File Offset: 0x0001414C
		static Type[] smethod_28(Type type_0)
		{
			return type_0.GetGenericArguments();
		}

		// Token: 0x06002953 RID: 10579 RVA: 0x00017625 File Offset: 0x00015825
		static bool smethod_29(Type type_0, Type type_1)
		{
			return type_0.IsAssignableFrom(type_1);
		}

		// Token: 0x06002954 RID: 10580 RVA: 0x0001E4EC File Offset: 0x0001C6EC
		static Type smethod_30(FieldInfo fieldInfo_0)
		{
			return fieldInfo_0.FieldType;
		}

		// Token: 0x06002955 RID: 10581 RVA: 0x000162CE File Offset: 0x000144CE
		static Type smethod_31(PropertyInfo propertyInfo_0)
		{
			return propertyInfo_0.PropertyType;
		}

		// Token: 0x06002956 RID: 10582 RVA: 0x0001F7F6 File Offset: 0x0001D9F6
		static Type smethod_32(EventInfo eventInfo_0)
		{
			return eventInfo_0.EventHandlerType;
		}

		// Token: 0x06002957 RID: 10583 RVA: 0x0001CAC6 File Offset: 0x0001ACC6
		static Type smethod_33(MethodInfo methodInfo_0)
		{
			return methodInfo_0.ReturnType;
		}

		// Token: 0x06002958 RID: 10584 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_34(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}

		// Token: 0x06002959 RID: 10585 RVA: 0x0001CA1E File Offset: 0x0001AC1E
		static bool smethod_35(PropertyInfo propertyInfo_0, PropertyInfo propertyInfo_1)
		{
			return propertyInfo_0 != propertyInfo_1;
		}

		// Token: 0x0600295A RID: 10586 RVA: 0x0001F7FE File Offset: 0x0001D9FE
		static ParameterInfo[] smethod_36(PropertyInfo propertyInfo_0)
		{
			return propertyInfo_0.GetIndexParameters();
		}

		// Token: 0x0600295B RID: 10587 RVA: 0x0001E4D9 File Offset: 0x0001C6D9
		static object smethod_37(FieldInfo fieldInfo_0, object object_0)
		{
			return fieldInfo_0.GetValue(object_0);
		}

		// Token: 0x0600295C RID: 10588 RVA: 0x0000CDFE File Offset: 0x0000AFFE
		static object smethod_38(PropertyInfo propertyInfo_0, object object_0, object[] object_1)
		{
			return propertyInfo_0.GetValue(object_0, object_1);
		}

		// Token: 0x0600295D RID: 10589 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_39(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x0600295E RID: 10590 RVA: 0x00018E88 File Offset: 0x00017088
		static ArgumentException smethod_40(string string_0, Exception exception_0)
		{
			return new ArgumentException(string_0, exception_0);
		}

		// Token: 0x0600295F RID: 10591 RVA: 0x0001F806 File Offset: 0x0001DA06
		static void smethod_41(FieldInfo fieldInfo_0, object object_0, object object_1)
		{
			fieldInfo_0.SetValue(object_0, object_1);
		}

		// Token: 0x06002960 RID: 10592 RVA: 0x0000CE08 File Offset: 0x0000B008
		static void smethod_42(PropertyInfo propertyInfo_0, object object_0, object object_1, object[] object_2)
		{
			propertyInfo_0.SetValue(object_0, object_1, object_2);
		}

		// Token: 0x06002961 RID: 10593 RVA: 0x0001F810 File Offset: 0x0001DA10
		static bool smethod_43(FieldInfo fieldInfo_0)
		{
			return fieldInfo_0.IsPublic;
		}

		// Token: 0x06002962 RID: 10594 RVA: 0x0001F818 File Offset: 0x0001DA18
		static bool smethod_44(PropertyInfo propertyInfo_0)
		{
			return propertyInfo_0.CanRead;
		}

		// Token: 0x06002963 RID: 10595 RVA: 0x0001E4C8 File Offset: 0x0001C6C8
		static MethodInfo smethod_45(PropertyInfo propertyInfo_0, bool bool_0)
		{
			return propertyInfo_0.GetGetMethod(bool_0);
		}

		// Token: 0x06002964 RID: 10596 RVA: 0x0001E4D1 File Offset: 0x0001C6D1
		static bool smethod_46(FieldInfo fieldInfo_0)
		{
			return fieldInfo_0.IsLiteral;
		}

		// Token: 0x06002965 RID: 10597 RVA: 0x0001E59E File Offset: 0x0001C79E
		static bool smethod_47(FieldInfo fieldInfo_0)
		{
			return fieldInfo_0.IsInitOnly;
		}

		// Token: 0x06002966 RID: 10598 RVA: 0x0001F820 File Offset: 0x0001DA20
		static bool smethod_48(PropertyInfo propertyInfo_0)
		{
			return propertyInfo_0.CanWrite;
		}

		// Token: 0x06002967 RID: 10599 RVA: 0x0001E4F4 File Offset: 0x0001C6F4
		static MethodInfo smethod_49(PropertyInfo propertyInfo_0, bool bool_0)
		{
			return propertyInfo_0.GetSetMethod(bool_0);
		}

		// Token: 0x06002968 RID: 10600 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_50(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06002969 RID: 10601 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_51(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x0600296A RID: 10602 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_52(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x0600296B RID: 10603 RVA: 0x00014858 File Offset: 0x00012A58
		static Type smethod_53(MemberInfo memberInfo_0)
		{
			return memberInfo_0.DeclaringType;
		}

		// Token: 0x0600296C RID: 10604 RVA: 0x0001E948 File Offset: 0x0001CB48
		static MemberInfo[] smethod_54(Type type_0, string string_0, BindingFlags bindingFlags_0)
		{
			return type_0.GetMember(string_0, bindingFlags_0);
		}

		// Token: 0x0600296D RID: 10605 RVA: 0x0001F828 File Offset: 0x0001DA28
		static bool smethod_55(Type type_0)
		{
			return type_0.IsGenericParameter;
		}

		// Token: 0x0600296E RID: 10606 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_56(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x0600296F RID: 10607 RVA: 0x00017758 File Offset: 0x00015958
		static object[] smethod_57(MemberInfo memberInfo_0, bool bool_0)
		{
			return memberInfo_0.GetCustomAttributes(bool_0);
		}

		// Token: 0x06002970 RID: 10608 RVA: 0x000130EC File Offset: 0x000112EC
		static object[] smethod_58(MemberInfo memberInfo_0, Type type_0, bool bool_0)
		{
			return memberInfo_0.GetCustomAttributes(type_0, bool_0);
		}

		// Token: 0x06002971 RID: 10609 RVA: 0x0001F830 File Offset: 0x0001DA30
		static Attribute[] smethod_59(Assembly assembly_0)
		{
			return Attribute.GetCustomAttributes(assembly_0);
		}

		// Token: 0x06002972 RID: 10610 RVA: 0x0001F838 File Offset: 0x0001DA38
		static Attribute[] smethod_60(Assembly assembly_0, Type type_0)
		{
			return Attribute.GetCustomAttributes(assembly_0, type_0);
		}

		// Token: 0x06002973 RID: 10611 RVA: 0x0001F841 File Offset: 0x0001DA41
		static Attribute[] smethod_61(MemberInfo memberInfo_0, bool bool_0)
		{
			return Attribute.GetCustomAttributes(memberInfo_0, bool_0);
		}

		// Token: 0x06002974 RID: 10612 RVA: 0x0001F84A File Offset: 0x0001DA4A
		static Attribute[] smethod_62(MemberInfo memberInfo_0, Type type_0, bool bool_0)
		{
			return Attribute.GetCustomAttributes(memberInfo_0, type_0, bool_0);
		}

		// Token: 0x06002975 RID: 10613 RVA: 0x0001F854 File Offset: 0x0001DA54
		static Attribute[] smethod_63(Module module_0, bool bool_0)
		{
			return Attribute.GetCustomAttributes(module_0, bool_0);
		}

		// Token: 0x06002976 RID: 10614 RVA: 0x0001F85D File Offset: 0x0001DA5D
		static Attribute[] smethod_64(Module module_0, Type type_0, bool bool_0)
		{
			return Attribute.GetCustomAttributes(module_0, type_0, bool_0);
		}

		// Token: 0x06002977 RID: 10615 RVA: 0x0001F867 File Offset: 0x0001DA67
		static Attribute[] smethod_65(ParameterInfo parameterInfo_0, bool bool_0)
		{
			return Attribute.GetCustomAttributes(parameterInfo_0, bool_0);
		}

		// Token: 0x06002978 RID: 10616 RVA: 0x0001F870 File Offset: 0x0001DA70
		static Attribute[] smethod_66(ParameterInfo parameterInfo_0, Type type_0, bool bool_0)
		{
			return Attribute.GetCustomAttributes(parameterInfo_0, type_0, bool_0);
		}

		// Token: 0x06002979 RID: 10617 RVA: 0x0001F87A File Offset: 0x0001DA7A
		static object[] smethod_67(ICustomAttributeProvider icustomAttributeProvider_0, bool bool_0)
		{
			return icustomAttributeProvider_0.GetCustomAttributes(bool_0);
		}

		// Token: 0x0600297A RID: 10618 RVA: 0x0001F883 File Offset: 0x0001DA83
		static object[] smethod_68(ICustomAttributeProvider icustomAttributeProvider_0, Type type_0, bool bool_0)
		{
			return icustomAttributeProvider_0.GetCustomAttributes(type_0, bool_0);
		}

		// Token: 0x0600297B RID: 10619 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_69(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x0600297C RID: 10620 RVA: 0x0000C6B8 File Offset: 0x0000A8B8
		static string smethod_70(string string_0)
		{
			return string_0.Trim();
		}

		// Token: 0x0600297D RID: 10621 RVA: 0x0001F88D File Offset: 0x0001DA8D
		static PropertyInfo smethod_71(Type type_0, string string_0, BindingFlags bindingFlags_0, Binder binder_0, Type type_1, Type[] type_2, ParameterModifier[] parameterModifier_0)
		{
			return type_0.GetProperty(string_0, bindingFlags_0, binder_0, type_1, type_2, parameterModifier_0);
		}

		// Token: 0x0600297E RID: 10622 RVA: 0x0001F89E File Offset: 0x0001DA9E
		static MemberInfo[] smethod_72(Type type_0, string string_0, MemberTypes memberTypes_0, BindingFlags bindingFlags_0)
		{
			return type_0.GetMember(string_0, memberTypes_0, bindingFlags_0);
		}

		// Token: 0x0600297F RID: 10623 RVA: 0x0001CB19 File Offset: 0x0001AD19
		static FieldInfo[] smethod_73(Type type_0, BindingFlags bindingFlags_0)
		{
			return type_0.GetFields(bindingFlags_0);
		}

		// Token: 0x06002980 RID: 10624 RVA: 0x00016369 File Offset: 0x00014569
		static PropertyInfo[] smethod_74(Type type_0, BindingFlags bindingFlags_0)
		{
			return type_0.GetProperties(bindingFlags_0);
		}

		// Token: 0x06002981 RID: 10625 RVA: 0x0001CA85 File Offset: 0x0001AC85
		static MethodInfo[] smethod_75(Type type_0, BindingFlags bindingFlags_0)
		{
			return type_0.GetMethods(bindingFlags_0);
		}

		// Token: 0x06002982 RID: 10626 RVA: 0x0001CA54 File Offset: 0x0001AC54
		static ParameterInfo[] smethod_76(MethodBase methodBase_0)
		{
			return methodBase_0.GetParameters();
		}

		// Token: 0x06002983 RID: 10627 RVA: 0x0001CA64 File Offset: 0x0001AC64
		static Type smethod_77(ParameterInfo parameterInfo_0)
		{
			return parameterInfo_0.ParameterType;
		}

		// Token: 0x06002984 RID: 10628 RVA: 0x0001F8A9 File Offset: 0x0001DAA9
		static bool smethod_78(FieldInfo fieldInfo_0)
		{
			return fieldInfo_0.IsPrivate;
		}

		// Token: 0x04000E60 RID: 3680
		public static readonly Type[] EmptyTypes = Type.EmptyTypes;
	}
}
