﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000228 RID: 552
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter, AllowMultiple = false)]
	public sealed class JsonPropertyAttribute : Attribute
	{
		// Token: 0x1700049D RID: 1181
		// (get) Token: 0x06001F52 RID: 8018 RVA: 0x0001A755 File Offset: 0x00018955
		// (set) Token: 0x06001F53 RID: 8019 RVA: 0x0001A75D File Offset: 0x0001895D
		public Type ItemConverterType { get; set; }

		// Token: 0x1700049E RID: 1182
		// (get) Token: 0x06001F54 RID: 8020 RVA: 0x0001A766 File Offset: 0x00018966
		// (set) Token: 0x06001F55 RID: 8021 RVA: 0x0001A76E File Offset: 0x0001896E
		public object[] ItemConverterParameters { get; set; }

		// Token: 0x1700049F RID: 1183
		// (get) Token: 0x06001F56 RID: 8022 RVA: 0x00085344 File Offset: 0x00083544
		// (set) Token: 0x06001F57 RID: 8023 RVA: 0x0001A777 File Offset: 0x00018977
		public NullValueHandling NullValueHandling
		{
			get
			{
				NullValueHandling? nullValueHandling = this._nullValueHandling;
				if (nullValueHandling == null)
				{
					return NullValueHandling.Include;
				}
				return nullValueHandling.GetValueOrDefault();
			}
			set
			{
				this._nullValueHandling = new NullValueHandling?(value);
			}
		}

		// Token: 0x170004A0 RID: 1184
		// (get) Token: 0x06001F58 RID: 8024 RVA: 0x0008536C File Offset: 0x0008356C
		// (set) Token: 0x06001F59 RID: 8025 RVA: 0x0001A785 File Offset: 0x00018985
		public DefaultValueHandling DefaultValueHandling
		{
			get
			{
				DefaultValueHandling? defaultValueHandling = this._defaultValueHandling;
				if (defaultValueHandling == null)
				{
					return DefaultValueHandling.Include;
				}
				return defaultValueHandling.GetValueOrDefault();
			}
			set
			{
				this._defaultValueHandling = new DefaultValueHandling?(value);
			}
		}

		// Token: 0x170004A1 RID: 1185
		// (get) Token: 0x06001F5A RID: 8026 RVA: 0x00085394 File Offset: 0x00083594
		// (set) Token: 0x06001F5B RID: 8027 RVA: 0x0001A793 File Offset: 0x00018993
		public ReferenceLoopHandling ReferenceLoopHandling
		{
			get
			{
				ReferenceLoopHandling? referenceLoopHandling = this._referenceLoopHandling;
				if (referenceLoopHandling == null)
				{
					return ReferenceLoopHandling.Error;
				}
				return referenceLoopHandling.GetValueOrDefault();
			}
			set
			{
				this._referenceLoopHandling = new ReferenceLoopHandling?(value);
			}
		}

		// Token: 0x170004A2 RID: 1186
		// (get) Token: 0x06001F5C RID: 8028 RVA: 0x000853BC File Offset: 0x000835BC
		// (set) Token: 0x06001F5D RID: 8029 RVA: 0x0001A7A1 File Offset: 0x000189A1
		public ObjectCreationHandling ObjectCreationHandling
		{
			get
			{
				ObjectCreationHandling? objectCreationHandling = this._objectCreationHandling;
				if (objectCreationHandling == null)
				{
					return ObjectCreationHandling.Auto;
				}
				return objectCreationHandling.GetValueOrDefault();
			}
			set
			{
				this._objectCreationHandling = new ObjectCreationHandling?(value);
			}
		}

		// Token: 0x170004A3 RID: 1187
		// (get) Token: 0x06001F5E RID: 8030 RVA: 0x000853E4 File Offset: 0x000835E4
		// (set) Token: 0x06001F5F RID: 8031 RVA: 0x0001A7AF File Offset: 0x000189AF
		public TypeNameHandling TypeNameHandling
		{
			get
			{
				TypeNameHandling? typeNameHandling = this._typeNameHandling;
				if (typeNameHandling == null)
				{
					return TypeNameHandling.None;
				}
				return typeNameHandling.GetValueOrDefault();
			}
			set
			{
				this._typeNameHandling = new TypeNameHandling?(value);
			}
		}

		// Token: 0x170004A4 RID: 1188
		// (get) Token: 0x06001F60 RID: 8032 RVA: 0x0008540C File Offset: 0x0008360C
		// (set) Token: 0x06001F61 RID: 8033 RVA: 0x0001A7BD File Offset: 0x000189BD
		public bool IsReference
		{
			get
			{
				return this._isReference ?? false;
			}
			set
			{
				this._isReference = new bool?(value);
			}
		}

		// Token: 0x170004A5 RID: 1189
		// (get) Token: 0x06001F62 RID: 8034 RVA: 0x00085434 File Offset: 0x00083634
		// (set) Token: 0x06001F63 RID: 8035 RVA: 0x0001A7CB File Offset: 0x000189CB
		public int Order
		{
			get
			{
				int? order = this._order;
				if (order == null)
				{
					return 0;
				}
				return order.GetValueOrDefault();
			}
			set
			{
				this._order = new int?(value);
			}
		}

		// Token: 0x170004A6 RID: 1190
		// (get) Token: 0x06001F64 RID: 8036 RVA: 0x0008545C File Offset: 0x0008365C
		// (set) Token: 0x06001F65 RID: 8037 RVA: 0x0001A7D9 File Offset: 0x000189D9
		public Required Required
		{
			get
			{
				Required? required = this._required;
				if (required == null)
				{
					return Required.Default;
				}
				return required.GetValueOrDefault();
			}
			set
			{
				this._required = new Required?(value);
			}
		}

		// Token: 0x170004A7 RID: 1191
		// (get) Token: 0x06001F66 RID: 8038 RVA: 0x0001A7E7 File Offset: 0x000189E7
		// (set) Token: 0x06001F67 RID: 8039 RVA: 0x0001A7EF File Offset: 0x000189EF
		public string PropertyName { get; set; }

		// Token: 0x170004A8 RID: 1192
		// (get) Token: 0x06001F68 RID: 8040 RVA: 0x00085484 File Offset: 0x00083684
		// (set) Token: 0x06001F69 RID: 8041 RVA: 0x0001A7F8 File Offset: 0x000189F8
		public ReferenceLoopHandling ItemReferenceLoopHandling
		{
			get
			{
				ReferenceLoopHandling? itemReferenceLoopHandling = this._itemReferenceLoopHandling;
				if (itemReferenceLoopHandling == null)
				{
					return ReferenceLoopHandling.Error;
				}
				return itemReferenceLoopHandling.GetValueOrDefault();
			}
			set
			{
				this._itemReferenceLoopHandling = new ReferenceLoopHandling?(value);
			}
		}

		// Token: 0x170004A9 RID: 1193
		// (get) Token: 0x06001F6A RID: 8042 RVA: 0x000854AC File Offset: 0x000836AC
		// (set) Token: 0x06001F6B RID: 8043 RVA: 0x0001A806 File Offset: 0x00018A06
		public TypeNameHandling ItemTypeNameHandling
		{
			get
			{
				TypeNameHandling? itemTypeNameHandling = this._itemTypeNameHandling;
				if (itemTypeNameHandling == null)
				{
					return TypeNameHandling.None;
				}
				return itemTypeNameHandling.GetValueOrDefault();
			}
			set
			{
				this._itemTypeNameHandling = new TypeNameHandling?(value);
			}
		}

		// Token: 0x170004AA RID: 1194
		// (get) Token: 0x06001F6C RID: 8044 RVA: 0x000854D4 File Offset: 0x000836D4
		// (set) Token: 0x06001F6D RID: 8045 RVA: 0x0001A814 File Offset: 0x00018A14
		public bool ItemIsReference
		{
			get
			{
				return this._itemIsReference ?? false;
			}
			set
			{
				this._itemIsReference = new bool?(value);
			}
		}

		// Token: 0x06001F6E RID: 8046 RVA: 0x0000E0B5 File Offset: 0x0000C2B5
		public JsonPropertyAttribute()
		{
		}

		// Token: 0x06001F6F RID: 8047 RVA: 0x0001A822 File Offset: 0x00018A22
		public JsonPropertyAttribute(string propertyName)
		{
			this.PropertyName = propertyName;
		}

		// Token: 0x04000B9B RID: 2971
		internal NullValueHandling? _nullValueHandling;

		// Token: 0x04000B9C RID: 2972
		internal DefaultValueHandling? _defaultValueHandling;

		// Token: 0x04000B9D RID: 2973
		internal ReferenceLoopHandling? _referenceLoopHandling;

		// Token: 0x04000B9E RID: 2974
		internal ObjectCreationHandling? _objectCreationHandling;

		// Token: 0x04000B9F RID: 2975
		internal TypeNameHandling? _typeNameHandling;

		// Token: 0x04000BA0 RID: 2976
		internal bool? _isReference;

		// Token: 0x04000BA1 RID: 2977
		internal int? _order;

		// Token: 0x04000BA2 RID: 2978
		internal Required? _required;

		// Token: 0x04000BA3 RID: 2979
		internal bool? _itemIsReference;

		// Token: 0x04000BA4 RID: 2980
		internal ReferenceLoopHandling? _itemReferenceLoopHandling;

		// Token: 0x04000BA5 RID: 2981
		internal TypeNameHandling? _itemTypeNameHandling;
	}
}
