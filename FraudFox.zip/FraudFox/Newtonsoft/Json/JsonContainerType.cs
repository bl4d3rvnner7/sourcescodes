﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x020001BD RID: 445
	internal enum JsonContainerType
	{
		// Token: 0x040009E0 RID: 2528
		None,
		// Token: 0x040009E1 RID: 2529
		Object,
		// Token: 0x040009E2 RID: 2530
		Array,
		// Token: 0x040009E3 RID: 2531
		Constructor
	}
}
