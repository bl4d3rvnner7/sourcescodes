﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200020B RID: 523
	public enum ObjectCreationHandling
	{
		// Token: 0x04000B66 RID: 2918
		Auto,
		// Token: 0x04000B67 RID: 2919
		Reuse,
		// Token: 0x04000B68 RID: 2920
		Replace
	}
}
