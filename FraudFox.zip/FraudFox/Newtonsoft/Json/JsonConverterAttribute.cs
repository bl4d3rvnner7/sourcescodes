﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000203 RID: 515
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Enum | AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Interface | AttributeTargets.Parameter, AllowMultiple = false)]
	public sealed class JsonConverterAttribute : Attribute
	{
		// Token: 0x17000410 RID: 1040
		// (get) Token: 0x06001D0A RID: 7434 RVA: 0x00019503 File Offset: 0x00017703
		public Type ConverterType
		{
			get
			{
				return this._converterType;
			}
		}

		// Token: 0x17000411 RID: 1041
		// (get) Token: 0x06001D0B RID: 7435 RVA: 0x0001950B File Offset: 0x0001770B
		// (set) Token: 0x06001D0C RID: 7436 RVA: 0x00019513 File Offset: 0x00017713
		public object[] ConverterParameters { get; private set; }

		// Token: 0x06001D0D RID: 7437 RVA: 0x0001951C File Offset: 0x0001771C
		public JsonConverterAttribute(Type converterType)
		{
			if (JsonConverterAttribute.smethod_0(converterType, null))
			{
				throw JsonConverterAttribute.smethod_1(<Module>.smethod_23<string>(3869579912U));
			}
			this._converterType = converterType;
		}

		// Token: 0x06001D0E RID: 7438 RVA: 0x00019544 File Offset: 0x00017744
		public JsonConverterAttribute(Type converterType, params object[] converterParameters)
			: this(converterType)
		{
			this.ConverterParameters = converterParameters;
		}

		// Token: 0x06001D0F RID: 7439 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_0(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x06001D10 RID: 7440 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_1(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x04000B0E RID: 2830
		private readonly Type _converterType;
	}
}
