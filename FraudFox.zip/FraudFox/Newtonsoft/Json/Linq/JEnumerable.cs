﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x0200023C RID: 572
	public struct JEnumerable<T> : IEnumerable<T>, IJEnumerable<T>, IEquatable<JEnumerable<T>>, IEnumerable where T : JToken
	{
		// Token: 0x06002177 RID: 8567 RVA: 0x0001BC41 File Offset: 0x00019E41
		public JEnumerable(IEnumerable<T> enumerable)
		{
			ValidationUtils.ArgumentNotNull(enumerable, <Module>.smethod_24<string>(3846245214U));
			this._enumerable = enumerable;
		}

		// Token: 0x06002178 RID: 8568 RVA: 0x00088608 File Offset: 0x00086808
		public IEnumerator<T> GetEnumerator()
		{
			if (this._enumerable == null)
			{
				return JEnumerable<T>.Empty.GetEnumerator();
			}
			return this._enumerable.GetEnumerator();
		}

		// Token: 0x06002179 RID: 8569 RVA: 0x0001BC5A File Offset: 0x00019E5A
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		// Token: 0x170004F0 RID: 1264
		public IJEnumerable<JToken> this[object key]
		{
			get
			{
				if (this._enumerable == null)
				{
					return JEnumerable<JToken>.Empty;
				}
				return new JEnumerable<JToken>(this._enumerable.Values(key));
			}
		}

		// Token: 0x0600217B RID: 8571 RVA: 0x0001BC8D File Offset: 0x00019E8D
		public bool Equals(JEnumerable<T> other)
		{
			return JEnumerable<T>.smethod_0(this._enumerable, other._enumerable);
		}

		// Token: 0x0600217C RID: 8572 RVA: 0x0001BCA1 File Offset: 0x00019EA1
		public override bool Equals(object obj)
		{
			return obj is JEnumerable<T> && this.Equals((JEnumerable<T>)obj);
		}

		// Token: 0x0600217D RID: 8573 RVA: 0x0001BCB9 File Offset: 0x00019EB9
		public override int GetHashCode()
		{
			if (this._enumerable == null)
			{
				return 0;
			}
			return JEnumerable<T>.smethod_1(this._enumerable);
		}

		// Token: 0x04000C0F RID: 3087
		public static readonly JEnumerable<T> Empty = new JEnumerable<T>(Enumerable.Empty<T>());

		// Token: 0x04000C10 RID: 3088
		private readonly IEnumerable<T> _enumerable;
	}
}
