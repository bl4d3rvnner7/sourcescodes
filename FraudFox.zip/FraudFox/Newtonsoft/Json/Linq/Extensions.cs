﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x02000235 RID: 565
	public static class Extensions
	{
		// Token: 0x0600209C RID: 8348 RVA: 0x0001B501 File Offset: 0x00019701
		public static IJEnumerable<JToken> Ancestors<T>(this IEnumerable<T> source) where T : JToken
		{
			ValidationUtils.ArgumentNotNull(source, <Module>.smethod_26<string>(1736673023U));
			return source.SelectMany((T j) => j.Ancestors()).AsJEnumerable();
		}

		// Token: 0x0600209D RID: 8349 RVA: 0x0001B52A File Offset: 0x0001972A
		public static IJEnumerable<JToken> AncestorsAndSelf<T>(this IEnumerable<T> source) where T : JToken
		{
			ValidationUtils.ArgumentNotNull(source, <Module>.smethod_25<string>(394423462U));
			return source.SelectMany((T j) => j.AncestorsAndSelf()).AsJEnumerable();
		}

		// Token: 0x0600209E RID: 8350 RVA: 0x0001B553 File Offset: 0x00019753
		public static IJEnumerable<JToken> Descendants<T>(this IEnumerable<T> source) where T : JContainer
		{
			ValidationUtils.ArgumentNotNull(source, <Module>.smethod_26<string>(1736673023U));
			return source.SelectMany((T j) => j.Descendants()).AsJEnumerable();
		}

		// Token: 0x0600209F RID: 8351 RVA: 0x0001B57C File Offset: 0x0001977C
		public static IJEnumerable<JToken> DescendantsAndSelf<T>(this IEnumerable<T> source) where T : JContainer
		{
			ValidationUtils.ArgumentNotNull(source, <Module>.smethod_23<string>(2465512069U));
			return source.SelectMany((T j) => j.DescendantsAndSelf()).AsJEnumerable();
		}

		// Token: 0x060020A0 RID: 8352 RVA: 0x0001B5A5 File Offset: 0x000197A5
		public static IJEnumerable<JProperty> Properties(this IEnumerable<JObject> source)
		{
			ValidationUtils.ArgumentNotNull(source, <Module>.smethod_23<string>(2465512069U));
			return source.SelectMany((JObject d) => d.Properties()).AsJEnumerable<JProperty>();
		}

		// Token: 0x060020A1 RID: 8353 RVA: 0x0001B5DF File Offset: 0x000197DF
		public static IJEnumerable<JToken> Values(this IEnumerable<JToken> source, object key)
		{
			return source.Values(key).AsJEnumerable();
		}

		// Token: 0x060020A2 RID: 8354 RVA: 0x0001B5ED File Offset: 0x000197ED
		public static IJEnumerable<JToken> Values(this IEnumerable<JToken> source)
		{
			return source.Values(null);
		}

		// Token: 0x060020A3 RID: 8355 RVA: 0x0001B5F6 File Offset: 0x000197F6
		public static IEnumerable<U> Values<U>(this IEnumerable<JToken> source, object key)
		{
			return source.Values(key);
		}

		// Token: 0x060020A4 RID: 8356 RVA: 0x0001B5FF File Offset: 0x000197FF
		public static IEnumerable<U> Values<U>(this IEnumerable<JToken> source)
		{
			return source.Values(null);
		}

		// Token: 0x060020A5 RID: 8357 RVA: 0x0001B608 File Offset: 0x00019808
		public static U Value<U>(this IEnumerable<JToken> value)
		{
			return value.Value<JToken, U>();
		}

		// Token: 0x060020A6 RID: 8358 RVA: 0x00086EB0 File Offset: 0x000850B0
		public static U Value<T, U>(this IEnumerable<T> value) where T : JToken
		{
			ValidationUtils.ArgumentNotNull(value, <Module>.smethod_23<string>(2465512069U));
			JToken jtoken = value as JToken;
			if (jtoken == null)
			{
				throw Extensions.smethod_0(<Module>.smethod_23<string>(2833261448U));
			}
			return jtoken.Convert<JToken, U>();
		}

		// Token: 0x060020A7 RID: 8359 RVA: 0x00086EF0 File Offset: 0x000850F0
		internal static IEnumerable<U> Values<T, U>(this IEnumerable<T> source, object key) where T : JToken
		{
			Extensions.<Values>d__6<T, U> <Values>d__ = new Extensions.<Values>d__6<T, U>(-2);
			<Values>d__.<>3__source = source;
			<Values>d__.<>3__key = key;
			return <Values>d__;
		}

		// Token: 0x060020A8 RID: 8360 RVA: 0x0001B610 File Offset: 0x00019810
		public static IJEnumerable<JToken> Children<T>(this IEnumerable<T> source) where T : JToken
		{
			return source.Children<T, JToken>().AsJEnumerable();
		}

		// Token: 0x060020A9 RID: 8361 RVA: 0x0001B61D File Offset: 0x0001981D
		public static IEnumerable<U> Children<T, U>(this IEnumerable<T> source) where T : JToken
		{
			ValidationUtils.ArgumentNotNull(source, <Module>.smethod_25<string>(394423462U));
			return source.SelectMany((T c) => c.Children()).Convert<JToken, U>();
		}

		// Token: 0x060020AA RID: 8362 RVA: 0x00086F14 File Offset: 0x00085114
		internal static IEnumerable<U> Convert<T, U>(this IEnumerable<T> source) where T : JToken
		{
			Extensions.<Convert>d__11<T, U> <Convert>d__ = new Extensions.<Convert>d__11<T, U>(-2);
			<Convert>d__.<>3__source = source;
			return <Convert>d__;
		}

		// Token: 0x060020AB RID: 8363 RVA: 0x00086F34 File Offset: 0x00085134
		internal static U Convert<T, U>(this T token) where T : JToken
		{
			if (token == null)
			{
				return default(U);
			}
			if (token is U && Extensions.smethod_2(Extensions.smethod_1(typeof(U).TypeHandle), Extensions.smethod_1(typeof(IComparable).TypeHandle)) && Extensions.smethod_2(Extensions.smethod_1(typeof(U).TypeHandle), Extensions.smethod_1(typeof(IFormattable).TypeHandle)))
			{
				return (U)((object)token);
			}
			JValue jvalue = token as JValue;
			if (jvalue == null)
			{
				throw Extensions.smethod_4(<Module>.smethod_23<string>(758464049U).FormatWith(Extensions.smethod_3(), token.GetType(), Extensions.smethod_1(typeof(T).TypeHandle)));
			}
			if (jvalue.Value is U)
			{
				return (U)((object)jvalue.Value);
			}
			Type type = Extensions.smethod_1(typeof(U).TypeHandle);
			if (ReflectionUtils.IsNullableType(type))
			{
				if (jvalue.Value == null)
				{
					return default(U);
				}
				type = Extensions.smethod_5(type);
			}
			return (U)((object)Extensions.smethod_6(jvalue.Value, type, Extensions.smethod_3()));
		}

		// Token: 0x060020AC RID: 8364 RVA: 0x0001B646 File Offset: 0x00019846
		public static IJEnumerable<JToken> AsJEnumerable(this IEnumerable<JToken> source)
		{
			return source.AsJEnumerable<JToken>();
		}

		// Token: 0x060020AD RID: 8365 RVA: 0x00087040 File Offset: 0x00085240
		public static IJEnumerable<T> AsJEnumerable<T>(this IEnumerable<T> source) where T : JToken
		{
			if (source == null)
			{
				goto IL_0037;
			}
			if (!(source is IJEnumerable<T>))
			{
				return new JEnumerable<T>(source);
			}
			int num = 1396672627;
			IL_001E:
			switch (num ^ 1396672627)
			{
			case 1:
				return null;
			case 2:
				IL_0037:
				num = 1396672626;
				goto IL_001E;
			}
			return (IJEnumerable<T>)source;
		}

		// Token: 0x060020B4 RID: 8372 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_0(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x060020B5 RID: 8373 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_1(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060020B6 RID: 8374 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_2(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x060020B7 RID: 8375 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_3()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060020B8 RID: 8376 RVA: 0x0001B6A6 File Offset: 0x000198A6
		static InvalidCastException smethod_4(string string_0)
		{
			return new InvalidCastException(string_0);
		}

		// Token: 0x060020B9 RID: 8377 RVA: 0x000175B6 File Offset: 0x000157B6
		static Type smethod_5(Type type_0)
		{
			return Nullable.GetUnderlyingType(type_0);
		}

		// Token: 0x060020BA RID: 8378 RVA: 0x000193D1 File Offset: 0x000175D1
		static object smethod_6(object object_0, Type type_0, IFormatProvider iformatProvider_0)
		{
			return global::System.Convert.ChangeType(object_0, type_0, iformatProvider_0);
		}
	}
}
