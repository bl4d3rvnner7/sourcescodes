﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Numerics;
using System.Reflection;
using Newtonsoft.Json.Linq.JsonPath;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x020001EB RID: 491
	public abstract class JToken : IEnumerable<JToken>, IJEnumerable<JToken>, IEnumerable, ICloneable, IDynamicMetaObjectProvider, IJsonLineInfo
	{
		// Token: 0x170003EA RID: 1002
		// (get) Token: 0x06001B6A RID: 7018 RVA: 0x00018A52 File Offset: 0x00016C52
		public static JTokenEqualityComparer EqualityComparer
		{
			get
			{
				if (JToken._equalityComparer == null)
				{
					JToken._equalityComparer = new JTokenEqualityComparer();
				}
				return JToken._equalityComparer;
			}
		}

		// Token: 0x170003EB RID: 1003
		// (get) Token: 0x06001B6B RID: 7019 RVA: 0x00018A6A File Offset: 0x00016C6A
		// (set) Token: 0x06001B6C RID: 7020 RVA: 0x00018A72 File Offset: 0x00016C72
		public JContainer Parent
		{
			[DebuggerStepThrough]
			get
			{
				return this._parent;
			}
			internal set
			{
				this._parent = value;
			}
		}

		// Token: 0x170003EC RID: 1004
		// (get) Token: 0x06001B6D RID: 7021 RVA: 0x0007BBB0 File Offset: 0x00079DB0
		public JToken Root
		{
			get
			{
				JContainer jcontainer = this.Parent;
				if (jcontainer == null)
				{
					return this;
				}
				while (jcontainer.Parent != null)
				{
					jcontainer = jcontainer.Parent;
				}
				return jcontainer;
			}
		}

		// Token: 0x06001B6E RID: 7022
		internal abstract JToken CloneToken();

		// Token: 0x06001B6F RID: 7023
		internal abstract bool DeepEquals(JToken node);

		// Token: 0x170003ED RID: 1005
		// (get) Token: 0x06001B70 RID: 7024
		public abstract JTokenType Type { get; }

		// Token: 0x170003EE RID: 1006
		// (get) Token: 0x06001B71 RID: 7025
		public abstract bool HasValues { get; }

		// Token: 0x06001B72 RID: 7026 RVA: 0x00018A7B File Offset: 0x00016C7B
		public static bool DeepEquals(JToken t1, JToken t2)
		{
			return t1 == t2 || (t1 != null && t2 != null && t1.DeepEquals(t2));
		}

		// Token: 0x170003EF RID: 1007
		// (get) Token: 0x06001B73 RID: 7027 RVA: 0x00018A92 File Offset: 0x00016C92
		// (set) Token: 0x06001B74 RID: 7028 RVA: 0x00018A9A File Offset: 0x00016C9A
		public JToken Next
		{
			get
			{
				return this._next;
			}
			internal set
			{
				this._next = value;
			}
		}

		// Token: 0x170003F0 RID: 1008
		// (get) Token: 0x06001B75 RID: 7029 RVA: 0x00018AA3 File Offset: 0x00016CA3
		// (set) Token: 0x06001B76 RID: 7030 RVA: 0x00018AAB File Offset: 0x00016CAB
		public JToken Previous
		{
			get
			{
				return this._previous;
			}
			internal set
			{
				this._previous = value;
			}
		}

		// Token: 0x170003F1 RID: 1009
		// (get) Token: 0x06001B77 RID: 7031 RVA: 0x0007BBDC File Offset: 0x00079DDC
		public string Path
		{
			get
			{
				if (this.Parent != null)
				{
					IList<JToken> list = this.AncestorsAndSelf().Reverse<JToken>().ToList<JToken>();
					IList<JsonPosition> list2 = new List<JsonPosition>();
					for (int i = 0; i < list.Count; i++)
					{
						JToken jtoken = list[i];
						JToken jtoken2 = null;
						if (i + 1 < list.Count)
						{
							jtoken2 = list[i + 1];
						}
						else if (list[i].Type == JTokenType.Property)
						{
							jtoken2 = list[i];
						}
						if (jtoken2 != null)
						{
							switch (jtoken.Type)
							{
							case JTokenType.Array:
							case JTokenType.Constructor:
							{
								int num = ((IList<JToken>)jtoken).IndexOf(jtoken2);
								list2.Add(new JsonPosition(JsonContainerType.Array)
								{
									Position = num
								});
								break;
							}
							case JTokenType.Property:
							{
								JProperty jproperty = (JProperty)jtoken;
								list2.Add(new JsonPosition(JsonContainerType.Object)
								{
									PropertyName = jproperty.Name
								});
								break;
							}
							}
						}
					}
					return JsonPosition.BuildPath(list2);
				}
				return string.Empty;
			}
		}

		// Token: 0x06001B78 RID: 7032 RVA: 0x0000C6A8 File Offset: 0x0000A8A8
		internal JToken()
		{
		}

		// Token: 0x06001B79 RID: 7033 RVA: 0x0007BCDC File Offset: 0x00079EDC
		public void AddAfterSelf(object content)
		{
			if (this._parent == null)
			{
				throw JToken.smethod_0(<Module>.smethod_27<string>(911291724U));
			}
			int num = this._parent.IndexOfItem(this);
			this._parent.AddInternal(num + 1, content, false);
		}

		// Token: 0x06001B7A RID: 7034 RVA: 0x0007BD20 File Offset: 0x00079F20
		public void AddBeforeSelf(object content)
		{
			if (this._parent == null)
			{
				throw JToken.smethod_0(<Module>.smethod_23<string>(1153354380U));
			}
			int num = this._parent.IndexOfItem(this);
			this._parent.AddInternal(num, content, false);
		}

		// Token: 0x06001B7B RID: 7035 RVA: 0x00018AB4 File Offset: 0x00016CB4
		public IEnumerable<JToken> Ancestors()
		{
			return this.GetAncestors(false);
		}

		// Token: 0x06001B7C RID: 7036 RVA: 0x00018ABD File Offset: 0x00016CBD
		public IEnumerable<JToken> AncestorsAndSelf()
		{
			return this.GetAncestors(true);
		}

		// Token: 0x06001B7D RID: 7037 RVA: 0x0007BD60 File Offset: 0x00079F60
		internal IEnumerable<JToken> GetAncestors(bool self)
		{
			JToken.<GetAncestors>d__2 <GetAncestors>d__ = new JToken.<GetAncestors>d__2(-2);
			<GetAncestors>d__.<>4__this = this;
			<GetAncestors>d__.<>3__self = self;
			return <GetAncestors>d__;
		}

		// Token: 0x06001B7E RID: 7038 RVA: 0x0007BD84 File Offset: 0x00079F84
		public IEnumerable<JToken> AfterSelf()
		{
			if (this.Parent != null)
			{
				for (JToken o = this.Next; o != null; o = o.Next)
				{
					yield return o;
				}
			}
			yield break;
		}

		// Token: 0x06001B7F RID: 7039 RVA: 0x0007BDA4 File Offset: 0x00079FA4
		public IEnumerable<JToken> BeforeSelf()
		{
			JToken.<BeforeSelf>d__a <BeforeSelf>d__a = new JToken.<BeforeSelf>d__a(-2);
			<BeforeSelf>d__a.<>4__this = this;
			return <BeforeSelf>d__a;
		}

		// Token: 0x170003F2 RID: 1010
		public virtual JToken this[object key]
		{
			get
			{
				throw JToken.smethod_0(<Module>.smethod_24<string>(1845859438U).FormatWith(JToken.smethod_1(), JToken.smethod_2(this)));
			}
			set
			{
				throw JToken.smethod_0(<Module>.smethod_23<string>(3223011277U).FormatWith(JToken.smethod_1(), JToken.smethod_2(this)));
			}
		}

		// Token: 0x06001B82 RID: 7042 RVA: 0x0007BDC4 File Offset: 0x00079FC4
		public virtual T Value<T>(object key)
		{
			JToken jtoken = this[key];
			if (jtoken == null)
			{
				return default(T);
			}
			return jtoken.Convert<JToken, T>();
		}

		// Token: 0x170003F3 RID: 1011
		// (get) Token: 0x06001B83 RID: 7043 RVA: 0x00018B08 File Offset: 0x00016D08
		public virtual JToken First
		{
			get
			{
				throw JToken.smethod_0(<Module>.smethod_23<string>(1907667263U).FormatWith(JToken.smethod_1(), JToken.smethod_2(this)));
			}
		}

		// Token: 0x170003F4 RID: 1012
		// (get) Token: 0x06001B84 RID: 7044 RVA: 0x00018AC6 File Offset: 0x00016CC6
		public virtual JToken Last
		{
			get
			{
				throw JToken.smethod_0(<Module>.smethod_24<string>(1845859438U).FormatWith(JToken.smethod_1(), JToken.smethod_2(this)));
			}
		}

		// Token: 0x06001B85 RID: 7045 RVA: 0x00018B29 File Offset: 0x00016D29
		public virtual JEnumerable<JToken> Children()
		{
			return JEnumerable<JToken>.Empty;
		}

		// Token: 0x06001B86 RID: 7046 RVA: 0x00018B30 File Offset: 0x00016D30
		public JEnumerable<T> Children<T>() where T : JToken
		{
			return new JEnumerable<T>(this.Children().OfType<T>());
		}

		// Token: 0x06001B87 RID: 7047 RVA: 0x00018AC6 File Offset: 0x00016CC6
		public virtual IEnumerable<T> Values<T>()
		{
			throw JToken.smethod_0(<Module>.smethod_24<string>(1845859438U).FormatWith(JToken.smethod_1(), JToken.smethod_2(this)));
		}

		// Token: 0x06001B88 RID: 7048 RVA: 0x00018B47 File Offset: 0x00016D47
		public void Remove()
		{
			if (this._parent == null)
			{
				throw JToken.smethod_0(<Module>.smethod_26<string>(1855587484U));
			}
			this._parent.RemoveItem(this);
		}

		// Token: 0x06001B89 RID: 7049 RVA: 0x00018B6E File Offset: 0x00016D6E
		public void Replace(JToken value)
		{
			if (this._parent == null)
			{
				throw JToken.smethod_0(<Module>.smethod_23<string>(1153354380U));
			}
			this._parent.ReplaceItem(this, value);
		}

		// Token: 0x06001B8A RID: 7050
		public abstract void WriteTo(JsonWriter writer, params JsonConverter[] converters);

		// Token: 0x06001B8B RID: 7051 RVA: 0x00018B95 File Offset: 0x00016D95
		public override string ToString()
		{
			return this.ToString(Formatting.Indented, new JsonConverter[0]);
		}

		// Token: 0x06001B8C RID: 7052 RVA: 0x0007BDEC File Offset: 0x00079FEC
		public string ToString(Formatting formatting, params JsonConverter[] converters)
		{
			StringWriter stringWriter = JToken.smethod_3(JToken.smethod_1());
			string text;
			try
			{
				this.WriteTo(new JsonTextWriter(stringWriter)
				{
					Formatting = formatting
				}, converters);
				text = JToken.smethod_4(stringWriter);
			}
			finally
			{
				if (stringWriter != null)
				{
					JToken.smethod_5(stringWriter);
				}
			}
			return text;
		}

		// Token: 0x06001B8D RID: 7053 RVA: 0x0007BE40 File Offset: 0x0007A040
		private static JValue EnsureValue(JToken value)
		{
			if (value == null)
			{
				throw JToken.smethod_6(<Module>.smethod_26<string>(1806306238U));
			}
			if (value is JProperty)
			{
				value = ((JProperty)value).Value;
			}
			return value as JValue;
		}

		// Token: 0x06001B8E RID: 7054 RVA: 0x00018BA4 File Offset: 0x00016DA4
		private static string GetType(JToken token)
		{
			ValidationUtils.ArgumentNotNull(token, <Module>.smethod_24<string>(3026683931U));
			if (token is JProperty)
			{
				token = ((JProperty)token).Value;
			}
			return JToken.smethod_4(token.Type);
		}

		// Token: 0x06001B8F RID: 7055 RVA: 0x00018BDB File Offset: 0x00016DDB
		private static bool ValidateToken(JToken o, JTokenType[] validTypes, bool nullable)
		{
			return Array.IndexOf<JTokenType>(validTypes, o.Type) != -1 || (nullable && (o.Type == JTokenType.Null || o.Type == JTokenType.Undefined));
		}

		// Token: 0x06001B90 RID: 7056 RVA: 0x0007BE80 File Offset: 0x0007A080
		public static explicit operator bool(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.BooleanTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_26<string>(3322356694U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return JToken.smethod_8((int)((BigInteger)jvalue.Value));
			}
			return JToken.smethod_9(jvalue.Value, JToken.smethod_1());
		}

		// Token: 0x06001B91 RID: 7057 RVA: 0x0007BEF8 File Offset: 0x0007A0F8
		public static explicit operator DateTimeOffset(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.DateTimeTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_24<string>(97488130U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is DateTimeOffset)
			{
				return (DateTimeOffset)jvalue.Value;
			}
			if (jvalue.Value is string)
			{
				return DateTimeOffset.Parse((string)jvalue.Value, JToken.smethod_1());
			}
			return new DateTimeOffset(JToken.smethod_10(jvalue.Value, JToken.smethod_1()));
		}

		// Token: 0x06001B92 RID: 7058 RVA: 0x0007BF90 File Offset: 0x0007A190
		public static explicit operator bool?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.BooleanTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_24<string>(3525637243U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return new bool?(JToken.smethod_8((int)((BigInteger)jvalue.Value)));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new bool?(JToken.smethod_9(jvalue.Value, JToken.smethod_1()));
		}

		// Token: 0x06001B93 RID: 7059 RVA: 0x0007C034 File Offset: 0x0007A234
		public static explicit operator long(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_23<string>(3746414158U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return (long)((BigInteger)jvalue.Value);
			}
			return JToken.smethod_11(jvalue.Value, JToken.smethod_1());
		}

		// Token: 0x06001B94 RID: 7060 RVA: 0x0007C0A8 File Offset: 0x0007A2A8
		public static explicit operator DateTime?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.DateTimeTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_26<string>(1227543213U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is DateTimeOffset)
			{
				return new DateTime?(((DateTimeOffset)jvalue.Value).DateTime);
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new DateTime?(Convert.ToDateTime(jvalue.Value, CultureInfo.InvariantCulture));
		}

		// Token: 0x06001B95 RID: 7061 RVA: 0x0007C14C File Offset: 0x0007A34C
		public static explicit operator DateTimeOffset?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.DateTimeTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_26<string>(2627277665U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			if (jvalue.Value is DateTimeOffset)
			{
				return (DateTimeOffset?)jvalue.Value;
			}
			if (jvalue.Value is string)
			{
				return new DateTimeOffset?(DateTimeOffset.Parse((string)jvalue.Value, JToken.smethod_1()));
			}
			return new DateTimeOffset?(new DateTimeOffset(JToken.smethod_10(jvalue.Value, JToken.smethod_1())));
		}

		// Token: 0x06001B96 RID: 7062 RVA: 0x0007C210 File Offset: 0x0007A410
		public static explicit operator decimal?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_27<string>(3895080076U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return new decimal?((decimal)((BigInteger)jvalue.Value));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new decimal?(JToken.smethod_12(jvalue.Value, JToken.smethod_1()));
		}

		// Token: 0x06001B97 RID: 7063 RVA: 0x0007C2AC File Offset: 0x0007A4AC
		public static explicit operator double?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_23<string>(1483475509U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return new double?((double)((BigInteger)jvalue.Value));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new double?(JToken.smethod_13(jvalue.Value, JToken.smethod_1()));
		}

		// Token: 0x06001B98 RID: 7064 RVA: 0x0007C34C File Offset: 0x0007A54C
		public static explicit operator char?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.CharTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_23<string>(1115726130U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return new char?((char)(ushort)((BigInteger)jvalue.Value));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new char?(JToken.smethod_14(jvalue.Value, JToken.smethod_1()));
		}

		// Token: 0x06001B99 RID: 7065 RVA: 0x0007C3EC File Offset: 0x0007A5EC
		public static explicit operator int(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_25<string>(2721843193U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return (int)((BigInteger)jvalue.Value);
			}
			return JToken.smethod_15(jvalue.Value, JToken.smethod_1());
		}

		// Token: 0x06001B9A RID: 7066 RVA: 0x0007C460 File Offset: 0x0007A660
		public static explicit operator short(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_27<string>(2543050979U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return (short)((BigInteger)jvalue.Value);
			}
			return JToken.smethod_16(jvalue.Value, JToken.smethod_1());
		}

		// Token: 0x06001B9B RID: 7067 RVA: 0x0007C4D4 File Offset: 0x0007A6D4
		[CLSCompliant(false)]
		public static explicit operator ushort(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_26<string>(3255321936U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return (ushort)((BigInteger)jvalue.Value);
			}
			return JToken.smethod_17(jvalue.Value, JToken.smethod_1());
		}

		// Token: 0x06001B9C RID: 7068 RVA: 0x0007C548 File Offset: 0x0007A748
		[CLSCompliant(false)]
		public static explicit operator char(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.CharTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_26<string>(3207439966U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return (char)(ushort)((BigInteger)jvalue.Value);
			}
			return JToken.smethod_14(jvalue.Value, JToken.smethod_1());
		}

		// Token: 0x06001B9D RID: 7069 RVA: 0x0007C5BC File Offset: 0x0007A7BC
		public static explicit operator byte(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_27<string>(1703860505U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return (byte)((BigInteger)jvalue.Value);
			}
			return JToken.smethod_18(jvalue.Value, JToken.smethod_1());
		}

		// Token: 0x06001B9E RID: 7070 RVA: 0x0007C630 File Offset: 0x0007A830
		[CLSCompliant(false)]
		public static explicit operator sbyte(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_24<string>(82753188U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return (sbyte)((BigInteger)jvalue.Value);
			}
			return JToken.smethod_19(jvalue.Value, JToken.smethod_1());
		}

		// Token: 0x06001B9F RID: 7071 RVA: 0x0007C6A4 File Offset: 0x0007A8A4
		public static explicit operator int?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_26<string>(1788552726U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return new int?((int)((BigInteger)jvalue.Value));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new int?(JToken.smethod_15(jvalue.Value, JToken.smethod_1()));
		}

		// Token: 0x06001BA0 RID: 7072 RVA: 0x0007C744 File Offset: 0x0007A944
		public static explicit operator short?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_23<string>(1445847259U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return new short?((short)((BigInteger)jvalue.Value));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new short?(JToken.smethod_16(jvalue.Value, JToken.smethod_1()));
		}

		// Token: 0x06001BA1 RID: 7073 RVA: 0x0007C7E4 File Offset: 0x0007A9E4
		[CLSCompliant(false)]
		public static explicit operator ushort?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_24<string>(3510902301U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return new ushort?((ushort)((BigInteger)jvalue.Value));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new ushort?(JToken.smethod_17(jvalue.Value, JToken.smethod_1()));
		}

		// Token: 0x06001BA2 RID: 7074 RVA: 0x0007C884 File Offset: 0x0007AA84
		public static explicit operator byte?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_26<string>(3979130147U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return new byte?((byte)((BigInteger)jvalue.Value));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new byte?(JToken.smethod_18(jvalue.Value, JToken.smethod_1()));
		}

		// Token: 0x06001BA3 RID: 7075 RVA: 0x0007C920 File Offset: 0x0007AB20
		[CLSCompliant(false)]
		public static explicit operator sbyte?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_23<string>(3147754777U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return new sbyte?((sbyte)((BigInteger)jvalue.Value));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new sbyte?(JToken.smethod_19(jvalue.Value, JToken.smethod_1()));
		}

		// Token: 0x06001BA4 RID: 7076 RVA: 0x0007C9BC File Offset: 0x0007ABBC
		public static explicit operator DateTime(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.DateTimeTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_26<string>(1227543213U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is DateTimeOffset)
			{
				return ((DateTimeOffset)jvalue.Value).DateTime;
			}
			return Convert.ToDateTime(jvalue.Value, CultureInfo.InvariantCulture);
		}

		// Token: 0x06001BA5 RID: 7077 RVA: 0x0007CA34 File Offset: 0x0007AC34
		public static explicit operator long?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_24<string>(2942846807U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return new long?((long)((BigInteger)jvalue.Value));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new long?(JToken.smethod_11(jvalue.Value, JToken.smethod_1()));
		}

		// Token: 0x06001BA6 RID: 7078 RVA: 0x0007CAD0 File Offset: 0x0007ACD0
		public static explicit operator float?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_26<string>(3494731786U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return new float?((float)((BigInteger)jvalue.Value));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new float?(JToken.smethod_20(jvalue.Value, JToken.smethod_1()));
		}

		// Token: 0x06001BA7 RID: 7079 RVA: 0x0007CB70 File Offset: 0x0007AD70
		public static explicit operator decimal(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_26<string>(321783516U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return (decimal)((BigInteger)jvalue.Value);
			}
			return JToken.smethod_12(jvalue.Value, JToken.smethod_1());
		}

		// Token: 0x06001BA8 RID: 7080 RVA: 0x0007CBE4 File Offset: 0x0007ADE4
		[CLSCompliant(false)]
		public static explicit operator uint?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_26<string>(2799652757U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return new uint?((uint)((BigInteger)jvalue.Value));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new uint?(JToken.smethod_21(jvalue.Value, JToken.smethod_1()));
		}

		// Token: 0x06001BA9 RID: 7081 RVA: 0x0007CC80 File Offset: 0x0007AE80
		[CLSCompliant(false)]
		public static explicit operator ulong?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_25<string>(2701768403U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return new ulong?((ulong)((BigInteger)jvalue.Value));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new ulong?(JToken.smethod_22(jvalue.Value, JToken.smethod_1()));
		}

		// Token: 0x06001BAA RID: 7082 RVA: 0x0007CD20 File Offset: 0x0007AF20
		public static explicit operator double(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_24<string>(787995688U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return (double)((BigInteger)jvalue.Value);
			}
			return JToken.smethod_13(jvalue.Value, JToken.smethod_1());
		}

		// Token: 0x06001BAB RID: 7083 RVA: 0x0007CD94 File Offset: 0x0007AF94
		public static explicit operator float(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_26<string>(3494731786U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return (float)((BigInteger)jvalue.Value);
			}
			return JToken.smethod_20(jvalue.Value, JToken.smethod_1());
		}

		// Token: 0x06001BAC RID: 7084 RVA: 0x0007CE08 File Offset: 0x0007B008
		public static explicit operator string(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.StringTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_25<string>(3188950574U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			if (jvalue.Value is byte[])
			{
				return JToken.smethod_23((byte[])jvalue.Value);
			}
			if (jvalue.Value is BigInteger)
			{
				return ((BigInteger)jvalue.Value).ToString(JToken.smethod_1());
			}
			return Convert.ToString(jvalue.Value, CultureInfo.InvariantCulture);
		}

		// Token: 0x06001BAD RID: 7085 RVA: 0x0007CEB4 File Offset: 0x0007B0B4
		[CLSCompliant(false)]
		public static explicit operator uint(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_25<string>(2214586232U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return (uint)((BigInteger)jvalue.Value);
			}
			return JToken.smethod_21(jvalue.Value, JToken.smethod_1());
		}

		// Token: 0x06001BAE RID: 7086 RVA: 0x0007CF28 File Offset: 0x0007B128
		[CLSCompliant(false)]
		public static explicit operator ulong(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.NumberTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_27<string>(1464980500U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is BigInteger)
			{
				return (ulong)((BigInteger)jvalue.Value);
			}
			return JToken.smethod_22(jvalue.Value, JToken.smethod_1());
		}

		// Token: 0x06001BAF RID: 7087 RVA: 0x0007CF9C File Offset: 0x0007B19C
		public static explicit operator byte[](JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.BytesTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_27<string>(625790026U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is string)
			{
				return JToken.smethod_25(JToken.smethod_24(jvalue.Value, JToken.smethod_1()));
			}
			if (jvalue.Value is BigInteger)
			{
				return ((BigInteger)jvalue.Value).ToByteArray();
			}
			if (jvalue.Value is byte[])
			{
				return (byte[])jvalue.Value;
			}
			throw new ArgumentException(<Module>.smethod_25<string>(3676132745U).FormatWith(CultureInfo.InvariantCulture, JToken.GetType(value)));
		}

		// Token: 0x06001BB0 RID: 7088 RVA: 0x0007D064 File Offset: 0x0007B264
		public static explicit operator Guid(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.GuidTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_25<string>(4093717463U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value is byte[])
			{
				return new Guid((byte[])jvalue.Value);
			}
			if (!(jvalue.Value is Guid))
			{
				return new Guid(Convert.ToString(jvalue.Value, CultureInfo.InvariantCulture));
			}
			return (Guid)jvalue.Value;
		}

		// Token: 0x06001BB1 RID: 7089 RVA: 0x0007D0F8 File Offset: 0x0007B2F8
		public static explicit operator Guid?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.GuidTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_26<string>(2142879304U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			if (jvalue.Value is byte[])
			{
				return new Guid?(new Guid((byte[])jvalue.Value));
			}
			return new Guid?((jvalue.Value is Guid) ? ((Guid)jvalue.Value) : new Guid(Convert.ToString(jvalue.Value, CultureInfo.InvariantCulture)));
		}

		// Token: 0x06001BB2 RID: 7090 RVA: 0x0007D1B8 File Offset: 0x0007B3B8
		public static explicit operator TimeSpan(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.TimeSpanTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_24<string>(1057288493U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (!(jvalue.Value is TimeSpan))
			{
				return ConvertUtils.ParseTimeSpan(JToken.smethod_24(jvalue.Value, JToken.smethod_1()));
			}
			return (TimeSpan)jvalue.Value;
		}

		// Token: 0x06001BB3 RID: 7091 RVA: 0x0007D22C File Offset: 0x0007B42C
		public static explicit operator TimeSpan?(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.TimeSpanTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_25<string>(355529791U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new TimeSpan?((jvalue.Value is TimeSpan) ? ((TimeSpan)jvalue.Value) : ConvertUtils.ParseTimeSpan(JToken.smethod_24(jvalue.Value, JToken.smethod_1())));
		}

		// Token: 0x06001BB4 RID: 7092 RVA: 0x0007D2C8 File Offset: 0x0007B4C8
		public static explicit operator Uri(JToken value)
		{
			if (value == null)
			{
				return null;
			}
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.UriTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_27<string>(1319343881U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			if (!(jvalue.Value is Uri))
			{
				return JToken.smethod_26(JToken.smethod_24(jvalue.Value, JToken.smethod_1()));
			}
			return (Uri)jvalue.Value;
		}

		// Token: 0x06001BB5 RID: 7093 RVA: 0x0007D34C File Offset: 0x0007B54C
		private static BigInteger ToBigInteger(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.BigIntegerTypes, false))
			{
				throw JToken.smethod_7(<Module>.smethod_23<string>(2331859017U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			return ConvertUtils.ToBigInteger(jvalue.Value);
		}

		// Token: 0x06001BB6 RID: 7094 RVA: 0x0007D39C File Offset: 0x0007B59C
		private static BigInteger? ToBigIntegerNullable(JToken value)
		{
			JValue jvalue = JToken.EnsureValue(value);
			if (jvalue == null || !JToken.ValidateToken(jvalue, JToken.BigIntegerTypes, true))
			{
				throw JToken.smethod_7(<Module>.smethod_23<string>(2331859017U).FormatWith(JToken.smethod_1(), JToken.GetType(value)));
			}
			if (jvalue.Value == null)
			{
				return null;
			}
			return new BigInteger?(ConvertUtils.ToBigInteger(jvalue.Value));
		}

		// Token: 0x06001BB7 RID: 7095 RVA: 0x00018C09 File Offset: 0x00016E09
		public static implicit operator JToken(bool value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BB8 RID: 7096 RVA: 0x00018C11 File Offset: 0x00016E11
		public static implicit operator JToken(DateTimeOffset value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BB9 RID: 7097 RVA: 0x00018C19 File Offset: 0x00016E19
		public static implicit operator JToken(byte value)
		{
			return new JValue((long)((ulong)value));
		}

		// Token: 0x06001BBA RID: 7098 RVA: 0x00018C22 File Offset: 0x00016E22
		public static implicit operator JToken(byte? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BBB RID: 7099 RVA: 0x00018C2F File Offset: 0x00016E2F
		[CLSCompliant(false)]
		public static implicit operator JToken(sbyte value)
		{
			return new JValue((long)value);
		}

		// Token: 0x06001BBC RID: 7100 RVA: 0x00018C38 File Offset: 0x00016E38
		[CLSCompliant(false)]
		public static implicit operator JToken(sbyte? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BBD RID: 7101 RVA: 0x00018C45 File Offset: 0x00016E45
		public static implicit operator JToken(bool? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BBE RID: 7102 RVA: 0x00018C52 File Offset: 0x00016E52
		public static implicit operator JToken(long value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BBF RID: 7103 RVA: 0x00018C5A File Offset: 0x00016E5A
		public static implicit operator JToken(DateTime? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BC0 RID: 7104 RVA: 0x00018C67 File Offset: 0x00016E67
		public static implicit operator JToken(DateTimeOffset? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BC1 RID: 7105 RVA: 0x00018C74 File Offset: 0x00016E74
		public static implicit operator JToken(decimal? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BC2 RID: 7106 RVA: 0x00018C81 File Offset: 0x00016E81
		public static implicit operator JToken(double? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BC3 RID: 7107 RVA: 0x00018C2F File Offset: 0x00016E2F
		[CLSCompliant(false)]
		public static implicit operator JToken(short value)
		{
			return new JValue((long)value);
		}

		// Token: 0x06001BC4 RID: 7108 RVA: 0x00018C19 File Offset: 0x00016E19
		[CLSCompliant(false)]
		public static implicit operator JToken(ushort value)
		{
			return new JValue((long)((ulong)value));
		}

		// Token: 0x06001BC5 RID: 7109 RVA: 0x00018C2F File Offset: 0x00016E2F
		public static implicit operator JToken(int value)
		{
			return new JValue((long)value);
		}

		// Token: 0x06001BC6 RID: 7110 RVA: 0x00018C8E File Offset: 0x00016E8E
		public static implicit operator JToken(int? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BC7 RID: 7111 RVA: 0x00018C9B File Offset: 0x00016E9B
		public static implicit operator JToken(DateTime value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BC8 RID: 7112 RVA: 0x00018CA3 File Offset: 0x00016EA3
		public static implicit operator JToken(long? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BC9 RID: 7113 RVA: 0x00018CB0 File Offset: 0x00016EB0
		public static implicit operator JToken(float? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BCA RID: 7114 RVA: 0x00018CBD File Offset: 0x00016EBD
		public static implicit operator JToken(decimal value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BCB RID: 7115 RVA: 0x00018CC5 File Offset: 0x00016EC5
		[CLSCompliant(false)]
		public static implicit operator JToken(short? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BCC RID: 7116 RVA: 0x00018CD2 File Offset: 0x00016ED2
		[CLSCompliant(false)]
		public static implicit operator JToken(ushort? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BCD RID: 7117 RVA: 0x00018CDF File Offset: 0x00016EDF
		[CLSCompliant(false)]
		public static implicit operator JToken(uint? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BCE RID: 7118 RVA: 0x00018CEC File Offset: 0x00016EEC
		[CLSCompliant(false)]
		public static implicit operator JToken(ulong? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BCF RID: 7119 RVA: 0x00018CF9 File Offset: 0x00016EF9
		public static implicit operator JToken(double value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BD0 RID: 7120 RVA: 0x00018D01 File Offset: 0x00016F01
		public static implicit operator JToken(float value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BD1 RID: 7121 RVA: 0x00018D09 File Offset: 0x00016F09
		public static implicit operator JToken(string value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BD2 RID: 7122 RVA: 0x00018C19 File Offset: 0x00016E19
		[CLSCompliant(false)]
		public static implicit operator JToken(uint value)
		{
			return new JValue((long)((ulong)value));
		}

		// Token: 0x06001BD3 RID: 7123 RVA: 0x00018D11 File Offset: 0x00016F11
		[CLSCompliant(false)]
		public static implicit operator JToken(ulong value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BD4 RID: 7124 RVA: 0x00018D19 File Offset: 0x00016F19
		public static implicit operator JToken(byte[] value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BD5 RID: 7125 RVA: 0x00018D21 File Offset: 0x00016F21
		public static implicit operator JToken(Uri value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BD6 RID: 7126 RVA: 0x00018D29 File Offset: 0x00016F29
		public static implicit operator JToken(TimeSpan value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BD7 RID: 7127 RVA: 0x00018D31 File Offset: 0x00016F31
		public static implicit operator JToken(TimeSpan? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BD8 RID: 7128 RVA: 0x00018D3E File Offset: 0x00016F3E
		public static implicit operator JToken(Guid value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BD9 RID: 7129 RVA: 0x00018D46 File Offset: 0x00016F46
		public static implicit operator JToken(Guid? value)
		{
			return new JValue(value);
		}

		// Token: 0x06001BDA RID: 7130 RVA: 0x00018D53 File Offset: 0x00016F53
		IEnumerator IEnumerable.GetEnumerator()
		{
			return ((IEnumerable<JToken>)this).GetEnumerator();
		}

		// Token: 0x06001BDB RID: 7131 RVA: 0x0007D404 File Offset: 0x0007B604
		IEnumerator<JToken> IEnumerable<JToken>.GetEnumerator()
		{
			return this.Children().GetEnumerator();
		}

		// Token: 0x06001BDC RID: 7132
		internal abstract int GetDeepHashCode();

		// Token: 0x170003F5 RID: 1013
		IJEnumerable<JToken> IJEnumerable<JToken>.this[object key]
		{
			get
			{
				return this[key];
			}
		}

		// Token: 0x06001BDE RID: 7134 RVA: 0x00018D64 File Offset: 0x00016F64
		public JsonReader CreateReader()
		{
			return new JTokenReader(this, this.Path);
		}

		// Token: 0x06001BDF RID: 7135 RVA: 0x0007D420 File Offset: 0x0007B620
		internal static JToken FromObjectInternal(object o, JsonSerializer jsonSerializer)
		{
			ValidationUtils.ArgumentNotNull(o, <Module>.smethod_23<string>(1582073370U));
			ValidationUtils.ArgumentNotNull(jsonSerializer, <Module>.smethod_25<string>(2612096160U));
			JTokenWriter jtokenWriter = new JTokenWriter();
			JToken token;
			try
			{
				jsonSerializer.Serialize(jtokenWriter, o);
				token = jtokenWriter.Token;
			}
			finally
			{
				if (jtokenWriter != null)
				{
					JToken.smethod_5(jtokenWriter);
				}
			}
			return token;
		}

		// Token: 0x06001BE0 RID: 7136 RVA: 0x00018D72 File Offset: 0x00016F72
		public static JToken FromObject(object o)
		{
			return JToken.FromObjectInternal(o, JsonSerializer.CreateDefault());
		}

		// Token: 0x06001BE1 RID: 7137 RVA: 0x00018D7F File Offset: 0x00016F7F
		public static JToken FromObject(object o, JsonSerializer jsonSerializer)
		{
			return JToken.FromObjectInternal(o, jsonSerializer);
		}

		// Token: 0x06001BE2 RID: 7138 RVA: 0x00018D88 File Offset: 0x00016F88
		public T ToObject<T>()
		{
			return (T)((object)this.ToObject(JToken.smethod_27(typeof(T).TypeHandle)));
		}

		// Token: 0x06001BE3 RID: 7139 RVA: 0x0007D480 File Offset: 0x0007B680
		public object ToObject(Type objectType)
		{
			if (JsonConvert.DefaultSettings == null)
			{
				bool flag;
				PrimitiveTypeCode typeCode = ConvertUtils.GetTypeCode(objectType, out flag);
				if (flag && this.Type == JTokenType.String)
				{
					Type type = (objectType.IsEnum() ? objectType : JToken.smethod_28(objectType));
					object obj;
					try
					{
						obj = JToken.smethod_29(type, (string)this, true);
					}
					catch (Exception ex)
					{
						throw JToken.smethod_31(<Module>.smethod_26<string>(570769760U).FormatWith(JToken.smethod_1(), (string)this, JToken.smethod_30(type)), ex);
					}
					return obj;
				}
				switch (typeCode)
				{
				case PrimitiveTypeCode.Char:
					return (char)this;
				case PrimitiveTypeCode.CharNullable:
					return (char?)this;
				case PrimitiveTypeCode.Boolean:
					return (bool)this;
				case PrimitiveTypeCode.BooleanNullable:
					return (bool?)this;
				case PrimitiveTypeCode.SByte:
					return (sbyte?)this;
				case PrimitiveTypeCode.SByteNullable:
					return (sbyte)this;
				case PrimitiveTypeCode.Int16:
					return (short)this;
				case PrimitiveTypeCode.Int16Nullable:
					return (short?)this;
				case PrimitiveTypeCode.UInt16:
					return (ushort)this;
				case PrimitiveTypeCode.UInt16Nullable:
					return (ushort?)this;
				case PrimitiveTypeCode.Int32:
					return (int)this;
				case PrimitiveTypeCode.Int32Nullable:
					return (int?)this;
				case PrimitiveTypeCode.Byte:
					return (byte)this;
				case PrimitiveTypeCode.ByteNullable:
					return (byte?)this;
				case PrimitiveTypeCode.UInt32:
					return (uint)this;
				case PrimitiveTypeCode.UInt32Nullable:
					return (uint?)this;
				case PrimitiveTypeCode.Int64:
					return (long)this;
				case PrimitiveTypeCode.Int64Nullable:
					return (long?)this;
				case PrimitiveTypeCode.UInt64:
					return (ulong)this;
				case PrimitiveTypeCode.UInt64Nullable:
					return (ulong?)this;
				case PrimitiveTypeCode.Single:
					return (float)this;
				case PrimitiveTypeCode.SingleNullable:
					return (float?)this;
				case PrimitiveTypeCode.Double:
					return (double)this;
				case PrimitiveTypeCode.DoubleNullable:
					return (double?)this;
				case PrimitiveTypeCode.DateTime:
					return (DateTime)this;
				case PrimitiveTypeCode.DateTimeNullable:
					return (DateTime?)this;
				case PrimitiveTypeCode.DateTimeOffset:
					return (DateTimeOffset)this;
				case PrimitiveTypeCode.DateTimeOffsetNullable:
					return (DateTimeOffset?)this;
				case PrimitiveTypeCode.Decimal:
					return (decimal)this;
				case PrimitiveTypeCode.DecimalNullable:
					return (decimal?)this;
				case PrimitiveTypeCode.Guid:
					return (Guid)this;
				case PrimitiveTypeCode.GuidNullable:
					return (Guid?)this;
				case PrimitiveTypeCode.TimeSpan:
					return (TimeSpan)this;
				case PrimitiveTypeCode.TimeSpanNullable:
					return (TimeSpan?)this;
				case PrimitiveTypeCode.BigInteger:
					return JToken.ToBigInteger(this);
				case PrimitiveTypeCode.BigIntegerNullable:
					return JToken.ToBigIntegerNullable(this);
				case PrimitiveTypeCode.Uri:
					return (Uri)this;
				case PrimitiveTypeCode.String:
					return (string)this;
				}
			}
			return this.ToObject(objectType, JsonSerializer.CreateDefault());
		}

		// Token: 0x06001BE4 RID: 7140 RVA: 0x00018D9F File Offset: 0x00016F9F
		public T ToObject<T>(JsonSerializer jsonSerializer)
		{
			return (T)((object)this.ToObject(JToken.smethod_27(typeof(T).TypeHandle), jsonSerializer));
		}

		// Token: 0x06001BE5 RID: 7141 RVA: 0x0007D780 File Offset: 0x0007B980
		public object ToObject(Type objectType, JsonSerializer jsonSerializer)
		{
			ValidationUtils.ArgumentNotNull(jsonSerializer, <Module>.smethod_25<string>(2612096160U));
			JTokenReader jtokenReader = new JTokenReader(this);
			object obj;
			try
			{
				obj = jsonSerializer.Deserialize(jtokenReader, objectType);
			}
			finally
			{
				if (jtokenReader != null)
				{
					JToken.smethod_5(jtokenReader);
				}
			}
			return obj;
		}

		// Token: 0x06001BE6 RID: 7142 RVA: 0x0007D7CC File Offset: 0x0007B9CC
		public static JToken ReadFrom(JsonReader reader)
		{
			ValidationUtils.ArgumentNotNull(reader, <Module>.smethod_26<string>(3313616177U));
			if (reader.TokenType == JsonToken.None && !reader.Read())
			{
				throw JsonReaderException.Create(reader, <Module>.smethod_25<string>(2751291066U));
			}
			IJsonLineInfo jsonLineInfo = reader as IJsonLineInfo;
			switch (reader.TokenType)
			{
			case JsonToken.StartObject:
				return JObject.Load(reader);
			case JsonToken.StartArray:
				return JArray.Load(reader);
			case JsonToken.StartConstructor:
				return JConstructor.Load(reader);
			case JsonToken.PropertyName:
				return JProperty.Load(reader);
			case JsonToken.Comment:
			{
				JValue jvalue = JValue.CreateComment(JToken.smethod_4(reader.Value));
				jvalue.SetLineInfo(jsonLineInfo);
				return jvalue;
			}
			case JsonToken.Integer:
			case JsonToken.Float:
			case JsonToken.String:
			case JsonToken.Boolean:
			case JsonToken.Date:
			case JsonToken.Bytes:
			{
				JValue jvalue = new JValue(reader.Value);
				jvalue.SetLineInfo(jsonLineInfo);
				return jvalue;
			}
			case JsonToken.Null:
			{
				JValue jvalue = JValue.CreateNull();
				jvalue.SetLineInfo(jsonLineInfo);
				return jvalue;
			}
			case JsonToken.Undefined:
			{
				JValue jvalue = JValue.CreateUndefined();
				jvalue.SetLineInfo(jsonLineInfo);
				return jvalue;
			}
			}
			throw JsonReaderException.Create(reader, <Module>.smethod_24<string>(229593929U).FormatWith(JToken.smethod_1(), reader.TokenType));
		}

		// Token: 0x06001BE7 RID: 7143 RVA: 0x0007D8F4 File Offset: 0x0007BAF4
		public static JToken Parse(string json)
		{
			JsonReader jsonReader = new JsonTextReader(JToken.smethod_32(json));
			JToken jtoken2;
			try
			{
				JToken jtoken = JToken.Load(jsonReader);
				if (jsonReader.Read() && jsonReader.TokenType != JsonToken.Comment)
				{
					throw JsonReaderException.Create(jsonReader, <Module>.smethod_25<string>(712890139U));
				}
				jtoken2 = jtoken;
			}
			finally
			{
				if (jsonReader != null)
				{
					JToken.smethod_5(jsonReader);
				}
			}
			return jtoken2;
		}

		// Token: 0x06001BE8 RID: 7144 RVA: 0x00018DB7 File Offset: 0x00016FB7
		public static JToken Load(JsonReader reader)
		{
			return JToken.ReadFrom(reader);
		}

		// Token: 0x06001BE9 RID: 7145 RVA: 0x00018DBF File Offset: 0x00016FBF
		internal void SetLineInfo(IJsonLineInfo lineInfo)
		{
			if (lineInfo != null && lineInfo.HasLineInfo())
			{
				this.SetLineInfo(lineInfo.LineNumber, lineInfo.LinePosition);
				return;
			}
		}

		// Token: 0x06001BEA RID: 7146 RVA: 0x00018DDF File Offset: 0x00016FDF
		internal void SetLineInfo(int lineNumber, int linePosition)
		{
			this.AddAnnotation(new JToken.LineInfoAnnotation(lineNumber, linePosition));
		}

		// Token: 0x06001BEB RID: 7147 RVA: 0x00018DEE File Offset: 0x00016FEE
		bool IJsonLineInfo.HasLineInfo()
		{
			return this.Annotation<JToken.LineInfoAnnotation>() != null;
		}

		// Token: 0x170003F6 RID: 1014
		// (get) Token: 0x06001BEC RID: 7148 RVA: 0x0007D958 File Offset: 0x0007BB58
		int IJsonLineInfo.LineNumber
		{
			get
			{
				JToken.LineInfoAnnotation lineInfoAnnotation = this.Annotation<JToken.LineInfoAnnotation>();
				if (lineInfoAnnotation != null)
				{
					return lineInfoAnnotation.LineNumber;
				}
				return 0;
			}
		}

		// Token: 0x170003F7 RID: 1015
		// (get) Token: 0x06001BED RID: 7149 RVA: 0x0007D978 File Offset: 0x0007BB78
		int IJsonLineInfo.LinePosition
		{
			get
			{
				JToken.LineInfoAnnotation lineInfoAnnotation = this.Annotation<JToken.LineInfoAnnotation>();
				if (lineInfoAnnotation != null)
				{
					return lineInfoAnnotation.LinePosition;
				}
				return 0;
			}
		}

		// Token: 0x06001BEE RID: 7150 RVA: 0x00018DFC File Offset: 0x00016FFC
		public JToken SelectToken(string path)
		{
			return this.SelectToken(path, false);
		}

		// Token: 0x06001BEF RID: 7151 RVA: 0x0007D998 File Offset: 0x0007BB98
		public JToken SelectToken(string path, bool errorWhenNoMatch)
		{
			JPath jpath = new JPath(path);
			JToken jtoken = null;
			IEnumerator<JToken> enumerator = jpath.Evaluate(this, errorWhenNoMatch).GetEnumerator();
			try
			{
				while (JToken.smethod_33(enumerator))
				{
					JToken jtoken2 = enumerator.Current;
					if (jtoken != null)
					{
						throw new JsonException(<Module>.smethod_24<string>(2066374889U));
					}
					jtoken = jtoken2;
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JToken.smethod_5(enumerator);
				}
			}
			return jtoken;
		}

		// Token: 0x06001BF0 RID: 7152 RVA: 0x00018E06 File Offset: 0x00017006
		public IEnumerable<JToken> SelectTokens(string path)
		{
			return this.SelectTokens(path, false);
		}

		// Token: 0x06001BF1 RID: 7153 RVA: 0x0007DA04 File Offset: 0x0007BC04
		public IEnumerable<JToken> SelectTokens(string path, bool errorWhenNoMatch)
		{
			JPath jpath = new JPath(path);
			return jpath.Evaluate(this, errorWhenNoMatch);
		}

		// Token: 0x06001BF2 RID: 7154 RVA: 0x00018E10 File Offset: 0x00017010
		protected virtual DynamicMetaObject GetMetaObject(Expression parameter)
		{
			return new DynamicProxyMetaObject<JToken>(parameter, this, new DynamicProxy<JToken>(), true);
		}

		// Token: 0x06001BF3 RID: 7155 RVA: 0x00018E1F File Offset: 0x0001701F
		DynamicMetaObject IDynamicMetaObjectProvider.GetMetaObject(Expression parameter)
		{
			return this.GetMetaObject(parameter);
		}

		// Token: 0x06001BF4 RID: 7156 RVA: 0x00018E28 File Offset: 0x00017028
		object ICloneable.Clone()
		{
			return this.DeepClone();
		}

		// Token: 0x06001BF5 RID: 7157 RVA: 0x00018E30 File Offset: 0x00017030
		public JToken DeepClone()
		{
			return this.CloneToken();
		}

		// Token: 0x06001BF6 RID: 7158 RVA: 0x0007DA20 File Offset: 0x0007BC20
		public void AddAnnotation(object annotation)
		{
			if (annotation == null)
			{
				throw JToken.smethod_6(<Module>.smethod_23<string>(1526244261U));
			}
			if (this._annotations == null)
			{
				this._annotations = ((annotation is object[]) ? new object[] { annotation } : annotation);
				return;
			}
			object[] array = this._annotations as object[];
			if (array != null)
			{
				int num = 0;
				while (num < array.Length && array[num] != null)
				{
					num++;
				}
				if (num == array.Length)
				{
					Array.Resize<object>(ref array, num * 2);
					this._annotations = array;
				}
				array[num] = annotation;
				return;
			}
			this._annotations = new object[] { this._annotations, annotation };
		}

		// Token: 0x06001BF7 RID: 7159 RVA: 0x0007DAC0 File Offset: 0x0007BCC0
		public T Annotation<T>() where T : class
		{
			if (this._annotations != null)
			{
				object[] array = this._annotations as object[];
				if (array == null)
				{
					return this._annotations as T;
				}
				foreach (object obj in array)
				{
					if (obj == null)
					{
						break;
					}
					T t = obj as T;
					if (t != null)
					{
						return t;
					}
				}
			}
			return default(T);
		}

		// Token: 0x06001BF8 RID: 7160 RVA: 0x0007DB2C File Offset: 0x0007BD2C
		public object Annotation(Type type)
		{
			if (JToken.smethod_34(type, null))
			{
				throw JToken.smethod_6(<Module>.smethod_26<string>(1001144091U));
			}
			if (this._annotations != null)
			{
				object[] array = this._annotations as object[];
				if (array != null)
				{
					foreach (object obj in array)
					{
						if (obj == null)
						{
							break;
						}
						if (JToken.smethod_35(type, obj))
						{
							return obj;
						}
					}
				}
				else if (JToken.smethod_35(type, this._annotations))
				{
					return this._annotations;
				}
			}
			return null;
		}

		// Token: 0x06001BF9 RID: 7161 RVA: 0x0007DBA4 File Offset: 0x0007BDA4
		public IEnumerable<T> Annotations<T>() where T : class
		{
			if (this._annotations != null)
			{
				object[] annotations = this._annotations as object[];
				if (annotations == null)
				{
					T annotation = this._annotations as T;
					if (annotation != null)
					{
						yield return annotation;
					}
				}
				else
				{
					foreach (object o in annotations)
					{
						if (o == null)
						{
							break;
						}
						T casted = o as T;
						if (casted != null)
						{
							yield return casted;
						}
					}
				}
			}
			yield break;
		}

		// Token: 0x06001BFA RID: 7162 RVA: 0x0007DBC4 File Offset: 0x0007BDC4
		public IEnumerable<object> Annotations(Type type)
		{
			if (JToken.<Annotations>d__16.smethod_2(type, null))
			{
				throw JToken.<Annotations>d__16.smethod_3(<Module>.smethod_24<string>(1347420388U));
			}
			if (this._annotations != null)
			{
				object[] annotations = this._annotations as object[];
				if (annotations == null)
				{
					if (JToken.<Annotations>d__16.smethod_4(type, this._annotations))
					{
						yield return this._annotations;
					}
				}
				else
				{
					foreach (object o in annotations)
					{
						if (o == null)
						{
							break;
						}
						if (JToken.<Annotations>d__16.smethod_4(type, o))
						{
							yield return o;
						}
					}
				}
			}
			yield break;
		}

		// Token: 0x06001BFB RID: 7163 RVA: 0x0007DBE8 File Offset: 0x0007BDE8
		public void RemoveAnnotations<T>() where T : class
		{
			if (this._annotations != null)
			{
				object[] array = this._annotations as object[];
				if (array == null)
				{
					if (this._annotations is T)
					{
						this._annotations = null;
						return;
					}
				}
				else
				{
					int i = 0;
					int j = 0;
					while (i < array.Length)
					{
						object obj = array[i];
						if (obj == null)
						{
							break;
						}
						if (!(obj is T))
						{
							array[j++] = obj;
						}
						i++;
					}
					if (j != 0)
					{
						while (j < i)
						{
							array[j++] = null;
						}
						return;
					}
					this._annotations = null;
				}
			}
		}

		// Token: 0x06001BFC RID: 7164 RVA: 0x0007DC64 File Offset: 0x0007BE64
		public void RemoveAnnotations(Type type)
		{
			if (JToken.smethod_34(type, null))
			{
				throw JToken.smethod_6(<Module>.smethod_24<string>(1347420388U));
			}
			if (this._annotations != null)
			{
				object[] array = this._annotations as object[];
				if (array == null)
				{
					if (JToken.smethod_35(type, this._annotations))
					{
						this._annotations = null;
						return;
					}
				}
				else
				{
					int i = 0;
					int j = 0;
					while (i < array.Length)
					{
						object obj = array[i];
						if (obj == null)
						{
							break;
						}
						if (!JToken.smethod_35(type, obj))
						{
							array[j++] = obj;
						}
						i++;
					}
					if (j != 0)
					{
						while (j < i)
						{
							array[j++] = null;
						}
						return;
					}
					this._annotations = null;
				}
			}
		}

		// Token: 0x06001BFE RID: 7166 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_0(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x06001BFF RID: 7167 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_1()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001C00 RID: 7168 RVA: 0x0001040D File Offset: 0x0000E60D
		static Type smethod_2(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06001C01 RID: 7169 RVA: 0x00016261 File Offset: 0x00014461
		static StringWriter smethod_3(IFormatProvider iformatProvider_0)
		{
			return new StringWriter(iformatProvider_0);
		}

		// Token: 0x06001C02 RID: 7170 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_4(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06001C03 RID: 7171 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_5(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06001C04 RID: 7172 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_6(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x06001C05 RID: 7173 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_7(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x06001C06 RID: 7174 RVA: 0x00018E38 File Offset: 0x00017038
		static bool smethod_8(int int_0)
		{
			return Convert.ToBoolean(int_0);
		}

		// Token: 0x06001C07 RID: 7175 RVA: 0x0001711B File Offset: 0x0001531B
		static bool smethod_9(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToBoolean(object_0, iformatProvider_0);
		}

		// Token: 0x06001C08 RID: 7176 RVA: 0x00017124 File Offset: 0x00015324
		static DateTime smethod_10(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToDateTime(object_0, iformatProvider_0);
		}

		// Token: 0x06001C09 RID: 7177 RVA: 0x00017109 File Offset: 0x00015309
		static long smethod_11(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToInt64(object_0, iformatProvider_0);
		}

		// Token: 0x06001C0A RID: 7178 RVA: 0x00016830 File Offset: 0x00014A30
		static decimal smethod_12(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToDecimal(object_0, iformatProvider_0);
		}

		// Token: 0x06001C0B RID: 7179 RVA: 0x00017112 File Offset: 0x00015312
		static double smethod_13(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToDouble(object_0, iformatProvider_0);
		}

		// Token: 0x06001C0C RID: 7180 RVA: 0x00018E40 File Offset: 0x00017040
		static char smethod_14(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToChar(object_0, iformatProvider_0);
		}

		// Token: 0x06001C0D RID: 7181 RVA: 0x00016839 File Offset: 0x00014A39
		static int smethod_15(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToInt32(object_0, iformatProvider_0);
		}

		// Token: 0x06001C0E RID: 7182 RVA: 0x00018E49 File Offset: 0x00017049
		static short smethod_16(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToInt16(object_0, iformatProvider_0);
		}

		// Token: 0x06001C0F RID: 7183 RVA: 0x00018E52 File Offset: 0x00017052
		static ushort smethod_17(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToUInt16(object_0, iformatProvider_0);
		}

		// Token: 0x06001C10 RID: 7184 RVA: 0x000175BE File Offset: 0x000157BE
		static byte smethod_18(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToByte(object_0, iformatProvider_0);
		}

		// Token: 0x06001C11 RID: 7185 RVA: 0x00018E5B File Offset: 0x0001705B
		static sbyte smethod_19(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToSByte(object_0, iformatProvider_0);
		}

		// Token: 0x06001C12 RID: 7186 RVA: 0x00018E64 File Offset: 0x00017064
		static float smethod_20(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToSingle(object_0, iformatProvider_0);
		}

		// Token: 0x06001C13 RID: 7187 RVA: 0x00018E6D File Offset: 0x0001706D
		static uint smethod_21(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToUInt32(object_0, iformatProvider_0);
		}

		// Token: 0x06001C14 RID: 7188 RVA: 0x00018E76 File Offset: 0x00017076
		static ulong smethod_22(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToUInt64(object_0, iformatProvider_0);
		}

		// Token: 0x06001C15 RID: 7189 RVA: 0x0000C8C9 File Offset: 0x0000AAC9
		static string smethod_23(byte[] byte_0)
		{
			return Convert.ToBase64String(byte_0);
		}

		// Token: 0x06001C16 RID: 7190 RVA: 0x00018E7F File Offset: 0x0001707F
		static string smethod_24(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToString(object_0, iformatProvider_0);
		}

		// Token: 0x06001C17 RID: 7191 RVA: 0x0000C86F File Offset: 0x0000AA6F
		static byte[] smethod_25(string string_0)
		{
			return Convert.FromBase64String(string_0);
		}

		// Token: 0x06001C18 RID: 7192 RVA: 0x0000DEDB File Offset: 0x0000C0DB
		static Uri smethod_26(string string_0)
		{
			return new Uri(string_0);
		}

		// Token: 0x06001C19 RID: 7193 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_27(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return global::System.Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001C1A RID: 7194 RVA: 0x000175B6 File Offset: 0x000157B6
		static Type smethod_28(Type type_0)
		{
			return Nullable.GetUnderlyingType(type_0);
		}

		// Token: 0x06001C1B RID: 7195 RVA: 0x00013078 File Offset: 0x00011278
		static object smethod_29(Type type_0, string string_0, bool bool_0)
		{
			return Enum.Parse(type_0, string_0, bool_0);
		}

		// Token: 0x06001C1C RID: 7196 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_30(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x06001C1D RID: 7197 RVA: 0x00018E88 File Offset: 0x00017088
		static ArgumentException smethod_31(string string_0, Exception exception_0)
		{
			return new ArgumentException(string_0, exception_0);
		}

		// Token: 0x06001C1E RID: 7198 RVA: 0x000161BD File Offset: 0x000143BD
		static StringReader smethod_32(string string_0)
		{
			return new StringReader(string_0);
		}

		// Token: 0x06001C1F RID: 7199 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_33(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06001C20 RID: 7200 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_34(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x06001C21 RID: 7201 RVA: 0x00018E91 File Offset: 0x00017091
		static bool smethod_35(Type type_0, object object_0)
		{
			return type_0.IsInstanceOfType(object_0);
		}

		// Token: 0x04000ABA RID: 2746
		private static JTokenEqualityComparer _equalityComparer;

		// Token: 0x04000ABB RID: 2747
		private JContainer _parent;

		// Token: 0x04000ABC RID: 2748
		private JToken _previous;

		// Token: 0x04000ABD RID: 2749
		private JToken _next;

		// Token: 0x04000ABE RID: 2750
		private object _annotations;

		// Token: 0x04000ABF RID: 2751
		private static readonly JTokenType[] BooleanTypes = new JTokenType[]
		{
			JTokenType.Integer,
			JTokenType.Float,
			JTokenType.String,
			JTokenType.Comment,
			JTokenType.Raw,
			JTokenType.Boolean
		};

		// Token: 0x04000AC0 RID: 2752
		private static readonly JTokenType[] NumberTypes = new JTokenType[]
		{
			JTokenType.Integer,
			JTokenType.Float,
			JTokenType.String,
			JTokenType.Comment,
			JTokenType.Raw,
			JTokenType.Boolean
		};

		// Token: 0x04000AC1 RID: 2753
		private static readonly JTokenType[] BigIntegerTypes = new JTokenType[]
		{
			JTokenType.Integer,
			JTokenType.Float,
			JTokenType.String,
			JTokenType.Comment,
			JTokenType.Raw,
			JTokenType.Boolean,
			JTokenType.Bytes
		};

		// Token: 0x04000AC2 RID: 2754
		private static readonly JTokenType[] StringTypes = new JTokenType[]
		{
			JTokenType.Date,
			JTokenType.Integer,
			JTokenType.Float,
			JTokenType.String,
			JTokenType.Comment,
			JTokenType.Raw,
			JTokenType.Boolean,
			JTokenType.Bytes,
			JTokenType.Guid,
			JTokenType.TimeSpan,
			JTokenType.Uri
		};

		// Token: 0x04000AC3 RID: 2755
		private static readonly JTokenType[] GuidTypes = new JTokenType[]
		{
			JTokenType.String,
			JTokenType.Comment,
			JTokenType.Raw,
			JTokenType.Guid,
			JTokenType.Bytes
		};

		// Token: 0x04000AC4 RID: 2756
		private static readonly JTokenType[] TimeSpanTypes = new JTokenType[]
		{
			JTokenType.String,
			JTokenType.Comment,
			JTokenType.Raw,
			JTokenType.TimeSpan
		};

		// Token: 0x04000AC5 RID: 2757
		private static readonly JTokenType[] UriTypes = new JTokenType[]
		{
			JTokenType.String,
			JTokenType.Comment,
			JTokenType.Raw,
			JTokenType.Uri
		};

		// Token: 0x04000AC6 RID: 2758
		private static readonly JTokenType[] CharTypes = new JTokenType[]
		{
			JTokenType.Integer,
			JTokenType.Float,
			JTokenType.String,
			JTokenType.Comment,
			JTokenType.Raw
		};

		// Token: 0x04000AC7 RID: 2759
		private static readonly JTokenType[] DateTimeTypes = new JTokenType[]
		{
			JTokenType.Date,
			JTokenType.String,
			JTokenType.Comment,
			JTokenType.Raw
		};

		// Token: 0x04000AC8 RID: 2760
		private static readonly JTokenType[] BytesTypes = new JTokenType[]
		{
			JTokenType.Bytes,
			JTokenType.String,
			JTokenType.Comment,
			JTokenType.Raw,
			JTokenType.Integer
		};

		// Token: 0x020001EC RID: 492
		private class LineInfoAnnotation
		{
			// Token: 0x06001C22 RID: 7202 RVA: 0x00018E9A File Offset: 0x0001709A
			public LineInfoAnnotation(int lineNumber, int linePosition)
			{
				this.LineNumber = lineNumber;
				this.LinePosition = linePosition;
			}

			// Token: 0x04000AC9 RID: 2761
			internal readonly int LineNumber;

			// Token: 0x04000ACA RID: 2762
			internal readonly int LinePosition;
		}
	}
}
