﻿using System;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x02000246 RID: 582
	public enum JTokenType
	{
		// Token: 0x04000C2B RID: 3115
		None,
		// Token: 0x04000C2C RID: 3116
		Object,
		// Token: 0x04000C2D RID: 3117
		Array,
		// Token: 0x04000C2E RID: 3118
		Constructor,
		// Token: 0x04000C2F RID: 3119
		Property,
		// Token: 0x04000C30 RID: 3120
		Comment,
		// Token: 0x04000C31 RID: 3121
		Integer,
		// Token: 0x04000C32 RID: 3122
		Float,
		// Token: 0x04000C33 RID: 3123
		String,
		// Token: 0x04000C34 RID: 3124
		Boolean,
		// Token: 0x04000C35 RID: 3125
		Null,
		// Token: 0x04000C36 RID: 3126
		Undefined,
		// Token: 0x04000C37 RID: 3127
		Date,
		// Token: 0x04000C38 RID: 3128
		Raw,
		// Token: 0x04000C39 RID: 3129
		Bytes,
		// Token: 0x04000C3A RID: 3130
		Guid,
		// Token: 0x04000C3B RID: 3131
		Uri,
		// Token: 0x04000C3C RID: 3132
		TimeSpan
	}
}
