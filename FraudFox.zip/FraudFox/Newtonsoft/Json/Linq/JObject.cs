﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Dynamic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x0200023D RID: 573
	public class JObject : JContainer, IDictionary<string, JToken>, ICollection<KeyValuePair<string, JToken>>, IEnumerable<KeyValuePair<string, JToken>>, INotifyPropertyChanged, IEnumerable, ICustomTypeDescriptor, INotifyPropertyChanging
	{
		// Token: 0x170004F1 RID: 1265
		// (get) Token: 0x0600217F RID: 8575 RVA: 0x0001BCE1 File Offset: 0x00019EE1
		protected override IList<JToken> ChildrenTokens
		{
			get
			{
				return this._properties;
			}
		}

		// Token: 0x1400002B RID: 43
		// (add) Token: 0x06002180 RID: 8576 RVA: 0x00088638 File Offset: 0x00086838
		// (remove) Token: 0x06002181 RID: 8577 RVA: 0x00088670 File Offset: 0x00086870
		public event PropertyChangedEventHandler PropertyChanged
		{
			add
			{
				PropertyChangedEventHandler propertyChangedEventHandler = this.PropertyChanged;
				PropertyChangedEventHandler propertyChangedEventHandler2;
				do
				{
					propertyChangedEventHandler2 = propertyChangedEventHandler;
					PropertyChangedEventHandler propertyChangedEventHandler3 = (PropertyChangedEventHandler)JObject.smethod_65(propertyChangedEventHandler2, value);
					propertyChangedEventHandler = Interlocked.CompareExchange<PropertyChangedEventHandler>(ref this.PropertyChanged, propertyChangedEventHandler3, propertyChangedEventHandler2);
				}
				while (propertyChangedEventHandler != propertyChangedEventHandler2);
			}
			remove
			{
				PropertyChangedEventHandler propertyChangedEventHandler = this.PropertyChanged;
				PropertyChangedEventHandler propertyChangedEventHandler2;
				do
				{
					propertyChangedEventHandler2 = propertyChangedEventHandler;
					PropertyChangedEventHandler propertyChangedEventHandler3 = (PropertyChangedEventHandler)JObject.smethod_66(propertyChangedEventHandler2, value);
					propertyChangedEventHandler = Interlocked.CompareExchange<PropertyChangedEventHandler>(ref this.PropertyChanged, propertyChangedEventHandler3, propertyChangedEventHandler2);
				}
				while (propertyChangedEventHandler != propertyChangedEventHandler2);
			}
		}

		// Token: 0x1400002C RID: 44
		// (add) Token: 0x06002182 RID: 8578 RVA: 0x000886A8 File Offset: 0x000868A8
		// (remove) Token: 0x06002183 RID: 8579 RVA: 0x000886E0 File Offset: 0x000868E0
		public event PropertyChangingEventHandler PropertyChanging
		{
			add
			{
				PropertyChangingEventHandler propertyChangingEventHandler = this.PropertyChanging;
				PropertyChangingEventHandler propertyChangingEventHandler2;
				do
				{
					propertyChangingEventHandler2 = propertyChangingEventHandler;
					PropertyChangingEventHandler propertyChangingEventHandler3 = (PropertyChangingEventHandler)JObject.smethod_65(propertyChangingEventHandler2, value);
					propertyChangingEventHandler = Interlocked.CompareExchange<PropertyChangingEventHandler>(ref this.PropertyChanging, propertyChangingEventHandler3, propertyChangingEventHandler2);
				}
				while (propertyChangingEventHandler != propertyChangingEventHandler2);
			}
			remove
			{
				PropertyChangingEventHandler propertyChangingEventHandler = this.PropertyChanging;
				PropertyChangingEventHandler propertyChangingEventHandler2;
				do
				{
					propertyChangingEventHandler2 = propertyChangingEventHandler;
					PropertyChangingEventHandler propertyChangingEventHandler3 = (PropertyChangingEventHandler)JObject.smethod_66(propertyChangingEventHandler2, value);
					propertyChangingEventHandler = Interlocked.CompareExchange<PropertyChangingEventHandler>(ref this.PropertyChanging, propertyChangingEventHandler3, propertyChangingEventHandler2);
				}
				while (propertyChangingEventHandler != propertyChangingEventHandler2);
			}
		}

		// Token: 0x06002184 RID: 8580 RVA: 0x0001BCE9 File Offset: 0x00019EE9
		public JObject()
		{
		}

		// Token: 0x06002185 RID: 8581 RVA: 0x0001BCFC File Offset: 0x00019EFC
		public JObject(JObject other)
			: base(other)
		{
		}

		// Token: 0x06002186 RID: 8582 RVA: 0x0001BD10 File Offset: 0x00019F10
		public JObject(params object[] content)
			: this(content)
		{
		}

		// Token: 0x06002187 RID: 8583 RVA: 0x0001BD19 File Offset: 0x00019F19
		public JObject(object content)
		{
			this.Add(content);
		}

		// Token: 0x06002188 RID: 8584 RVA: 0x00088718 File Offset: 0x00086918
		internal override bool DeepEquals(JToken node)
		{
			JObject jobject = node as JObject;
			return jobject != null && this._properties.Compare(jobject._properties);
		}

		// Token: 0x06002189 RID: 8585 RVA: 0x0001BD33 File Offset: 0x00019F33
		internal override void InsertItem(int index, JToken item, bool skipParentCheck)
		{
			if (item != null && item.Type == JTokenType.Comment)
			{
				return;
			}
			base.InsertItem(index, item, skipParentCheck);
		}

		// Token: 0x0600218A RID: 8586 RVA: 0x00088744 File Offset: 0x00086944
		internal override void ValidateToken(JToken o, JToken existing)
		{
			ValidationUtils.ArgumentNotNull(o, <Module>.smethod_26<string>(620414310U));
			if (o.Type != JTokenType.Property)
			{
				throw JObject.smethod_70(<Module>.smethod_26<string>(1344040869U).FormatWith(JObject.smethod_67(), JObject.smethod_68(o), JObject.smethod_69(this)));
			}
			JProperty jproperty = (JProperty)o;
			if (existing != null)
			{
				JProperty jproperty2 = (JProperty)existing;
				if (JObject.smethod_71(jproperty.Name, jproperty2.Name))
				{
					return;
				}
			}
			if (this._properties.TryGetValue(jproperty.Name, out existing))
			{
				throw JObject.smethod_70(<Module>.smethod_25<string>(3753847372U).FormatWith(JObject.smethod_67(), jproperty.Name, JObject.smethod_69(this)));
			}
		}

		// Token: 0x0600218B RID: 8587 RVA: 0x000887F0 File Offset: 0x000869F0
		internal override void MergeItem(object content, JsonMergeSettings settings)
		{
			JObject jobject = content as JObject;
			if (jobject == null)
			{
				return;
			}
			IEnumerator<KeyValuePair<string, JToken>> enumerator = jobject.GetEnumerator();
			try
			{
				while (JObject.smethod_72(enumerator))
				{
					KeyValuePair<string, JToken> keyValuePair = enumerator.Current;
					JProperty jproperty = this.Property(keyValuePair.Key);
					if (jproperty != null)
					{
						if (keyValuePair.Value != null)
						{
							JContainer jcontainer = jproperty.Value as JContainer;
							if (jcontainer != null)
							{
								if (jcontainer.Type == keyValuePair.Value.Type)
								{
									jcontainer.Merge(keyValuePair.Value, settings);
								}
								else
								{
									jproperty.Value = keyValuePair.Value;
								}
							}
							else if (keyValuePair.Value.Type != JTokenType.Null)
							{
								jproperty.Value = keyValuePair.Value;
							}
						}
					}
					else
					{
						this.Add(keyValuePair.Key, keyValuePair.Value);
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JObject.smethod_73(enumerator);
				}
			}
		}

		// Token: 0x0600218C RID: 8588 RVA: 0x000888D8 File Offset: 0x00086AD8
		internal void InternalPropertyChanged(JProperty childProperty)
		{
			this.OnPropertyChanged(childProperty.Name);
			if (this._listChanged != null)
			{
				this.OnListChanged(JObject.smethod_74(ListChangedType.ItemChanged, base.IndexOfItem(childProperty)));
			}
			if (this._collectionChanged != null)
			{
				this.OnCollectionChanged(JObject.smethod_75(NotifyCollectionChangedAction.Replace, childProperty, childProperty, base.IndexOfItem(childProperty)));
			}
		}

		// Token: 0x0600218D RID: 8589 RVA: 0x0001BD4B File Offset: 0x00019F4B
		internal void InternalPropertyChanging(JProperty childProperty)
		{
			this.OnPropertyChanging(childProperty.Name);
		}

		// Token: 0x0600218E RID: 8590 RVA: 0x0001BD59 File Offset: 0x00019F59
		internal override JToken CloneToken()
		{
			return new JObject(this);
		}

		// Token: 0x170004F2 RID: 1266
		// (get) Token: 0x0600218F RID: 8591 RVA: 0x0000ED8C File Offset: 0x0000CF8C
		public override JTokenType Type
		{
			get
			{
				return JTokenType.Object;
			}
		}

		// Token: 0x06002190 RID: 8592 RVA: 0x0001BD61 File Offset: 0x00019F61
		public IEnumerable<JProperty> Properties()
		{
			return this._properties.Cast<JProperty>();
		}

		// Token: 0x06002191 RID: 8593 RVA: 0x0008892C File Offset: 0x00086B2C
		public JProperty Property(string name)
		{
			if (name == null)
			{
				return null;
			}
			JToken jtoken;
			this._properties.TryGetValue(name, out jtoken);
			return (JProperty)jtoken;
		}

		// Token: 0x06002192 RID: 8594 RVA: 0x0001BD6E File Offset: 0x00019F6E
		public JEnumerable<JToken> PropertyValues()
		{
			return new JEnumerable<JToken>(from p in this.Properties()
				select p.Value);
		}

		// Token: 0x170004F3 RID: 1267
		public override JToken this[object key]
		{
			get
			{
				ValidationUtils.ArgumentNotNull(key, <Module>.smethod_26<string>(620414310U));
				string text = key as string;
				if (text == null)
				{
					throw JObject.smethod_70(<Module>.smethod_27<string>(2206433858U).FormatWith(JObject.smethod_67(), MiscellaneousUtils.ToString(key)));
				}
				return this[text];
			}
			set
			{
				ValidationUtils.ArgumentNotNull(key, <Module>.smethod_26<string>(620414310U));
				string text = key as string;
				if (text == null)
				{
					throw JObject.smethod_70(<Module>.smethod_24<string>(1921563281U).FormatWith(JObject.smethod_67(), MiscellaneousUtils.ToString(key)));
				}
				this[text] = value;
			}
		}

		// Token: 0x170004F4 RID: 1268
		public JToken this[string propertyName]
		{
			get
			{
				ValidationUtils.ArgumentNotNull(propertyName, <Module>.smethod_26<string>(107105115U));
				JProperty jproperty = this.Property(propertyName);
				if (jproperty == null)
				{
					return null;
				}
				return jproperty.Value;
			}
			set
			{
				JProperty jproperty = this.Property(propertyName);
				if (jproperty != null)
				{
					jproperty.Value = value;
					return;
				}
				this.OnPropertyChanging(propertyName);
				this.Add(new JProperty(propertyName, value));
				this.OnPropertyChanged(propertyName);
			}
		}

		// Token: 0x06002197 RID: 8599 RVA: 0x00088A60 File Offset: 0x00086C60
		public new static JObject Load(JsonReader reader)
		{
			ValidationUtils.ArgumentNotNull(reader, <Module>.smethod_26<string>(3313616177U));
			if (reader.TokenType == JsonToken.None && !reader.Read())
			{
				throw JsonReaderException.Create(reader, <Module>.smethod_24<string>(40068816U));
			}
			while (reader.TokenType == JsonToken.Comment)
			{
				reader.Read();
			}
			if (reader.TokenType == JsonToken.StartObject)
			{
				JObject jobject = new JObject();
				jobject.SetLineInfo(reader as IJsonLineInfo);
				jobject.ReadTokenFrom(reader);
				return jobject;
			}
			throw JsonReaderException.Create(reader, <Module>.smethod_26<string>(37653552U).FormatWith(JObject.smethod_67(), reader.TokenType));
		}

		// Token: 0x06002198 RID: 8600 RVA: 0x00088AFC File Offset: 0x00086CFC
		public new static JObject Parse(string json)
		{
			JsonReader jsonReader = new JsonTextReader(JObject.smethod_76(json));
			JObject jobject2;
			try
			{
				JObject jobject = JObject.Load(jsonReader);
				if (jsonReader.Read() && jsonReader.TokenType != JsonToken.Comment)
				{
					throw JsonReaderException.Create(jsonReader, <Module>.smethod_27<string>(4256510540U));
				}
				jobject2 = jobject;
			}
			finally
			{
				if (jsonReader != null)
				{
					JObject.smethod_73(jsonReader);
				}
			}
			return jobject2;
		}

		// Token: 0x06002199 RID: 8601 RVA: 0x0001BD9D File Offset: 0x00019F9D
		public new static JObject FromObject(object o)
		{
			return JObject.FromObject(o, JsonSerializer.CreateDefault());
		}

		// Token: 0x0600219A RID: 8602 RVA: 0x00088B60 File Offset: 0x00086D60
		public new static JObject FromObject(object o, JsonSerializer jsonSerializer)
		{
			JToken jtoken = JToken.FromObjectInternal(o, jsonSerializer);
			if (jtoken != null && jtoken.Type != JTokenType.Object)
			{
				throw JObject.smethod_70(<Module>.smethod_25<string>(2636229537U).FormatWith(JObject.smethod_67(), jtoken.Type));
			}
			return (JObject)jtoken;
		}

		// Token: 0x0600219B RID: 8603 RVA: 0x00088BAC File Offset: 0x00086DAC
		public override void WriteTo(JsonWriter writer, params JsonConverter[] converters)
		{
			writer.WriteStartObject();
			for (int i = 0; i < this._properties.Count; i++)
			{
				this._properties[i].WriteTo(writer, converters);
			}
			writer.WriteEndObject();
		}

		// Token: 0x0600219C RID: 8604 RVA: 0x0001BDAA File Offset: 0x00019FAA
		public JToken GetValue(string propertyName)
		{
			return this.GetValue(propertyName, StringComparison.Ordinal);
		}

		// Token: 0x0600219D RID: 8605 RVA: 0x00088BF0 File Offset: 0x00086DF0
		public JToken GetValue(string propertyName, StringComparison comparison)
		{
			if (propertyName == null)
			{
				return null;
			}
			JProperty jproperty = this.Property(propertyName);
			if (jproperty != null)
			{
				return jproperty.Value;
			}
			if (comparison != StringComparison.Ordinal)
			{
				IEnumerator<JToken> enumerator = this._properties.GetEnumerator();
				try
				{
					while (JObject.smethod_72(enumerator))
					{
						JProperty jproperty2 = (JProperty)enumerator.Current;
						if (JObject.smethod_77(jproperty2.Name, propertyName, comparison))
						{
							return jproperty2.Value;
						}
					}
					goto IL_0064;
				}
				finally
				{
					if (enumerator != null)
					{
						JObject.smethod_73(enumerator);
					}
				}
				JToken jtoken;
				return jtoken;
			}
			IL_0064:
			return null;
		}

		// Token: 0x0600219E RID: 8606 RVA: 0x0001BDB4 File Offset: 0x00019FB4
		public bool TryGetValue(string propertyName, StringComparison comparison, out JToken value)
		{
			value = this.GetValue(propertyName, comparison);
			return value != null;
		}

		// Token: 0x0600219F RID: 8607 RVA: 0x0001BDC8 File Offset: 0x00019FC8
		public void Add(string propertyName, JToken value)
		{
			this.Add(new JProperty(propertyName, value));
		}

		// Token: 0x060021A0 RID: 8608 RVA: 0x0001BDD7 File Offset: 0x00019FD7
		bool IDictionary<string, JToken>.ContainsKey(string key)
		{
			return this._properties.Contains(key);
		}

		// Token: 0x170004F5 RID: 1269
		// (get) Token: 0x060021A1 RID: 8609 RVA: 0x0001BDE5 File Offset: 0x00019FE5
		ICollection<string> IDictionary<string, JToken>.Keys
		{
			get
			{
				return this._properties.Keys;
			}
		}

		// Token: 0x060021A2 RID: 8610 RVA: 0x00088C74 File Offset: 0x00086E74
		public bool Remove(string propertyName)
		{
			JProperty jproperty = this.Property(propertyName);
			if (jproperty == null)
			{
				return false;
			}
			jproperty.Remove();
			return true;
		}

		// Token: 0x060021A3 RID: 8611 RVA: 0x00088C98 File Offset: 0x00086E98
		public bool TryGetValue(string propertyName, out JToken value)
		{
			JProperty jproperty = this.Property(propertyName);
			if (jproperty == null)
			{
				value = null;
				return false;
			}
			value = jproperty.Value;
			return true;
		}

		// Token: 0x170004F6 RID: 1270
		// (get) Token: 0x060021A4 RID: 8612 RVA: 0x0001BDF2 File Offset: 0x00019FF2
		ICollection<JToken> IDictionary<string, JToken>.Values
		{
			get
			{
				throw JObject.smethod_78();
			}
		}

		// Token: 0x060021A5 RID: 8613 RVA: 0x0001BDF9 File Offset: 0x00019FF9
		void ICollection<KeyValuePair<string, JToken>>.Add(KeyValuePair<string, JToken> item)
		{
			this.Add(new JProperty(item.Key, item.Value));
		}

		// Token: 0x060021A6 RID: 8614 RVA: 0x0001BE14 File Offset: 0x0001A014
		void ICollection<KeyValuePair<string, JToken>>.Clear()
		{
			base.RemoveAll();
		}

		// Token: 0x060021A7 RID: 8615 RVA: 0x00088CC0 File Offset: 0x00086EC0
		bool ICollection<KeyValuePair<string, JToken>>.Contains(KeyValuePair<string, JToken> item)
		{
			JProperty jproperty = this.Property(item.Key);
			return jproperty != null && jproperty.Value == item.Value;
		}

		// Token: 0x060021A8 RID: 8616 RVA: 0x00088CF0 File Offset: 0x00086EF0
		void ICollection<KeyValuePair<string, JToken>>.CopyTo(KeyValuePair<string, JToken>[] array, int arrayIndex)
		{
			if (array == null)
			{
				throw JObject.smethod_79(<Module>.smethod_25<string>(4251731250U));
			}
			for (;;)
			{
				IL_0099:
				int num = ((arrayIndex < 0) ? 1436773620 : 1436773618);
				for (;;)
				{
					switch (num ^ 1436773622)
					{
					case 0:
						goto IL_00A2;
					case 1:
						if (base.Count > array.Length - arrayIndex)
						{
							goto Block_4;
						}
						goto IL_001D;
					case 2:
						goto IL_00C2;
					case 4:
						num = ((arrayIndex < array.Length) ? 1436773623 : 1436773616);
						continue;
					case 5:
						num = 1436773630;
						continue;
					case 6:
						num = ((arrayIndex == 0) ? 1436773623 : 1436773622);
						continue;
					case 7:
						goto IL_001D;
					case 8:
						goto IL_0099;
					}
					goto Block_5;
					IL_001D:
					int num2 = 0;
					num = 1436773621;
				}
			}
			Block_4:
			throw JObject.smethod_70(<Module>.smethod_25<string>(1934940511U));
			Block_5:
			goto IL_00DC;
			IL_00A2:
			throw JObject.smethod_70(<Module>.smethod_25<string>(821381263U));
			IL_00C2:
			throw JObject.smethod_80(<Module>.smethod_26<string>(4003861596U), <Module>.smethod_23<string>(1824083936U));
			IL_00DC:
			IEnumerator<JToken> enumerator = this._properties.GetEnumerator();
			try
			{
				while (JObject.smethod_72(enumerator))
				{
					JProperty jproperty = (JProperty)enumerator.Current;
					int num2;
					array[arrayIndex + num2] = new KeyValuePair<string, JToken>(jproperty.Name, jproperty.Value);
					num2++;
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JObject.smethod_73(enumerator);
				}
			}
		}

		// Token: 0x170004F7 RID: 1271
		// (get) Token: 0x060021A9 RID: 8617 RVA: 0x0000C17A File Offset: 0x0000A37A
		bool ICollection<KeyValuePair<string, JToken>>.IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x060021AA RID: 8618 RVA: 0x0001BE1C File Offset: 0x0001A01C
		bool ICollection<KeyValuePair<string, JToken>>.Remove(KeyValuePair<string, JToken> item)
		{
			if (!((ICollection<KeyValuePair<string, JToken>>)this).Contains(item))
			{
				return false;
			}
			((IDictionary<string, JToken>)this).Remove(item.Key);
			return true;
		}

		// Token: 0x060021AB RID: 8619 RVA: 0x0001BE38 File Offset: 0x0001A038
		internal override int GetDeepHashCode()
		{
			return base.ContentsHashCode();
		}

		// Token: 0x060021AC RID: 8620 RVA: 0x00088E3C File Offset: 0x0008703C
		public IEnumerator<KeyValuePair<string, JToken>> GetEnumerator()
		{
			IEnumerator<JToken> enumerator = this._properties.GetEnumerator();
			try
			{
				while (JObject.<GetEnumerator>d__2.smethod_0(enumerator))
				{
					JProperty property = (JProperty)enumerator.Current;
					yield return new KeyValuePair<string, JToken>(property.Name, property.Value);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JObject.<GetEnumerator>d__2.smethod_2(enumerator);
				}
			}
			yield break;
		}

		// Token: 0x060021AD RID: 8621 RVA: 0x0001BE40 File Offset: 0x0001A040
		protected virtual void OnPropertyChanged(string propertyName)
		{
			if (this.PropertyChanged != null)
			{
				this.PropertyChanged(this, JObject.smethod_81(propertyName));
			}
		}

		// Token: 0x060021AE RID: 8622 RVA: 0x0001BE5C File Offset: 0x0001A05C
		protected virtual void OnPropertyChanging(string propertyName)
		{
			if (this.PropertyChanging != null)
			{
				this.PropertyChanging(this, JObject.smethod_82(propertyName));
			}
		}

		// Token: 0x060021AF RID: 8623 RVA: 0x0001BE78 File Offset: 0x0001A078
		PropertyDescriptorCollection ICustomTypeDescriptor.GetProperties()
		{
			return JObject.smethod_83(this, null);
		}

		// Token: 0x060021B0 RID: 8624 RVA: 0x00088E58 File Offset: 0x00087058
		PropertyDescriptorCollection ICustomTypeDescriptor.GetProperties(Attribute[] attributes)
		{
			PropertyDescriptorCollection propertyDescriptorCollection = JObject.smethod_84(null);
			IEnumerator<KeyValuePair<string, JToken>> enumerator = this.GetEnumerator();
			try
			{
				while (JObject.smethod_72(enumerator))
				{
					KeyValuePair<string, JToken> keyValuePair = enumerator.Current;
					JObject.smethod_85(propertyDescriptorCollection, new JPropertyDescriptor(keyValuePair.Key));
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JObject.smethod_73(enumerator);
				}
			}
			return propertyDescriptorCollection;
		}

		// Token: 0x060021B1 RID: 8625 RVA: 0x0001BE81 File Offset: 0x0001A081
		AttributeCollection ICustomTypeDescriptor.GetAttributes()
		{
			return AttributeCollection.Empty;
		}

		// Token: 0x060021B2 RID: 8626 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		string ICustomTypeDescriptor.GetClassName()
		{
			return null;
		}

		// Token: 0x060021B3 RID: 8627 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		string ICustomTypeDescriptor.GetComponentName()
		{
			return null;
		}

		// Token: 0x060021B4 RID: 8628 RVA: 0x0001BE88 File Offset: 0x0001A088
		TypeConverter ICustomTypeDescriptor.GetConverter()
		{
			return JObject.smethod_86();
		}

		// Token: 0x060021B5 RID: 8629 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		EventDescriptor ICustomTypeDescriptor.GetDefaultEvent()
		{
			return null;
		}

		// Token: 0x060021B6 RID: 8630 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		PropertyDescriptor ICustomTypeDescriptor.GetDefaultProperty()
		{
			return null;
		}

		// Token: 0x060021B7 RID: 8631 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		object ICustomTypeDescriptor.GetEditor(Type editorBaseType)
		{
			return null;
		}

		// Token: 0x060021B8 RID: 8632 RVA: 0x0001BE8F File Offset: 0x0001A08F
		EventDescriptorCollection ICustomTypeDescriptor.GetEvents(Attribute[] attributes)
		{
			return EventDescriptorCollection.Empty;
		}

		// Token: 0x060021B9 RID: 8633 RVA: 0x0001BE8F File Offset: 0x0001A08F
		EventDescriptorCollection ICustomTypeDescriptor.GetEvents()
		{
			return EventDescriptorCollection.Empty;
		}

		// Token: 0x060021BA RID: 8634 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		object ICustomTypeDescriptor.GetPropertyOwner(PropertyDescriptor pd)
		{
			return null;
		}

		// Token: 0x060021BB RID: 8635 RVA: 0x0001BE96 File Offset: 0x0001A096
		protected override DynamicMetaObject GetMetaObject(Expression parameter)
		{
			return new DynamicProxyMetaObject<JObject>(parameter, this, new JObject.JObjectDynamicProxy(), true);
		}

		// Token: 0x060021BD RID: 8637 RVA: 0x0000CD19 File Offset: 0x0000AF19
		static Delegate smethod_65(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Combine(delegate_0, delegate_1);
		}

		// Token: 0x060021BE RID: 8638 RVA: 0x0000CD22 File Offset: 0x0000AF22
		static Delegate smethod_66(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Remove(delegate_0, delegate_1);
		}

		// Token: 0x060021BF RID: 8639 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_67()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060021C0 RID: 8640 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_68(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x060021C1 RID: 8641 RVA: 0x0001040D File Offset: 0x0000E60D
		static Type smethod_69(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x060021C2 RID: 8642 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_70(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x060021C3 RID: 8643 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_71(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x060021C4 RID: 8644 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_72(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060021C5 RID: 8645 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_73(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060021C6 RID: 8646 RVA: 0x0001BAB6 File Offset: 0x00019CB6
		static ListChangedEventArgs smethod_74(ListChangedType listChangedType_0, int int_0)
		{
			return new ListChangedEventArgs(listChangedType_0, int_0);
		}

		// Token: 0x060021C7 RID: 8647 RVA: 0x0001BEAD File Offset: 0x0001A0AD
		static NotifyCollectionChangedEventArgs smethod_75(NotifyCollectionChangedAction notifyCollectionChangedAction_0, IList ilist_0, IList ilist_1, int int_0)
		{
			return new NotifyCollectionChangedEventArgs(notifyCollectionChangedAction_0, ilist_0, ilist_1, int_0);
		}

		// Token: 0x060021C8 RID: 8648 RVA: 0x000161BD File Offset: 0x000143BD
		static StringReader smethod_76(string string_0)
		{
			return new StringReader(string_0);
		}

		// Token: 0x060021C9 RID: 8649 RVA: 0x000170FF File Offset: 0x000152FF
		static bool smethod_77(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string.Equals(string_0, string_1, stringComparison_0);
		}

		// Token: 0x060021CA RID: 8650 RVA: 0x000109B6 File Offset: 0x0000EBB6
		static NotImplementedException smethod_78()
		{
			return new NotImplementedException();
		}

		// Token: 0x060021CB RID: 8651 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_79(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x060021CC RID: 8652 RVA: 0x0000DECA File Offset: 0x0000C0CA
		static ArgumentOutOfRangeException smethod_80(string string_0, string string_1)
		{
			return new ArgumentOutOfRangeException(string_0, string_1);
		}

		// Token: 0x060021CD RID: 8653 RVA: 0x0000CD2B File Offset: 0x0000AF2B
		static PropertyChangedEventArgs smethod_81(string string_0)
		{
			return new PropertyChangedEventArgs(string_0);
		}

		// Token: 0x060021CE RID: 8654 RVA: 0x0001BEB8 File Offset: 0x0001A0B8
		static PropertyChangingEventArgs smethod_82(string string_0)
		{
			return new PropertyChangingEventArgs(string_0);
		}

		// Token: 0x060021CF RID: 8655 RVA: 0x0001BEC0 File Offset: 0x0001A0C0
		static PropertyDescriptorCollection smethod_83(ICustomTypeDescriptor icustomTypeDescriptor_0, Attribute[] attribute_0)
		{
			return icustomTypeDescriptor_0.GetProperties(attribute_0);
		}

		// Token: 0x060021D0 RID: 8656 RVA: 0x0001BEC9 File Offset: 0x0001A0C9
		static PropertyDescriptorCollection smethod_84(PropertyDescriptor[] propertyDescriptor_0)
		{
			return new PropertyDescriptorCollection(propertyDescriptor_0);
		}

		// Token: 0x060021D1 RID: 8657 RVA: 0x0001BED1 File Offset: 0x0001A0D1
		static int smethod_85(PropertyDescriptorCollection propertyDescriptorCollection_0, PropertyDescriptor propertyDescriptor_0)
		{
			return propertyDescriptorCollection_0.Add(propertyDescriptor_0);
		}

		// Token: 0x060021D2 RID: 8658 RVA: 0x0001BEDA File Offset: 0x0001A0DA
		static TypeConverter smethod_86()
		{
			return new TypeConverter();
		}

		// Token: 0x04000C11 RID: 3089
		private readonly JPropertyKeyedCollection _properties = new JPropertyKeyedCollection();

		// Token: 0x0200023E RID: 574
		private class JObjectDynamicProxy : DynamicProxy<JObject>
		{
			// Token: 0x060021D3 RID: 8659 RVA: 0x0001BEE1 File Offset: 0x0001A0E1
			public override bool TryGetMember(JObject instance, GetMemberBinder binder, out object result)
			{
				result = instance[JObject.JObjectDynamicProxy.smethod_0(binder)];
				return true;
			}

			// Token: 0x060021D4 RID: 8660 RVA: 0x00088EB8 File Offset: 0x000870B8
			public override bool TrySetMember(JObject instance, SetMemberBinder binder, object value)
			{
				JToken jtoken = value as JToken;
				if (jtoken == null)
				{
					jtoken = new JValue(value);
				}
				instance[JObject.JObjectDynamicProxy.smethod_1(binder)] = jtoken;
				return true;
			}

			// Token: 0x060021D5 RID: 8661 RVA: 0x0001BEF2 File Offset: 0x0001A0F2
			public override IEnumerable<string> GetDynamicMemberNames(JObject instance)
			{
				return from p in instance.Properties()
					select p.Name;
			}

			// Token: 0x060021D8 RID: 8664 RVA: 0x0001BF2C File Offset: 0x0001A12C
			static string smethod_0(GetMemberBinder getMemberBinder_0)
			{
				return getMemberBinder_0.Name;
			}

			// Token: 0x060021D9 RID: 8665 RVA: 0x0001BF34 File Offset: 0x0001A134
			static string smethod_1(SetMemberBinder setMemberBinder_0)
			{
				return setMemberBinder_0.Name;
			}
		}
	}
}
