﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x02000240 RID: 576
	public class JArray : JContainer, IEnumerable<JToken>, IList<JToken>, ICollection<JToken>, IEnumerable
	{
		// Token: 0x170004FA RID: 1274
		// (get) Token: 0x060021E4 RID: 8676 RVA: 0x0001BF83 File Offset: 0x0001A183
		protected override IList<JToken> ChildrenTokens
		{
			get
			{
				return this._values;
			}
		}

		// Token: 0x170004FB RID: 1275
		// (get) Token: 0x060021E5 RID: 8677 RVA: 0x0001BF8B File Offset: 0x0001A18B
		public override JTokenType Type
		{
			get
			{
				return JTokenType.Array;
			}
		}

		// Token: 0x060021E6 RID: 8678 RVA: 0x0001BF8E File Offset: 0x0001A18E
		public JArray()
		{
		}

		// Token: 0x060021E7 RID: 8679 RVA: 0x0001BFA1 File Offset: 0x0001A1A1
		public JArray(JArray other)
			: base(other)
		{
		}

		// Token: 0x060021E8 RID: 8680 RVA: 0x0001BFB5 File Offset: 0x0001A1B5
		public JArray(params object[] content)
			: this(content)
		{
		}

		// Token: 0x060021E9 RID: 8681 RVA: 0x0001BFBE File Offset: 0x0001A1BE
		public JArray(object content)
		{
			this.Add(content);
		}

		// Token: 0x060021EA RID: 8682 RVA: 0x00088FF0 File Offset: 0x000871F0
		internal override bool DeepEquals(JToken node)
		{
			JArray jarray = node as JArray;
			return jarray != null && base.ContentsEqual(jarray);
		}

		// Token: 0x060021EB RID: 8683 RVA: 0x0001BFD8 File Offset: 0x0001A1D8
		internal override JToken CloneToken()
		{
			return new JArray(this);
		}

		// Token: 0x060021EC RID: 8684 RVA: 0x00089010 File Offset: 0x00087210
		public new static JArray Load(JsonReader reader)
		{
			if (reader.TokenType == JsonToken.None && !reader.Read())
			{
				throw JsonReaderException.Create(reader, <Module>.smethod_24<string>(3223313801U));
			}
			while (reader.TokenType == JsonToken.Comment)
			{
				reader.Read();
			}
			if (reader.TokenType != JsonToken.StartArray)
			{
				throw JsonReaderException.Create(reader, <Module>.smethod_26<string>(828496521U).FormatWith(JArray.smethod_65(), reader.TokenType));
			}
			JArray jarray = new JArray();
			jarray.SetLineInfo(reader as IJsonLineInfo);
			jarray.ReadTokenFrom(reader);
			return jarray;
		}

		// Token: 0x060021ED RID: 8685 RVA: 0x00089098 File Offset: 0x00087298
		public new static JArray Parse(string json)
		{
			JsonReader jsonReader = new JsonTextReader(JArray.smethod_66(json));
			JArray jarray2;
			try
			{
				JArray jarray = JArray.Load(jsonReader);
				if (jsonReader.Read() && jsonReader.TokenType != JsonToken.Comment)
				{
					throw JsonReaderException.Create(jsonReader, <Module>.smethod_26<string>(15338908U));
				}
				jarray2 = jarray;
			}
			finally
			{
				if (jsonReader != null)
				{
					JArray.smethod_67(jsonReader);
				}
			}
			return jarray2;
		}

		// Token: 0x060021EE RID: 8686 RVA: 0x0001BFE0 File Offset: 0x0001A1E0
		public new static JArray FromObject(object o)
		{
			return JArray.FromObject(o, JsonSerializer.CreateDefault());
		}

		// Token: 0x060021EF RID: 8687 RVA: 0x000890FC File Offset: 0x000872FC
		public new static JArray FromObject(object o, JsonSerializer jsonSerializer)
		{
			JToken jtoken = JToken.FromObjectInternal(o, jsonSerializer);
			if (jtoken.Type == JTokenType.Array)
			{
				return (JArray)jtoken;
			}
			throw JArray.smethod_68(<Module>.smethod_25<string>(1432998046U).FormatWith(JArray.smethod_65(), jtoken.Type));
		}

		// Token: 0x060021F0 RID: 8688 RVA: 0x00089148 File Offset: 0x00087348
		public override void WriteTo(JsonWriter writer, params JsonConverter[] converters)
		{
			writer.WriteStartArray();
			for (int i = 0; i < this._values.Count; i++)
			{
				this._values[i].WriteTo(writer, converters);
			}
			writer.WriteEndArray();
		}

		// Token: 0x170004FC RID: 1276
		public override JToken this[object key]
		{
			get
			{
				ValidationUtils.ArgumentNotNull(key, <Module>.smethod_27<string>(2471166570U));
				if (!(key is int))
				{
					throw JArray.smethod_68(<Module>.smethod_24<string>(485672246U).FormatWith(JArray.smethod_65(), MiscellaneousUtils.ToString(key)));
				}
				return this.GetItem((int)key);
			}
			set
			{
				ValidationUtils.ArgumentNotNull(key, <Module>.smethod_23<string>(1582073370U));
				if (!(key is int))
				{
					throw JArray.smethod_68(<Module>.smethod_27<string>(3022987545U).FormatWith(JArray.smethod_65(), MiscellaneousUtils.ToString(key)));
				}
				this.SetItem((int)key, value);
			}
		}

		// Token: 0x170004FD RID: 1277
		public JToken this[int index]
		{
			get
			{
				return this.GetItem(index);
			}
			set
			{
				this.SetItem(index, value);
			}
		}

		// Token: 0x060021F5 RID: 8693 RVA: 0x00089234 File Offset: 0x00087434
		internal override void MergeItem(object content, JsonMergeSettings settings)
		{
			IEnumerable enumerable;
			if (base.IsMultiContent(content) || content is JArray)
			{
				enumerable = (IEnumerable)content;
				goto IL_0056;
			}
			goto IL_0028;
			int num;
			IEnumerable enumerable2;
			for (;;)
			{
				IL_0034:
				switch (num ^ -1834958968)
				{
				case 0:
					if (enumerable2 == null)
					{
						return;
					}
					goto IL_0019;
				case 1:
					goto IL_0055;
				case 2:
					goto IL_0028;
				case 3:
					goto IL_0019;
				}
				goto Block_3;
				IL_0019:
				JContainer.MergeEnumerableContent(this, enumerable2, settings);
				num = -1834958964;
			}
			return;
			Block_3:
			return;
			IL_0055:
			enumerable = null;
			goto IL_0056;
			IL_0028:
			num = -1834958967;
			goto IL_0034;
			IL_0056:
			enumerable2 = enumerable;
			num = -1834958968;
			goto IL_0034;
		}

		// Token: 0x060021F6 RID: 8694 RVA: 0x0001B9C5 File Offset: 0x00019BC5
		public int IndexOf(JToken item)
		{
			return base.IndexOfItem(item);
		}

		// Token: 0x060021F7 RID: 8695 RVA: 0x0001B9CE File Offset: 0x00019BCE
		public void Insert(int index, JToken item)
		{
			this.InsertItem(index, item, false);
		}

		// Token: 0x060021F8 RID: 8696 RVA: 0x0001B9D9 File Offset: 0x00019BD9
		public void RemoveAt(int index)
		{
			this.RemoveItemAt(index);
		}

		// Token: 0x060021F9 RID: 8697 RVA: 0x0007D404 File Offset: 0x0007B604
		public IEnumerator<JToken> GetEnumerator()
		{
			return this.Children().GetEnumerator();
		}

		// Token: 0x060021FA RID: 8698 RVA: 0x0001B9F5 File Offset: 0x00019BF5
		public void Add(JToken item)
		{
			this.Add(item);
		}

		// Token: 0x060021FB RID: 8699 RVA: 0x0001B99E File Offset: 0x00019B9E
		public void Clear()
		{
			this.ClearItems();
		}

		// Token: 0x060021FC RID: 8700 RVA: 0x0001B9FE File Offset: 0x00019BFE
		public bool Contains(JToken item)
		{
			return this.ContainsItem(item);
		}

		// Token: 0x060021FD RID: 8701 RVA: 0x0001BA07 File Offset: 0x00019C07
		public void CopyTo(JToken[] array, int arrayIndex)
		{
			this.CopyItemsTo(array, arrayIndex);
		}

		// Token: 0x170004FE RID: 1278
		// (get) Token: 0x060021FE RID: 8702 RVA: 0x0000C17A File Offset: 0x0000A37A
		public bool IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x060021FF RID: 8703 RVA: 0x0001BA11 File Offset: 0x00019C11
		public bool Remove(JToken item)
		{
			return this.RemoveItem(item);
		}

		// Token: 0x06002200 RID: 8704 RVA: 0x0001BE38 File Offset: 0x0001A038
		internal override int GetDeepHashCode()
		{
			return base.ContentsHashCode();
		}

		// Token: 0x06002201 RID: 8705 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_65()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06002202 RID: 8706 RVA: 0x000161BD File Offset: 0x000143BD
		static StringReader smethod_66(string string_0)
		{
			return new StringReader(string_0);
		}

		// Token: 0x06002203 RID: 8707 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_67(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06002204 RID: 8708 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_68(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x04000C1B RID: 3099
		private readonly List<JToken> _values = new List<JToken>();
	}
}
