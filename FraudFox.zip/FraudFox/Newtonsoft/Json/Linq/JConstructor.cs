﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x0200023B RID: 571
	public class JConstructor : JContainer
	{
		// Token: 0x170004EC RID: 1260
		// (get) Token: 0x06002160 RID: 8544 RVA: 0x0001BB95 File Offset: 0x00019D95
		protected override IList<JToken> ChildrenTokens
		{
			get
			{
				return this._values;
			}
		}

		// Token: 0x06002161 RID: 8545 RVA: 0x00088400 File Offset: 0x00086600
		internal override void MergeItem(object content, JsonMergeSettings settings)
		{
			JConstructor jconstructor = content as JConstructor;
			if (jconstructor == null)
			{
				return;
			}
			if (jconstructor.Name != null)
			{
				this.Name = jconstructor.Name;
			}
			JContainer.MergeEnumerableContent(this, jconstructor, settings);
		}

		// Token: 0x170004ED RID: 1261
		// (get) Token: 0x06002162 RID: 8546 RVA: 0x0001BB9D File Offset: 0x00019D9D
		// (set) Token: 0x06002163 RID: 8547 RVA: 0x0001BBA5 File Offset: 0x00019DA5
		public string Name
		{
			get
			{
				return this._name;
			}
			set
			{
				this._name = value;
			}
		}

		// Token: 0x170004EE RID: 1262
		// (get) Token: 0x06002164 RID: 8548 RVA: 0x00016AC8 File Offset: 0x00014CC8
		public override JTokenType Type
		{
			get
			{
				return JTokenType.Constructor;
			}
		}

		// Token: 0x06002165 RID: 8549 RVA: 0x0001BBAE File Offset: 0x00019DAE
		public JConstructor()
		{
		}

		// Token: 0x06002166 RID: 8550 RVA: 0x0001BBC1 File Offset: 0x00019DC1
		public JConstructor(JConstructor other)
			: base(other)
		{
			this._name = other.Name;
		}

		// Token: 0x06002167 RID: 8551 RVA: 0x0001BBE1 File Offset: 0x00019DE1
		public JConstructor(string name, params object[] content)
			: this(name, content)
		{
		}

		// Token: 0x06002168 RID: 8552 RVA: 0x0001BBEB File Offset: 0x00019DEB
		public JConstructor(string name, object content)
			: this(name)
		{
			this.Add(content);
		}

		// Token: 0x06002169 RID: 8553 RVA: 0x0001BBFB File Offset: 0x00019DFB
		public JConstructor(string name)
		{
			ValidationUtils.ArgumentNotNullOrEmpty(name, <Module>.smethod_26<string>(3601180475U));
			this._name = name;
		}

		// Token: 0x0600216A RID: 8554 RVA: 0x00088434 File Offset: 0x00086634
		internal override bool DeepEquals(JToken node)
		{
			JConstructor jconstructor = node as JConstructor;
			return jconstructor != null && JConstructor.smethod_65(this._name, jconstructor.Name) && base.ContentsEqual(jconstructor);
		}

		// Token: 0x0600216B RID: 8555 RVA: 0x0001BC25 File Offset: 0x00019E25
		internal override JToken CloneToken()
		{
			return new JConstructor(this);
		}

		// Token: 0x0600216C RID: 8556 RVA: 0x00088468 File Offset: 0x00086668
		public override void WriteTo(JsonWriter writer, params JsonConverter[] converters)
		{
			writer.WriteStartConstructor(this._name);
			IEnumerator<JToken> enumerator = this.Children().GetEnumerator();
			try
			{
				while (JConstructor.smethod_66(enumerator))
				{
					JToken jtoken = enumerator.Current;
					jtoken.WriteTo(writer, converters);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JConstructor.smethod_67(enumerator);
				}
			}
			writer.WriteEndConstructor();
		}

		// Token: 0x170004EF RID: 1263
		public override JToken this[object key]
		{
			get
			{
				ValidationUtils.ArgumentNotNull(key, <Module>.smethod_23<string>(1582073370U));
				if (!(key is int))
				{
					throw JConstructor.smethod_69(<Module>.smethod_25<string>(2242778196U).FormatWith(JConstructor.smethod_68(), MiscellaneousUtils.ToString(key)));
				}
				return this.GetItem((int)key);
			}
			set
			{
				ValidationUtils.ArgumentNotNull(key, <Module>.smethod_23<string>(1582073370U));
				if (!(key is int))
				{
					throw JConstructor.smethod_69(<Module>.smethod_25<string>(3913117068U).FormatWith(JConstructor.smethod_68(), MiscellaneousUtils.ToString(key)));
				}
				this.SetItem((int)key, value);
			}
		}

		// Token: 0x0600216F RID: 8559 RVA: 0x0001BC2D File Offset: 0x00019E2D
		internal override int GetDeepHashCode()
		{
			return JConstructor.smethod_70(this._name) ^ base.ContentsHashCode();
		}

		// Token: 0x06002170 RID: 8560 RVA: 0x00088574 File Offset: 0x00086774
		public new static JConstructor Load(JsonReader reader)
		{
			if (reader.TokenType == JsonToken.None && !reader.Read())
			{
				throw JsonReaderException.Create(reader, <Module>.smethod_23<string>(938072178U));
			}
			while (reader.TokenType == JsonToken.Comment)
			{
				reader.Read();
			}
			if (reader.TokenType != JsonToken.StartConstructor)
			{
				throw JsonReaderException.Create(reader, <Module>.smethod_23<string>(3182196702U).FormatWith(JConstructor.smethod_68(), reader.TokenType));
			}
			JConstructor jconstructor = new JConstructor((string)reader.Value);
			jconstructor.SetLineInfo(reader as IJsonLineInfo);
			jconstructor.ReadTokenFrom(reader);
			return jconstructor;
		}

		// Token: 0x06002171 RID: 8561 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_65(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06002172 RID: 8562 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_66(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06002173 RID: 8563 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_67(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06002174 RID: 8564 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_68()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06002175 RID: 8565 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_69(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x06002176 RID: 8566 RVA: 0x0000CF7A File Offset: 0x0000B17A
		static int smethod_70(object object_0)
		{
			return object_0.GetHashCode();
		}

		// Token: 0x04000C0D RID: 3085
		private string _name;

		// Token: 0x04000C0E RID: 3086
		private readonly List<JToken> _values = new List<JToken>();
	}
}
