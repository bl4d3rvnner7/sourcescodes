﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq.JsonPath
{
	// Token: 0x020001C7 RID: 455
	internal class ArraySliceFilter : PathFilter
	{
		// Token: 0x170003AF RID: 943
		// (get) Token: 0x060019FB RID: 6651 RVA: 0x00017D1B File Offset: 0x00015F1B
		// (set) Token: 0x060019FC RID: 6652 RVA: 0x00017D23 File Offset: 0x00015F23
		public int? Start { get; set; }

		// Token: 0x170003B0 RID: 944
		// (get) Token: 0x060019FD RID: 6653 RVA: 0x00017D2C File Offset: 0x00015F2C
		// (set) Token: 0x060019FE RID: 6654 RVA: 0x00017D34 File Offset: 0x00015F34
		public int? End { get; set; }

		// Token: 0x170003B1 RID: 945
		// (get) Token: 0x060019FF RID: 6655 RVA: 0x00017D3D File Offset: 0x00015F3D
		// (set) Token: 0x06001A00 RID: 6656 RVA: 0x00017D45 File Offset: 0x00015F45
		public int? Step { get; set; }

		// Token: 0x06001A01 RID: 6657 RVA: 0x00078504 File Offset: 0x00076704
		public override IEnumerable<JToken> ExecuteFilter(IEnumerable<JToken> current, bool errorWhenNoMatch)
		{
			if (this.Step == 0)
			{
				throw new JsonException(<Module>.smethod_25<string>(3014993299U));
			}
			IEnumerator<JToken> enumerator = current.GetEnumerator();
			JToken t;
			try
			{
				while (enumerator.MoveNext())
				{
					t = enumerator.Current;
					JArray a = t as JArray;
					if (a != null)
					{
						int stepCount = this.Step ?? 1;
						int startIndex = this.Start ?? ((stepCount > 0) ? 0 : (a.Count - 1));
						int stopIndex = this.End ?? ((stepCount > 0) ? a.Count : (-1));
						if (this.Start < 0)
						{
							startIndex = a.Count + startIndex;
						}
						if (this.End < 0)
						{
							stopIndex = a.Count + stopIndex;
						}
						startIndex = ArraySliceFilter.<ExecuteFilter>d__0.smethod_2(startIndex, (stepCount > 0) ? 0 : int.MinValue);
						startIndex = ArraySliceFilter.<ExecuteFilter>d__0.smethod_3(startIndex, (stepCount > 0) ? a.Count : (a.Count - 1));
						stopIndex = ArraySliceFilter.<ExecuteFilter>d__0.smethod_2(stopIndex, -1);
						stopIndex = ArraySliceFilter.<ExecuteFilter>d__0.smethod_3(stopIndex, a.Count);
						bool positiveStep = stepCount > 0;
						if (!this.IsValid(startIndex, stopIndex, positiveStep))
						{
							if (errorWhenNoMatch)
							{
								goto IL_0308;
							}
						}
						else
						{
							int i = startIndex;
							while (this.IsValid(i, stopIndex, positiveStep))
							{
								yield return a[i];
								i += stepCount;
							}
						}
					}
					else if (errorWhenNoMatch)
					{
						goto IL_03AA;
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					ArraySliceFilter.<ExecuteFilter>d__0.smethod_6(enumerator);
				}
			}
			yield break;
			IL_0308:
			throw new JsonException(<Module>.smethod_27<string>(1650568526U).FormatWith(ArraySliceFilter.<ExecuteFilter>d__0.smethod_4(), (this.Start != null) ? this.Start.Value.ToString(ArraySliceFilter.<ExecuteFilter>d__0.smethod_4()) : <Module>.smethod_25<string>(1166420420U), (this.End != null) ? this.End.Value.ToString(CultureInfo.InvariantCulture) : <Module>.smethod_27<string>(4272996723U)));
			IL_03AA:
			throw new JsonException(<Module>.smethod_25<string>(3919760188U).FormatWith(CultureInfo.InvariantCulture, t.GetType().Name));
		}

		// Token: 0x06001A02 RID: 6658 RVA: 0x00017D4E File Offset: 0x00015F4E
		private bool IsValid(int index, int stopIndex, bool positiveStep)
		{
			if (positiveStep)
			{
				return index < stopIndex;
			}
			return index > stopIndex;
		}
	}
}
