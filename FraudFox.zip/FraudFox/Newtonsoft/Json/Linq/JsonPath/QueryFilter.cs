﻿using System;
using System.Collections.Generic;

namespace Newtonsoft.Json.Linq.JsonPath
{
	// Token: 0x020001D2 RID: 466
	internal class QueryFilter : PathFilter
	{
		// Token: 0x170003BF RID: 959
		// (get) Token: 0x06001A74 RID: 6772 RVA: 0x00017FD8 File Offset: 0x000161D8
		// (set) Token: 0x06001A75 RID: 6773 RVA: 0x00017FE0 File Offset: 0x000161E0
		public QueryExpression Expression { get; set; }

		// Token: 0x06001A76 RID: 6774 RVA: 0x0007A688 File Offset: 0x00078888
		public override IEnumerable<JToken> ExecuteFilter(IEnumerable<JToken> current, bool errorWhenNoMatch)
		{
			goto IL_001D;
			for (;;)
			{
				JToken v;
				IEnumerator<JToken> enumerator2;
				try
				{
					IL_0092:
					IEnumerator<JToken> enumerator;
					while (QueryFilter.<ExecuteFilter>d__0.smethod_2(enumerator))
					{
						v = enumerator.Current;
						if (this.Expression.IsMatch(v))
						{
							goto IL_00B4;
						}
					}
					goto JumpOutOfTryFinally2;
					IL_001D:
					enumerator2 = current.GetEnumerator();
					goto IL_00A5;
					IL_003E:
					JToken t = enumerator2.Current;
					enumerator = ((IEnumerable<JToken>)t).GetEnumerator();
					goto IL_0092;
				}
				finally
				{
					IEnumerator<JToken> enumerator;
					if (enumerator != null)
					{
						QueryFilter.<ExecuteFilter>d__0.smethod_4(enumerator);
					}
				}
				goto JumpOutOfTryFinally2;
				Block_3:
				try
				{
					continue;
					IL_00CB:;
				}
				finally
				{
					if (enumerator2 != null)
					{
						QueryFilter.<ExecuteFilter>d__0.smethod_4(enumerator2);
					}
				}
				break;
				continue;
				IL_00A5:
				if (QueryFilter.<ExecuteFilter>d__0.smethod_2(enumerator2))
				{
					goto IL_003E;
				}
				goto IL_00CB;
				IL_00B4:
				yield return v;
				goto Block_3;
				JumpOutOfTryFinally2:
				goto IL_00A5;
			}
			yield break;
		}
	}
}
