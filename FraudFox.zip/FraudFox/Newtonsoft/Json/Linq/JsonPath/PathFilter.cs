﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq.JsonPath
{
	// Token: 0x020001C2 RID: 450
	internal abstract class PathFilter
	{
		// Token: 0x060019CC RID: 6604
		public abstract IEnumerable<JToken> ExecuteFilter(IEnumerable<JToken> current, bool errorWhenNoMatch);

		// Token: 0x060019CD RID: 6605 RVA: 0x00077F64 File Offset: 0x00076164
		protected static JToken GetTokenIndex(JToken t, bool errorWhenNoMatch, int index)
		{
			JArray jarray = t as JArray;
			JConstructor jconstructor = t as JConstructor;
			if (jarray != null)
			{
				if (jarray.Count > index)
				{
					return jarray[index];
				}
				if (errorWhenNoMatch)
				{
					throw new JsonException(<Module>.smethod_24<string>(2057229833U).FormatWith(PathFilter.smethod_0(), index));
				}
				return null;
			}
			else if (jconstructor != null)
			{
				if (jconstructor.Count > index)
				{
					return jconstructor[index];
				}
				if (errorWhenNoMatch)
				{
					throw new JsonException(<Module>.smethod_26<string>(3889780745U).FormatWith(PathFilter.smethod_0(), index));
				}
				return null;
			}
			else
			{
				if (errorWhenNoMatch)
				{
					throw new JsonException(<Module>.smethod_27<string>(2303272228U).FormatWith(PathFilter.smethod_0(), index, PathFilter.smethod_2(PathFilter.smethod_1(t))));
				}
				return null;
			}
		}

		// Token: 0x060019CF RID: 6607 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_0()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x060019D0 RID: 6608 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_1(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x060019D1 RID: 6609 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_2(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}
	}
}
