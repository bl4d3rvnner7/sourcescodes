﻿using System;
using System.Collections.Generic;

namespace Newtonsoft.Json.Linq.JsonPath
{
	// Token: 0x020001C3 RID: 451
	internal class ArrayIndexFilter : PathFilter
	{
		// Token: 0x170003A9 RID: 937
		// (get) Token: 0x060019D2 RID: 6610 RVA: 0x00017C17 File Offset: 0x00015E17
		// (set) Token: 0x060019D3 RID: 6611 RVA: 0x00017C1F File Offset: 0x00015E1F
		public int? Index { get; set; }

		// Token: 0x060019D4 RID: 6612 RVA: 0x00078028 File Offset: 0x00076228
		public override IEnumerable<JToken> ExecuteFilter(IEnumerable<JToken> current, bool errorWhenNoMatch)
		{
			ArrayIndexFilter.<ExecuteFilter>d__0 <ExecuteFilter>d__ = new ArrayIndexFilter.<ExecuteFilter>d__0(-2);
			<ExecuteFilter>d__.<>4__this = this;
			<ExecuteFilter>d__.<>3__current = current;
			<ExecuteFilter>d__.<>3__errorWhenNoMatch = errorWhenNoMatch;
			return <ExecuteFilter>d__;
		}
	}
}
