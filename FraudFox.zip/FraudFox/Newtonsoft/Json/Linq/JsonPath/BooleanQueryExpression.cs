﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Newtonsoft.Json.Linq.JsonPath
{
	// Token: 0x020001D1 RID: 465
	internal class BooleanQueryExpression : QueryExpression
	{
		// Token: 0x170003BD RID: 957
		// (get) Token: 0x06001A6B RID: 6763 RVA: 0x00017FAE File Offset: 0x000161AE
		// (set) Token: 0x06001A6C RID: 6764 RVA: 0x00017FB6 File Offset: 0x000161B6
		public List<PathFilter> Path { get; set; }

		// Token: 0x170003BE RID: 958
		// (get) Token: 0x06001A6D RID: 6765 RVA: 0x00017FBF File Offset: 0x000161BF
		// (set) Token: 0x06001A6E RID: 6766 RVA: 0x00017FC7 File Offset: 0x000161C7
		public JValue Value { get; set; }

		// Token: 0x06001A6F RID: 6767 RVA: 0x0007A554 File Offset: 0x00078754
		public override bool IsMatch(JToken t)
		{
			IEnumerable<JToken> enumerable = JPath.Evaluate(this.Path, t, false);
			IEnumerator<JToken> enumerator = enumerable.GetEnumerator();
			try
			{
				while (BooleanQueryExpression.smethod_1(enumerator))
				{
					JToken jtoken = enumerator.Current;
					JValue jvalue = jtoken as JValue;
					switch (base.Operator)
					{
					case QueryOperator.Equals:
						if (jvalue != null && jvalue.Equals(this.Value))
						{
							return true;
						}
						break;
					case QueryOperator.NotEquals:
						if (jvalue != null && !jvalue.Equals(this.Value))
						{
							return true;
						}
						break;
					case QueryOperator.Exists:
						return true;
					case QueryOperator.LessThan:
						if (jvalue != null)
						{
							if (jvalue.CompareTo(this.Value) < 0)
							{
								return true;
							}
						}
						break;
					case QueryOperator.LessThanOrEquals:
						if (jvalue != null)
						{
							if (jvalue.CompareTo(this.Value) <= 0)
							{
								return true;
							}
						}
						break;
					case QueryOperator.GreaterThan:
						if (jvalue != null && jvalue.CompareTo(this.Value) > 0)
						{
							return true;
						}
						break;
					case QueryOperator.GreaterThanOrEquals:
						if (jvalue != null && jvalue.CompareTo(this.Value) >= 0)
						{
							return true;
						}
						break;
					default:
						throw BooleanQueryExpression.smethod_0();
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					BooleanQueryExpression.smethod_2(enumerator);
				}
			}
			return false;
		}

		// Token: 0x06001A71 RID: 6769 RVA: 0x00016A1F File Offset: 0x00014C1F
		static ArgumentOutOfRangeException smethod_0()
		{
			return new ArgumentOutOfRangeException();
		}

		// Token: 0x06001A72 RID: 6770 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_1(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06001A73 RID: 6771 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_2(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}
	}
}
