﻿using System;
using System.Collections.Generic;

namespace Newtonsoft.Json.Linq.JsonPath
{
	// Token: 0x020001C5 RID: 453
	internal class ArrayMultipleIndexFilter : PathFilter
	{
		// Token: 0x170003AC RID: 940
		// (get) Token: 0x060019E8 RID: 6632 RVA: 0x00017C9E File Offset: 0x00015E9E
		// (set) Token: 0x060019E9 RID: 6633 RVA: 0x00017CA6 File Offset: 0x00015EA6
		public List<int> Indexes { get; set; }

		// Token: 0x060019EA RID: 6634 RVA: 0x000782F0 File Offset: 0x000764F0
		public override IEnumerable<JToken> ExecuteFilter(IEnumerable<JToken> current, bool errorWhenNoMatch)
		{
			goto IL_0020;
			for (;;)
			{
				JToken v;
				IEnumerator<JToken> enumerator2;
				try
				{
					IL_00A7:
					List<int>.Enumerator enumerator;
					JToken t;
					while (enumerator.MoveNext())
					{
						int i = enumerator.Current;
						v = PathFilter.GetTokenIndex(t, errorWhenNoMatch, i);
						if (v != null)
						{
							goto IL_00CC;
						}
					}
					goto JumpOutOfTryFinally2;
					IL_0020:
					enumerator2 = current.GetEnumerator();
					goto IL_00BA;
					IL_0041:
					t = enumerator2.Current;
					enumerator = this.Indexes.GetEnumerator();
					goto IL_00A7;
				}
				finally
				{
					List<int>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				goto JumpOutOfTryFinally2;
				Block_3:
				try
				{
					continue;
					IL_00E3:;
				}
				finally
				{
					if (enumerator2 != null)
					{
						ArrayMultipleIndexFilter.<ExecuteFilter>d__0.smethod_4(enumerator2);
					}
				}
				break;
				continue;
				IL_00BA:
				if (ArrayMultipleIndexFilter.<ExecuteFilter>d__0.smethod_2(enumerator2))
				{
					goto IL_0041;
				}
				goto IL_00E3;
				IL_00CC:
				yield return v;
				goto Block_3;
				JumpOutOfTryFinally2:
				goto IL_00BA;
			}
			yield break;
		}
	}
}
