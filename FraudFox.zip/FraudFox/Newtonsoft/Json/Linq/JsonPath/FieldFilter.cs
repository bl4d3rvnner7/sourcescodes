﻿using System;
using System.Collections.Generic;

namespace Newtonsoft.Json.Linq.JsonPath
{
	// Token: 0x020001C9 RID: 457
	internal class FieldFilter : PathFilter
	{
		// Token: 0x170003B4 RID: 948
		// (get) Token: 0x06001A14 RID: 6676 RVA: 0x00017DAE File Offset: 0x00015FAE
		// (set) Token: 0x06001A15 RID: 6677 RVA: 0x00017DB6 File Offset: 0x00015FB6
		public string Name { get; set; }

		// Token: 0x06001A16 RID: 6678 RVA: 0x000789DC File Offset: 0x00076BDC
		public override IEnumerable<JToken> ExecuteFilter(IEnumerable<JToken> current, bool errorWhenNoMatch)
		{
			FieldFilter.<ExecuteFilter>d__0 <ExecuteFilter>d__ = new FieldFilter.<ExecuteFilter>d__0(-2);
			<ExecuteFilter>d__.<>4__this = this;
			<ExecuteFilter>d__.<>3__current = current;
			<ExecuteFilter>d__.<>3__errorWhenNoMatch = errorWhenNoMatch;
			return <ExecuteFilter>d__;
		}
	}
}
