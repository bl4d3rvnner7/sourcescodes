﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq.JsonPath
{
	// Token: 0x020001CB RID: 459
	internal class FieldMultipleFilter : PathFilter
	{
		// Token: 0x170003B7 RID: 951
		// (get) Token: 0x06001A2A RID: 6698 RVA: 0x00017E2D File Offset: 0x0001602D
		// (set) Token: 0x06001A2B RID: 6699 RVA: 0x00017E35 File Offset: 0x00016035
		public List<string> Names { get; set; }

		// Token: 0x06001A2C RID: 6700 RVA: 0x00078CE4 File Offset: 0x00076EE4
		public override IEnumerable<JToken> ExecuteFilter(IEnumerable<JToken> current, bool errorWhenNoMatch)
		{
			goto IL_001E;
			string name;
			JToken t;
			for (;;)
			{
				JToken v;
				IEnumerator<JToken> enumerator2;
				try
				{
					List<string>.Enumerator enumerator;
					JObject o;
					while (!errorWhenNoMatch)
					{
						IL_00D6:
						if (!enumerator.MoveNext())
						{
							goto Block_8;
						}
						name = enumerator.Current;
						v = o[name];
						if (v != null)
						{
							goto IL_0189;
						}
					}
					goto IL_0169;
					Block_8:
					goto JumpOutOfTryFinally2;
					IL_001E:
					enumerator2 = current.GetEnumerator();
					goto IL_00E9;
					IL_0042:
					t = enumerator2.Current;
					o = t as JObject;
					if (o != null)
					{
						goto IL_0079;
					}
					if (!errorWhenNoMatch)
					{
						goto IL_00E9;
					}
					break;
					IL_0079:
					enumerator = this.Names.GetEnumerator();
					goto IL_00D6;
				}
				finally
				{
					List<string>.Enumerator enumerator;
					((IDisposable)enumerator).Dispose();
				}
				goto JumpOutOfTryFinally2;
				Block_4:
				try
				{
					continue;
					IL_01A0:;
				}
				finally
				{
					if (enumerator2 != null)
					{
						FieldMultipleFilter.<ExecuteFilter>d__2.smethod_8(enumerator2);
					}
				}
				goto JumpOutOfTryFinally3;
				continue;
				IL_00E9:
				if (FieldMultipleFilter.<ExecuteFilter>d__2.smethod_6(enumerator2))
				{
					goto IL_0042;
				}
				goto IL_01A0;
				IL_0189:
				yield return v;
				goto Block_4;
				JumpOutOfTryFinally2:
				goto IL_00E9;
			}
			throw new JsonException(<Module>.smethod_23<string>(624810997U).FormatWith(FieldMultipleFilter.<ExecuteFilter>d__2.smethod_2(), FieldMultipleFilter.<ExecuteFilter>d__2.smethod_3(<Module>.smethod_27<string>(290212269U), this.Names.Select((string n) => FieldMultipleFilter.smethod_3(<Module>.smethod_23<string>(1423027249U), n, <Module>.smethod_24<string>(1329633372U))).ToArray<string>()), FieldMultipleFilter.<ExecuteFilter>d__2.smethod_5(FieldMultipleFilter.<ExecuteFilter>d__2.smethod_4(t))));
			IL_0169:
			throw new JsonException(<Module>.smethod_26<string>(3060632200U).FormatWith(FieldMultipleFilter.<ExecuteFilter>d__2.smethod_2(), name));
			JumpOutOfTryFinally3:
			yield break;
		}

		// Token: 0x06001A2F RID: 6703 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_3(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}
	}
}
