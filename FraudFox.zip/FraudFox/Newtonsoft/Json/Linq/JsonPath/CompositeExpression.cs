﻿using System;
using System.Collections.Generic;

namespace Newtonsoft.Json.Linq.JsonPath
{
	// Token: 0x020001D0 RID: 464
	internal class CompositeExpression : QueryExpression
	{
		// Token: 0x170003BC RID: 956
		// (get) Token: 0x06001A66 RID: 6758 RVA: 0x00017F8A File Offset: 0x0001618A
		// (set) Token: 0x06001A67 RID: 6759 RVA: 0x00017F92 File Offset: 0x00016192
		public List<QueryExpression> Expressions { get; set; }

		// Token: 0x06001A68 RID: 6760 RVA: 0x00017F9B File Offset: 0x0001619B
		public CompositeExpression()
		{
			this.Expressions = new List<QueryExpression>();
		}

		// Token: 0x06001A69 RID: 6761 RVA: 0x0007A488 File Offset: 0x00078688
		public override bool IsMatch(JToken t)
		{
			switch (base.Operator)
			{
			case QueryOperator.And:
				foreach (QueryExpression queryExpression in this.Expressions)
				{
					if (!queryExpression.IsMatch(t))
					{
						return false;
					}
				}
				return true;
			case QueryOperator.Or:
			{
				using (List<QueryExpression>.Enumerator enumerator2 = this.Expressions.GetEnumerator())
				{
					while (enumerator2.MoveNext())
					{
						QueryExpression queryExpression2 = enumerator2.Current;
						if (queryExpression2.IsMatch(t))
						{
							return true;
						}
					}
					return false;
				}
				break;
			}
			default:
				throw CompositeExpression.smethod_0();
			}
			bool flag;
			return flag;
		}

		// Token: 0x06001A6A RID: 6762 RVA: 0x00016A1F File Offset: 0x00014C1F
		static ArgumentOutOfRangeException smethod_0()
		{
			return new ArgumentOutOfRangeException();
		}
	}
}
