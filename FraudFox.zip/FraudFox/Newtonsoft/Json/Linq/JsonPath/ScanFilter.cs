﻿using System;
using System.Collections.Generic;

namespace Newtonsoft.Json.Linq.JsonPath
{
	// Token: 0x020001D4 RID: 468
	internal class ScanFilter : PathFilter
	{
		// Token: 0x170003C2 RID: 962
		// (get) Token: 0x06001A87 RID: 6791 RVA: 0x00018057 File Offset: 0x00016257
		// (set) Token: 0x06001A88 RID: 6792 RVA: 0x0001805F File Offset: 0x0001625F
		public string Name { get; set; }

		// Token: 0x06001A89 RID: 6793 RVA: 0x0007A86C File Offset: 0x00078A6C
		public override IEnumerable<JToken> ExecuteFilter(IEnumerable<JToken> current, bool errorWhenNoMatch)
		{
			IEnumerator<JToken> enumerator = current.GetEnumerator();
			try
			{
				while (ScanFilter.<ExecuteFilter>d__0.smethod_3(enumerator))
				{
					JToken root = enumerator.Current;
					if (this.Name == null)
					{
						yield return root;
					}
					JToken value = root;
					JToken container = root;
					for (;;)
					{
						if (container != null)
						{
							if (container.HasValues)
							{
								value = container.First;
								goto IL_0151;
							}
						}
						while (value != null)
						{
							if (value == root)
							{
								break;
							}
							if (value != value.Parent.Last)
							{
								break;
							}
							value = value.Parent;
						}
						if (value == null || value == root)
						{
							break;
						}
						value = value.Next;
						IL_0151:
						JProperty e = value as JProperty;
						if (e != null)
						{
							if (ScanFilter.<ExecuteFilter>d__0.smethod_2(e.Name, this.Name))
							{
								yield return e.Value;
							}
						}
						else if (this.Name == null)
						{
							yield return value;
						}
						container = value as JContainer;
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					ScanFilter.<ExecuteFilter>d__0.smethod_5(enumerator);
				}
			}
			yield break;
		}
	}
}
