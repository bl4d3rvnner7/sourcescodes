﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq.JsonPath
{
	// Token: 0x020001CD RID: 461
	internal class JPath
	{
		// Token: 0x170003BA RID: 954
		// (get) Token: 0x06001A43 RID: 6723 RVA: 0x00017EC6 File Offset: 0x000160C6
		// (set) Token: 0x06001A44 RID: 6724 RVA: 0x00017ECE File Offset: 0x000160CE
		public List<PathFilter> Filters { get; private set; }

		// Token: 0x06001A45 RID: 6725 RVA: 0x00017ED7 File Offset: 0x000160D7
		public JPath(string expression)
		{
			ValidationUtils.ArgumentNotNull(expression, <Module>.smethod_24<string>(2836147043U));
			this._expression = expression;
			this.Filters = new List<PathFilter>();
			this.ParseMain();
		}

		// Token: 0x06001A46 RID: 6726 RVA: 0x00078FBC File Offset: 0x000771BC
		private void ParseMain()
		{
			int num = this._currentIndex;
			this.EatWhitespace();
			if (JPath.smethod_0(this._expression) != this._currentIndex)
			{
				if (JPath.smethod_1(this._expression, this._currentIndex) == '$')
				{
					if (JPath.smethod_0(this._expression) == 1)
					{
						return;
					}
					char c = JPath.smethod_1(this._expression, this._currentIndex + 1);
					if (c == '.' || c == '[')
					{
						this._currentIndex++;
						num = this._currentIndex;
					}
				}
				if (!this.ParsePath(this.Filters, num, false))
				{
					int currentIndex = this._currentIndex;
					this.EatWhitespace();
					if (this._currentIndex < JPath.smethod_0(this._expression))
					{
						throw new JsonException(JPath.smethod_2(<Module>.smethod_26<string>(2495624954U), JPath.smethod_1(this._expression, currentIndex)));
					}
				}
				return;
			}
		}

		// Token: 0x06001A47 RID: 6727 RVA: 0x0007909C File Offset: 0x0007729C
		private bool ParsePath(List<PathFilter> filters, int currentPartStartIndex, bool query)
		{
			bool flag = false;
			char c;
			bool flag3;
			for (;;)
			{
				IL_060B:
				int num = -827200277;
				for (;;)
				{
					PathFilter pathFilter;
					PathFilter pathFilter2;
					bool flag2;
					bool flag4;
					bool flag5;
					PathFilter pathFilter3;
					char c2;
					switch (num ^ -827200320)
					{
					case 0:
						goto IL_01D5;
					case 1:
					{
						ScanFilter scanFilter;
						pathFilter = scanFilter;
						goto IL_00DB;
					}
					case 2:
					{
						if (!flag)
						{
							FieldFilter fieldFilter = new FieldFilter();
							num = -827200301;
							continue;
						}
						string text;
						pathFilter2 = new ScanFilter
						{
							Name = text
						};
						goto IL_036C;
					}
					case 3:
						num = -827200282;
						continue;
					case 4:
						flag2 = false;
						num = -827200294;
						continue;
					case 5:
						if (c != '>' && c != '|')
						{
							num = ((c == '&') ? (-827200270) : (-827200308));
							continue;
						}
						goto IL_00CD;
					case 6:
						num = -827200282;
						continue;
					case 7:
					{
						string text2;
						num = (JPath.smethod_4(text2, <Module>.smethod_23<string>(3095736491U)) ? (-827200302) : (-827200269));
						continue;
					}
					case 9:
						goto IL_014E;
					case 10:
					{
						ScanFilter scanFilter2;
						string text3;
						scanFilter2.Name = text3;
						num = -827200280;
						continue;
					}
					case 11:
						flag3 = this._currentIndex == JPath.smethod_0(this._expression);
						if (this._currentIndex > currentPartStartIndex)
						{
							string text2 = JPath.smethod_5(JPath.smethod_3(this._expression, currentPartStartIndex, this._currentIndex - currentPartStartIndex), new char[0]);
							num = -827200313;
							continue;
						}
						goto IL_020D;
					case 12:
						goto IL_01CA;
					case 13:
						num = ((JPath.smethod_1(this._expression, this._currentIndex + 1) != '.') ? (-827200298) : (-827200300));
						continue;
					case 14:
						num = -827200282;
						continue;
					case 15:
						num = ((!flag4) ? (-827200290) : (-827200309));
						continue;
					case 16:
					{
						FieldFilter fieldFilter2 = new FieldFilter();
						num = -827200281;
						continue;
					}
					case 17:
					{
						string text3;
						num = ((!JPath.smethod_4(text3, <Module>.smethod_25<string>(1166420420U))) ? (-827200283) : (-827200289));
						continue;
					}
					case 18:
					{
						string text2 = null;
						num = -827200269;
						continue;
					}
					case 19:
					{
						FieldFilter fieldFilter;
						string text;
						fieldFilter.Name = text;
						num = -827200299;
						continue;
					}
					case 20:
						flag = true;
						num = -827200293;
						continue;
					case 21:
					{
						FieldFilter fieldFilter;
						pathFilter2 = fieldFilter;
						goto IL_036C;
					}
					case 22:
						this._currentIndex++;
						currentPartStartIndex = this._currentIndex;
						num = -827200285;
						continue;
					case 23:
						flag4 = true;
						num = -827200279;
						continue;
					case 24:
						num = ((!query) ? (-827200312) : (-827200287));
						continue;
					case 25:
						goto IL_0048;
					case 26:
						flag4 = false;
						num = -827200282;
						continue;
					case 27:
						this._currentIndex++;
						num = -827200298;
						continue;
					case 28:
						flag2 = true;
						num = -827200306;
						continue;
					case 29:
						goto IL_060B;
					case 30:
						c = JPath.smethod_1(this._expression, this._currentIndex);
						num = -827200274;
						continue;
					case 31:
					{
						string text3 = null;
						num = -827200283;
						continue;
					}
					case 32:
						goto IL_019B;
					case 33:
						goto IL_0615;
					case 34:
						goto IL_01E1;
					case 35:
						flag5 = false;
						num = -827200292;
						continue;
					case 36:
						goto IL_0175;
					case 37:
					{
						if (!flag)
						{
							FieldFilter fieldFilter3 = new FieldFilter();
							string text3;
							fieldFilter3.Name = text3;
							num = -827200268;
							continue;
						}
						ScanFilter scanFilter2 = new ScanFilter();
						num = -827200310;
						continue;
					}
					case 38:
						num = ((this._currentIndex >= JPath.smethod_0(this._expression)) ? (-827200309) : (-827200305));
						continue;
					case 39:
					{
						string text2;
						FieldFilter fieldFilter2;
						fieldFilter2.Name = text2;
						num = -827200271;
						continue;
					}
					case 40:
					{
						ScanFilter scanFilter2;
						pathFilter3 = scanFilter2;
						goto IL_0092;
					}
					case 41:
						num = -827200282;
						continue;
					case 42:
						flag = false;
						num = -827200273;
						continue;
					case 43:
						flag5 = false;
						num = -827200316;
						continue;
					case 44:
						flag2 = false;
						num = -827200272;
						continue;
					case 45:
						goto IL_020D;
					case 46:
						c2 = c;
						if (c2 > ')')
						{
							goto IL_0175;
						}
						if (c2 == ' ')
						{
							goto IL_014E;
						}
						switch (c2)
						{
						case '(':
							goto IL_001F;
						case ')':
							goto IL_01D5;
						default:
							num = -827200288;
							continue;
						}
						break;
					case 47:
						goto IL_00F9;
					case 48:
						num = -827200282;
						continue;
					case 49:
					{
						FieldFilter fieldFilter2;
						pathFilter = fieldFilter2;
						goto IL_00DB;
					}
					case 50:
						goto IL_00CD;
					case 51:
					{
						if (!flag)
						{
							num = -827200304;
							continue;
						}
						ScanFilter scanFilter = new ScanFilter();
						string text2;
						scanFilter.Name = text2;
						num = -827200319;
						continue;
					}
					case 52:
					{
						FieldFilter fieldFilter3;
						pathFilter3 = fieldFilter3;
						goto IL_0092;
					}
					case 53:
						goto IL_0078;
					case 54:
						goto IL_001F;
					case 55:
						num = ((!flag3) ? (-827200296) : (-827200287));
						continue;
					}
					goto Block_30;
					IL_001F:
					if (this._currentIndex > currentPartStartIndex)
					{
						string text = JPath.smethod_3(this._expression, currentPartStartIndex, this._currentIndex - currentPartStartIndex);
						num = -827200318;
						continue;
					}
					goto IL_0048;
					IL_0175:
					if (c2 == '.')
					{
						goto IL_01E1;
					}
					switch (c2)
					{
					case '[':
						goto IL_001F;
					case '\\':
						goto IL_019B;
					case ']':
						goto IL_01D5;
					default:
						num = -827200288;
						continue;
					}
					IL_0048:
					filters.Add(this.ParseIndexer(c));
					this._currentIndex++;
					currentPartStartIndex = this._currentIndex;
					flag5 = true;
					num = -827200276;
					continue;
					IL_0078:
					this._currentIndex++;
					num = -827200282;
					continue;
					IL_01CA:
					if (flag5)
					{
						goto Block_15;
					}
					goto IL_0078;
					IL_019B:
					if (!query)
					{
						goto IL_01CA;
					}
					if (c != '=' && c != '<')
					{
						num = ((c == '!') ? (-827200270) : (-827200315));
						continue;
					}
					goto IL_00CD;
					IL_0092:
					PathFilter pathFilter4 = pathFilter3;
					filters.Add(pathFilter4);
					num = -827200278;
					continue;
					IL_00CD:
					flag4 = true;
					num = -827200317;
					continue;
					IL_00DB:
					PathFilter pathFilter5 = pathFilter;
					filters.Add(pathFilter5);
					num = -827200312;
					continue;
					IL_00F9:
					num = ((this._currentIndex + 1 < JPath.smethod_0(this._expression)) ? (-827200307) : (-827200298));
					continue;
					IL_01E1:
					if (this._currentIndex > currentPartStartIndex)
					{
						string text3 = JPath.smethod_3(this._expression, currentPartStartIndex, this._currentIndex - currentPartStartIndex);
						num = -827200303;
						continue;
					}
					goto IL_00F9;
					IL_014E:
					num = ((this._currentIndex < JPath.smethod_0(this._expression)) ? (-827200297) : (-827200282));
					continue;
					IL_01D5:
					flag4 = true;
					num = -827200314;
					continue;
					IL_020D:
					num = (flag2 ? (-827200265) : (-827200312));
					continue;
					IL_036C:
					PathFilter pathFilter6 = pathFilter2;
					filters.Add(pathFilter6);
					flag = false;
					num = -827200295;
				}
			}
			Block_15:
			throw new JsonException(JPath.smethod_2(<Module>.smethod_25<string>(3273308321U), c));
			Block_30:
			return flag3;
			IL_0615:
			throw new JsonException(<Module>.smethod_26<string>(3248162347U));
		}

		// Token: 0x06001A48 RID: 6728 RVA: 0x000796EC File Offset: 0x000778EC
		private PathFilter ParseIndexer(char indexerOpenChar)
		{
			this._currentIndex++;
			char c = ((indexerOpenChar == '[') ? ']' : ')');
			this.EnsureLength(<Module>.smethod_26<string>(1838851501U));
			this.EatWhitespace();
			if (JPath.smethod_1(this._expression, this._currentIndex) == '\'')
			{
				return this.ParseQuotedField(c);
			}
			if (JPath.smethod_1(this._expression, this._currentIndex) == '?')
			{
				return this.ParseQuery(c);
			}
			return this.ParseArrayIndexer(c);
		}

		// Token: 0x06001A49 RID: 6729 RVA: 0x0007976C File Offset: 0x0007796C
		private PathFilter ParseArrayIndexer(char indexerCloseChar)
		{
			int num = this._currentIndex;
			int? num2 = null;
			List<int> list = null;
			int num3 = 0;
			int? num4 = null;
			int? num5 = null;
			int? num6 = null;
			while (this._currentIndex < JPath.smethod_0(this._expression))
			{
				char c = JPath.smethod_1(this._expression, this._currentIndex);
				if (c == ' ')
				{
					num2 = new int?(this._currentIndex);
					this.EatWhitespace();
				}
				else if (c == indexerCloseChar)
				{
					int num7 = (num2 ?? this._currentIndex) - num;
					if (list != null)
					{
						if (num7 == 0)
						{
							throw new JsonException(<Module>.smethod_25<string>(1026115035U));
						}
						string text = JPath.smethod_3(this._expression, num, num7);
						int num8 = JPath.smethod_7(text, JPath.smethod_6());
						list.Add(num8);
						return new ArrayMultipleIndexFilter
						{
							Indexes = list
						};
					}
					else
					{
						if (num3 > 0)
						{
							if (num7 > 0)
							{
								string text2 = JPath.smethod_3(this._expression, num, num7);
								int num9 = JPath.smethod_7(text2, JPath.smethod_6());
								if (num3 == 1)
								{
									num5 = new int?(num9);
								}
								else
								{
									num6 = new int?(num9);
								}
							}
							return new ArraySliceFilter
							{
								Start = num4,
								End = num5,
								Step = num6
							};
						}
						if (num7 == 0)
						{
							throw new JsonException(<Module>.smethod_23<string>(1497149132U));
						}
						string text3 = JPath.smethod_3(this._expression, num, num7);
						int num10 = JPath.smethod_7(text3, JPath.smethod_6());
						return new ArrayIndexFilter
						{
							Index = new int?(num10)
						};
					}
				}
				else if (c == ',')
				{
					int num11 = (num2 ?? this._currentIndex) - num;
					if (num11 == 0)
					{
						throw new JsonException(<Module>.smethod_23<string>(1497149132U));
					}
					if (list == null)
					{
						list = new List<int>();
					}
					string text4 = JPath.smethod_3(this._expression, num, num11);
					list.Add(JPath.smethod_7(text4, JPath.smethod_6()));
					this._currentIndex++;
					this.EatWhitespace();
					num = this._currentIndex;
					num2 = null;
				}
				else if (c == '*')
				{
					this._currentIndex++;
					this.EnsureLength(<Module>.smethod_26<string>(1838851501U));
					this.EatWhitespace();
					if (JPath.smethod_1(this._expression, this._currentIndex) != indexerCloseChar)
					{
						throw new JsonException(JPath.smethod_2(<Module>.smethod_24<string>(4163303598U), c));
					}
					return new ArrayIndexFilter();
				}
				else if (c == ':')
				{
					int num12 = (num2 ?? this._currentIndex) - num;
					if (num12 > 0)
					{
						string text5 = JPath.smethod_3(this._expression, num, num12);
						int num13 = JPath.smethod_7(text5, JPath.smethod_6());
						if (num3 == 0)
						{
							num4 = new int?(num13);
						}
						else if (num3 == 1)
						{
							num5 = new int?(num13);
						}
						else
						{
							num6 = new int?(num13);
						}
					}
					num3++;
					this._currentIndex++;
					this.EatWhitespace();
					num = this._currentIndex;
					num2 = null;
				}
				else
				{
					if (!char.IsDigit(c) && c != '-')
					{
						throw new JsonException(JPath.smethod_2(<Module>.smethod_24<string>(4163303598U), c));
					}
					if (num2 != null)
					{
						throw new JsonException(JPath.smethod_2(<Module>.smethod_26<string>(228436381U), c));
					}
					this._currentIndex++;
				}
			}
			throw new JsonException(<Module>.smethod_24<string>(2077045982U));
		}

		// Token: 0x06001A4A RID: 6730 RVA: 0x00017F07 File Offset: 0x00016107
		private void EatWhitespace()
		{
			while (this._currentIndex < JPath.smethod_0(this._expression))
			{
				if (JPath.smethod_1(this._expression, this._currentIndex) != ' ')
				{
					return;
				}
				this._currentIndex++;
			}
		}

		// Token: 0x06001A4B RID: 6731 RVA: 0x00079B20 File Offset: 0x00077D20
		private PathFilter ParseQuery(char indexerCloseChar)
		{
			this._currentIndex++;
			QueryFilter queryFilter;
			for (;;)
			{
				IL_0124:
				int num = -1161172355;
				for (;;)
				{
					switch (num ^ -1161172360)
					{
					case 0:
						if (JPath.smethod_1(this._expression, this._currentIndex) != indexerCloseChar)
						{
							goto Block_2;
						}
						goto IL_0086;
					case 1:
					{
						QueryExpression queryExpression = this.ParseExpression();
						num = -1161172356;
						continue;
					}
					case 2:
						goto IL_0156;
					case 3:
						goto IL_0124;
					case 4:
						this._currentIndex++;
						num = -1161172367;
						continue;
					case 5:
						this.EnsureLength(<Module>.smethod_24<string>(2077045982U));
						num = -1161172368;
						continue;
					case 6:
						goto IL_0086;
					case 7:
					{
						QueryExpression queryExpression;
						queryFilter.Expression = queryExpression;
						num = -1161172364;
						continue;
					}
					case 8:
						num = ((JPath.smethod_1(this._expression, this._currentIndex) == '(') ? (-1161172366) : (-1161172358));
						continue;
					case 9:
						this.EnsureLength(<Module>.smethod_25<string>(857472256U));
						num = -1161172365;
						continue;
					case 10:
						this._currentIndex++;
						num = -1161172359;
						continue;
					case 11:
						this.EatWhitespace();
						num = -1161172360;
						continue;
					}
					goto Block_3;
					IL_0086:
					queryFilter = new QueryFilter();
					num = -1161172353;
				}
			}
			Block_2:
			throw new JsonException(JPath.smethod_2(<Module>.smethod_26<string>(228436381U), JPath.smethod_1(this._expression, this._currentIndex)));
			Block_3:
			return queryFilter;
			IL_0156:
			throw new JsonException(JPath.smethod_2(<Module>.smethod_27<string>(3929259943U), JPath.smethod_1(this._expression, this._currentIndex)));
		}

		// Token: 0x06001A4C RID: 6732 RVA: 0x00079CB0 File Offset: 0x00077EB0
		private QueryExpression ParseExpression()
		{
			QueryExpression queryExpression = null;
			CompositeExpression compositeExpression = null;
			while (this._currentIndex < JPath.smethod_0(this._expression))
			{
				this.EatWhitespace();
				if (JPath.smethod_1(this._expression, this._currentIndex) != '@')
				{
					throw new JsonException(JPath.smethod_2(<Module>.smethod_27<string>(3649529785U), JPath.smethod_1(this._expression, this._currentIndex)));
				}
				this._currentIndex++;
				List<PathFilter> list = new List<PathFilter>();
				if (!this.ParsePath(list, this._currentIndex, true))
				{
					this.EatWhitespace();
					this.EnsureLength(<Module>.smethod_24<string>(382533235U));
					object obj = null;
					if (JPath.smethod_1(this._expression, this._currentIndex) == ')')
					{
						goto IL_00E4;
					}
					if (JPath.smethod_1(this._expression, this._currentIndex) == '|' || JPath.smethod_1(this._expression, this._currentIndex) == '&')
					{
						goto IL_00E4;
					}
					QueryOperator queryOperator = this.ParseOperator();
					this.EatWhitespace();
					this.EnsureLength(<Module>.smethod_27<string>(2763717618U));
					obj = this.ParseValue();
					this.EatWhitespace();
					this.EnsureLength(<Module>.smethod_23<string>(1846084386U));
					IL_00E7:
					BooleanQueryExpression booleanQueryExpression = new BooleanQueryExpression
					{
						Path = list,
						Operator = queryOperator,
						Value = ((queryOperator != QueryOperator.Exists) ? new JValue(obj) : null)
					};
					if (JPath.smethod_1(this._expression, this._currentIndex) == ')')
					{
						if (compositeExpression != null)
						{
							compositeExpression.Expressions.Add(booleanQueryExpression);
							return queryExpression;
						}
						return booleanQueryExpression;
					}
					else
					{
						if (JPath.smethod_1(this._expression, this._currentIndex) == '&' && this.Match(<Module>.smethod_26<string>(3857053830U)))
						{
							if (compositeExpression == null || compositeExpression.Operator != QueryOperator.And)
							{
								CompositeExpression compositeExpression2 = new CompositeExpression
								{
									Operator = QueryOperator.And
								};
								if (compositeExpression != null)
								{
									compositeExpression.Expressions.Add(compositeExpression2);
								}
								compositeExpression = compositeExpression2;
								if (queryExpression == null)
								{
									queryExpression = compositeExpression;
								}
							}
							compositeExpression.Expressions.Add(booleanQueryExpression);
						}
						if (JPath.smethod_1(this._expression, this._currentIndex) == '|' && this.Match(<Module>.smethod_23<string>(2968146648U)))
						{
							if (compositeExpression == null || compositeExpression.Operator != QueryOperator.Or)
							{
								CompositeExpression compositeExpression3 = new CompositeExpression
								{
									Operator = QueryOperator.Or
								};
								if (compositeExpression != null)
								{
									compositeExpression.Expressions.Add(compositeExpression3);
								}
								compositeExpression = compositeExpression3;
								if (queryExpression == null)
								{
									queryExpression = compositeExpression;
								}
							}
							compositeExpression.Expressions.Add(booleanQueryExpression);
							continue;
						}
						continue;
					}
					IL_00E4:
					queryOperator = QueryOperator.Exists;
					goto IL_00E7;
				}
				throw new JsonException(<Module>.smethod_23<string>(1846084386U));
			}
			throw new JsonException(<Module>.smethod_25<string>(3114038625U));
		}

		// Token: 0x06001A4D RID: 6733 RVA: 0x00079F40 File Offset: 0x00078140
		private object ParseValue()
		{
			char c = JPath.smethod_1(this._expression, this._currentIndex);
			if (c == '\'')
			{
				return this.ReadQuotedString();
			}
			if (!char.IsDigit(c))
			{
				if (c != '-')
				{
					if (c == 't')
					{
						if (this.Match(<Module>.smethod_23<string>(4283490662U)))
						{
							return true;
						}
						goto IL_0160;
					}
					else if (c == 'f')
					{
						if (this.Match(<Module>.smethod_25<string>(628605107U)))
						{
							return false;
						}
						goto IL_0160;
					}
					else
					{
						if (c == 'n' && this.Match(<Module>.smethod_25<string>(2731143561U)))
						{
							return null;
						}
						goto IL_0160;
					}
				}
			}
			StringBuilder stringBuilder = JPath.smethod_8();
			JPath.smethod_9(stringBuilder, c);
			this._currentIndex++;
			while (this._currentIndex < JPath.smethod_0(this._expression))
			{
				c = JPath.smethod_1(this._expression, this._currentIndex);
				if (c != ' ' && c != ')')
				{
					JPath.smethod_9(stringBuilder, c);
					this._currentIndex++;
				}
				else
				{
					string text = JPath.smethod_10(stringBuilder);
					string text2 = text;
					char[] array = new char[3];
					JPath.smethod_11(array, fieldof(<PrivateImplementationDetails>{2050F94B-4B51-45A2-913D-663F8B3DB301}.$$method0x60001f0-1).FieldHandle);
					if (JPath.smethod_12(text2, array) == -1)
					{
						long num;
						if (long.TryParse(text, NumberStyles.Integer, JPath.smethod_6(), out num))
						{
							return num;
						}
						throw new JsonException(<Module>.smethod_27<string>(2577230846U));
					}
					else
					{
						double num2;
						if (!double.TryParse(text, NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite | NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands | NumberStyles.AllowExponent, JPath.smethod_6(), out num2))
						{
							throw new JsonException(<Module>.smethod_25<string>(3392428437U));
						}
						return num2;
					}
				}
			}
			IL_0160:
			throw new JsonException(<Module>.smethod_23<string>(4090208910U));
		}

		// Token: 0x06001A4E RID: 6734 RVA: 0x0007A0C4 File Offset: 0x000782C4
		private string ReadQuotedString()
		{
			StringBuilder stringBuilder = JPath.smethod_8();
			this._currentIndex++;
			while (this._currentIndex < JPath.smethod_0(this._expression))
			{
				char c = JPath.smethod_1(this._expression, this._currentIndex);
				if (c == '\\' && this._currentIndex + 1 < JPath.smethod_0(this._expression))
				{
					this._currentIndex++;
					if (JPath.smethod_1(this._expression, this._currentIndex) == '\'')
					{
						JPath.smethod_9(stringBuilder, '\'');
					}
					else
					{
						if (JPath.smethod_1(this._expression, this._currentIndex) != '\\')
						{
							throw new JsonException(JPath.smethod_2(<Module>.smethod_27<string>(1877905451U), JPath.smethod_1(this._expression, this._currentIndex)));
						}
						JPath.smethod_9(stringBuilder, '\\');
					}
					this._currentIndex++;
				}
				else
				{
					if (c == '\'')
					{
						this._currentIndex++;
						return JPath.smethod_10(stringBuilder);
					}
					this._currentIndex++;
					JPath.smethod_9(stringBuilder, c);
				}
			}
			throw new JsonException(<Module>.smethod_27<string>(3177541315U));
		}

		// Token: 0x06001A4F RID: 6735 RVA: 0x0007A1F8 File Offset: 0x000783F8
		private bool Match(string s)
		{
			int num = this._currentIndex;
			for (int i = 0; i < JPath.smethod_0(s); i++)
			{
				char c = JPath.smethod_1(s, i);
				if (num >= JPath.smethod_0(this._expression) || JPath.smethod_1(this._expression, num) != c)
				{
					return false;
				}
				num++;
			}
			this._currentIndex = num;
			return true;
		}

		// Token: 0x06001A50 RID: 6736 RVA: 0x0007A25C File Offset: 0x0007845C
		private QueryOperator ParseOperator()
		{
			if (this._currentIndex + 1 >= JPath.smethod_0(this._expression))
			{
				throw new JsonException(<Module>.smethod_23<string>(1846084386U));
			}
			if (this.Match(<Module>.smethod_24<string>(1655831229U)))
			{
				return QueryOperator.Equals;
			}
			if (this.Match(<Module>.smethod_27<string>(2757946078U)) || this.Match(<Module>.smethod_27<string>(2291729148U)))
			{
				return QueryOperator.NotEquals;
			}
			if (this.Match(<Module>.smethod_27<string>(2198485762U)))
			{
				return QueryOperator.LessThanOrEquals;
			}
			if (this.Match(<Module>.smethod_25<string>(3947661292U)))
			{
				return QueryOperator.LessThan;
			}
			if (this.Match(<Module>.smethod_26<string>(4134769256U)))
			{
				return QueryOperator.GreaterThanOrEquals;
			}
			if (this.Match(<Module>.smethod_24<string>(1595879686U)))
			{
				return QueryOperator.GreaterThan;
			}
			throw new JsonException(<Module>.smethod_27<string>(2384972534U));
		}

		// Token: 0x06001A51 RID: 6737 RVA: 0x0007A328 File Offset: 0x00078528
		private PathFilter ParseQuotedField(char indexerCloseChar)
		{
			List<string> list = null;
			while (this._currentIndex < JPath.smethod_0(this._expression))
			{
				string text = this.ReadQuotedString();
				this.EatWhitespace();
				this.EnsureLength(<Module>.smethod_24<string>(2077045982U));
				if (JPath.smethod_1(this._expression, this._currentIndex) == indexerCloseChar)
				{
					if (list != null)
					{
						list.Add(text);
						return new FieldMultipleFilter
						{
							Names = list
						};
					}
					return new FieldFilter
					{
						Name = text
					};
				}
				else
				{
					if (JPath.smethod_1(this._expression, this._currentIndex) != ',')
					{
						throw new JsonException(JPath.smethod_2(<Module>.smethod_26<string>(228436381U), JPath.smethod_1(this._expression, this._currentIndex)));
					}
					this._currentIndex++;
					this.EatWhitespace();
					if (list == null)
					{
						list = new List<string>();
					}
					list.Add(text);
				}
			}
			throw new JsonException(<Module>.smethod_23<string>(3411152527U));
		}

		// Token: 0x06001A52 RID: 6738 RVA: 0x00017F45 File Offset: 0x00016145
		private void EnsureLength(string message)
		{
			if (this._currentIndex >= JPath.smethod_0(this._expression))
			{
				throw new JsonException(message);
			}
		}

		// Token: 0x06001A53 RID: 6739 RVA: 0x00017F61 File Offset: 0x00016161
		internal IEnumerable<JToken> Evaluate(JToken t, bool errorWhenNoMatch)
		{
			return JPath.Evaluate(this.Filters, t, errorWhenNoMatch);
		}

		// Token: 0x06001A54 RID: 6740 RVA: 0x0007A424 File Offset: 0x00078624
		internal static IEnumerable<JToken> Evaluate(List<PathFilter> filters, JToken t, bool errorWhenNoMatch)
		{
			IEnumerable<JToken> enumerable = new JToken[] { t };
			foreach (PathFilter pathFilter in filters)
			{
				enumerable = pathFilter.ExecuteFilter(enumerable, errorWhenNoMatch);
			}
			return enumerable;
		}

		// Token: 0x06001A55 RID: 6741 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_0(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06001A56 RID: 6742 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_1(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x06001A57 RID: 6743 RVA: 0x0000EE96 File Offset: 0x0000D096
		static string smethod_2(object object_0, object object_1)
		{
			return object_0 + object_1;
		}

		// Token: 0x06001A58 RID: 6744 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_3(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x06001A59 RID: 6745 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_4(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06001A5A RID: 6746 RVA: 0x000161D8 File Offset: 0x000143D8
		static string smethod_5(string string_0, char[] char_0)
		{
			return string_0.TrimEnd(char_0);
		}

		// Token: 0x06001A5B RID: 6747 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_6()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001A5C RID: 6748 RVA: 0x00017F70 File Offset: 0x00016170
		static int smethod_7(string string_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToInt32(string_0, iformatProvider_0);
		}

		// Token: 0x06001A5D RID: 6749 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_8()
		{
			return new StringBuilder();
		}

		// Token: 0x06001A5E RID: 6750 RVA: 0x0001008C File Offset: 0x0000E28C
		static StringBuilder smethod_9(StringBuilder stringBuilder_0, char char_0)
		{
			return stringBuilder_0.Append(char_0);
		}

		// Token: 0x06001A5F RID: 6751 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_10(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06001A60 RID: 6752 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_11(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x06001A61 RID: 6753 RVA: 0x00017A95 File Offset: 0x00015C95
		static int smethod_12(string string_0, char[] char_0)
		{
			return string_0.IndexOfAny(char_0);
		}

		// Token: 0x04000A3A RID: 2618
		private readonly string _expression;

		// Token: 0x04000A3B RID: 2619
		private int _currentIndex;
	}
}
