﻿using System;

namespace Newtonsoft.Json.Linq.JsonPath
{
	// Token: 0x020001CF RID: 463
	internal abstract class QueryExpression
	{
		// Token: 0x170003BB RID: 955
		// (get) Token: 0x06001A62 RID: 6754 RVA: 0x00017F79 File Offset: 0x00016179
		// (set) Token: 0x06001A63 RID: 6755 RVA: 0x00017F81 File Offset: 0x00016181
		public QueryOperator Operator { get; set; }

		// Token: 0x06001A64 RID: 6756
		public abstract bool IsMatch(JToken t);
	}
}
