﻿using System;

namespace Newtonsoft.Json.Linq.JsonPath
{
	// Token: 0x020001CE RID: 462
	internal enum QueryOperator
	{
		// Token: 0x04000A3E RID: 2622
		None,
		// Token: 0x04000A3F RID: 2623
		Equals,
		// Token: 0x04000A40 RID: 2624
		NotEquals,
		// Token: 0x04000A41 RID: 2625
		Exists,
		// Token: 0x04000A42 RID: 2626
		LessThan,
		// Token: 0x04000A43 RID: 2627
		LessThanOrEquals,
		// Token: 0x04000A44 RID: 2628
		GreaterThan,
		// Token: 0x04000A45 RID: 2629
		GreaterThanOrEquals,
		// Token: 0x04000A46 RID: 2630
		And,
		// Token: 0x04000A47 RID: 2631
		Or
	}
}
