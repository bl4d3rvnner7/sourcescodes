﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.Linq.Expressions;
using System.Numerics;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x020001F2 RID: 498
	public class JValue : JToken, IEquatable<JValue>, IComparable<JValue>, IFormattable, IComparable, IConvertible
	{
		// Token: 0x06001C5A RID: 7258 RVA: 0x00018FCB File Offset: 0x000171CB
		internal JValue(object value, JTokenType type)
		{
			this._value = value;
			this._valueType = type;
		}

		// Token: 0x06001C5B RID: 7259 RVA: 0x00018FE1 File Offset: 0x000171E1
		public JValue(JValue other)
			: this(other.Value, other.Type)
		{
		}

		// Token: 0x06001C5C RID: 7260 RVA: 0x00018FF5 File Offset: 0x000171F5
		public JValue(long value)
			: this(value, JTokenType.Integer)
		{
		}

		// Token: 0x06001C5D RID: 7261 RVA: 0x00019004 File Offset: 0x00017204
		public JValue(decimal value)
			: this(value, JTokenType.Float)
		{
		}

		// Token: 0x06001C5E RID: 7262 RVA: 0x00019013 File Offset: 0x00017213
		public JValue(char value)
			: this(value, JTokenType.String)
		{
		}

		// Token: 0x06001C5F RID: 7263 RVA: 0x00019022 File Offset: 0x00017222
		[CLSCompliant(false)]
		public JValue(ulong value)
			: this(value, JTokenType.Integer)
		{
		}

		// Token: 0x06001C60 RID: 7264 RVA: 0x00019031 File Offset: 0x00017231
		public JValue(double value)
			: this(value, JTokenType.Float)
		{
		}

		// Token: 0x06001C61 RID: 7265 RVA: 0x00019040 File Offset: 0x00017240
		public JValue(float value)
			: this(value, JTokenType.Float)
		{
		}

		// Token: 0x06001C62 RID: 7266 RVA: 0x0001904F File Offset: 0x0001724F
		public JValue(DateTime value)
			: this(value, JTokenType.Date)
		{
		}

		// Token: 0x06001C63 RID: 7267 RVA: 0x0001905F File Offset: 0x0001725F
		public JValue(DateTimeOffset value)
			: this(value, JTokenType.Date)
		{
		}

		// Token: 0x06001C64 RID: 7268 RVA: 0x0001906F File Offset: 0x0001726F
		public JValue(bool value)
			: this(value, JTokenType.Boolean)
		{
		}

		// Token: 0x06001C65 RID: 7269 RVA: 0x0001907F File Offset: 0x0001727F
		public JValue(string value)
			: this(value, JTokenType.String)
		{
		}

		// Token: 0x06001C66 RID: 7270 RVA: 0x00019089 File Offset: 0x00017289
		public JValue(Guid value)
			: this(value, JTokenType.Guid)
		{
		}

		// Token: 0x06001C67 RID: 7271 RVA: 0x00019099 File Offset: 0x00017299
		public JValue(Uri value)
			: this(value, JValue.smethod_36(value, null) ? JTokenType.Uri : JTokenType.Null)
		{
		}

		// Token: 0x06001C68 RID: 7272 RVA: 0x000190B1 File Offset: 0x000172B1
		public JValue(TimeSpan value)
			: this(value, JTokenType.TimeSpan)
		{
		}

		// Token: 0x06001C69 RID: 7273 RVA: 0x0007E41C File Offset: 0x0007C61C
		public JValue(object value)
			: this(value, JValue.GetValueType(null, value))
		{
		}

		// Token: 0x06001C6A RID: 7274 RVA: 0x0007E440 File Offset: 0x0007C640
		internal override bool DeepEquals(JToken node)
		{
			JValue jvalue = node as JValue;
			return jvalue != null && (jvalue == this || JValue.ValuesEquals(this, jvalue));
		}

		// Token: 0x17000402 RID: 1026
		// (get) Token: 0x06001C6B RID: 7275 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool HasValues
		{
			get
			{
				return false;
			}
		}

		// Token: 0x06001C6C RID: 7276 RVA: 0x0007E468 File Offset: 0x0007C668
		private static int CompareBigInteger(BigInteger i1, object i2)
		{
			int num = i1.CompareTo(ConvertUtils.ToBigInteger(i2));
			if (num != 0)
			{
				return num;
			}
			if (i2 is decimal)
			{
				decimal num2 = (decimal)i2;
				return 0m.CompareTo(Math.Abs(num2 - Math.Truncate(num2)));
			}
			if (!(i2 is double) && !(i2 is float))
			{
				return num;
			}
			double num3 = Convert.ToDouble(i2, CultureInfo.InvariantCulture);
			return 0.0.CompareTo(Math.Abs(num3 - Math.Truncate(num3)));
		}

		// Token: 0x06001C6D RID: 7277 RVA: 0x0007E4F4 File Offset: 0x0007C6F4
		internal static int Compare(JTokenType valueType, object objA, object objB)
		{
			if (objA == null && objB == null)
			{
				return 0;
			}
			if (objA != null && objB == null)
			{
				return 1;
			}
			if (objA == null && objB != null)
			{
				return -1;
			}
			switch (valueType)
			{
			case JTokenType.Comment:
			case JTokenType.String:
			case JTokenType.Raw:
			{
				string text = Convert.ToString(objA, CultureInfo.InvariantCulture);
				string text2 = Convert.ToString(objB, CultureInfo.InvariantCulture);
				return string.CompareOrdinal(text, text2);
			}
			case JTokenType.Integer:
				if (objA is BigInteger)
				{
					return JValue.CompareBigInteger((BigInteger)objA, objB);
				}
				if (objB is BigInteger)
				{
					return -JValue.CompareBigInteger((BigInteger)objB, objA);
				}
				if (objA is ulong || objB is ulong || objA is decimal || objB is decimal)
				{
					return JValue.smethod_38(objA, JValue.smethod_37()).CompareTo(JValue.smethod_38(objB, JValue.smethod_37()));
				}
				if (!(objA is float) && !(objB is float) && !(objA is double) && !(objB is double))
				{
					return Convert.ToInt64(objA, CultureInfo.InvariantCulture).CompareTo(Convert.ToInt64(objB, CultureInfo.InvariantCulture));
				}
				return JValue.CompareFloat(objA, objB);
			case JTokenType.Float:
				if (objA is BigInteger)
				{
					return JValue.CompareBigInteger((BigInteger)objA, objB);
				}
				if (objB is BigInteger)
				{
					return -JValue.CompareBigInteger((BigInteger)objB, objA);
				}
				return JValue.CompareFloat(objA, objB);
			case JTokenType.Boolean:
			{
				bool flag = Convert.ToBoolean(objA, CultureInfo.InvariantCulture);
				bool flag2 = Convert.ToBoolean(objB, CultureInfo.InvariantCulture);
				return flag.CompareTo(flag2);
			}
			case JTokenType.Date:
			{
				if (objA is DateTime)
				{
					DateTime dateTime = (DateTime)objA;
					DateTime dateTime2;
					if (objB is DateTimeOffset)
					{
						dateTime2 = ((DateTimeOffset)objB).DateTime;
					}
					else
					{
						dateTime2 = Convert.ToDateTime(objB, CultureInfo.InvariantCulture);
					}
					return dateTime.CompareTo(dateTime2);
				}
				DateTimeOffset dateTimeOffset = (DateTimeOffset)objA;
				DateTimeOffset dateTimeOffset2;
				if (!(objB is DateTimeOffset))
				{
					dateTimeOffset2 = new DateTimeOffset(Convert.ToDateTime(objB, CultureInfo.InvariantCulture));
				}
				else
				{
					dateTimeOffset2 = (DateTimeOffset)objB;
				}
				return dateTimeOffset.CompareTo(dateTimeOffset2);
			}
			case JTokenType.Bytes:
			{
				if (!(objB is byte[]))
				{
					throw new ArgumentException(<Module>.smethod_26<string>(3634379963U));
				}
				byte[] array = objA as byte[];
				byte[] array2 = objB as byte[];
				if (array == null)
				{
					return -1;
				}
				if (array2 == null)
				{
					return 1;
				}
				return MiscellaneousUtils.ByteArrayCompare(array, array2);
			}
			case JTokenType.Guid:
				if (objB is Guid)
				{
					Guid guid = (Guid)objA;
					Guid guid2 = (Guid)objB;
					return guid.CompareTo(guid2);
				}
				throw new ArgumentException(<Module>.smethod_24<string>(670624831U));
			case JTokenType.Uri:
				if (objB is Uri)
				{
					Uri uri = (Uri)objA;
					Uri uri2 = (Uri)objB;
					return Comparer<string>.Default.Compare(uri.ToString(), uri2.ToString());
				}
				throw new ArgumentException(<Module>.smethod_24<string>(3922463319U));
			case JTokenType.TimeSpan:
			{
				if (!(objB is TimeSpan))
				{
					throw new ArgumentException(<Module>.smethod_26<string>(2958453722U));
				}
				TimeSpan timeSpan = (TimeSpan)objA;
				TimeSpan timeSpan2 = (TimeSpan)objB;
				return timeSpan.CompareTo(timeSpan2);
			}
			}
			throw MiscellaneousUtils.CreateArgumentOutOfRangeException(<Module>.smethod_23<string>(2573050023U), valueType, <Module>.smethod_26<string>(633806785U).FormatWith(CultureInfo.InvariantCulture, valueType));
		}

		// Token: 0x06001C6E RID: 7278 RVA: 0x0007E810 File Offset: 0x0007CA10
		private static int CompareFloat(object objA, object objB)
		{
			double num = JValue.smethod_39(objA, JValue.smethod_37());
			double num2 = JValue.smethod_39(objB, JValue.smethod_37());
			if (MathUtils.ApproxEquals(num, num2))
			{
				return 0;
			}
			return num.CompareTo(num2);
		}

		// Token: 0x06001C6F RID: 7279 RVA: 0x0007E848 File Offset: 0x0007CA48
		private static bool Operation(ExpressionType operation, object objA, object objB, out object result)
		{
			if (objA is string || objB is string)
			{
				if (operation != ExpressionType.Add)
				{
					if (operation != ExpressionType.AddAssign)
					{
						goto IL_0020;
					}
				}
				result = JValue.smethod_41((objA != null) ? JValue.smethod_40(objA) : null, (objB != null) ? JValue.smethod_40(objB) : null);
				return true;
			}
			IL_0020:
			if (!(objA is BigInteger) && !(objB is BigInteger))
			{
				if (!(objA is ulong) && !(objB is ulong) && !(objA is decimal) && !(objB is decimal))
				{
					if (!(objA is float) && !(objB is float) && !(objA is double) && !(objB is double))
					{
						if (objA is int || objA is uint || objA is long || objA is short || objA is ushort || objA is sbyte || objA is byte || objB is int || objB is uint || objB is long || objB is short || objB is ushort || objB is sbyte || objB is byte)
						{
							if (objA != null && objB != null)
							{
								long num = JValue.smethod_42(objA, JValue.smethod_37());
								long num2 = JValue.smethod_42(objB, JValue.smethod_37());
								if (operation > ExpressionType.Multiply)
								{
									if (operation > ExpressionType.DivideAssign)
									{
										if (operation == ExpressionType.MultiplyAssign)
										{
											goto IL_015F;
										}
										if (operation != ExpressionType.SubtractAssign)
										{
											goto IL_03BC;
										}
									}
									else if (operation != ExpressionType.Subtract)
									{
										switch (operation)
										{
										case ExpressionType.AddAssign:
											goto IL_018E;
										case ExpressionType.AndAssign:
											goto IL_03BC;
										case ExpressionType.DivideAssign:
											goto IL_019C;
										default:
											goto IL_03BC;
										}
									}
									result = num - num2;
									return true;
								}
								if (operation == ExpressionType.Add)
								{
									goto IL_018E;
								}
								if (operation == ExpressionType.Divide)
								{
									goto IL_019C;
								}
								if (operation != ExpressionType.Multiply)
								{
									goto IL_03BC;
								}
								IL_015F:
								result = num * num2;
								return true;
								IL_018E:
								result = num + num2;
								return true;
								IL_019C:
								result = num / num2;
								return true;
							}
							result = null;
							return true;
						}
					}
					else
					{
						if (objA != null && objB != null)
						{
							double num3 = JValue.smethod_39(objA, JValue.smethod_37());
							double num4 = JValue.smethod_39(objB, JValue.smethod_37());
							if (operation > ExpressionType.Multiply)
							{
								if (operation <= ExpressionType.DivideAssign)
								{
									if (operation != ExpressionType.Subtract)
									{
										switch (operation)
										{
										case ExpressionType.AddAssign:
											goto IL_0264;
										case ExpressionType.AndAssign:
											goto IL_03BC;
										case ExpressionType.DivideAssign:
											goto IL_0256;
										default:
											goto IL_03BC;
										}
									}
								}
								else
								{
									if (operation == ExpressionType.MultiplyAssign)
									{
										goto IL_0248;
									}
									if (operation != ExpressionType.SubtractAssign)
									{
										goto IL_03BC;
									}
								}
								result = num3 - num4;
								return true;
							}
							if (operation == ExpressionType.Add)
							{
								goto IL_0264;
							}
							if (operation == ExpressionType.Divide)
							{
								goto IL_0256;
							}
							if (operation != ExpressionType.Multiply)
							{
								goto IL_03BC;
							}
							IL_0248:
							result = num3 * num4;
							return true;
							IL_0256:
							result = num3 / num4;
							return true;
							IL_0264:
							result = num3 + num4;
							return true;
						}
						result = null;
						return true;
					}
				}
				else
				{
					if (objA != null && objB != null)
					{
						decimal num5 = JValue.smethod_38(objA, JValue.smethod_37());
						decimal num6 = JValue.smethod_38(objB, JValue.smethod_37());
						if (operation > ExpressionType.Multiply)
						{
							if (operation <= ExpressionType.DivideAssign)
							{
								if (operation != ExpressionType.Subtract)
								{
									switch (operation)
									{
									case ExpressionType.AddAssign:
										goto IL_02E4;
									case ExpressionType.AndAssign:
										goto IL_03BC;
									case ExpressionType.DivideAssign:
										goto IL_02F5;
									default:
										goto IL_03BC;
									}
								}
							}
							else
							{
								if (operation == ExpressionType.MultiplyAssign)
								{
									goto IL_0328;
								}
								if (operation != ExpressionType.SubtractAssign)
								{
									goto IL_03BC;
								}
							}
							result = num5 - num6;
							return true;
						}
						if (operation != ExpressionType.Add)
						{
							if (operation == ExpressionType.Divide)
							{
								goto IL_02F5;
							}
							if (operation != ExpressionType.Multiply)
							{
								goto IL_03BC;
							}
							goto IL_0328;
						}
						IL_02E4:
						result = num5 + num6;
						return true;
						IL_02F5:
						result = num5 / num6;
						return true;
						IL_0328:
						result = num5 * num6;
						return true;
					}
					result = null;
					return true;
				}
			}
			else
			{
				if (objA != null && objB != null)
				{
					BigInteger bigInteger = ConvertUtils.ToBigInteger(objA);
					BigInteger bigInteger2 = ConvertUtils.ToBigInteger(objB);
					if (operation > ExpressionType.Multiply)
					{
						if (operation <= ExpressionType.DivideAssign)
						{
							if (operation != ExpressionType.Subtract)
							{
								switch (operation)
								{
								case ExpressionType.AddAssign:
									goto IL_0392;
								case ExpressionType.AndAssign:
									goto IL_03BC;
								case ExpressionType.DivideAssign:
									goto IL_03A2;
								default:
									goto IL_03BC;
								}
							}
						}
						else
						{
							if (operation == ExpressionType.MultiplyAssign)
							{
								goto IL_03D1;
							}
							if (operation != ExpressionType.SubtractAssign)
							{
								goto IL_03BC;
							}
						}
						result = bigInteger - bigInteger2;
						return true;
					}
					if (operation != ExpressionType.Add)
					{
						if (operation == ExpressionType.Divide)
						{
							goto IL_03A2;
						}
						if (operation != ExpressionType.Multiply)
						{
							goto IL_03BC;
						}
						goto IL_03D1;
					}
					IL_0392:
					result = bigInteger + bigInteger2;
					return true;
					IL_03A2:
					result = bigInteger / bigInteger2;
					return true;
					IL_03D1:
					result = bigInteger * bigInteger2;
					return true;
				}
				result = null;
				return true;
			}
			IL_03BC:
			result = null;
			return false;
		}

		// Token: 0x06001C70 RID: 7280 RVA: 0x000190C1 File Offset: 0x000172C1
		internal override JToken CloneToken()
		{
			return new JValue(this);
		}

		// Token: 0x06001C71 RID: 7281 RVA: 0x000190C9 File Offset: 0x000172C9
		public static JValue CreateComment(string value)
		{
			return new JValue(value, JTokenType.Comment);
		}

		// Token: 0x06001C72 RID: 7282 RVA: 0x000190D2 File Offset: 0x000172D2
		public static JValue CreateString(string value)
		{
			return new JValue(value, JTokenType.String);
		}

		// Token: 0x06001C73 RID: 7283 RVA: 0x000190DB File Offset: 0x000172DB
		public static JValue CreateNull()
		{
			return new JValue(null, JTokenType.Null);
		}

		// Token: 0x06001C74 RID: 7284 RVA: 0x000190E5 File Offset: 0x000172E5
		public static JValue CreateUndefined()
		{
			return new JValue(null, JTokenType.Undefined);
		}

		// Token: 0x06001C75 RID: 7285 RVA: 0x0007EC5C File Offset: 0x0007CE5C
		private static JTokenType GetValueType(JTokenType? current, object value)
		{
			if (value == null)
			{
				return JTokenType.Null;
			}
			if (value == DBNull.Value)
			{
				return JTokenType.Null;
			}
			if (value is string)
			{
				return JValue.GetStringValueType(current);
			}
			if (value is long || value is int || value is short || value is sbyte || value is ulong || value is uint || value is ushort || value is byte)
			{
				return JTokenType.Integer;
			}
			if (value is Enum)
			{
				return JTokenType.Integer;
			}
			if (value is BigInteger)
			{
				return JTokenType.Integer;
			}
			if (value is double || value is float || value is decimal)
			{
				return JTokenType.Float;
			}
			if (value is DateTime)
			{
				return JTokenType.Date;
			}
			if (value is DateTimeOffset)
			{
				return JTokenType.Date;
			}
			if (value is byte[])
			{
				return JTokenType.Bytes;
			}
			if (value is bool)
			{
				return JTokenType.Boolean;
			}
			if (value is Guid)
			{
				return JTokenType.Guid;
			}
			if (value is Uri)
			{
				return JTokenType.Uri;
			}
			if (value is TimeSpan)
			{
				return JTokenType.TimeSpan;
			}
			throw JValue.smethod_44(<Module>.smethod_25<string>(901607708U).FormatWith(JValue.smethod_37(), JValue.smethod_43(value)));
		}

		// Token: 0x06001C76 RID: 7286 RVA: 0x0007ED84 File Offset: 0x0007CF84
		private static JTokenType GetStringValueType(JTokenType? current)
		{
			if (current != null)
			{
				JTokenType value = current.Value;
				if (value != JTokenType.Comment && value != JTokenType.String)
				{
					if (value != JTokenType.Raw)
					{
						return JTokenType.String;
					}
				}
				return current.Value;
			}
			return JTokenType.String;
		}

		// Token: 0x17000403 RID: 1027
		// (get) Token: 0x06001C77 RID: 7287 RVA: 0x000190EF File Offset: 0x000172EF
		public override JTokenType Type
		{
			get
			{
				return this._valueType;
			}
		}

		// Token: 0x17000404 RID: 1028
		// (get) Token: 0x06001C78 RID: 7288 RVA: 0x000190F7 File Offset: 0x000172F7
		// (set) Token: 0x06001C79 RID: 7289 RVA: 0x0007EDBC File Offset: 0x0007CFBC
		public new object Value
		{
			get
			{
				return this._value;
			}
			set
			{
				Type type;
				if (this._value != null)
				{
					type = JValue.smethod_43(this._value);
					goto IL_005E;
				}
				goto IL_0096;
				int num;
				for (;;)
				{
					IL_0071:
					switch (num ^ 1059721079)
					{
					case 1:
						goto IL_005D;
					case 2:
						this._value = value;
						num = 1059721079;
						continue;
					case 3:
						goto IL_0036;
					case 4:
						goto IL_0096;
					case 5:
						this._valueType = JValue.GetValueType(new JTokenType?(this._valueType), value);
						num = 1059721077;
						continue;
					}
					return;
				}
				IL_0036:
				Type type2 = null;
				goto IL_0037;
				IL_005D:
				type = null;
				goto IL_005E;
				IL_0037:
				Type type3 = type2;
				Type type4;
				num = (JValue.smethod_45(type4, type3) ? 1059721074 : 1059721077);
				goto IL_0071;
				IL_005E:
				type4 = type;
				if (value == null)
				{
					num = 1059721076;
					goto IL_0071;
				}
				type2 = JValue.smethod_43(value);
				goto IL_0037;
				IL_0096:
				num = 1059721078;
				goto IL_0071;
			}
		}

		// Token: 0x06001C7A RID: 7290 RVA: 0x0007EE68 File Offset: 0x0007D068
		public override void WriteTo(JsonWriter writer, params JsonConverter[] converters)
		{
			if (converters != null && converters.Length > 0 && this._value != null)
			{
				JsonConverter matchingConverter = JsonSerializer.GetMatchingConverter(converters, JValue.smethod_43(this._value));
				if (matchingConverter != null && matchingConverter.CanWrite)
				{
					matchingConverter.WriteJson(writer, this._value, JsonSerializer.CreateDefault());
					return;
				}
			}
			switch (this._valueType)
			{
			case JTokenType.Comment:
				writer.WriteComment((this._value != null) ? JValue.smethod_40(this._value) : null);
				return;
			case JTokenType.Integer:
				if (this._value is int)
				{
					writer.WriteValue((int)this._value);
					return;
				}
				if (this._value is long)
				{
					writer.WriteValue((long)this._value);
					return;
				}
				if (this._value is ulong)
				{
					writer.WriteValue((ulong)this._value);
					return;
				}
				if (this._value is BigInteger)
				{
					writer.WriteValue((BigInteger)this._value);
					return;
				}
				writer.WriteValue(JValue.smethod_42(this._value, JValue.smethod_37()));
				return;
			case JTokenType.Float:
				if (this._value is decimal)
				{
					writer.WriteValue((decimal)this._value);
					return;
				}
				if (this._value is double)
				{
					writer.WriteValue((double)this._value);
					return;
				}
				if (this._value is float)
				{
					writer.WriteValue((float)this._value);
					return;
				}
				writer.WriteValue(JValue.smethod_39(this._value, JValue.smethod_37()));
				return;
			case JTokenType.String:
				writer.WriteValue((this._value != null) ? JValue.smethod_40(this._value) : null);
				return;
			case JTokenType.Boolean:
				writer.WriteValue(JValue.smethod_46(this._value, JValue.smethod_37()));
				return;
			case JTokenType.Null:
				writer.WriteNull();
				return;
			case JTokenType.Undefined:
				writer.WriteUndefined();
				return;
			case JTokenType.Date:
				if (!(this._value is DateTimeOffset))
				{
					writer.WriteValue(JValue.smethod_47(this._value, JValue.smethod_37()));
					return;
				}
				writer.WriteValue((DateTimeOffset)this._value);
				return;
			case JTokenType.Raw:
				writer.WriteRawValue((this._value != null) ? JValue.smethod_40(this._value) : null);
				return;
			case JTokenType.Bytes:
				writer.WriteValue((byte[])this._value);
				return;
			case JTokenType.Guid:
			case JTokenType.Uri:
			case JTokenType.TimeSpan:
				writer.WriteValue((this._value != null) ? JValue.smethod_40(this._value) : null);
				return;
			default:
				throw MiscellaneousUtils.CreateArgumentOutOfRangeException(<Module>.smethod_23<string>(3596004305U), this._valueType, <Module>.smethod_23<string>(1738443285U));
			}
		}

		// Token: 0x06001C7B RID: 7291 RVA: 0x0007F10C File Offset: 0x0007D30C
		internal override int GetDeepHashCode()
		{
			int num = ((this._value == null) ? 0 : JValue.smethod_48(this._value));
			int valueType = (int)this._valueType;
			return valueType.GetHashCode() ^ num;
		}

		// Token: 0x06001C7C RID: 7292 RVA: 0x000190FF File Offset: 0x000172FF
		private static bool ValuesEquals(JValue v1, JValue v2)
		{
			return v1 == v2 || (v1._valueType == v2._valueType && JValue.Compare(v1._valueType, v1._value, v2._value) == 0);
		}

		// Token: 0x06001C7D RID: 7293 RVA: 0x00019131 File Offset: 0x00017331
		public bool Equals(JValue other)
		{
			return other != null && JValue.ValuesEquals(this, other);
		}

		// Token: 0x06001C7E RID: 7294 RVA: 0x0007F140 File Offset: 0x0007D340
		public override bool Equals(object obj)
		{
			if (obj == null)
			{
				return false;
			}
			JValue jvalue = obj as JValue;
			if (jvalue != null)
			{
				return this.Equals(jvalue);
			}
			return this.method_0(obj);
		}

		// Token: 0x06001C7F RID: 7295 RVA: 0x0001913F File Offset: 0x0001733F
		public override int GetHashCode()
		{
			if (this._value == null)
			{
				return 0;
			}
			return JValue.smethod_48(this._value);
		}

		// Token: 0x06001C80 RID: 7296 RVA: 0x00019156 File Offset: 0x00017356
		public override string ToString()
		{
			if (this._value == null)
			{
				return string.Empty;
			}
			return JValue.smethod_40(this._value);
		}

		// Token: 0x06001C81 RID: 7297 RVA: 0x00019171 File Offset: 0x00017371
		public string ToString(string format)
		{
			return this.ToString(format, JValue.smethod_49());
		}

		// Token: 0x06001C82 RID: 7298 RVA: 0x0001917F File Offset: 0x0001737F
		public string ToString(IFormatProvider formatProvider)
		{
			return this.ToString(null, formatProvider);
		}

		// Token: 0x06001C83 RID: 7299 RVA: 0x0007F16C File Offset: 0x0007D36C
		public string ToString(string format, IFormatProvider formatProvider)
		{
			if (this._value == null)
			{
				return string.Empty;
			}
			IFormattable formattable = this._value as IFormattable;
			if (formattable != null)
			{
				return JValue.smethod_50(formattable, format, formatProvider);
			}
			return JValue.smethod_40(this._value);
		}

		// Token: 0x06001C84 RID: 7300 RVA: 0x00019189 File Offset: 0x00017389
		protected override DynamicMetaObject GetMetaObject(Expression parameter)
		{
			return new DynamicProxyMetaObject<JValue>(parameter, this, new JValue.JValueDynamicProxy(), true);
		}

		// Token: 0x06001C85 RID: 7301 RVA: 0x0007F1AC File Offset: 0x0007D3AC
		int IComparable.CompareTo(object obj)
		{
			if (obj == null)
			{
				goto IL_0038;
			}
			object obj2;
			if (obj is JValue)
			{
				obj2 = ((JValue)obj).Value;
				goto IL_0040;
			}
			int num = -2097515721;
			IL_001F:
			switch (num ^ -2097515721)
			{
			case 1:
				return 1;
			case 2:
				IL_0038:
				num = -2097515722;
				goto IL_001F;
			}
			obj2 = obj;
			IL_0040:
			object obj3 = obj2;
			return JValue.Compare(this._valueType, this._value, obj3);
		}

		// Token: 0x06001C86 RID: 7302 RVA: 0x00019198 File Offset: 0x00017398
		public int CompareTo(JValue obj)
		{
			if (obj == null)
			{
				return 1;
			}
			return JValue.Compare(this._valueType, this._value, obj._value);
		}

		// Token: 0x06001C87 RID: 7303 RVA: 0x000191B6 File Offset: 0x000173B6
		TypeCode IConvertible.GetTypeCode()
		{
			if (this._value == null)
			{
				return TypeCode.Empty;
			}
			if (this._value is DateTimeOffset)
			{
				return TypeCode.DateTime;
			}
			if (this._value is BigInteger)
			{
				return TypeCode.Object;
			}
			return JValue.smethod_51(JValue.smethod_43(this._value));
		}

		// Token: 0x06001C88 RID: 7304 RVA: 0x000191F1 File Offset: 0x000173F1
		bool IConvertible.ToBoolean(IFormatProvider provider)
		{
			return (bool)this;
		}

		// Token: 0x06001C89 RID: 7305 RVA: 0x000191F9 File Offset: 0x000173F9
		char IConvertible.ToChar(IFormatProvider provider)
		{
			return (char)this;
		}

		// Token: 0x06001C8A RID: 7306 RVA: 0x00019201 File Offset: 0x00017401
		sbyte IConvertible.ToSByte(IFormatProvider provider)
		{
			return (sbyte)this;
		}

		// Token: 0x06001C8B RID: 7307 RVA: 0x00019209 File Offset: 0x00017409
		byte IConvertible.ToByte(IFormatProvider provider)
		{
			return (byte)this;
		}

		// Token: 0x06001C8C RID: 7308 RVA: 0x00019211 File Offset: 0x00017411
		short IConvertible.ToInt16(IFormatProvider provider)
		{
			return (short)this;
		}

		// Token: 0x06001C8D RID: 7309 RVA: 0x00019219 File Offset: 0x00017419
		ushort IConvertible.ToUInt16(IFormatProvider provider)
		{
			return (ushort)this;
		}

		// Token: 0x06001C8E RID: 7310 RVA: 0x00019221 File Offset: 0x00017421
		int IConvertible.ToInt32(IFormatProvider provider)
		{
			return (int)this;
		}

		// Token: 0x06001C8F RID: 7311 RVA: 0x00019229 File Offset: 0x00017429
		uint IConvertible.ToUInt32(IFormatProvider provider)
		{
			return (uint)this;
		}

		// Token: 0x06001C90 RID: 7312 RVA: 0x00019231 File Offset: 0x00017431
		long IConvertible.ToInt64(IFormatProvider provider)
		{
			return (long)this;
		}

		// Token: 0x06001C91 RID: 7313 RVA: 0x00019239 File Offset: 0x00017439
		ulong IConvertible.ToUInt64(IFormatProvider provider)
		{
			return (ulong)this;
		}

		// Token: 0x06001C92 RID: 7314 RVA: 0x00019241 File Offset: 0x00017441
		float IConvertible.ToSingle(IFormatProvider provider)
		{
			return (float)this;
		}

		// Token: 0x06001C93 RID: 7315 RVA: 0x0001924A File Offset: 0x0001744A
		double IConvertible.ToDouble(IFormatProvider provider)
		{
			return (double)this;
		}

		// Token: 0x06001C94 RID: 7316 RVA: 0x00019253 File Offset: 0x00017453
		decimal IConvertible.ToDecimal(IFormatProvider provider)
		{
			return (decimal)this;
		}

		// Token: 0x06001C95 RID: 7317 RVA: 0x0001925B File Offset: 0x0001745B
		DateTime IConvertible.ToDateTime(IFormatProvider provider)
		{
			return (DateTime)this;
		}

		// Token: 0x06001C96 RID: 7318 RVA: 0x00019263 File Offset: 0x00017463
		object IConvertible.ToType(Type conversionType, IFormatProvider provider)
		{
			return base.ToObject(conversionType);
		}

		// Token: 0x06001C97 RID: 7319 RVA: 0x0000FADF File Offset: 0x0000DCDF
		static bool smethod_36(Uri uri_0, Uri uri_1)
		{
			return uri_0 != uri_1;
		}

		// Token: 0x06001C98 RID: 7320 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_37()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001C99 RID: 7321 RVA: 0x00016830 File Offset: 0x00014A30
		static decimal smethod_38(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToDecimal(object_0, iformatProvider_0);
		}

		// Token: 0x06001C9A RID: 7322 RVA: 0x00017112 File Offset: 0x00015312
		static double smethod_39(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToDouble(object_0, iformatProvider_0);
		}

		// Token: 0x06001C9B RID: 7323 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_40(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06001C9C RID: 7324 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_41(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x06001C9D RID: 7325 RVA: 0x00017109 File Offset: 0x00015309
		static long smethod_42(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToInt64(object_0, iformatProvider_0);
		}

		// Token: 0x06001C9E RID: 7326 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_43(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06001C9F RID: 7327 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_44(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x06001CA0 RID: 7328 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_45(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x06001CA1 RID: 7329 RVA: 0x0001711B File Offset: 0x0001531B
		static bool smethod_46(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToBoolean(object_0, iformatProvider_0);
		}

		// Token: 0x06001CA2 RID: 7330 RVA: 0x00017124 File Offset: 0x00015324
		static DateTime smethod_47(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToDateTime(object_0, iformatProvider_0);
		}

		// Token: 0x06001CA3 RID: 7331 RVA: 0x0000CF7A File Offset: 0x0000B17A
		static int smethod_48(object object_0)
		{
			return object_0.GetHashCode();
		}

		// Token: 0x06001CA4 RID: 7332 RVA: 0x0001926C File Offset: 0x0001746C
		bool method_0(object object_0)
		{
			return base.Equals(object_0);
		}

		// Token: 0x06001CA5 RID: 7333 RVA: 0x00019275 File Offset: 0x00017475
		static CultureInfo smethod_49()
		{
			return CultureInfo.CurrentCulture;
		}

		// Token: 0x06001CA6 RID: 7334 RVA: 0x00016842 File Offset: 0x00014A42
		static string smethod_50(IFormattable iformattable_0, string string_0, IFormatProvider iformatProvider_0)
		{
			return iformattable_0.ToString(string_0, iformatProvider_0);
		}

		// Token: 0x06001CA7 RID: 7335 RVA: 0x0001927C File Offset: 0x0001747C
		static TypeCode smethod_51(Type type_0)
		{
			return global::System.Type.GetTypeCode(type_0);
		}

		// Token: 0x04000AEE RID: 2798
		private JTokenType _valueType;

		// Token: 0x04000AEF RID: 2799
		private object _value;

		// Token: 0x020001F3 RID: 499
		private class JValueDynamicProxy : DynamicProxy<JValue>
		{
			// Token: 0x06001CA8 RID: 7336 RVA: 0x0007F210 File Offset: 0x0007D410
			public override bool TryConvert(JValue instance, ConvertBinder binder, out object result)
			{
				if (JValue.JValueDynamicProxy.smethod_2(JValue.JValueDynamicProxy.smethod_0(binder), JValue.JValueDynamicProxy.smethod_1(typeof(JValue).TypeHandle)))
				{
					result = instance;
					return true;
				}
				object value = instance.Value;
				if (value != null)
				{
					result = ConvertUtils.Convert(value, JValue.JValueDynamicProxy.smethod_3(), JValue.JValueDynamicProxy.smethod_0(binder));
					return true;
				}
				result = null;
				return ReflectionUtils.IsNullable(JValue.JValueDynamicProxy.smethod_0(binder));
			}

			// Token: 0x06001CA9 RID: 7337 RVA: 0x0007F268 File Offset: 0x0007D468
			public override bool TryBinaryOperation(JValue instance, BinaryOperationBinder binder, object arg, out object result)
			{
				object obj = ((!(arg is JValue)) ? arg : ((JValue)arg).Value);
				ExpressionType expressionType = JValue.JValueDynamicProxy.smethod_4(binder);
				if (expressionType <= ExpressionType.NotEqual)
				{
					if (expressionType <= ExpressionType.LessThanOrEqual)
					{
						if (expressionType != ExpressionType.Add)
						{
							switch (expressionType)
							{
							case ExpressionType.Divide:
								break;
							case ExpressionType.Equal:
								result = JValue.Compare(instance.Type, instance.Value, obj) == 0;
								return true;
							case ExpressionType.ExclusiveOr:
							case ExpressionType.Invoke:
							case ExpressionType.Lambda:
							case ExpressionType.LeftShift:
								goto IL_018A;
							case ExpressionType.GreaterThan:
								result = JValue.Compare(instance.Type, instance.Value, obj) > 0;
								return true;
							case ExpressionType.GreaterThanOrEqual:
								result = JValue.Compare(instance.Type, instance.Value, obj) >= 0;
								return true;
							case ExpressionType.LessThan:
								result = JValue.Compare(instance.Type, instance.Value, obj) < 0;
								return true;
							case ExpressionType.LessThanOrEqual:
								result = JValue.Compare(instance.Type, instance.Value, obj) <= 0;
								return true;
							default:
								goto IL_018A;
							}
						}
					}
					else if (expressionType != ExpressionType.Multiply)
					{
						if (expressionType != ExpressionType.NotEqual)
						{
							goto IL_018A;
						}
						result = JValue.Compare(instance.Type, instance.Value, obj) != 0;
						return true;
					}
				}
				else if (expressionType > ExpressionType.DivideAssign)
				{
					if (expressionType != ExpressionType.MultiplyAssign && expressionType != ExpressionType.SubtractAssign)
					{
						goto IL_018A;
					}
				}
				else if (expressionType != ExpressionType.Subtract)
				{
					switch (expressionType)
					{
					case ExpressionType.AddAssign:
					case ExpressionType.DivideAssign:
						break;
					case ExpressionType.AndAssign:
						goto IL_018A;
					default:
						goto IL_018A;
					}
				}
				if (JValue.Operation(JValue.JValueDynamicProxy.smethod_4(binder), instance.Value, obj, out result))
				{
					result = new JValue(result);
					return true;
				}
				IL_018A:
				result = null;
				return false;
			}

			// Token: 0x06001CAB RID: 7339 RVA: 0x0001928C File Offset: 0x0001748C
			static Type smethod_0(ConvertBinder convertBinder_0)
			{
				return convertBinder_0.Type;
			}

			// Token: 0x06001CAC RID: 7340 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
			static Type smethod_1(RuntimeTypeHandle runtimeTypeHandle_0)
			{
				return global::System.Type.GetTypeFromHandle(runtimeTypeHandle_0);
			}

			// Token: 0x06001CAD RID: 7341 RVA: 0x000108AF File Offset: 0x0000EAAF
			static bool smethod_2(Type type_0, Type type_1)
			{
				return type_0 == type_1;
			}

			// Token: 0x06001CAE RID: 7342 RVA: 0x0000CDAA File Offset: 0x0000AFAA
			static CultureInfo smethod_3()
			{
				return CultureInfo.InvariantCulture;
			}

			// Token: 0x06001CAF RID: 7343 RVA: 0x00019294 File Offset: 0x00017494
			static ExpressionType smethod_4(BinaryOperationBinder binaryOperationBinder_0)
			{
				return binaryOperationBinder_0.Operation;
			}
		}
	}
}
