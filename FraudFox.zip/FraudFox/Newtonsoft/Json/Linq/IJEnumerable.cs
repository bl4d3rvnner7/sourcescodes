﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x020001EA RID: 490
	public interface IJEnumerable<out T> : IEnumerable<T>, IEnumerable where T : JToken
	{
		// Token: 0x170003E9 RID: 1001
		IJEnumerable<JToken> this[object key] { get; }
	}
}
