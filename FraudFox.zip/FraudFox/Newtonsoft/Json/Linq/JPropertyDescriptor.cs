﻿using System;
using System.ComponentModel;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x020001FD RID: 509
	public class JPropertyDescriptor : PropertyDescriptor
	{
		// Token: 0x06001CED RID: 7405 RVA: 0x000194A1 File Offset: 0x000176A1
		public JPropertyDescriptor(string name)
			: base(name, null)
		{
		}

		// Token: 0x06001CEE RID: 7406 RVA: 0x000194AB File Offset: 0x000176AB
		private static JObject CastInstance(object instance)
		{
			return (JObject)instance;
		}

		// Token: 0x06001CEF RID: 7407 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanResetValue(object component)
		{
			return false;
		}

		// Token: 0x06001CF0 RID: 7408 RVA: 0x0007F750 File Offset: 0x0007D950
		public override object GetValue(object component)
		{
			return JPropertyDescriptor.CastInstance(component)[JPropertyDescriptor.smethod_0(this)];
		}

		// Token: 0x06001CF1 RID: 7409 RVA: 0x0000C600 File Offset: 0x0000A800
		public override void ResetValue(object component)
		{
		}

		// Token: 0x06001CF2 RID: 7410 RVA: 0x0007F770 File Offset: 0x0007D970
		public override void SetValue(object component, object value)
		{
			JToken jtoken = ((value is JToken) ? ((JToken)value) : new JValue(value));
			JPropertyDescriptor.CastInstance(component)[JPropertyDescriptor.smethod_0(this)] = jtoken;
		}

		// Token: 0x06001CF3 RID: 7411 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool ShouldSerializeValue(object component)
		{
			return false;
		}

		// Token: 0x1700040B RID: 1035
		// (get) Token: 0x06001CF4 RID: 7412 RVA: 0x000194B3 File Offset: 0x000176B3
		public override Type ComponentType
		{
			get
			{
				return JPropertyDescriptor.smethod_1(typeof(JObject).TypeHandle);
			}
		}

		// Token: 0x1700040C RID: 1036
		// (get) Token: 0x06001CF5 RID: 7413 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700040D RID: 1037
		// (get) Token: 0x06001CF6 RID: 7414 RVA: 0x000194BF File Offset: 0x000176BF
		public override Type PropertyType
		{
			get
			{
				return JPropertyDescriptor.smethod_1(typeof(object).TypeHandle);
			}
		}

		// Token: 0x1700040E RID: 1038
		// (get) Token: 0x06001CF7 RID: 7415 RVA: 0x0007F7A8 File Offset: 0x0007D9A8
		protected override int NameHashCode
		{
			get
			{
				return base.NameHashCode;
			}
		}

		// Token: 0x06001CF8 RID: 7416 RVA: 0x000194CB File Offset: 0x000176CB
		static string smethod_0(MemberDescriptor memberDescriptor_0)
		{
			return memberDescriptor_0.Name;
		}

		// Token: 0x06001CF9 RID: 7417 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_1(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}
	}
}
