﻿using System;
using System.Globalization;
using System.Numerics;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x02000242 RID: 578
	public class JTokenWriter : JsonWriter
	{
		// Token: 0x17000503 RID: 1283
		// (get) Token: 0x0600221F RID: 8735 RVA: 0x0001C042 File Offset: 0x0001A242
		public JToken CurrentToken
		{
			get
			{
				return this._current;
			}
		}

		// Token: 0x17000504 RID: 1284
		// (get) Token: 0x06002220 RID: 8736 RVA: 0x0001C04A File Offset: 0x0001A24A
		public JToken Token
		{
			get
			{
				if (this._token != null)
				{
					return this._token;
				}
				return this._value;
			}
		}

		// Token: 0x06002221 RID: 8737 RVA: 0x0001C061 File Offset: 0x0001A261
		public JTokenWriter(JContainer container)
		{
			ValidationUtils.ArgumentNotNull(container, <Module>.smethod_24<string>(593389368U));
			this._token = container;
			this._parent = container;
		}

		// Token: 0x06002222 RID: 8738 RVA: 0x0001C087 File Offset: 0x0001A287
		public JTokenWriter()
		{
		}

		// Token: 0x06002223 RID: 8739 RVA: 0x0000C600 File Offset: 0x0000A800
		public override void Flush()
		{
		}

		// Token: 0x06002224 RID: 8740 RVA: 0x0001C08F File Offset: 0x0001A28F
		public override void Close()
		{
			base.Close();
		}

		// Token: 0x06002225 RID: 8741 RVA: 0x0001C097 File Offset: 0x0001A297
		public override void WriteStartObject()
		{
			base.WriteStartObject();
			this.AddParent(new JObject());
		}

		// Token: 0x06002226 RID: 8742 RVA: 0x0001C0AA File Offset: 0x0001A2AA
		private void AddParent(JContainer container)
		{
			if (this._parent == null)
			{
				this._token = container;
			}
			else
			{
				this._parent.AddAndSkipParentCheck(container);
			}
			this._parent = container;
			this._current = container;
		}

		// Token: 0x06002227 RID: 8743 RVA: 0x00089718 File Offset: 0x00087918
		private void RemoveParent()
		{
			this._current = this._parent;
			this._parent = this._parent.Parent;
			if (this._parent != null && this._parent.Type == JTokenType.Property)
			{
				this._parent = this._parent.Parent;
			}
		}

		// Token: 0x06002228 RID: 8744 RVA: 0x0001C0D7 File Offset: 0x0001A2D7
		public override void WriteStartArray()
		{
			base.WriteStartArray();
			this.AddParent(new JArray());
		}

		// Token: 0x06002229 RID: 8745 RVA: 0x0001C0EA File Offset: 0x0001A2EA
		public override void WriteStartConstructor(string name)
		{
			base.WriteStartConstructor(name);
			this.AddParent(new JConstructor(name));
		}

		// Token: 0x0600222A RID: 8746 RVA: 0x0001C0FF File Offset: 0x0001A2FF
		protected override void WriteEnd(JsonToken token)
		{
			this.RemoveParent();
		}

		// Token: 0x0600222B RID: 8747 RVA: 0x0001C107 File Offset: 0x0001A307
		public override void WritePropertyName(string name)
		{
			this.AddParent(new JProperty(name));
			base.WritePropertyName(name);
		}

		// Token: 0x0600222C RID: 8748 RVA: 0x0001C11C File Offset: 0x0001A31C
		private void AddValue(object value, JsonToken token)
		{
			this.AddValue(new JValue(value), token);
		}

		// Token: 0x0600222D RID: 8749 RVA: 0x0008976C File Offset: 0x0008796C
		internal void AddValue(JValue value, JsonToken token)
		{
			if (this._parent != null)
			{
				this._parent.Add(value);
				this._current = this._parent.Last;
				if (this._parent.Type == JTokenType.Property)
				{
					this._parent = this._parent.Parent;
					return;
				}
			}
			else
			{
				this._value = value ?? JValue.CreateNull();
				this._current = this._value;
			}
		}

		// Token: 0x0600222E RID: 8750 RVA: 0x0001C12B File Offset: 0x0001A32B
		public override void WriteValue(object value)
		{
			if (value is BigInteger)
			{
				base.InternalWriteValue(JsonToken.Integer);
				this.AddValue(value, JsonToken.Integer);
				return;
			}
			base.WriteValue(value);
		}

		// Token: 0x0600222F RID: 8751 RVA: 0x0001C14C File Offset: 0x0001A34C
		public override void WriteNull()
		{
			base.WriteNull();
			this.AddValue(null, JsonToken.Null);
		}

		// Token: 0x06002230 RID: 8752 RVA: 0x0001C15D File Offset: 0x0001A35D
		public override void WriteUndefined()
		{
			base.WriteUndefined();
			this.AddValue(null, JsonToken.Undefined);
		}

		// Token: 0x06002231 RID: 8753 RVA: 0x0001C16E File Offset: 0x0001A36E
		public override void WriteRaw(string json)
		{
			base.WriteRaw(json);
			this.AddValue(new JRaw(json), JsonToken.Raw);
		}

		// Token: 0x06002232 RID: 8754 RVA: 0x0001C184 File Offset: 0x0001A384
		public override void WriteComment(string text)
		{
			base.WriteComment(text);
			this.AddValue(JValue.CreateComment(text), JsonToken.Comment);
		}

		// Token: 0x06002233 RID: 8755 RVA: 0x0001C19A File Offset: 0x0001A39A
		public override void WriteValue(string value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.String);
		}

		// Token: 0x06002234 RID: 8756 RVA: 0x0001C1AC File Offset: 0x0001A3AC
		public override void WriteValue(int value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.Integer);
		}

		// Token: 0x06002235 RID: 8757 RVA: 0x0001C1C2 File Offset: 0x0001A3C2
		[CLSCompliant(false)]
		public override void WriteValue(uint value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.Integer);
		}

		// Token: 0x06002236 RID: 8758 RVA: 0x0001C1D8 File Offset: 0x0001A3D8
		public override void WriteValue(long value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.Integer);
		}

		// Token: 0x06002237 RID: 8759 RVA: 0x0001C1EE File Offset: 0x0001A3EE
		[CLSCompliant(false)]
		public override void WriteValue(ulong value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.Integer);
		}

		// Token: 0x06002238 RID: 8760 RVA: 0x0001C204 File Offset: 0x0001A404
		public override void WriteValue(float value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.Float);
		}

		// Token: 0x06002239 RID: 8761 RVA: 0x0001C21A File Offset: 0x0001A41A
		public override void WriteValue(double value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.Float);
		}

		// Token: 0x0600223A RID: 8762 RVA: 0x0001C230 File Offset: 0x0001A430
		public override void WriteValue(bool value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.Boolean);
		}

		// Token: 0x0600223B RID: 8763 RVA: 0x0001C247 File Offset: 0x0001A447
		public override void WriteValue(short value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.Integer);
		}

		// Token: 0x0600223C RID: 8764 RVA: 0x0001C25D File Offset: 0x0001A45D
		[CLSCompliant(false)]
		public override void WriteValue(ushort value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.Integer);
		}

		// Token: 0x0600223D RID: 8765 RVA: 0x000897DC File Offset: 0x000879DC
		public override void WriteValue(char value)
		{
			base.WriteValue(value);
			string text = value.ToString(JTokenWriter.smethod_16());
			this.AddValue(text, JsonToken.String);
		}

		// Token: 0x0600223E RID: 8766 RVA: 0x0001C273 File Offset: 0x0001A473
		public override void WriteValue(byte value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.Integer);
		}

		// Token: 0x0600223F RID: 8767 RVA: 0x0001C289 File Offset: 0x0001A489
		[CLSCompliant(false)]
		public override void WriteValue(sbyte value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.Integer);
		}

		// Token: 0x06002240 RID: 8768 RVA: 0x0001C29F File Offset: 0x0001A49F
		public override void WriteValue(decimal value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.Float);
		}

		// Token: 0x06002241 RID: 8769 RVA: 0x0001C2B5 File Offset: 0x0001A4B5
		public override void WriteValue(DateTime value)
		{
			base.WriteValue(value);
			value = DateTimeUtils.EnsureDateTime(value, base.DateTimeZoneHandling);
			this.AddValue(value, JsonToken.Date);
		}

		// Token: 0x06002242 RID: 8770 RVA: 0x0001C2DA File Offset: 0x0001A4DA
		public override void WriteValue(DateTimeOffset value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.Date);
		}

		// Token: 0x06002243 RID: 8771 RVA: 0x0001C2F1 File Offset: 0x0001A4F1
		public override void WriteValue(byte[] value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.Bytes);
		}

		// Token: 0x06002244 RID: 8772 RVA: 0x0001C303 File Offset: 0x0001A503
		public override void WriteValue(TimeSpan value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.String);
		}

		// Token: 0x06002245 RID: 8773 RVA: 0x0001C31A File Offset: 0x0001A51A
		public override void WriteValue(Guid value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.String);
		}

		// Token: 0x06002246 RID: 8774 RVA: 0x0001C331 File Offset: 0x0001A531
		public override void WriteValue(Uri value)
		{
			base.WriteValue(value);
			this.AddValue(value, JsonToken.String);
		}

		// Token: 0x06002247 RID: 8775 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_16()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x04000C20 RID: 3104
		private JContainer _token;

		// Token: 0x04000C21 RID: 3105
		private JContainer _parent;

		// Token: 0x04000C22 RID: 3106
		private JValue _value;

		// Token: 0x04000C23 RID: 3107
		private JToken _current;
	}
}
