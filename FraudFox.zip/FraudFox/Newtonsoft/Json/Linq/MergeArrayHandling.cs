﻿using System;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x020001D6 RID: 470
	public enum MergeArrayHandling
	{
		// Token: 0x04000A64 RID: 2660
		Concat,
		// Token: 0x04000A65 RID: 2661
		Union,
		// Token: 0x04000A66 RID: 2662
		Replace,
		// Token: 0x04000A67 RID: 2663
		Merge
	}
}
