﻿using System;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x02000241 RID: 577
	public class JTokenReader : JsonReader, IJsonLineInfo
	{
		// Token: 0x170004FF RID: 1279
		// (get) Token: 0x06002205 RID: 8709 RVA: 0x0001BFED File Offset: 0x0001A1ED
		public JToken CurrentToken
		{
			get
			{
				return this._current;
			}
		}

		// Token: 0x06002206 RID: 8710 RVA: 0x0001BFF5 File Offset: 0x0001A1F5
		public JTokenReader(JToken token)
		{
			ValidationUtils.ArgumentNotNull(token, <Module>.smethod_24<string>(3026683931U));
			this._root = token;
		}

		// Token: 0x06002207 RID: 8711 RVA: 0x0001C014 File Offset: 0x0001A214
		internal JTokenReader(JToken token, string initialPath)
			: this(token)
		{
			this._initialPath = initialPath;
		}

		// Token: 0x06002208 RID: 8712 RVA: 0x0001690A File Offset: 0x00014B0A
		public override byte[] ReadAsBytes()
		{
			return base.ReadAsBytesInternal();
		}

		// Token: 0x06002209 RID: 8713 RVA: 0x00016912 File Offset: 0x00014B12
		public override decimal? ReadAsDecimal()
		{
			return base.ReadAsDecimalInternal();
		}

		// Token: 0x0600220A RID: 8714 RVA: 0x0001691A File Offset: 0x00014B1A
		public override int? ReadAsInt32()
		{
			return base.ReadAsInt32Internal();
		}

		// Token: 0x0600220B RID: 8715 RVA: 0x00016922 File Offset: 0x00014B22
		public override string ReadAsString()
		{
			return base.ReadAsStringInternal();
		}

		// Token: 0x0600220C RID: 8716 RVA: 0x0001692A File Offset: 0x00014B2A
		public override DateTime? ReadAsDateTime()
		{
			return base.ReadAsDateTimeInternal();
		}

		// Token: 0x0600220D RID: 8717 RVA: 0x00016932 File Offset: 0x00014B32
		public override DateTimeOffset? ReadAsDateTimeOffset()
		{
			return base.ReadAsDateTimeOffsetInternal();
		}

		// Token: 0x0600220E RID: 8718 RVA: 0x000892A0 File Offset: 0x000874A0
		internal override bool ReadInternal()
		{
			if (base.CurrentState == JsonReader.State.Start)
			{
				this._current = this._root;
				this.SetToken(this._current);
				return true;
			}
			if (this._current == null)
			{
				return false;
			}
			JContainer jcontainer = this._current as JContainer;
			if (jcontainer != null && this._parent != jcontainer)
			{
				return this.ReadInto(jcontainer);
			}
			return this.ReadOver(this._current);
		}

		// Token: 0x0600220F RID: 8719 RVA: 0x0001693A File Offset: 0x00014B3A
		public override bool Read()
		{
			this._readType = ReadType.Read;
			return this.ReadInternal();
		}

		// Token: 0x06002210 RID: 8720 RVA: 0x00089308 File Offset: 0x00087508
		private bool ReadOver(JToken t)
		{
			if (t == this._root)
			{
				return this.ReadToEnd();
			}
			JToken next = t.Next;
			if (next != null && next != t)
			{
				if (t != t.Parent.Last)
				{
					this._current = next;
					this.SetToken(this._current);
					return true;
				}
			}
			if (t.Parent == null)
			{
				return this.ReadToEnd();
			}
			return this.SetEnd(t.Parent);
		}

		// Token: 0x06002211 RID: 8721 RVA: 0x0001C024 File Offset: 0x0001A224
		private bool ReadToEnd()
		{
			this._current = null;
			base.SetToken(JsonToken.None);
			return false;
		}

		// Token: 0x06002212 RID: 8722 RVA: 0x00089374 File Offset: 0x00087574
		private JsonToken? GetEndToken(JContainer c)
		{
			switch (c.Type)
			{
			case JTokenType.Object:
				return new JsonToken?(JsonToken.EndObject);
			case JTokenType.Array:
				return new JsonToken?(JsonToken.EndArray);
			case JTokenType.Constructor:
				return new JsonToken?(JsonToken.EndConstructor);
			case JTokenType.Property:
				return null;
			default:
				throw MiscellaneousUtils.CreateArgumentOutOfRangeException(<Module>.smethod_26<string>(3196282644U), c.Type, <Module>.smethod_23<string>(3149708954U));
			}
		}

		// Token: 0x06002213 RID: 8723 RVA: 0x000893E8 File Offset: 0x000875E8
		private bool ReadInto(JContainer c)
		{
			JToken first = c.First;
			if (first == null)
			{
				return this.SetEnd(c);
			}
			this.SetToken(first);
			this._current = first;
			this._parent = c;
			return true;
		}

		// Token: 0x06002214 RID: 8724 RVA: 0x00089420 File Offset: 0x00087620
		private bool SetEnd(JContainer c)
		{
			JsonToken? endToken = this.GetEndToken(c);
			if (endToken != null)
			{
				base.SetToken(endToken.Value);
				this._current = c;
				this._parent = c;
				return true;
			}
			return this.ReadOver(c);
		}

		// Token: 0x06002215 RID: 8725 RVA: 0x00089464 File Offset: 0x00087664
		private void SetToken(JToken token)
		{
			switch (token.Type)
			{
			case JTokenType.Object:
				base.SetToken(JsonToken.StartObject);
				return;
			case JTokenType.Array:
				base.SetToken(JsonToken.StartArray);
				return;
			case JTokenType.Constructor:
				base.SetToken(JsonToken.StartConstructor, ((JConstructor)token).Name);
				return;
			case JTokenType.Property:
				base.SetToken(JsonToken.PropertyName, ((JProperty)token).Name);
				return;
			case JTokenType.Comment:
				base.SetToken(JsonToken.Comment, ((JValue)token).Value);
				return;
			case JTokenType.Integer:
				base.SetToken(JsonToken.Integer, ((JValue)token).Value);
				return;
			case JTokenType.Float:
				base.SetToken(JsonToken.Float, ((JValue)token).Value);
				return;
			case JTokenType.String:
				base.SetToken(JsonToken.String, ((JValue)token).Value);
				return;
			case JTokenType.Boolean:
				base.SetToken(JsonToken.Boolean, ((JValue)token).Value);
				return;
			case JTokenType.Null:
				base.SetToken(JsonToken.Null, ((JValue)token).Value);
				return;
			case JTokenType.Undefined:
				base.SetToken(JsonToken.Undefined, ((JValue)token).Value);
				return;
			case JTokenType.Date:
				base.SetToken(JsonToken.Date, ((JValue)token).Value);
				return;
			case JTokenType.Raw:
				base.SetToken(JsonToken.Raw, ((JValue)token).Value);
				return;
			case JTokenType.Bytes:
				base.SetToken(JsonToken.Bytes, ((JValue)token).Value);
				return;
			case JTokenType.Guid:
				base.SetToken(JsonToken.String, this.SafeToString(((JValue)token).Value));
				return;
			case JTokenType.Uri:
				base.SetToken(JsonToken.String, this.SafeToString(((JValue)token).Value));
				return;
			case JTokenType.TimeSpan:
				base.SetToken(JsonToken.String, this.SafeToString(((JValue)token).Value));
				return;
			default:
				throw MiscellaneousUtils.CreateArgumentOutOfRangeException(<Module>.smethod_24<string>(2120742129U), token.Type, <Module>.smethod_23<string>(3342990706U));
			}
		}

		// Token: 0x06002216 RID: 8726 RVA: 0x0001C035 File Offset: 0x0001A235
		private string SafeToString(object value)
		{
			if (value == null)
			{
				return null;
			}
			return JTokenReader.smethod_12(value);
		}

		// Token: 0x06002217 RID: 8727 RVA: 0x00089630 File Offset: 0x00087830
		bool IJsonLineInfo.HasLineInfo()
		{
			if (base.CurrentState != JsonReader.State.Start)
			{
				IJsonLineInfo current = this._current;
				return current != null && current.HasLineInfo();
			}
			return false;
		}

		// Token: 0x17000500 RID: 1280
		// (get) Token: 0x06002218 RID: 8728 RVA: 0x0008965C File Offset: 0x0008785C
		int IJsonLineInfo.LineNumber
		{
			get
			{
				if (base.CurrentState == JsonReader.State.Start)
				{
					return 0;
				}
				IJsonLineInfo current = this._current;
				if (current != null)
				{
					return current.LineNumber;
				}
				return 0;
			}
		}

		// Token: 0x17000501 RID: 1281
		// (get) Token: 0x06002219 RID: 8729 RVA: 0x00089688 File Offset: 0x00087888
		int IJsonLineInfo.LinePosition
		{
			get
			{
				if (base.CurrentState == JsonReader.State.Start)
				{
					return 0;
				}
				IJsonLineInfo current = this._current;
				if (current != null)
				{
					return current.LinePosition;
				}
				return 0;
			}
		}

		// Token: 0x17000502 RID: 1282
		// (get) Token: 0x0600221A RID: 8730 RVA: 0x000896B4 File Offset: 0x000878B4
		public override string Path
		{
			get
			{
				string text = base.Path;
				if (!JTokenReader.smethod_13(this._initialPath))
				{
					if (JTokenReader.smethod_13(text))
					{
						return this._initialPath;
					}
					if (text.StartsWith('['))
					{
						text = JTokenReader.smethod_14(this._initialPath, text);
					}
					else
					{
						text = JTokenReader.smethod_15(this._initialPath, <Module>.smethod_26<string>(3551626751U), text);
					}
				}
				return text;
			}
		}

		// Token: 0x0600221B RID: 8731 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_12(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x0600221C RID: 8732 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_13(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x0600221D RID: 8733 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_14(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x0600221E RID: 8734 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_15(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x04000C1C RID: 3100
		private readonly string _initialPath;

		// Token: 0x04000C1D RID: 3101
		private readonly JToken _root;

		// Token: 0x04000C1E RID: 3102
		private JToken _parent;

		// Token: 0x04000C1F RID: 3103
		private JToken _current;
	}
}
