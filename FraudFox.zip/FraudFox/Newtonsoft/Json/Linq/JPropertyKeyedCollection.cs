﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x020001C0 RID: 448
	internal class JPropertyKeyedCollection : Collection<JToken>
	{
		// Token: 0x060019B1 RID: 6577 RVA: 0x00017AB1 File Offset: 0x00015CB1
		private void AddKey(string key, JToken item)
		{
			this.EnsureDictionary();
			this._dictionary[key] = item;
		}

		// Token: 0x060019B2 RID: 6578 RVA: 0x00077D08 File Offset: 0x00075F08
		protected void ChangeItemKey(JToken item, string newKey)
		{
			if (!this.ContainsItem(item))
			{
				throw JPropertyKeyedCollection.smethod_0(<Module>.smethod_26<string>(1689626930U));
			}
			string keyForItem = this.GetKeyForItem(item);
			if (!JPropertyKeyedCollection.Comparer.Equals(keyForItem, newKey))
			{
				if (newKey != null)
				{
					this.AddKey(newKey, item);
				}
				if (keyForItem != null)
				{
					this.RemoveKey(keyForItem);
				}
			}
		}

		// Token: 0x060019B3 RID: 6579 RVA: 0x00017AC6 File Offset: 0x00015CC6
		protected override void ClearItems()
		{
			base.ClearItems();
			if (this._dictionary != null)
			{
				this._dictionary.Clear();
			}
		}

		// Token: 0x060019B4 RID: 6580 RVA: 0x00017AE1 File Offset: 0x00015CE1
		public bool Contains(string key)
		{
			if (key == null)
			{
				throw JPropertyKeyedCollection.smethod_1(<Module>.smethod_27<string>(2215800382U));
			}
			return this._dictionary != null && this._dictionary.ContainsKey(key);
		}

		// Token: 0x060019B5 RID: 6581 RVA: 0x00077D5C File Offset: 0x00075F5C
		private bool ContainsItem(JToken item)
		{
			if (this._dictionary == null)
			{
				return false;
			}
			string keyForItem = this.GetKeyForItem(item);
			JToken jtoken;
			return this._dictionary.TryGetValue(keyForItem, out jtoken);
		}

		// Token: 0x060019B6 RID: 6582 RVA: 0x00017B0C File Offset: 0x00015D0C
		private void EnsureDictionary()
		{
			if (this._dictionary == null)
			{
				this._dictionary = new Dictionary<string, JToken>(JPropertyKeyedCollection.Comparer);
			}
		}

		// Token: 0x060019B7 RID: 6583 RVA: 0x00017B26 File Offset: 0x00015D26
		private string GetKeyForItem(JToken item)
		{
			return ((JProperty)item).Name;
		}

		// Token: 0x060019B8 RID: 6584 RVA: 0x00017B33 File Offset: 0x00015D33
		protected override void InsertItem(int index, JToken item)
		{
			this.AddKey(this.GetKeyForItem(item), item);
			base.InsertItem(index, item);
		}

		// Token: 0x060019B9 RID: 6585 RVA: 0x00077D8C File Offset: 0x00075F8C
		public bool Remove(string key)
		{
			if (key == null)
			{
				throw JPropertyKeyedCollection.smethod_1(<Module>.smethod_23<string>(2029085134U));
			}
			return this._dictionary != null && this._dictionary.ContainsKey(key) && base.Remove(this._dictionary[key]);
		}

		// Token: 0x060019BA RID: 6586 RVA: 0x00077DD8 File Offset: 0x00075FD8
		protected override void RemoveItem(int index)
		{
			string keyForItem = this.GetKeyForItem(base.Items[index]);
			this.RemoveKey(keyForItem);
			base.RemoveItem(index);
		}

		// Token: 0x060019BB RID: 6587 RVA: 0x00017B4B File Offset: 0x00015D4B
		private void RemoveKey(string key)
		{
			if (this._dictionary != null)
			{
				this._dictionary.Remove(key);
			}
		}

		// Token: 0x060019BC RID: 6588 RVA: 0x00077E08 File Offset: 0x00076008
		protected override void SetItem(int index, JToken item)
		{
			string keyForItem = this.GetKeyForItem(item);
			string keyForItem2 = this.GetKeyForItem(base.Items[index]);
			if (JPropertyKeyedCollection.Comparer.Equals(keyForItem2, keyForItem))
			{
				if (this._dictionary != null)
				{
					this._dictionary[keyForItem] = item;
				}
			}
			else
			{
				this.AddKey(keyForItem, item);
				if (keyForItem2 != null)
				{
					this.RemoveKey(keyForItem2);
				}
			}
			base.SetItem(index, item);
		}

		// Token: 0x170003A5 RID: 933
		public JToken this[string key]
		{
			get
			{
				if (key == null)
				{
					throw JPropertyKeyedCollection.smethod_1(<Module>.smethod_25<string>(3870237525U));
				}
				if (this._dictionary == null)
				{
					throw JPropertyKeyedCollection.smethod_2();
				}
				return this._dictionary[key];
			}
		}

		// Token: 0x060019BE RID: 6590 RVA: 0x00017B91 File Offset: 0x00015D91
		public bool TryGetValue(string key, out JToken value)
		{
			if (this._dictionary == null)
			{
				value = null;
				return false;
			}
			return this._dictionary.TryGetValue(key, out value);
		}

		// Token: 0x170003A6 RID: 934
		// (get) Token: 0x060019BF RID: 6591 RVA: 0x00017BAD File Offset: 0x00015DAD
		public ICollection<string> Keys
		{
			get
			{
				this.EnsureDictionary();
				return this._dictionary.Keys;
			}
		}

		// Token: 0x170003A7 RID: 935
		// (get) Token: 0x060019C0 RID: 6592 RVA: 0x00017BC0 File Offset: 0x00015DC0
		public ICollection<JToken> Values
		{
			get
			{
				this.EnsureDictionary();
				return this._dictionary.Values;
			}
		}

		// Token: 0x060019C1 RID: 6593 RVA: 0x00077E70 File Offset: 0x00076070
		public bool Compare(JPropertyKeyedCollection other)
		{
			if (this == other)
			{
				return true;
			}
			Dictionary<string, JToken> dictionary = this._dictionary;
			Dictionary<string, JToken> dictionary2 = other._dictionary;
			if (dictionary == null && dictionary2 == null)
			{
				return true;
			}
			if (dictionary == null)
			{
				return dictionary2.Count == 0;
			}
			if (dictionary2 == null)
			{
				return dictionary.Count == 0;
			}
			if (dictionary.Count != dictionary2.Count)
			{
				return false;
			}
			using (Dictionary<string, JToken>.Enumerator enumerator = dictionary.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					KeyValuePair<string, JToken> keyValuePair = enumerator.Current;
					JToken jtoken;
					if (!dictionary2.TryGetValue(keyValuePair.Key, out jtoken))
					{
						return false;
					}
					JProperty jproperty = (JProperty)keyValuePair.Value;
					JProperty jproperty2 = (JProperty)jtoken;
					if (jproperty.Value == null)
					{
						return jproperty2.Value == null;
					}
					if (!jproperty.Value.DeepEquals(jproperty2.Value))
					{
						return false;
					}
				}
				return true;
			}
			bool flag;
			return flag;
		}

		// Token: 0x060019C4 RID: 6596 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_0(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x060019C5 RID: 6597 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_1(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x060019C6 RID: 6598 RVA: 0x00017BE7 File Offset: 0x00015DE7
		static KeyNotFoundException smethod_2()
		{
			return new KeyNotFoundException();
		}

		// Token: 0x060019C7 RID: 6599 RVA: 0x0001283F File Offset: 0x00010A3F
		static StringComparer smethod_3()
		{
			return StringComparer.Ordinal;
		}

		// Token: 0x040009E9 RID: 2537
		private static readonly IEqualityComparer<string> Comparer = JPropertyKeyedCollection.smethod_3();

		// Token: 0x040009EA RID: 2538
		private Dictionary<string, JToken> _dictionary;
	}
}
