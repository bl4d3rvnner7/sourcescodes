﻿using System;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x020001C1 RID: 449
	public class JsonMergeSettings
	{
		// Token: 0x170003A8 RID: 936
		// (get) Token: 0x060019C8 RID: 6600 RVA: 0x00017BEE File Offset: 0x00015DEE
		// (set) Token: 0x060019C9 RID: 6601 RVA: 0x00017BF6 File Offset: 0x00015DF6
		public MergeArrayHandling MergeArrayHandling
		{
			get
			{
				return this._mergeArrayHandling;
			}
			set
			{
				if (value < MergeArrayHandling.Concat || value > MergeArrayHandling.Merge)
				{
					throw JsonMergeSettings.smethod_0(<Module>.smethod_23<string>(2033612370U));
				}
				this._mergeArrayHandling = value;
			}
		}

		// Token: 0x060019CB RID: 6603 RVA: 0x0000F870 File Offset: 0x0000DA70
		static ArgumentOutOfRangeException smethod_0(string string_0)
		{
			return new ArgumentOutOfRangeException(string_0);
		}

		// Token: 0x040009EB RID: 2539
		private MergeArrayHandling _mergeArrayHandling;
	}
}
