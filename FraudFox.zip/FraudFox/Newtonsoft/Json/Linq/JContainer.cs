﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Threading;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x02000238 RID: 568
	public abstract class JContainer : JToken, IEnumerable<JToken>, IList<JToken>, ICollection<JToken>, IEnumerable, ITypedList, IBindingList, IList, ICollection, INotifyCollectionChanged
	{
		// Token: 0x14000028 RID: 40
		// (add) Token: 0x060020CE RID: 8398 RVA: 0x0001B788 File Offset: 0x00019988
		// (remove) Token: 0x060020CF RID: 8399 RVA: 0x0001B7A1 File Offset: 0x000199A1
		public event ListChangedEventHandler ListChanged
		{
			add
			{
				this._listChanged = (ListChangedEventHandler)JContainer.smethod_36(this._listChanged, value);
			}
			remove
			{
				this._listChanged = (ListChangedEventHandler)JContainer.smethod_37(this._listChanged, value);
			}
		}

		// Token: 0x14000029 RID: 41
		// (add) Token: 0x060020D0 RID: 8400 RVA: 0x0001B7BA File Offset: 0x000199BA
		// (remove) Token: 0x060020D1 RID: 8401 RVA: 0x0001B7D3 File Offset: 0x000199D3
		public event AddingNewEventHandler AddingNew
		{
			add
			{
				this._addingNew = (AddingNewEventHandler)JContainer.smethod_36(this._addingNew, value);
			}
			remove
			{
				this._addingNew = (AddingNewEventHandler)JContainer.smethod_37(this._addingNew, value);
			}
		}

		// Token: 0x1400002A RID: 42
		// (add) Token: 0x060020D2 RID: 8402 RVA: 0x0001B7EC File Offset: 0x000199EC
		// (remove) Token: 0x060020D3 RID: 8403 RVA: 0x0001B805 File Offset: 0x00019A05
		public event NotifyCollectionChangedEventHandler CollectionChanged
		{
			add
			{
				this._collectionChanged = (NotifyCollectionChangedEventHandler)JContainer.smethod_36(this._collectionChanged, value);
			}
			remove
			{
				this._collectionChanged = (NotifyCollectionChangedEventHandler)JContainer.smethod_37(this._collectionChanged, value);
			}
		}

		// Token: 0x170004D5 RID: 1237
		// (get) Token: 0x060020D4 RID: 8404
		protected abstract IList<JToken> ChildrenTokens { get; }

		// Token: 0x060020D5 RID: 8405 RVA: 0x0001B81E File Offset: 0x00019A1E
		internal JContainer()
		{
		}

		// Token: 0x060020D6 RID: 8406 RVA: 0x0008746C File Offset: 0x0008566C
		internal JContainer(JContainer other)
			: this()
		{
			ValidationUtils.ArgumentNotNull(other, <Module>.smethod_26<string>(1261851056U));
			int num = 0;
			IEnumerator<JToken> enumerator = ((IEnumerable<JToken>)other).GetEnumerator();
			try
			{
				while (JContainer.smethod_38(enumerator))
				{
					JToken jtoken = enumerator.Current;
					this.AddInternal(num, jtoken, false);
					num++;
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JContainer.smethod_39(enumerator);
				}
			}
		}

		// Token: 0x060020D7 RID: 8407 RVA: 0x0001B826 File Offset: 0x00019A26
		internal void CheckReentrancy()
		{
			if (this._busy)
			{
				throw JContainer.smethod_42(<Module>.smethod_27<string>(731854302U).FormatWith(JContainer.smethod_40(), JContainer.smethod_41(this)));
			}
		}

		// Token: 0x060020D8 RID: 8408 RVA: 0x0001B850 File Offset: 0x00019A50
		internal virtual IList<JToken> CreateChildrenCollection()
		{
			return new List<JToken>();
		}

		// Token: 0x060020D9 RID: 8409 RVA: 0x000874D4 File Offset: 0x000856D4
		protected virtual void OnAddingNew(AddingNewEventArgs e)
		{
			AddingNewEventHandler addingNew = this._addingNew;
			if (addingNew != null)
			{
				addingNew(this, e);
			}
		}

		// Token: 0x060020DA RID: 8410 RVA: 0x000874F4 File Offset: 0x000856F4
		protected virtual void OnListChanged(ListChangedEventArgs e)
		{
			ListChangedEventHandler listChanged = this._listChanged;
			if (listChanged != null)
			{
				this._busy = true;
				try
				{
					listChanged(this, e);
				}
				finally
				{
					this._busy = false;
				}
			}
		}

		// Token: 0x060020DB RID: 8411 RVA: 0x00087534 File Offset: 0x00085734
		protected virtual void OnCollectionChanged(NotifyCollectionChangedEventArgs e)
		{
			NotifyCollectionChangedEventHandler collectionChanged = this._collectionChanged;
			if (collectionChanged != null)
			{
				this._busy = true;
				try
				{
					collectionChanged(this, e);
				}
				finally
				{
					this._busy = false;
				}
			}
		}

		// Token: 0x170004D6 RID: 1238
		// (get) Token: 0x060020DC RID: 8412 RVA: 0x0001B857 File Offset: 0x00019A57
		public override bool HasValues
		{
			get
			{
				return this.ChildrenTokens.Count > 0;
			}
		}

		// Token: 0x060020DD RID: 8413 RVA: 0x00087574 File Offset: 0x00085774
		internal bool ContentsEqual(JContainer container)
		{
			if (container == this)
			{
				return true;
			}
			IList<JToken> childrenTokens = this.ChildrenTokens;
			IList<JToken> childrenTokens2 = container.ChildrenTokens;
			if (childrenTokens.Count != childrenTokens2.Count)
			{
				return false;
			}
			for (int i = 0; i < childrenTokens.Count; i++)
			{
				if (!childrenTokens[i].DeepEquals(childrenTokens2[i]))
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x170004D7 RID: 1239
		// (get) Token: 0x060020DE RID: 8414 RVA: 0x0001B867 File Offset: 0x00019A67
		public override JToken First
		{
			get
			{
				return this.ChildrenTokens.FirstOrDefault<JToken>();
			}
		}

		// Token: 0x170004D8 RID: 1240
		// (get) Token: 0x060020DF RID: 8415 RVA: 0x0001B874 File Offset: 0x00019A74
		public override JToken Last
		{
			get
			{
				return this.ChildrenTokens.LastOrDefault<JToken>();
			}
		}

		// Token: 0x060020E0 RID: 8416 RVA: 0x0001B881 File Offset: 0x00019A81
		public override JEnumerable<JToken> Children()
		{
			return new JEnumerable<JToken>(this.ChildrenTokens);
		}

		// Token: 0x060020E1 RID: 8417 RVA: 0x0001B88E File Offset: 0x00019A8E
		public override IEnumerable<T> Values<T>()
		{
			return this.ChildrenTokens.Convert<JToken, T>();
		}

		// Token: 0x060020E2 RID: 8418 RVA: 0x0001B89B File Offset: 0x00019A9B
		public IEnumerable<JToken> Descendants()
		{
			return this.GetDescendants(false);
		}

		// Token: 0x060020E3 RID: 8419 RVA: 0x0001B8A4 File Offset: 0x00019AA4
		public IEnumerable<JToken> DescendantsAndSelf()
		{
			return this.GetDescendants(true);
		}

		// Token: 0x060020E4 RID: 8420 RVA: 0x000875D0 File Offset: 0x000857D0
		internal IEnumerable<JToken> GetDescendants(bool self)
		{
			JContainer.<GetDescendants>d__0 <GetDescendants>d__ = new JContainer.<GetDescendants>d__0(-2);
			<GetDescendants>d__.<>4__this = this;
			<GetDescendants>d__.<>3__self = self;
			return <GetDescendants>d__;
		}

		// Token: 0x060020E5 RID: 8421 RVA: 0x0001B8AD File Offset: 0x00019AAD
		internal bool IsMultiContent(object content)
		{
			return content is IEnumerable && !(content is string) && !(content is JToken) && !(content is byte[]);
		}

		// Token: 0x060020E6 RID: 8422 RVA: 0x0001B8D5 File Offset: 0x00019AD5
		internal JToken EnsureParentToken(JToken item, bool skipParentCheck)
		{
			if (item == null)
			{
				return JValue.CreateNull();
			}
			if (skipParentCheck)
			{
				return item;
			}
			if (item.Parent != null || item == this || (item.HasValues && base.Root == item))
			{
				item = item.CloneToken();
			}
			return item;
		}

		// Token: 0x060020E7 RID: 8423 RVA: 0x0001B90B File Offset: 0x00019B0B
		internal int IndexOfItem(JToken item)
		{
			return this.ChildrenTokens.IndexOf(item, JContainer.JTokenReferenceEqualityComparer.Instance);
		}

		// Token: 0x060020E8 RID: 8424 RVA: 0x000875F4 File Offset: 0x000857F4
		internal virtual void InsertItem(int index, JToken item, bool skipParentCheck)
		{
			if (index > this.ChildrenTokens.Count)
			{
				throw JContainer.smethod_43(<Module>.smethod_24<string>(726512525U), <Module>.smethod_27<string>(3768035887U));
			}
			this.CheckReentrancy();
			item = this.EnsureParentToken(item, skipParentCheck);
			JToken jtoken = ((index == 0) ? null : this.ChildrenTokens[index - 1]);
			JToken jtoken2 = ((index == this.ChildrenTokens.Count) ? null : this.ChildrenTokens[index]);
			this.ValidateToken(item, null);
			item.Parent = this;
			item.Previous = jtoken;
			if (jtoken != null)
			{
				jtoken.Next = item;
			}
			item.Next = jtoken2;
			if (jtoken2 != null)
			{
				jtoken2.Previous = item;
			}
			this.ChildrenTokens.Insert(index, item);
			if (this._listChanged != null)
			{
				this.OnListChanged(JContainer.smethod_44(ListChangedType.ItemAdded, index));
			}
			if (this._collectionChanged != null)
			{
				this.OnCollectionChanged(JContainer.smethod_45(NotifyCollectionChangedAction.Add, item, index));
			}
		}

		// Token: 0x060020E9 RID: 8425 RVA: 0x000876D8 File Offset: 0x000858D8
		internal virtual void RemoveItemAt(int index)
		{
			if (index < 0)
			{
				throw JContainer.smethod_43(<Module>.smethod_24<string>(726512525U), <Module>.smethod_25<string>(3277366908U));
			}
			if (index >= this.ChildrenTokens.Count)
			{
				throw JContainer.smethod_43(<Module>.smethod_25<string>(2094210207U), <Module>.smethod_26<string>(2747773054U));
			}
			this.CheckReentrancy();
			JToken jtoken = this.ChildrenTokens[index];
			JToken jtoken2 = ((index == 0) ? null : this.ChildrenTokens[index - 1]);
			JToken jtoken3 = ((index == this.ChildrenTokens.Count - 1) ? null : this.ChildrenTokens[index + 1]);
			if (jtoken2 != null)
			{
				jtoken2.Next = jtoken3;
			}
			if (jtoken3 != null)
			{
				jtoken3.Previous = jtoken2;
			}
			jtoken.Parent = null;
			jtoken.Previous = null;
			jtoken.Next = null;
			this.ChildrenTokens.RemoveAt(index);
			if (this._listChanged != null)
			{
				this.OnListChanged(JContainer.smethod_44(ListChangedType.ItemDeleted, index));
			}
			if (this._collectionChanged != null)
			{
				this.OnCollectionChanged(JContainer.smethod_45(NotifyCollectionChangedAction.Remove, jtoken, index));
			}
		}

		// Token: 0x060020EA RID: 8426 RVA: 0x000877D8 File Offset: 0x000859D8
		internal virtual bool RemoveItem(JToken item)
		{
			int num = this.IndexOfItem(item);
			if (num >= 0)
			{
				this.RemoveItemAt(num);
				return true;
			}
			return false;
		}

		// Token: 0x060020EB RID: 8427 RVA: 0x0001B91E File Offset: 0x00019B1E
		internal virtual JToken GetItem(int index)
		{
			return this.ChildrenTokens[index];
		}

		// Token: 0x060020EC RID: 8428 RVA: 0x000877FC File Offset: 0x000859FC
		internal virtual void SetItem(int index, JToken item)
		{
			if (index < 0)
			{
				throw JContainer.smethod_43(<Module>.smethod_27<string>(79150600U), <Module>.smethod_23<string>(3351523827U));
			}
			if (index >= this.ChildrenTokens.Count)
			{
				throw JContainer.smethod_43(<Module>.smethod_27<string>(79150600U), <Module>.smethod_26<string>(2747773054U));
			}
			JToken jtoken = this.ChildrenTokens[index];
			if (JContainer.IsTokenUnchanged(jtoken, item))
			{
				return;
			}
			this.CheckReentrancy();
			item = this.EnsureParentToken(item, false);
			this.ValidateToken(item, jtoken);
			JToken jtoken2 = ((index == 0) ? null : this.ChildrenTokens[index - 1]);
			JToken jtoken3 = ((index == this.ChildrenTokens.Count - 1) ? null : this.ChildrenTokens[index + 1]);
			item.Parent = this;
			item.Previous = jtoken2;
			if (jtoken2 != null)
			{
				jtoken2.Next = item;
			}
			item.Next = jtoken3;
			if (jtoken3 != null)
			{
				jtoken3.Previous = item;
			}
			this.ChildrenTokens[index] = item;
			jtoken.Parent = null;
			jtoken.Previous = null;
			jtoken.Next = null;
			if (this._listChanged != null)
			{
				this.OnListChanged(JContainer.smethod_44(ListChangedType.ItemChanged, index));
			}
			if (this._collectionChanged != null)
			{
				this.OnCollectionChanged(JContainer.smethod_46(NotifyCollectionChangedAction.Replace, item, jtoken, index));
			}
		}

		// Token: 0x060020ED RID: 8429 RVA: 0x0008792C File Offset: 0x00085B2C
		internal virtual void ClearItems()
		{
			this.CheckReentrancy();
			IEnumerator<JToken> enumerator = this.ChildrenTokens.GetEnumerator();
			try
			{
				while (JContainer.smethod_38(enumerator))
				{
					JToken jtoken = enumerator.Current;
					jtoken.Parent = null;
					jtoken.Previous = null;
					jtoken.Next = null;
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JContainer.smethod_39(enumerator);
				}
			}
			this.ChildrenTokens.Clear();
			if (this._listChanged != null)
			{
				this.OnListChanged(JContainer.smethod_44(ListChangedType.Reset, -1));
			}
			if (this._collectionChanged != null)
			{
				this.OnCollectionChanged(JContainer.smethod_47(NotifyCollectionChangedAction.Reset));
			}
		}

		// Token: 0x060020EE RID: 8430 RVA: 0x000879C4 File Offset: 0x00085BC4
		internal virtual void ReplaceItem(JToken existing, JToken replacement)
		{
			if (existing != null)
			{
				if (existing.Parent == this)
				{
					int num = this.IndexOfItem(existing);
					this.SetItem(num, replacement);
					return;
				}
			}
		}

		// Token: 0x060020EF RID: 8431 RVA: 0x0001B92C File Offset: 0x00019B2C
		internal virtual bool ContainsItem(JToken item)
		{
			return this.IndexOfItem(item) != -1;
		}

		// Token: 0x060020F0 RID: 8432 RVA: 0x000879F0 File Offset: 0x00085BF0
		internal virtual void CopyItemsTo(Array array, int arrayIndex)
		{
			if (array == null)
			{
				throw JContainer.smethod_48(<Module>.smethod_25<string>(4251731250U));
			}
			if (arrayIndex < 0)
			{
				throw JContainer.smethod_43(<Module>.smethod_25<string>(542991451U), <Module>.smethod_25<string>(264601639U));
			}
			if (arrayIndex >= JContainer.smethod_49(array) && arrayIndex != 0)
			{
				throw JContainer.smethod_50(<Module>.smethod_25<string>(821381263U));
			}
			if (this.Count > JContainer.smethod_49(array) - arrayIndex)
			{
				throw JContainer.smethod_50(<Module>.smethod_26<string>(1185239904U));
			}
			int num = 0;
			IEnumerator<JToken> enumerator = this.ChildrenTokens.GetEnumerator();
			try
			{
				while (JContainer.smethod_38(enumerator))
				{
					JToken jtoken = enumerator.Current;
					JContainer.smethod_51(array, jtoken, arrayIndex + num);
					num++;
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JContainer.smethod_39(enumerator);
				}
			}
		}

		// Token: 0x060020F1 RID: 8433 RVA: 0x00087AB4 File Offset: 0x00085CB4
		internal static bool IsTokenUnchanged(JToken currentValue, JToken newValue)
		{
			JValue jvalue = currentValue as JValue;
			return jvalue != null && ((jvalue.Type == JTokenType.Null && newValue == null) || JContainer.smethod_52(jvalue, newValue));
		}

		// Token: 0x060020F2 RID: 8434 RVA: 0x00087AE4 File Offset: 0x00085CE4
		internal virtual void ValidateToken(JToken o, JToken existing)
		{
			ValidationUtils.ArgumentNotNull(o, <Module>.smethod_26<string>(620414310U));
			if (o.Type == JTokenType.Property)
			{
				throw JContainer.smethod_50(<Module>.smethod_27<string>(2637572175U).FormatWith(JContainer.smethod_40(), JContainer.smethod_53(o), JContainer.smethod_41(this)));
			}
		}

		// Token: 0x060020F3 RID: 8435 RVA: 0x0001B93B File Offset: 0x00019B3B
		public virtual void Add(object content)
		{
			this.AddInternal(this.ChildrenTokens.Count, content, false);
		}

		// Token: 0x060020F4 RID: 8436 RVA: 0x0001B950 File Offset: 0x00019B50
		internal void AddAndSkipParentCheck(JToken token)
		{
			this.AddInternal(this.ChildrenTokens.Count, token, true);
		}

		// Token: 0x060020F5 RID: 8437 RVA: 0x0001B965 File Offset: 0x00019B65
		public void AddFirst(object content)
		{
			this.AddInternal(0, content, false);
		}

		// Token: 0x060020F6 RID: 8438 RVA: 0x00087B30 File Offset: 0x00085D30
		internal void AddInternal(int index, object content, bool skipParentCheck)
		{
			if (this.IsMultiContent(content))
			{
				IEnumerable enumerable = (IEnumerable)content;
				int num = index;
				IEnumerator enumerator = JContainer.smethod_54(enumerable);
				try
				{
					while (JContainer.smethod_38(enumerator))
					{
						object obj = JContainer.smethod_55(enumerator);
						this.AddInternal(num, obj, skipParentCheck);
						num++;
					}
					return;
				}
				finally
				{
					IDisposable disposable = enumerator as IDisposable;
					if (disposable != null)
					{
						JContainer.smethod_39(disposable);
					}
				}
			}
			JToken jtoken = JContainer.CreateFromContent(content);
			this.InsertItem(index, jtoken, skipParentCheck);
		}

		// Token: 0x060020F7 RID: 8439 RVA: 0x0001B970 File Offset: 0x00019B70
		internal static JToken CreateFromContent(object content)
		{
			if (content is JToken)
			{
				return (JToken)content;
			}
			return new JValue(content);
		}

		// Token: 0x060020F8 RID: 8440 RVA: 0x0001B987 File Offset: 0x00019B87
		public JsonWriter CreateWriter()
		{
			return new JTokenWriter(this);
		}

		// Token: 0x060020F9 RID: 8441 RVA: 0x0001B98F File Offset: 0x00019B8F
		public void ReplaceAll(object content)
		{
			this.ClearItems();
			this.Add(content);
		}

		// Token: 0x060020FA RID: 8442 RVA: 0x0001B99E File Offset: 0x00019B9E
		public void RemoveAll()
		{
			this.ClearItems();
		}

		// Token: 0x060020FB RID: 8443
		internal abstract void MergeItem(object content, JsonMergeSettings settings);

		// Token: 0x060020FC RID: 8444 RVA: 0x0001B9A6 File Offset: 0x00019BA6
		public void Merge(object content)
		{
			this.MergeItem(content, new JsonMergeSettings());
		}

		// Token: 0x060020FD RID: 8445 RVA: 0x0001B9B4 File Offset: 0x00019BB4
		public void Merge(object content, JsonMergeSettings settings)
		{
			this.MergeItem(content, settings);
		}

		// Token: 0x060020FE RID: 8446 RVA: 0x00087BB0 File Offset: 0x00085DB0
		internal void ReadTokenFrom(JsonReader reader)
		{
			int depth = reader.Depth;
			if (!reader.Read())
			{
				throw JsonReaderException.Create(reader, <Module>.smethod_27<string>(2777437254U).FormatWith(JContainer.smethod_40(), JContainer.smethod_56(JContainer.smethod_41(this))));
			}
			this.ReadContentFrom(reader);
			int depth2 = reader.Depth;
			if (depth2 > depth)
			{
				throw JsonReaderException.Create(reader, <Module>.smethod_27<string>(1938246780U).FormatWith(JContainer.smethod_40(), JContainer.smethod_56(JContainer.smethod_41(this))));
			}
		}

		// Token: 0x060020FF RID: 8447 RVA: 0x00087C2C File Offset: 0x00085E2C
		internal void ReadContentFrom(JsonReader r)
		{
			ValidationUtils.ArgumentNotNull(r, <Module>.smethod_24<string>(2195937293U));
			IJsonLineInfo jsonLineInfo = r as IJsonLineInfo;
			JContainer jcontainer = this;
			for (;;)
			{
				if (jcontainer is JProperty && ((JProperty)jcontainer).Value != null)
				{
					if (jcontainer == this)
					{
						return;
					}
					jcontainer = jcontainer.Parent;
				}
				switch (r.TokenType)
				{
				case JsonToken.None:
					goto IL_01D8;
				case JsonToken.StartObject:
				{
					JObject jobject = new JObject();
					jobject.SetLineInfo(jsonLineInfo);
					jcontainer.Add(jobject);
					jcontainer = jobject;
					goto IL_01D8;
				}
				case JsonToken.StartArray:
				{
					JArray jarray = new JArray();
					jarray.SetLineInfo(jsonLineInfo);
					jcontainer.Add(jarray);
					jcontainer = jarray;
					goto IL_01D8;
				}
				case JsonToken.StartConstructor:
				{
					JConstructor jconstructor = new JConstructor(JContainer.smethod_57(r.Value));
					jconstructor.SetLineInfo(jsonLineInfo);
					jcontainer.Add(jconstructor);
					jcontainer = jconstructor;
					goto IL_01D8;
				}
				case JsonToken.PropertyName:
				{
					string text = JContainer.smethod_57(r.Value);
					JProperty jproperty = new JProperty(text);
					jproperty.SetLineInfo(jsonLineInfo);
					JObject jobject2 = (JObject)jcontainer;
					JProperty jproperty2 = jobject2.Property(text);
					if (jproperty2 == null)
					{
						jcontainer.Add(jproperty);
					}
					else
					{
						jproperty2.Replace(jproperty);
					}
					jcontainer = jproperty;
					goto IL_01D8;
				}
				case JsonToken.Comment:
				{
					JValue jvalue = JValue.CreateComment(JContainer.smethod_57(r.Value));
					jvalue.SetLineInfo(jsonLineInfo);
					jcontainer.Add(jvalue);
					goto IL_01D8;
				}
				case JsonToken.Integer:
				case JsonToken.Float:
				case JsonToken.String:
				case JsonToken.Boolean:
				case JsonToken.Date:
				case JsonToken.Bytes:
				{
					JValue jvalue = new JValue(r.Value);
					jvalue.SetLineInfo(jsonLineInfo);
					jcontainer.Add(jvalue);
					goto IL_01D8;
				}
				case JsonToken.Null:
				{
					JValue jvalue = JValue.CreateNull();
					jvalue.SetLineInfo(jsonLineInfo);
					jcontainer.Add(jvalue);
					goto IL_01D8;
				}
				case JsonToken.Undefined:
				{
					JValue jvalue = JValue.CreateUndefined();
					jvalue.SetLineInfo(jsonLineInfo);
					jcontainer.Add(jvalue);
					goto IL_01D8;
				}
				case JsonToken.EndObject:
					if (jcontainer == this)
					{
						return;
					}
					jcontainer = jcontainer.Parent;
					goto IL_01D8;
				case JsonToken.EndArray:
					if (jcontainer == this)
					{
						return;
					}
					jcontainer = jcontainer.Parent;
					goto IL_01D8;
				case JsonToken.EndConstructor:
					if (jcontainer == this)
					{
						return;
					}
					jcontainer = jcontainer.Parent;
					goto IL_01D8;
				}
				break;
				IL_01D8:
				if (!r.Read())
				{
					return;
				}
			}
			throw JContainer.smethod_42(<Module>.smethod_26<string>(3534618290U).FormatWith(JContainer.smethod_40(), r.TokenType));
		}

		// Token: 0x06002100 RID: 8448 RVA: 0x00087E74 File Offset: 0x00086074
		internal int ContentsHashCode()
		{
			int num = 0;
			IEnumerator<JToken> enumerator = this.ChildrenTokens.GetEnumerator();
			try
			{
				while (JContainer.smethod_38(enumerator))
				{
					JToken jtoken = enumerator.Current;
					num ^= jtoken.GetDeepHashCode();
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JContainer.smethod_39(enumerator);
				}
			}
			return num;
		}

		// Token: 0x06002101 RID: 8449 RVA: 0x0001B9BE File Offset: 0x00019BBE
		string ITypedList.GetListName(PropertyDescriptor[] listAccessors)
		{
			return string.Empty;
		}

		// Token: 0x06002102 RID: 8450 RVA: 0x00087EC8 File Offset: 0x000860C8
		PropertyDescriptorCollection ITypedList.GetItemProperties(PropertyDescriptor[] listAccessors)
		{
			ICustomTypeDescriptor customTypeDescriptor = this.First as ICustomTypeDescriptor;
			if (customTypeDescriptor != null)
			{
				return JContainer.smethod_58(customTypeDescriptor);
			}
			return null;
		}

		// Token: 0x06002103 RID: 8451 RVA: 0x0001B9C5 File Offset: 0x00019BC5
		int IList<JToken>.IndexOf(JToken item)
		{
			return this.IndexOfItem(item);
		}

		// Token: 0x06002104 RID: 8452 RVA: 0x0001B9CE File Offset: 0x00019BCE
		void IList<JToken>.Insert(int index, JToken item)
		{
			this.InsertItem(index, item, false);
		}

		// Token: 0x06002105 RID: 8453 RVA: 0x0001B9D9 File Offset: 0x00019BD9
		void IList<JToken>.RemoveAt(int index)
		{
			this.RemoveItemAt(index);
		}

		// Token: 0x170004D9 RID: 1241
		JToken IList<JToken>.this[int index]
		{
			get
			{
				return this.GetItem(index);
			}
			set
			{
				this.SetItem(index, value);
			}
		}

		// Token: 0x06002108 RID: 8456 RVA: 0x0001B9F5 File Offset: 0x00019BF5
		void ICollection<JToken>.Add(JToken item)
		{
			this.Add(item);
		}

		// Token: 0x06002109 RID: 8457 RVA: 0x0001B99E File Offset: 0x00019B9E
		void ICollection<JToken>.Clear()
		{
			this.ClearItems();
		}

		// Token: 0x0600210A RID: 8458 RVA: 0x0001B9FE File Offset: 0x00019BFE
		bool ICollection<JToken>.Contains(JToken item)
		{
			return this.ContainsItem(item);
		}

		// Token: 0x0600210B RID: 8459 RVA: 0x0001BA07 File Offset: 0x00019C07
		void ICollection<JToken>.CopyTo(JToken[] array, int arrayIndex)
		{
			this.CopyItemsTo(array, arrayIndex);
		}

		// Token: 0x170004DA RID: 1242
		// (get) Token: 0x0600210C RID: 8460 RVA: 0x0000C17A File Offset: 0x0000A37A
		bool ICollection<JToken>.IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x0600210D RID: 8461 RVA: 0x0001BA11 File Offset: 0x00019C11
		bool ICollection<JToken>.Remove(JToken item)
		{
			return this.RemoveItem(item);
		}

		// Token: 0x0600210E RID: 8462 RVA: 0x00087EEC File Offset: 0x000860EC
		private JToken EnsureValue(object value)
		{
			if (value == null)
			{
				goto IL_003B;
			}
			if (!(value is JToken))
			{
				throw JContainer.smethod_50(<Module>.smethod_23<string>(2102903192U));
			}
			int num = 1985621134;
			IL_0022:
			switch (num ^ 1985621135)
			{
			case 0:
				IL_003B:
				num = 1985621133;
				goto IL_0022;
			case 2:
				return null;
			}
			return (JToken)value;
		}

		// Token: 0x0600210F RID: 8463 RVA: 0x0001BA1A File Offset: 0x00019C1A
		int IList.Add(object value)
		{
			this.Add(this.EnsureValue(value));
			return this.Count - 1;
		}

		// Token: 0x06002110 RID: 8464 RVA: 0x0001B99E File Offset: 0x00019B9E
		void IList.Clear()
		{
			this.ClearItems();
		}

		// Token: 0x06002111 RID: 8465 RVA: 0x0001BA31 File Offset: 0x00019C31
		bool IList.Contains(object value)
		{
			return this.ContainsItem(this.EnsureValue(value));
		}

		// Token: 0x06002112 RID: 8466 RVA: 0x0001BA40 File Offset: 0x00019C40
		int IList.IndexOf(object value)
		{
			return this.IndexOfItem(this.EnsureValue(value));
		}

		// Token: 0x06002113 RID: 8467 RVA: 0x0001BA4F File Offset: 0x00019C4F
		void IList.Insert(int index, object value)
		{
			this.InsertItem(index, this.EnsureValue(value), false);
		}

		// Token: 0x170004DB RID: 1243
		// (get) Token: 0x06002114 RID: 8468 RVA: 0x0000C17A File Offset: 0x0000A37A
		bool IList.IsFixedSize
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170004DC RID: 1244
		// (get) Token: 0x06002115 RID: 8469 RVA: 0x0000C17A File Offset: 0x0000A37A
		bool IList.IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x06002116 RID: 8470 RVA: 0x0001BA60 File Offset: 0x00019C60
		void IList.Remove(object value)
		{
			this.RemoveItem(this.EnsureValue(value));
		}

		// Token: 0x06002117 RID: 8471 RVA: 0x0001B9D9 File Offset: 0x00019BD9
		void IList.RemoveAt(int index)
		{
			this.RemoveItemAt(index);
		}

		// Token: 0x170004DD RID: 1245
		object IList.this[int index]
		{
			get
			{
				return this.GetItem(index);
			}
			set
			{
				this.SetItem(index, this.EnsureValue(value));
			}
		}

		// Token: 0x0600211A RID: 8474 RVA: 0x0001BA07 File Offset: 0x00019C07
		void ICollection.CopyTo(Array array, int index)
		{
			this.CopyItemsTo(array, index);
		}

		// Token: 0x170004DE RID: 1246
		// (get) Token: 0x0600211B RID: 8475 RVA: 0x0001BA80 File Offset: 0x00019C80
		public int Count
		{
			get
			{
				return this.ChildrenTokens.Count;
			}
		}

		// Token: 0x170004DF RID: 1247
		// (get) Token: 0x0600211C RID: 8476 RVA: 0x0000C17A File Offset: 0x0000A37A
		bool ICollection.IsSynchronized
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170004E0 RID: 1248
		// (get) Token: 0x0600211D RID: 8477 RVA: 0x0001BA8D File Offset: 0x00019C8D
		object ICollection.SyncRoot
		{
			get
			{
				if (this._syncRoot == null)
				{
					JContainer.smethod_60(ref this._syncRoot, JContainer.smethod_59(), null);
				}
				return this._syncRoot;
			}
		}

		// Token: 0x0600211E RID: 8478 RVA: 0x0000C600 File Offset: 0x0000A800
		void IBindingList.AddIndex(PropertyDescriptor property)
		{
		}

		// Token: 0x0600211F RID: 8479 RVA: 0x00087F44 File Offset: 0x00086144
		object IBindingList.AddNew()
		{
			AddingNewEventArgs addingNewEventArgs = JContainer.smethod_61();
			this.OnAddingNew(addingNewEventArgs);
			if (JContainer.smethod_62(addingNewEventArgs) == null)
			{
				throw new JsonException(<Module>.smethod_25<string>(3446009687U).FormatWith(JContainer.smethod_40(), JContainer.smethod_41(this)));
			}
			if (!(JContainer.smethod_62(addingNewEventArgs) is JToken))
			{
				throw new JsonException(<Module>.smethod_26<string>(1238700535U).FormatWith(JContainer.smethod_40(), JContainer.smethod_63(typeof(JToken).TypeHandle)));
			}
			JToken jtoken = (JToken)JContainer.smethod_62(addingNewEventArgs);
			this.Add(jtoken);
			return jtoken;
		}

		// Token: 0x170004E1 RID: 1249
		// (get) Token: 0x06002120 RID: 8480 RVA: 0x0000ED8C File Offset: 0x0000CF8C
		bool IBindingList.AllowEdit
		{
			get
			{
				return true;
			}
		}

		// Token: 0x170004E2 RID: 1250
		// (get) Token: 0x06002121 RID: 8481 RVA: 0x0000ED8C File Offset: 0x0000CF8C
		bool IBindingList.AllowNew
		{
			get
			{
				return true;
			}
		}

		// Token: 0x170004E3 RID: 1251
		// (get) Token: 0x06002122 RID: 8482 RVA: 0x0000ED8C File Offset: 0x0000CF8C
		bool IBindingList.AllowRemove
		{
			get
			{
				return true;
			}
		}

		// Token: 0x06002123 RID: 8483 RVA: 0x0001BAAF File Offset: 0x00019CAF
		void IBindingList.ApplySort(PropertyDescriptor property, ListSortDirection direction)
		{
			throw JContainer.smethod_64();
		}

		// Token: 0x06002124 RID: 8484 RVA: 0x0001BAAF File Offset: 0x00019CAF
		int IBindingList.Find(PropertyDescriptor property, object key)
		{
			throw JContainer.smethod_64();
		}

		// Token: 0x170004E4 RID: 1252
		// (get) Token: 0x06002125 RID: 8485 RVA: 0x0000C17A File Offset: 0x0000A37A
		bool IBindingList.IsSorted
		{
			get
			{
				return false;
			}
		}

		// Token: 0x06002126 RID: 8486 RVA: 0x0000C600 File Offset: 0x0000A800
		void IBindingList.RemoveIndex(PropertyDescriptor property)
		{
		}

		// Token: 0x06002127 RID: 8487 RVA: 0x0001BAAF File Offset: 0x00019CAF
		void IBindingList.RemoveSort()
		{
			throw JContainer.smethod_64();
		}

		// Token: 0x170004E5 RID: 1253
		// (get) Token: 0x06002128 RID: 8488 RVA: 0x0000C17A File Offset: 0x0000A37A
		ListSortDirection IBindingList.SortDirection
		{
			get
			{
				return ListSortDirection.Ascending;
			}
		}

		// Token: 0x170004E6 RID: 1254
		// (get) Token: 0x06002129 RID: 8489 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		PropertyDescriptor IBindingList.SortProperty
		{
			get
			{
				return null;
			}
		}

		// Token: 0x170004E7 RID: 1255
		// (get) Token: 0x0600212A RID: 8490 RVA: 0x0000ED8C File Offset: 0x0000CF8C
		bool IBindingList.SupportsChangeNotification
		{
			get
			{
				return true;
			}
		}

		// Token: 0x170004E8 RID: 1256
		// (get) Token: 0x0600212B RID: 8491 RVA: 0x0000C17A File Offset: 0x0000A37A
		bool IBindingList.SupportsSearching
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170004E9 RID: 1257
		// (get) Token: 0x0600212C RID: 8492 RVA: 0x0000C17A File Offset: 0x0000A37A
		bool IBindingList.SupportsSorting
		{
			get
			{
				return false;
			}
		}

		// Token: 0x0600212D RID: 8493 RVA: 0x00087FCC File Offset: 0x000861CC
		internal static void MergeEnumerableContent(JContainer target, IEnumerable content, JsonMergeSettings settings)
		{
			switch (settings.MergeArrayHandling)
			{
			case MergeArrayHandling.Concat:
			{
				IEnumerator enumerator = JContainer.smethod_54(content);
				try
				{
					while (JContainer.smethod_38(enumerator))
					{
						JToken jtoken = (JToken)JContainer.smethod_55(enumerator);
						target.Add(jtoken);
					}
					return;
				}
				finally
				{
					IDisposable disposable = enumerator as IDisposable;
					if (disposable != null)
					{
						JContainer.smethod_39(disposable);
					}
				}
				break;
			}
			case MergeArrayHandling.Union:
				break;
			case MergeArrayHandling.Replace:
				goto IL_00CE;
			case MergeArrayHandling.Merge:
				goto IL_0118;
			default:
				throw JContainer.smethod_43(<Module>.smethod_26<string>(1981661534U), <Module>.smethod_24<string>(1774722540U));
			}
			HashSet<JToken> hashSet = new HashSet<JToken>(target, JToken.EqualityComparer);
			IEnumerator enumerator2 = JContainer.smethod_54(content);
			try
			{
				while (JContainer.smethod_38(enumerator2))
				{
					JToken jtoken2 = (JToken)JContainer.smethod_55(enumerator2);
					if (hashSet.Add(jtoken2))
					{
						target.Add(jtoken2);
					}
				}
				return;
			}
			finally
			{
				IDisposable disposable2 = enumerator2 as IDisposable;
				if (disposable2 != null)
				{
					JContainer.smethod_39(disposable2);
				}
			}
			IL_00CE:
			target.ClearItems();
			IEnumerator enumerator3 = JContainer.smethod_54(content);
			try
			{
				while (JContainer.smethod_38(enumerator3))
				{
					JToken jtoken3 = (JToken)JContainer.smethod_55(enumerator3);
					target.Add(jtoken3);
				}
				return;
			}
			finally
			{
				IDisposable disposable3 = enumerator3 as IDisposable;
				if (disposable3 != null)
				{
					JContainer.smethod_39(disposable3);
				}
			}
			IL_0118:
			int num = 0;
			IEnumerator enumerator4 = JContainer.smethod_54(content);
			try
			{
				while (JContainer.smethod_38(enumerator4))
				{
					object obj = JContainer.smethod_55(enumerator4);
					if (num >= target.Count)
					{
						target.Add(obj);
					}
					else
					{
						JToken jtoken4 = target[num];
						JContainer jcontainer = jtoken4 as JContainer;
						if (jcontainer == null)
						{
							if (obj != null)
							{
								JToken jtoken5 = JContainer.CreateFromContent(obj);
								if (jtoken5.Type != JTokenType.Null)
								{
									target[num] = jtoken5;
								}
							}
						}
						else
						{
							jcontainer.Merge(obj, settings);
						}
					}
					num++;
				}
			}
			finally
			{
				IDisposable disposable4 = enumerator4 as IDisposable;
				if (disposable4 != null)
				{
					JContainer.smethod_39(disposable4);
				}
			}
		}

		// Token: 0x0600212E RID: 8494 RVA: 0x0000CD19 File Offset: 0x0000AF19
		static Delegate smethod_36(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Combine(delegate_0, delegate_1);
		}

		// Token: 0x0600212F RID: 8495 RVA: 0x0000CD22 File Offset: 0x0000AF22
		static Delegate smethod_37(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Remove(delegate_0, delegate_1);
		}

		// Token: 0x06002130 RID: 8496 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_38(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06002131 RID: 8497 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_39(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06002132 RID: 8498 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_40()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06002133 RID: 8499 RVA: 0x0001040D File Offset: 0x0000E60D
		static Type smethod_41(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06002134 RID: 8500 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_42(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x06002135 RID: 8501 RVA: 0x0000DECA File Offset: 0x0000C0CA
		static ArgumentOutOfRangeException smethod_43(string string_0, string string_1)
		{
			return new ArgumentOutOfRangeException(string_0, string_1);
		}

		// Token: 0x06002136 RID: 8502 RVA: 0x0001BAB6 File Offset: 0x00019CB6
		static ListChangedEventArgs smethod_44(ListChangedType listChangedType_0, int int_0)
		{
			return new ListChangedEventArgs(listChangedType_0, int_0);
		}

		// Token: 0x06002137 RID: 8503 RVA: 0x0001BABF File Offset: 0x00019CBF
		static NotifyCollectionChangedEventArgs smethod_45(NotifyCollectionChangedAction notifyCollectionChangedAction_0, object object_0, int int_0)
		{
			return new NotifyCollectionChangedEventArgs(notifyCollectionChangedAction_0, object_0, int_0);
		}

		// Token: 0x06002138 RID: 8504 RVA: 0x0001BAC9 File Offset: 0x00019CC9
		static NotifyCollectionChangedEventArgs smethod_46(NotifyCollectionChangedAction notifyCollectionChangedAction_0, object object_0, object object_1, int int_0)
		{
			return new NotifyCollectionChangedEventArgs(notifyCollectionChangedAction_0, object_0, object_1, int_0);
		}

		// Token: 0x06002139 RID: 8505 RVA: 0x0001BAD4 File Offset: 0x00019CD4
		static NotifyCollectionChangedEventArgs smethod_47(NotifyCollectionChangedAction notifyCollectionChangedAction_0)
		{
			return new NotifyCollectionChangedEventArgs(notifyCollectionChangedAction_0);
		}

		// Token: 0x0600213A RID: 8506 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_48(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x0600213B RID: 8507 RVA: 0x0001BADC File Offset: 0x00019CDC
		static int smethod_49(Array array_0)
		{
			return array_0.Length;
		}

		// Token: 0x0600213C RID: 8508 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_50(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x0600213D RID: 8509 RVA: 0x000162F9 File Offset: 0x000144F9
		static void smethod_51(Array array_0, object object_0, int int_0)
		{
			array_0.SetValue(object_0, int_0);
		}

		// Token: 0x0600213E RID: 8510 RVA: 0x0000ED73 File Offset: 0x0000CF73
		static bool smethod_52(object object_0, object object_1)
		{
			return object_0.Equals(object_1);
		}

		// Token: 0x0600213F RID: 8511 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_53(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06002140 RID: 8512 RVA: 0x0000DAD6 File Offset: 0x0000BCD6
		static IEnumerator smethod_54(IEnumerable ienumerable_0)
		{
			return ienumerable_0.GetEnumerator();
		}

		// Token: 0x06002141 RID: 8513 RVA: 0x0000D8E2 File Offset: 0x0000BAE2
		static object smethod_55(IEnumerator ienumerator_0)
		{
			return ienumerator_0.Current;
		}

		// Token: 0x06002142 RID: 8514 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_56(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x06002143 RID: 8515 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_57(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06002144 RID: 8516 RVA: 0x0001BAE4 File Offset: 0x00019CE4
		static PropertyDescriptorCollection smethod_58(ICustomTypeDescriptor icustomTypeDescriptor_0)
		{
			return icustomTypeDescriptor_0.GetProperties();
		}

		// Token: 0x06002145 RID: 8517 RVA: 0x00013209 File Offset: 0x00011409
		static object smethod_59()
		{
			return new object();
		}

		// Token: 0x06002146 RID: 8518 RVA: 0x0001BAEC File Offset: 0x00019CEC
		static object smethod_60(ref object object_0, object object_1, object object_2)
		{
			return Interlocked.CompareExchange(ref object_0, object_1, object_2);
		}

		// Token: 0x06002147 RID: 8519 RVA: 0x0001BAF6 File Offset: 0x00019CF6
		static AddingNewEventArgs smethod_61()
		{
			return new AddingNewEventArgs();
		}

		// Token: 0x06002148 RID: 8520 RVA: 0x0001BAFD File Offset: 0x00019CFD
		static object smethod_62(AddingNewEventArgs addingNewEventArgs_0)
		{
			return addingNewEventArgs_0.NewObject;
		}

		// Token: 0x06002149 RID: 8521 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_63(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return global::System.Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x0600214A RID: 8522 RVA: 0x0000E031 File Offset: 0x0000C231
		static NotSupportedException smethod_64()
		{
			return new NotSupportedException();
		}

		// Token: 0x04000BFC RID: 3068
		internal ListChangedEventHandler _listChanged;

		// Token: 0x04000BFD RID: 3069
		internal AddingNewEventHandler _addingNew;

		// Token: 0x04000BFE RID: 3070
		internal NotifyCollectionChangedEventHandler _collectionChanged;

		// Token: 0x04000BFF RID: 3071
		private object _syncRoot;

		// Token: 0x04000C00 RID: 3072
		private bool _busy;

		// Token: 0x02000239 RID: 569
		private class JTokenReferenceEqualityComparer : IEqualityComparer<JToken>
		{
			// Token: 0x0600214B RID: 8523 RVA: 0x0001BB05 File Offset: 0x00019D05
			public bool Equals(JToken x, JToken y)
			{
				return JContainer.JTokenReferenceEqualityComparer.smethod_0(x, y);
			}

			// Token: 0x0600214C RID: 8524 RVA: 0x0001BB0E File Offset: 0x00019D0E
			public int GetHashCode(JToken obj)
			{
				if (obj == null)
				{
					return 0;
				}
				return JContainer.JTokenReferenceEqualityComparer.smethod_1(obj);
			}

			// Token: 0x0600214F RID: 8527 RVA: 0x0000F49D File Offset: 0x0000D69D
			static bool smethod_0(object object_0, object object_1)
			{
				return object.ReferenceEquals(object_0, object_1);
			}

			// Token: 0x06002150 RID: 8528 RVA: 0x0000CF7A File Offset: 0x0000B17A
			static int smethod_1(object object_0)
			{
				return object_0.GetHashCode();
			}

			// Token: 0x04000C01 RID: 3073
			public static readonly JContainer.JTokenReferenceEqualityComparer Instance = new JContainer.JTokenReferenceEqualityComparer();
		}
	}
}
