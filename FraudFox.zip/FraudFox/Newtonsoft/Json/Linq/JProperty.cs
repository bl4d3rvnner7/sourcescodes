﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x02000243 RID: 579
	public class JProperty : JContainer
	{
		// Token: 0x17000505 RID: 1285
		// (get) Token: 0x06002248 RID: 8776 RVA: 0x0001C343 File Offset: 0x0001A543
		protected override IList<JToken> ChildrenTokens
		{
			get
			{
				return this._content;
			}
		}

		// Token: 0x17000506 RID: 1286
		// (get) Token: 0x06002249 RID: 8777 RVA: 0x0001C34B File Offset: 0x0001A54B
		public string Name
		{
			[DebuggerStepThrough]
			get
			{
				return this._name;
			}
		}

		// Token: 0x17000507 RID: 1287
		// (get) Token: 0x0600224A RID: 8778 RVA: 0x0001C353 File Offset: 0x0001A553
		// (set) Token: 0x0600224B RID: 8779 RVA: 0x00089808 File Offset: 0x00087A08
		public new JToken Value
		{
			[DebuggerStepThrough]
			get
			{
				return this._content._token;
			}
			set
			{
				base.CheckReentrancy();
				JToken jtoken = value ?? JValue.CreateNull();
				if (this._content._token == null)
				{
					this.InsertItem(0, jtoken, false);
					return;
				}
				this.SetItem(0, jtoken);
			}
		}

		// Token: 0x0600224C RID: 8780 RVA: 0x0001C360 File Offset: 0x0001A560
		public JProperty(JProperty other)
			: base(other)
		{
			this._name = other.Name;
		}

		// Token: 0x0600224D RID: 8781 RVA: 0x0001C380 File Offset: 0x0001A580
		internal override JToken GetItem(int index)
		{
			if (index != 0)
			{
				throw JProperty.smethod_65();
			}
			return this.Value;
		}

		// Token: 0x0600224E RID: 8782 RVA: 0x00089848 File Offset: 0x00087A48
		internal override void SetItem(int index, JToken item)
		{
			if (index != 0)
			{
				throw JProperty.smethod_65();
			}
			if (JContainer.IsTokenUnchanged(this.Value, item))
			{
				return;
			}
			if (base.Parent != null)
			{
				((JObject)base.Parent).InternalPropertyChanging(this);
			}
			base.SetItem(0, item);
			if (base.Parent != null)
			{
				((JObject)base.Parent).InternalPropertyChanged(this);
			}
		}

		// Token: 0x0600224F RID: 8783 RVA: 0x0001C391 File Offset: 0x0001A591
		internal override bool RemoveItem(JToken item)
		{
			throw new JsonException(<Module>.smethod_26<string>(2410182459U).FormatWith(JProperty.smethod_66(), JProperty.smethod_67(typeof(JProperty).TypeHandle)));
		}

		// Token: 0x06002250 RID: 8784 RVA: 0x0001C3B6 File Offset: 0x0001A5B6
		internal override void RemoveItemAt(int index)
		{
			throw new JsonException(<Module>.smethod_25<string>(1552118162U).FormatWith(JProperty.smethod_66(), JProperty.smethod_67(typeof(JProperty).TypeHandle)));
		}

		// Token: 0x06002251 RID: 8785 RVA: 0x000898A8 File Offset: 0x00087AA8
		internal override void InsertItem(int index, JToken item, bool skipParentCheck)
		{
			if (item != null)
			{
				if (item.Type == JTokenType.Comment)
				{
					return;
				}
			}
			if (this.Value != null)
			{
				throw new JsonException(<Module>.smethod_23<string>(1815550815U).FormatWith(JProperty.smethod_66(), JProperty.smethod_67(typeof(JProperty).TypeHandle)));
			}
			base.InsertItem(0, item, false);
		}

		// Token: 0x06002252 RID: 8786 RVA: 0x0001C3DB File Offset: 0x0001A5DB
		internal override bool ContainsItem(JToken item)
		{
			return this.Value == item;
		}

		// Token: 0x06002253 RID: 8787 RVA: 0x000898FC File Offset: 0x00087AFC
		internal override void MergeItem(object content, JsonMergeSettings settings)
		{
			JProperty jproperty = content as JProperty;
			if (jproperty == null)
			{
				return;
			}
			if (jproperty.Value != null)
			{
				if (jproperty.Value.Type != JTokenType.Null)
				{
					this.Value = jproperty.Value;
				}
			}
		}

		// Token: 0x06002254 RID: 8788 RVA: 0x0001C3E6 File Offset: 0x0001A5E6
		internal override void ClearItems()
		{
			throw new JsonException(<Module>.smethod_27<string>(2830729233U).FormatWith(JProperty.smethod_66(), JProperty.smethod_67(typeof(JProperty).TypeHandle)));
		}

		// Token: 0x06002255 RID: 8789 RVA: 0x0008993C File Offset: 0x00087B3C
		internal override bool DeepEquals(JToken node)
		{
			JProperty jproperty = node as JProperty;
			return jproperty != null && JProperty.smethod_68(this._name, jproperty.Name) && base.ContentsEqual(jproperty);
		}

		// Token: 0x06002256 RID: 8790 RVA: 0x0001C40B File Offset: 0x0001A60B
		internal override JToken CloneToken()
		{
			return new JProperty(this);
		}

		// Token: 0x17000508 RID: 1288
		// (get) Token: 0x06002257 RID: 8791 RVA: 0x00016B0D File Offset: 0x00014D0D
		public override JTokenType Type
		{
			[DebuggerStepThrough]
			get
			{
				return JTokenType.Property;
			}
		}

		// Token: 0x06002258 RID: 8792 RVA: 0x0001C413 File Offset: 0x0001A613
		internal JProperty(string name)
		{
			ValidationUtils.ArgumentNotNull(name, <Module>.smethod_24<string>(3279218244U));
			this._name = name;
		}

		// Token: 0x06002259 RID: 8793 RVA: 0x0001C43D File Offset: 0x0001A63D
		public JProperty(string name, params object[] content)
			: this(name, content)
		{
		}

		// Token: 0x0600225A RID: 8794 RVA: 0x00089970 File Offset: 0x00087B70
		public JProperty(string name, object content)
		{
			ValidationUtils.ArgumentNotNull(name, <Module>.smethod_24<string>(3279218244U));
			this._name = name;
			this.Value = (base.IsMultiContent(content) ? new JArray(content) : JContainer.CreateFromContent(content));
		}

		// Token: 0x0600225B RID: 8795 RVA: 0x000899C4 File Offset: 0x00087BC4
		public override void WriteTo(JsonWriter writer, params JsonConverter[] converters)
		{
			writer.WritePropertyName(this._name);
			JToken value = this.Value;
			if (value != null)
			{
				value.WriteTo(writer, converters);
				return;
			}
			writer.WriteNull();
		}

		// Token: 0x0600225C RID: 8796 RVA: 0x0001C447 File Offset: 0x0001A647
		internal override int GetDeepHashCode()
		{
			return JProperty.smethod_69(this._name) ^ ((this.Value != null) ? this.Value.GetDeepHashCode() : 0);
		}

		// Token: 0x0600225D RID: 8797 RVA: 0x000899F8 File Offset: 0x00087BF8
		public new static JProperty Load(JsonReader reader)
		{
			if (reader.TokenType == JsonToken.None && !reader.Read())
			{
				throw JsonReaderException.Create(reader, <Module>.smethod_25<string>(3570444299U));
			}
			while (reader.TokenType == JsonToken.Comment)
			{
				reader.Read();
			}
			if (reader.TokenType != JsonToken.PropertyName)
			{
				throw JsonReaderException.Create(reader, <Module>.smethod_26<string>(3896104457U).FormatWith(JProperty.smethod_66(), reader.TokenType));
			}
			JProperty jproperty = new JProperty((string)reader.Value);
			jproperty.SetLineInfo(reader as IJsonLineInfo);
			jproperty.ReadTokenFrom(reader);
			return jproperty;
		}

		// Token: 0x0600225E RID: 8798 RVA: 0x00016A1F File Offset: 0x00014C1F
		static ArgumentOutOfRangeException smethod_65()
		{
			return new ArgumentOutOfRangeException();
		}

		// Token: 0x0600225F RID: 8799 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_66()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06002260 RID: 8800 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_67(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return global::System.Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06002261 RID: 8801 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_68(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06002262 RID: 8802 RVA: 0x0000CF7A File Offset: 0x0000B17A
		static int smethod_69(object object_0)
		{
			return object_0.GetHashCode();
		}

		// Token: 0x04000C24 RID: 3108
		private readonly JProperty.JPropertyList _content = new JProperty.JPropertyList();

		// Token: 0x04000C25 RID: 3109
		private readonly string _name;

		// Token: 0x02000244 RID: 580
		private class JPropertyList : IEnumerable<JToken>, IList<JToken>, ICollection<JToken>, IEnumerable
		{
			// Token: 0x06002263 RID: 8803 RVA: 0x00089A8C File Offset: 0x00087C8C
			public IEnumerator<JToken> GetEnumerator()
			{
				if (this._token != null)
				{
					yield return this._token;
				}
				yield break;
			}

			// Token: 0x06002264 RID: 8804 RVA: 0x0001C46B File Offset: 0x0001A66B
			IEnumerator IEnumerable.GetEnumerator()
			{
				return this.GetEnumerator();
			}

			// Token: 0x06002265 RID: 8805 RVA: 0x0001C473 File Offset: 0x0001A673
			public void Add(JToken item)
			{
				this._token = item;
			}

			// Token: 0x06002266 RID: 8806 RVA: 0x0001C47C File Offset: 0x0001A67C
			public void Clear()
			{
				this._token = null;
			}

			// Token: 0x06002267 RID: 8807 RVA: 0x0001C485 File Offset: 0x0001A685
			public bool Contains(JToken item)
			{
				return this._token == item;
			}

			// Token: 0x06002268 RID: 8808 RVA: 0x0001C490 File Offset: 0x0001A690
			public void CopyTo(JToken[] array, int arrayIndex)
			{
				if (this._token != null)
				{
					array[arrayIndex] = this._token;
				}
			}

			// Token: 0x06002269 RID: 8809 RVA: 0x0001C4A7 File Offset: 0x0001A6A7
			public bool Remove(JToken item)
			{
				if (this._token == item)
				{
					this._token = null;
					return true;
				}
				return false;
			}

			// Token: 0x17000509 RID: 1289
			// (get) Token: 0x0600226A RID: 8810 RVA: 0x0001C4BC File Offset: 0x0001A6BC
			public int Count
			{
				get
				{
					if (this._token == null)
					{
						return 0;
					}
					return 1;
				}
			}

			// Token: 0x1700050A RID: 1290
			// (get) Token: 0x0600226B RID: 8811 RVA: 0x0000C17A File Offset: 0x0000A37A
			public bool IsReadOnly
			{
				get
				{
					return false;
				}
			}

			// Token: 0x0600226C RID: 8812 RVA: 0x0001C4C9 File Offset: 0x0001A6C9
			public int IndexOf(JToken item)
			{
				if (this._token != item)
				{
					return -1;
				}
				return 0;
			}

			// Token: 0x0600226D RID: 8813 RVA: 0x0001C4D7 File Offset: 0x0001A6D7
			public void Insert(int index, JToken item)
			{
				if (index == 0)
				{
					this._token = item;
				}
			}

			// Token: 0x0600226E RID: 8814 RVA: 0x0001C4E3 File Offset: 0x0001A6E3
			public void RemoveAt(int index)
			{
				if (index == 0)
				{
					this._token = null;
				}
			}

			// Token: 0x1700050B RID: 1291
			public JToken this[int index]
			{
				get
				{
					if (index != 0)
					{
						return null;
					}
					return this._token;
				}
				set
				{
					if (index == 0)
					{
						this._token = value;
					}
				}
			}

			// Token: 0x04000C26 RID: 3110
			internal JToken _token;
		}
	}
}
