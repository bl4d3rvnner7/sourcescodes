﻿using System;
using System.Globalization;
using System.IO;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x020001F4 RID: 500
	public class JRaw : JValue
	{
		// Token: 0x06001CB0 RID: 7344 RVA: 0x0001929C File Offset: 0x0001749C
		public JRaw(JRaw other)
			: base(other)
		{
		}

		// Token: 0x06001CB1 RID: 7345 RVA: 0x000192A5 File Offset: 0x000174A5
		public JRaw(object rawJson)
			: base(rawJson, JTokenType.Raw)
		{
		}

		// Token: 0x06001CB2 RID: 7346 RVA: 0x0007F404 File Offset: 0x0007D604
		public static JRaw Create(JsonReader reader)
		{
			StringWriter stringWriter = JRaw.smethod_53(JRaw.smethod_52());
			JRaw jraw;
			try
			{
				JsonTextWriter jsonTextWriter = new JsonTextWriter(stringWriter);
				try
				{
					jsonTextWriter.WriteToken(reader);
					jraw = new JRaw(JRaw.smethod_54(stringWriter));
				}
				finally
				{
					if (jsonTextWriter != null)
					{
						JRaw.smethod_55(jsonTextWriter);
					}
				}
			}
			finally
			{
				if (stringWriter != null)
				{
					JRaw.smethod_55(stringWriter);
				}
			}
			return jraw;
		}

		// Token: 0x06001CB3 RID: 7347 RVA: 0x000192B0 File Offset: 0x000174B0
		internal override JToken CloneToken()
		{
			return new JRaw(this);
		}

		// Token: 0x06001CB4 RID: 7348 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_52()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x06001CB5 RID: 7349 RVA: 0x00016261 File Offset: 0x00014461
		static StringWriter smethod_53(IFormatProvider iformatProvider_0)
		{
			return new StringWriter(iformatProvider_0);
		}

		// Token: 0x06001CB6 RID: 7350 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_54(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06001CB7 RID: 7351 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_55(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}
	}
}
