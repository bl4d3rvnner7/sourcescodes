﻿using System;
using System.Collections.Generic;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x02000209 RID: 521
	public class JTokenEqualityComparer : IEqualityComparer<JToken>
	{
		// Token: 0x06001DB7 RID: 7607 RVA: 0x000199CF File Offset: 0x00017BCF
		public bool Equals(JToken x, JToken y)
		{
			return JToken.DeepEquals(x, y);
		}

		// Token: 0x06001DB8 RID: 7608 RVA: 0x000199D8 File Offset: 0x00017BD8
		public int GetHashCode(JToken obj)
		{
			if (obj == null)
			{
				return 0;
			}
			return obj.GetDeepHashCode();
		}
	}
}
