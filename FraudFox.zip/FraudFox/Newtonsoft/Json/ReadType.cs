﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000226 RID: 550
	internal enum ReadType
	{
		// Token: 0x04000B88 RID: 2952
		Read,
		// Token: 0x04000B89 RID: 2953
		ReadAsInt32,
		// Token: 0x04000B8A RID: 2954
		ReadAsBytes,
		// Token: 0x04000B8B RID: 2955
		ReadAsString,
		// Token: 0x04000B8C RID: 2956
		ReadAsDecimal,
		// Token: 0x04000B8D RID: 2957
		ReadAsDateTime,
		// Token: 0x04000B8E RID: 2958
		ReadAsDateTimeOffset
	}
}
