﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Numerics;
using Newtonsoft.Json.Utilities;

namespace Newtonsoft.Json
{
	// Token: 0x0200019B RID: 411
	public abstract class JsonWriter : IDisposable
	{
		// Token: 0x060017F7 RID: 6135 RVA: 0x000747C8 File Offset: 0x000729C8
		internal static JsonWriter.State[][] BuildStateArray()
		{
			List<JsonWriter.State[]> list = JsonWriter.StateArrayTempate.ToList<JsonWriter.State[]>();
			JsonWriter.State[] array = JsonWriter.StateArrayTempate[0];
			JsonWriter.State[] array2 = JsonWriter.StateArrayTempate[7];
			IEnumerator<object> enumerator = EnumUtils.GetValues(JsonWriter.smethod_0(typeof(JsonToken).TypeHandle)).GetEnumerator();
			try
			{
				while (JsonWriter.smethod_1(enumerator))
				{
					JsonToken jsonToken = (JsonToken)enumerator.Current;
					if (list.Count <= (int)jsonToken)
					{
						switch (jsonToken)
						{
						case JsonToken.Integer:
						case JsonToken.Float:
						case JsonToken.String:
						case JsonToken.Boolean:
						case JsonToken.Null:
						case JsonToken.Undefined:
						case JsonToken.Date:
						case JsonToken.Bytes:
							list.Add(array2);
							break;
						default:
							list.Add(array);
							break;
						}
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					JsonWriter.smethod_2(enumerator);
				}
			}
			return list.ToArray();
		}

		// Token: 0x17000385 RID: 901
		// (get) Token: 0x060017F9 RID: 6137 RVA: 0x00016C22 File Offset: 0x00014E22
		// (set) Token: 0x060017FA RID: 6138 RVA: 0x00016C2A File Offset: 0x00014E2A
		public bool CloseOutput { get; set; }

		// Token: 0x17000386 RID: 902
		// (get) Token: 0x060017FB RID: 6139 RVA: 0x00074ABC File Offset: 0x00072CBC
		protected internal int Top
		{
			get
			{
				int num = this._stack.Count;
				if (this.Peek() != JsonContainerType.None)
				{
					num++;
				}
				return num;
			}
		}

		// Token: 0x17000387 RID: 903
		// (get) Token: 0x060017FC RID: 6140 RVA: 0x00074AE4 File Offset: 0x00072CE4
		public WriteState WriteState
		{
			get
			{
				switch (this._currentState)
				{
				case JsonWriter.State.Start:
					return WriteState.Start;
				case JsonWriter.State.Property:
					return WriteState.Property;
				case JsonWriter.State.ObjectStart:
				case JsonWriter.State.Object:
					return WriteState.Object;
				case JsonWriter.State.ArrayStart:
				case JsonWriter.State.Array:
					return WriteState.Array;
				case JsonWriter.State.ConstructorStart:
				case JsonWriter.State.Constructor:
					return WriteState.Constructor;
				case JsonWriter.State.Closed:
					return WriteState.Closed;
				case JsonWriter.State.Error:
					return WriteState.Error;
				default:
					throw JsonWriterException.Create(this, JsonWriter.smethod_3(<Module>.smethod_26<string>(2915405362U), this._currentState), null);
				}
			}
		}

		// Token: 0x17000388 RID: 904
		// (get) Token: 0x060017FD RID: 6141 RVA: 0x00016C33 File Offset: 0x00014E33
		internal string ContainerPath
		{
			get
			{
				if (this._currentPosition.Type == JsonContainerType.None)
				{
					return string.Empty;
				}
				return JsonPosition.BuildPath(this._stack);
			}
		}

		// Token: 0x17000389 RID: 905
		// (get) Token: 0x060017FE RID: 6142 RVA: 0x00074B58 File Offset: 0x00072D58
		public string Path
		{
			get
			{
				if (this._currentPosition.Type == JsonContainerType.None)
				{
					return string.Empty;
				}
				IEnumerable<JsonPosition> enumerable = ((this._currentState == JsonWriter.State.ArrayStart || this._currentState == JsonWriter.State.ConstructorStart || this._currentState == JsonWriter.State.ObjectStart) ? this._stack : this._stack.Concat(new JsonPosition[] { this._currentPosition }));
				return JsonPosition.BuildPath(enumerable);
			}
		}

		// Token: 0x1700038A RID: 906
		// (get) Token: 0x060017FF RID: 6143 RVA: 0x00016C53 File Offset: 0x00014E53
		// (set) Token: 0x06001800 RID: 6144 RVA: 0x00016C5B File Offset: 0x00014E5B
		public Formatting Formatting
		{
			get
			{
				return this._formatting;
			}
			set
			{
				this._formatting = value;
			}
		}

		// Token: 0x1700038B RID: 907
		// (get) Token: 0x06001801 RID: 6145 RVA: 0x00016C64 File Offset: 0x00014E64
		// (set) Token: 0x06001802 RID: 6146 RVA: 0x00016C6C File Offset: 0x00014E6C
		public DateFormatHandling DateFormatHandling
		{
			get
			{
				return this._dateFormatHandling;
			}
			set
			{
				this._dateFormatHandling = value;
			}
		}

		// Token: 0x1700038C RID: 908
		// (get) Token: 0x06001803 RID: 6147 RVA: 0x00016C75 File Offset: 0x00014E75
		// (set) Token: 0x06001804 RID: 6148 RVA: 0x00016C7D File Offset: 0x00014E7D
		public DateTimeZoneHandling DateTimeZoneHandling
		{
			get
			{
				return this._dateTimeZoneHandling;
			}
			set
			{
				this._dateTimeZoneHandling = value;
			}
		}

		// Token: 0x1700038D RID: 909
		// (get) Token: 0x06001805 RID: 6149 RVA: 0x00016C86 File Offset: 0x00014E86
		// (set) Token: 0x06001806 RID: 6150 RVA: 0x00016C8E File Offset: 0x00014E8E
		public StringEscapeHandling StringEscapeHandling
		{
			get
			{
				return this._stringEscapeHandling;
			}
			set
			{
				this._stringEscapeHandling = value;
				this.OnStringEscapeHandlingChanged();
			}
		}

		// Token: 0x06001807 RID: 6151 RVA: 0x0000C600 File Offset: 0x0000A800
		internal virtual void OnStringEscapeHandlingChanged()
		{
		}

		// Token: 0x1700038E RID: 910
		// (get) Token: 0x06001808 RID: 6152 RVA: 0x00016C9D File Offset: 0x00014E9D
		// (set) Token: 0x06001809 RID: 6153 RVA: 0x00016CA5 File Offset: 0x00014EA5
		public FloatFormatHandling FloatFormatHandling
		{
			get
			{
				return this._floatFormatHandling;
			}
			set
			{
				this._floatFormatHandling = value;
			}
		}

		// Token: 0x1700038F RID: 911
		// (get) Token: 0x0600180A RID: 6154 RVA: 0x00016CAE File Offset: 0x00014EAE
		// (set) Token: 0x0600180B RID: 6155 RVA: 0x00016CB6 File Offset: 0x00014EB6
		public string DateFormatString
		{
			get
			{
				return this._dateFormatString;
			}
			set
			{
				this._dateFormatString = value;
			}
		}

		// Token: 0x17000390 RID: 912
		// (get) Token: 0x0600180C RID: 6156 RVA: 0x00016CBF File Offset: 0x00014EBF
		// (set) Token: 0x0600180D RID: 6157 RVA: 0x00016CD0 File Offset: 0x00014ED0
		public CultureInfo Culture
		{
			get
			{
				return this._culture ?? JsonWriter.smethod_4();
			}
			set
			{
				this._culture = value;
			}
		}

		// Token: 0x0600180E RID: 6158 RVA: 0x00016CD9 File Offset: 0x00014ED9
		protected JsonWriter()
		{
			this._stack = new List<JsonPosition>(4);
			this._currentState = JsonWriter.State.Start;
			this._formatting = Formatting.None;
			this._dateTimeZoneHandling = DateTimeZoneHandling.RoundtripKind;
			this.CloseOutput = true;
		}

		// Token: 0x0600180F RID: 6159 RVA: 0x00016D09 File Offset: 0x00014F09
		internal void UpdateScopeWithFinishedValue()
		{
			if (this._currentPosition.HasIndex)
			{
				this._currentPosition.Position = this._currentPosition.Position + 1;
			}
		}

		// Token: 0x06001810 RID: 6160 RVA: 0x00016D2B File Offset: 0x00014F2B
		private void Push(JsonContainerType value)
		{
			if (this._currentPosition.Type != JsonContainerType.None)
			{
				this._stack.Add(this._currentPosition);
			}
			this._currentPosition = new JsonPosition(value);
		}

		// Token: 0x06001811 RID: 6161 RVA: 0x00074BD0 File Offset: 0x00072DD0
		private JsonContainerType Pop()
		{
			JsonPosition currentPosition = this._currentPosition;
			if (this._stack.Count > 0)
			{
				this._currentPosition = this._stack[this._stack.Count - 1];
				this._stack.RemoveAt(this._stack.Count - 1);
			}
			else
			{
				this._currentPosition = default(JsonPosition);
			}
			return currentPosition.Type;
		}

		// Token: 0x06001812 RID: 6162 RVA: 0x00016D57 File Offset: 0x00014F57
		private JsonContainerType Peek()
		{
			return this._currentPosition.Type;
		}

		// Token: 0x06001813 RID: 6163
		public abstract void Flush();

		// Token: 0x06001814 RID: 6164 RVA: 0x00016D64 File Offset: 0x00014F64
		public virtual void Close()
		{
			this.AutoCompleteAll();
		}

		// Token: 0x06001815 RID: 6165 RVA: 0x00016D6C File Offset: 0x00014F6C
		public virtual void WriteStartObject()
		{
			this.InternalWriteStart(JsonToken.StartObject, JsonContainerType.Object);
		}

		// Token: 0x06001816 RID: 6166 RVA: 0x00016D76 File Offset: 0x00014F76
		public virtual void WriteEndObject()
		{
			this.InternalWriteEnd(JsonContainerType.Object);
		}

		// Token: 0x06001817 RID: 6167 RVA: 0x00016D7F File Offset: 0x00014F7F
		public virtual void WriteStartArray()
		{
			this.InternalWriteStart(JsonToken.StartArray, JsonContainerType.Array);
		}

		// Token: 0x06001818 RID: 6168 RVA: 0x00016D89 File Offset: 0x00014F89
		public virtual void WriteEndArray()
		{
			this.InternalWriteEnd(JsonContainerType.Array);
		}

		// Token: 0x06001819 RID: 6169 RVA: 0x00016D92 File Offset: 0x00014F92
		public virtual void WriteStartConstructor(string name)
		{
			this.InternalWriteStart(JsonToken.StartConstructor, JsonContainerType.Constructor);
		}

		// Token: 0x0600181A RID: 6170 RVA: 0x00016D9C File Offset: 0x00014F9C
		public virtual void WriteEndConstructor()
		{
			this.InternalWriteEnd(JsonContainerType.Constructor);
		}

		// Token: 0x0600181B RID: 6171 RVA: 0x00016DA5 File Offset: 0x00014FA5
		public virtual void WritePropertyName(string name)
		{
			this.InternalWritePropertyName(name);
		}

		// Token: 0x0600181C RID: 6172 RVA: 0x00016DAE File Offset: 0x00014FAE
		public virtual void WritePropertyName(string name, bool escape)
		{
			this.WritePropertyName(name);
		}

		// Token: 0x0600181D RID: 6173 RVA: 0x00016DB7 File Offset: 0x00014FB7
		public virtual void WriteEnd()
		{
			this.WriteEnd(this.Peek());
		}

		// Token: 0x0600181E RID: 6174 RVA: 0x00016DC5 File Offset: 0x00014FC5
		public void WriteToken(JsonReader reader)
		{
			this.WriteToken(reader, true, true);
		}

		// Token: 0x0600181F RID: 6175 RVA: 0x00016DD0 File Offset: 0x00014FD0
		public void WriteToken(JsonReader reader, bool writeChildren)
		{
			ValidationUtils.ArgumentNotNull(reader, <Module>.smethod_24<string>(1458178418U));
			this.WriteToken(reader, writeChildren, true);
		}

		// Token: 0x06001820 RID: 6176 RVA: 0x00016DEB File Offset: 0x00014FEB
		public void WriteToken(JsonToken token, object value)
		{
			this.WriteTokenInternal(token, value);
		}

		// Token: 0x06001821 RID: 6177 RVA: 0x00016DF5 File Offset: 0x00014FF5
		public void WriteToken(JsonToken token)
		{
			this.WriteTokenInternal(token, null);
		}

		// Token: 0x06001822 RID: 6178 RVA: 0x00074C40 File Offset: 0x00072E40
		internal void WriteToken(JsonReader reader, bool writeChildren, bool writeDateConstructorAsDate)
		{
			int num;
			if (reader.TokenType == JsonToken.None)
			{
				num = -1;
			}
			else if (JsonTokenUtils.IsStartToken(reader.TokenType))
			{
				num = reader.Depth;
			}
			else
			{
				num = reader.Depth + 1;
			}
			this.WriteToken(reader, num, writeChildren, writeDateConstructorAsDate);
		}

		// Token: 0x06001823 RID: 6179 RVA: 0x00074C84 File Offset: 0x00072E84
		internal void WriteToken(JsonReader reader, int initialDepth, bool writeChildren, bool writeDateConstructorAsDate)
		{
			do
			{
				if (writeDateConstructorAsDate && reader.TokenType == JsonToken.StartConstructor && JsonWriter.smethod_6(JsonWriter.smethod_5(reader.Value), <Module>.smethod_23<string>(2473942043U), StringComparison.Ordinal))
				{
					this.WriteConstructorDate(reader);
				}
				else
				{
					this.WriteTokenInternal(reader.TokenType, reader.Value);
				}
			}
			while (initialDepth - 1 < reader.Depth - (JsonTokenUtils.IsEndToken(reader.TokenType) ? 1 : 0) && writeChildren && reader.Read());
		}

		// Token: 0x06001824 RID: 6180 RVA: 0x00074D00 File Offset: 0x00072F00
		private void WriteTokenInternal(JsonToken tokenType, object value)
		{
			switch (tokenType)
			{
			case JsonToken.None:
				return;
			case JsonToken.StartObject:
				this.WriteStartObject();
				return;
			case JsonToken.StartArray:
				this.WriteStartArray();
				return;
			case JsonToken.StartConstructor:
				ValidationUtils.ArgumentNotNull(value, <Module>.smethod_24<string>(4014942403U));
				this.WriteStartConstructor(JsonWriter.smethod_5(value));
				return;
			case JsonToken.PropertyName:
				ValidationUtils.ArgumentNotNull(value, <Module>.smethod_23<string>(2033612370U));
				this.WritePropertyName(JsonWriter.smethod_5(value));
				return;
			case JsonToken.Comment:
				this.WriteComment((value != null) ? JsonWriter.smethod_5(value) : null);
				return;
			case JsonToken.Raw:
				this.WriteRawValue((value != null) ? JsonWriter.smethod_5(value) : null);
				return;
			case JsonToken.Integer:
				ValidationUtils.ArgumentNotNull(value, <Module>.smethod_26<string>(1806306238U));
				if (!(value is BigInteger))
				{
					this.WriteValue(JsonWriter.smethod_7(value, JsonWriter.smethod_4()));
					return;
				}
				this.WriteValue((BigInteger)value);
				return;
			case JsonToken.Float:
				ValidationUtils.ArgumentNotNull(value, <Module>.smethod_23<string>(2033612370U));
				if (value is decimal)
				{
					this.WriteValue((decimal)value);
					return;
				}
				if (value is double)
				{
					this.WriteValue((double)value);
					return;
				}
				if (value is float)
				{
					this.WriteValue((float)value);
					return;
				}
				this.WriteValue(JsonWriter.smethod_8(value, JsonWriter.smethod_4()));
				return;
			case JsonToken.String:
				ValidationUtils.ArgumentNotNull(value, <Module>.smethod_23<string>(2033612370U));
				this.WriteValue(JsonWriter.smethod_5(value));
				return;
			case JsonToken.Boolean:
				ValidationUtils.ArgumentNotNull(value, <Module>.smethod_26<string>(1806306238U));
				this.WriteValue(JsonWriter.smethod_9(value, JsonWriter.smethod_4()));
				return;
			case JsonToken.Null:
				this.WriteNull();
				return;
			case JsonToken.Undefined:
				this.WriteUndefined();
				return;
			case JsonToken.EndObject:
				this.WriteEndObject();
				return;
			case JsonToken.EndArray:
				this.WriteEndArray();
				return;
			case JsonToken.EndConstructor:
				this.WriteEndConstructor();
				return;
			case JsonToken.Date:
				ValidationUtils.ArgumentNotNull(value, <Module>.smethod_25<string>(3622406065U));
				if (value is DateTimeOffset)
				{
					this.WriteValue((DateTimeOffset)value);
					return;
				}
				this.WriteValue(JsonWriter.smethod_10(value, JsonWriter.smethod_4()));
				return;
			case JsonToken.Bytes:
				ValidationUtils.ArgumentNotNull(value, <Module>.smethod_27<string>(2371252898U));
				if (value is Guid)
				{
					this.WriteValue((Guid)value);
					return;
				}
				this.WriteValue((byte[])value);
				return;
			default:
				throw MiscellaneousUtils.CreateArgumentOutOfRangeException(<Module>.smethod_25<string>(1800987386U), tokenType, <Module>.smethod_24<string>(4112491528U));
			}
		}

		// Token: 0x06001825 RID: 6181 RVA: 0x00074F54 File Offset: 0x00073154
		private void WriteConstructorDate(JsonReader reader)
		{
			if (!reader.Read())
			{
				throw JsonWriterException.Create(this, <Module>.smethod_27<string>(303861596U), null);
			}
			if (reader.TokenType != JsonToken.Integer)
			{
				throw JsonWriterException.Create(this, JsonWriter.smethod_3(<Module>.smethod_27<string>(4272477041U), reader.TokenType), null);
			}
			long num = (long)reader.Value;
			DateTime dateTime = DateTimeUtils.ConvertJavaScriptTicksToDateTime(num);
			if (!reader.Read())
			{
				throw JsonWriterException.Create(this, <Module>.smethod_24<string>(4166350089U), null);
			}
			if (reader.TokenType != JsonToken.EndConstructor)
			{
				throw JsonWriterException.Create(this, JsonWriter.smethod_3(<Module>.smethod_26<string>(4228952268U), reader.TokenType), null);
			}
			this.WriteValue(dateTime);
		}

		// Token: 0x06001826 RID: 6182 RVA: 0x00075008 File Offset: 0x00073208
		private void WriteEnd(JsonContainerType type)
		{
			switch (type)
			{
			case JsonContainerType.Object:
				this.WriteEndObject();
				return;
			case JsonContainerType.Array:
				this.WriteEndArray();
				return;
			case JsonContainerType.Constructor:
				this.WriteEndConstructor();
				return;
			default:
				throw JsonWriterException.Create(this, JsonWriter.smethod_3(<Module>.smethod_25<string>(1641717690U), type), null);
			}
		}

		// Token: 0x06001827 RID: 6183 RVA: 0x00016DFF File Offset: 0x00014FFF
		private void AutoCompleteAll()
		{
			while (this.Top > 0)
			{
				this.WriteEnd();
			}
		}

		// Token: 0x06001828 RID: 6184 RVA: 0x0007505C File Offset: 0x0007325C
		private JsonToken GetCloseTokenForType(JsonContainerType type)
		{
			switch (type)
			{
			case JsonContainerType.Object:
				return JsonToken.EndObject;
			case JsonContainerType.Array:
				return JsonToken.EndArray;
			case JsonContainerType.Constructor:
				return JsonToken.EndConstructor;
			default:
				throw JsonWriterException.Create(this, JsonWriter.smethod_3(<Module>.smethod_23<string>(3558376055U), type), null);
			}
		}

		// Token: 0x06001829 RID: 6185 RVA: 0x000750A4 File Offset: 0x000732A4
		private void AutoCompleteClose(JsonContainerType type)
		{
			int num = 0;
			if (this._currentPosition.Type != type)
			{
				int num2 = this.Top - 2;
				for (int i = num2; i >= 0; i--)
				{
					int num3 = num2 - i;
					if (this._stack[num3].Type == type)
					{
						num = i + 2;
						break;
					}
				}
			}
			else
			{
				num = 1;
			}
			if (num != 0)
			{
				for (int j = 0; j < num; j++)
				{
					JsonToken closeTokenForType = this.GetCloseTokenForType(this.Pop());
					if (this._currentState == JsonWriter.State.Property)
					{
						this.WriteNull();
					}
					if (this._formatting == Formatting.Indented && this._currentState != JsonWriter.State.ObjectStart && this._currentState != JsonWriter.State.ArrayStart)
					{
						this.WriteIndent();
					}
					this.WriteEnd(closeTokenForType);
					JsonContainerType jsonContainerType = this.Peek();
					switch (jsonContainerType)
					{
					case JsonContainerType.None:
						this._currentState = JsonWriter.State.Start;
						break;
					case JsonContainerType.Object:
						this._currentState = JsonWriter.State.Object;
						break;
					case JsonContainerType.Array:
						this._currentState = JsonWriter.State.Array;
						break;
					case JsonContainerType.Constructor:
						this._currentState = JsonWriter.State.Array;
						break;
					default:
						throw JsonWriterException.Create(this, JsonWriter.smethod_3(<Module>.smethod_24<string>(3284796964U), jsonContainerType), null);
					}
				}
				return;
			}
			throw JsonWriterException.Create(this, <Module>.smethod_26<string>(2143715181U), null);
		}

		// Token: 0x0600182A RID: 6186 RVA: 0x0000C600 File Offset: 0x0000A800
		protected virtual void WriteEnd(JsonToken token)
		{
		}

		// Token: 0x0600182B RID: 6187 RVA: 0x0000C600 File Offset: 0x0000A800
		protected virtual void WriteIndent()
		{
		}

		// Token: 0x0600182C RID: 6188 RVA: 0x0000C600 File Offset: 0x0000A800
		protected virtual void WriteValueDelimiter()
		{
		}

		// Token: 0x0600182D RID: 6189 RVA: 0x0000C600 File Offset: 0x0000A800
		protected virtual void WriteIndentSpace()
		{
		}

		// Token: 0x0600182E RID: 6190 RVA: 0x000751D8 File Offset: 0x000733D8
		internal void AutoComplete(JsonToken tokenBeingWritten)
		{
			JsonWriter.State state = JsonWriter.StateArray[(int)tokenBeingWritten][(int)this._currentState];
			if (state == JsonWriter.State.Error)
			{
				throw JsonWriterException.Create(this, <Module>.smethod_23<string>(2735488763U).FormatWith(JsonWriter.smethod_4(), JsonWriter.smethod_5(tokenBeingWritten), JsonWriter.smethod_5(this._currentState)), null);
			}
			if (this._currentState != JsonWriter.State.Object)
			{
				if (this._currentState != JsonWriter.State.Array)
				{
					if (this._currentState != JsonWriter.State.Constructor)
					{
						goto IL_0078;
					}
				}
			}
			if (tokenBeingWritten != JsonToken.Comment)
			{
				this.WriteValueDelimiter();
			}
			IL_0078:
			if (this._formatting == Formatting.Indented)
			{
				if (this._currentState == JsonWriter.State.Property)
				{
					this.WriteIndentSpace();
				}
				if (this._currentState != JsonWriter.State.Array)
				{
					if (this._currentState != JsonWriter.State.ArrayStart)
					{
						if (this._currentState != JsonWriter.State.Constructor && this._currentState != JsonWriter.State.ConstructorStart && (tokenBeingWritten != JsonToken.PropertyName || this._currentState == JsonWriter.State.Start))
						{
							goto IL_00CC;
						}
					}
				}
				this.WriteIndent();
			}
			IL_00CC:
			this._currentState = state;
		}

		// Token: 0x0600182F RID: 6191 RVA: 0x00016E13 File Offset: 0x00015013
		public virtual void WriteNull()
		{
			this.InternalWriteValue(JsonToken.Null);
		}

		// Token: 0x06001830 RID: 6192 RVA: 0x00016E1D File Offset: 0x0001501D
		public virtual void WriteUndefined()
		{
			this.InternalWriteValue(JsonToken.Undefined);
		}

		// Token: 0x06001831 RID: 6193 RVA: 0x00016E27 File Offset: 0x00015027
		public virtual void WriteRaw(string json)
		{
			this.InternalWriteRaw();
		}

		// Token: 0x06001832 RID: 6194 RVA: 0x00016E2F File Offset: 0x0001502F
		public virtual void WriteRawValue(string json)
		{
			this.UpdateScopeWithFinishedValue();
			this.AutoComplete(JsonToken.Undefined);
			this.WriteRaw(json);
		}

		// Token: 0x06001833 RID: 6195 RVA: 0x00016E46 File Offset: 0x00015046
		public virtual void WriteValue(string value)
		{
			this.InternalWriteValue(JsonToken.String);
		}

		// Token: 0x06001834 RID: 6196 RVA: 0x00016E50 File Offset: 0x00015050
		public virtual void WriteValue(int value)
		{
			this.InternalWriteValue(JsonToken.Integer);
		}

		// Token: 0x06001835 RID: 6197 RVA: 0x00016E50 File Offset: 0x00015050
		[CLSCompliant(false)]
		public virtual void WriteValue(uint value)
		{
			this.InternalWriteValue(JsonToken.Integer);
		}

		// Token: 0x06001836 RID: 6198 RVA: 0x00016E50 File Offset: 0x00015050
		public virtual void WriteValue(long value)
		{
			this.InternalWriteValue(JsonToken.Integer);
		}

		// Token: 0x06001837 RID: 6199 RVA: 0x00016E50 File Offset: 0x00015050
		[CLSCompliant(false)]
		public virtual void WriteValue(ulong value)
		{
			this.InternalWriteValue(JsonToken.Integer);
		}

		// Token: 0x06001838 RID: 6200 RVA: 0x00016E59 File Offset: 0x00015059
		public virtual void WriteValue(float value)
		{
			this.InternalWriteValue(JsonToken.Float);
		}

		// Token: 0x06001839 RID: 6201 RVA: 0x00016E59 File Offset: 0x00015059
		public virtual void WriteValue(double value)
		{
			this.InternalWriteValue(JsonToken.Float);
		}

		// Token: 0x0600183A RID: 6202 RVA: 0x00016E62 File Offset: 0x00015062
		public virtual void WriteValue(bool value)
		{
			this.InternalWriteValue(JsonToken.Boolean);
		}

		// Token: 0x0600183B RID: 6203 RVA: 0x00016E50 File Offset: 0x00015050
		public virtual void WriteValue(short value)
		{
			this.InternalWriteValue(JsonToken.Integer);
		}

		// Token: 0x0600183C RID: 6204 RVA: 0x00016E50 File Offset: 0x00015050
		[CLSCompliant(false)]
		public virtual void WriteValue(ushort value)
		{
			this.InternalWriteValue(JsonToken.Integer);
		}

		// Token: 0x0600183D RID: 6205 RVA: 0x00016E46 File Offset: 0x00015046
		public virtual void WriteValue(char value)
		{
			this.InternalWriteValue(JsonToken.String);
		}

		// Token: 0x0600183E RID: 6206 RVA: 0x00016E50 File Offset: 0x00015050
		public virtual void WriteValue(byte value)
		{
			this.InternalWriteValue(JsonToken.Integer);
		}

		// Token: 0x0600183F RID: 6207 RVA: 0x00016E50 File Offset: 0x00015050
		[CLSCompliant(false)]
		public virtual void WriteValue(sbyte value)
		{
			this.InternalWriteValue(JsonToken.Integer);
		}

		// Token: 0x06001840 RID: 6208 RVA: 0x00016E59 File Offset: 0x00015059
		public virtual void WriteValue(decimal value)
		{
			this.InternalWriteValue(JsonToken.Float);
		}

		// Token: 0x06001841 RID: 6209 RVA: 0x00016E6C File Offset: 0x0001506C
		public virtual void WriteValue(DateTime value)
		{
			this.InternalWriteValue(JsonToken.Date);
		}

		// Token: 0x06001842 RID: 6210 RVA: 0x00016E6C File Offset: 0x0001506C
		public virtual void WriteValue(DateTimeOffset value)
		{
			this.InternalWriteValue(JsonToken.Date);
		}

		// Token: 0x06001843 RID: 6211 RVA: 0x00016E46 File Offset: 0x00015046
		public virtual void WriteValue(Guid value)
		{
			this.InternalWriteValue(JsonToken.String);
		}

		// Token: 0x06001844 RID: 6212 RVA: 0x00016E46 File Offset: 0x00015046
		public virtual void WriteValue(TimeSpan value)
		{
			this.InternalWriteValue(JsonToken.String);
		}

		// Token: 0x06001845 RID: 6213 RVA: 0x00016E76 File Offset: 0x00015076
		public virtual void WriteValue(int? value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			this.WriteValue(value.Value);
		}

		// Token: 0x06001846 RID: 6214 RVA: 0x00016E95 File Offset: 0x00015095
		[CLSCompliant(false)]
		public virtual void WriteValue(uint? value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			this.WriteValue(value.Value);
		}

		// Token: 0x06001847 RID: 6215 RVA: 0x00016EB4 File Offset: 0x000150B4
		public virtual void WriteValue(long? value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			this.WriteValue(value.Value);
		}

		// Token: 0x06001848 RID: 6216 RVA: 0x00016ED3 File Offset: 0x000150D3
		[CLSCompliant(false)]
		public virtual void WriteValue(ulong? value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			this.WriteValue(value.Value);
		}

		// Token: 0x06001849 RID: 6217 RVA: 0x00016EF2 File Offset: 0x000150F2
		public virtual void WriteValue(float? value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			this.WriteValue(value.Value);
		}

		// Token: 0x0600184A RID: 6218 RVA: 0x00016F11 File Offset: 0x00015111
		public virtual void WriteValue(double? value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			this.WriteValue(value.Value);
		}

		// Token: 0x0600184B RID: 6219 RVA: 0x00016F30 File Offset: 0x00015130
		public virtual void WriteValue(bool? value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			this.WriteValue(value.Value);
		}

		// Token: 0x0600184C RID: 6220 RVA: 0x000752B8 File Offset: 0x000734B8
		public virtual void WriteValue(short? value)
		{
			short? num = value;
			for (;;)
			{
				IL_0064:
				int num2 = -520525605;
				for (;;)
				{
					int? num3;
					switch (num2 ^ -520525608)
					{
					case 0:
						goto IL_0064;
					case 1:
						goto IL_006B;
					case 2:
						num3 = null;
						goto IL_0020;
					case 3:
						if (num == null)
						{
							num2 = -520525606;
							continue;
						}
						num3 = new int?((int)num.GetValueOrDefault());
						goto IL_0020;
					}
					goto Block_3;
					IL_0020:
					int? num4 = num3;
					num2 = ((num4 != null) ? (-520525604) : (-520525607));
				}
			}
			Block_3:
			goto IL_0072;
			IL_006B:
			this.WriteNull();
			return;
			IL_0072:
			this.WriteValue(value.Value);
		}

		// Token: 0x0600184D RID: 6221 RVA: 0x00075344 File Offset: 0x00073544
		[CLSCompliant(false)]
		public virtual void WriteValue(ushort? value)
		{
			ushort? num = value;
			int? num2 = ((num != null) ? new int?((int)num.GetValueOrDefault()) : null);
			if (num2 == null)
			{
				this.WriteNull();
				return;
			}
			this.WriteValue(value.Value);
		}

		// Token: 0x0600184E RID: 6222 RVA: 0x00075394 File Offset: 0x00073594
		public virtual void WriteValue(char? value)
		{
			char? c = value;
			int? num = ((c != null) ? new int?((int)c.GetValueOrDefault()) : null);
			if (num != null)
			{
				this.WriteValue(value.Value);
				return;
			}
			this.WriteNull();
		}

		// Token: 0x0600184F RID: 6223 RVA: 0x000753E4 File Offset: 0x000735E4
		public virtual void WriteValue(byte? value)
		{
			byte? b = value;
			int? num = ((b == null) ? null : new int?((int)b.GetValueOrDefault()));
			if (num == null)
			{
				this.WriteNull();
				return;
			}
			this.WriteValue(value.Value);
		}

		// Token: 0x06001850 RID: 6224 RVA: 0x00075434 File Offset: 0x00073634
		[CLSCompliant(false)]
		public virtual void WriteValue(sbyte? value)
		{
			sbyte? b = value;
			int? num = ((b == null) ? null : new int?((int)b.GetValueOrDefault()));
			if (num != null)
			{
				this.WriteValue(value.Value);
				return;
			}
			this.WriteNull();
		}

		// Token: 0x06001851 RID: 6225 RVA: 0x00016F4F File Offset: 0x0001514F
		public virtual void WriteValue(decimal? value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			this.WriteValue(value.Value);
		}

		// Token: 0x06001852 RID: 6226 RVA: 0x00016F6E File Offset: 0x0001516E
		public virtual void WriteValue(DateTime? value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			this.WriteValue(value.Value);
		}

		// Token: 0x06001853 RID: 6227 RVA: 0x00016F8D File Offset: 0x0001518D
		public virtual void WriteValue(DateTimeOffset? value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			this.WriteValue(value.Value);
		}

		// Token: 0x06001854 RID: 6228 RVA: 0x00016FAC File Offset: 0x000151AC
		public virtual void WriteValue(Guid? value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			this.WriteValue(value.Value);
		}

		// Token: 0x06001855 RID: 6229 RVA: 0x00016FCB File Offset: 0x000151CB
		public virtual void WriteValue(TimeSpan? value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			this.WriteValue(value.Value);
		}

		// Token: 0x06001856 RID: 6230 RVA: 0x00016FEA File Offset: 0x000151EA
		public virtual void WriteValue(byte[] value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			this.InternalWriteValue(JsonToken.Bytes);
		}

		// Token: 0x06001857 RID: 6231 RVA: 0x00016FFE File Offset: 0x000151FE
		public virtual void WriteValue(Uri value)
		{
			if (JsonWriter.smethod_11(value, null))
			{
				this.WriteNull();
				return;
			}
			this.InternalWriteValue(JsonToken.String);
		}

		// Token: 0x06001858 RID: 6232 RVA: 0x00017018 File Offset: 0x00015218
		public virtual void WriteValue(object value)
		{
			if (value == null)
			{
				this.WriteNull();
				return;
			}
			if (value is BigInteger)
			{
				throw JsonWriter.CreateUnsupportedTypeException(this, value);
			}
			JsonWriter.WriteValue(this, ConvertUtils.GetTypeCode(JsonWriter.smethod_12(value)), value);
		}

		// Token: 0x06001859 RID: 6233 RVA: 0x00017046 File Offset: 0x00015246
		public virtual void WriteComment(string text)
		{
			this.InternalWriteComment();
		}

		// Token: 0x0600185A RID: 6234 RVA: 0x0001704E File Offset: 0x0001524E
		public virtual void WriteWhitespace(string ws)
		{
			this.InternalWriteWhitespace(ws);
		}

		// Token: 0x0600185B RID: 6235 RVA: 0x00017057 File Offset: 0x00015257
		void IDisposable.Dispose()
		{
			this.Dispose(true);
		}

		// Token: 0x0600185C RID: 6236 RVA: 0x00017060 File Offset: 0x00015260
		private void Dispose(bool disposing)
		{
			if (this._currentState != JsonWriter.State.Closed)
			{
				this.Close();
			}
		}

		// Token: 0x0600185D RID: 6237 RVA: 0x00075484 File Offset: 0x00073684
		internal static void WriteValue(JsonWriter writer, PrimitiveTypeCode typeCode, object value)
		{
			for (;;)
			{
				IL_049B:
				int num = -1788890017;
				for (;;)
				{
					Type type;
					PrimitiveTypeCode primitiveTypeCode;
					PrimitiveTypeCode primitiveTypeCode2;
					Type type2;
					switch (num ^ -1788890081)
					{
					case 0:
						goto IL_00FC;
					case 1:
						return;
					case 2:
						return;
					case 3:
						goto IL_0507;
					case 4:
						goto IL_04C0;
					case 5:
						goto IL_0590;
					case 6:
						goto IL_013C;
					case 7:
						goto IL_01BC;
					case 8:
						goto IL_0548;
					case 9:
						return;
					case 10:
						goto IL_049B;
					case 11:
						goto IL_0583;
					case 12:
						return;
					case 14:
						goto IL_0212;
					case 15:
						goto IL_0152;
					case 16:
					{
						TypeInformation typeInformation;
						type = typeInformation.Type;
						goto IL_032A;
					}
					case 17:
						return;
					case 18:
						return;
					case 19:
						return;
					case 20:
						goto IL_0228;
					case 21:
						goto IL_04FA;
					case 22:
						goto IL_02F2;
					case 23:
						goto IL_063B;
					case 24:
						goto IL_05CB;
					case 25:
						return;
					case 26:
						goto IL_04ED;
					case 27:
						goto IL_04CD;
					case 28:
						goto IL_061A;
					case 29:
						return;
					case 30:
						goto IL_0112;
					case 31:
						goto IL_0168;
					case 32:
						goto IL_02AD;
					case 33:
						goto IL_0527;
					case 34:
						goto IL_02DC;
					case 35:
						goto IL_05D8;
					case 36:
						goto IL_01E6;
					case 37:
						return;
					case 38:
						if (value is IConvertible)
						{
							IConvertible convertible = (IConvertible)value;
							TypeInformation typeInformation = ConvertUtils.GetTypeInformation(convertible);
							if (typeInformation.TypeCode != PrimitiveTypeCode.Object)
							{
								num = -1788890077;
								continue;
							}
							primitiveTypeCode = PrimitiveTypeCode.String;
							goto IL_0306;
						}
						break;
					case 39:
						goto IL_0555;
					case 40:
						goto IL_00D3;
					case 41:
						return;
					case 42:
						goto IL_0292;
					case 43:
						return;
					case 44:
						goto IL_05F9;
					case 45:
						return;
					case 46:
						return;
					case 47:
						goto IL_05BE;
					case 48:
						goto IL_065C;
					case 49:
						goto IL_059D;
					case 50:
					{
						object obj;
						JsonWriter.WriteValue(writer, primitiveTypeCode2, obj);
						num = -1788890110;
						continue;
					}
					case 51:
						goto IL_0669;
					case 52:
						return;
					case 53:
						goto IL_0252;
					case 54:
						return;
					case 55:
						goto IL_0268;
					case 56:
						goto IL_01FC;
					case 57:
						return;
					case 58:
					{
						TypeInformation typeInformation;
						if (typeInformation.TypeCode != PrimitiveTypeCode.Object)
						{
							num = -1788890097;
							continue;
						}
						type = JsonWriter.smethod_0(typeof(string).TypeHandle);
						goto IL_032A;
					}
					case 59:
						goto IL_0562;
					case 60:
					{
						TypeInformation typeInformation;
						primitiveTypeCode = typeInformation.TypeCode;
						goto IL_0306;
					}
					case 61:
						return;
					case 62:
						return;
					case 63:
						goto IL_0192;
					case 64:
						switch (typeCode)
						{
						case PrimitiveTypeCode.Char:
							goto IL_04C0;
						case PrimitiveTypeCode.CharNullable:
							goto IL_04CD;
						case PrimitiveTypeCode.Boolean:
							goto IL_04ED;
						case PrimitiveTypeCode.BooleanNullable:
							goto IL_00D3;
						case PrimitiveTypeCode.SByte:
							goto IL_04FA;
						case PrimitiveTypeCode.SByteNullable:
							goto IL_0507;
						case PrimitiveTypeCode.Int16:
							goto IL_00FC;
						case PrimitiveTypeCode.Int16Nullable:
							goto IL_0527;
						case PrimitiveTypeCode.UInt16:
							goto IL_0548;
						case PrimitiveTypeCode.UInt16Nullable:
							goto IL_0112;
						case PrimitiveTypeCode.Int32:
							goto IL_0555;
						case PrimitiveTypeCode.Int32Nullable:
							goto IL_0676;
						case PrimitiveTypeCode.Byte:
							goto IL_013C;
						case PrimitiveTypeCode.ByteNullable:
							goto IL_0562;
						case PrimitiveTypeCode.UInt32:
							goto IL_0152;
						case PrimitiveTypeCode.UInt32Nullable:
							goto IL_0168;
						case PrimitiveTypeCode.Int64:
							goto IL_0583;
						case PrimitiveTypeCode.Int64Nullable:
							goto IL_0192;
						case PrimitiveTypeCode.UInt64:
							goto IL_0590;
						case PrimitiveTypeCode.UInt64Nullable:
							goto IL_059D;
						case PrimitiveTypeCode.Single:
							goto IL_05BE;
						case PrimitiveTypeCode.SingleNullable:
							goto IL_01BC;
						case PrimitiveTypeCode.Double:
							goto IL_05CB;
						case PrimitiveTypeCode.DoubleNullable:
							goto IL_05D8;
						case PrimitiveTypeCode.DateTime:
							goto IL_01E6;
						case PrimitiveTypeCode.DateTimeNullable:
							goto IL_05F9;
						case PrimitiveTypeCode.DateTimeOffset:
							goto IL_01FC;
						case PrimitiveTypeCode.DateTimeOffsetNullable:
							goto IL_061A;
						case PrimitiveTypeCode.Decimal:
							goto IL_0212;
						case PrimitiveTypeCode.DecimalNullable:
							goto IL_0228;
						case PrimitiveTypeCode.Guid:
							goto IL_0252;
						case PrimitiveTypeCode.GuidNullable:
							goto IL_063B;
						case PrimitiveTypeCode.TimeSpan:
							goto IL_0697;
						case PrimitiveTypeCode.TimeSpanNullable:
							goto IL_0268;
						case PrimitiveTypeCode.BigInteger:
							goto IL_0292;
						case PrimitiveTypeCode.BigIntegerNullable:
							goto IL_02AD;
						case PrimitiveTypeCode.Uri:
							goto IL_065C;
						case PrimitiveTypeCode.String:
							goto IL_0669;
						case PrimitiveTypeCode.Bytes:
							goto IL_02DC;
						case PrimitiveTypeCode.DBNull:
							goto IL_02F2;
						default:
							num = -1788890055;
							continue;
						}
						break;
					case 65:
					{
						IConvertible convertible;
						object obj = JsonWriter.smethod_13(convertible, type2, JsonWriter.smethod_4());
						num = -1788890067;
						continue;
					}
					case 66:
						goto IL_0676;
					case 67:
						goto IL_0697;
					}
					goto Block_13;
					IL_00D3:
					writer.WriteValue((value == null) ? null : new bool?((bool)value));
					num = -1788890058;
					continue;
					IL_00FC:
					writer.WriteValue((short)value);
					num = -1788890069;
					continue;
					IL_0112:
					writer.WriteValue((value == null) ? null : new ushort?((ushort)value));
					num = -1788890082;
					continue;
					IL_013C:
					writer.WriteValue((byte)value);
					num = -1788890063;
					continue;
					IL_0152:
					writer.WriteValue((uint)value);
					num = -1788890074;
					continue;
					IL_0168:
					writer.WriteValue((value == null) ? null : new uint?((uint)value));
					num = -1788890083;
					continue;
					IL_0192:
					writer.WriteValue((value == null) ? null : new long?((long)value));
					num = -1788890078;
					continue;
					IL_01BC:
					writer.WriteValue((value == null) ? null : new float?((float)value));
					num = -1788890062;
					continue;
					IL_01E6:
					writer.WriteValue((DateTime)value);
					num = -1788890106;
					continue;
					IL_01FC:
					writer.WriteValue((DateTimeOffset)value);
					num = -1788890100;
					continue;
					IL_0212:
					writer.WriteValue((decimal)value);
					num = -1788890093;
					continue;
					IL_0228:
					writer.WriteValue((value == null) ? null : new decimal?((decimal)value));
					num = -1788890060;
					continue;
					IL_0252:
					writer.WriteValue((Guid)value);
					num = -1788890098;
					continue;
					IL_0268:
					writer.WriteValue((value == null) ? null : new TimeSpan?((TimeSpan)value));
					num = -1788890054;
					continue;
					IL_0292:
					writer.WriteValue((BigInteger)value);
					num = -1788890071;
					continue;
					IL_02AD:
					writer.WriteValue((value == null) ? null : new BigInteger?((BigInteger)value));
					num = -1788890079;
					continue;
					IL_02DC:
					writer.WriteValue((byte[])value);
					num = -1788890099;
					continue;
					IL_02F2:
					writer.WriteNull();
					num = -1788890090;
					continue;
					IL_0306:
					primitiveTypeCode2 = primitiveTypeCode;
					num = -1788890075;
					continue;
					IL_032A:
					type2 = type;
					num = -1788890018;
				}
			}
			Block_13:
			throw JsonWriter.CreateUnsupportedTypeException(writer, value);
			IL_04C0:
			writer.WriteValue((char)value);
			return;
			IL_04CD:
			writer.WriteValue((value == null) ? null : new char?((char)value));
			return;
			IL_04ED:
			writer.WriteValue((bool)value);
			return;
			IL_04FA:
			writer.WriteValue((sbyte)value);
			return;
			IL_0507:
			writer.WriteValue((value == null) ? null : new sbyte?((sbyte)value));
			return;
			IL_0527:
			writer.WriteValue((value == null) ? null : new short?((short)value));
			return;
			IL_0548:
			writer.WriteValue((ushort)value);
			return;
			IL_0555:
			writer.WriteValue((int)value);
			return;
			IL_0562:
			writer.WriteValue((value == null) ? null : new byte?((byte)value));
			return;
			IL_0583:
			writer.WriteValue((long)value);
			return;
			IL_0590:
			writer.WriteValue((ulong)value);
			return;
			IL_059D:
			writer.WriteValue((value == null) ? null : new ulong?((ulong)value));
			return;
			IL_05BE:
			writer.WriteValue((float)value);
			return;
			IL_05CB:
			writer.WriteValue((double)value);
			return;
			IL_05D8:
			writer.WriteValue((value == null) ? null : new double?((double)value));
			return;
			IL_05F9:
			writer.WriteValue((value == null) ? null : new DateTime?((DateTime)value));
			return;
			IL_061A:
			writer.WriteValue((value == null) ? null : new DateTimeOffset?((DateTimeOffset)value));
			return;
			IL_063B:
			writer.WriteValue((value == null) ? null : new Guid?((Guid)value));
			return;
			IL_065C:
			writer.WriteValue((Uri)value);
			return;
			IL_0669:
			writer.WriteValue((string)value);
			return;
			IL_0676:
			writer.WriteValue((value == null) ? null : new int?((int)value));
			return;
			IL_0697:
			writer.WriteValue((TimeSpan)value);
		}

		// Token: 0x0600185E RID: 6238 RVA: 0x00017071 File Offset: 0x00015271
		private static JsonWriterException CreateUnsupportedTypeException(JsonWriter writer, object value)
		{
			return JsonWriterException.Create(writer, <Module>.smethod_25<string>(3931790519U).FormatWith(JsonWriter.smethod_4(), JsonWriter.smethod_12(value)), null);
		}

		// Token: 0x0600185F RID: 6239 RVA: 0x00075B34 File Offset: 0x00073D34
		protected void SetWriteState(JsonToken token, object value)
		{
			switch (token)
			{
			case JsonToken.StartObject:
				this.InternalWriteStart(token, JsonContainerType.Object);
				return;
			case JsonToken.StartArray:
				this.InternalWriteStart(token, JsonContainerType.Array);
				return;
			case JsonToken.StartConstructor:
				this.InternalWriteStart(token, JsonContainerType.Constructor);
				return;
			case JsonToken.PropertyName:
				if (value is string)
				{
					this.InternalWritePropertyName((string)value);
					return;
				}
				throw JsonWriter.smethod_14(<Module>.smethod_23<string>(1594612376U), <Module>.smethod_27<string>(2371252898U));
			case JsonToken.Comment:
				this.InternalWriteComment();
				return;
			case JsonToken.Raw:
				this.InternalWriteRaw();
				return;
			case JsonToken.Integer:
			case JsonToken.Float:
			case JsonToken.String:
			case JsonToken.Boolean:
			case JsonToken.Null:
			case JsonToken.Undefined:
			case JsonToken.Date:
			case JsonToken.Bytes:
				this.InternalWriteValue(token);
				return;
			case JsonToken.EndObject:
				this.InternalWriteEnd(JsonContainerType.Object);
				return;
			case JsonToken.EndArray:
				this.InternalWriteEnd(JsonContainerType.Array);
				return;
			case JsonToken.EndConstructor:
				this.InternalWriteEnd(JsonContainerType.Constructor);
				return;
			default:
				throw JsonWriter.smethod_15(<Module>.smethod_27<string>(2006227450U));
			}
		}

		// Token: 0x06001860 RID: 6240 RVA: 0x00017094 File Offset: 0x00015294
		internal void InternalWriteEnd(JsonContainerType container)
		{
			this.AutoCompleteClose(container);
		}

		// Token: 0x06001861 RID: 6241 RVA: 0x0001709D File Offset: 0x0001529D
		internal void InternalWritePropertyName(string name)
		{
			this._currentPosition.PropertyName = name;
			this.AutoComplete(JsonToken.PropertyName);
		}

		// Token: 0x06001862 RID: 6242 RVA: 0x0000C600 File Offset: 0x0000A800
		internal void InternalWriteRaw()
		{
		}

		// Token: 0x06001863 RID: 6243 RVA: 0x000170B2 File Offset: 0x000152B2
		internal void InternalWriteStart(JsonToken token, JsonContainerType container)
		{
			this.UpdateScopeWithFinishedValue();
			this.AutoComplete(token);
			this.Push(container);
		}

		// Token: 0x06001864 RID: 6244 RVA: 0x000170C8 File Offset: 0x000152C8
		internal void InternalWriteValue(JsonToken token)
		{
			this.UpdateScopeWithFinishedValue();
			this.AutoComplete(token);
		}

		// Token: 0x06001865 RID: 6245 RVA: 0x000170D7 File Offset: 0x000152D7
		internal void InternalWriteWhitespace(string ws)
		{
			if (ws != null && !StringUtils.IsWhiteSpace(ws))
			{
				throw JsonWriterException.Create(this, <Module>.smethod_25<string>(2351123890U), null);
			}
		}

		// Token: 0x06001866 RID: 6246 RVA: 0x000170F6 File Offset: 0x000152F6
		internal void InternalWriteComment()
		{
			this.AutoComplete(JsonToken.Comment);
		}

		// Token: 0x06001867 RID: 6247 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_0(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06001868 RID: 6248 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_1(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06001869 RID: 6249 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_2(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x0600186A RID: 6250 RVA: 0x0000EE96 File Offset: 0x0000D096
		static string smethod_3(object object_0, object object_1)
		{
			return object_0 + object_1;
		}

		// Token: 0x0600186B RID: 6251 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_4()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x0600186C RID: 6252 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_5(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x0600186D RID: 6253 RVA: 0x000170FF File Offset: 0x000152FF
		static bool smethod_6(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string.Equals(string_0, string_1, stringComparison_0);
		}

		// Token: 0x0600186E RID: 6254 RVA: 0x00017109 File Offset: 0x00015309
		static long smethod_7(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToInt64(object_0, iformatProvider_0);
		}

		// Token: 0x0600186F RID: 6255 RVA: 0x00017112 File Offset: 0x00015312
		static double smethod_8(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToDouble(object_0, iformatProvider_0);
		}

		// Token: 0x06001870 RID: 6256 RVA: 0x0001711B File Offset: 0x0001531B
		static bool smethod_9(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToBoolean(object_0, iformatProvider_0);
		}

		// Token: 0x06001871 RID: 6257 RVA: 0x00017124 File Offset: 0x00015324
		static DateTime smethod_10(object object_0, IFormatProvider iformatProvider_0)
		{
			return Convert.ToDateTime(object_0, iformatProvider_0);
		}

		// Token: 0x06001872 RID: 6258 RVA: 0x0000FCA7 File Offset: 0x0000DEA7
		static bool smethod_11(Uri uri_0, Uri uri_1)
		{
			return uri_0 == uri_1;
		}

		// Token: 0x06001873 RID: 6259 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_12(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06001874 RID: 6260 RVA: 0x0001712D File Offset: 0x0001532D
		static object smethod_13(IConvertible iconvertible_0, Type type_0, IFormatProvider iformatProvider_0)
		{
			return iconvertible_0.ToType(type_0, iformatProvider_0);
		}

		// Token: 0x06001875 RID: 6261 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_14(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}

		// Token: 0x06001876 RID: 6262 RVA: 0x0000F870 File Offset: 0x0000DA70
		static ArgumentOutOfRangeException smethod_15(string string_0)
		{
			return new ArgumentOutOfRangeException(string_0);
		}

		// Token: 0x04000982 RID: 2434
		private static readonly JsonWriter.State[][] StateArray = JsonWriter.BuildStateArray();

		// Token: 0x04000983 RID: 2435
		internal static readonly JsonWriter.State[][] StateArrayTempate = new JsonWriter.State[][]
		{
			new JsonWriter.State[]
			{
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.Error
			},
			new JsonWriter.State[]
			{
				JsonWriter.State.ObjectStart,
				JsonWriter.State.ObjectStart,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.ObjectStart,
				JsonWriter.State.ObjectStart,
				JsonWriter.State.ObjectStart,
				JsonWriter.State.ObjectStart,
				JsonWriter.State.Error,
				JsonWriter.State.Error
			},
			new JsonWriter.State[]
			{
				JsonWriter.State.ArrayStart,
				JsonWriter.State.ArrayStart,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.ArrayStart,
				JsonWriter.State.ArrayStart,
				JsonWriter.State.ArrayStart,
				JsonWriter.State.ArrayStart,
				JsonWriter.State.Error,
				JsonWriter.State.Error
			},
			new JsonWriter.State[]
			{
				JsonWriter.State.ConstructorStart,
				JsonWriter.State.ConstructorStart,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.ConstructorStart,
				JsonWriter.State.ConstructorStart,
				JsonWriter.State.ConstructorStart,
				JsonWriter.State.ConstructorStart,
				JsonWriter.State.Error,
				JsonWriter.State.Error
			},
			new JsonWriter.State[]
			{
				JsonWriter.State.Property,
				JsonWriter.State.Error,
				JsonWriter.State.Property,
				JsonWriter.State.Property,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.Error
			},
			new JsonWriter.State[]
			{
				JsonWriter.State.Start,
				JsonWriter.State.Property,
				JsonWriter.State.ObjectStart,
				JsonWriter.State.Object,
				JsonWriter.State.ArrayStart,
				JsonWriter.State.Array,
				JsonWriter.State.Constructor,
				JsonWriter.State.Constructor,
				JsonWriter.State.Error,
				JsonWriter.State.Error
			},
			new JsonWriter.State[]
			{
				JsonWriter.State.Start,
				JsonWriter.State.Property,
				JsonWriter.State.ObjectStart,
				JsonWriter.State.Object,
				JsonWriter.State.ArrayStart,
				JsonWriter.State.Array,
				JsonWriter.State.Constructor,
				JsonWriter.State.Constructor,
				JsonWriter.State.Error,
				JsonWriter.State.Error
			},
			new JsonWriter.State[]
			{
				JsonWriter.State.Start,
				JsonWriter.State.Object,
				JsonWriter.State.Error,
				JsonWriter.State.Error,
				JsonWriter.State.Array,
				JsonWriter.State.Array,
				JsonWriter.State.Constructor,
				JsonWriter.State.Constructor,
				JsonWriter.State.Error,
				JsonWriter.State.Error
			}
		};

		// Token: 0x04000984 RID: 2436
		private readonly List<JsonPosition> _stack;

		// Token: 0x04000985 RID: 2437
		private JsonPosition _currentPosition;

		// Token: 0x04000986 RID: 2438
		private JsonWriter.State _currentState;

		// Token: 0x04000987 RID: 2439
		private Formatting _formatting;

		// Token: 0x04000988 RID: 2440
		private DateFormatHandling _dateFormatHandling;

		// Token: 0x04000989 RID: 2441
		private DateTimeZoneHandling _dateTimeZoneHandling;

		// Token: 0x0400098A RID: 2442
		private StringEscapeHandling _stringEscapeHandling;

		// Token: 0x0400098B RID: 2443
		private FloatFormatHandling _floatFormatHandling;

		// Token: 0x0400098C RID: 2444
		private string _dateFormatString;

		// Token: 0x0400098D RID: 2445
		private CultureInfo _culture;

		// Token: 0x0200019C RID: 412
		internal enum State
		{
			// Token: 0x04000990 RID: 2448
			Start,
			// Token: 0x04000991 RID: 2449
			Property,
			// Token: 0x04000992 RID: 2450
			ObjectStart,
			// Token: 0x04000993 RID: 2451
			Object,
			// Token: 0x04000994 RID: 2452
			ArrayStart,
			// Token: 0x04000995 RID: 2453
			Array,
			// Token: 0x04000996 RID: 2454
			ConstructorStart,
			// Token: 0x04000997 RID: 2455
			Constructor,
			// Token: 0x04000998 RID: 2456
			Closed,
			// Token: 0x04000999 RID: 2457
			Error
		}
	}
}
