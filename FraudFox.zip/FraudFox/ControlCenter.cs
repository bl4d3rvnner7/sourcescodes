﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using FraudFox.Socks5;
using Newtonsoft.Json;
using TheArtOfDev.HtmlRenderer.WinForms;

namespace FraudFox
{
	// Token: 0x02000017 RID: 23
	public partial class ControlCenter : Form
	{
		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000128 RID: 296 RVA: 0x0000C6C0 File Offset: 0x0000A8C0
		// (set) Token: 0x06000129 RID: 297 RVA: 0x0000C6C8 File Offset: 0x0000A8C8
		public string Username { get; set; }

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x0600012A RID: 298 RVA: 0x0000C6D1 File Offset: 0x0000A8D1
		// (set) Token: 0x0600012B RID: 299 RVA: 0x0000C6D9 File Offset: 0x0000A8D9
		public string NewsHtml { get; set; }

		// Token: 0x0600012C RID: 300 RVA: 0x00023500 File Offset: 0x00021700
		public ControlCenter(int formSpawned)
		{
			int num = (int)Math.Truncate(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds);
			if (Math.Abs(num - formSpawned) > 10)
			{
				LogManager.AddEntry(string.Format(<Module>.smethod_27<string>(476699041U), Math.Abs(num - formSpawned)), null);
				Application.Exit();
			}
			this.InitializeComponent();
			this._main = new Main(formSpawned)
			{
				Username = this.Username,
				FrmControlCenter = this
			};
		}

		// Token: 0x0600012D RID: 301 RVA: 0x000235A8 File Offset: 0x000217A8
		private string GetSetupDetails()
		{
			string message;
			try
			{
				Process process = ControlCenter.smethod_3();
				ControlCenter.smethod_6(ControlCenter.smethod_4(process), ConfigManager.UserConfigFile.GetValue<string>(<Module>.smethod_27<string>(3839232477U), <Module>.smethod_23<string>(1795504542U), ControlCenter.smethod_5(this._currentPath, <Module>.smethod_23<string>(4176468443U), <Module>.smethod_27<string>(3652745705U))));
				ControlCenter.smethod_7(ControlCenter.smethod_4(process), ConfigManager.UserConfigFile.GetValue<string>(<Module>.smethod_26<string>(3082474271U), <Module>.smethod_24<string>(292608712U), ""));
				ControlCenter.smethod_9(ControlCenter.smethod_4(process), ConfigManager.UserConfigFile.GetValue<string>(<Module>.smethod_27<string>(3839232477U), <Module>.smethod_23<string>(2512189175U), ControlCenter.smethod_8(this._currentPath, <Module>.smethod_26<string>(1673163425U))));
				ControlCenter.smethod_10(ControlCenter.smethod_4(process), ProcessWindowStyle.Hidden);
				ControlCenter.smethod_11(ControlCenter.smethod_4(process), false);
				ControlCenter.smethod_12(ControlCenter.smethod_4(process), true);
				ControlCenter.smethod_13(ControlCenter.smethod_4(process), true);
				ControlCenter.smethod_14(process);
				ControlCenter.smethod_15(10000);
				if (ControlCenter.smethod_16(ControlCenter.smethod_5(this._currentPath, <Module>.smethod_25<string>(3848397821U), <Module>.smethod_25<string>(527794867U))))
				{
					string text = ControlCenter.smethod_18(ControlCenter.smethod_5(this._currentPath, <Module>.smethod_27<string>(2953420310U), <Module>.smethod_24<string>(3598305761U)));
					ControlCenter.smethod_19(ControlCenter.smethod_5(this._currentPath, <Module>.smethod_23<string>(829095782U), <Module>.smethod_23<string>(2144439796U)));
					if (ControlCenter.smethod_20(text) < 2)
					{
						throw ControlCenter.smethod_17(<Module>.smethod_27<string>(2673690152U));
					}
					int num = (int)Math.Truncate(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds);
					Dictionary<string, string> dictionary = new Dictionary<string, string>
					{
						{
							<Module>.smethod_27<string>(3926704323U),
							Assembly.GetEntryAssembly().GetName().Version.ToString()
						},
						{
							<Module>.smethod_23<string>(1559454038U),
							Convert.ToString(num)
						},
						{
							<Module>.smethod_26<string>(4083997908U),
							text
						}
					};
					using (SocksWebClient socksWebClient = new SocksWebClient())
					{
						socksWebClient.Headers[HttpRequestHeader.ContentType] = <Module>.smethod_26<string>(1217494246U);
						string text2 = string.Format(<Module>.smethod_27<string>(2994270463U), <Module>.smethod_24<string>(3475853697U), Uri.EscapeDataString(ControlCenter.EncryptRj256(<Module>.smethod_23<string>(2469420423U), <Module>.smethod_25<string>(3549933219U), dictionary.ToJson())));
						try
						{
							string text3 = socksWebClient.DownloadString(text2);
							return ControlCenter.DecryptRj256(<Module>.smethod_25<string>(3062751048U), <Module>.smethod_26<string>(2703416244U), text3);
						}
						catch (FormatException)
						{
							throw new FormatException(<Module>.smethod_25<string>(4037115390U));
						}
						catch (JsonSerializationException)
						{
							throw new FormatException(<Module>.smethod_27<string>(1409132901U));
						}
					}
				}
				throw ControlCenter.smethod_17(<Module>.smethod_24<string>(929257709U));
			}
			catch (Exception ex)
			{
				message = ex.Message;
			}
			return message;
		}

		// Token: 0x0600012E RID: 302 RVA: 0x000238EC File Offset: 0x00021AEC
		private void ControlCenter_Load(object sender, EventArgs e)
		{
			ControlCenter.smethod_25(this, ControlCenter.smethod_24(<Module>.smethod_24<string>(3353401633U), ControlCenter.smethod_23(ControlCenter.smethod_22(ControlCenter.smethod_21())), this.Username));
			LogManager.AddEntry(ControlCenter.smethod_24(<Module>.smethod_24<string>(4166361255U), ControlCenter.smethod_23(ControlCenter.smethod_22(ControlCenter.smethod_21())), this.Username), null);
			ControlCenter.smethod_25(this.wbNews, this.NewsHtml);
		}

		// Token: 0x0600012F RID: 303 RVA: 0x0000C6E2 File Offset: 0x0000A8E2
		private static void ShowError(string message)
		{
			ControlCenter.smethod_26(message, <Module>.smethod_24<string>(2364131386U), MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x06000130 RID: 304 RVA: 0x00023960 File Offset: 0x00021B60
		private void btnOsfuscator_Click(object sender, EventArgs e)
		{
			try
			{
				Process process = ControlCenter.smethod_3();
				ControlCenter.smethod_6(ControlCenter.smethod_4(process), ControlCenter.smethod_27(this._currentPath, <Module>.smethod_27<string>(3745989091U), <Module>.smethod_25<string>(745960309U), <Module>.smethod_24<string>(3461118755U)));
				ControlCenter.smethod_10(ControlCenter.smethod_4(process), ProcessWindowStyle.Normal);
				ControlCenter.smethod_9(ControlCenter.smethod_4(process), ControlCenter.smethod_5(this._currentPath, <Module>.smethod_27<string>(3745989091U), <Module>.smethod_26<string>(1121730306U)));
				ControlCenter.smethod_14(process);
			}
			catch (Exception ex)
			{
				ControlCenter.ShowError(<Module>.smethod_27<string>(1310117975U));
				LogManager.AddEntry(<Module>.smethod_24<string>(3637429380U), ex);
			}
		}

		// Token: 0x06000131 RID: 305 RVA: 0x00023A18 File Offset: 0x00021C18
		private void btnSocksCap_Click(object sender, EventArgs e)
		{
			try
			{
				Process process = ControlCenter.smethod_3();
				ControlCenter.smethod_6(ControlCenter.smethod_4(process), ControlCenter.smethod_27(this._currentPath, <Module>.smethod_24<string>(3774616386U), <Module>.smethod_23<string>(2974009179U), <Module>.smethod_27<string>(564170887U)));
				ControlCenter.smethod_9(ControlCenter.smethod_4(process), ControlCenter.smethod_5(this._currentPath, <Module>.smethod_27<string>(3745989091U), <Module>.smethod_27<string>(1123631203U)));
				ControlCenter.smethod_10(ControlCenter.smethod_4(process), ProcessWindowStyle.Normal);
				ControlCenter.smethod_14(process);
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_00B9:
					int num = 1644714605;
					for (;;)
					{
						switch (num ^ 1644714607)
						{
						case 0:
							goto IL_00B9;
						case 2:
							ControlCenter.ShowError(<Module>.smethod_25<string>(3112273711U));
							LogManager.AddEntry(<Module>.smethod_26<string>(1902996881U), ex);
							num = 1644714606;
							continue;
						}
						goto Block_3;
					}
				}
				Block_3:;
			}
		}

		// Token: 0x06000132 RID: 306 RVA: 0x00023AF8 File Offset: 0x00021CF8
		private void btnConfig_Click(object sender, EventArgs e)
		{
			try
			{
				Process process = ControlCenter.smethod_3();
				ControlCenter.smethod_6(ControlCenter.smethod_4(process), ControlCenter.smethod_27(this._currentPath, <Module>.smethod_24<string>(3774616386U), <Module>.smethod_23<string>(2625073925U), <Module>.smethod_23<string>(3553854435U)));
				ControlCenter.smethod_9(ControlCenter.smethod_4(process), ControlCenter.smethod_8(this._currentPath, <Module>.smethod_23<string>(885538157U)));
				ControlCenter.smethod_11(ControlCenter.smethod_4(process), true);
				ControlCenter.smethod_7(ControlCenter.smethod_4(process), <Module>.smethod_23<string>(1993926796U));
				ControlCenter.smethod_10(ControlCenter.smethod_4(process), ProcessWindowStyle.Normal);
				ControlCenter.smethod_14(process);
			}
			catch (Exception ex)
			{
				ControlCenter.ShowError(<Module>.smethod_23<string>(4238051320U));
				for (;;)
				{
					IL_00D0:
					int num = 1317176334;
					for (;;)
					{
						switch (num ^ 1317176335)
						{
						case 0:
							goto IL_00D0;
						case 1:
							LogManager.AddEntry(<Module>.smethod_24<string>(880480355U), ex);
							num = 1317176333;
							continue;
						}
						goto Block_3;
					}
				}
				Block_3:;
			}
		}

		// Token: 0x06000133 RID: 307 RVA: 0x0000C6F8 File Offset: 0x0000A8F8
		private void btnNewProfile_Click(object sender, EventArgs e)
		{
			if (!ControlCenter.smethod_28(this._main))
			{
				ControlCenter.smethod_29(this._main);
			}
		}

		// Token: 0x06000134 RID: 308 RVA: 0x0000C712 File Offset: 0x0000A912
		private void btnOpenFile_Click(object sender, EventArgs e)
		{
			if (!ControlCenter.smethod_28(this._main))
			{
				this._main.ImportFileProfile(this);
			}
		}

		// Token: 0x06000135 RID: 309 RVA: 0x0000C72D File Offset: 0x0000A92D
		private void btnOpenTextProfile_Click(object sender, EventArgs e)
		{
			if (!ControlCenter.smethod_28(this._main))
			{
				this._main.ImportTextProfile();
			}
		}

		// Token: 0x06000136 RID: 310 RVA: 0x0000C600 File Offset: 0x0000A800
		private void btnRefresh_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000137 RID: 311 RVA: 0x00023BF0 File Offset: 0x00021DF0
		private static string DecryptRj256(string prmKey, string prmIv, string prmTextToDecrypt)
		{
			RijndaelManaged rijndaelManaged = ControlCenter.smethod_30();
			ControlCenter.smethod_31(rijndaelManaged, PaddingMode.Zeros);
			ControlCenter.smethod_32(rijndaelManaged, CipherMode.CBC);
			ControlCenter.smethod_33(rijndaelManaged, 256);
			ControlCenter.smethod_34(rijndaelManaged, 256);
			byte[] array = ControlCenter.smethod_36(ControlCenter.smethod_35(), prmKey);
			byte[] array2 = ControlCenter.smethod_36(ControlCenter.smethod_35(), prmIv);
			ICryptoTransform cryptoTransform = ControlCenter.smethod_37(rijndaelManaged, array, array2);
			byte[] array3 = ControlCenter.smethod_38(prmTextToDecrypt);
			byte[] array4 = new byte[array3.Length];
			ControlCenter.smethod_41(ControlCenter.smethod_40(ControlCenter.smethod_39(array3), cryptoTransform, CryptoStreamMode.Read), array4, 0, array4.Length);
			return ControlCenter.smethod_42(ControlCenter.smethod_35(), array4);
		}

		// Token: 0x06000138 RID: 312 RVA: 0x00023C78 File Offset: 0x00021E78
		private static string EncryptRj256(string prmKey, string prmIv, string prmTextToEncrypt)
		{
			RijndaelManaged rijndaelManaged = ControlCenter.smethod_30();
			ControlCenter.smethod_31(rijndaelManaged, PaddingMode.Zeros);
			ControlCenter.smethod_32(rijndaelManaged, CipherMode.CBC);
			ControlCenter.smethod_33(rijndaelManaged, 256);
			ControlCenter.smethod_34(rijndaelManaged, 256);
			byte[] array = ControlCenter.smethod_36(ControlCenter.smethod_35(), prmKey);
			byte[] array2 = ControlCenter.smethod_36(ControlCenter.smethod_35(), prmIv);
			ICryptoTransform cryptoTransform = ControlCenter.smethod_43(rijndaelManaged, array, array2);
			MemoryStream memoryStream = ControlCenter.smethod_44();
			CryptoStream cryptoStream = ControlCenter.smethod_40(memoryStream, cryptoTransform, CryptoStreamMode.Write);
			byte[] array3 = ControlCenter.smethod_36(ControlCenter.smethod_35(), prmTextToEncrypt);
			ControlCenter.smethod_45(cryptoStream, array3, 0, array3.Length);
			ControlCenter.smethod_46(cryptoStream);
			return ControlCenter.smethod_48(ControlCenter.smethod_47(memoryStream));
		}

		// Token: 0x06000139 RID: 313 RVA: 0x0000C747 File Offset: 0x0000A947
		private void ControlCenter_FormClosing(object sender, FormClosingEventArgs e)
		{
			LogManager.Flush();
		}

		// Token: 0x0600013A RID: 314 RVA: 0x0000C74E File Offset: 0x0000A94E
		private void ControlCenter_FormClosed(object sender, FormClosedEventArgs e)
		{
			ControlCenter.smethod_49(0);
		}

		// Token: 0x0600013D RID: 317 RVA: 0x0000C65F File Offset: 0x0000A85F
		static Assembly smethod_0()
		{
			return Assembly.GetExecutingAssembly();
		}

		// Token: 0x0600013E RID: 318 RVA: 0x0000C666 File Offset: 0x0000A866
		static string smethod_1(Assembly assembly_0)
		{
			return assembly_0.Location;
		}

		// Token: 0x0600013F RID: 319 RVA: 0x0000C66E File Offset: 0x0000A86E
		static string smethod_2(string string_0)
		{
			return Path.GetDirectoryName(string_0);
		}

		// Token: 0x06000140 RID: 320 RVA: 0x0000C775 File Offset: 0x0000A975
		static Process smethod_3()
		{
			return new Process();
		}

		// Token: 0x06000141 RID: 321 RVA: 0x0000C77C File Offset: 0x0000A97C
		static ProcessStartInfo smethod_4(Process process_0)
		{
			return process_0.StartInfo;
		}

		// Token: 0x06000142 RID: 322 RVA: 0x0000C784 File Offset: 0x0000A984
		static string smethod_5(string string_0, string string_1, string string_2)
		{
			return Path.Combine(string_0, string_1, string_2);
		}

		// Token: 0x06000143 RID: 323 RVA: 0x0000C78E File Offset: 0x0000A98E
		static void smethod_6(ProcessStartInfo processStartInfo_0, string string_0)
		{
			processStartInfo_0.FileName = string_0;
		}

		// Token: 0x06000144 RID: 324 RVA: 0x0000C797 File Offset: 0x0000A997
		static void smethod_7(ProcessStartInfo processStartInfo_0, string string_0)
		{
			processStartInfo_0.Arguments = string_0;
		}

		// Token: 0x06000145 RID: 325 RVA: 0x0000C656 File Offset: 0x0000A856
		static string smethod_8(string string_0, string string_1)
		{
			return Path.Combine(string_0, string_1);
		}

		// Token: 0x06000146 RID: 326 RVA: 0x0000C7A0 File Offset: 0x0000A9A0
		static void smethod_9(ProcessStartInfo processStartInfo_0, string string_0)
		{
			processStartInfo_0.WorkingDirectory = string_0;
		}

		// Token: 0x06000147 RID: 327 RVA: 0x0000C7A9 File Offset: 0x0000A9A9
		static void smethod_10(ProcessStartInfo processStartInfo_0, ProcessWindowStyle processWindowStyle_0)
		{
			processStartInfo_0.WindowStyle = processWindowStyle_0;
		}

		// Token: 0x06000148 RID: 328 RVA: 0x0000C7B2 File Offset: 0x0000A9B2
		static void smethod_11(ProcessStartInfo processStartInfo_0, bool bool_0)
		{
			processStartInfo_0.UseShellExecute = bool_0;
		}

		// Token: 0x06000149 RID: 329 RVA: 0x0000C7BB File Offset: 0x0000A9BB
		static void smethod_12(ProcessStartInfo processStartInfo_0, bool bool_0)
		{
			processStartInfo_0.RedirectStandardOutput = bool_0;
		}

		// Token: 0x0600014A RID: 330 RVA: 0x0000C7C4 File Offset: 0x0000A9C4
		static void smethod_13(ProcessStartInfo processStartInfo_0, bool bool_0)
		{
			processStartInfo_0.CreateNoWindow = bool_0;
		}

		// Token: 0x0600014B RID: 331 RVA: 0x0000C7CD File Offset: 0x0000A9CD
		static bool smethod_14(Process process_0)
		{
			return process_0.Start();
		}

		// Token: 0x0600014C RID: 332 RVA: 0x0000C7D5 File Offset: 0x0000A9D5
		static void smethod_15(int int_0)
		{
			Thread.Sleep(int_0);
		}

		// Token: 0x0600014D RID: 333 RVA: 0x0000C681 File Offset: 0x0000A881
		static bool smethod_16(string string_0)
		{
			return File.Exists(string_0);
		}

		// Token: 0x0600014E RID: 334 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_17(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x0600014F RID: 335 RVA: 0x0000C7E5 File Offset: 0x0000A9E5
		static string smethod_18(string string_0)
		{
			return File.ReadAllText(string_0);
		}

		// Token: 0x06000150 RID: 336 RVA: 0x0000C7ED File Offset: 0x0000A9ED
		static void smethod_19(string string_0)
		{
			File.Delete(string_0);
		}

		// Token: 0x06000151 RID: 337 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_20(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06000152 RID: 338 RVA: 0x0000C7F5 File Offset: 0x0000A9F5
		static Assembly smethod_21()
		{
			return Assembly.GetEntryAssembly();
		}

		// Token: 0x06000153 RID: 339 RVA: 0x0000C7FC File Offset: 0x0000A9FC
		static AssemblyName smethod_22(Assembly assembly_0)
		{
			return assembly_0.GetName();
		}

		// Token: 0x06000154 RID: 340 RVA: 0x0000C804 File Offset: 0x0000AA04
		static Version smethod_23(AssemblyName assemblyName_0)
		{
			return assemblyName_0.Version;
		}

		// Token: 0x06000155 RID: 341 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_24(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x06000156 RID: 342 RVA: 0x0000C816 File Offset: 0x0000AA16
		static void smethod_25(Control control_0, string string_0)
		{
			control_0.Text = string_0;
		}

		// Token: 0x06000157 RID: 343 RVA: 0x0000C81F File Offset: 0x0000AA1F
		static DialogResult smethod_26(string string_0, string string_1, MessageBoxButtons messageBoxButtons_0, MessageBoxIcon messageBoxIcon_0)
		{
			return MessageBox.Show(string_0, string_1, messageBoxButtons_0, messageBoxIcon_0);
		}

		// Token: 0x06000158 RID: 344 RVA: 0x0000C676 File Offset: 0x0000A876
		static string smethod_27(string string_0, string string_1, string string_2, string string_3)
		{
			return Path.Combine(string_0, string_1, string_2, string_3);
		}

		// Token: 0x06000159 RID: 345 RVA: 0x0000C82A File Offset: 0x0000AA2A
		static bool smethod_28(Control control_0)
		{
			return control_0.Visible;
		}

		// Token: 0x0600015A RID: 346 RVA: 0x0000C832 File Offset: 0x0000AA32
		static void smethod_29(Control control_0)
		{
			control_0.Show();
		}

		// Token: 0x0600015B RID: 347 RVA: 0x0000C83A File Offset: 0x0000AA3A
		static RijndaelManaged smethod_30()
		{
			return new RijndaelManaged();
		}

		// Token: 0x0600015C RID: 348 RVA: 0x0000C841 File Offset: 0x0000AA41
		static void smethod_31(SymmetricAlgorithm symmetricAlgorithm_0, PaddingMode paddingMode_0)
		{
			symmetricAlgorithm_0.Padding = paddingMode_0;
		}

		// Token: 0x0600015D RID: 349 RVA: 0x0000C84A File Offset: 0x0000AA4A
		static void smethod_32(SymmetricAlgorithm symmetricAlgorithm_0, CipherMode cipherMode_0)
		{
			symmetricAlgorithm_0.Mode = cipherMode_0;
		}

		// Token: 0x0600015E RID: 350 RVA: 0x0000C853 File Offset: 0x0000AA53
		static void smethod_33(SymmetricAlgorithm symmetricAlgorithm_0, int int_0)
		{
			symmetricAlgorithm_0.KeySize = int_0;
		}

		// Token: 0x0600015F RID: 351 RVA: 0x0000C85C File Offset: 0x0000AA5C
		static void smethod_34(SymmetricAlgorithm symmetricAlgorithm_0, int int_0)
		{
			symmetricAlgorithm_0.BlockSize = int_0;
		}

		// Token: 0x06000160 RID: 352 RVA: 0x0000C3FB File Offset: 0x0000A5FB
		static Encoding smethod_35()
		{
			return Encoding.ASCII;
		}

		// Token: 0x06000161 RID: 353 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_36(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x06000162 RID: 354 RVA: 0x0000C865 File Offset: 0x0000AA65
		static ICryptoTransform smethod_37(SymmetricAlgorithm symmetricAlgorithm_0, byte[] byte_0, byte[] byte_1)
		{
			return symmetricAlgorithm_0.CreateDecryptor(byte_0, byte_1);
		}

		// Token: 0x06000163 RID: 355 RVA: 0x0000C86F File Offset: 0x0000AA6F
		static byte[] smethod_38(string string_0)
		{
			return Convert.FromBase64String(string_0);
		}

		// Token: 0x06000164 RID: 356 RVA: 0x0000C877 File Offset: 0x0000AA77
		static MemoryStream smethod_39(byte[] byte_0)
		{
			return new MemoryStream(byte_0);
		}

		// Token: 0x06000165 RID: 357 RVA: 0x0000C87F File Offset: 0x0000AA7F
		static CryptoStream smethod_40(Stream stream_0, ICryptoTransform icryptoTransform_0, CryptoStreamMode cryptoStreamMode_0)
		{
			return new CryptoStream(stream_0, icryptoTransform_0, cryptoStreamMode_0);
		}

		// Token: 0x06000166 RID: 358 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_41(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06000167 RID: 359 RVA: 0x0000C894 File Offset: 0x0000AA94
		static string smethod_42(Encoding encoding_0, byte[] byte_0)
		{
			return encoding_0.GetString(byte_0);
		}

		// Token: 0x06000168 RID: 360 RVA: 0x0000C89D File Offset: 0x0000AA9D
		static ICryptoTransform smethod_43(SymmetricAlgorithm symmetricAlgorithm_0, byte[] byte_0, byte[] byte_1)
		{
			return symmetricAlgorithm_0.CreateEncryptor(byte_0, byte_1);
		}

		// Token: 0x06000169 RID: 361 RVA: 0x0000C8A7 File Offset: 0x0000AAA7
		static MemoryStream smethod_44()
		{
			return new MemoryStream();
		}

		// Token: 0x0600016A RID: 362 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_45(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x0600016B RID: 363 RVA: 0x0000C8B9 File Offset: 0x0000AAB9
		static void smethod_46(CryptoStream cryptoStream_0)
		{
			cryptoStream_0.FlushFinalBlock();
		}

		// Token: 0x0600016C RID: 364 RVA: 0x0000C8C1 File Offset: 0x0000AAC1
		static byte[] smethod_47(MemoryStream memoryStream_0)
		{
			return memoryStream_0.ToArray();
		}

		// Token: 0x0600016D RID: 365 RVA: 0x0000C8C9 File Offset: 0x0000AAC9
		static string smethod_48(byte[] byte_0)
		{
			return Convert.ToBase64String(byte_0);
		}

		// Token: 0x0600016E RID: 366 RVA: 0x0000C8D1 File Offset: 0x0000AAD1
		static void smethod_49(int int_0)
		{
			Environment.Exit(int_0);
		}

		// Token: 0x0600016F RID: 367 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_50(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06000170 RID: 368 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_51(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06000171 RID: 369 RVA: 0x0000C8E9 File Offset: 0x0000AAE9
		static ComponentResourceManager smethod_52(Type type_0)
		{
			return new ComponentResourceManager(type_0);
		}

		// Token: 0x06000172 RID: 370 RVA: 0x0000C8F1 File Offset: 0x0000AAF1
		static GroupBox smethod_53()
		{
			return new GroupBox();
		}

		// Token: 0x06000173 RID: 371 RVA: 0x0000C8F8 File Offset: 0x0000AAF8
		static Button smethod_54()
		{
			return new Button();
		}

		// Token: 0x06000174 RID: 372 RVA: 0x0000C8FF File Offset: 0x0000AAFF
		static void smethod_55(Control control_0)
		{
			control_0.SuspendLayout();
		}

		// Token: 0x06000175 RID: 373 RVA: 0x0000C907 File Offset: 0x0000AB07
		static void smethod_56(Control control_0)
		{
			control_0.SuspendLayout();
		}

		// Token: 0x06000176 RID: 374 RVA: 0x0000C90F File Offset: 0x0000AB0F
		static Control.ControlCollection smethod_57(Control control_0)
		{
			return control_0.Controls;
		}

		// Token: 0x06000177 RID: 375 RVA: 0x0000C917 File Offset: 0x0000AB17
		static void smethod_58(Control.ControlCollection controlCollection_0, Control control_0)
		{
			controlCollection_0.Add(control_0);
		}

		// Token: 0x0400004B RID: 75
		private readonly string _currentPath = ControlCenter.smethod_2(ControlCenter.smethod_1(ControlCenter.smethod_0()));

		// Token: 0x0400004C RID: 76
		private const string CommunicationServer = "ba434tkccyddp2oq.onion";

		// Token: 0x0400004D RID: 77
		private const string CommunicationKey = "f2RxsiYmqHgKzBzlGgPREbjq6J4FtIy7";

		// Token: 0x0400004E RID: 78
		private const string CommunicationIv = "dzRrmdq25XwU3AHFq3mgfRdezftr9bOU";

		// Token: 0x0400004F RID: 79
		private Main _main;
	}
}
