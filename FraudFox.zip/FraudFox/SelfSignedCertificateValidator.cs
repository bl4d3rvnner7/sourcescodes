﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Threading;

namespace FraudFox
{
	// Token: 0x0200003F RID: 63
	public class SelfSignedCertificateValidator
	{
		// Token: 0x06000485 RID: 1157 RVA: 0x00032E04 File Offset: 0x00031004
		private SelfSignedCertificateValidator()
		{
			bool flag = false;
			try
			{
				SelfSignedCertificateValidator.smethod_0(this, ref flag);
				if (SelfSignedCertificateValidator.__createdSingleton)
				{
					throw SelfSignedCertificateValidator.smethod_1(<Module>.smethod_25<string>(20610621U));
				}
				SelfSignedCertificateValidator.smethod_4((RemoteCertificateValidationCallback)SelfSignedCertificateValidator.smethod_3(SelfSignedCertificateValidator.smethod_2(), new RemoteCertificateValidationCallback(this.ValidateServerCertficate)));
				SelfSignedCertificateValidator.__createdSingleton = true;
			}
			finally
			{
				if (flag)
				{
					SelfSignedCertificateValidator.smethod_5(this);
				}
			}
		}

		// Token: 0x06000486 RID: 1158 RVA: 0x0000DBD0 File Offset: 0x0000BDD0
		public static SelfSignedCertificateValidator Create()
		{
			return new SelfSignedCertificateValidator();
		}

		// Token: 0x06000487 RID: 1159 RVA: 0x00032EB0 File Offset: 0x000310B0
		private bool ValidateServerCertficate(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors sslPolicyErrors)
		{
			return sslPolicyErrors == SslPolicyErrors.None || this.__knownSelfSignedCertificates.Any((SelfSignedCertificateValidator.CertificateAttributes c) => c.IsMatch(cert));
		}

		// Token: 0x06000488 RID: 1160 RVA: 0x0000DBD7 File Offset: 0x0000BDD7
		static void smethod_0(object object_0, ref bool bool_0)
		{
			Monitor.Enter(object_0, ref bool_0);
		}

		// Token: 0x06000489 RID: 1161 RVA: 0x0000CFEC File Offset: 0x0000B1EC
		static ApplicationException smethod_1(string string_0)
		{
			return new ApplicationException(string_0);
		}

		// Token: 0x0600048A RID: 1162 RVA: 0x0000DBE0 File Offset: 0x0000BDE0
		static RemoteCertificateValidationCallback smethod_2()
		{
			return ServicePointManager.ServerCertificateValidationCallback;
		}

		// Token: 0x0600048B RID: 1163 RVA: 0x0000CD19 File Offset: 0x0000AF19
		static Delegate smethod_3(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Combine(delegate_0, delegate_1);
		}

		// Token: 0x0600048C RID: 1164 RVA: 0x0000DBE7 File Offset: 0x0000BDE7
		static void smethod_4(RemoteCertificateValidationCallback remoteCertificateValidationCallback_0)
		{
			ServicePointManager.ServerCertificateValidationCallback = remoteCertificateValidationCallback_0;
		}

		// Token: 0x0600048D RID: 1165 RVA: 0x0000DBEF File Offset: 0x0000BDEF
		static void smethod_5(object object_0)
		{
			Monitor.Exit(object_0);
		}

		// Token: 0x0400019A RID: 410
		private readonly List<SelfSignedCertificateValidator.CertificateAttributes> __knownSelfSignedCertificates = new List<SelfSignedCertificateValidator.CertificateAttributes>
		{
			new SelfSignedCertificateValidator.CertificateAttributes(<Module>.smethod_24<string>(2532817409U), <Module>.smethod_25<string>(3689200840U), <Module>.smethod_24<string>(2180196159U))
		};

		// Token: 0x0400019B RID: 411
		private static bool __createdSingleton;

		// Token: 0x02000040 RID: 64
		private class CertificateAttributes
		{
			// Token: 0x1700005F RID: 95
			// (get) Token: 0x0600048E RID: 1166 RVA: 0x0000DBF7 File Offset: 0x0000BDF7
			// (set) Token: 0x0600048F RID: 1167 RVA: 0x0000DBFF File Offset: 0x0000BDFF
			public string Subject { get; private set; }

			// Token: 0x17000060 RID: 96
			// (get) Token: 0x06000490 RID: 1168 RVA: 0x0000DC08 File Offset: 0x0000BE08
			// (set) Token: 0x06000491 RID: 1169 RVA: 0x0000DC10 File Offset: 0x0000BE10
			public string Issuer { get; private set; }

			// Token: 0x17000061 RID: 97
			// (get) Token: 0x06000492 RID: 1170 RVA: 0x0000DC19 File Offset: 0x0000BE19
			// (set) Token: 0x06000493 RID: 1171 RVA: 0x0000DC21 File Offset: 0x0000BE21
			public string Thumbprint { get; private set; }

			// Token: 0x06000494 RID: 1172 RVA: 0x0000DC2A File Offset: 0x0000BE2A
			public CertificateAttributes(string subject, string issuer, string thumbprint)
			{
				this.Subject = subject;
				this.Issuer = issuer;
				this.Thumbprint = SelfSignedCertificateValidator.CertificateAttributes.smethod_0(thumbprint, new char[] { '\u200e', '\u200f' });
			}

			// Token: 0x06000495 RID: 1173 RVA: 0x00032EE8 File Offset: 0x000310E8
			public bool IsMatch(X509Certificate cert)
			{
				bool flag = SelfSignedCertificateValidator.CertificateAttributes.smethod_3(SelfSignedCertificateValidator.CertificateAttributes.smethod_1(this.Subject, <Module>.smethod_26<string>(2342675128U), ""), SelfSignedCertificateValidator.CertificateAttributes.smethod_1(SelfSignedCertificateValidator.CertificateAttributes.smethod_2(cert), <Module>.smethod_25<string>(482330791U), ""), StringComparison.InvariantCulture);
				bool flag2 = SelfSignedCertificateValidator.CertificateAttributes.smethod_3(SelfSignedCertificateValidator.CertificateAttributes.smethod_1(this.Issuer, <Module>.smethod_27<string>(2931232896U), ""), SelfSignedCertificateValidator.CertificateAttributes.smethod_1(SelfSignedCertificateValidator.CertificateAttributes.smethod_4(cert), <Module>.smethod_23<string>(4219134048U), ""), StringComparison.InvariantCulture);
				bool flag3 = SelfSignedCertificateValidator.CertificateAttributes.smethod_7(this.Thumbprint, SelfSignedCertificateValidator.CertificateAttributes.smethod_6(<Module>.smethod_25<string>(482330791U), (from h in SelfSignedCertificateValidator.CertificateAttributes.smethod_5(cert)
					select h.ToString(<Module>.smethod_27<string>(3330367902U))).ToArray<string>()));
				return flag && flag2 && flag3;
			}

			// Token: 0x06000496 RID: 1174 RVA: 0x0000DC62 File Offset: 0x0000BE62
			static string smethod_0(string string_0, char[] char_0)
			{
				return string_0.Trim(char_0);
			}

			// Token: 0x06000497 RID: 1175 RVA: 0x0000C689 File Offset: 0x0000A889
			static string smethod_1(string string_0, string string_1, string string_2)
			{
				return string_0.Replace(string_1, string_2);
			}

			// Token: 0x06000498 RID: 1176 RVA: 0x0000DC6B File Offset: 0x0000BE6B
			static string smethod_2(X509Certificate x509Certificate_0)
			{
				return x509Certificate_0.Subject;
			}

			// Token: 0x06000499 RID: 1177 RVA: 0x0000D0A2 File Offset: 0x0000B2A2
			static bool smethod_3(string string_0, string string_1, StringComparison stringComparison_0)
			{
				return string_0.Equals(string_1, stringComparison_0);
			}

			// Token: 0x0600049A RID: 1178 RVA: 0x0000DC73 File Offset: 0x0000BE73
			static string smethod_4(X509Certificate x509Certificate_0)
			{
				return x509Certificate_0.Issuer;
			}

			// Token: 0x0600049B RID: 1179 RVA: 0x0000DC7B File Offset: 0x0000BE7B
			static byte[] smethod_5(X509Certificate x509Certificate_0)
			{
				return x509Certificate_0.GetCertHash();
			}

			// Token: 0x0600049C RID: 1180 RVA: 0x0000DAF6 File Offset: 0x0000BCF6
			static string smethod_6(string string_0, string[] string_1)
			{
				return string.Join(string_0, string_1);
			}

			// Token: 0x0600049D RID: 1181 RVA: 0x0000CD45 File Offset: 0x0000AF45
			static bool smethod_7(string string_0, string string_1)
			{
				return string_0 == string_1;
			}
		}
	}
}
