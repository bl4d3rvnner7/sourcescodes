﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace Ionic.Crc
{
	// Token: 0x02000158 RID: 344
	[ClassInterface(ClassInterfaceType.AutoDispatch)]
	[ComVisible(true)]
	[Guid("ebc25cf6-9120-4283-b972-0e5520d0000C")]
	public class CRC32
	{
		// Token: 0x17000322 RID: 802
		// (get) Token: 0x06001569 RID: 5481 RVA: 0x0001580A File Offset: 0x00013A0A
		public long TotalBytesRead
		{
			get
			{
				return this._TotalBytesRead;
			}
		}

		// Token: 0x17000323 RID: 803
		// (get) Token: 0x0600156A RID: 5482 RVA: 0x00015812 File Offset: 0x00013A12
		public int Crc32Result
		{
			get
			{
				return (int)(~(int)this._register);
			}
		}

		// Token: 0x0600156B RID: 5483 RVA: 0x0001581B File Offset: 0x00013A1B
		public int GetCrc32(Stream input)
		{
			return this.GetCrc32AndCopy(input, null);
		}

		// Token: 0x0600156C RID: 5484 RVA: 0x0006FA84 File Offset: 0x0006DC84
		public int GetCrc32AndCopy(Stream input, Stream output)
		{
			if (input == null)
			{
				throw CRC32.smethod_0(<Module>.smethod_23<string>(2586826793U));
			}
			byte[] array = new byte[8192];
			int num = 8192;
			this._TotalBytesRead = 0L;
			int i = CRC32.smethod_1(input, array, 0, 8192);
			if (output != null)
			{
				CRC32.smethod_2(output, array, 0, i);
			}
			this._TotalBytesRead += (long)i;
			while (i > 0)
			{
				this.SlurpBlock(array, 0, i);
				i = CRC32.smethod_1(input, array, 0, num);
				if (output != null)
				{
					CRC32.smethod_2(output, array, 0, i);
				}
				this._TotalBytesRead += (long)i;
			}
			return (int)(~(int)this._register);
		}

		// Token: 0x0600156D RID: 5485 RVA: 0x00015825 File Offset: 0x00013A25
		public int ComputeCrc32(int W, byte B)
		{
			return this._InternalComputeCrc32((uint)W, B);
		}

		// Token: 0x0600156E RID: 5486 RVA: 0x0001582F File Offset: 0x00013A2F
		internal int _InternalComputeCrc32(uint W, byte B)
		{
			return (int)(this.crc32Table[(int)((UIntPtr)((W ^ (uint)B) & 255U))] ^ (W >> 8));
		}

		// Token: 0x0600156F RID: 5487 RVA: 0x0006FB28 File Offset: 0x0006DD28
		public void SlurpBlock(byte[] block, int offset, int count)
		{
			if (block == null)
			{
				throw CRC32.smethod_0(<Module>.smethod_26<string>(2450159789U));
			}
			for (int i = 0; i < count; i++)
			{
				int num = offset + i;
				byte b = block[num];
				if (!this.reverseBits)
				{
					uint num2 = (this._register & 255U) ^ (uint)b;
					this._register = (this._register >> 8) ^ this.crc32Table[(int)((UIntPtr)num2)];
				}
				else
				{
					uint num3 = (this._register >> 24) ^ (uint)b;
					this._register = (this._register << 8) ^ this.crc32Table[(int)((UIntPtr)num3)];
				}
			}
			this._TotalBytesRead += (long)count;
		}

		// Token: 0x06001570 RID: 5488 RVA: 0x0006FBC4 File Offset: 0x0006DDC4
		public void UpdateCRC(byte b)
		{
			if (this.reverseBits)
			{
				uint num = (this._register >> 24) ^ (uint)b;
				this._register = (this._register << 8) ^ this.crc32Table[(int)((UIntPtr)num)];
				return;
			}
			uint num2 = (this._register & 255U) ^ (uint)b;
			this._register = (this._register >> 8) ^ this.crc32Table[(int)((UIntPtr)num2)];
		}

		// Token: 0x06001571 RID: 5489 RVA: 0x0006FC28 File Offset: 0x0006DE28
		public void UpdateCRC(byte b, int n)
		{
			while (n-- > 0)
			{
				if (this.reverseBits)
				{
					uint num = (this._register >> 24) ^ (uint)b;
					this._register = (this._register << 8) ^ this.crc32Table[(int)((UIntPtr)num)];
				}
				else
				{
					uint num2 = (this._register & 255U) ^ (uint)b;
					this._register = (this._register >> 8) ^ this.crc32Table[(int)((UIntPtr)num2)];
				}
			}
		}

		// Token: 0x06001572 RID: 5490 RVA: 0x0006FC98 File Offset: 0x0006DE98
		private static uint ReverseBits(uint data)
		{
			uint num = ((data & 1431655765U) << 1) | ((data >> 1) & 1431655765U);
			num = ((num & 858993459U) << 2) | ((num >> 2) & 858993459U);
			num = ((num & 252645135U) << 4) | ((num >> 4) & 252645135U);
			return (num << 24) | ((num & 65280U) << 8) | ((num >> 8) & 65280U) | (num >> 24);
		}

		// Token: 0x06001573 RID: 5491 RVA: 0x0006FD04 File Offset: 0x0006DF04
		private static byte ReverseBits(byte data)
		{
			uint num = (uint)data * 131586U;
			uint num2 = num & 17055760U;
			uint num3 = (num << 2) & 34111520U;
			return (byte)(16781313U * (num2 + num3) >> 24);
		}

		// Token: 0x06001574 RID: 5492 RVA: 0x0006FD38 File Offset: 0x0006DF38
		private void GenerateLookupTable()
		{
			this.crc32Table = new uint[256];
			byte b = 0;
			do
			{
				uint num = (uint)b;
				for (byte b2 = 8; b2 > 0; b2 -= 1)
				{
					if ((num & 1U) == 1U)
					{
						num = (num >> 1) ^ this.dwPolynomial;
					}
					else
					{
						num >>= 1;
					}
				}
				if (!this.reverseBits)
				{
					this.crc32Table[(int)b] = num;
				}
				else
				{
					this.crc32Table[(int)CRC32.ReverseBits(b)] = CRC32.ReverseBits(num);
				}
				b += 1;
			}
			while (b != 0);
		}

		// Token: 0x06001575 RID: 5493 RVA: 0x0006FDB0 File Offset: 0x0006DFB0
		private uint gf2_matrix_times(uint[] matrix, uint vec)
		{
			uint num = 0U;
			int num2 = 0;
			while (vec != 0U)
			{
				if ((vec & 1U) == 1U)
				{
					num ^= matrix[num2];
				}
				vec >>= 1;
				num2++;
			}
			return num;
		}

		// Token: 0x06001576 RID: 5494 RVA: 0x0006FDDC File Offset: 0x0006DFDC
		private void gf2_matrix_square(uint[] square, uint[] mat)
		{
			for (int i = 0; i < 32; i++)
			{
				square[i] = this.gf2_matrix_times(mat, mat[i]);
			}
		}

		// Token: 0x06001577 RID: 5495 RVA: 0x0006FE04 File Offset: 0x0006E004
		public void Combine(int crc, int length)
		{
			uint[] array = new uint[32];
			uint[] array2 = new uint[32];
			if (length == 0)
			{
				return;
			}
			uint num = ~this._register;
			array2[0] = this.dwPolynomial;
			uint num2 = 1U;
			for (int i = 1; i < 32; i++)
			{
				array2[i] = num2;
				num2 <<= 1;
			}
			this.gf2_matrix_square(array, array2);
			this.gf2_matrix_square(array2, array);
			uint num3 = (uint)length;
			do
			{
				this.gf2_matrix_square(array, array2);
				if ((num3 & 1U) == 1U)
				{
					num = this.gf2_matrix_times(array, num);
				}
				num3 >>= 1;
				if (num3 == 0U)
				{
					break;
				}
				this.gf2_matrix_square(array2, array);
				if ((num3 & 1U) == 1U)
				{
					num = this.gf2_matrix_times(array2, num);
				}
				num3 >>= 1;
			}
			while (num3 != 0U);
			num ^= (uint)crc;
			this._register = ~num;
		}

		// Token: 0x06001578 RID: 5496 RVA: 0x00015846 File Offset: 0x00013A46
		public CRC32()
			: this(false)
		{
		}

		// Token: 0x06001579 RID: 5497 RVA: 0x0001584F File Offset: 0x00013A4F
		public CRC32(bool reverseBits)
			: this(-306674912, reverseBits)
		{
		}

		// Token: 0x0600157A RID: 5498 RVA: 0x0001585D File Offset: 0x00013A5D
		public CRC32(int polynomial, bool reverseBits)
		{
			this.reverseBits = reverseBits;
			this.dwPolynomial = (uint)polynomial;
			this.GenerateLookupTable();
		}

		// Token: 0x0600157B RID: 5499 RVA: 0x00015880 File Offset: 0x00013A80
		public void Reset()
		{
			this._register = uint.MaxValue;
		}

		// Token: 0x0600157C RID: 5500 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_0(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x0600157D RID: 5501 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_1(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x0600157E RID: 5502 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_2(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x04000877 RID: 2167
		private const int BUFFER_SIZE = 8192;

		// Token: 0x04000878 RID: 2168
		private uint dwPolynomial;

		// Token: 0x04000879 RID: 2169
		private long _TotalBytesRead;

		// Token: 0x0400087A RID: 2170
		private bool reverseBits;

		// Token: 0x0400087B RID: 2171
		private uint[] crc32Table;

		// Token: 0x0400087C RID: 2172
		private uint _register = uint.MaxValue;
	}
}
