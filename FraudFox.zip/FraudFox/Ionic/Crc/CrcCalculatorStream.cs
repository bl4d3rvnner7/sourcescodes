﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace Ionic.Crc
{
	// Token: 0x02000159 RID: 345
	[ComVisible(true)]
	public class CrcCalculatorStream : Stream, IDisposable
	{
		// Token: 0x0600157F RID: 5503 RVA: 0x00015889 File Offset: 0x00013A89
		public CrcCalculatorStream(Stream stream)
			: this(true, CrcCalculatorStream.UnsetLengthLimit, stream, null)
		{
		}

		// Token: 0x06001580 RID: 5504 RVA: 0x00015899 File Offset: 0x00013A99
		public CrcCalculatorStream(Stream stream, bool leaveOpen)
			: this(leaveOpen, CrcCalculatorStream.UnsetLengthLimit, stream, null)
		{
		}

		// Token: 0x06001581 RID: 5505 RVA: 0x000158A9 File Offset: 0x00013AA9
		public CrcCalculatorStream(Stream stream, long length)
			: this(true, length, stream, null)
		{
			if (length < 0L)
			{
				throw CrcCalculatorStream.smethod_0(<Module>.smethod_26<string>(1439332236U));
			}
		}

		// Token: 0x06001582 RID: 5506 RVA: 0x000158D1 File Offset: 0x00013AD1
		public CrcCalculatorStream(Stream stream, long length, bool leaveOpen)
			: this(leaveOpen, length, stream, null)
		{
			if (length < 0L)
			{
				throw CrcCalculatorStream.smethod_0(<Module>.smethod_25<string>(770020971U));
			}
		}

		// Token: 0x06001583 RID: 5507 RVA: 0x000158F9 File Offset: 0x00013AF9
		public CrcCalculatorStream(Stream stream, long length, bool leaveOpen, CRC32 crc32)
			: this(leaveOpen, length, stream, crc32)
		{
			if (length < 0L)
			{
				throw CrcCalculatorStream.smethod_0(<Module>.smethod_26<string>(1439332236U));
			}
		}

		// Token: 0x06001584 RID: 5508 RVA: 0x0006FEC8 File Offset: 0x0006E0C8
		private CrcCalculatorStream(bool leaveOpen, long length, Stream stream, CRC32 crc32)
		{
			if (stream == null)
			{
				throw CrcCalculatorStream.smethod_1(<Module>.smethod_23<string>(848935761U));
			}
			this._innerStream = stream;
			this._crc32 = crc32 ?? new CRC32();
			this._lengthLimit = length;
			this._leaveOpen = leaveOpen;
		}

		// Token: 0x17000324 RID: 804
		// (get) Token: 0x06001585 RID: 5509 RVA: 0x00015922 File Offset: 0x00013B22
		public long TotalBytesSlurped
		{
			get
			{
				return this._crc32.TotalBytesRead;
			}
		}

		// Token: 0x17000325 RID: 805
		// (get) Token: 0x06001586 RID: 5510 RVA: 0x0001592F File Offset: 0x00013B2F
		public int Crc
		{
			get
			{
				return this._crc32.Crc32Result;
			}
		}

		// Token: 0x17000326 RID: 806
		// (get) Token: 0x06001587 RID: 5511 RVA: 0x0001593C File Offset: 0x00013B3C
		// (set) Token: 0x06001588 RID: 5512 RVA: 0x00015944 File Offset: 0x00013B44
		public bool LeaveOpen
		{
			get
			{
				return this._leaveOpen;
			}
			set
			{
				this._leaveOpen = value;
			}
		}

		// Token: 0x06001589 RID: 5513 RVA: 0x0006FF24 File Offset: 0x0006E124
		public override int Read(byte[] buffer, int offset, int count)
		{
			int num = count;
			if (this._lengthLimit != CrcCalculatorStream.UnsetLengthLimit)
			{
				if (this._crc32.TotalBytesRead >= this._lengthLimit)
				{
					return 0;
				}
				long num2 = this._lengthLimit - this._crc32.TotalBytesRead;
				if (num2 < (long)count)
				{
					num = (int)num2;
				}
			}
			int num3 = CrcCalculatorStream.smethod_2(this._innerStream, buffer, offset, num);
			if (num3 > 0)
			{
				this._crc32.SlurpBlock(buffer, offset, num3);
			}
			return num3;
		}

		// Token: 0x0600158A RID: 5514 RVA: 0x0001594D File Offset: 0x00013B4D
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (count > 0)
			{
				this._crc32.SlurpBlock(buffer, offset, count);
			}
			CrcCalculatorStream.smethod_3(this._innerStream, buffer, offset, count);
		}

		// Token: 0x17000327 RID: 807
		// (get) Token: 0x0600158B RID: 5515 RVA: 0x0001596F File Offset: 0x00013B6F
		public override bool CanRead
		{
			get
			{
				return CrcCalculatorStream.smethod_4(this._innerStream);
			}
		}

		// Token: 0x17000328 RID: 808
		// (get) Token: 0x0600158C RID: 5516 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000329 RID: 809
		// (get) Token: 0x0600158D RID: 5517 RVA: 0x0001597C File Offset: 0x00013B7C
		public override bool CanWrite
		{
			get
			{
				return CrcCalculatorStream.smethod_5(this._innerStream);
			}
		}

		// Token: 0x0600158E RID: 5518 RVA: 0x00015989 File Offset: 0x00013B89
		public override void Flush()
		{
			CrcCalculatorStream.smethod_6(this._innerStream);
		}

		// Token: 0x1700032A RID: 810
		// (get) Token: 0x0600158F RID: 5519 RVA: 0x00015996 File Offset: 0x00013B96
		public override long Length
		{
			get
			{
				if (this._lengthLimit == CrcCalculatorStream.UnsetLengthLimit)
				{
					return CrcCalculatorStream.smethod_7(this._innerStream);
				}
				return this._lengthLimit;
			}
		}

		// Token: 0x1700032B RID: 811
		// (get) Token: 0x06001590 RID: 5520 RVA: 0x00015922 File Offset: 0x00013B22
		// (set) Token: 0x06001591 RID: 5521 RVA: 0x000159B7 File Offset: 0x00013BB7
		public override long Position
		{
			get
			{
				return this._crc32.TotalBytesRead;
			}
			set
			{
				throw CrcCalculatorStream.smethod_8();
			}
		}

		// Token: 0x06001592 RID: 5522 RVA: 0x000159B7 File Offset: 0x00013BB7
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw CrcCalculatorStream.smethod_8();
		}

		// Token: 0x06001593 RID: 5523 RVA: 0x000159B7 File Offset: 0x00013BB7
		public override void SetLength(long value)
		{
			throw CrcCalculatorStream.smethod_8();
		}

		// Token: 0x06001594 RID: 5524 RVA: 0x000159BE File Offset: 0x00013BBE
		void IDisposable.Dispose()
		{
			CrcCalculatorStream.smethod_9(this);
		}

		// Token: 0x06001595 RID: 5525 RVA: 0x000159C6 File Offset: 0x00013BC6
		public override void Close()
		{
			this.method_0();
			if (!this._leaveOpen)
			{
				CrcCalculatorStream.smethod_9(this._innerStream);
			}
		}

		// Token: 0x06001597 RID: 5527 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_0(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x06001598 RID: 5528 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_1(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x06001599 RID: 5529 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_2(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x0600159A RID: 5530 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_3(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x0600159B RID: 5531 RVA: 0x00012837 File Offset: 0x00010A37
		static bool smethod_4(Stream stream_0)
		{
			return stream_0.CanRead;
		}

		// Token: 0x0600159C RID: 5532 RVA: 0x00012D86 File Offset: 0x00010F86
		static bool smethod_5(Stream stream_0)
		{
			return stream_0.CanWrite;
		}

		// Token: 0x0600159D RID: 5533 RVA: 0x00012D8E File Offset: 0x00010F8E
		static void smethod_6(Stream stream_0)
		{
			stream_0.Flush();
		}

		// Token: 0x0600159E RID: 5534 RVA: 0x00012BE5 File Offset: 0x00010DE5
		static long smethod_7(Stream stream_0)
		{
			return stream_0.Length;
		}

		// Token: 0x0600159F RID: 5535 RVA: 0x0000E031 File Offset: 0x0000C231
		static NotSupportedException smethod_8()
		{
			return new NotSupportedException();
		}

		// Token: 0x060015A0 RID: 5536 RVA: 0x00012E9A File Offset: 0x0001109A
		static void smethod_9(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x060015A1 RID: 5537 RVA: 0x00012EA2 File Offset: 0x000110A2
		void method_0()
		{
			base.Close();
		}

		// Token: 0x0400087D RID: 2173
		private static readonly long UnsetLengthLimit = -99L;

		// Token: 0x0400087E RID: 2174
		private readonly Stream _innerStream;

		// Token: 0x0400087F RID: 2175
		private readonly CRC32 _crc32;

		// Token: 0x04000880 RID: 2176
		private readonly long _lengthLimit = -99L;

		// Token: 0x04000881 RID: 2177
		private bool _leaveOpen;
	}
}
