﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using Ionic.Crc;

namespace Ionic.Zip
{
	// Token: 0x020000E9 RID: 233
	[ComVisible(true)]
	public class ZipInputStream : Stream
	{
		// Token: 0x06000E3A RID: 3642 RVA: 0x00012A99 File Offset: 0x00010C99
		public ZipInputStream(Stream stream)
			: this(stream, false)
		{
		}

		// Token: 0x06000E3B RID: 3643 RVA: 0x00053F04 File Offset: 0x00052104
		public ZipInputStream(string fileName)
		{
			Stream stream = ZipInputStream.smethod_0(fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
			this._Init(stream, false, fileName);
		}

		// Token: 0x06000E3C RID: 3644 RVA: 0x00012AA3 File Offset: 0x00010CA3
		public ZipInputStream(Stream stream, bool leaveOpen)
		{
			this._Init(stream, leaveOpen, null);
		}

		// Token: 0x06000E3D RID: 3645 RVA: 0x00053F2C File Offset: 0x0005212C
		private void _Init(Stream stream, bool leaveOpen, string name)
		{
			this._inputStream = stream;
			if (ZipInputStream.smethod_1(this._inputStream))
			{
				this._container = new ZipContainer(this);
				this._provisionalAlternateEncoding = ZipInputStream.smethod_2(<Module>.smethod_26<string>(1542074113U));
				this._leaveUnderlyingStreamOpen = leaveOpen;
				this._findRequired = true;
				this._name = name ?? <Module>.smethod_24<string>(1509499167U);
				return;
			}
			throw new ZipException(<Module>.smethod_24<string>(776312820U));
		}

		// Token: 0x06000E3E RID: 3646 RVA: 0x00012AB4 File Offset: 0x00010CB4
		public override string ToString()
		{
			return ZipInputStream.smethod_3(<Module>.smethod_23<string>(3012050017U), this._name, this._leaveUnderlyingStreamOpen);
		}

		// Token: 0x1700021D RID: 541
		// (get) Token: 0x06000E3F RID: 3647 RVA: 0x00012AD6 File Offset: 0x00010CD6
		// (set) Token: 0x06000E40 RID: 3648 RVA: 0x00012ADE File Offset: 0x00010CDE
		public Encoding ProvisionalAlternateEncoding
		{
			get
			{
				return this._provisionalAlternateEncoding;
			}
			set
			{
				this._provisionalAlternateEncoding = value;
			}
		}

		// Token: 0x1700021E RID: 542
		// (get) Token: 0x06000E41 RID: 3649 RVA: 0x00012AE7 File Offset: 0x00010CE7
		// (set) Token: 0x06000E42 RID: 3650 RVA: 0x00012AEF File Offset: 0x00010CEF
		public int CodecBufferSize { get; set; }

		// Token: 0x1700021F RID: 543
		// (set) Token: 0x06000E43 RID: 3651 RVA: 0x00012AF8 File Offset: 0x00010CF8
		public string Password
		{
			set
			{
				if (this._closed)
				{
					this._exceptionPending = true;
					throw ZipInputStream.smethod_4(<Module>.smethod_23<string>(1840536912U));
				}
				this._Password = value;
			}
		}

		// Token: 0x06000E44 RID: 3652 RVA: 0x00012B20 File Offset: 0x00010D20
		private void SetupStream()
		{
			this._crcStream = this._currentEntry.InternalOpenReader(this._Password);
			this._LeftToRead = ZipInputStream.smethod_5(this._crcStream);
			this._needSetup = false;
		}

		// Token: 0x17000220 RID: 544
		// (get) Token: 0x06000E45 RID: 3653 RVA: 0x00012B51 File Offset: 0x00010D51
		internal Stream ReadStream
		{
			get
			{
				return this._inputStream;
			}
		}

		// Token: 0x06000E46 RID: 3654 RVA: 0x00053FA4 File Offset: 0x000521A4
		public override int Read(byte[] buffer, int offset, int count)
		{
			if (this._closed)
			{
				this._exceptionPending = true;
				throw ZipInputStream.smethod_4(<Module>.smethod_24<string>(113749109U));
			}
			if (this._needSetup)
			{
				this.SetupStream();
			}
			if (this._LeftToRead == 0L)
			{
				return 0;
			}
			int num = ((this._LeftToRead > (long)count) ? count : ((int)this._LeftToRead));
			int num2 = ZipInputStream.smethod_6(this._crcStream, buffer, offset, num);
			this._LeftToRead -= (long)num2;
			if (this._LeftToRead == 0L)
			{
				int crc = this._crcStream.Crc;
				this._currentEntry.VerifyCrcAfterExtract(crc, this._currentEntry.Encryption, this._currentEntry._Crc32, this._currentEntry.ArchiveStream, this._currentEntry.UncompressedSize);
				ZipInputStream.smethod_7(this._inputStream, this._endOfEntry, SeekOrigin.Begin);
			}
			return num2;
		}

		// Token: 0x06000E47 RID: 3655 RVA: 0x00054090 File Offset: 0x00052290
		public ZipEntry GetNextEntry()
		{
			if (this._findRequired)
			{
				long num = SharedUtilities.FindSignature(this._inputStream, 67324752);
				if (num == -1L)
				{
					return null;
				}
				ZipInputStream.smethod_7(this._inputStream, -4L, SeekOrigin.Current);
			}
			else if (this._firstEntry)
			{
				ZipInputStream.smethod_7(this._inputStream, this._endOfEntry, SeekOrigin.Begin);
			}
			this._currentEntry = ZipEntry.ReadEntry(this._container, !this._firstEntry);
			this._endOfEntry = ZipInputStream.smethod_8(this._inputStream);
			this._firstEntry = true;
			this._needSetup = true;
			this._findRequired = false;
			return this._currentEntry;
		}

		// Token: 0x06000E48 RID: 3656 RVA: 0x00012B59 File Offset: 0x00010D59
		protected override void Dispose(bool disposing)
		{
			if (this._closed)
			{
				return;
			}
			if (disposing)
			{
				if (this._exceptionPending)
				{
					return;
				}
				if (!this._leaveUnderlyingStreamOpen)
				{
					ZipInputStream.smethod_9(this._inputStream);
				}
			}
			this._closed = true;
		}

		// Token: 0x17000221 RID: 545
		// (get) Token: 0x06000E49 RID: 3657 RVA: 0x0000ED8C File Offset: 0x0000CF8C
		public override bool CanRead
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000222 RID: 546
		// (get) Token: 0x06000E4A RID: 3658 RVA: 0x00012B8A File Offset: 0x00010D8A
		public override bool CanSeek
		{
			get
			{
				return ZipInputStream.smethod_10(this._inputStream);
			}
		}

		// Token: 0x17000223 RID: 547
		// (get) Token: 0x06000E4B RID: 3659 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanWrite
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000224 RID: 548
		// (get) Token: 0x06000E4C RID: 3660 RVA: 0x00012B97 File Offset: 0x00010D97
		public override long Length
		{
			get
			{
				return ZipInputStream.smethod_5(this._inputStream);
			}
		}

		// Token: 0x17000225 RID: 549
		// (get) Token: 0x06000E4D RID: 3661 RVA: 0x00012BA4 File Offset: 0x00010DA4
		// (set) Token: 0x06000E4E RID: 3662 RVA: 0x00012BB1 File Offset: 0x00010DB1
		public override long Position
		{
			get
			{
				return ZipInputStream.smethod_8(this._inputStream);
			}
			set
			{
				ZipInputStream.smethod_7(this, value, SeekOrigin.Begin);
			}
		}

		// Token: 0x06000E4F RID: 3663 RVA: 0x00012BBC File Offset: 0x00010DBC
		public override void Flush()
		{
			throw ZipInputStream.smethod_11(<Module>.smethod_23<string>(2974421767U));
		}

		// Token: 0x06000E50 RID: 3664 RVA: 0x00012BCD File Offset: 0x00010DCD
		public override void Write(byte[] buffer, int offset, int count)
		{
			throw ZipInputStream.smethod_11(<Module>.smethod_26<string>(53735310U));
		}

		// Token: 0x06000E51 RID: 3665 RVA: 0x00054140 File Offset: 0x00052340
		public override long Seek(long offset, SeekOrigin origin)
		{
			this._findRequired = true;
			return ZipInputStream.smethod_7(this._inputStream, offset, origin);
		}

		// Token: 0x06000E52 RID: 3666 RVA: 0x00012BDE File Offset: 0x00010DDE
		public override void SetLength(long value)
		{
			throw ZipInputStream.smethod_12();
		}

		// Token: 0x06000E53 RID: 3667 RVA: 0x0000FB08 File Offset: 0x0000DD08
		static FileStream smethod_0(string string_0, FileMode fileMode_0, FileAccess fileAccess_0, FileShare fileShare_0)
		{
			return File.Open(string_0, fileMode_0, fileAccess_0, fileShare_0);
		}

		// Token: 0x06000E54 RID: 3668 RVA: 0x00012837 File Offset: 0x00010A37
		static bool smethod_1(Stream stream_0)
		{
			return stream_0.CanRead;
		}

		// Token: 0x06000E55 RID: 3669 RVA: 0x0001282F File Offset: 0x00010A2F
		static Encoding smethod_2(string string_0)
		{
			return Encoding.GetEncoding(string_0);
		}

		// Token: 0x06000E56 RID: 3670 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_3(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x06000E57 RID: 3671 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_4(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x06000E58 RID: 3672 RVA: 0x00012BE5 File Offset: 0x00010DE5
		static long smethod_5(Stream stream_0)
		{
			return stream_0.Length;
		}

		// Token: 0x06000E59 RID: 3673 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_6(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06000E5A RID: 3674 RVA: 0x00012BED File Offset: 0x00010DED
		static long smethod_7(Stream stream_0, long long_0, SeekOrigin seekOrigin_0)
		{
			return stream_0.Seek(long_0, seekOrigin_0);
		}

		// Token: 0x06000E5B RID: 3675 RVA: 0x00012846 File Offset: 0x00010A46
		static long smethod_8(Stream stream_0)
		{
			return stream_0.Position;
		}

		// Token: 0x06000E5C RID: 3676 RVA: 0x0000FB13 File Offset: 0x0000DD13
		static void smethod_9(Stream stream_0)
		{
			stream_0.Dispose();
		}

		// Token: 0x06000E5D RID: 3677 RVA: 0x00012BF7 File Offset: 0x00010DF7
		static bool smethod_10(Stream stream_0)
		{
			return stream_0.CanSeek;
		}

		// Token: 0x06000E5E RID: 3678 RVA: 0x0001284E File Offset: 0x00010A4E
		static NotSupportedException smethod_11(string string_0)
		{
			return new NotSupportedException(string_0);
		}

		// Token: 0x06000E5F RID: 3679 RVA: 0x0000E031 File Offset: 0x0000C231
		static NotSupportedException smethod_12()
		{
			return new NotSupportedException();
		}

		// Token: 0x040004C1 RID: 1217
		private Stream _inputStream;

		// Token: 0x040004C2 RID: 1218
		private Encoding _provisionalAlternateEncoding;

		// Token: 0x040004C3 RID: 1219
		private ZipEntry _currentEntry;

		// Token: 0x040004C4 RID: 1220
		private bool _firstEntry;

		// Token: 0x040004C5 RID: 1221
		private bool _needSetup;

		// Token: 0x040004C6 RID: 1222
		private ZipContainer _container;

		// Token: 0x040004C7 RID: 1223
		private CrcCalculatorStream _crcStream;

		// Token: 0x040004C8 RID: 1224
		private long _LeftToRead;

		// Token: 0x040004C9 RID: 1225
		internal string _Password;

		// Token: 0x040004CA RID: 1226
		private long _endOfEntry;

		// Token: 0x040004CB RID: 1227
		private string _name;

		// Token: 0x040004CC RID: 1228
		private bool _leaveUnderlyingStreamOpen;

		// Token: 0x040004CD RID: 1229
		private bool _closed;

		// Token: 0x040004CE RID: 1230
		private bool _findRequired;

		// Token: 0x040004CF RID: 1231
		private bool _exceptionPending;
	}
}
