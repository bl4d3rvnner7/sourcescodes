﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace Ionic.Zip
{
	// Token: 0x02000107 RID: 263
	[ComVisible(true)]
	[Guid("ebc25cf6-9120-4283-b972-0e5520d00007")]
	[Serializable]
	public class BadStateException : ZipException
	{
		// Token: 0x06000FAF RID: 4015 RVA: 0x00013292 File Offset: 0x00011492
		public BadStateException()
		{
		}

		// Token: 0x06000FB0 RID: 4016 RVA: 0x0001329A File Offset: 0x0001149A
		public BadStateException(string message)
			: base(message)
		{
		}

		// Token: 0x06000FB1 RID: 4017 RVA: 0x000132A3 File Offset: 0x000114A3
		public BadStateException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

		// Token: 0x06000FB2 RID: 4018 RVA: 0x000132AD File Offset: 0x000114AD
		protected BadStateException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
