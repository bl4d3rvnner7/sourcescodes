﻿using System;
using System.IO;
using System.Security.Cryptography;

namespace Ionic.Zip
{
	// Token: 0x020000FF RID: 255
	internal class WinZipAesCrypto
	{
		// Token: 0x06000F52 RID: 3922 RVA: 0x0001310E File Offset: 0x0001130E
		private WinZipAesCrypto(string password, int KeyStrengthInBits)
		{
			this._Password = password;
			this._KeyStrengthInBits = KeyStrengthInBits;
		}

		// Token: 0x06000F53 RID: 3923 RVA: 0x0005624C File Offset: 0x0005444C
		public static WinZipAesCrypto Generate(string password, int KeyStrengthInBits)
		{
			WinZipAesCrypto winZipAesCrypto = new WinZipAesCrypto(password, KeyStrengthInBits);
			int num = winZipAesCrypto._KeyStrengthInBytes / 2;
			winZipAesCrypto._Salt = new byte[num];
			Random random = WinZipAesCrypto.smethod_0();
			WinZipAesCrypto.smethod_1(random, winZipAesCrypto._Salt);
			return winZipAesCrypto;
		}

		// Token: 0x06000F54 RID: 3924 RVA: 0x0005628C File Offset: 0x0005448C
		public static WinZipAesCrypto ReadFromStream(string password, int KeyStrengthInBits, Stream s)
		{
			WinZipAesCrypto winZipAesCrypto = new WinZipAesCrypto(password, KeyStrengthInBits);
			int num = winZipAesCrypto._KeyStrengthInBytes / 2;
			winZipAesCrypto._Salt = new byte[num];
			winZipAesCrypto._providedPv = new byte[2];
			WinZipAesCrypto.smethod_2(s, winZipAesCrypto._Salt, 0, winZipAesCrypto._Salt.Length);
			WinZipAesCrypto.smethod_2(s, winZipAesCrypto._providedPv, 0, winZipAesCrypto._providedPv.Length);
			winZipAesCrypto.PasswordVerificationStored = (short)((int)winZipAesCrypto._providedPv[0] + (int)winZipAesCrypto._providedPv[1] * 256);
			if (password != null)
			{
				winZipAesCrypto.PasswordVerificationGenerated = (short)((int)winZipAesCrypto.GeneratedPV[0] + (int)winZipAesCrypto.GeneratedPV[1] * 256);
				if (winZipAesCrypto.PasswordVerificationGenerated != winZipAesCrypto.PasswordVerificationStored)
				{
					throw new BadPasswordException(<Module>.smethod_27<string>(3221087706U));
				}
			}
			return winZipAesCrypto;
		}

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x06000F55 RID: 3925 RVA: 0x0001312F File Offset: 0x0001132F
		public byte[] GeneratedPV
		{
			get
			{
				if (!this._cryptoGenerated)
				{
					this._GenerateCryptoBytes();
				}
				return this._generatedPv;
			}
		}

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x06000F56 RID: 3926 RVA: 0x00013145 File Offset: 0x00011345
		public byte[] Salt
		{
			get
			{
				return this._Salt;
			}
		}

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x06000F57 RID: 3927 RVA: 0x0001314D File Offset: 0x0001134D
		private int _KeyStrengthInBytes
		{
			get
			{
				return this._KeyStrengthInBits / 8;
			}
		}

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x06000F58 RID: 3928 RVA: 0x00013157 File Offset: 0x00011357
		public int SizeOfEncryptionMetadata
		{
			get
			{
				return this._KeyStrengthInBytes / 2 + 10 + 2;
			}
		}

		// Token: 0x1700023F RID: 575
		// (get) Token: 0x06000F5A RID: 3930 RVA: 0x00013166 File Offset: 0x00011366
		// (set) Token: 0x06000F59 RID: 3929 RVA: 0x0005634C File Offset: 0x0005454C
		public string Password
		{
			private get
			{
				return this._Password;
			}
			set
			{
				this._Password = value;
				if (this._Password != null)
				{
					this.PasswordVerificationGenerated = (short)((int)this.GeneratedPV[0] + (int)this.GeneratedPV[1] * 256);
					if (this.PasswordVerificationGenerated != this.PasswordVerificationStored)
					{
						throw new BadPasswordException();
					}
				}
			}
		}

		// Token: 0x06000F5B RID: 3931 RVA: 0x0005639C File Offset: 0x0005459C
		private void _GenerateCryptoBytes()
		{
			Rfc2898DeriveBytes rfc2898DeriveBytes = WinZipAesCrypto.smethod_3(this._Password, this.Salt, this.Rfc2898KeygenIterations);
			this._keyBytes = WinZipAesCrypto.smethod_4(rfc2898DeriveBytes, this._KeyStrengthInBytes);
			this._MacInitializationVector = WinZipAesCrypto.smethod_4(rfc2898DeriveBytes, this._KeyStrengthInBytes);
			this._generatedPv = WinZipAesCrypto.smethod_4(rfc2898DeriveBytes, 2);
			this._cryptoGenerated = true;
		}

		// Token: 0x17000240 RID: 576
		// (get) Token: 0x06000F5C RID: 3932 RVA: 0x0001316E File Offset: 0x0001136E
		public byte[] KeyBytes
		{
			get
			{
				if (!this._cryptoGenerated)
				{
					this._GenerateCryptoBytes();
				}
				return this._keyBytes;
			}
		}

		// Token: 0x17000241 RID: 577
		// (get) Token: 0x06000F5D RID: 3933 RVA: 0x00013184 File Offset: 0x00011384
		public byte[] MacIv
		{
			get
			{
				if (!this._cryptoGenerated)
				{
					this._GenerateCryptoBytes();
				}
				return this._MacInitializationVector;
			}
		}

		// Token: 0x06000F5E RID: 3934 RVA: 0x000563FC File Offset: 0x000545FC
		public void ReadAndVerifyMac(Stream s)
		{
			bool flag = false;
			this._StoredMac = new byte[10];
			WinZipAesCrypto.smethod_2(s, this._StoredMac, 0, this._StoredMac.Length);
			if (this._StoredMac.Length != this.CalculatedMac.Length)
			{
				flag = true;
			}
			if (!flag)
			{
				for (int i = 0; i < this._StoredMac.Length; i++)
				{
					if (this._StoredMac[i] != this.CalculatedMac[i])
					{
						flag = true;
					}
				}
			}
			if (flag)
			{
				throw new BadStateException(<Module>.smethod_27<string>(3407574478U));
			}
		}

		// Token: 0x06000F5F RID: 3935 RVA: 0x0000D808 File Offset: 0x0000BA08
		static Random smethod_0()
		{
			return new Random();
		}

		// Token: 0x06000F60 RID: 3936 RVA: 0x0001319A File Offset: 0x0001139A
		static void smethod_1(Random random_0, byte[] byte_0)
		{
			random_0.NextBytes(byte_0);
		}

		// Token: 0x06000F61 RID: 3937 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_2(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06000F62 RID: 3938 RVA: 0x000131A3 File Offset: 0x000113A3
		static Rfc2898DeriveBytes smethod_3(string string_0, byte[] byte_0, int int_0)
		{
			return new Rfc2898DeriveBytes(string_0, byte_0, int_0);
		}

		// Token: 0x06000F63 RID: 3939 RVA: 0x000131AD File Offset: 0x000113AD
		static byte[] smethod_4(DeriveBytes deriveBytes_0, int int_0)
		{
			return deriveBytes_0.GetBytes(int_0);
		}

		// Token: 0x0400051F RID: 1311
		internal byte[] _Salt;

		// Token: 0x04000520 RID: 1312
		internal byte[] _providedPv;

		// Token: 0x04000521 RID: 1313
		internal byte[] _generatedPv;

		// Token: 0x04000522 RID: 1314
		internal int _KeyStrengthInBits;

		// Token: 0x04000523 RID: 1315
		private byte[] _MacInitializationVector;

		// Token: 0x04000524 RID: 1316
		private byte[] _StoredMac;

		// Token: 0x04000525 RID: 1317
		private byte[] _keyBytes;

		// Token: 0x04000526 RID: 1318
		private short PasswordVerificationStored;

		// Token: 0x04000527 RID: 1319
		private short PasswordVerificationGenerated;

		// Token: 0x04000528 RID: 1320
		private int Rfc2898KeygenIterations = 1000;

		// Token: 0x04000529 RID: 1321
		private string _Password;

		// Token: 0x0400052A RID: 1322
		private bool _cryptoGenerated;

		// Token: 0x0400052B RID: 1323
		public byte[] CalculatedMac;
	}
}
