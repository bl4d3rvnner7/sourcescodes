﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x0200010E RID: 270
	// (Invoke) Token: 0x06001028 RID: 4136
	[ComVisible(true)]
	public delegate Stream OpenDelegate(string entryName);
}
