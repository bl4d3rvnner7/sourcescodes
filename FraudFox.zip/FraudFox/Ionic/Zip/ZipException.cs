﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace Ionic.Zip
{
	// Token: 0x02000102 RID: 258
	[Guid("ebc25cf6-9120-4283-b972-0e5520d00006")]
	[ComVisible(true)]
	[Serializable]
	public class ZipException : Exception
	{
		// Token: 0x06000F9D RID: 3997 RVA: 0x0000F665 File Offset: 0x0000D865
		public ZipException()
		{
		}

		// Token: 0x06000F9E RID: 3998 RVA: 0x0000C1DA File Offset: 0x0000A3DA
		public ZipException(string message)
			: base(message)
		{
		}

		// Token: 0x06000F9F RID: 3999 RVA: 0x0000F66D File Offset: 0x0000D86D
		public ZipException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

		// Token: 0x06000FA0 RID: 4000 RVA: 0x00013288 File Offset: 0x00011488
		protected ZipException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
