﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x02000111 RID: 273
	[ComVisible(true)]
	public enum ZipProgressEventType
	{
		// Token: 0x0400055A RID: 1370
		Adding_Started,
		// Token: 0x0400055B RID: 1371
		Adding_AfterAddEntry,
		// Token: 0x0400055C RID: 1372
		Adding_Completed,
		// Token: 0x0400055D RID: 1373
		Reading_Started,
		// Token: 0x0400055E RID: 1374
		Reading_BeforeReadEntry,
		// Token: 0x0400055F RID: 1375
		Reading_AfterReadEntry,
		// Token: 0x04000560 RID: 1376
		Reading_Completed,
		// Token: 0x04000561 RID: 1377
		Reading_ArchiveBytesRead,
		// Token: 0x04000562 RID: 1378
		Saving_Started,
		// Token: 0x04000563 RID: 1379
		Saving_BeforeWriteEntry,
		// Token: 0x04000564 RID: 1380
		Saving_AfterWriteEntry,
		// Token: 0x04000565 RID: 1381
		Saving_Completed,
		// Token: 0x04000566 RID: 1382
		Saving_AfterSaveTempArchive,
		// Token: 0x04000567 RID: 1383
		Saving_BeforeRenameTempArchive,
		// Token: 0x04000568 RID: 1384
		Saving_AfterRenameTempArchive,
		// Token: 0x04000569 RID: 1385
		Saving_AfterCompileSelfExtractor,
		// Token: 0x0400056A RID: 1386
		Saving_EntryBytesRead,
		// Token: 0x0400056B RID: 1387
		Extracting_BeforeExtractEntry,
		// Token: 0x0400056C RID: 1388
		Extracting_AfterExtractEntry,
		// Token: 0x0400056D RID: 1389
		Extracting_ExtractEntryWouldOverwrite,
		// Token: 0x0400056E RID: 1390
		Extracting_EntryBytesWritten,
		// Token: 0x0400056F RID: 1391
		Extracting_BeforeExtractAll,
		// Token: 0x04000570 RID: 1392
		Extracting_AfterExtractAll,
		// Token: 0x04000571 RID: 1393
		Error_Saving
	}
}
