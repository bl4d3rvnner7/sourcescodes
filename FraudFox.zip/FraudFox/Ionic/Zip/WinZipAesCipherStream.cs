﻿using System;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Threading;

namespace Ionic.Zip
{
	// Token: 0x02000100 RID: 256
	internal class WinZipAesCipherStream : Stream
	{
		// Token: 0x06000F64 RID: 3940 RVA: 0x000131B6 File Offset: 0x000113B6
		internal WinZipAesCipherStream(Stream s, WinZipAesCrypto cryptoParams, long length, CryptoMode mode)
			: this(s, cryptoParams, mode)
		{
			if (s == null)
			{
				throw WinZipAesCipherStream.smethod_0(<Module>.smethod_27<string>(1759848722U));
			}
			this._length = length;
		}

		// Token: 0x06000F65 RID: 3941 RVA: 0x00056480 File Offset: 0x00054680
		internal WinZipAesCipherStream(Stream s, WinZipAesCrypto cryptoParams, CryptoMode mode)
		{
			this._params = cryptoParams;
			this._s = s;
			this._mode = mode;
			this._nonce = 1;
			if (this._params == null)
			{
				throw new BadPasswordException(<Module>.smethod_24<string>(2431701948U));
			}
			int num = this._params.KeyBytes.Length * 8;
			if (num != 256 && num != 128 && num != 192)
			{
				throw WinZipAesCipherStream.smethod_2(<Module>.smethod_23<string>(3658618652U), <Module>.smethod_25<string>(2740516644U));
			}
			this._mac = WinZipAesCipherStream.smethod_3(this._params.MacIv);
			this._aesCipher = WinZipAesCipherStream.smethod_4();
			WinZipAesCipherStream.smethod_5(this._aesCipher, 128);
			WinZipAesCipherStream.smethod_6(this._aesCipher, num);
			WinZipAesCipherStream.smethod_7(this._aesCipher, CipherMode.ECB);
			WinZipAesCipherStream.smethod_8(this._aesCipher, PaddingMode.None);
			byte[] array = new byte[16];
			this._xform = WinZipAesCipherStream.smethod_9(this._aesCipher, this._params.KeyBytes, array);
			if (this._mode == CryptoMode.Encrypt)
			{
				this._iobuf = new byte[2048];
				this._PendingWriteBlock = new byte[16];
			}
		}

		// Token: 0x06000F66 RID: 3942 RVA: 0x000565D0 File Offset: 0x000547D0
		private void XorInPlace(byte[] buffer, int offset, int count)
		{
			for (int i = 0; i < count; i++)
			{
				buffer[offset + i] = this.counterOut[i] ^ buffer[offset + i];
			}
		}

		// Token: 0x06000F67 RID: 3943 RVA: 0x00056600 File Offset: 0x00054800
		private void WriteTransformOneBlock(byte[] buffer, int offset)
		{
			WinZipAesCipherStream.smethod_11(WinZipAesCipherStream.smethod_10(this._nonce++), 0, this.counter, 0, 4);
			WinZipAesCipherStream.smethod_12(this._xform, this.counter, 0, 16, this.counterOut, 0);
			this.XorInPlace(buffer, offset, 16);
			WinZipAesCipherStream.smethod_13(this._mac, buffer, offset, 16, null, 0);
		}

		// Token: 0x06000F68 RID: 3944 RVA: 0x0005666C File Offset: 0x0005486C
		private void WriteTransformBlocks(byte[] buffer, int offset, int count)
		{
			int num = offset;
			int num2 = count + offset;
			while (num < buffer.Length && num < num2)
			{
				this.WriteTransformOneBlock(buffer, num);
				num += 16;
			}
		}

		// Token: 0x06000F69 RID: 3945 RVA: 0x00056698 File Offset: 0x00054898
		private void WriteTransformFinalBlock()
		{
			if (this._pendingCount == 0)
			{
				throw WinZipAesCipherStream.smethod_14(<Module>.smethod_27<string>(1869058609U));
			}
			if (this._finalBlock)
			{
				throw WinZipAesCipherStream.smethod_14(<Module>.smethod_25<string>(3535536500U));
			}
			WinZipAesCipherStream.smethod_11(WinZipAesCipherStream.smethod_10(this._nonce++), 0, this.counter, 0, 4);
			this.counterOut = WinZipAesCipherStream.smethod_15(this._xform, this.counter, 0, 16);
			this.XorInPlace(this._PendingWriteBlock, 0, this._pendingCount);
			WinZipAesCipherStream.smethod_16(this._mac, this._PendingWriteBlock, 0, this._pendingCount);
			this._finalBlock = true;
		}

		// Token: 0x06000F6A RID: 3946 RVA: 0x00056748 File Offset: 0x00054948
		private int ReadTransformOneBlock(byte[] buffer, int offset, int last)
		{
			if (this._finalBlock)
			{
				throw WinZipAesCipherStream.smethod_17();
			}
			int num = last - offset;
			int num2 = ((num > 16) ? 16 : num);
			WinZipAesCipherStream.smethod_11(WinZipAesCipherStream.smethod_10(this._nonce++), 0, this.counter, 0, 4);
			if (num2 == num && this._length > 0L && this._totalBytesXferred + (long)last == this._length)
			{
				WinZipAesCipherStream.smethod_16(this._mac, buffer, offset, num2);
				this.counterOut = WinZipAesCipherStream.smethod_15(this._xform, this.counter, 0, 16);
				this._finalBlock = true;
			}
			else
			{
				WinZipAesCipherStream.smethod_13(this._mac, buffer, offset, num2, null, 0);
				WinZipAesCipherStream.smethod_12(this._xform, this.counter, 0, 16, this.counterOut, 0);
			}
			this.XorInPlace(buffer, offset, num2);
			return num2;
		}

		// Token: 0x06000F6B RID: 3947 RVA: 0x00056828 File Offset: 0x00054A28
		private void ReadTransformBlocks(byte[] buffer, int offset, int count)
		{
			int num = offset;
			int num2 = count + offset;
			while (num < buffer.Length && num < num2)
			{
				int num3 = this.ReadTransformOneBlock(buffer, num, num2);
				num += num3;
			}
		}

		// Token: 0x06000F6C RID: 3948 RVA: 0x00056858 File Offset: 0x00054A58
		public override int Read(byte[] buffer, int offset, int count)
		{
			if (this._mode == CryptoMode.Encrypt)
			{
				throw WinZipAesCipherStream.smethod_17();
			}
			if (buffer == null)
			{
				throw WinZipAesCipherStream.smethod_0(<Module>.smethod_25<string>(2270679300U));
			}
			if (offset < 0)
			{
				throw WinZipAesCipherStream.smethod_2(<Module>.smethod_25<string>(562920811U), <Module>.smethod_25<string>(354128452U));
			}
			if (count < 0)
			{
				throw WinZipAesCipherStream.smethod_2(<Module>.smethod_25<string>(910908076U), <Module>.smethod_27<string>(2515990771U));
			}
			if (buffer.Length < offset + count)
			{
				throw WinZipAesCipherStream.smethod_18(<Module>.smethod_27<string>(2096395534U));
			}
			int num = count;
			if (this._totalBytesXferred >= this._length)
			{
				return 0;
			}
			long num2 = this._length - this._totalBytesXferred;
			if (num2 < (long)count)
			{
				num = (int)num2;
			}
			int num3 = WinZipAesCipherStream.smethod_19(this._s, buffer, offset, num);
			this.ReadTransformBlocks(buffer, offset, num);
			this._totalBytesXferred += (long)num3;
			return num3;
		}

		// Token: 0x17000242 RID: 578
		// (get) Token: 0x06000F6D RID: 3949 RVA: 0x0005692C File Offset: 0x00054B2C
		public byte[] FinalAuthentication
		{
			get
			{
				if (!this._finalBlock)
				{
					if (this._totalBytesXferred != 0L)
					{
						throw new BadStateException(<Module>.smethod_23<string>(3054818769U));
					}
					byte[] array = new byte[0];
					WinZipAesCipherStream.smethod_20(this._mac, array);
				}
				byte[] array2 = new byte[10];
				WinZipAesCipherStream.smethod_11(WinZipAesCipherStream.smethod_21(this._mac), 0, array2, 0, 10);
				return array2;
			}
		}

		// Token: 0x06000F6E RID: 3950 RVA: 0x00056994 File Offset: 0x00054B94
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (this._finalBlock)
			{
				throw WinZipAesCipherStream.smethod_14(<Module>.smethod_23<string>(2705883515U));
			}
			if (this._mode == CryptoMode.Decrypt)
			{
				throw WinZipAesCipherStream.smethod_17();
			}
			if (buffer == null)
			{
				throw WinZipAesCipherStream.smethod_0(<Module>.smethod_26<string>(1465462961U));
			}
			if (offset < 0)
			{
				throw WinZipAesCipherStream.smethod_2(<Module>.smethod_25<string>(562920811U), <Module>.smethod_26<string>(547710065U));
			}
			if (count < 0)
			{
				throw WinZipAesCipherStream.smethod_2(<Module>.smethod_23<string>(3285728771U), <Module>.smethod_24<string>(913499826U));
			}
			if (buffer.Length < offset + count)
			{
				throw WinZipAesCipherStream.smethod_18(<Module>.smethod_23<string>(4002413404U));
			}
			if (count == 0)
			{
				return;
			}
			if (count + this._pendingCount <= 16)
			{
				WinZipAesCipherStream.smethod_22(buffer, offset, this._PendingWriteBlock, this._pendingCount, count);
				this._pendingCount += count;
				return;
			}
			int num = count;
			int num2 = offset;
			if (this._pendingCount != 0)
			{
				int num3 = 16 - this._pendingCount;
				if (num3 > 0)
				{
					WinZipAesCipherStream.smethod_22(buffer, offset, this._PendingWriteBlock, this._pendingCount, num3);
					num -= num3;
					num2 += num3;
				}
				this.WriteTransformOneBlock(this._PendingWriteBlock, 0);
				WinZipAesCipherStream.smethod_23(this._s, this._PendingWriteBlock, 0, 16);
				this._totalBytesXferred += 16L;
				this._pendingCount = 0;
			}
			int num4 = (num - 1) / 16;
			this._pendingCount = num - num4 * 16;
			WinZipAesCipherStream.smethod_22(buffer, num2 + num - this._pendingCount, this._PendingWriteBlock, 0, this._pendingCount);
			num -= this._pendingCount;
			this._totalBytesXferred += (long)num;
			if (num4 > 0)
			{
				do
				{
					int num5 = this._iobuf.Length;
					if (num5 > num)
					{
						num5 = num;
					}
					WinZipAesCipherStream.smethod_22(buffer, num2, this._iobuf, 0, num5);
					this.WriteTransformBlocks(this._iobuf, 0, num5);
					WinZipAesCipherStream.smethod_23(this._s, this._iobuf, 0, num5);
					num -= num5;
					num2 += num5;
				}
				while (num > 0);
			}
		}

		// Token: 0x06000F6F RID: 3951 RVA: 0x00056B88 File Offset: 0x00054D88
		public override void Close()
		{
			if (this._pendingCount > 0)
			{
				this.WriteTransformFinalBlock();
				WinZipAesCipherStream.smethod_23(this._s, this._PendingWriteBlock, 0, this._pendingCount);
				this._totalBytesXferred += (long)this._pendingCount;
				this._pendingCount = 0;
			}
			WinZipAesCipherStream.smethod_24(this._s);
		}

		// Token: 0x17000243 RID: 579
		// (get) Token: 0x06000F70 RID: 3952 RVA: 0x000131DC File Offset: 0x000113DC
		public override bool CanRead
		{
			get
			{
				return this._mode == CryptoMode.Decrypt;
			}
		}

		// Token: 0x17000244 RID: 580
		// (get) Token: 0x06000F71 RID: 3953 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000245 RID: 581
		// (get) Token: 0x06000F72 RID: 3954 RVA: 0x000131EA File Offset: 0x000113EA
		public override bool CanWrite
		{
			get
			{
				return this._mode == CryptoMode.Encrypt;
			}
		}

		// Token: 0x06000F73 RID: 3955 RVA: 0x000131F5 File Offset: 0x000113F5
		public override void Flush()
		{
			WinZipAesCipherStream.smethod_25(this._s);
		}

		// Token: 0x17000246 RID: 582
		// (get) Token: 0x06000F74 RID: 3956 RVA: 0x00013202 File Offset: 0x00011402
		public override long Length
		{
			get
			{
				throw WinZipAesCipherStream.smethod_26();
			}
		}

		// Token: 0x17000247 RID: 583
		// (get) Token: 0x06000F75 RID: 3957 RVA: 0x00013202 File Offset: 0x00011402
		// (set) Token: 0x06000F76 RID: 3958 RVA: 0x00013202 File Offset: 0x00011402
		public override long Position
		{
			get
			{
				throw WinZipAesCipherStream.smethod_26();
			}
			set
			{
				throw WinZipAesCipherStream.smethod_26();
			}
		}

		// Token: 0x06000F77 RID: 3959 RVA: 0x00013202 File Offset: 0x00011402
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw WinZipAesCipherStream.smethod_26();
		}

		// Token: 0x06000F78 RID: 3960 RVA: 0x00013202 File Offset: 0x00011402
		public override void SetLength(long value)
		{
			throw WinZipAesCipherStream.smethod_26();
		}

		// Token: 0x06000F79 RID: 3961 RVA: 0x00056BE4 File Offset: 0x00054DE4
		[Conditional("Trace")]
		private void TraceOutput(string format, params object[] varParams)
		{
			object outputLock;
			WinZipAesCipherStream.smethod_27(outputLock = this._outputLock);
			try
			{
				int num = WinZipAesCipherStream.smethod_29(WinZipAesCipherStream.smethod_28());
				WinZipAesCipherStream.smethod_30(num % 8 + ConsoleColor.DarkGray);
				WinZipAesCipherStream.smethod_31(<Module>.smethod_23<string>(1022790122U), num);
				WinZipAesCipherStream.smethod_32(format, varParams);
				WinZipAesCipherStream.smethod_33();
			}
			finally
			{
				WinZipAesCipherStream.smethod_34(outputLock);
			}
		}

		// Token: 0x06000F7A RID: 3962 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_0(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x06000F7B RID: 3963 RVA: 0x00013209 File Offset: 0x00011409
		static object smethod_1()
		{
			return new object();
		}

		// Token: 0x06000F7C RID: 3964 RVA: 0x0000DECA File Offset: 0x0000C0CA
		static ArgumentOutOfRangeException smethod_2(string string_0, string string_1)
		{
			return new ArgumentOutOfRangeException(string_0, string_1);
		}

		// Token: 0x06000F7D RID: 3965 RVA: 0x00013210 File Offset: 0x00011410
		static HMACSHA1 smethod_3(byte[] byte_0)
		{
			return new HMACSHA1(byte_0);
		}

		// Token: 0x06000F7E RID: 3966 RVA: 0x0000C83A File Offset: 0x0000AA3A
		static RijndaelManaged smethod_4()
		{
			return new RijndaelManaged();
		}

		// Token: 0x06000F7F RID: 3967 RVA: 0x0000C85C File Offset: 0x0000AA5C
		static void smethod_5(SymmetricAlgorithm symmetricAlgorithm_0, int int_0)
		{
			symmetricAlgorithm_0.BlockSize = int_0;
		}

		// Token: 0x06000F80 RID: 3968 RVA: 0x0000C853 File Offset: 0x0000AA53
		static void smethod_6(SymmetricAlgorithm symmetricAlgorithm_0, int int_0)
		{
			symmetricAlgorithm_0.KeySize = int_0;
		}

		// Token: 0x06000F81 RID: 3969 RVA: 0x0000C84A File Offset: 0x0000AA4A
		static void smethod_7(SymmetricAlgorithm symmetricAlgorithm_0, CipherMode cipherMode_0)
		{
			symmetricAlgorithm_0.Mode = cipherMode_0;
		}

		// Token: 0x06000F82 RID: 3970 RVA: 0x0000C841 File Offset: 0x0000AA41
		static void smethod_8(SymmetricAlgorithm symmetricAlgorithm_0, PaddingMode paddingMode_0)
		{
			symmetricAlgorithm_0.Padding = paddingMode_0;
		}

		// Token: 0x06000F83 RID: 3971 RVA: 0x0000C89D File Offset: 0x0000AA9D
		static ICryptoTransform smethod_9(SymmetricAlgorithm symmetricAlgorithm_0, byte[] byte_0, byte[] byte_1)
		{
			return symmetricAlgorithm_0.CreateEncryptor(byte_0, byte_1);
		}

		// Token: 0x06000F84 RID: 3972 RVA: 0x00012D75 File Offset: 0x00010F75
		static byte[] smethod_10(int int_0)
		{
			return BitConverter.GetBytes(int_0);
		}

		// Token: 0x06000F85 RID: 3973 RVA: 0x0000C3EE File Offset: 0x0000A5EE
		static void smethod_11(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Array.Copy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x06000F86 RID: 3974 RVA: 0x00013218 File Offset: 0x00011418
		static int smethod_12(ICryptoTransform icryptoTransform_0, byte[] byte_0, int int_0, int int_1, byte[] byte_1, int int_2)
		{
			return icryptoTransform_0.TransformBlock(byte_0, int_0, int_1, byte_1, int_2);
		}

		// Token: 0x06000F87 RID: 3975 RVA: 0x00013227 File Offset: 0x00011427
		static int smethod_13(HashAlgorithm hashAlgorithm_0, byte[] byte_0, int int_0, int int_1, byte[] byte_1, int int_2)
		{
			return hashAlgorithm_0.TransformBlock(byte_0, int_0, int_1, byte_1, int_2);
		}

		// Token: 0x06000F88 RID: 3976 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_14(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x06000F89 RID: 3977 RVA: 0x00013236 File Offset: 0x00011436
		static byte[] smethod_15(ICryptoTransform icryptoTransform_0, byte[] byte_0, int int_0, int int_1)
		{
			return icryptoTransform_0.TransformFinalBlock(byte_0, int_0, int_1);
		}

		// Token: 0x06000F8A RID: 3978 RVA: 0x00013241 File Offset: 0x00011441
		static byte[] smethod_16(HashAlgorithm hashAlgorithm_0, byte[] byte_0, int int_0, int int_1)
		{
			return hashAlgorithm_0.TransformFinalBlock(byte_0, int_0, int_1);
		}

		// Token: 0x06000F8B RID: 3979 RVA: 0x0000E031 File Offset: 0x0000C231
		static NotSupportedException smethod_17()
		{
			return new NotSupportedException();
		}

		// Token: 0x06000F8C RID: 3980 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_18(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x06000F8D RID: 3981 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_19(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06000F8E RID: 3982 RVA: 0x0000DA3F File Offset: 0x0000BC3F
		static byte[] smethod_20(HashAlgorithm hashAlgorithm_0, byte[] byte_0)
		{
			return hashAlgorithm_0.ComputeHash(byte_0);
		}

		// Token: 0x06000F8F RID: 3983 RVA: 0x0001324C File Offset: 0x0001144C
		static byte[] smethod_21(HashAlgorithm hashAlgorithm_0)
		{
			return hashAlgorithm_0.Hash;
		}

		// Token: 0x06000F90 RID: 3984 RVA: 0x00013254 File Offset: 0x00011454
		static void smethod_22(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Buffer.BlockCopy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x06000F91 RID: 3985 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_23(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x06000F92 RID: 3986 RVA: 0x00012E9A File Offset: 0x0001109A
		static void smethod_24(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x06000F93 RID: 3987 RVA: 0x00012D8E File Offset: 0x00010F8E
		static void smethod_25(Stream stream_0)
		{
			stream_0.Flush();
		}

		// Token: 0x06000F94 RID: 3988 RVA: 0x000109B6 File Offset: 0x0000EBB6
		static NotImplementedException smethod_26()
		{
			return new NotImplementedException();
		}

		// Token: 0x06000F95 RID: 3989 RVA: 0x00013261 File Offset: 0x00011461
		static void smethod_27(object object_0)
		{
			Monitor.Enter(object_0);
		}

		// Token: 0x06000F96 RID: 3990 RVA: 0x00013269 File Offset: 0x00011469
		static Thread smethod_28()
		{
			return Thread.CurrentThread;
		}

		// Token: 0x06000F97 RID: 3991 RVA: 0x0000CF7A File Offset: 0x0000B17A
		static int smethod_29(object object_0)
		{
			return object_0.GetHashCode();
		}

		// Token: 0x06000F98 RID: 3992 RVA: 0x00013270 File Offset: 0x00011470
		static void smethod_30(ConsoleColor consoleColor_0)
		{
			Console.ForegroundColor = consoleColor_0;
		}

		// Token: 0x06000F99 RID: 3993 RVA: 0x00013278 File Offset: 0x00011478
		static void smethod_31(string string_0, object object_0)
		{
			Console.Write(string_0, object_0);
		}

		// Token: 0x06000F9A RID: 3994 RVA: 0x00013082 File Offset: 0x00011282
		static void smethod_32(string string_0, object[] object_0)
		{
			Console.WriteLine(string_0, object_0);
		}

		// Token: 0x06000F9B RID: 3995 RVA: 0x00013281 File Offset: 0x00011481
		static void smethod_33()
		{
			Console.ResetColor();
		}

		// Token: 0x06000F9C RID: 3996 RVA: 0x0000DBEF File Offset: 0x0000BDEF
		static void smethod_34(object object_0)
		{
			Monitor.Exit(object_0);
		}

		// Token: 0x0400052C RID: 1324
		private const int BLOCK_SIZE_IN_BYTES = 16;

		// Token: 0x0400052D RID: 1325
		private WinZipAesCrypto _params;

		// Token: 0x0400052E RID: 1326
		private Stream _s;

		// Token: 0x0400052F RID: 1327
		private CryptoMode _mode;

		// Token: 0x04000530 RID: 1328
		private int _nonce;

		// Token: 0x04000531 RID: 1329
		private bool _finalBlock;

		// Token: 0x04000532 RID: 1330
		internal HMACSHA1 _mac;

		// Token: 0x04000533 RID: 1331
		internal RijndaelManaged _aesCipher;

		// Token: 0x04000534 RID: 1332
		internal ICryptoTransform _xform;

		// Token: 0x04000535 RID: 1333
		private byte[] counter = new byte[16];

		// Token: 0x04000536 RID: 1334
		private byte[] counterOut = new byte[16];

		// Token: 0x04000537 RID: 1335
		private long _length;

		// Token: 0x04000538 RID: 1336
		private long _totalBytesXferred;

		// Token: 0x04000539 RID: 1337
		private byte[] _PendingWriteBlock;

		// Token: 0x0400053A RID: 1338
		private int _pendingCount;

		// Token: 0x0400053B RID: 1339
		private byte[] _iobuf;

		// Token: 0x0400053C RID: 1340
		private object _outputLock = WinZipAesCipherStream.smethod_1();
	}
}
