﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Ionic.Zlib;
using Microsoft.CSharp;

namespace Ionic.Zip
{
	// Token: 0x0200011F RID: 287
	[ClassInterface(ClassInterfaceType.AutoDispatch)]
	[Guid("ebc25cf6-9120-4283-b972-0e5520d00005")]
	[ComVisible(true)]
	public class ZipFile : IEnumerable<ZipEntry>, IEnumerable, IDisposable
	{
		// Token: 0x0600117B RID: 4475 RVA: 0x00013F06 File Offset: 0x00012106
		public ZipEntry AddItem(string fileOrDirectoryName)
		{
			return this.AddItem(fileOrDirectoryName, null);
		}

		// Token: 0x0600117C RID: 4476 RVA: 0x00013F10 File Offset: 0x00012110
		public ZipEntry AddItem(string fileOrDirectoryName, string directoryPathInArchive)
		{
			if (ZipFile.smethod_0(fileOrDirectoryName))
			{
				return this.AddFile(fileOrDirectoryName, directoryPathInArchive);
			}
			if (!ZipFile.smethod_1(fileOrDirectoryName))
			{
				throw ZipFile.smethod_3(ZipFile.smethod_2(<Module>.smethod_25<string>(1728659970U), fileOrDirectoryName));
			}
			return this.AddDirectory(fileOrDirectoryName, directoryPathInArchive);
		}

		// Token: 0x0600117D RID: 4477 RVA: 0x00013F49 File Offset: 0x00012149
		public ZipEntry AddFile(string fileName)
		{
			return this.AddFile(fileName, null);
		}

		// Token: 0x0600117E RID: 4478 RVA: 0x0005DD8C File Offset: 0x0005BF8C
		public ZipEntry AddFile(string fileName, string directoryPathInArchive)
		{
			string text = ZipEntry.NameInArchive(fileName, directoryPathInArchive);
			ZipEntry zipEntry = ZipEntry.CreateFromFile(fileName, text);
			if (this.Verbose)
			{
				ZipFile.smethod_4(this.StatusMessageTextWriter, <Module>.smethod_25<string>(3120609030U), fileName);
			}
			return this._InternalAddEntry(zipEntry);
		}

		// Token: 0x0600117F RID: 4479 RVA: 0x0005DDD0 File Offset: 0x0005BFD0
		public void RemoveEntries(ICollection<ZipEntry> entriesToRemove)
		{
			if (entriesToRemove == null)
			{
				throw ZipFile.smethod_5(<Module>.smethod_26<string>(1991328754U));
			}
			IEnumerator<ZipEntry> enumerator = entriesToRemove.GetEnumerator();
			try
			{
				while (ZipFile.smethod_6(enumerator))
				{
					ZipEntry zipEntry = enumerator.Current;
					this.RemoveEntry(zipEntry);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					ZipFile.smethod_7(enumerator);
				}
			}
		}

		// Token: 0x06001180 RID: 4480 RVA: 0x0005DE2C File Offset: 0x0005C02C
		public void RemoveEntries(ICollection<string> entriesToRemove)
		{
			if (entriesToRemove == null)
			{
				throw ZipFile.smethod_5(<Module>.smethod_27<string>(2457825998U));
			}
			IEnumerator<string> enumerator = entriesToRemove.GetEnumerator();
			try
			{
				while (ZipFile.smethod_6(enumerator))
				{
					string text = enumerator.Current;
					this.RemoveEntry(text);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					ZipFile.smethod_7(enumerator);
				}
			}
		}

		// Token: 0x06001181 RID: 4481 RVA: 0x00013F53 File Offset: 0x00012153
		public void AddFiles(IEnumerable<string> fileNames)
		{
			this.AddFiles(fileNames, null);
		}

		// Token: 0x06001182 RID: 4482 RVA: 0x00013F5D File Offset: 0x0001215D
		public void UpdateFiles(IEnumerable<string> fileNames)
		{
			this.UpdateFiles(fileNames, null);
		}

		// Token: 0x06001183 RID: 4483 RVA: 0x00013F67 File Offset: 0x00012167
		public void AddFiles(IEnumerable<string> fileNames, string directoryPathInArchive)
		{
			this.AddFiles(fileNames, false, directoryPathInArchive);
		}

		// Token: 0x06001184 RID: 4484 RVA: 0x0005DE88 File Offset: 0x0005C088
		public void AddFiles(IEnumerable<string> fileNames, bool preserveDirHierarchy, string directoryPathInArchive)
		{
			if (fileNames == null)
			{
				throw ZipFile.smethod_5(<Module>.smethod_24<string>(305812034U));
			}
			this._addOperationCanceled = false;
			this.OnAddStarted();
			if (preserveDirHierarchy)
			{
				IEnumerator<string> enumerator = fileNames.GetEnumerator();
				try
				{
					while (ZipFile.smethod_6(enumerator))
					{
						string text = enumerator.Current;
						if (this._addOperationCanceled)
						{
							break;
						}
						if (directoryPathInArchive != null)
						{
							string text2 = ZipFile.smethod_10(ZipFile.smethod_9(directoryPathInArchive, ZipFile.smethod_8(text)));
							this.AddFile(text, text2);
						}
						else
						{
							this.AddFile(text, null);
						}
					}
					goto IL_00B1;
				}
				finally
				{
					if (enumerator != null)
					{
						ZipFile.smethod_7(enumerator);
					}
				}
			}
			IEnumerator<string> enumerator2 = fileNames.GetEnumerator();
			try
			{
				while (ZipFile.smethod_6(enumerator2))
				{
					string text3 = enumerator2.Current;
					if (this._addOperationCanceled)
					{
						break;
					}
					this.AddFile(text3, directoryPathInArchive);
				}
			}
			finally
			{
				if (enumerator2 != null)
				{
					ZipFile.smethod_7(enumerator2);
				}
			}
			IL_00B1:
			if (!this._addOperationCanceled)
			{
				this.OnAddCompleted();
			}
		}

		// Token: 0x06001185 RID: 4485 RVA: 0x0005DF70 File Offset: 0x0005C170
		public void UpdateFiles(IEnumerable<string> fileNames, string directoryPathInArchive)
		{
			if (fileNames == null)
			{
				throw ZipFile.smethod_5(<Module>.smethod_27<string>(2131474147U));
			}
			this.OnAddStarted();
			IEnumerator<string> enumerator = fileNames.GetEnumerator();
			try
			{
				while (ZipFile.smethod_6(enumerator))
				{
					string text = enumerator.Current;
					this.UpdateFile(text, directoryPathInArchive);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					ZipFile.smethod_7(enumerator);
				}
			}
			this.OnAddCompleted();
		}

		// Token: 0x06001186 RID: 4486 RVA: 0x00013F72 File Offset: 0x00012172
		public ZipEntry UpdateFile(string fileName)
		{
			return this.UpdateFile(fileName, null);
		}

		// Token: 0x06001187 RID: 4487 RVA: 0x0005DFDC File Offset: 0x0005C1DC
		public ZipEntry UpdateFile(string fileName, string directoryPathInArchive)
		{
			string text = ZipEntry.NameInArchive(fileName, directoryPathInArchive);
			if (this[text] != null)
			{
				this.RemoveEntry(text);
			}
			return this.AddFile(fileName, directoryPathInArchive);
		}

		// Token: 0x06001188 RID: 4488 RVA: 0x00013F7C File Offset: 0x0001217C
		public ZipEntry UpdateDirectory(string directoryName)
		{
			return this.UpdateDirectory(directoryName, null);
		}

		// Token: 0x06001189 RID: 4489 RVA: 0x00013F86 File Offset: 0x00012186
		public ZipEntry UpdateDirectory(string directoryName, string directoryPathInArchive)
		{
			return this.AddOrUpdateDirectoryImpl(directoryName, directoryPathInArchive, AddOrUpdateAction.AddOrUpdate);
		}

		// Token: 0x0600118A RID: 4490 RVA: 0x00013F91 File Offset: 0x00012191
		public void UpdateItem(string itemName)
		{
			this.UpdateItem(itemName, null);
		}

		// Token: 0x0600118B RID: 4491 RVA: 0x00013F9B File Offset: 0x0001219B
		public void UpdateItem(string itemName, string directoryPathInArchive)
		{
			if (ZipFile.smethod_0(itemName))
			{
				this.UpdateFile(itemName, directoryPathInArchive);
				return;
			}
			if (!ZipFile.smethod_1(itemName))
			{
				throw ZipFile.smethod_3(ZipFile.smethod_2(<Module>.smethod_26<string>(1248367755U), itemName));
			}
			this.UpdateDirectory(itemName, directoryPathInArchive);
		}

		// Token: 0x0600118C RID: 4492 RVA: 0x00013FD6 File Offset: 0x000121D6
		public ZipEntry AddEntry(string entryName, string content)
		{
			return this.AddEntry(entryName, content, ZipFile.smethod_11());
		}

		// Token: 0x0600118D RID: 4493 RVA: 0x0005E00C File Offset: 0x0005C20C
		public ZipEntry AddEntry(string entryName, string content, Encoding encoding)
		{
			MemoryStream memoryStream = ZipFile.smethod_12();
			StreamWriter streamWriter = ZipFile.smethod_13(memoryStream, encoding);
			ZipFile.smethod_14(streamWriter, content);
			ZipFile.smethod_15(streamWriter);
			ZipFile.smethod_16(memoryStream, 0L, SeekOrigin.Begin);
			return this.AddEntry(entryName, memoryStream);
		}

		// Token: 0x0600118E RID: 4494 RVA: 0x0005E050 File Offset: 0x0005C250
		public ZipEntry AddEntry(string entryName, Stream stream)
		{
			ZipEntry zipEntry = ZipEntry.CreateForStream(entryName, stream);
			zipEntry.SetEntryTimes(DateTime.Now, DateTime.Now, DateTime.Now);
			if (this.Verbose)
			{
				ZipFile.smethod_4(this.StatusMessageTextWriter, <Module>.smethod_27<string>(2224717533U), entryName);
			}
			return this._InternalAddEntry(zipEntry);
		}

		// Token: 0x0600118F RID: 4495 RVA: 0x0005E0A0 File Offset: 0x0005C2A0
		public ZipEntry AddEntry(string entryName, WriteDelegate writer)
		{
			ZipEntry zipEntry = ZipEntry.CreateForWriter(entryName, writer);
			if (this.Verbose)
			{
				ZipFile.smethod_4(this.StatusMessageTextWriter, <Module>.smethod_24<string>(3327481336U), entryName);
			}
			return this._InternalAddEntry(zipEntry);
		}

		// Token: 0x06001190 RID: 4496 RVA: 0x0005E0DC File Offset: 0x0005C2DC
		public ZipEntry AddEntry(string entryName, OpenDelegate opener, CloseDelegate closer)
		{
			ZipEntry zipEntry = ZipEntry.CreateForJitStreamProvider(entryName, opener, closer);
			zipEntry.SetEntryTimes(DateTime.Now, DateTime.Now, DateTime.Now);
			if (this.Verbose)
			{
				ZipFile.smethod_4(this.StatusMessageTextWriter, <Module>.smethod_23<string>(1152844261U), entryName);
			}
			return this._InternalAddEntry(zipEntry);
		}

		// Token: 0x06001191 RID: 4497 RVA: 0x0005E12C File Offset: 0x0005C32C
		private ZipEntry _InternalAddEntry(ZipEntry ze)
		{
			ze._container = new ZipContainer(this);
			ze.CompressionMethod = this.CompressionMethod;
			ze.CompressionLevel = this.CompressionLevel;
			ze.ExtractExistingFile = this.ExtractExistingFile;
			ze.ZipErrorAction = this.ZipErrorAction;
			ze.SetCompression = this.SetCompression;
			ze.AlternateEncoding = this.AlternateEncoding;
			ze.AlternateEncodingUsage = this.AlternateEncodingUsage;
			ze.Password = this._Password;
			ze.Encryption = this.Encryption;
			ze.EmitTimesInWindowsFormatWhenSaving = this._emitNtfsTimes;
			ze.EmitTimesInUnixFormatWhenSaving = this._emitUnixTimes;
			this.InternalAddEntry(ze.FileName, ze);
			this.AfterAddEntry(ze);
			return ze;
		}

		// Token: 0x06001192 RID: 4498 RVA: 0x00013FE5 File Offset: 0x000121E5
		public ZipEntry UpdateEntry(string entryName, string content)
		{
			return this.UpdateEntry(entryName, content, ZipFile.smethod_11());
		}

		// Token: 0x06001193 RID: 4499 RVA: 0x00013FF4 File Offset: 0x000121F4
		public ZipEntry UpdateEntry(string entryName, string content, Encoding encoding)
		{
			this.RemoveEntryForUpdate(entryName);
			return this.AddEntry(entryName, content, encoding);
		}

		// Token: 0x06001194 RID: 4500 RVA: 0x00014006 File Offset: 0x00012206
		public ZipEntry UpdateEntry(string entryName, WriteDelegate writer)
		{
			this.RemoveEntryForUpdate(entryName);
			return this.AddEntry(entryName, writer);
		}

		// Token: 0x06001195 RID: 4501 RVA: 0x00014017 File Offset: 0x00012217
		public ZipEntry UpdateEntry(string entryName, OpenDelegate opener, CloseDelegate closer)
		{
			this.RemoveEntryForUpdate(entryName);
			return this.AddEntry(entryName, opener, closer);
		}

		// Token: 0x06001196 RID: 4502 RVA: 0x00014029 File Offset: 0x00012229
		public ZipEntry UpdateEntry(string entryName, Stream stream)
		{
			this.RemoveEntryForUpdate(entryName);
			return this.AddEntry(entryName, stream);
		}

		// Token: 0x06001197 RID: 4503 RVA: 0x0005E1E0 File Offset: 0x0005C3E0
		private void RemoveEntryForUpdate(string entryName)
		{
			if (ZipFile.smethod_17(entryName))
			{
				throw ZipFile.smethod_5(<Module>.smethod_26<string>(3665616776U));
			}
			string text = null;
			if (ZipFile.smethod_18(entryName, '\\') != -1)
			{
				text = ZipFile.smethod_8(entryName);
				entryName = ZipFile.smethod_19(entryName);
			}
			string text2 = ZipEntry.NameInArchive(entryName, text);
			if (this[text2] != null)
			{
				this.RemoveEntry(text2);
			}
		}

		// Token: 0x06001198 RID: 4504 RVA: 0x0005E23C File Offset: 0x0005C43C
		public ZipEntry AddEntry(string entryName, byte[] byteContent)
		{
			if (byteContent == null)
			{
				throw ZipFile.smethod_20(<Module>.smethod_23<string>(3166058783U), <Module>.smethod_24<string>(3557650522U));
			}
			MemoryStream memoryStream = ZipFile.smethod_21(byteContent);
			return this.AddEntry(entryName, memoryStream);
		}

		// Token: 0x06001199 RID: 4505 RVA: 0x0001403A File Offset: 0x0001223A
		public ZipEntry UpdateEntry(string entryName, byte[] byteContent)
		{
			this.RemoveEntryForUpdate(entryName);
			return this.AddEntry(entryName, byteContent);
		}

		// Token: 0x0600119A RID: 4506 RVA: 0x0001404B File Offset: 0x0001224B
		public ZipEntry AddDirectory(string directoryName)
		{
			return this.AddDirectory(directoryName, null);
		}

		// Token: 0x0600119B RID: 4507 RVA: 0x00014055 File Offset: 0x00012255
		public ZipEntry AddDirectory(string directoryName, string directoryPathInArchive)
		{
			return this.AddOrUpdateDirectoryImpl(directoryName, directoryPathInArchive, AddOrUpdateAction.AddOnly);
		}

		// Token: 0x0600119C RID: 4508 RVA: 0x0005E278 File Offset: 0x0005C478
		public ZipEntry AddDirectoryByName(string directoryNameInArchive)
		{
			ZipEntry zipEntry = ZipEntry.CreateFromNothing(directoryNameInArchive);
			zipEntry._container = new ZipContainer(this);
			zipEntry.MarkAsDirectory();
			zipEntry.AlternateEncoding = this.AlternateEncoding;
			zipEntry.AlternateEncodingUsage = this.AlternateEncodingUsage;
			zipEntry.SetEntryTimes(DateTime.Now, DateTime.Now, DateTime.Now);
			zipEntry.EmitTimesInWindowsFormatWhenSaving = this._emitNtfsTimes;
			zipEntry.EmitTimesInUnixFormatWhenSaving = this._emitUnixTimes;
			zipEntry._Source = ZipEntrySource.Stream;
			this.InternalAddEntry(zipEntry.FileName, zipEntry);
			this.AfterAddEntry(zipEntry);
			return zipEntry;
		}

		// Token: 0x0600119D RID: 4509 RVA: 0x00014060 File Offset: 0x00012260
		private ZipEntry AddOrUpdateDirectoryImpl(string directoryName, string rootDirectoryPathInArchive, AddOrUpdateAction action)
		{
			if (rootDirectoryPathInArchive == null)
			{
				rootDirectoryPathInArchive = "";
			}
			return this.AddOrUpdateDirectoryImpl(directoryName, rootDirectoryPathInArchive, action, true, 0);
		}

		// Token: 0x0600119E RID: 4510 RVA: 0x00014077 File Offset: 0x00012277
		internal void InternalAddEntry(string name, ZipEntry entry)
		{
			this._entries.Add(name, entry);
			this._zipEntriesAsList = null;
			this._contentsChanged = true;
		}

		// Token: 0x0600119F RID: 4511 RVA: 0x0005E300 File Offset: 0x0005C500
		private ZipEntry AddOrUpdateDirectoryImpl(string directoryName, string rootDirectoryPathInArchive, AddOrUpdateAction action, bool recurse, int level)
		{
			if (this.Verbose)
			{
				ZipFile.smethod_22(this.StatusMessageTextWriter, <Module>.smethod_25<string>(635175512U), (action == AddOrUpdateAction.AddOnly) ? <Module>.smethod_23<string>(379717253U) : <Module>.smethod_25<string>(356785700U), directoryName);
			}
			if (level == 0)
			{
				this._addOperationCanceled = false;
				this.OnAddStarted();
			}
			if (this._addOperationCanceled)
			{
				return null;
			}
			string text = rootDirectoryPathInArchive;
			ZipEntry zipEntry = null;
			if (level > 0)
			{
				int num = ZipFile.smethod_23(directoryName);
				for (int i = level; i > 0; i--)
				{
					num = ZipFile.smethod_25(directoryName, ZipFile.smethod_24(<Module>.smethod_26<string>(3477250752U)), num - 1, num - 1);
				}
				text = ZipFile.smethod_26(directoryName, num + 1);
				text = ZipFile.smethod_9(rootDirectoryPathInArchive, text);
			}
			if (level > 0 || ZipFile.smethod_27(rootDirectoryPathInArchive, ""))
			{
				zipEntry = ZipEntry.CreateFromFile(directoryName, text);
				zipEntry._container = new ZipContainer(this);
				zipEntry.AlternateEncoding = this.AlternateEncoding;
				zipEntry.AlternateEncodingUsage = this.AlternateEncodingUsage;
				zipEntry.MarkAsDirectory();
				zipEntry.EmitTimesInWindowsFormatWhenSaving = this._emitNtfsTimes;
				zipEntry.EmitTimesInUnixFormatWhenSaving = this._emitUnixTimes;
				if (!this._entries.ContainsKey(zipEntry.FileName))
				{
					this.InternalAddEntry(zipEntry.FileName, zipEntry);
					this.AfterAddEntry(zipEntry);
				}
				text = zipEntry.FileName;
			}
			if (!this._addOperationCanceled)
			{
				string[] array = ZipFile.smethod_28(directoryName);
				if (recurse)
				{
					foreach (string text2 in array)
					{
						if (this._addOperationCanceled)
						{
							break;
						}
						if (action != AddOrUpdateAction.AddOnly)
						{
							this.UpdateFile(text2, text);
						}
						else
						{
							this.AddFile(text2, text);
						}
					}
					if (!this._addOperationCanceled)
					{
						string[] array3 = ZipFile.smethod_29(directoryName);
						foreach (string text3 in array3)
						{
							FileAttributes fileAttributes = ZipFile.smethod_30(text3);
							if (this.AddDirectoryWillTraverseReparsePoints || (fileAttributes & FileAttributes.ReparsePoint) == (FileAttributes)0)
							{
								this.AddOrUpdateDirectoryImpl(text3, rootDirectoryPathInArchive, action, recurse, level + 1);
							}
						}
					}
				}
			}
			if (level == 0)
			{
				this.OnAddCompleted();
			}
			return zipEntry;
		}

		// Token: 0x060011A0 RID: 4512 RVA: 0x00014094 File Offset: 0x00012294
		public static bool CheckZip(string zipFileName)
		{
			return ZipFile.CheckZip(zipFileName, false, null);
		}

		// Token: 0x060011A1 RID: 4513 RVA: 0x0005E4FC File Offset: 0x0005C6FC
		public static bool CheckZip(string zipFileName, bool fixIfNecessary, TextWriter writer)
		{
			ZipFile zipFile = null;
			ZipFile zipFile2 = null;
			bool flag = true;
			try
			{
				zipFile = new ZipFile();
				zipFile.FullScan = true;
				zipFile.Initialize(zipFileName);
				zipFile2 = ZipFile.Read(zipFileName);
				IEnumerator<ZipEntry> enumerator = zipFile.GetEnumerator();
				try
				{
					while (ZipFile.smethod_6(enumerator))
					{
						ZipEntry zipEntry = enumerator.Current;
						IEnumerator<ZipEntry> enumerator2 = zipFile2.GetEnumerator();
						try
						{
							while (ZipFile.smethod_6(enumerator2))
							{
								ZipEntry zipEntry2 = enumerator2.Current;
								if (ZipFile.smethod_31(zipEntry.FileName, zipEntry2.FileName))
								{
									if (zipEntry._RelativeOffsetOfLocalHeader != zipEntry2._RelativeOffsetOfLocalHeader)
									{
										flag = false;
										if (writer != null)
										{
											ZipFile.smethod_32(writer, <Module>.smethod_24<string>(942461031U), zipEntry.FileName, zipEntry._RelativeOffsetOfLocalHeader, zipEntry2._RelativeOffsetOfLocalHeader);
										}
									}
									if (zipEntry._CompressedSize != zipEntry2._CompressedSize)
									{
										flag = false;
										if (writer != null)
										{
											ZipFile.smethod_32(writer, <Module>.smethod_27<string>(1286512133U), zipEntry.FileName, zipEntry._CompressedSize, zipEntry2._CompressedSize);
										}
									}
									if (zipEntry._UncompressedSize != zipEntry2._UncompressedSize)
									{
										flag = false;
										if (writer != null)
										{
											ZipFile.smethod_32(writer, <Module>.smethod_24<string>(1916996336U), zipEntry.FileName, zipEntry._UncompressedSize, zipEntry2._UncompressedSize);
										}
									}
									if (zipEntry.CompressionMethod != zipEntry2.CompressionMethod)
									{
										flag = false;
										if (writer != null)
										{
											ZipFile.smethod_32(writer, <Module>.smethod_23<string>(530230253U), zipEntry.FileName, zipEntry.CompressionMethod, zipEntry2.CompressionMethod);
										}
									}
									if (zipEntry.Crc == zipEntry2.Crc)
									{
										break;
									}
									flag = false;
									if (writer != null)
									{
										ZipFile.smethod_32(writer, <Module>.smethod_23<string>(3665507037U), zipEntry.FileName, zipEntry.Crc, zipEntry2.Crc);
										break;
									}
									break;
								}
							}
						}
						finally
						{
							if (enumerator2 != null)
							{
								ZipFile.smethod_7(enumerator2);
							}
						}
					}
				}
				finally
				{
					if (enumerator != null)
					{
						ZipFile.smethod_7(enumerator);
					}
				}
				zipFile2.Dispose();
				zipFile2 = null;
				if (!flag && fixIfNecessary)
				{
					string text = ZipFile.smethod_33(zipFileName);
					text = ZipFile.smethod_2(<Module>.smethod_27<string>(581415198U), text);
					zipFile.Save(text);
				}
			}
			finally
			{
				if (zipFile != null)
				{
					zipFile.Dispose();
				}
				if (zipFile2 != null)
				{
					zipFile2.Dispose();
				}
			}
			return flag;
		}

		// Token: 0x060011A2 RID: 4514 RVA: 0x0005E784 File Offset: 0x0005C984
		public static void FixZipDirectory(string zipFileName)
		{
			ZipFile zipFile = new ZipFile();
			try
			{
				zipFile.FullScan = true;
				zipFile.Initialize(zipFileName);
				zipFile.Save(zipFileName);
			}
			finally
			{
				if (zipFile != null)
				{
					ZipFile.smethod_7(zipFile);
				}
			}
		}

		// Token: 0x060011A3 RID: 4515 RVA: 0x0005E7C8 File Offset: 0x0005C9C8
		public static bool CheckZipPassword(string zipFileName, string password)
		{
			bool flag = false;
			try
			{
				ZipFile zipFile = ZipFile.Read(zipFileName);
				try
				{
					IEnumerator<ZipEntry> enumerator = zipFile.GetEnumerator();
					try
					{
						while (ZipFile.smethod_6(enumerator))
						{
							ZipEntry zipEntry = enumerator.Current;
							if (!zipEntry.IsDirectory && zipEntry.UsesEncryption)
							{
								zipEntry.ExtractWithPassword(Stream.Null, password);
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							ZipFile.smethod_7(enumerator);
						}
					}
				}
				finally
				{
					if (zipFile != null)
					{
						ZipFile.smethod_7(zipFile);
					}
				}
				flag = true;
			}
			catch (BadPasswordException)
			{
			}
			return flag;
		}

		// Token: 0x1700028F RID: 655
		// (get) Token: 0x060011A4 RID: 4516 RVA: 0x0005E85C File Offset: 0x0005CA5C
		public string Info
		{
			get
			{
				StringBuilder stringBuilder = ZipFile.smethod_34();
				ZipFile.smethod_35(stringBuilder, ZipFile.smethod_2(<Module>.smethod_24<string>(2024713458U), this.Name));
				if (!ZipFile.smethod_17(this._Comment))
				{
					ZipFile.smethod_35(stringBuilder, ZipFile.smethod_2(<Module>.smethod_24<string>(3244152891U), this._Comment));
				}
				if (this._versionMadeBy != 0)
				{
					ZipFile.smethod_35(stringBuilder, ZipFile.smethod_2(<Module>.smethod_26<string>(2916241239U), this._versionMadeBy));
				}
				if (this._versionNeededToExtract != 0)
				{
					ZipFile.smethod_35(stringBuilder, ZipFile.smethod_2(<Module>.smethod_25<string>(3915628886U), this._versionNeededToExtract));
				}
				ZipFile.smethod_35(stringBuilder, ZipFile.smethod_2(<Module>.smethod_24<string>(3758349824U), this.InputUsesZip64));
				ZipFile.smethod_35(stringBuilder, ZipFile.smethod_2(<Module>.smethod_27<string>(2545297844U), this._diskNumberWithCd));
				if (this._OffsetOfCentralDirectory != 4294967295U)
				{
					ZipFile.smethod_35(stringBuilder, ZipFile.smethod_2(<Module>.smethod_26<string>(1656154964U), this._OffsetOfCentralDirectory));
				}
				else
				{
					ZipFile.smethod_35(stringBuilder, ZipFile.smethod_2(<Module>.smethod_25<string>(1111655976U), this._OffsetOfCentralDirectory64));
				}
				ZipFile.smethod_35(stringBuilder, <Module>.smethod_24<string>(3717705751U));
				foreach (ZipEntry zipEntry in this._entries.Values)
				{
					ZipFile.smethod_35(stringBuilder, zipEntry.Info);
				}
				return ZipFile.smethod_36(stringBuilder);
			}
		}

		// Token: 0x17000290 RID: 656
		// (get) Token: 0x060011A5 RID: 4517 RVA: 0x0001409E File Offset: 0x0001229E
		// (set) Token: 0x060011A6 RID: 4518 RVA: 0x000140A6 File Offset: 0x000122A6
		public bool FullScan { get; set; }

		// Token: 0x17000291 RID: 657
		// (get) Token: 0x060011A7 RID: 4519 RVA: 0x000140AF File Offset: 0x000122AF
		// (set) Token: 0x060011A8 RID: 4520 RVA: 0x000140B7 File Offset: 0x000122B7
		public bool SortEntriesBeforeSaving { get; set; }

		// Token: 0x17000292 RID: 658
		// (get) Token: 0x060011A9 RID: 4521 RVA: 0x000140C0 File Offset: 0x000122C0
		// (set) Token: 0x060011AA RID: 4522 RVA: 0x000140C8 File Offset: 0x000122C8
		public bool AddDirectoryWillTraverseReparsePoints { get; set; }

		// Token: 0x17000293 RID: 659
		// (get) Token: 0x060011AB RID: 4523 RVA: 0x000140D1 File Offset: 0x000122D1
		// (set) Token: 0x060011AC RID: 4524 RVA: 0x000140D9 File Offset: 0x000122D9
		public int BufferSize
		{
			get
			{
				return this._BufferSize;
			}
			set
			{
				this._BufferSize = value;
			}
		}

		// Token: 0x17000294 RID: 660
		// (get) Token: 0x060011AD RID: 4525 RVA: 0x000140E2 File Offset: 0x000122E2
		// (set) Token: 0x060011AE RID: 4526 RVA: 0x000140EA File Offset: 0x000122EA
		public int CodecBufferSize { get; set; }

		// Token: 0x17000295 RID: 661
		// (get) Token: 0x060011AF RID: 4527 RVA: 0x000140F3 File Offset: 0x000122F3
		// (set) Token: 0x060011B0 RID: 4528 RVA: 0x000140FB File Offset: 0x000122FB
		public bool FlattenFoldersOnExtract { get; set; }

		// Token: 0x17000296 RID: 662
		// (get) Token: 0x060011B1 RID: 4529 RVA: 0x00014104 File Offset: 0x00012304
		// (set) Token: 0x060011B2 RID: 4530 RVA: 0x0001410C File Offset: 0x0001230C
		public CompressionStrategy Strategy
		{
			get
			{
				return this._Strategy;
			}
			set
			{
				this._Strategy = value;
			}
		}

		// Token: 0x17000297 RID: 663
		// (get) Token: 0x060011B3 RID: 4531 RVA: 0x00014115 File Offset: 0x00012315
		// (set) Token: 0x060011B4 RID: 4532 RVA: 0x0001411D File Offset: 0x0001231D
		public string Name
		{
			get
			{
				return this._name;
			}
			set
			{
				this._name = value;
			}
		}

		// Token: 0x17000298 RID: 664
		// (get) Token: 0x060011B5 RID: 4533 RVA: 0x00014126 File Offset: 0x00012326
		// (set) Token: 0x060011B6 RID: 4534 RVA: 0x0001412E File Offset: 0x0001232E
		public CompressionLevel CompressionLevel { get; set; }

		// Token: 0x17000299 RID: 665
		// (get) Token: 0x060011B7 RID: 4535 RVA: 0x00014137 File Offset: 0x00012337
		// (set) Token: 0x060011B8 RID: 4536 RVA: 0x0001413F File Offset: 0x0001233F
		public CompressionMethod CompressionMethod
		{
			get
			{
				return this._compressionMethod;
			}
			set
			{
				this._compressionMethod = value;
			}
		}

		// Token: 0x1700029A RID: 666
		// (get) Token: 0x060011B9 RID: 4537 RVA: 0x00014148 File Offset: 0x00012348
		// (set) Token: 0x060011BA RID: 4538 RVA: 0x00014150 File Offset: 0x00012350
		public string Comment
		{
			get
			{
				return this._Comment;
			}
			set
			{
				this._Comment = value;
				this._contentsChanged = true;
			}
		}

		// Token: 0x1700029B RID: 667
		// (get) Token: 0x060011BB RID: 4539 RVA: 0x00014160 File Offset: 0x00012360
		// (set) Token: 0x060011BC RID: 4540 RVA: 0x00014168 File Offset: 0x00012368
		public bool EmitTimesInWindowsFormatWhenSaving
		{
			get
			{
				return this._emitNtfsTimes;
			}
			set
			{
				this._emitNtfsTimes = value;
			}
		}

		// Token: 0x1700029C RID: 668
		// (get) Token: 0x060011BD RID: 4541 RVA: 0x00014171 File Offset: 0x00012371
		// (set) Token: 0x060011BE RID: 4542 RVA: 0x00014179 File Offset: 0x00012379
		public bool EmitTimesInUnixFormatWhenSaving
		{
			get
			{
				return this._emitUnixTimes;
			}
			set
			{
				this._emitUnixTimes = value;
			}
		}

		// Token: 0x1700029D RID: 669
		// (get) Token: 0x060011BF RID: 4543 RVA: 0x00014182 File Offset: 0x00012382
		internal bool Verbose
		{
			get
			{
				return this._StatusMessageTextWriter != null;
			}
		}

		// Token: 0x060011C0 RID: 4544 RVA: 0x00014190 File Offset: 0x00012390
		public bool ContainsEntry(string name)
		{
			return this._entries.ContainsKey(SharedUtilities.NormalizePathForUseInZipFile(name));
		}

		// Token: 0x1700029E RID: 670
		// (get) Token: 0x060011C1 RID: 4545 RVA: 0x000141A3 File Offset: 0x000123A3
		// (set) Token: 0x060011C2 RID: 4546 RVA: 0x000141AB File Offset: 0x000123AB
		public bool CaseSensitiveRetrieval
		{
			get
			{
				return this._CaseSensitiveRetrieval;
			}
			set
			{
				if (value != this._CaseSensitiveRetrieval)
				{
					this._CaseSensitiveRetrieval = value;
					this._initEntriesDictionary();
				}
			}
		}

		// Token: 0x1700029F RID: 671
		// (get) Token: 0x060011C3 RID: 4547 RVA: 0x000141C3 File Offset: 0x000123C3
		// (set) Token: 0x060011C4 RID: 4548 RVA: 0x000141E7 File Offset: 0x000123E7
		[Obsolete("Beginning with v1.9.1.6 of DotNetZip, this property is obsolete.  It will be removed in a future version of the library. Your applications should  use AlternateEncoding and AlternateEncodingUsage instead.")]
		public bool UseUnicodeAsNecessary
		{
			get
			{
				return this._alternateEncoding == ZipFile.smethod_37(<Module>.smethod_24<string>(350525539U)) && this._alternateEncodingUsage == ZipOption.AsNecessary;
			}
			set
			{
				if (value)
				{
					this._alternateEncoding = ZipFile.smethod_37(<Module>.smethod_26<string>(2277039646U));
					this._alternateEncodingUsage = ZipOption.AsNecessary;
					return;
				}
				this._alternateEncoding = ZipFile.DefaultEncoding;
				this._alternateEncodingUsage = ZipOption.Default;
			}
		}

		// Token: 0x170002A0 RID: 672
		// (get) Token: 0x060011C5 RID: 4549 RVA: 0x0001421B File Offset: 0x0001241B
		// (set) Token: 0x060011C6 RID: 4550 RVA: 0x00014223 File Offset: 0x00012423
		public Zip64Option UseZip64WhenSaving
		{
			get
			{
				return this._zip64;
			}
			set
			{
				this._zip64 = value;
			}
		}

		// Token: 0x170002A1 RID: 673
		// (get) Token: 0x060011C7 RID: 4551 RVA: 0x0005EA00 File Offset: 0x0005CC00
		public bool? RequiresZip64
		{
			get
			{
				if (this._entries.Count > 65534)
				{
					return new bool?(true);
				}
				if (this._hasBeenSaved && !this._contentsChanged)
				{
					using (Dictionary<string, ZipEntry>.ValueCollection.Enumerator enumerator = this._entries.Values.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							ZipEntry zipEntry = enumerator.Current;
							if (zipEntry.RequiresZip64.Value)
							{
								return new bool?(true);
							}
						}
						goto IL_007B;
					}
					bool? flag;
					return flag;
					IL_007B:
					return new bool?(false);
				}
				return null;
			}
		}

		// Token: 0x170002A2 RID: 674
		// (get) Token: 0x060011C8 RID: 4552 RVA: 0x0001422C File Offset: 0x0001242C
		public bool? OutputUsedZip64
		{
			get
			{
				return this._OutputUsesZip64;
			}
		}

		// Token: 0x170002A3 RID: 675
		// (get) Token: 0x060011C9 RID: 4553 RVA: 0x0005EAA8 File Offset: 0x0005CCA8
		public bool? InputUsesZip64
		{
			get
			{
				if (this._entries.Count > 65534)
				{
					return new bool?(true);
				}
				IEnumerator<ZipEntry> enumerator = this.GetEnumerator();
				try
				{
					while (ZipFile.smethod_6(enumerator))
					{
						ZipEntry zipEntry = enumerator.Current;
						if (zipEntry.Source != ZipEntrySource.ZipFile)
						{
							return null;
						}
						if (zipEntry._InputUsesZip64)
						{
							return new bool?(true);
						}
					}
				}
				finally
				{
					if (enumerator != null)
					{
						ZipFile.smethod_7(enumerator);
					}
				}
				return new bool?(false);
			}
		}

		// Token: 0x170002A4 RID: 676
		// (get) Token: 0x060011CA RID: 4554 RVA: 0x00014234 File Offset: 0x00012434
		// (set) Token: 0x060011CB RID: 4555 RVA: 0x00014247 File Offset: 0x00012447
		[Obsolete("use AlternateEncoding instead.")]
		public Encoding ProvisionalAlternateEncoding
		{
			get
			{
				if (this._alternateEncodingUsage == ZipOption.AsNecessary)
				{
					return this._alternateEncoding;
				}
				return null;
			}
			set
			{
				this._alternateEncoding = value;
				this._alternateEncodingUsage = ZipOption.AsNecessary;
			}
		}

		// Token: 0x170002A5 RID: 677
		// (get) Token: 0x060011CC RID: 4556 RVA: 0x00014257 File Offset: 0x00012457
		// (set) Token: 0x060011CD RID: 4557 RVA: 0x0001425F File Offset: 0x0001245F
		public Encoding AlternateEncoding
		{
			get
			{
				return this._alternateEncoding;
			}
			set
			{
				this._alternateEncoding = value;
			}
		}

		// Token: 0x170002A6 RID: 678
		// (get) Token: 0x060011CE RID: 4558 RVA: 0x00014268 File Offset: 0x00012468
		// (set) Token: 0x060011CF RID: 4559 RVA: 0x00014270 File Offset: 0x00012470
		public ZipOption AlternateEncodingUsage
		{
			get
			{
				return this._alternateEncodingUsage;
			}
			set
			{
				this._alternateEncodingUsage = value;
			}
		}

		// Token: 0x170002A7 RID: 679
		// (get) Token: 0x060011D0 RID: 4560 RVA: 0x00014279 File Offset: 0x00012479
		public static Encoding DefaultEncoding
		{
			get
			{
				return ZipFile._defaultEncoding;
			}
		}

		// Token: 0x170002A8 RID: 680
		// (get) Token: 0x060011D1 RID: 4561 RVA: 0x00014280 File Offset: 0x00012480
		// (set) Token: 0x060011D2 RID: 4562 RVA: 0x00014288 File Offset: 0x00012488
		public TextWriter StatusMessageTextWriter
		{
			get
			{
				return this._StatusMessageTextWriter;
			}
			set
			{
				this._StatusMessageTextWriter = value;
			}
		}

		// Token: 0x170002A9 RID: 681
		// (get) Token: 0x060011D3 RID: 4563 RVA: 0x00014291 File Offset: 0x00012491
		// (set) Token: 0x060011D4 RID: 4564 RVA: 0x00014299 File Offset: 0x00012499
		public string TempFileFolder
		{
			get
			{
				return this._TempFileFolder;
			}
			set
			{
				this._TempFileFolder = value;
				if (value == null)
				{
					return;
				}
				if (!ZipFile.smethod_1(value))
				{
					throw ZipFile.smethod_3(ZipFile.smethod_2(<Module>.smethod_23<string>(3227641660U), value));
				}
			}
		}

		// Token: 0x170002AA RID: 682
		// (get) Token: 0x060011D6 RID: 4566 RVA: 0x000142EC File Offset: 0x000124EC
		// (set) Token: 0x060011D5 RID: 4565 RVA: 0x000142C4 File Offset: 0x000124C4
		public string Password
		{
			private get
			{
				return this._Password;
			}
			set
			{
				this._Password = value;
				if (this._Password != null)
				{
					if (this.Encryption == EncryptionAlgorithm.None)
					{
						this.Encryption = EncryptionAlgorithm.PkzipWeak;
					}
					return;
				}
				this.Encryption = EncryptionAlgorithm.None;
			}
		}

		// Token: 0x170002AB RID: 683
		// (get) Token: 0x060011D7 RID: 4567 RVA: 0x000142F4 File Offset: 0x000124F4
		// (set) Token: 0x060011D8 RID: 4568 RVA: 0x000142FC File Offset: 0x000124FC
		public ExtractExistingFileAction ExtractExistingFile { get; set; }

		// Token: 0x170002AC RID: 684
		// (get) Token: 0x060011D9 RID: 4569 RVA: 0x00014305 File Offset: 0x00012505
		// (set) Token: 0x060011DA RID: 4570 RVA: 0x0001431C File Offset: 0x0001251C
		public ZipErrorAction ZipErrorAction
		{
			get
			{
				if (this.ZipError != null)
				{
					this._zipErrorAction = ZipErrorAction.InvokeErrorEvent;
				}
				return this._zipErrorAction;
			}
			set
			{
				this._zipErrorAction = value;
				if (this._zipErrorAction != ZipErrorAction.InvokeErrorEvent && this.ZipError != null)
				{
					this.ZipError = null;
				}
			}
		}

		// Token: 0x170002AD RID: 685
		// (get) Token: 0x060011DB RID: 4571 RVA: 0x0001433D File Offset: 0x0001253D
		// (set) Token: 0x060011DC RID: 4572 RVA: 0x00014345 File Offset: 0x00012545
		public EncryptionAlgorithm Encryption
		{
			get
			{
				return this._Encryption;
			}
			set
			{
				if (value == EncryptionAlgorithm.Unsupported)
				{
					throw ZipFile.smethod_38(<Module>.smethod_23<string>(2033818664U));
				}
				this._Encryption = value;
			}
		}

		// Token: 0x170002AE RID: 686
		// (get) Token: 0x060011DD RID: 4573 RVA: 0x00014362 File Offset: 0x00012562
		// (set) Token: 0x060011DE RID: 4574 RVA: 0x0001436A File Offset: 0x0001256A
		public SetCompressionCallback SetCompression { get; set; }

		// Token: 0x170002AF RID: 687
		// (get) Token: 0x060011DF RID: 4575 RVA: 0x00014373 File Offset: 0x00012573
		// (set) Token: 0x060011E0 RID: 4576 RVA: 0x0001437B File Offset: 0x0001257B
		public int MaxOutputSegmentSize
		{
			get
			{
				return this._maxOutputSegmentSize;
			}
			set
			{
				if (value < 65536 && value != 0)
				{
					throw new ZipException(<Module>.smethod_24<string>(663514491U));
				}
				this._maxOutputSegmentSize = value;
			}
		}

		// Token: 0x170002B0 RID: 688
		// (get) Token: 0x060011E1 RID: 4577 RVA: 0x0001439F File Offset: 0x0001259F
		public int NumberOfSegmentsForMostRecentSave
		{
			get
			{
				return (int)(this._numberOfSegmentsForMostRecentSave + 1U);
			}
		}

		// Token: 0x170002B1 RID: 689
		// (get) Token: 0x060011E3 RID: 4579 RVA: 0x000143E6 File Offset: 0x000125E6
		// (set) Token: 0x060011E2 RID: 4578 RVA: 0x000143A9 File Offset: 0x000125A9
		public long ParallelDeflateThreshold
		{
			get
			{
				return this._ParallelDeflateThreshold;
			}
			set
			{
				if (value != 0L && value != -1L && value < 65536L)
				{
					throw ZipFile.smethod_39(<Module>.smethod_24<string>(3156251918U));
				}
				this._ParallelDeflateThreshold = value;
			}
		}

		// Token: 0x170002B2 RID: 690
		// (get) Token: 0x060011E4 RID: 4580 RVA: 0x000143EE File Offset: 0x000125EE
		// (set) Token: 0x060011E5 RID: 4581 RVA: 0x000143F6 File Offset: 0x000125F6
		public int ParallelDeflateMaxBufferPairs
		{
			get
			{
				return this._maxBufferPairs;
			}
			set
			{
				if (value < 4)
				{
					throw ZipFile.smethod_40(<Module>.smethod_26<string>(904453448U), <Module>.smethod_23<string>(2943785049U));
				}
				this._maxBufferPairs = value;
			}
		}

		// Token: 0x060011E6 RID: 4582 RVA: 0x0001441D File Offset: 0x0001261D
		public override string ToString()
		{
			return ZipFile.smethod_2(<Module>.smethod_27<string>(1653714137U), this.Name);
		}

		// Token: 0x170002B3 RID: 691
		// (get) Token: 0x060011E7 RID: 4583 RVA: 0x00014434 File Offset: 0x00012634
		public static Version LibraryVersion
		{
			get
			{
				return ZipFile.smethod_43(ZipFile.smethod_42(ZipFile.smethod_41()));
			}
		}

		// Token: 0x060011E8 RID: 4584 RVA: 0x00014445 File Offset: 0x00012645
		internal void NotifyEntryChanged()
		{
			this._contentsChanged = true;
		}

		// Token: 0x060011E9 RID: 4585 RVA: 0x0001444E File Offset: 0x0001264E
		internal Stream StreamForDiskNumber(uint diskNumber)
		{
			if (diskNumber + 1U != this._diskNumberWithCd && (diskNumber != 0U || this._diskNumberWithCd != 0U))
			{
				return ZipSegmentedStream.ForReading(this._readName ?? this._name, diskNumber, this._diskNumberWithCd);
			}
			return this.ReadStream;
		}

		// Token: 0x060011EA RID: 4586 RVA: 0x0005EB38 File Offset: 0x0005CD38
		internal void Reset(bool whileSaving)
		{
			if (this._JustSaved)
			{
				ZipFile zipFile = new ZipFile();
				try
				{
					zipFile._readName = (zipFile._name = (whileSaving ? (this._readName ?? this._name) : this._name));
					zipFile.AlternateEncoding = this.AlternateEncoding;
					zipFile.AlternateEncodingUsage = this.AlternateEncodingUsage;
					ZipFile.ReadIntoInstance(zipFile);
					IEnumerator<ZipEntry> enumerator = zipFile.GetEnumerator();
					try
					{
						while (ZipFile.smethod_6(enumerator))
						{
							ZipEntry zipEntry = enumerator.Current;
							IEnumerator<ZipEntry> enumerator2 = this.GetEnumerator();
							try
							{
								while (ZipFile.smethod_6(enumerator2))
								{
									ZipEntry zipEntry2 = enumerator2.Current;
									if (ZipFile.smethod_31(zipEntry.FileName, zipEntry2.FileName))
									{
										zipEntry2.CopyMetaData(zipEntry);
										break;
									}
								}
							}
							finally
							{
								if (enumerator2 != null)
								{
									ZipFile.smethod_7(enumerator2);
								}
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							ZipFile.smethod_7(enumerator);
						}
					}
				}
				finally
				{
					if (zipFile != null)
					{
						ZipFile.smethod_7(zipFile);
					}
				}
				this._JustSaved = false;
			}
		}

		// Token: 0x060011EB RID: 4587 RVA: 0x0005EC48 File Offset: 0x0005CE48
		public ZipFile(string fileName)
		{
			this._alternateEncoding = ZipFile.smethod_37(<Module>.smethod_27<string>(370494147U));
			this._BufferSize = ZipFile.BufferSizeDefault;
			this._maxBufferPairs = 16;
			this._lengthOfReadStream = -99L;
			base..ctor();
			try
			{
				this._InitInstance(fileName, null);
			}
			catch (Exception ex)
			{
				throw new ZipException(ZipFile.smethod_2(<Module>.smethod_26<string>(3875461567U), fileName), ex);
			}
		}

		// Token: 0x060011EC RID: 4588 RVA: 0x0005ECF4 File Offset: 0x0005CEF4
		public ZipFile(string fileName, Encoding encoding)
		{
			this._alternateEncoding = ZipFile.smethod_37(<Module>.smethod_24<string>(1915978978U));
			this._BufferSize = ZipFile.BufferSizeDefault;
			this._maxBufferPairs = 16;
			this._lengthOfReadStream = -99L;
			base..ctor();
			try
			{
				this.AlternateEncoding = encoding;
				this.AlternateEncodingUsage = ZipOption.Always;
				this._InitInstance(fileName, null);
			}
			catch (Exception ex)
			{
				throw new ZipException(ZipFile.smethod_2(<Module>.smethod_24<string>(3670448851U), fileName), ex);
			}
		}

		// Token: 0x060011ED RID: 4589 RVA: 0x0005EDB0 File Offset: 0x0005CFB0
		public ZipFile()
		{
			this._alternateEncoding = ZipFile.smethod_37(<Module>.smethod_24<string>(1915978978U));
			this._BufferSize = ZipFile.BufferSizeDefault;
			this._maxBufferPairs = 16;
			this._lengthOfReadStream = -99L;
			base..ctor();
			this._InitInstance(null, null);
		}

		// Token: 0x060011EE RID: 4590 RVA: 0x0005EE34 File Offset: 0x0005D034
		public ZipFile(Encoding encoding)
		{
			this._alternateEncoding = ZipFile.smethod_37(<Module>.smethod_24<string>(1915978978U));
			this._BufferSize = ZipFile.BufferSizeDefault;
			this._maxBufferPairs = 16;
			this._lengthOfReadStream = -99L;
			base..ctor();
			this.AlternateEncoding = encoding;
			this.AlternateEncodingUsage = ZipOption.Always;
			this._InitInstance(null, null);
		}

		// Token: 0x060011EF RID: 4591 RVA: 0x0005EEC4 File Offset: 0x0005D0C4
		public ZipFile(string fileName, TextWriter statusMessageWriter)
		{
			this._alternateEncoding = ZipFile.smethod_37(<Module>.smethod_25<string>(1316389748U));
			this._BufferSize = ZipFile.BufferSizeDefault;
			this._maxBufferPairs = 16;
			this._lengthOfReadStream = -99L;
			base..ctor();
			try
			{
				this._InitInstance(fileName, statusMessageWriter);
			}
			catch (Exception ex)
			{
				throw new ZipException(ZipFile.smethod_2(<Module>.smethod_25<string>(743593921U), fileName), ex);
			}
		}

		// Token: 0x060011F0 RID: 4592 RVA: 0x0005EF70 File Offset: 0x0005D170
		public ZipFile(string fileName, TextWriter statusMessageWriter, Encoding encoding)
		{
			this._alternateEncoding = ZipFile.smethod_37(<Module>.smethod_23<string>(2015004539U));
			this._BufferSize = ZipFile.BufferSizeDefault;
			this._maxBufferPairs = 16;
			this._lengthOfReadStream = -99L;
			base..ctor();
			try
			{
				this.AlternateEncoding = encoding;
				this.AlternateEncodingUsage = ZipOption.Always;
				this._InitInstance(fileName, statusMessageWriter);
			}
			catch (Exception ex)
			{
				throw new ZipException(ZipFile.smethod_2(<Module>.smethod_27<string>(2440511378U), fileName), ex);
			}
		}

		// Token: 0x060011F1 RID: 4593 RVA: 0x0005F02C File Offset: 0x0005D22C
		public void Initialize(string fileName)
		{
			try
			{
				this._InitInstance(fileName, null);
			}
			catch (Exception ex)
			{
				throw new ZipException(ZipFile.smethod_2(<Module>.smethod_24<string>(3670448851U), fileName), ex);
			}
		}

		// Token: 0x060011F2 RID: 4594 RVA: 0x0005F06C File Offset: 0x0005D26C
		private void _initEntriesDictionary()
		{
			StringComparer stringComparer = ((!this.CaseSensitiveRetrieval) ? ZipFile.smethod_45() : ZipFile.smethod_46());
			this._entries = ((this._entries != null) ? new Dictionary<string, ZipEntry>(this._entries, stringComparer) : new Dictionary<string, ZipEntry>(stringComparer));
		}

		// Token: 0x060011F3 RID: 4595 RVA: 0x0005F0B0 File Offset: 0x0005D2B0
		private void _InitInstance(string zipFileName, TextWriter statusMessageWriter)
		{
			this._name = zipFileName;
			this._StatusMessageTextWriter = statusMessageWriter;
			this._contentsChanged = true;
			this.AddDirectoryWillTraverseReparsePoints = true;
			this.CompressionLevel = CompressionLevel.Default;
			this.ParallelDeflateThreshold = 524288L;
			this._initEntriesDictionary();
			if (ZipFile.smethod_0(this._name))
			{
				if (this.FullScan)
				{
					ZipFile.ReadIntoInstance_Orig(this);
				}
				else
				{
					ZipFile.ReadIntoInstance(this);
				}
				this._fileAlreadyExists = true;
			}
		}

		// Token: 0x170002B4 RID: 692
		// (get) Token: 0x060011F4 RID: 4596 RVA: 0x00014489 File Offset: 0x00012689
		private List<ZipEntry> ZipEntriesAsList
		{
			get
			{
				if (this._zipEntriesAsList == null)
				{
					this._zipEntriesAsList = new List<ZipEntry>(this._entries.Values);
				}
				return this._zipEntriesAsList;
			}
		}

		// Token: 0x170002B5 RID: 693
		public ZipEntry this[int ix]
		{
			get
			{
				return this.ZipEntriesAsList[ix];
			}
		}

		// Token: 0x170002B6 RID: 694
		public ZipEntry this[string fileName]
		{
			get
			{
				string text = SharedUtilities.NormalizePathForUseInZipFile(fileName);
				if (this._entries.ContainsKey(text))
				{
					return this._entries[text];
				}
				text = ZipFile.smethod_47(text, <Module>.smethod_23<string>(1912091352U), <Module>.smethod_27<string>(3822296921U));
				if (this._entries.ContainsKey(text))
				{
					return this._entries[text];
				}
				return null;
			}
		}

		// Token: 0x170002B7 RID: 695
		// (get) Token: 0x060011F7 RID: 4599 RVA: 0x000144BD File Offset: 0x000126BD
		public ICollection<string> EntryFileNames
		{
			get
			{
				return this._entries.Keys;
			}
		}

		// Token: 0x170002B8 RID: 696
		// (get) Token: 0x060011F8 RID: 4600 RVA: 0x000144CA File Offset: 0x000126CA
		public ICollection<ZipEntry> Entries
		{
			get
			{
				return this._entries.Values;
			}
		}

		// Token: 0x170002B9 RID: 697
		// (get) Token: 0x060011F9 RID: 4601 RVA: 0x0005F188 File Offset: 0x0005D388
		public ICollection<ZipEntry> EntriesSorted
		{
			get
			{
				List<ZipEntry> list = new List<ZipEntry>();
				IEnumerator<ZipEntry> enumerator = this.Entries.GetEnumerator();
				try
				{
					while (ZipFile.smethod_6(enumerator))
					{
						ZipEntry zipEntry = enumerator.Current;
						list.Add(zipEntry);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						ZipFile.smethod_7(enumerator);
					}
				}
				StringComparison sc = (this.CaseSensitiveRetrieval ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase);
				list.Sort((ZipEntry x, ZipEntry y) => ZipFile.<>c__DisplayClass1.smethod_0(x.FileName, y.FileName, sc));
				return list.AsReadOnly();
			}
		}

		// Token: 0x170002BA RID: 698
		// (get) Token: 0x060011FA RID: 4602 RVA: 0x000144D7 File Offset: 0x000126D7
		public int Count
		{
			get
			{
				return this._entries.Count;
			}
		}

		// Token: 0x060011FB RID: 4603 RVA: 0x000144E4 File Offset: 0x000126E4
		public void RemoveEntry(ZipEntry entry)
		{
			if (entry == null)
			{
				throw ZipFile.smethod_5(<Module>.smethod_25<string>(1300373545U));
			}
			this._entries.Remove(SharedUtilities.NormalizePathForUseInZipFile(entry.FileName));
			this._zipEntriesAsList = null;
			this._contentsChanged = true;
		}

		// Token: 0x060011FC RID: 4604 RVA: 0x0005F20C File Offset: 0x0005D40C
		public void RemoveEntry(string fileName)
		{
			string text = ZipEntry.NameInArchive(fileName, null);
			ZipEntry zipEntry = this[text];
			if (zipEntry == null)
			{
				throw ZipFile.smethod_48(<Module>.smethod_26<string>(3703086475U));
			}
			this.RemoveEntry(zipEntry);
		}

		// Token: 0x060011FD RID: 4605 RVA: 0x0001451E File Offset: 0x0001271E
		public void Dispose()
		{
			this.Dispose(true);
			ZipFile.smethod_49(this);
		}

		// Token: 0x060011FE RID: 4606 RVA: 0x0005F244 File Offset: 0x0005D444
		protected virtual void Dispose(bool disposeManagedResources)
		{
			if (!this._disposed)
			{
				if (disposeManagedResources)
				{
					if (this._ReadStreamIsOurs && this._readstream != null)
					{
						ZipFile.smethod_50(this._readstream);
						this._readstream = null;
					}
					if (this._temporaryFileName != null && this._name != null && this._writestream != null)
					{
						ZipFile.smethod_50(this._writestream);
						this._writestream = null;
					}
					if (this.ParallelDeflater != null)
					{
						this.ParallelDeflater.Dispose();
						this.ParallelDeflater = null;
					}
				}
				this._disposed = true;
			}
		}

		// Token: 0x170002BB RID: 699
		// (get) Token: 0x060011FF RID: 4607 RVA: 0x0005F2CC File Offset: 0x0005D4CC
		internal Stream ReadStream
		{
			get
			{
				if (this._readstream == null && (this._readName != null || this._name != null))
				{
					this._readstream = ZipFile.smethod_51(this._readName ?? this._name, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
					this._ReadStreamIsOurs = true;
				}
				return this._readstream;
			}
		}

		// Token: 0x170002BC RID: 700
		// (get) Token: 0x06001200 RID: 4608 RVA: 0x0005F31C File Offset: 0x0005D51C
		// (set) Token: 0x06001201 RID: 4609 RVA: 0x0001452D File Offset: 0x0001272D
		private Stream WriteStream
		{
			get
			{
				if (this._writestream != null)
				{
					return this._writestream;
				}
				if (this._name == null)
				{
					return this._writestream;
				}
				if (this._maxOutputSegmentSize != 0)
				{
					this._writestream = ZipSegmentedStream.ForWriting(this._name, this._maxOutputSegmentSize);
					return this._writestream;
				}
				SharedUtilities.CreateAndOpenUniqueTempFile(this.TempFileFolder ?? ZipFile.smethod_8(this._name), out this._writestream, out this._temporaryFileName);
				return this._writestream;
			}
			set
			{
				if (value != null)
				{
					throw new ZipException(<Module>.smethod_24<string>(1638049796U));
				}
				this._writestream = null;
			}
		}

		// Token: 0x170002BD RID: 701
		// (get) Token: 0x06001202 RID: 4610 RVA: 0x00014549 File Offset: 0x00012749
		private string ArchiveNameForEvent
		{
			get
			{
				if (this._name == null)
				{
					return <Module>.smethod_27<string>(323872454U);
				}
				return this._name;
			}
		}

		// Token: 0x14000020 RID: 32
		// (add) Token: 0x06001203 RID: 4611 RVA: 0x0005F39C File Offset: 0x0005D59C
		// (remove) Token: 0x06001204 RID: 4612 RVA: 0x0005F3D8 File Offset: 0x0005D5D8
		public event EventHandler<SaveProgressEventArgs> SaveProgress
		{
			add
			{
				EventHandler<SaveProgressEventArgs> eventHandler = this.SaveProgress;
				EventHandler<SaveProgressEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<SaveProgressEventArgs> eventHandler3 = (EventHandler<SaveProgressEventArgs>)ZipFile.smethod_52(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<SaveProgressEventArgs>>(ref this.SaveProgress, eventHandler3, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<SaveProgressEventArgs> eventHandler = this.SaveProgress;
				EventHandler<SaveProgressEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<SaveProgressEventArgs> eventHandler3 = (EventHandler<SaveProgressEventArgs>)ZipFile.smethod_53(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<SaveProgressEventArgs>>(ref this.SaveProgress, eventHandler3, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06001205 RID: 4613 RVA: 0x0005F410 File Offset: 0x0005D610
		internal bool OnSaveBlock(ZipEntry entry, long bytesXferred, long totalBytesToXfer)
		{
			EventHandler<SaveProgressEventArgs> saveProgress = this.SaveProgress;
			if (saveProgress != null)
			{
				SaveProgressEventArgs saveProgressEventArgs = SaveProgressEventArgs.ByteUpdate(this.ArchiveNameForEvent, entry, bytesXferred, totalBytesToXfer);
				saveProgress(this, saveProgressEventArgs);
				if (saveProgressEventArgs.Cancel)
				{
					this._saveOperationCanceled = true;
				}
			}
			return this._saveOperationCanceled;
		}

		// Token: 0x06001206 RID: 4614 RVA: 0x0005F454 File Offset: 0x0005D654
		private void OnSaveEntry(int current, ZipEntry entry, bool before)
		{
			EventHandler<SaveProgressEventArgs> saveProgress = this.SaveProgress;
			if (saveProgress != null)
			{
				SaveProgressEventArgs saveProgressEventArgs = new SaveProgressEventArgs(this.ArchiveNameForEvent, before, this._entries.Count, current, entry);
				saveProgress(this, saveProgressEventArgs);
				if (saveProgressEventArgs.Cancel)
				{
					this._saveOperationCanceled = true;
				}
			}
		}

		// Token: 0x06001207 RID: 4615 RVA: 0x0005F49C File Offset: 0x0005D69C
		private void OnSaveEvent(ZipProgressEventType eventFlavor)
		{
			EventHandler<SaveProgressEventArgs> saveProgress = this.SaveProgress;
			if (saveProgress != null)
			{
				SaveProgressEventArgs saveProgressEventArgs = new SaveProgressEventArgs(this.ArchiveNameForEvent, eventFlavor);
				saveProgress(this, saveProgressEventArgs);
				if (saveProgressEventArgs.Cancel)
				{
					this._saveOperationCanceled = true;
				}
			}
		}

		// Token: 0x06001208 RID: 4616 RVA: 0x0005F4D8 File Offset: 0x0005D6D8
		private void OnSaveStarted()
		{
			EventHandler<SaveProgressEventArgs> saveProgress = this.SaveProgress;
			if (saveProgress != null)
			{
				SaveProgressEventArgs saveProgressEventArgs = SaveProgressEventArgs.Started(this.ArchiveNameForEvent);
				saveProgress(this, saveProgressEventArgs);
				if (saveProgressEventArgs.Cancel)
				{
					this._saveOperationCanceled = true;
				}
			}
		}

		// Token: 0x06001209 RID: 4617 RVA: 0x0005F514 File Offset: 0x0005D714
		private void OnSaveCompleted()
		{
			EventHandler<SaveProgressEventArgs> saveProgress = this.SaveProgress;
			if (saveProgress != null)
			{
				SaveProgressEventArgs saveProgressEventArgs = SaveProgressEventArgs.Completed(this.ArchiveNameForEvent);
				saveProgress(this, saveProgressEventArgs);
			}
		}

		// Token: 0x14000021 RID: 33
		// (add) Token: 0x0600120A RID: 4618 RVA: 0x0005F540 File Offset: 0x0005D740
		// (remove) Token: 0x0600120B RID: 4619 RVA: 0x0005F5AC File Offset: 0x0005D7AC
		public event EventHandler<ReadProgressEventArgs> ReadProgress
		{
			add
			{
				EventHandler<ReadProgressEventArgs> eventHandler = this.ReadProgress;
				for (;;)
				{
					IL_0057:
					int num = -940923237;
					for (;;)
					{
						EventHandler<ReadProgressEventArgs> eventHandler3;
						EventHandler<ReadProgressEventArgs> eventHandler2;
						switch (num ^ -940923239)
						{
						case 0:
							goto IL_0057;
						case 1:
							goto IL_0026;
						case 2:
							break;
						case 3:
							eventHandler2 = (EventHandler<ReadProgressEventArgs>)ZipFile.smethod_52(eventHandler3, value);
							num = -940923240;
							continue;
						default:
							goto IL_0026;
						}
						IL_001D:
						eventHandler3 = eventHandler;
						num = -940923238;
						continue;
						IL_0026:
						eventHandler = Interlocked.CompareExchange<EventHandler<ReadProgressEventArgs>>(ref this.ReadProgress, eventHandler2, eventHandler3);
						if (eventHandler == eventHandler3)
						{
							return;
						}
						goto IL_001D;
					}
				}
			}
			remove
			{
				EventHandler<ReadProgressEventArgs> eventHandler = this.ReadProgress;
				EventHandler<ReadProgressEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<ReadProgressEventArgs> eventHandler3 = (EventHandler<ReadProgressEventArgs>)ZipFile.smethod_53(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<ReadProgressEventArgs>>(ref this.ReadProgress, eventHandler3, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x0600120C RID: 4620 RVA: 0x0005F5E4 File Offset: 0x0005D7E4
		private void OnReadStarted()
		{
			EventHandler<ReadProgressEventArgs> readProgress = this.ReadProgress;
			if (readProgress != null)
			{
				ReadProgressEventArgs readProgressEventArgs = ReadProgressEventArgs.Started(this.ArchiveNameForEvent);
				readProgress(this, readProgressEventArgs);
			}
		}

		// Token: 0x0600120D RID: 4621 RVA: 0x0005F610 File Offset: 0x0005D810
		private void OnReadCompleted()
		{
			EventHandler<ReadProgressEventArgs> readProgress = this.ReadProgress;
			if (readProgress != null)
			{
				ReadProgressEventArgs readProgressEventArgs = ReadProgressEventArgs.Completed(this.ArchiveNameForEvent);
				readProgress(this, readProgressEventArgs);
			}
		}

		// Token: 0x0600120E RID: 4622 RVA: 0x0005F63C File Offset: 0x0005D83C
		internal void OnReadBytes(ZipEntry entry)
		{
			EventHandler<ReadProgressEventArgs> readProgress = this.ReadProgress;
			if (readProgress != null)
			{
				ReadProgressEventArgs readProgressEventArgs = ReadProgressEventArgs.ByteUpdate(this.ArchiveNameForEvent, entry, ZipFile.smethod_54(this.ReadStream), this.LengthOfReadStream);
				readProgress(this, readProgressEventArgs);
			}
		}

		// Token: 0x0600120F RID: 4623 RVA: 0x0005F67C File Offset: 0x0005D87C
		internal void OnReadEntry(bool before, ZipEntry entry)
		{
			EventHandler<ReadProgressEventArgs> readProgress = this.ReadProgress;
			if (readProgress != null)
			{
				ReadProgressEventArgs readProgressEventArgs = (before ? ReadProgressEventArgs.Before(this.ArchiveNameForEvent, this._entries.Count) : ReadProgressEventArgs.After(this.ArchiveNameForEvent, entry, this._entries.Count));
				readProgress(this, readProgressEventArgs);
			}
		}

		// Token: 0x170002BE RID: 702
		// (get) Token: 0x06001210 RID: 4624 RVA: 0x00014564 File Offset: 0x00012764
		private long LengthOfReadStream
		{
			get
			{
				if (this._lengthOfReadStream == -99L)
				{
					this._lengthOfReadStream = (this._ReadStreamIsOurs ? SharedUtilities.GetFileLength(this._name) : (-1L));
				}
				return this._lengthOfReadStream;
			}
		}

		// Token: 0x14000022 RID: 34
		// (add) Token: 0x06001211 RID: 4625 RVA: 0x0005F6D0 File Offset: 0x0005D8D0
		// (remove) Token: 0x06001212 RID: 4626 RVA: 0x0005F708 File Offset: 0x0005D908
		public event EventHandler<ExtractProgressEventArgs> ExtractProgress
		{
			add
			{
				EventHandler<ExtractProgressEventArgs> eventHandler = this.ExtractProgress;
				EventHandler<ExtractProgressEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<ExtractProgressEventArgs> eventHandler3 = (EventHandler<ExtractProgressEventArgs>)ZipFile.smethod_52(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<ExtractProgressEventArgs>>(ref this.ExtractProgress, eventHandler3, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<ExtractProgressEventArgs> eventHandler = this.ExtractProgress;
				EventHandler<ExtractProgressEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<ExtractProgressEventArgs> eventHandler3 = (EventHandler<ExtractProgressEventArgs>)ZipFile.smethod_53(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<ExtractProgressEventArgs>>(ref this.ExtractProgress, eventHandler3, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06001213 RID: 4627 RVA: 0x0005F740 File Offset: 0x0005D940
		private void OnExtractEntry(int current, bool before, ZipEntry currentEntry, string path)
		{
			EventHandler<ExtractProgressEventArgs> extractProgress = this.ExtractProgress;
			if (extractProgress != null)
			{
				ExtractProgressEventArgs extractProgressEventArgs = new ExtractProgressEventArgs(this.ArchiveNameForEvent, before, this._entries.Count, current, currentEntry, path);
				extractProgress(this, extractProgressEventArgs);
				if (extractProgressEventArgs.Cancel)
				{
					this._extractOperationCanceled = true;
				}
			}
		}

		// Token: 0x06001214 RID: 4628 RVA: 0x0005F78C File Offset: 0x0005D98C
		internal bool OnExtractBlock(ZipEntry entry, long bytesWritten, long totalBytesToWrite)
		{
			EventHandler<ExtractProgressEventArgs> extractProgress = this.ExtractProgress;
			if (extractProgress != null)
			{
				ExtractProgressEventArgs extractProgressEventArgs = ExtractProgressEventArgs.ByteUpdate(this.ArchiveNameForEvent, entry, bytesWritten, totalBytesToWrite);
				extractProgress(this, extractProgressEventArgs);
				if (extractProgressEventArgs.Cancel)
				{
					this._extractOperationCanceled = true;
				}
			}
			return this._extractOperationCanceled;
		}

		// Token: 0x06001215 RID: 4629 RVA: 0x0005F7D0 File Offset: 0x0005D9D0
		internal bool OnSingleEntryExtract(ZipEntry entry, string path, bool before)
		{
			EventHandler<ExtractProgressEventArgs> extractProgress = this.ExtractProgress;
			for (;;)
			{
				IL_0080:
				int num = -1670555169;
				for (;;)
				{
					ExtractProgressEventArgs extractProgressEventArgs;
					switch (num ^ -1670555172)
					{
					case 1:
						if (!before)
						{
							num = -1670555170;
							continue;
						}
						extractProgressEventArgs = ExtractProgressEventArgs.BeforeExtractEntry(this.ArchiveNameForEvent, entry, path);
						goto IL_0027;
					case 2:
						extractProgressEventArgs = ExtractProgressEventArgs.AfterExtractEntry(this.ArchiveNameForEvent, entry, path);
						goto IL_0027;
					case 3:
						num = ((extractProgress != null) ? (-1670555171) : (-1670555172));
						continue;
					case 4:
						goto IL_0080;
					}
					goto Block_4;
					IL_0027:
					ExtractProgressEventArgs extractProgressEventArgs2 = extractProgressEventArgs;
					extractProgress(this, extractProgressEventArgs2);
					if (!extractProgressEventArgs2.Cancel)
					{
						goto IL_0087;
					}
					this._extractOperationCanceled = true;
					num = -1670555172;
				}
			}
			Block_4:
			IL_0087:
			return this._extractOperationCanceled;
		}

		// Token: 0x06001216 RID: 4630 RVA: 0x0005F86C File Offset: 0x0005DA6C
		internal bool OnExtractExisting(ZipEntry entry, string path)
		{
			EventHandler<ExtractProgressEventArgs> extractProgress = this.ExtractProgress;
			if (extractProgress != null)
			{
				ExtractProgressEventArgs extractProgressEventArgs = ExtractProgressEventArgs.ExtractExisting(this.ArchiveNameForEvent, entry, path);
				extractProgress(this, extractProgressEventArgs);
				if (extractProgressEventArgs.Cancel)
				{
					this._extractOperationCanceled = true;
				}
			}
			return this._extractOperationCanceled;
		}

		// Token: 0x06001217 RID: 4631 RVA: 0x0005F8B0 File Offset: 0x0005DAB0
		private void OnExtractAllCompleted(string path)
		{
			EventHandler<ExtractProgressEventArgs> extractProgress = this.ExtractProgress;
			if (extractProgress != null)
			{
				ExtractProgressEventArgs extractProgressEventArgs = ExtractProgressEventArgs.ExtractAllCompleted(this.ArchiveNameForEvent, path);
				extractProgress(this, extractProgressEventArgs);
			}
		}

		// Token: 0x06001218 RID: 4632 RVA: 0x0005F8DC File Offset: 0x0005DADC
		private void OnExtractAllStarted(string path)
		{
			EventHandler<ExtractProgressEventArgs> extractProgress = this.ExtractProgress;
			if (extractProgress != null)
			{
				ExtractProgressEventArgs extractProgressEventArgs = ExtractProgressEventArgs.ExtractAllStarted(this.ArchiveNameForEvent, path);
				extractProgress(this, extractProgressEventArgs);
			}
		}

		// Token: 0x14000023 RID: 35
		// (add) Token: 0x06001219 RID: 4633 RVA: 0x0005F908 File Offset: 0x0005DB08
		// (remove) Token: 0x0600121A RID: 4634 RVA: 0x0005F940 File Offset: 0x0005DB40
		public event EventHandler<AddProgressEventArgs> AddProgress
		{
			add
			{
				EventHandler<AddProgressEventArgs> eventHandler = this.AddProgress;
				EventHandler<AddProgressEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<AddProgressEventArgs> eventHandler3 = (EventHandler<AddProgressEventArgs>)ZipFile.smethod_52(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<AddProgressEventArgs>>(ref this.AddProgress, eventHandler3, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<AddProgressEventArgs> eventHandler = this.AddProgress;
				EventHandler<AddProgressEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<AddProgressEventArgs> eventHandler3 = (EventHandler<AddProgressEventArgs>)ZipFile.smethod_53(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<AddProgressEventArgs>>(ref this.AddProgress, eventHandler3, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x0600121B RID: 4635 RVA: 0x0005F978 File Offset: 0x0005DB78
		private void OnAddStarted()
		{
			EventHandler<AddProgressEventArgs> addProgress = this.AddProgress;
			if (addProgress != null)
			{
				AddProgressEventArgs addProgressEventArgs = AddProgressEventArgs.Started(this.ArchiveNameForEvent);
				addProgress(this, addProgressEventArgs);
				if (addProgressEventArgs.Cancel)
				{
					this._addOperationCanceled = true;
				}
			}
		}

		// Token: 0x0600121C RID: 4636 RVA: 0x0005F9B4 File Offset: 0x0005DBB4
		private void OnAddCompleted()
		{
			EventHandler<AddProgressEventArgs> addProgress = this.AddProgress;
			if (addProgress != null)
			{
				AddProgressEventArgs addProgressEventArgs = AddProgressEventArgs.Completed(this.ArchiveNameForEvent);
				addProgress(this, addProgressEventArgs);
			}
		}

		// Token: 0x0600121D RID: 4637 RVA: 0x0005F9E0 File Offset: 0x0005DBE0
		internal void AfterAddEntry(ZipEntry entry)
		{
			EventHandler<AddProgressEventArgs> addProgress = this.AddProgress;
			if (addProgress != null)
			{
				AddProgressEventArgs addProgressEventArgs = AddProgressEventArgs.AfterEntry(this.ArchiveNameForEvent, entry, this._entries.Count);
				addProgress(this, addProgressEventArgs);
				if (addProgressEventArgs.Cancel)
				{
					this._addOperationCanceled = true;
				}
			}
		}

		// Token: 0x14000024 RID: 36
		// (add) Token: 0x0600121E RID: 4638 RVA: 0x0005FA28 File Offset: 0x0005DC28
		// (remove) Token: 0x0600121F RID: 4639 RVA: 0x0005FA88 File Offset: 0x0005DC88
		public event EventHandler<ZipErrorEventArgs> ZipError
		{
			add
			{
				EventHandler<ZipErrorEventArgs> eventHandler = this.ZipError;
				for (;;)
				{
					IL_004C:
					int num = 1694442070;
					for (;;)
					{
						switch (num ^ 1694442068)
						{
						case 0:
							goto IL_004C;
						case 1:
							goto IL_0012;
						case 2:
							break;
						default:
							goto IL_0012;
						}
						IL_0009:
						EventHandler<ZipErrorEventArgs> eventHandler2 = eventHandler;
						num = 1694442069;
						continue;
						IL_0012:
						EventHandler<ZipErrorEventArgs> eventHandler3 = (EventHandler<ZipErrorEventArgs>)ZipFile.smethod_52(eventHandler2, value);
						eventHandler = Interlocked.CompareExchange<EventHandler<ZipErrorEventArgs>>(ref this.ZipError, eventHandler3, eventHandler2);
						if (eventHandler == eventHandler2)
						{
							return;
						}
						goto IL_0009;
					}
				}
			}
			remove
			{
				EventHandler<ZipErrorEventArgs> eventHandler = this.ZipError;
				EventHandler<ZipErrorEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<ZipErrorEventArgs> eventHandler3 = (EventHandler<ZipErrorEventArgs>)ZipFile.smethod_53(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<ZipErrorEventArgs>>(ref this.ZipError, eventHandler3, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06001220 RID: 4640 RVA: 0x0005FAC0 File Offset: 0x0005DCC0
		internal bool OnZipErrorSaving(ZipEntry entry, Exception exc)
		{
			if (this.ZipError != null)
			{
				object @lock;
				ZipFile.smethod_55(@lock = this.LOCK);
				try
				{
					ZipErrorEventArgs zipErrorEventArgs = ZipErrorEventArgs.Saving(this.Name, entry, exc);
					this.ZipError(this, zipErrorEventArgs);
					if (zipErrorEventArgs.Cancel)
					{
						this._saveOperationCanceled = true;
					}
				}
				finally
				{
					ZipFile.smethod_56(@lock);
				}
			}
			return this._saveOperationCanceled;
		}

		// Token: 0x06001221 RID: 4641 RVA: 0x000145A1 File Offset: 0x000127A1
		public void ExtractAll(string path)
		{
			this._InternalExtractAll(path, true);
		}

		// Token: 0x06001222 RID: 4642 RVA: 0x000145AB File Offset: 0x000127AB
		public void ExtractAll(string path, ExtractExistingFileAction extractExistingFile)
		{
			this.ExtractExistingFile = extractExistingFile;
			this._InternalExtractAll(path, true);
		}

		// Token: 0x06001223 RID: 4643 RVA: 0x0005FB2C File Offset: 0x0005DD2C
		private void _InternalExtractAll(string path, bool overrideExtractExistingProperty)
		{
			bool flag = this.Verbose;
			this._inExtractAll = true;
			try
			{
				this.OnExtractAllStarted(path);
				int num = 0;
				foreach (ZipEntry zipEntry in this._entries.Values)
				{
					if (flag)
					{
						ZipFile.smethod_57(this.StatusMessageTextWriter, <Module>.smethod_26<string>(884464783U), new object[]
						{
							<Module>.smethod_25<string>(4014674212U),
							<Module>.smethod_27<string>(342535193U),
							<Module>.smethod_24<string>(1109117921U),
							<Module>.smethod_26<string>(1627425782U),
							<Module>.smethod_27<string>(4264528945U)
						});
						ZipFile.smethod_59(this.StatusMessageTextWriter, ZipFile.smethod_58('-', 72));
						flag = false;
					}
					if (this.Verbose)
					{
						this.StatusMessageTextWriter.WriteLine(<Module>.smethod_23<string>(1638618892U), new object[]
						{
							zipEntry.FileName,
							zipEntry.LastModified.ToString(<Module>.smethod_23<string>(148807251U)),
							zipEntry.UncompressedSize,
							zipEntry.CompressionRatio,
							zipEntry.CompressedSize
						});
						if (!string.IsNullOrEmpty(zipEntry.Comment))
						{
							this.StatusMessageTextWriter.WriteLine(<Module>.smethod_27<string>(336763653U), zipEntry.Comment);
						}
					}
					zipEntry.Password = this._Password;
					this.OnExtractEntry(num, true, zipEntry, path);
					if (overrideExtractExistingProperty)
					{
						zipEntry.ExtractExistingFile = this.ExtractExistingFile;
					}
					zipEntry.Extract(path);
					num++;
					this.OnExtractEntry(num, false, zipEntry, path);
					if (this._extractOperationCanceled)
					{
						break;
					}
				}
				if (!this._extractOperationCanceled)
				{
					foreach (ZipEntry zipEntry2 in this._entries.Values)
					{
						if (zipEntry2.IsDirectory || zipEntry2.FileName.EndsWith(<Module>.smethod_23<string>(1912091352U)))
						{
							string text = (zipEntry2.FileName.StartsWith(<Module>.smethod_27<string>(2343293944U)) ? Path.Combine(path, zipEntry2.FileName.Substring(1)) : Path.Combine(path, zipEntry2.FileName));
							zipEntry2._SetTimes(text, false);
						}
					}
					this.OnExtractAllCompleted(path);
				}
			}
			finally
			{
				this._inExtractAll = false;
			}
		}

		// Token: 0x06001224 RID: 4644 RVA: 0x000145BC File Offset: 0x000127BC
		public static ZipFile Read(string fileName)
		{
			return ZipFile.Read(fileName, null, null, null);
		}

		// Token: 0x06001225 RID: 4645 RVA: 0x000145C7 File Offset: 0x000127C7
		public static ZipFile Read(string fileName, ReadOptions options)
		{
			if (options == null)
			{
				throw ZipFile.smethod_5(<Module>.smethod_24<string>(2842754287U));
			}
			return ZipFile.Read(fileName, options.StatusMessageWriter, options.Encoding, options.ReadProgress);
		}

		// Token: 0x06001226 RID: 4646 RVA: 0x0005FDF8 File Offset: 0x0005DFF8
		private static ZipFile Read(string fileName, TextWriter statusMessageWriter, Encoding encoding, EventHandler<ReadProgressEventArgs> readProgress)
		{
			ZipFile zipFile = new ZipFile();
			zipFile.AlternateEncoding = encoding ?? ZipFile.DefaultEncoding;
			zipFile.AlternateEncodingUsage = ZipOption.Always;
			zipFile._StatusMessageTextWriter = statusMessageWriter;
			zipFile._name = fileName;
			if (readProgress != null)
			{
				zipFile.ReadProgress = readProgress;
			}
			if (zipFile.Verbose)
			{
				ZipFile.smethod_4(zipFile._StatusMessageTextWriter, <Module>.smethod_26<string>(4028683871U), fileName);
			}
			ZipFile.ReadIntoInstance(zipFile);
			zipFile._fileAlreadyExists = true;
			return zipFile;
		}

		// Token: 0x06001227 RID: 4647 RVA: 0x000145F4 File Offset: 0x000127F4
		public static ZipFile Read(Stream zipStream)
		{
			return ZipFile.Read(zipStream, null, null, null);
		}

		// Token: 0x06001228 RID: 4648 RVA: 0x000145FF File Offset: 0x000127FF
		public static ZipFile Read(Stream zipStream, ReadOptions options)
		{
			if (options == null)
			{
				throw ZipFile.smethod_5(<Module>.smethod_26<string>(1876412026U));
			}
			return ZipFile.Read(zipStream, options.StatusMessageWriter, options.Encoding, options.ReadProgress);
		}

		// Token: 0x06001229 RID: 4649 RVA: 0x0005FE68 File Offset: 0x0005E068
		private static ZipFile Read(Stream zipStream, TextWriter statusMessageWriter, Encoding encoding, EventHandler<ReadProgressEventArgs> readProgress)
		{
			if (zipStream == null)
			{
				throw ZipFile.smethod_5(<Module>.smethod_26<string>(1181332997U));
			}
			ZipFile zipFile = new ZipFile();
			zipFile._StatusMessageTextWriter = statusMessageWriter;
			zipFile._alternateEncoding = encoding ?? ZipFile.DefaultEncoding;
			zipFile._alternateEncodingUsage = ZipOption.Always;
			if (readProgress != null)
			{
				zipFile.ReadProgress += readProgress;
			}
			zipFile._readstream = ((ZipFile.smethod_54(zipStream) == 0L) ? zipStream : new OffsetStream(zipStream));
			zipFile._ReadStreamIsOurs = false;
			if (zipFile.Verbose)
			{
				ZipFile.smethod_59(zipFile._StatusMessageTextWriter, <Module>.smethod_27<string>(4165514019U));
			}
			ZipFile.ReadIntoInstance(zipFile);
			return zipFile;
		}

		// Token: 0x0600122A RID: 4650 RVA: 0x0005FF04 File Offset: 0x0005E104
		private static void ReadIntoInstance(ZipFile zf)
		{
			Stream readStream = zf.ReadStream;
			try
			{
				zf._readName = zf._name;
				if (!ZipFile.smethod_60(readStream))
				{
					ZipFile.ReadIntoInstance_Orig(zf);
					return;
				}
				zf.OnReadStarted();
				uint num = ZipFile.ReadFirstFourBytes(readStream);
				if (num == 101010256U)
				{
					return;
				}
				int num2 = 0;
				bool flag = false;
				long num3 = ZipFile.smethod_61(readStream) - 64L;
				long num4 = ZipFile.smethod_62(ZipFile.smethod_61(readStream) - 16384L, 10L);
				do
				{
					if (num3 < 0L)
					{
						num3 = 0L;
					}
					ZipFile.smethod_16(readStream, num3, SeekOrigin.Begin);
					long num5 = SharedUtilities.FindSignature(readStream, 101010256);
					if (num5 != -1L)
					{
						flag = true;
					}
					else
					{
						if (num3 == 0L)
						{
							break;
						}
						num2++;
						num3 -= (long)(32 * (num2 + 1) * num2);
					}
					if (flag)
					{
						break;
					}
				}
				while (num3 > num4);
				if (flag)
				{
					zf._locEndOfCDS = ZipFile.smethod_54(readStream) - 4L;
					byte[] array = new byte[16];
					ZipFile.smethod_63(readStream, array, 0, array.Length);
					zf._diskNumberWithCd = (uint)ZipFile.smethod_64(array, 2);
					if (zf._diskNumberWithCd == 65535U)
					{
						throw new ZipException(<Module>.smethod_27<string>(3559432010U));
					}
					zf._diskNumberWithCd += 1U;
					uint num6 = ZipFile.smethod_65(array, 12);
					if (num6 == 4294967295U)
					{
						ZipFile.Zip64SeekToCentralDirectory(zf);
					}
					else
					{
						zf._OffsetOfCentralDirectory = num6;
						ZipFile.smethod_16(readStream, (long)((ulong)num6), SeekOrigin.Begin);
					}
					ZipFile.ReadCentralDirectory(zf);
				}
				else
				{
					ZipFile.smethod_16(readStream, 0L, SeekOrigin.Begin);
					ZipFile.ReadIntoInstance_Orig(zf);
				}
			}
			catch (Exception ex)
			{
				if (zf._ReadStreamIsOurs && zf._readstream != null)
				{
					for (;;)
					{
						IL_01E4:
						int num7 = -1605540984;
						for (;;)
						{
							switch (num7 ^ -1605540983)
							{
							case 0:
								goto IL_01E4;
							case 1:
								ZipFile.smethod_50(zf._readstream);
								zf._readstream = null;
								num7 = -1605540981;
								continue;
							}
							goto Block_16;
						}
					}
					Block_16:;
				}
				throw new ZipException(<Module>.smethod_26<string>(1028110693U), ex);
			}
			zf._contentsChanged = false;
		}

		// Token: 0x0600122B RID: 4651 RVA: 0x00060134 File Offset: 0x0005E334
		private static void Zip64SeekToCentralDirectory(ZipFile zf)
		{
			Stream readStream = zf.ReadStream;
			uint num2;
			for (;;)
			{
				IL_011C:
				int num = -1244272211;
				for (;;)
				{
					byte[] array;
					switch (num ^ -1244272217)
					{
					case 0:
						if (num2 != 101075792U)
						{
							goto Block_1;
						}
						goto IL_00B6;
					case 1:
						num2 = (uint)SharedUtilities.ReadInt(readStream);
						num = -1244272217;
						continue;
					case 2:
						goto IL_00B6;
					case 3:
					{
						long num3;
						array = new byte[num3];
						ZipFile.smethod_63(readStream, array, 0, array.Length);
						long num4 = ZipFile.smethod_66(array, 36);
						num = -1244272209;
						continue;
					}
					case 5:
						zf._OffsetOfCentralDirectory = uint.MaxValue;
						num = -1244272212;
						continue;
					case 6:
						goto IL_011C;
					case 7:
					{
						long num3 = ZipFile.smethod_66(array, 0);
						num = -1244272220;
						continue;
					}
					case 8:
					{
						long num4;
						ZipFile.smethod_16(readStream, num4, SeekOrigin.Begin);
						num = -1244272221;
						continue;
					}
					case 9:
					{
						long num4;
						ZipFile.smethod_16(readStream, num4, SeekOrigin.Begin);
						num = -1244272218;
						continue;
					}
					case 10:
					{
						array = new byte[16];
						ZipFile.smethod_16(readStream, -40L, SeekOrigin.Current);
						ZipFile.smethod_63(readStream, array, 0, 16);
						long num4 = ZipFile.smethod_66(array, 8);
						num = -1244272222;
						continue;
					}
					case 11:
					{
						long num4;
						zf._OffsetOfCentralDirectory64 = num4;
						num = -1244272210;
						continue;
					}
					}
					return;
					IL_00B6:
					ZipFile.smethod_63(readStream, array, 0, 8);
					num = -1244272224;
				}
			}
			Block_1:
			throw new BadReadException(ZipFile.smethod_67(<Module>.smethod_25<string>(1121029059U), num2, ZipFile.smethod_54(readStream)));
		}

		// Token: 0x0600122C RID: 4652 RVA: 0x0006028C File Offset: 0x0005E48C
		private static uint ReadFirstFourBytes(Stream s)
		{
			return (uint)SharedUtilities.ReadInt(s);
		}

		// Token: 0x0600122D RID: 4653 RVA: 0x000602A4 File Offset: 0x0005E4A4
		private static void ReadCentralDirectory(ZipFile zf)
		{
			bool flag = false;
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			ZipEntry zipEntry;
			while ((zipEntry = ZipEntry.ReadDirEntry(zf, dictionary)) != null)
			{
				zipEntry.ResetDirEntry();
				zf.OnReadEntry(true, null);
				if (zf.Verbose)
				{
					ZipFile.smethod_4(zf.StatusMessageTextWriter, <Module>.smethod_23<string>(111179001U), zipEntry.FileName);
				}
				zf._entries.Add(zipEntry.FileName, zipEntry);
				if (zipEntry._InputUsesZip64)
				{
					flag = true;
				}
				dictionary.Add(zipEntry.FileName, null);
			}
			if (flag)
			{
				zf.UseZip64WhenSaving = Zip64Option.Always;
			}
			if (zf._locEndOfCDS > 0L)
			{
				ZipFile.smethod_16(zf.ReadStream, zf._locEndOfCDS, SeekOrigin.Begin);
			}
			ZipFile.ReadCentralDirectoryFooter(zf);
			if (zf.Verbose && !ZipFile.smethod_17(zf.Comment))
			{
				ZipFile.smethod_4(zf.StatusMessageTextWriter, <Module>.smethod_23<string>(1002331261U), zf.Comment);
			}
			if (zf.Verbose)
			{
				ZipFile.smethod_4(zf.StatusMessageTextWriter, <Module>.smethod_26<string>(1809377268U), zf._entries.Count);
			}
			zf.OnReadCompleted();
		}

		// Token: 0x0600122E RID: 4654 RVA: 0x000603B8 File Offset: 0x0005E5B8
		private static void ReadIntoInstance_Orig(ZipFile zf)
		{
			zf.OnReadStarted();
			zf._entries = new Dictionary<string, ZipEntry>();
			if (zf.Verbose)
			{
				if (zf.Name == null)
				{
					ZipFile.smethod_59(zf.StatusMessageTextWriter, <Module>.smethod_27<string>(2434739838U));
				}
				else
				{
					ZipFile.smethod_4(zf.StatusMessageTextWriter, <Module>.smethod_26<string>(3256993690U), zf.Name);
				}
			}
			bool flag = true;
			ZipContainer zipContainer = new ZipContainer(zf);
			ZipEntry zipEntry;
			while ((zipEntry = ZipEntry.ReadEntry(zipContainer, flag)) != null)
			{
				if (zf.Verbose)
				{
					ZipFile.smethod_4(zf.StatusMessageTextWriter, <Module>.smethod_23<string>(1949925896U), zipEntry.FileName);
				}
				zf._entries.Add(zipEntry.FileName, zipEntry);
				flag = false;
			}
			try
			{
				Dictionary<string, object> dictionary = new Dictionary<string, object>();
				ZipEntry zipEntry2;
				while ((zipEntry2 = ZipEntry.ReadDirEntry(zf, dictionary)) != null)
				{
					ZipEntry zipEntry3 = zf._entries[zipEntry2.FileName];
					if (zipEntry3 != null)
					{
						zipEntry3._Comment = zipEntry2.Comment;
						if (zipEntry2.IsDirectory)
						{
							zipEntry3.MarkAsDirectory();
						}
					}
					dictionary.Add(zipEntry2.FileName, null);
				}
				if (zf._locEndOfCDS > 0L)
				{
					ZipFile.smethod_16(zf.ReadStream, zf._locEndOfCDS, SeekOrigin.Begin);
				}
				ZipFile.ReadCentralDirectoryFooter(zf);
				if (zf.Verbose && !ZipFile.smethod_17(zf.Comment))
				{
					ZipFile.smethod_4(zf.StatusMessageTextWriter, <Module>.smethod_26<string>(1075992663U), zf.Comment);
				}
			}
			catch (ZipException)
			{
			}
			catch (IOException)
			{
			}
			zf.OnReadCompleted();
		}

		// Token: 0x0600122F RID: 4655 RVA: 0x00060544 File Offset: 0x0005E744
		private static void ReadCentralDirectoryFooter(ZipFile zf)
		{
			Stream readStream = zf.ReadStream;
			int num = SharedUtilities.ReadSignature(readStream);
			int num2 = 0;
			byte[] array;
			if ((long)num == 101075792L)
			{
				array = new byte[52];
				ZipFile.smethod_63(readStream, array, 0, array.Length);
				long num3 = ZipFile.smethod_66(array, 0);
				if (num3 < 44L)
				{
					throw new ZipException(<Module>.smethod_26<string>(3177965733U));
				}
				zf._versionMadeBy = ZipFile.smethod_64(array, num2);
				num2 += 2;
				zf._versionNeededToExtract = ZipFile.smethod_64(array, num2);
				num2 += 2;
				zf._diskNumberWithCd = ZipFile.smethod_65(array, num2);
				num2 += 2;
				array = new byte[num3 - 44L];
				ZipFile.smethod_63(readStream, array, 0, array.Length);
				num = SharedUtilities.ReadSignature(readStream);
				if ((long)num != 117853008L)
				{
					throw new ZipException(<Module>.smethod_23<string>(3498437914U));
				}
				array = new byte[16];
				ZipFile.smethod_63(readStream, array, 0, array.Length);
				num = SharedUtilities.ReadSignature(readStream);
			}
			if ((long)num != 101010256L)
			{
				ZipFile.smethod_16(readStream, -4L, SeekOrigin.Current);
				throw new BadReadException(ZipFile.smethod_67(<Module>.smethod_25<string>(1204058182U), num, ZipFile.smethod_54(readStream)));
			}
			array = new byte[16];
			ZipFile.smethod_63(zf.ReadStream, array, 0, array.Length);
			if (zf._diskNumberWithCd == 0U)
			{
				zf._diskNumberWithCd = (uint)ZipFile.smethod_64(array, 2);
			}
			ZipFile.ReadZipFileComment(zf);
		}

		// Token: 0x06001230 RID: 4656 RVA: 0x000606C0 File Offset: 0x0005E8C0
		private static void ReadZipFileComment(ZipFile zf)
		{
			byte[] array = new byte[2];
			ZipFile.smethod_63(zf.ReadStream, array, 0, array.Length);
			short num = (short)((int)array[0] + (int)array[1] * 256);
			if (num > 0)
			{
				array = new byte[(int)num];
				ZipFile.smethod_63(zf.ReadStream, array, 0, array.Length);
				string text = ZipFile.smethod_68(zf.AlternateEncoding, array, 0, array.Length);
				zf.Comment = text;
			}
		}

		// Token: 0x06001231 RID: 4657 RVA: 0x0001462C File Offset: 0x0001282C
		public static bool IsZipFile(string fileName)
		{
			return ZipFile.IsZipFile(fileName, false);
		}

		// Token: 0x06001232 RID: 4658 RVA: 0x00060728 File Offset: 0x0005E928
		public static bool IsZipFile(string fileName, bool testExtract)
		{
			bool flag = false;
			try
			{
				if (!ZipFile.smethod_0(fileName))
				{
					return false;
				}
				FileStream fileStream = ZipFile.smethod_51(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
				try
				{
					flag = ZipFile.IsZipFile(fileStream, testExtract);
				}
				finally
				{
					if (fileStream != null)
					{
						ZipFile.smethod_7(fileStream);
					}
				}
			}
			catch (IOException)
			{
			}
			catch (ZipException)
			{
			}
			return flag;
		}

		// Token: 0x06001233 RID: 4659 RVA: 0x00060794 File Offset: 0x0005E994
		public static bool IsZipFile(Stream stream, bool testExtract)
		{
			if (stream == null)
			{
				throw ZipFile.smethod_5(<Module>.smethod_24<string>(3955997052U));
			}
			bool flag = false;
			try
			{
				if (!ZipFile.smethod_69(stream))
				{
					return false;
				}
				Stream @null = Stream.Null;
				ZipFile zipFile = ZipFile.Read(stream, null, null, null);
				try
				{
					if (testExtract)
					{
						IEnumerator<ZipEntry> enumerator = zipFile.GetEnumerator();
						try
						{
							while (ZipFile.smethod_6(enumerator))
							{
								ZipEntry zipEntry = enumerator.Current;
								if (!zipEntry.IsDirectory)
								{
									zipEntry.Extract(@null);
								}
							}
						}
						finally
						{
							if (enumerator != null)
							{
								ZipFile.smethod_7(enumerator);
							}
						}
					}
				}
				finally
				{
					if (zipFile != null)
					{
						ZipFile.smethod_7(zipFile);
					}
				}
				flag = true;
			}
			catch (IOException)
			{
			}
			catch (ZipException)
			{
			}
			return flag;
		}

		// Token: 0x06001234 RID: 4660 RVA: 0x00060860 File Offset: 0x0005EA60
		private void DeleteFileWithRetry(string filename)
		{
			bool flag = false;
			int num = 3;
			int i = 0;
			while (i < num)
			{
				if (!flag)
				{
					try
					{
						ZipFile.smethod_70(filename);
						flag = true;
						goto IL_008E;
					}
					catch (UnauthorizedAccessException)
					{
						ZipFile.smethod_71(<Module>.smethod_24<string>(2506388433U));
						for (;;)
						{
							IL_0065:
							int num2 = 622604932;
							for (;;)
							{
								switch (num2 ^ 622604933)
								{
								case 1:
									ZipFile.smethod_72(200 + i * 200);
									num2 = 622604933;
									continue;
								case 2:
									goto IL_0065;
								}
								goto Block_6;
							}
						}
						Block_6:
						goto IL_008E;
					}
					goto IL_006E;
					IL_008E:
					i++;
					goto IL_0087;
				}
				int num3 = 622604935;
				IL_006E:
				switch (num3 ^ 622604933)
				{
				case 0:
					IL_0087:
					num3 = 622604932;
					goto IL_006E;
				case 1:
					break;
				case 2:
					return;
				default:
					return;
				}
			}
		}

		// Token: 0x06001235 RID: 4661 RVA: 0x00060914 File Offset: 0x0005EB14
		public void Save()
		{
			try
			{
				bool flag = false;
				this._saveOperationCanceled = false;
				this._numberOfSegmentsForMostRecentSave = 0U;
				this.OnSaveStarted();
				if (this.WriteStream == null)
				{
					throw new BadStateException(<Module>.smethod_25<string>(3431176678U));
				}
				if (this._name != null && ZipFile.smethod_73(this._name, <Module>.smethod_27<string>(2453781641U)) && !this._SavingSfx)
				{
					throw new BadStateException(<Module>.smethod_23<string>(1391152767U));
				}
				if (!this._contentsChanged)
				{
					this.OnSaveCompleted();
					if (this.Verbose)
					{
						ZipFile.smethod_59(this.StatusMessageTextWriter, <Module>.smethod_23<string>(3635277291U));
					}
				}
				else
				{
					this.Reset(true);
					if (this.Verbose)
					{
						ZipFile.smethod_59(this.StatusMessageTextWriter, <Module>.smethod_25<string>(975191033U));
					}
					if (this._entries.Count >= 65535 && this._zip64 == Zip64Option.Default)
					{
						throw new ZipException(<Module>.smethod_27<string>(1381482702U));
					}
					int num = 0;
					ICollection<ZipEntry> collection = (this.SortEntriesBeforeSaving ? this.EntriesSorted : this.Entries);
					IEnumerator<ZipEntry> enumerator = collection.GetEnumerator();
					try
					{
						while (ZipFile.smethod_6(enumerator))
						{
							ZipEntry zipEntry = enumerator.Current;
							this.OnSaveEntry(num, zipEntry, true);
							zipEntry.Write(this.WriteStream);
							if (this._saveOperationCanceled)
							{
								break;
							}
							num++;
							this.OnSaveEntry(num, zipEntry, false);
							if (this._saveOperationCanceled)
							{
								break;
							}
							if (zipEntry.IncludedInMostRecentSave)
							{
								flag |= zipEntry.OutputUsedZip64.Value;
							}
						}
					}
					finally
					{
						if (enumerator != null)
						{
							ZipFile.smethod_7(enumerator);
						}
					}
					if (!this._saveOperationCanceled)
					{
						ZipSegmentedStream zipSegmentedStream = this.WriteStream as ZipSegmentedStream;
						this._numberOfSegmentsForMostRecentSave = ((zipSegmentedStream != null) ? zipSegmentedStream.CurrentSegment : 1U);
						bool flag2 = ZipOutput.WriteCentralDirectoryStructure(this.WriteStream, collection, this._numberOfSegmentsForMostRecentSave, this._zip64, this.Comment, new ZipContainer(this));
						this.OnSaveEvent(ZipProgressEventType.Saving_AfterSaveTempArchive);
						this._hasBeenSaved = true;
						this._contentsChanged = false;
						flag = flag || flag2;
						this._OutputUsesZip64 = new bool?(flag);
						if (this._name != null && (this._temporaryFileName != null || zipSegmentedStream != null))
						{
							ZipFile.smethod_50(this.WriteStream);
							if (this._saveOperationCanceled)
							{
								return;
							}
							if (this._fileAlreadyExists && this._readstream != null)
							{
								ZipFile.smethod_74(this._readstream);
								this._readstream = null;
								IEnumerator<ZipEntry> enumerator2 = collection.GetEnumerator();
								try
								{
									while (ZipFile.smethod_6(enumerator2))
									{
										ZipEntry zipEntry2 = enumerator2.Current;
										ZipSegmentedStream zipSegmentedStream2 = zipEntry2._archiveStream as ZipSegmentedStream;
										if (zipSegmentedStream2 != null)
										{
											ZipFile.smethod_50(zipSegmentedStream2);
										}
										zipEntry2._archiveStream = null;
									}
								}
								finally
								{
									if (enumerator2 != null)
									{
										ZipFile.smethod_7(enumerator2);
									}
								}
							}
							string text = null;
							if (ZipFile.smethod_0(this._name))
							{
								text = ZipFile.smethod_76(this._name, <Module>.smethod_24<string>(4261372568U), ZipFile.smethod_75());
								if (ZipFile.smethod_0(text))
								{
									this.DeleteFileWithRetry(text);
								}
								ZipFile.smethod_77(this._name, text);
							}
							this.OnSaveEvent(ZipProgressEventType.Saving_BeforeRenameTempArchive);
							ZipFile.smethod_77((zipSegmentedStream != null) ? zipSegmentedStream.CurrentTempName : this._temporaryFileName, this._name);
							this.OnSaveEvent(ZipProgressEventType.Saving_AfterRenameTempArchive);
							if (text != null)
							{
								try
								{
									if (ZipFile.smethod_0(text))
									{
										ZipFile.smethod_70(text);
									}
								}
								catch
								{
								}
							}
							this._fileAlreadyExists = true;
						}
						ZipFile.NotifyEntriesSaveComplete(collection);
						this.OnSaveCompleted();
						this._JustSaved = true;
					}
				}
			}
			finally
			{
				this.CleanupAfterSaveOperation();
			}
		}

		// Token: 0x06001236 RID: 4662 RVA: 0x00060CCC File Offset: 0x0005EECC
		private static void NotifyEntriesSaveComplete(ICollection<ZipEntry> c)
		{
			IEnumerator<ZipEntry> enumerator = c.GetEnumerator();
			try
			{
				while (ZipFile.smethod_6(enumerator))
				{
					ZipEntry zipEntry = enumerator.Current;
					zipEntry.NotifySaveComplete();
				}
			}
			finally
			{
				if (enumerator != null)
				{
					ZipFile.smethod_7(enumerator);
				}
			}
		}

		// Token: 0x06001237 RID: 4663 RVA: 0x00060D14 File Offset: 0x0005EF14
		private void RemoveTempFile()
		{
			try
			{
				if (ZipFile.smethod_0(this._temporaryFileName))
				{
					ZipFile.smethod_70(this._temporaryFileName);
				}
			}
			catch (IOException ex)
			{
				if (this.Verbose)
				{
					ZipFile.smethod_4(this.StatusMessageTextWriter, <Module>.smethod_23<string>(2494400904U), ZipFile.smethod_78(ex));
				}
			}
		}

		// Token: 0x06001238 RID: 4664 RVA: 0x00060D74 File Offset: 0x0005EF74
		private void CleanupAfterSaveOperation()
		{
			if (this._name != null)
			{
				if (this._writestream != null)
				{
					try
					{
						ZipFile.smethod_50(this._writestream);
					}
					catch (IOException)
					{
					}
				}
				this._writestream = null;
				if (this._temporaryFileName != null)
				{
					this.RemoveTempFile();
					this._temporaryFileName = null;
				}
			}
		}

		// Token: 0x06001239 RID: 4665 RVA: 0x00060DD0 File Offset: 0x0005EFD0
		public void Save(string fileName)
		{
			if (this._name == null)
			{
				this._writestream = null;
			}
			else
			{
				this._readName = this._name;
			}
			this._name = fileName;
			if (ZipFile.smethod_1(this._name))
			{
				throw new ZipException(<Module>.smethod_25<string>(4066926838U), ZipFile.smethod_20(<Module>.smethod_27<string>(816250846U), <Module>.smethod_27<string>(3759189045U)));
			}
			this._contentsChanged = true;
			this._fileAlreadyExists = ZipFile.smethod_0(this._name);
			this.Save();
		}

		// Token: 0x0600123A RID: 4666 RVA: 0x00060E58 File Offset: 0x0005F058
		public void Save(Stream outputStream)
		{
			if (outputStream == null)
			{
				throw ZipFile.smethod_5(<Module>.smethod_24<string>(390660933U));
			}
			if (!ZipFile.smethod_79(outputStream))
			{
				throw ZipFile.smethod_20(<Module>.smethod_25<string>(2068675491U), <Module>.smethod_26<string>(1293832920U));
			}
			this._name = null;
			this._writestream = new CountingStream(outputStream);
			this._contentsChanged = true;
			this._fileAlreadyExists = false;
			this.Save();
		}

		// Token: 0x0600123B RID: 4667 RVA: 0x00014635 File Offset: 0x00012835
		public void AddSelectedFiles(string selectionCriteria)
		{
			this.AddSelectedFiles(selectionCriteria, <Module>.smethod_23<string>(386296197U), null, false);
		}

		// Token: 0x0600123C RID: 4668 RVA: 0x0001464A File Offset: 0x0001284A
		public void AddSelectedFiles(string selectionCriteria, bool recurseDirectories)
		{
			this.AddSelectedFiles(selectionCriteria, <Module>.smethod_27<string>(859418173U), null, recurseDirectories);
		}

		// Token: 0x0600123D RID: 4669 RVA: 0x0001465F File Offset: 0x0001285F
		public void AddSelectedFiles(string selectionCriteria, string directoryOnDisk)
		{
			this.AddSelectedFiles(selectionCriteria, directoryOnDisk, null, false);
		}

		// Token: 0x0600123E RID: 4670 RVA: 0x0001466B File Offset: 0x0001286B
		public void AddSelectedFiles(string selectionCriteria, string directoryOnDisk, bool recurseDirectories)
		{
			this.AddSelectedFiles(selectionCriteria, directoryOnDisk, null, recurseDirectories);
		}

		// Token: 0x0600123F RID: 4671 RVA: 0x00014677 File Offset: 0x00012877
		public void AddSelectedFiles(string selectionCriteria, string directoryOnDisk, string directoryPathInArchive)
		{
			this.AddSelectedFiles(selectionCriteria, directoryOnDisk, directoryPathInArchive, false);
		}

		// Token: 0x06001240 RID: 4672 RVA: 0x00014683 File Offset: 0x00012883
		public void AddSelectedFiles(string selectionCriteria, string directoryOnDisk, string directoryPathInArchive, bool recurseDirectories)
		{
			this._AddOrUpdateSelectedFiles(selectionCriteria, directoryOnDisk, directoryPathInArchive, recurseDirectories, false);
		}

		// Token: 0x06001241 RID: 4673 RVA: 0x00014691 File Offset: 0x00012891
		public void UpdateSelectedFiles(string selectionCriteria, string directoryOnDisk, string directoryPathInArchive, bool recurseDirectories)
		{
			this._AddOrUpdateSelectedFiles(selectionCriteria, directoryOnDisk, directoryPathInArchive, recurseDirectories, true);
		}

		// Token: 0x06001242 RID: 4674 RVA: 0x0001469F File Offset: 0x0001289F
		private string EnsureendInSlash(string s)
		{
			if (ZipFile.smethod_73(s, <Module>.smethod_23<string>(1896772993U)))
			{
				return s;
			}
			return ZipFile.smethod_80(s, <Module>.smethod_26<string>(1197414755U));
		}

		// Token: 0x06001243 RID: 4675 RVA: 0x00060EC4 File Offset: 0x0005F0C4
		private void _AddOrUpdateSelectedFiles(string selectionCriteria, string directoryOnDisk, string directoryPathInArchive, bool recurseDirectories, bool wantUpdate)
		{
			if (directoryOnDisk == null && ZipFile.smethod_1(selectionCriteria))
			{
				directoryOnDisk = selectionCriteria;
				selectionCriteria = <Module>.smethod_25<string>(2403231086U);
			}
			else if (ZipFile.smethod_17(directoryOnDisk))
			{
				directoryOnDisk = <Module>.smethod_26<string>(3551626751U);
			}
			while (ZipFile.smethod_73(directoryOnDisk, <Module>.smethod_27<string>(3822296921U)))
			{
				directoryOnDisk = ZipFile.smethod_81(directoryOnDisk, 0, ZipFile.smethod_23(directoryOnDisk) - 1);
			}
			if (this.Verbose)
			{
				ZipFile.smethod_22(this.StatusMessageTextWriter, <Module>.smethod_25<string>(2625455115U), selectionCriteria, directoryOnDisk);
			}
			FileSelector fileSelector = new FileSelector(selectionCriteria, this.AddDirectoryWillTraverseReparsePoints);
			ReadOnlyCollection<string> readOnlyCollection = fileSelector.SelectFiles(directoryOnDisk, recurseDirectories);
			if (this.Verbose)
			{
				ZipFile.smethod_4(this.StatusMessageTextWriter, <Module>.smethod_24<string>(1027309930U), readOnlyCollection.Count);
			}
			this.OnAddStarted();
			AddOrUpdateAction addOrUpdateAction = (wantUpdate ? AddOrUpdateAction.AddOrUpdate : AddOrUpdateAction.AddOnly);
			IEnumerator<string> enumerator = readOnlyCollection.GetEnumerator();
			try
			{
				while (ZipFile.smethod_6(enumerator))
				{
					string text = enumerator.Current;
					string text2 = ((directoryPathInArchive == null) ? null : ZipFile.ReplaceLeadingDirectory(ZipFile.smethod_8(text), directoryOnDisk, directoryPathInArchive));
					if (ZipFile.smethod_0(text))
					{
						if (!wantUpdate)
						{
							this.AddFile(text, text2);
						}
						else
						{
							this.UpdateFile(text, text2);
						}
					}
					else
					{
						this.AddOrUpdateDirectoryImpl(text, text2, addOrUpdateAction, false, 0);
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					ZipFile.smethod_7(enumerator);
				}
			}
			this.OnAddCompleted();
		}

		// Token: 0x06001244 RID: 4676 RVA: 0x0006101C File Offset: 0x0005F21C
		private static string ReplaceLeadingDirectory(string original, string pattern, string replacement)
		{
			string text = ZipFile.smethod_82(original);
			string text2 = ZipFile.smethod_82(pattern);
			int num = ZipFile.smethod_83(text, text2);
			if (num != 0)
			{
				return original;
			}
			return ZipFile.smethod_80(replacement, ZipFile.smethod_26(original, ZipFile.smethod_23(text2)));
		}

		// Token: 0x06001245 RID: 4677 RVA: 0x00061058 File Offset: 0x0005F258
		public ICollection<ZipEntry> SelectEntries(string selectionCriteria)
		{
			FileSelector fileSelector = new FileSelector(selectionCriteria, this.AddDirectoryWillTraverseReparsePoints);
			return fileSelector.SelectEntries(this);
		}

		// Token: 0x06001246 RID: 4678 RVA: 0x0006107C File Offset: 0x0005F27C
		public ICollection<ZipEntry> SelectEntries(string selectionCriteria, string directoryPathInArchive)
		{
			FileSelector fileSelector = new FileSelector(selectionCriteria, this.AddDirectoryWillTraverseReparsePoints);
			return fileSelector.SelectEntries(this, directoryPathInArchive);
		}

		// Token: 0x06001247 RID: 4679 RVA: 0x000610A0 File Offset: 0x0005F2A0
		public int RemoveSelectedEntries(string selectionCriteria)
		{
			ICollection<ZipEntry> collection = this.SelectEntries(selectionCriteria);
			this.RemoveEntries(collection);
			return collection.Count;
		}

		// Token: 0x06001248 RID: 4680 RVA: 0x000610C4 File Offset: 0x0005F2C4
		public int RemoveSelectedEntries(string selectionCriteria, string directoryPathInArchive)
		{
			ICollection<ZipEntry> collection = this.SelectEntries(selectionCriteria, directoryPathInArchive);
			this.RemoveEntries(collection);
			return collection.Count;
		}

		// Token: 0x06001249 RID: 4681 RVA: 0x000610E8 File Offset: 0x0005F2E8
		public void ExtractSelectedEntries(string selectionCriteria)
		{
			IEnumerator<ZipEntry> enumerator = this.SelectEntries(selectionCriteria).GetEnumerator();
			try
			{
				while (ZipFile.smethod_6(enumerator))
				{
					ZipEntry zipEntry = enumerator.Current;
					zipEntry.Password = this._Password;
					zipEntry.Extract();
				}
			}
			finally
			{
				if (enumerator != null)
				{
					ZipFile.smethod_7(enumerator);
				}
			}
		}

		// Token: 0x0600124A RID: 4682 RVA: 0x00061144 File Offset: 0x0005F344
		public void ExtractSelectedEntries(string selectionCriteria, ExtractExistingFileAction extractExistingFile)
		{
			IEnumerator<ZipEntry> enumerator = this.SelectEntries(selectionCriteria).GetEnumerator();
			try
			{
				while (ZipFile.smethod_6(enumerator))
				{
					ZipEntry zipEntry = enumerator.Current;
					zipEntry.Password = this._Password;
					zipEntry.Extract(extractExistingFile);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					ZipFile.smethod_7(enumerator);
				}
			}
		}

		// Token: 0x0600124B RID: 4683 RVA: 0x000611A0 File Offset: 0x0005F3A0
		public void ExtractSelectedEntries(string selectionCriteria, string directoryPathInArchive)
		{
			IEnumerator<ZipEntry> enumerator = this.SelectEntries(selectionCriteria, directoryPathInArchive).GetEnumerator();
			try
			{
				while (ZipFile.smethod_6(enumerator))
				{
					ZipEntry zipEntry = enumerator.Current;
					zipEntry.Password = this._Password;
					zipEntry.Extract();
				}
			}
			finally
			{
				if (enumerator != null)
				{
					ZipFile.smethod_7(enumerator);
				}
			}
		}

		// Token: 0x0600124C RID: 4684 RVA: 0x000611FC File Offset: 0x0005F3FC
		public void ExtractSelectedEntries(string selectionCriteria, string directoryInArchive, string extractDirectory)
		{
			IEnumerator<ZipEntry> enumerator = this.SelectEntries(selectionCriteria, directoryInArchive).GetEnumerator();
			try
			{
				while (ZipFile.smethod_6(enumerator))
				{
					ZipEntry zipEntry = enumerator.Current;
					zipEntry.Password = this._Password;
					zipEntry.Extract(extractDirectory);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					ZipFile.smethod_7(enumerator);
				}
			}
		}

		// Token: 0x0600124D RID: 4685 RVA: 0x00061258 File Offset: 0x0005F458
		public void ExtractSelectedEntries(string selectionCriteria, string directoryPathInArchive, string extractDirectory, ExtractExistingFileAction extractExistingFile)
		{
			IEnumerator<ZipEntry> enumerator = this.SelectEntries(selectionCriteria, directoryPathInArchive).GetEnumerator();
			try
			{
				while (ZipFile.smethod_6(enumerator))
				{
					ZipEntry zipEntry = enumerator.Current;
					zipEntry.Password = this._Password;
					zipEntry.Extract(extractDirectory, extractExistingFile);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					ZipFile.smethod_7(enumerator);
				}
			}
		}

		// Token: 0x0600124E RID: 4686 RVA: 0x000612B8 File Offset: 0x0005F4B8
		public void SaveSelfExtractor(string exeToGenerate, SelfExtractorFlavor flavor)
		{
			this.SaveSelfExtractor(exeToGenerate, new SelfExtractorSaveOptions
			{
				Flavor = flavor
			});
		}

		// Token: 0x0600124F RID: 4687 RVA: 0x000612DC File Offset: 0x0005F4DC
		public void SaveSelfExtractor(string exeToGenerate, SelfExtractorSaveOptions options)
		{
			if (this._name == null)
			{
				this._writestream = null;
			}
			this._SavingSfx = true;
			this._name = exeToGenerate;
			if (ZipFile.smethod_1(this._name))
			{
				throw new ZipException(<Module>.smethod_27<string>(583142381U), ZipFile.smethod_20(<Module>.smethod_27<string>(816250846U), <Module>.smethod_23<string>(1117474013U)));
			}
			this._contentsChanged = true;
			this._fileAlreadyExists = ZipFile.smethod_0(this._name);
			this._SaveSfxStub(exeToGenerate, options);
			this.Save();
			this._SavingSfx = false;
		}

		// Token: 0x06001250 RID: 4688 RVA: 0x0006136C File Offset: 0x0005F56C
		private static void ExtractResourceToFile(Assembly a, string resourceName, string filename)
		{
			byte[] array = new byte[1024];
			Stream stream = ZipFile.smethod_84(a, resourceName);
			try
			{
				if (stream == null)
				{
					throw new ZipException(ZipFile.smethod_2(<Module>.smethod_26<string>(2569074250U), resourceName));
				}
				FileStream fileStream = ZipFile.smethod_85(filename);
				try
				{
					int num;
					do
					{
						num = ZipFile.smethod_63(stream, array, 0, array.Length);
						ZipFile.smethod_86(fileStream, array, 0, num);
					}
					while (num > 0);
				}
				finally
				{
					if (fileStream != null)
					{
						ZipFile.smethod_7(fileStream);
					}
				}
			}
			finally
			{
				if (stream != null)
				{
					ZipFile.smethod_7(stream);
				}
			}
		}

		// Token: 0x06001251 RID: 4689 RVA: 0x000613FC File Offset: 0x0005F5FC
		private void _SaveSfxStub(string exeToGenerate, SelfExtractorSaveOptions options)
		{
			string text = null;
			string text2 = null;
			string text3 = null;
			try
			{
				if (ZipFile.smethod_0(exeToGenerate) && this.Verbose)
				{
					ZipFile.smethod_4(this.StatusMessageTextWriter, <Module>.smethod_27<string>(3753417505U), exeToGenerate);
				}
				if (!ZipFile.smethod_73(exeToGenerate, <Module>.smethod_27<string>(2453781641U)) && this.Verbose)
				{
					ZipFile.smethod_59(this.StatusMessageTextWriter, <Module>.smethod_23<string>(1697319269U));
				}
				text3 = this.TempFileFolder ?? ZipFile.smethod_8(exeToGenerate);
				text = ZipFile.GenerateTempPathname(text3, <Module>.smethod_26<string>(483837163U));
				Assembly assembly = ZipFile.smethod_88(ZipFile.smethod_87(typeof(ZipFile).TypeHandle));
				using (CSharpCodeProvider csharpCodeProvider = ZipFile.smethod_89(new Dictionary<string, string> { 
				{
					<Module>.smethod_25<string>(2535782872U),
					<Module>.smethod_25<string>(2187795607U)
				} }))
				{
					ZipFile.ExtractorSettings extractorSettings = null;
					ZipFile.ExtractorSettings[] settingsList = ZipFile.SettingsList;
					int i = 0;
					while (i < settingsList.Length)
					{
						ZipFile.ExtractorSettings extractorSettings2 = settingsList[i];
						if (extractorSettings2.Flavor == options.Flavor)
						{
							extractorSettings = extractorSettings2;
							IL_00FA:
							if (extractorSettings == null)
							{
								throw new BadStateException(ZipFile.smethod_2(<Module>.smethod_26<string>(2645685402U), options.Flavor));
							}
							CompilerParameters compilerParameters = ZipFile.smethod_90();
							ZipFile.smethod_93(ZipFile.smethod_91(compilerParameters), ZipFile.smethod_92(assembly));
							if (extractorSettings.ReferencedAssemblies != null)
							{
								foreach (string text4 in extractorSettings.ReferencedAssemblies)
								{
									ZipFile.smethod_93(ZipFile.smethod_91(compilerParameters), text4);
								}
							}
							ZipFile.smethod_94(compilerParameters, false);
							ZipFile.smethod_95(compilerParameters, true);
							ZipFile.smethod_96(compilerParameters, false);
							ZipFile.smethod_97(compilerParameters, "");
							Assembly assembly2 = ZipFile.smethod_41();
							StringBuilder stringBuilder = ZipFile.smethod_34();
							string text5 = ZipFile.GenerateTempPathname(text3, <Module>.smethod_27<string>(1320312936U));
							using (ZipFile zipFile = ZipFile.Read(ZipFile.smethod_84(assembly2, <Module>.smethod_27<string>(2395616868U))))
							{
								text2 = ZipFile.GenerateTempPathname(text3, <Module>.smethod_23<string>(3291482539U));
								if (ZipFile.smethod_17(options.IconFile))
								{
									ZipFile.smethod_98(text2);
									ZipEntry zipEntry = zipFile[<Module>.smethod_25<string>(4026777258U)];
									if ((zipEntry.Attributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
									{
										zipEntry.Attributes ^= FileAttributes.ReadOnly;
									}
									zipEntry.Extract(text2);
									string text6 = ZipFile.smethod_9(text2, <Module>.smethod_24<string>(2849355948U));
									CompilerParameters compilerParameters2 = compilerParameters;
									ZipFile.smethod_97(compilerParameters2, ZipFile.smethod_80(ZipFile.smethod_99(compilerParameters2), ZipFile.smethod_2(<Module>.smethod_23<string>(1994952650U), text6)));
								}
								else
								{
									CompilerParameters compilerParameters3 = compilerParameters;
									ZipFile.smethod_97(compilerParameters3, ZipFile.smethod_80(ZipFile.smethod_99(compilerParameters3), ZipFile.smethod_2(<Module>.smethod_26<string>(2090254550U), options.IconFile)));
								}
								ZipFile.smethod_100(compilerParameters, text);
								if (options.Flavor == SelfExtractorFlavor.WinFormsApplication)
								{
									CompilerParameters compilerParameters4 = compilerParameters;
									ZipFile.smethod_97(compilerParameters4, ZipFile.smethod_80(ZipFile.smethod_99(compilerParameters4), <Module>.smethod_24<string>(4122653942U)));
								}
								if (!ZipFile.smethod_17(options.AdditionalCompilerSwitches))
								{
									CompilerParameters compilerParameters5 = compilerParameters;
									ZipFile.smethod_97(compilerParameters5, ZipFile.smethod_76(ZipFile.smethod_99(compilerParameters5), <Module>.smethod_24<string>(2570929253U), options.AdditionalCompilerSwitches));
								}
								if (ZipFile.smethod_17(ZipFile.smethod_99(compilerParameters)))
								{
									ZipFile.smethod_97(compilerParameters, null);
								}
								if (extractorSettings.CopyThroughResources != null && extractorSettings.CopyThroughResources.Count != 0)
								{
									if (!ZipFile.smethod_1(text2))
									{
										ZipFile.smethod_98(text2);
									}
									foreach (string text7 in extractorSettings.CopyThroughResources)
									{
										string text8 = ZipFile.smethod_9(text2, text7);
										ZipFile.ExtractResourceToFile(assembly2, text7, text8);
										ZipFile.smethod_93(ZipFile.smethod_101(compilerParameters), text8);
									}
								}
								ZipFile.smethod_93(ZipFile.smethod_101(compilerParameters), ZipFile.smethod_92(assembly));
								ZipFile.smethod_35(ZipFile.smethod_35(ZipFile.smethod_35(ZipFile.smethod_35(ZipFile.smethod_35(stringBuilder, ZipFile.smethod_76(<Module>.smethod_27<string>(1463183008U), ZipFile.smethod_19(text5), <Module>.smethod_26<string>(1590882786U))), <Module>.smethod_24<string>(1047126079U)), <Module>.smethod_24<string>(3946343317U)), ZipFile.smethod_36(ZipFile.LibraryVersion)), <Module>.smethod_23<string>(4163820674U)).Append(DateTime.Now.ToString(<Module>.smethod_27<string>(1037816231U))).Append(<Module>.smethod_26<string>(537297794U));
								if (!string.IsNullOrEmpty(options.Description))
								{
									stringBuilder.Append(<Module>.smethod_26<string>(2708722427U) + options.Description.Replace(<Module>.smethod_27<string>(600527310U), "") + <Module>.smethod_27<string>(3747645965U));
								}
								else
								{
									stringBuilder.Append(<Module>.smethod_24<string>(165572954U));
								}
								if (!string.IsNullOrEmpty(options.ProductVersion))
								{
									stringBuilder.Append(<Module>.smethod_24<string>(1845350759U) + options.ProductVersion.Replace(<Module>.smethod_23<string>(2473225630U), "") + <Module>.smethod_25<string>(1521268950U));
								}
								string text9 = (string.IsNullOrEmpty(options.Copyright) ? <Module>.smethod_25<string>(3081860789U) : options.Copyright.Replace(<Module>.smethod_24<string>(3627261383U), ""));
								if (!string.IsNullOrEmpty(options.ProductName))
								{
									stringBuilder.Append(<Module>.smethod_26<string>(1586703401U)).Append(options.ProductName.Replace(<Module>.smethod_24<string>(3627261383U), "")).Append(<Module>.smethod_26<string>(2727875215U));
								}
								else
								{
									stringBuilder.Append(<Module>.smethod_23<string>(2805707908U));
								}
								stringBuilder.Append(<Module>.smethod_27<string>(1830385012U) + text9 + <Module>.smethod_27<string>(3747645965U)).Append(string.Format(<Module>.smethod_25<string>(2435408922U), ZipFile.LibraryVersion.ToString()));
								if (options.FileVersion != null)
								{
									stringBuilder.Append(string.Format(<Module>.smethod_23<string>(4276705424U), options.FileVersion.ToString()));
								}
								stringBuilder.Append(<Module>.smethod_23<string>(3117014912U));
								string text10 = options.DefaultExtractDirectory;
								if (text10 != null)
								{
									text10 = text10.Replace(<Module>.smethod_26<string>(1981843186U), "").Replace(<Module>.smethod_27<string>(3822296921U), <Module>.smethod_23<string>(4239077174U));
								}
								string text11 = options.PostExtractCommandLine;
								if (text11 != null)
								{
									text11 = text11.Replace(<Module>.smethod_26<string>(1197414755U), <Module>.smethod_24<string>(312413695U));
									text11 = text11.Replace(<Module>.smethod_25<string>(1519722181U), <Module>.smethod_23<string>(1351163368U));
								}
								foreach (string text12 in extractorSettings.ResourcesToCompile)
								{
									using (Stream stream = zipFile[text12].OpenReader())
									{
										if (stream == null)
										{
											throw new ZipException(string.Format(<Module>.smethod_25<string>(3002890253U), text12));
										}
										using (StreamReader streamReader = new StreamReader(stream))
										{
											while (streamReader.Peek() >= 0)
											{
												string text13 = streamReader.ReadLine();
												if (text10 != null)
												{
													text13 = text13.Replace(<Module>.smethod_24<string>(2751292561U), text10);
												}
												text13 = text13.Replace(<Module>.smethod_27<string>(1358396542U), options.RemoveUnpackedFilesAfterExecute.ToString());
												text13 = text13.Replace(<Module>.smethod_25<string>(1481119370U), options.Quiet.ToString());
												if (!string.IsNullOrEmpty(options.SfxExeWindowTitle))
												{
													text13 = text13.Replace(<Module>.smethod_26<string>(815013220U), options.SfxExeWindowTitle);
												}
												text13 = text13.Replace(<Module>.smethod_26<string>(2563495589U), ((int)options.ExtractExistingFile).ToString());
												if (text11 != null)
												{
													text13 = text13.Replace(<Module>.smethod_25<string>(2206541773U), text11);
												}
												stringBuilder.Append(text13).Append(<Module>.smethod_23<string>(287085070U));
											}
										}
										stringBuilder.Append(<Module>.smethod_24<string>(699586036U));
									}
								}
							}
							string text14 = stringBuilder.ToString();
							CompilerResults compilerResults = csharpCodeProvider.CompileAssemblyFromSource(compilerParameters, new string[] { text14 });
							if (compilerResults == null)
							{
								throw new SfxGenerationException(<Module>.smethod_26<string>(4020688405U));
							}
							if (this.Verbose)
							{
								foreach (string text15 in compilerResults.Output)
								{
									this.StatusMessageTextWriter.WriteLine(text15);
								}
							}
							if (compilerResults.Errors.Count != 0)
							{
								using (TextWriter textWriter = new StreamWriter(text5))
								{
									textWriter.Write(text14);
									textWriter.Write(<Module>.smethod_24<string>(1159924408U));
									textWriter.Write(<Module>.smethod_24<string>(577133972U));
									string fileName = Path.GetFileName(text5);
									foreach (object obj in compilerResults.Errors)
									{
										CompilerError compilerError = (CompilerError)obj;
										textWriter.Write(string.Format(<Module>.smethod_23<string>(3065713039U), new object[]
										{
											fileName,
											compilerError.Line,
											compilerError.Column,
											compilerError.IsWarning ? <Module>.smethod_27<string>(198176384U) : <Module>.smethod_27<string>(4166791829U),
											compilerError.ErrorNumber,
											compilerError.ErrorText
										}));
									}
								}
								throw new SfxGenerationException(string.Format(<Module>.smethod_24<string>(3936689582U), text5));
							}
							this.OnSaveEvent(ZipProgressEventType.Saving_AfterCompileSelfExtractor);
							using (Stream stream2 = File.OpenRead(text))
							{
								byte[] array = new byte[4000];
								int num = 1;
								while (num != 0)
								{
									num = stream2.Read(array, 0, array.Length);
									if (num != 0)
									{
										this.WriteStream.Write(array, 0, num);
									}
								}
							}
							goto IL_0A2F;
						}
						else
						{
							i++;
						}
					}
					goto IL_00FA;
				}
				IL_0A2F:
				this.OnSaveEvent(ZipProgressEventType.Saving_AfterSaveTempArchive);
			}
			finally
			{
				try
				{
					if (Directory.Exists(text2))
					{
						try
						{
							Directory.Delete(text2, true);
						}
						catch (IOException ex)
						{
							this.StatusMessageTextWriter.WriteLine(<Module>.smethod_26<string>(3924924465U), ex);
						}
					}
					if (File.Exists(text))
					{
						try
						{
							File.Delete(text);
						}
						catch (IOException ex2)
						{
							for (;;)
							{
								IL_0AB3:
								int num2 = -726469148;
								for (;;)
								{
									switch (num2 ^ -726469147)
									{
									case 1:
										this.StatusMessageTextWriter.WriteLine(<Module>.smethod_25<string>(3369623684U), ex2);
										num2 = -726469147;
										continue;
									case 2:
										goto IL_0AB3;
									}
									goto Block_92;
								}
							}
							Block_92:;
						}
					}
				}
				catch (IOException)
				{
				}
			}
		}

		// Token: 0x06001252 RID: 4690 RVA: 0x00062038 File Offset: 0x00060238
		internal static string GenerateTempPathname(string dir, string extension)
		{
			string text = ZipFile.smethod_102(ZipFile.smethod_42(ZipFile.smethod_41()));
			string text4;
			for (;;)
			{
				string text2 = Guid.NewGuid().ToString();
				string text3 = string.Format(<Module>.smethod_24<string>(1321500091U), new object[]
				{
					text,
					DateTime.Now.ToString(<Module>.smethod_24<string>(562399030U)),
					text2,
					extension
				});
				text4 = Path.Combine(dir, text3);
				if (!File.Exists(text4))
				{
					if (!Directory.Exists(text4))
					{
						break;
					}
				}
			}
			return text4;
		}

		// Token: 0x06001253 RID: 4691 RVA: 0x000620D4 File Offset: 0x000602D4
		public IEnumerator<ZipEntry> GetEnumerator()
		{
			foreach (ZipEntry e in this._entries.Values)
			{
				yield return e;
			}
			yield break;
		}

		// Token: 0x06001254 RID: 4692 RVA: 0x000146C5 File Offset: 0x000128C5
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		// Token: 0x06001255 RID: 4693 RVA: 0x000146C5 File Offset: 0x000128C5
		[DispId(-4)]
		public IEnumerator GetNewEnum()
		{
			return this.GetEnumerator();
		}

		// Token: 0x06001257 RID: 4695 RVA: 0x0000C681 File Offset: 0x0000A881
		static bool smethod_0(string string_0)
		{
			return File.Exists(string_0);
		}

		// Token: 0x06001258 RID: 4696 RVA: 0x0000D8B1 File Offset: 0x0000BAB1
		static bool smethod_1(string string_0)
		{
			return Directory.Exists(string_0);
		}

		// Token: 0x06001259 RID: 4697 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_2(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x0600125A RID: 4698 RVA: 0x00013358 File Offset: 0x00011558
		static FileNotFoundException smethod_3(string string_0)
		{
			return new FileNotFoundException(string_0);
		}

		// Token: 0x0600125B RID: 4699 RVA: 0x000146CD File Offset: 0x000128CD
		static void smethod_4(TextWriter textWriter_0, string string_0, object object_0)
		{
			textWriter_0.WriteLine(string_0, object_0);
		}

		// Token: 0x0600125C RID: 4700 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_5(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x0600125D RID: 4701 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_6(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x0600125E RID: 4702 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_7(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x0600125F RID: 4703 RVA: 0x0000C66E File Offset: 0x0000A86E
		static string smethod_8(string string_0)
		{
			return Path.GetDirectoryName(string_0);
		}

		// Token: 0x06001260 RID: 4704 RVA: 0x0000C656 File Offset: 0x0000A856
		static string smethod_9(string string_0, string string_1)
		{
			return Path.Combine(string_0, string_1);
		}

		// Token: 0x06001261 RID: 4705 RVA: 0x000146D7 File Offset: 0x000128D7
		static string smethod_10(string string_0)
		{
			return Path.GetFullPath(string_0);
		}

		// Token: 0x06001262 RID: 4706 RVA: 0x00012348 File Offset: 0x00010548
		static Encoding smethod_11()
		{
			return Encoding.Default;
		}

		// Token: 0x06001263 RID: 4707 RVA: 0x0000C8A7 File Offset: 0x0000AAA7
		static MemoryStream smethod_12()
		{
			return new MemoryStream();
		}

		// Token: 0x06001264 RID: 4708 RVA: 0x000146DF File Offset: 0x000128DF
		static StreamWriter smethod_13(Stream stream_0, Encoding encoding_0)
		{
			return new StreamWriter(stream_0, encoding_0);
		}

		// Token: 0x06001265 RID: 4709 RVA: 0x000146E8 File Offset: 0x000128E8
		static void smethod_14(TextWriter textWriter_0, string string_0)
		{
			textWriter_0.Write(string_0);
		}

		// Token: 0x06001266 RID: 4710 RVA: 0x000146F1 File Offset: 0x000128F1
		static void smethod_15(TextWriter textWriter_0)
		{
			textWriter_0.Flush();
		}

		// Token: 0x06001267 RID: 4711 RVA: 0x00012BED File Offset: 0x00010DED
		static long smethod_16(Stream stream_0, long long_0, SeekOrigin seekOrigin_0)
		{
			return stream_0.Seek(long_0, seekOrigin_0);
		}

		// Token: 0x06001268 RID: 4712 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_17(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06001269 RID: 4713 RVA: 0x0000FABD File Offset: 0x0000DCBD
		static int smethod_18(string string_0, char char_0)
		{
			return string_0.IndexOf(char_0);
		}

		// Token: 0x0600126A RID: 4714 RVA: 0x0000CFF4 File Offset: 0x0000B1F4
		static string smethod_19(string string_0)
		{
			return Path.GetFileName(string_0);
		}

		// Token: 0x0600126B RID: 4715 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_20(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}

		// Token: 0x0600126C RID: 4716 RVA: 0x0000C877 File Offset: 0x0000AA77
		static MemoryStream smethod_21(byte[] byte_0)
		{
			return new MemoryStream(byte_0);
		}

		// Token: 0x0600126D RID: 4717 RVA: 0x000146F9 File Offset: 0x000128F9
		static void smethod_22(TextWriter textWriter_0, string string_0, object object_0, object object_1)
		{
			textWriter_0.WriteLine(string_0, object_0, object_1);
		}

		// Token: 0x0600126E RID: 4718 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_23(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x0600126F RID: 4719 RVA: 0x00014704 File Offset: 0x00012904
		static char[] smethod_24(string string_0)
		{
			return string_0.ToCharArray();
		}

		// Token: 0x06001270 RID: 4720 RVA: 0x0001470C File Offset: 0x0001290C
		static int smethod_25(string string_0, char[] char_0, int int_0, int int_1)
		{
			return string_0.LastIndexOfAny(char_0, int_0, int_1);
		}

		// Token: 0x06001271 RID: 4721 RVA: 0x0000D416 File Offset: 0x0000B616
		static string smethod_26(string string_0, int int_0)
		{
			return string_0.Substring(int_0);
		}

		// Token: 0x06001272 RID: 4722 RVA: 0x0000CDA1 File Offset: 0x0000AFA1
		static bool smethod_27(string string_0, string string_1)
		{
			return string_0 != string_1;
		}

		// Token: 0x06001273 RID: 4723 RVA: 0x0001308B File Offset: 0x0001128B
		static string[] smethod_28(string string_0)
		{
			return Directory.GetFiles(string_0);
		}

		// Token: 0x06001274 RID: 4724 RVA: 0x00013093 File Offset: 0x00011293
		static string[] smethod_29(string string_0)
		{
			return Directory.GetDirectories(string_0);
		}

		// Token: 0x06001275 RID: 4725 RVA: 0x00012F3E File Offset: 0x0001113E
		static FileAttributes smethod_30(string string_0)
		{
			return File.GetAttributes(string_0);
		}

		// Token: 0x06001276 RID: 4726 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_31(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06001277 RID: 4727 RVA: 0x00014717 File Offset: 0x00012917
		static void smethod_32(TextWriter textWriter_0, string string_0, object object_0, object object_1, object object_2)
		{
			textWriter_0.WriteLine(string_0, object_0, object_1, object_2);
		}

		// Token: 0x06001278 RID: 4728 RVA: 0x0000DA84 File Offset: 0x0000BC84
		static string smethod_33(string string_0)
		{
			return Path.GetFileNameWithoutExtension(string_0);
		}

		// Token: 0x06001279 RID: 4729 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_34()
		{
			return new StringBuilder();
		}

		// Token: 0x0600127A RID: 4730 RVA: 0x0000DB11 File Offset: 0x0000BD11
		static StringBuilder smethod_35(StringBuilder stringBuilder_0, string string_0)
		{
			return stringBuilder_0.Append(string_0);
		}

		// Token: 0x0600127B RID: 4731 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_36(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x0600127C RID: 4732 RVA: 0x0001282F File Offset: 0x00010A2F
		static Encoding smethod_37(string string_0)
		{
			return Encoding.GetEncoding(string_0);
		}

		// Token: 0x0600127D RID: 4733 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_38(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x0600127E RID: 4734 RVA: 0x0000F870 File Offset: 0x0000DA70
		static ArgumentOutOfRangeException smethod_39(string string_0)
		{
			return new ArgumentOutOfRangeException(string_0);
		}

		// Token: 0x0600127F RID: 4735 RVA: 0x0000DECA File Offset: 0x0000C0CA
		static ArgumentOutOfRangeException smethod_40(string string_0, string string_1)
		{
			return new ArgumentOutOfRangeException(string_0, string_1);
		}

		// Token: 0x06001280 RID: 4736 RVA: 0x0000C65F File Offset: 0x0000A85F
		static Assembly smethod_41()
		{
			return Assembly.GetExecutingAssembly();
		}

		// Token: 0x06001281 RID: 4737 RVA: 0x0000C7FC File Offset: 0x0000A9FC
		static AssemblyName smethod_42(Assembly assembly_0)
		{
			return assembly_0.GetName();
		}

		// Token: 0x06001282 RID: 4738 RVA: 0x0000C804 File Offset: 0x0000AA04
		static Version smethod_43(AssemblyName assemblyName_0)
		{
			return assemblyName_0.Version;
		}

		// Token: 0x06001283 RID: 4739 RVA: 0x00013209 File Offset: 0x00011409
		static object smethod_44()
		{
			return new object();
		}

		// Token: 0x06001284 RID: 4740 RVA: 0x00014724 File Offset: 0x00012924
		static StringComparer smethod_45()
		{
			return StringComparer.OrdinalIgnoreCase;
		}

		// Token: 0x06001285 RID: 4741 RVA: 0x0001283F File Offset: 0x00010A3F
		static StringComparer smethod_46()
		{
			return StringComparer.Ordinal;
		}

		// Token: 0x06001286 RID: 4742 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_47(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x06001287 RID: 4743 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_48(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x06001288 RID: 4744 RVA: 0x0001472B File Offset: 0x0001292B
		static void smethod_49(object object_0)
		{
			GC.SuppressFinalize(object_0);
		}

		// Token: 0x06001289 RID: 4745 RVA: 0x0000FB13 File Offset: 0x0000DD13
		static void smethod_50(Stream stream_0)
		{
			stream_0.Dispose();
		}

		// Token: 0x0600128A RID: 4746 RVA: 0x0000FB08 File Offset: 0x0000DD08
		static FileStream smethod_51(string string_0, FileMode fileMode_0, FileAccess fileAccess_0, FileShare fileShare_0)
		{
			return File.Open(string_0, fileMode_0, fileAccess_0, fileShare_0);
		}

		// Token: 0x0600128B RID: 4747 RVA: 0x0000CD19 File Offset: 0x0000AF19
		static Delegate smethod_52(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Combine(delegate_0, delegate_1);
		}

		// Token: 0x0600128C RID: 4748 RVA: 0x0000CD22 File Offset: 0x0000AF22
		static Delegate smethod_53(Delegate delegate_0, Delegate delegate_1)
		{
			return Delegate.Remove(delegate_0, delegate_1);
		}

		// Token: 0x0600128D RID: 4749 RVA: 0x00012846 File Offset: 0x00010A46
		static long smethod_54(Stream stream_0)
		{
			return stream_0.Position;
		}

		// Token: 0x0600128E RID: 4750 RVA: 0x00013261 File Offset: 0x00011461
		static void smethod_55(object object_0)
		{
			Monitor.Enter(object_0);
		}

		// Token: 0x0600128F RID: 4751 RVA: 0x0000DBEF File Offset: 0x0000BDEF
		static void smethod_56(object object_0)
		{
			Monitor.Exit(object_0);
		}

		// Token: 0x06001290 RID: 4752 RVA: 0x00013E32 File Offset: 0x00012032
		static void smethod_57(TextWriter textWriter_0, string string_0, object[] object_0)
		{
			textWriter_0.WriteLine(string_0, object_0);
		}

		// Token: 0x06001291 RID: 4753 RVA: 0x000100A6 File Offset: 0x0000E2A6
		static string smethod_58(char char_0, int int_0)
		{
			return new string(char_0, int_0);
		}

		// Token: 0x06001292 RID: 4754 RVA: 0x0000D4F5 File Offset: 0x0000B6F5
		static void smethod_59(TextWriter textWriter_0, string string_0)
		{
			textWriter_0.WriteLine(string_0);
		}

		// Token: 0x06001293 RID: 4755 RVA: 0x00012BF7 File Offset: 0x00010DF7
		static bool smethod_60(Stream stream_0)
		{
			return stream_0.CanSeek;
		}

		// Token: 0x06001294 RID: 4756 RVA: 0x00012BE5 File Offset: 0x00010DE5
		static long smethod_61(Stream stream_0)
		{
			return stream_0.Length;
		}

		// Token: 0x06001295 RID: 4757 RVA: 0x00014733 File Offset: 0x00012933
		static long smethod_62(long long_0, long long_1)
		{
			return Math.Max(long_0, long_1);
		}

		// Token: 0x06001296 RID: 4758 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_63(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06001297 RID: 4759 RVA: 0x0001473C File Offset: 0x0001293C
		static ushort smethod_64(byte[] byte_0, int int_0)
		{
			return BitConverter.ToUInt16(byte_0, int_0);
		}

		// Token: 0x06001298 RID: 4760 RVA: 0x00014745 File Offset: 0x00012945
		static uint smethod_65(byte[] byte_0, int int_0)
		{
			return BitConverter.ToUInt32(byte_0, int_0);
		}

		// Token: 0x06001299 RID: 4761 RVA: 0x00013E8C File Offset: 0x0001208C
		static long smethod_66(byte[] byte_0, int int_0)
		{
			return BitConverter.ToInt64(byte_0, int_0);
		}

		// Token: 0x0600129A RID: 4762 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_67(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x0600129B RID: 4763 RVA: 0x0000DF79 File Offset: 0x0000C179
		static string smethod_68(Encoding encoding_0, byte[] byte_0, int int_0, int int_1)
		{
			return encoding_0.GetString(byte_0, int_0, int_1);
		}

		// Token: 0x0600129C RID: 4764 RVA: 0x00012837 File Offset: 0x00010A37
		static bool smethod_69(Stream stream_0)
		{
			return stream_0.CanRead;
		}

		// Token: 0x0600129D RID: 4765 RVA: 0x0000C7ED File Offset: 0x0000A9ED
		static void smethod_70(string string_0)
		{
			File.Delete(string_0);
		}

		// Token: 0x0600129E RID: 4766 RVA: 0x0001474E File Offset: 0x0001294E
		static void smethod_71(string string_0)
		{
			Console.WriteLine(string_0);
		}

		// Token: 0x0600129F RID: 4767 RVA: 0x0000C7D5 File Offset: 0x0000A9D5
		static void smethod_72(int int_0)
		{
			Thread.Sleep(int_0);
		}

		// Token: 0x060012A0 RID: 4768 RVA: 0x0000D9AC File Offset: 0x0000BBAC
		static bool smethod_73(string string_0, string string_1)
		{
			return string_0.EndsWith(string_1);
		}

		// Token: 0x060012A1 RID: 4769 RVA: 0x00012E9A File Offset: 0x0001109A
		static void smethod_74(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x060012A2 RID: 4770 RVA: 0x00013371 File Offset: 0x00011571
		static string smethod_75()
		{
			return Path.GetRandomFileName();
		}

		// Token: 0x060012A3 RID: 4771 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_76(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x060012A4 RID: 4772 RVA: 0x0000CD60 File Offset: 0x0000AF60
		static void smethod_77(string string_0, string string_1)
		{
			File.Move(string_0, string_1);
		}

		// Token: 0x060012A5 RID: 4773 RVA: 0x0000D3E3 File Offset: 0x0000B5E3
		static string smethod_78(Exception exception_0)
		{
			return exception_0.Message;
		}

		// Token: 0x060012A6 RID: 4774 RVA: 0x00012D86 File Offset: 0x00010F86
		static bool smethod_79(Stream stream_0)
		{
			return stream_0.CanWrite;
		}

		// Token: 0x060012A7 RID: 4775 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_80(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x060012A8 RID: 4776 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_81(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x060012A9 RID: 4777 RVA: 0x0000DAEE File Offset: 0x0000BCEE
		static string smethod_82(string string_0)
		{
			return string_0.ToUpper();
		}

		// Token: 0x060012AA RID: 4778 RVA: 0x0000E038 File Offset: 0x0000C238
		static int smethod_83(string string_0, string string_1)
		{
			return string_0.IndexOf(string_1);
		}

		// Token: 0x060012AB RID: 4779 RVA: 0x000109AD File Offset: 0x0000EBAD
		static Stream smethod_84(Assembly assembly_0, string string_0)
		{
			return assembly_0.GetManifestResourceStream(string_0);
		}

		// Token: 0x060012AC RID: 4780 RVA: 0x00014756 File Offset: 0x00012956
		static FileStream smethod_85(string string_0)
		{
			return File.OpenWrite(string_0);
		}

		// Token: 0x060012AD RID: 4781 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_86(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x060012AE RID: 4782 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_87(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060012AF RID: 4783 RVA: 0x0000DD49 File Offset: 0x0000BF49
		static Assembly smethod_88(Type type_0)
		{
			return type_0.Assembly;
		}

		// Token: 0x060012B0 RID: 4784 RVA: 0x0001475E File Offset: 0x0001295E
		static CSharpCodeProvider smethod_89(IDictionary<string, string> idictionary_0)
		{
			return new CSharpCodeProvider(idictionary_0);
		}

		// Token: 0x060012B1 RID: 4785 RVA: 0x00014766 File Offset: 0x00012966
		static CompilerParameters smethod_90()
		{
			return new CompilerParameters();
		}

		// Token: 0x060012B2 RID: 4786 RVA: 0x0001476D File Offset: 0x0001296D
		static StringCollection smethod_91(CompilerParameters compilerParameters_0)
		{
			return compilerParameters_0.ReferencedAssemblies;
		}

		// Token: 0x060012B3 RID: 4787 RVA: 0x0000C666 File Offset: 0x0000A866
		static string smethod_92(Assembly assembly_0)
		{
			return assembly_0.Location;
		}

		// Token: 0x060012B4 RID: 4788 RVA: 0x0000DFA5 File Offset: 0x0000C1A5
		static int smethod_93(StringCollection stringCollection_0, string string_0)
		{
			return stringCollection_0.Add(string_0);
		}

		// Token: 0x060012B5 RID: 4789 RVA: 0x00014775 File Offset: 0x00012975
		static void smethod_94(CompilerParameters compilerParameters_0, bool bool_0)
		{
			compilerParameters_0.GenerateInMemory = bool_0;
		}

		// Token: 0x060012B6 RID: 4790 RVA: 0x0001477E File Offset: 0x0001297E
		static void smethod_95(CompilerParameters compilerParameters_0, bool bool_0)
		{
			compilerParameters_0.GenerateExecutable = bool_0;
		}

		// Token: 0x060012B7 RID: 4791 RVA: 0x00014787 File Offset: 0x00012987
		static void smethod_96(CompilerParameters compilerParameters_0, bool bool_0)
		{
			compilerParameters_0.IncludeDebugInformation = bool_0;
		}

		// Token: 0x060012B8 RID: 4792 RVA: 0x00014790 File Offset: 0x00012990
		static void smethod_97(CompilerParameters compilerParameters_0, string string_0)
		{
			compilerParameters_0.CompilerOptions = string_0;
		}

		// Token: 0x060012B9 RID: 4793 RVA: 0x00013E3C File Offset: 0x0001203C
		static DirectoryInfo smethod_98(string string_0)
		{
			return Directory.CreateDirectory(string_0);
		}

		// Token: 0x060012BA RID: 4794 RVA: 0x00014799 File Offset: 0x00012999
		static string smethod_99(CompilerParameters compilerParameters_0)
		{
			return compilerParameters_0.CompilerOptions;
		}

		// Token: 0x060012BB RID: 4795 RVA: 0x000147A1 File Offset: 0x000129A1
		static void smethod_100(CompilerParameters compilerParameters_0, string string_0)
		{
			compilerParameters_0.OutputAssembly = string_0;
		}

		// Token: 0x060012BC RID: 4796 RVA: 0x000147AA File Offset: 0x000129AA
		static StringCollection smethod_101(CompilerParameters compilerParameters_0)
		{
			return compilerParameters_0.EmbeddedResources;
		}

		// Token: 0x060012BD RID: 4797 RVA: 0x000147B2 File Offset: 0x000129B2
		static string smethod_102(AssemblyName assemblyName_0)
		{
			return assemblyName_0.Name;
		}

		// Token: 0x040005E3 RID: 1507
		private TextWriter _StatusMessageTextWriter;

		// Token: 0x040005E4 RID: 1508
		private bool _CaseSensitiveRetrieval;

		// Token: 0x040005E5 RID: 1509
		private Stream _readstream;

		// Token: 0x040005E6 RID: 1510
		private Stream _writestream;

		// Token: 0x040005E7 RID: 1511
		private ushort _versionMadeBy;

		// Token: 0x040005E8 RID: 1512
		private ushort _versionNeededToExtract;

		// Token: 0x040005E9 RID: 1513
		private uint _diskNumberWithCd;

		// Token: 0x040005EA RID: 1514
		private int _maxOutputSegmentSize;

		// Token: 0x040005EB RID: 1515
		private uint _numberOfSegmentsForMostRecentSave;

		// Token: 0x040005EC RID: 1516
		private ZipErrorAction _zipErrorAction;

		// Token: 0x040005ED RID: 1517
		private bool _disposed;

		// Token: 0x040005EE RID: 1518
		private Dictionary<string, ZipEntry> _entries;

		// Token: 0x040005EF RID: 1519
		private List<ZipEntry> _zipEntriesAsList;

		// Token: 0x040005F0 RID: 1520
		private string _name;

		// Token: 0x040005F1 RID: 1521
		private string _readName;

		// Token: 0x040005F2 RID: 1522
		private string _Comment;

		// Token: 0x040005F3 RID: 1523
		internal string _Password;

		// Token: 0x040005F4 RID: 1524
		private bool _emitNtfsTimes = true;

		// Token: 0x040005F5 RID: 1525
		private bool _emitUnixTimes;

		// Token: 0x040005F6 RID: 1526
		private CompressionStrategy _Strategy;

		// Token: 0x040005F7 RID: 1527
		private CompressionMethod _compressionMethod = CompressionMethod.Deflate;

		// Token: 0x040005F8 RID: 1528
		private bool _fileAlreadyExists;

		// Token: 0x040005F9 RID: 1529
		private string _temporaryFileName;

		// Token: 0x040005FA RID: 1530
		private bool _contentsChanged;

		// Token: 0x040005FB RID: 1531
		private bool _hasBeenSaved;

		// Token: 0x040005FC RID: 1532
		private string _TempFileFolder;

		// Token: 0x040005FD RID: 1533
		private bool _ReadStreamIsOurs = true;

		// Token: 0x040005FE RID: 1534
		private object LOCK = ZipFile.smethod_44();

		// Token: 0x040005FF RID: 1535
		private bool _saveOperationCanceled;

		// Token: 0x04000600 RID: 1536
		private bool _extractOperationCanceled;

		// Token: 0x04000601 RID: 1537
		private bool _addOperationCanceled;

		// Token: 0x04000602 RID: 1538
		private EncryptionAlgorithm _Encryption;

		// Token: 0x04000603 RID: 1539
		private bool _JustSaved;

		// Token: 0x04000604 RID: 1540
		private long _locEndOfCDS = -1L;

		// Token: 0x04000605 RID: 1541
		private uint _OffsetOfCentralDirectory;

		// Token: 0x04000606 RID: 1542
		private long _OffsetOfCentralDirectory64;

		// Token: 0x04000607 RID: 1543
		private bool? _OutputUsesZip64;

		// Token: 0x04000608 RID: 1544
		internal bool _inExtractAll;

		// Token: 0x04000609 RID: 1545
		private Encoding _alternateEncoding;

		// Token: 0x0400060A RID: 1546
		private ZipOption _alternateEncodingUsage;

		// Token: 0x0400060B RID: 1547
		private static Encoding _defaultEncoding = ZipFile.smethod_37(<Module>.smethod_24<string>(1915978978U));

		// Token: 0x0400060C RID: 1548
		private int _BufferSize;

		// Token: 0x0400060D RID: 1549
		internal ParallelDeflateOutputStream ParallelDeflater;

		// Token: 0x0400060E RID: 1550
		private long _ParallelDeflateThreshold;

		// Token: 0x0400060F RID: 1551
		private int _maxBufferPairs;

		// Token: 0x04000610 RID: 1552
		internal Zip64Option _zip64;

		// Token: 0x04000611 RID: 1553
		private bool _SavingSfx;

		// Token: 0x04000612 RID: 1554
		public static readonly int BufferSizeDefault = 32768;

		// Token: 0x04000615 RID: 1557
		private long _lengthOfReadStream;

		// Token: 0x04000619 RID: 1561
		private static ZipFile.ExtractorSettings[] SettingsList = new ZipFile.ExtractorSettings[]
		{
			new ZipFile.ExtractorSettings
			{
				Flavor = SelfExtractorFlavor.WinFormsApplication,
				ReferencedAssemblies = new List<string>
				{
					<Module>.smethod_24<string>(2594798085U),
					<Module>.smethod_24<string>(4220717329U),
					<Module>.smethod_23<string>(1326177271U)
				},
				CopyThroughResources = new List<string>
				{
					<Module>.smethod_27<string>(2115437337U),
					<Module>.smethod_27<string>(2902234578U),
					<Module>.smethod_23<string>(1127755017U)
				},
				ResourcesToCompile = new List<string>
				{
					<Module>.smethod_27<string>(1736692253U),
					<Module>.smethod_27<string>(1363718709U),
					<Module>.smethod_24<string>(1306765149U),
					<Module>.smethod_26<string>(2126979198U),
					<Module>.smethod_26<string>(708091958U),
					<Module>.smethod_23<string>(4244217676U),
					<Module>.smethod_27<string>(1171460397U)
				}
			},
			new ZipFile.ExtractorSettings
			{
				Flavor = SelfExtractorFlavor.ConsoleApplication,
				ReferencedAssemblies = new List<string> { <Module>.smethod_27<string>(3001249504U) },
				CopyThroughResources = null,
				ResourcesToCompile = new List<string> { <Module>.smethod_23<string>(335813884U) }
			}
		};

		// Token: 0x02000120 RID: 288
		private class ExtractorSettings
		{
			// Token: 0x04000622 RID: 1570
			public SelfExtractorFlavor Flavor;

			// Token: 0x04000623 RID: 1571
			public List<string> ReferencedAssemblies;

			// Token: 0x04000624 RID: 1572
			public List<string> CopyThroughResources;

			// Token: 0x04000625 RID: 1573
			public List<string> ResourcesToCompile;
		}
	}
}
