﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x020000E6 RID: 230
	[ComVisible(true)]
	public enum ZipEntrySource
	{
		// Token: 0x04000499 RID: 1177
		None,
		// Token: 0x0400049A RID: 1178
		FileSystem,
		// Token: 0x0400049B RID: 1179
		Stream,
		// Token: 0x0400049C RID: 1180
		ZipFile,
		// Token: 0x0400049D RID: 1181
		WriteDelegate,
		// Token: 0x0400049E RID: 1182
		JitStream,
		// Token: 0x0400049F RID: 1183
		ZipOutputStream
	}
}
