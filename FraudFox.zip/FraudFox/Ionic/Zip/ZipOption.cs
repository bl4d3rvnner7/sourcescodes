﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x02000124 RID: 292
	[ComVisible(true)]
	public enum ZipOption
	{
		// Token: 0x04000632 RID: 1586
		Default,
		// Token: 0x04000633 RID: 1587
		Never = 0,
		// Token: 0x04000634 RID: 1588
		AsNecessary,
		// Token: 0x04000635 RID: 1589
		Always
	}
}
