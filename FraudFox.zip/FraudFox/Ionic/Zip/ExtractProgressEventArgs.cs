﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x02000116 RID: 278
	[ComVisible(true)]
	public class ExtractProgressEventArgs : ZipProgressEventArgs
	{
		// Token: 0x06001056 RID: 4182 RVA: 0x000135C0 File Offset: 0x000117C0
		internal ExtractProgressEventArgs(string archiveName, bool before, int entriesTotal, int entriesExtracted, ZipEntry entry, string extractLocation)
			: base(archiveName, before ? ZipProgressEventType.Extracting_BeforeExtractEntry : ZipProgressEventType.Extracting_AfterExtractEntry)
		{
			base.EntriesTotal = entriesTotal;
			base.CurrentEntry = entry;
			this._entriesExtracted = entriesExtracted;
			this._target = extractLocation;
		}

		// Token: 0x06001057 RID: 4183 RVA: 0x00013585 File Offset: 0x00011785
		internal ExtractProgressEventArgs(string archiveName, ZipProgressEventType flavor)
			: base(archiveName, flavor)
		{
		}

		// Token: 0x06001058 RID: 4184 RVA: 0x0001357D File Offset: 0x0001177D
		internal ExtractProgressEventArgs()
		{
		}

		// Token: 0x06001059 RID: 4185 RVA: 0x00057BA0 File Offset: 0x00055DA0
		internal static ExtractProgressEventArgs BeforeExtractEntry(string archiveName, ZipEntry entry, string extractLocation)
		{
			return new ExtractProgressEventArgs
			{
				ArchiveName = archiveName,
				EventType = ZipProgressEventType.Extracting_BeforeExtractEntry,
				CurrentEntry = entry,
				_target = extractLocation
			};
		}

		// Token: 0x0600105A RID: 4186 RVA: 0x00057BD4 File Offset: 0x00055DD4
		internal static ExtractProgressEventArgs ExtractExisting(string archiveName, ZipEntry entry, string extractLocation)
		{
			return new ExtractProgressEventArgs
			{
				ArchiveName = archiveName,
				EventType = ZipProgressEventType.Extracting_ExtractEntryWouldOverwrite,
				CurrentEntry = entry,
				_target = extractLocation
			};
		}

		// Token: 0x0600105B RID: 4187 RVA: 0x00057C08 File Offset: 0x00055E08
		internal static ExtractProgressEventArgs AfterExtractEntry(string archiveName, ZipEntry entry, string extractLocation)
		{
			return new ExtractProgressEventArgs
			{
				ArchiveName = archiveName,
				EventType = ZipProgressEventType.Extracting_AfterExtractEntry,
				CurrentEntry = entry,
				_target = extractLocation
			};
		}

		// Token: 0x0600105C RID: 4188 RVA: 0x00057C3C File Offset: 0x00055E3C
		internal static ExtractProgressEventArgs ExtractAllStarted(string archiveName, string extractLocation)
		{
			return new ExtractProgressEventArgs(archiveName, ZipProgressEventType.Extracting_BeforeExtractAll)
			{
				_target = extractLocation
			};
		}

		// Token: 0x0600105D RID: 4189 RVA: 0x00057C5C File Offset: 0x00055E5C
		internal static ExtractProgressEventArgs ExtractAllCompleted(string archiveName, string extractLocation)
		{
			return new ExtractProgressEventArgs(archiveName, ZipProgressEventType.Extracting_AfterExtractAll)
			{
				_target = extractLocation
			};
		}

		// Token: 0x0600105E RID: 4190 RVA: 0x00057C7C File Offset: 0x00055E7C
		internal static ExtractProgressEventArgs ByteUpdate(string archiveName, ZipEntry entry, long bytesWritten, long totalBytes)
		{
			return new ExtractProgressEventArgs(archiveName, ZipProgressEventType.Extracting_EntryBytesWritten)
			{
				ArchiveName = archiveName,
				CurrentEntry = entry,
				BytesTransferred = bytesWritten,
				TotalBytesToTransfer = totalBytes
			};
		}

		// Token: 0x1700025F RID: 607
		// (get) Token: 0x0600105F RID: 4191 RVA: 0x000135F1 File Offset: 0x000117F1
		public int EntriesExtracted
		{
			get
			{
				return this._entriesExtracted;
			}
		}

		// Token: 0x17000260 RID: 608
		// (get) Token: 0x06001060 RID: 4192 RVA: 0x000135F9 File Offset: 0x000117F9
		public string ExtractLocation
		{
			get
			{
				return this._target;
			}
		}

		// Token: 0x0400057A RID: 1402
		private int _entriesExtracted;

		// Token: 0x0400057B RID: 1403
		private string _target;
	}
}
