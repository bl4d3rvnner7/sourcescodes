﻿using System;
using System.IO;

namespace Ionic.Zip
{
	// Token: 0x020000EA RID: 234
	internal class ZipSegmentedStream : Stream
	{
		// Token: 0x06000E60 RID: 3680 RVA: 0x00012BFF File Offset: 0x00010DFF
		private ZipSegmentedStream()
		{
			this._exceptionPending = false;
		}

		// Token: 0x06000E61 RID: 3681 RVA: 0x00054164 File Offset: 0x00052364
		public static ZipSegmentedStream ForReading(string name, uint initialDiskNumber, uint maxDiskNumber)
		{
			ZipSegmentedStream zipSegmentedStream = new ZipSegmentedStream
			{
				rwMode = ZipSegmentedStream.RwMode.ReadOnly,
				CurrentSegment = initialDiskNumber,
				_maxDiskNumber = maxDiskNumber,
				_baseName = name
			};
			zipSegmentedStream._SetReadStream();
			return zipSegmentedStream;
		}

		// Token: 0x06000E62 RID: 3682 RVA: 0x0005419C File Offset: 0x0005239C
		public static ZipSegmentedStream ForWriting(string name, int maxSegmentSize)
		{
			ZipSegmentedStream zipSegmentedStream = new ZipSegmentedStream
			{
				rwMode = ZipSegmentedStream.RwMode.Write,
				CurrentSegment = 0U,
				_baseName = name,
				_maxSegmentSize = maxSegmentSize,
				_baseDir = ZipSegmentedStream.smethod_0(name)
			};
			if (ZipSegmentedStream.smethod_1(zipSegmentedStream._baseDir, ""))
			{
				zipSegmentedStream._baseDir = <Module>.smethod_26<string>(3551626751U);
			}
			zipSegmentedStream._SetWriteStream(0U);
			return zipSegmentedStream;
		}

		// Token: 0x06000E63 RID: 3683 RVA: 0x00054204 File Offset: 0x00052404
		public static Stream ForUpdate(string name, uint diskNumber)
		{
			string text = ZipSegmentedStream.smethod_4(<Module>.smethod_27<string>(953939369U), ZipSegmentedStream.smethod_3(ZipSegmentedStream.smethod_0(name), ZipSegmentedStream.smethod_2(name)), diskNumber + 1U);
			return ZipSegmentedStream.smethod_5(text, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
		}

		// Token: 0x17000226 RID: 550
		// (get) Token: 0x06000E64 RID: 3684 RVA: 0x00012C0E File Offset: 0x00010E0E
		// (set) Token: 0x06000E65 RID: 3685 RVA: 0x00012C16 File Offset: 0x00010E16
		public bool ContiguousWrite { get; set; }

		// Token: 0x17000227 RID: 551
		// (get) Token: 0x06000E66 RID: 3686 RVA: 0x00012C1F File Offset: 0x00010E1F
		// (set) Token: 0x06000E67 RID: 3687 RVA: 0x00012C27 File Offset: 0x00010E27
		public uint CurrentSegment
		{
			get
			{
				return this._currentDiskNumber;
			}
			private set
			{
				this._currentDiskNumber = value;
				this._currentName = null;
			}
		}

		// Token: 0x17000228 RID: 552
		// (get) Token: 0x06000E68 RID: 3688 RVA: 0x00012C37 File Offset: 0x00010E37
		public string CurrentName
		{
			get
			{
				if (this._currentName == null)
				{
					this._currentName = this._NameForSegment(this.CurrentSegment);
				}
				return this._currentName;
			}
		}

		// Token: 0x17000229 RID: 553
		// (get) Token: 0x06000E69 RID: 3689 RVA: 0x00012C59 File Offset: 0x00010E59
		public string CurrentTempName
		{
			get
			{
				return this._currentTempName;
			}
		}

		// Token: 0x06000E6A RID: 3690 RVA: 0x00012C61 File Offset: 0x00010E61
		private string _NameForSegment(uint diskNumber)
		{
			return ZipSegmentedStream.smethod_4(<Module>.smethod_23<string>(1852359505U), ZipSegmentedStream.smethod_3(ZipSegmentedStream.smethod_0(this._baseName), ZipSegmentedStream.smethod_2(this._baseName)), diskNumber + 1U);
		}

		// Token: 0x06000E6B RID: 3691 RVA: 0x00012C95 File Offset: 0x00010E95
		public uint ComputeSegment(int length)
		{
			if (ZipSegmentedStream.smethod_6(this._innerStream) + (long)length > (long)this._maxSegmentSize)
			{
				return this.CurrentSegment + 1U;
			}
			return this.CurrentSegment;
		}

		// Token: 0x06000E6C RID: 3692 RVA: 0x00054244 File Offset: 0x00052444
		public override string ToString()
		{
			return ZipSegmentedStream.smethod_8(<Module>.smethod_26<string>(3644047183U), new object[]
			{
				<Module>.smethod_25<string>(3676060030U),
				this.CurrentName,
				ZipSegmentedStream.smethod_7(this.rwMode),
				ZipSegmentedStream.smethod_6(this)
			});
		}

		// Token: 0x06000E6D RID: 3693 RVA: 0x000542A0 File Offset: 0x000524A0
		private void _SetReadStream()
		{
			if (this._innerStream != null)
			{
				ZipSegmentedStream.smethod_9(this._innerStream);
			}
			if (this.CurrentSegment + 1U == this._maxDiskNumber)
			{
				this._currentName = this._baseName;
			}
			this._innerStream = ZipSegmentedStream.smethod_10(this.CurrentName);
		}

		// Token: 0x06000E6E RID: 3694 RVA: 0x000542F0 File Offset: 0x000524F0
		public override int Read(byte[] buffer, int offset, int count)
		{
			if (this.rwMode != ZipSegmentedStream.RwMode.ReadOnly)
			{
				this._exceptionPending = true;
				throw ZipSegmentedStream.smethod_11(<Module>.smethod_27<string>(4036742647U));
			}
			int num = ZipSegmentedStream.smethod_12(this._innerStream, buffer, offset, count);
			int num2 = num;
			while (num2 != count)
			{
				if (ZipSegmentedStream.smethod_6(this._innerStream) != ZipSegmentedStream.smethod_13(this._innerStream))
				{
					this._exceptionPending = true;
					throw new ZipException(ZipSegmentedStream.smethod_14(<Module>.smethod_24<string>(761577878U), this.CurrentName));
				}
				if (this.CurrentSegment + 1U == this._maxDiskNumber)
				{
					return num;
				}
				this.CurrentSegment += 1U;
				this._SetReadStream();
				offset += num2;
				count -= num2;
				num2 = ZipSegmentedStream.smethod_12(this._innerStream, buffer, offset, count);
				num += num2;
			}
			return num;
		}

		// Token: 0x06000E6F RID: 3695 RVA: 0x000543B8 File Offset: 0x000525B8
		private void _SetWriteStream(uint increment)
		{
			if (this._innerStream != null)
			{
				ZipSegmentedStream.smethod_9(this._innerStream);
				if (ZipSegmentedStream.smethod_15(this.CurrentName))
				{
					ZipSegmentedStream.smethod_16(this.CurrentName);
				}
				ZipSegmentedStream.smethod_17(this._currentTempName, this.CurrentName);
			}
			if (increment > 0U)
			{
				this.CurrentSegment += increment;
			}
			SharedUtilities.CreateAndOpenUniqueTempFile(this._baseDir, out this._innerStream, out this._currentTempName);
			if (this.CurrentSegment == 0U)
			{
				ZipSegmentedStream.smethod_19(this._innerStream, ZipSegmentedStream.smethod_18(134695760), 0, 4);
			}
		}

		// Token: 0x06000E70 RID: 3696 RVA: 0x0005444C File Offset: 0x0005264C
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (this.rwMode != ZipSegmentedStream.RwMode.Write)
			{
				this._exceptionPending = true;
				throw ZipSegmentedStream.smethod_11(<Module>.smethod_26<string>(1338553034U));
			}
			if (this.ContiguousWrite)
			{
				if (ZipSegmentedStream.smethod_6(this._innerStream) + (long)count > (long)this._maxSegmentSize)
				{
					this._SetWriteStream(1U);
				}
			}
			else
			{
				while (ZipSegmentedStream.smethod_6(this._innerStream) + (long)count > (long)this._maxSegmentSize)
				{
					int num = this._maxSegmentSize - (int)ZipSegmentedStream.smethod_6(this._innerStream);
					ZipSegmentedStream.smethod_19(this._innerStream, buffer, offset, num);
					this._SetWriteStream(1U);
					count -= num;
					offset += num;
				}
			}
			ZipSegmentedStream.smethod_19(this._innerStream, buffer, offset, count);
		}

		// Token: 0x06000E71 RID: 3697 RVA: 0x000544FC File Offset: 0x000526FC
		public long TruncateBackward(uint diskNumber, long offset)
		{
			if (this.rwMode != ZipSegmentedStream.RwMode.Write)
			{
				this._exceptionPending = true;
				throw new ZipException(<Module>.smethod_23<string>(711483118U));
			}
			if (diskNumber == this.CurrentSegment)
			{
				return ZipSegmentedStream.smethod_20(this._innerStream, offset, SeekOrigin.Begin);
			}
			if (this._innerStream != null)
			{
				ZipSegmentedStream.smethod_9(this._innerStream);
				if (ZipSegmentedStream.smethod_15(this._currentTempName))
				{
					ZipSegmentedStream.smethod_16(this._currentTempName);
				}
			}
			for (uint num = this.CurrentSegment - 1U; num > diskNumber; num -= 1U)
			{
				string text = this._NameForSegment(num);
				if (ZipSegmentedStream.smethod_15(text))
				{
					ZipSegmentedStream.smethod_16(text);
				}
			}
			this.CurrentSegment = diskNumber;
			for (int i = 0; i < 3; i++)
			{
				try
				{
					this._currentTempName = SharedUtilities.InternalGetTempFileName();
					ZipSegmentedStream.smethod_17(this.CurrentName, this._currentTempName);
					break;
				}
				catch (IOException)
				{
					if (i == 2)
					{
						throw;
					}
				}
			}
			this._innerStream = ZipSegmentedStream.smethod_21(this._currentTempName, FileMode.Open);
			return ZipSegmentedStream.smethod_20(this._innerStream, offset, SeekOrigin.Begin);
		}

		// Token: 0x1700022A RID: 554
		// (get) Token: 0x06000E72 RID: 3698 RVA: 0x00012CBD File Offset: 0x00010EBD
		public override bool CanRead
		{
			get
			{
				return this.rwMode == ZipSegmentedStream.RwMode.ReadOnly && this._innerStream != null && ZipSegmentedStream.smethod_22(this._innerStream);
			}
		}

		// Token: 0x1700022B RID: 555
		// (get) Token: 0x06000E73 RID: 3699 RVA: 0x00012CDD File Offset: 0x00010EDD
		public override bool CanSeek
		{
			get
			{
				return this._innerStream != null && ZipSegmentedStream.smethod_23(this._innerStream);
			}
		}

		// Token: 0x1700022C RID: 556
		// (get) Token: 0x06000E74 RID: 3700 RVA: 0x00012CF4 File Offset: 0x00010EF4
		public override bool CanWrite
		{
			get
			{
				return this.rwMode == ZipSegmentedStream.RwMode.Write && this._innerStream != null && ZipSegmentedStream.smethod_24(this._innerStream);
			}
		}

		// Token: 0x06000E75 RID: 3701 RVA: 0x00012D14 File Offset: 0x00010F14
		public override void Flush()
		{
			ZipSegmentedStream.smethod_25(this._innerStream);
		}

		// Token: 0x1700022D RID: 557
		// (get) Token: 0x06000E76 RID: 3702 RVA: 0x00012D21 File Offset: 0x00010F21
		public override long Length
		{
			get
			{
				return ZipSegmentedStream.smethod_13(this._innerStream);
			}
		}

		// Token: 0x1700022E RID: 558
		// (get) Token: 0x06000E77 RID: 3703 RVA: 0x00012D2E File Offset: 0x00010F2E
		// (set) Token: 0x06000E78 RID: 3704 RVA: 0x00012D3B File Offset: 0x00010F3B
		public override long Position
		{
			get
			{
				return ZipSegmentedStream.smethod_6(this._innerStream);
			}
			set
			{
				ZipSegmentedStream.smethod_26(this._innerStream, value);
			}
		}

		// Token: 0x06000E79 RID: 3705 RVA: 0x00054604 File Offset: 0x00052804
		public override long Seek(long offset, SeekOrigin origin)
		{
			return ZipSegmentedStream.smethod_20(this._innerStream, offset, origin);
		}

		// Token: 0x06000E7A RID: 3706 RVA: 0x00012D49 File Offset: 0x00010F49
		public override void SetLength(long value)
		{
			if (this.rwMode != ZipSegmentedStream.RwMode.Write)
			{
				this._exceptionPending = true;
				throw ZipSegmentedStream.smethod_27();
			}
			ZipSegmentedStream.smethod_28(this._innerStream, value);
		}

		// Token: 0x06000E7B RID: 3707 RVA: 0x00054620 File Offset: 0x00052820
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (this._innerStream != null)
				{
					ZipSegmentedStream.smethod_9(this._innerStream);
					if (this.rwMode != ZipSegmentedStream.RwMode.Write)
					{
					}
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000E7C RID: 3708 RVA: 0x0000C66E File Offset: 0x0000A86E
		static string smethod_0(string string_0)
		{
			return Path.GetDirectoryName(string_0);
		}

		// Token: 0x06000E7D RID: 3709 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_1(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06000E7E RID: 3710 RVA: 0x0000DA84 File Offset: 0x0000BC84
		static string smethod_2(string string_0)
		{
			return Path.GetFileNameWithoutExtension(string_0);
		}

		// Token: 0x06000E7F RID: 3711 RVA: 0x0000C656 File Offset: 0x0000A856
		static string smethod_3(string string_0, string string_1)
		{
			return Path.Combine(string_0, string_1);
		}

		// Token: 0x06000E80 RID: 3712 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_4(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x06000E81 RID: 3713 RVA: 0x0000FB08 File Offset: 0x0000DD08
		static FileStream smethod_5(string string_0, FileMode fileMode_0, FileAccess fileAccess_0, FileShare fileShare_0)
		{
			return File.Open(string_0, fileMode_0, fileAccess_0, fileShare_0);
		}

		// Token: 0x06000E82 RID: 3714 RVA: 0x00012846 File Offset: 0x00010A46
		static long smethod_6(Stream stream_0)
		{
			return stream_0.Position;
		}

		// Token: 0x06000E83 RID: 3715 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_7(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06000E84 RID: 3716 RVA: 0x0000CD33 File Offset: 0x0000AF33
		static string smethod_8(string string_0, object[] object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x06000E85 RID: 3717 RVA: 0x0000FB13 File Offset: 0x0000DD13
		static void smethod_9(Stream stream_0)
		{
			stream_0.Dispose();
		}

		// Token: 0x06000E86 RID: 3718 RVA: 0x00012D6D File Offset: 0x00010F6D
		static FileStream smethod_10(string string_0)
		{
			return File.OpenRead(string_0);
		}

		// Token: 0x06000E87 RID: 3719 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_11(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x06000E88 RID: 3720 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_12(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06000E89 RID: 3721 RVA: 0x00012BE5 File Offset: 0x00010DE5
		static long smethod_13(Stream stream_0)
		{
			return stream_0.Length;
		}

		// Token: 0x06000E8A RID: 3722 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_14(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x06000E8B RID: 3723 RVA: 0x0000C681 File Offset: 0x0000A881
		static bool smethod_15(string string_0)
		{
			return File.Exists(string_0);
		}

		// Token: 0x06000E8C RID: 3724 RVA: 0x0000C7ED File Offset: 0x0000A9ED
		static void smethod_16(string string_0)
		{
			File.Delete(string_0);
		}

		// Token: 0x06000E8D RID: 3725 RVA: 0x0000CD60 File Offset: 0x0000AF60
		static void smethod_17(string string_0, string string_1)
		{
			File.Move(string_0, string_1);
		}

		// Token: 0x06000E8E RID: 3726 RVA: 0x00012D75 File Offset: 0x00010F75
		static byte[] smethod_18(int int_0)
		{
			return BitConverter.GetBytes(int_0);
		}

		// Token: 0x06000E8F RID: 3727 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_19(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x06000E90 RID: 3728 RVA: 0x00012BED File Offset: 0x00010DED
		static long smethod_20(Stream stream_0, long long_0, SeekOrigin seekOrigin_0)
		{
			return stream_0.Seek(long_0, seekOrigin_0);
		}

		// Token: 0x06000E91 RID: 3729 RVA: 0x00012D7D File Offset: 0x00010F7D
		static FileStream smethod_21(string string_0, FileMode fileMode_0)
		{
			return new FileStream(string_0, fileMode_0);
		}

		// Token: 0x06000E92 RID: 3730 RVA: 0x00012837 File Offset: 0x00010A37
		static bool smethod_22(Stream stream_0)
		{
			return stream_0.CanRead;
		}

		// Token: 0x06000E93 RID: 3731 RVA: 0x00012BF7 File Offset: 0x00010DF7
		static bool smethod_23(Stream stream_0)
		{
			return stream_0.CanSeek;
		}

		// Token: 0x06000E94 RID: 3732 RVA: 0x00012D86 File Offset: 0x00010F86
		static bool smethod_24(Stream stream_0)
		{
			return stream_0.CanWrite;
		}

		// Token: 0x06000E95 RID: 3733 RVA: 0x00012D8E File Offset: 0x00010F8E
		static void smethod_25(Stream stream_0)
		{
			stream_0.Flush();
		}

		// Token: 0x06000E96 RID: 3734 RVA: 0x00012D96 File Offset: 0x00010F96
		static void smethod_26(Stream stream_0, long long_0)
		{
			stream_0.Position = long_0;
		}

		// Token: 0x06000E97 RID: 3735 RVA: 0x0000C331 File Offset: 0x0000A531
		static InvalidOperationException smethod_27()
		{
			return new InvalidOperationException();
		}

		// Token: 0x06000E98 RID: 3736 RVA: 0x00012D9F File Offset: 0x00010F9F
		static void smethod_28(Stream stream_0, long long_0)
		{
			stream_0.SetLength(long_0);
		}

		// Token: 0x040004D1 RID: 1233
		private ZipSegmentedStream.RwMode rwMode;

		// Token: 0x040004D2 RID: 1234
		private bool _exceptionPending;

		// Token: 0x040004D3 RID: 1235
		private string _baseName;

		// Token: 0x040004D4 RID: 1236
		private string _baseDir;

		// Token: 0x040004D5 RID: 1237
		private string _currentName;

		// Token: 0x040004D6 RID: 1238
		private string _currentTempName;

		// Token: 0x040004D7 RID: 1239
		private uint _currentDiskNumber;

		// Token: 0x040004D8 RID: 1240
		private uint _maxDiskNumber;

		// Token: 0x040004D9 RID: 1241
		private int _maxSegmentSize;

		// Token: 0x040004DA RID: 1242
		private Stream _innerStream;

		// Token: 0x020000EB RID: 235
		private enum RwMode
		{
			// Token: 0x040004DD RID: 1245
			None,
			// Token: 0x040004DE RID: 1246
			ReadOnly,
			// Token: 0x040004DF RID: 1247
			Write
		}
	}
}
