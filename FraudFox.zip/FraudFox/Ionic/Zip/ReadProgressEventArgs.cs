﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x02000113 RID: 275
	[ComVisible(true)]
	public class ReadProgressEventArgs : ZipProgressEventArgs
	{
		// Token: 0x06001043 RID: 4163 RVA: 0x0001357D File Offset: 0x0001177D
		internal ReadProgressEventArgs()
		{
		}

		// Token: 0x06001044 RID: 4164 RVA: 0x00013585 File Offset: 0x00011785
		private ReadProgressEventArgs(string archiveName, ZipProgressEventType flavor)
			: base(archiveName, flavor)
		{
		}

		// Token: 0x06001045 RID: 4165 RVA: 0x00057A48 File Offset: 0x00055C48
		internal static ReadProgressEventArgs Before(string archiveName, int entriesTotal)
		{
			return new ReadProgressEventArgs(archiveName, ZipProgressEventType.Reading_BeforeReadEntry)
			{
				EntriesTotal = entriesTotal
			};
		}

		// Token: 0x06001046 RID: 4166 RVA: 0x00057A68 File Offset: 0x00055C68
		internal static ReadProgressEventArgs After(string archiveName, ZipEntry entry, int entriesTotal)
		{
			return new ReadProgressEventArgs(archiveName, ZipProgressEventType.Reading_AfterReadEntry)
			{
				EntriesTotal = entriesTotal,
				CurrentEntry = entry
			};
		}

		// Token: 0x06001047 RID: 4167 RVA: 0x00057A8C File Offset: 0x00055C8C
		internal static ReadProgressEventArgs Started(string archiveName)
		{
			return new ReadProgressEventArgs(archiveName, ZipProgressEventType.Reading_Started);
		}

		// Token: 0x06001048 RID: 4168 RVA: 0x00057AA4 File Offset: 0x00055CA4
		internal static ReadProgressEventArgs ByteUpdate(string archiveName, ZipEntry entry, long bytesXferred, long totalBytes)
		{
			return new ReadProgressEventArgs(archiveName, ZipProgressEventType.Reading_ArchiveBytesRead)
			{
				CurrentEntry = entry,
				BytesTransferred = bytesXferred,
				TotalBytesToTransfer = totalBytes
			};
		}

		// Token: 0x06001049 RID: 4169 RVA: 0x00057AD0 File Offset: 0x00055CD0
		internal static ReadProgressEventArgs Completed(string archiveName)
		{
			return new ReadProgressEventArgs(archiveName, ZipProgressEventType.Reading_Completed);
		}
	}
}
