﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x020000EC RID: 236
	[Guid("ebc25cf6-9120-4283-b972-0e5520d0000F")]
	[ClassInterface(ClassInterfaceType.AutoDispatch)]
	[ComVisible(true)]
	public class ComHelper
	{
		// Token: 0x06000E99 RID: 3737 RVA: 0x00012DA8 File Offset: 0x00010FA8
		public bool IsZipFile(string filename)
		{
			return ZipFile.IsZipFile(filename);
		}

		// Token: 0x06000E9A RID: 3738 RVA: 0x00012DB0 File Offset: 0x00010FB0
		public bool IsZipFileWithExtract(string filename)
		{
			return ZipFile.IsZipFile(filename, true);
		}

		// Token: 0x06000E9B RID: 3739 RVA: 0x00012DB9 File Offset: 0x00010FB9
		public bool CheckZip(string filename)
		{
			return ZipFile.CheckZip(filename);
		}

		// Token: 0x06000E9C RID: 3740 RVA: 0x00012DC1 File Offset: 0x00010FC1
		public bool CheckZipPassword(string filename, string password)
		{
			return ZipFile.CheckZipPassword(filename, password);
		}

		// Token: 0x06000E9D RID: 3741 RVA: 0x00012DCA File Offset: 0x00010FCA
		public void FixZipDirectory(string filename)
		{
			ZipFile.FixZipDirectory(filename);
		}

		// Token: 0x06000E9E RID: 3742 RVA: 0x00012DD2 File Offset: 0x00010FD2
		public string GetZipLibraryVersion()
		{
			return ComHelper.smethod_0(ZipFile.LibraryVersion);
		}

		// Token: 0x06000EA0 RID: 3744 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_0(object object_0)
		{
			return object_0.ToString();
		}
	}
}
