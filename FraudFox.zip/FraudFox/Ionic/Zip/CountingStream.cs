﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x02000109 RID: 265
	[ComVisible(true)]
	public class CountingStream : Stream
	{
		// Token: 0x06000FEA RID: 4074 RVA: 0x0005755C File Offset: 0x0005575C
		public CountingStream(Stream stream)
		{
			this._s = stream;
			try
			{
				this._initialOffset = CountingStream.smethod_0(this._s);
			}
			catch
			{
				this._initialOffset = 0L;
			}
		}

		// Token: 0x17000248 RID: 584
		// (get) Token: 0x06000FEB RID: 4075 RVA: 0x000133A1 File Offset: 0x000115A1
		public Stream WrappedStream
		{
			get
			{
				return this._s;
			}
		}

		// Token: 0x17000249 RID: 585
		// (get) Token: 0x06000FEC RID: 4076 RVA: 0x000133A9 File Offset: 0x000115A9
		public long BytesWritten
		{
			get
			{
				return this._bytesWritten;
			}
		}

		// Token: 0x1700024A RID: 586
		// (get) Token: 0x06000FED RID: 4077 RVA: 0x000133B1 File Offset: 0x000115B1
		public long BytesRead
		{
			get
			{
				return this._bytesRead;
			}
		}

		// Token: 0x06000FEE RID: 4078 RVA: 0x000575AC File Offset: 0x000557AC
		public void Adjust(long delta)
		{
			this._bytesWritten -= delta;
			if (this._bytesWritten >= 0L)
			{
				if (this._s is CountingStream)
				{
					((CountingStream)this._s).Adjust(delta);
				}
				return;
			}
			throw CountingStream.smethod_1();
		}

		// Token: 0x06000FEF RID: 4079 RVA: 0x00057600 File Offset: 0x00055800
		public override int Read(byte[] buffer, int offset, int count)
		{
			int num = CountingStream.smethod_2(this._s, buffer, offset, count);
			this._bytesRead += (long)num;
			return num;
		}

		// Token: 0x06000FF0 RID: 4080 RVA: 0x000133B9 File Offset: 0x000115B9
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (count == 0)
			{
				return;
			}
			CountingStream.smethod_3(this._s, buffer, offset, count);
			this._bytesWritten += (long)count;
		}

		// Token: 0x1700024B RID: 587
		// (get) Token: 0x06000FF1 RID: 4081 RVA: 0x000133DC File Offset: 0x000115DC
		public override bool CanRead
		{
			get
			{
				return CountingStream.smethod_4(this._s);
			}
		}

		// Token: 0x1700024C RID: 588
		// (get) Token: 0x06000FF2 RID: 4082 RVA: 0x000133E9 File Offset: 0x000115E9
		public override bool CanSeek
		{
			get
			{
				return CountingStream.smethod_5(this._s);
			}
		}

		// Token: 0x1700024D RID: 589
		// (get) Token: 0x06000FF3 RID: 4083 RVA: 0x000133F6 File Offset: 0x000115F6
		public override bool CanWrite
		{
			get
			{
				return CountingStream.smethod_6(this._s);
			}
		}

		// Token: 0x06000FF4 RID: 4084 RVA: 0x00013403 File Offset: 0x00011603
		public override void Flush()
		{
			CountingStream.smethod_7(this._s);
		}

		// Token: 0x1700024E RID: 590
		// (get) Token: 0x06000FF5 RID: 4085 RVA: 0x00013410 File Offset: 0x00011610
		public override long Length
		{
			get
			{
				return CountingStream.smethod_8(this._s);
			}
		}

		// Token: 0x1700024F RID: 591
		// (get) Token: 0x06000FF6 RID: 4086 RVA: 0x0001341D File Offset: 0x0001161D
		public long ComputedPosition
		{
			get
			{
				return this._initialOffset + this._bytesWritten;
			}
		}

		// Token: 0x17000250 RID: 592
		// (get) Token: 0x06000FF7 RID: 4087 RVA: 0x0001342C File Offset: 0x0001162C
		// (set) Token: 0x06000FF8 RID: 4088 RVA: 0x00013439 File Offset: 0x00011639
		public override long Position
		{
			get
			{
				return CountingStream.smethod_0(this._s);
			}
			set
			{
				CountingStream.smethod_9(this._s, value, SeekOrigin.Begin);
			}
		}

		// Token: 0x06000FF9 RID: 4089 RVA: 0x00013449 File Offset: 0x00011649
		public override long Seek(long offset, SeekOrigin origin)
		{
			return CountingStream.smethod_9(this._s, offset, origin);
		}

		// Token: 0x06000FFA RID: 4090 RVA: 0x00013458 File Offset: 0x00011658
		public override void SetLength(long value)
		{
			CountingStream.smethod_10(this._s, value);
		}

		// Token: 0x06000FFB RID: 4091 RVA: 0x00012846 File Offset: 0x00010A46
		static long smethod_0(Stream stream_0)
		{
			return stream_0.Position;
		}

		// Token: 0x06000FFC RID: 4092 RVA: 0x0000C331 File Offset: 0x0000A531
		static InvalidOperationException smethod_1()
		{
			return new InvalidOperationException();
		}

		// Token: 0x06000FFD RID: 4093 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_2(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06000FFE RID: 4094 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_3(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x06000FFF RID: 4095 RVA: 0x00012837 File Offset: 0x00010A37
		static bool smethod_4(Stream stream_0)
		{
			return stream_0.CanRead;
		}

		// Token: 0x06001000 RID: 4096 RVA: 0x00012BF7 File Offset: 0x00010DF7
		static bool smethod_5(Stream stream_0)
		{
			return stream_0.CanSeek;
		}

		// Token: 0x06001001 RID: 4097 RVA: 0x00012D86 File Offset: 0x00010F86
		static bool smethod_6(Stream stream_0)
		{
			return stream_0.CanWrite;
		}

		// Token: 0x06001002 RID: 4098 RVA: 0x00012D8E File Offset: 0x00010F8E
		static void smethod_7(Stream stream_0)
		{
			stream_0.Flush();
		}

		// Token: 0x06001003 RID: 4099 RVA: 0x00012BE5 File Offset: 0x00010DE5
		static long smethod_8(Stream stream_0)
		{
			return stream_0.Length;
		}

		// Token: 0x06001004 RID: 4100 RVA: 0x00012BED File Offset: 0x00010DED
		static long smethod_9(Stream stream_0, long long_0, SeekOrigin seekOrigin_0)
		{
			return stream_0.Seek(long_0, seekOrigin_0);
		}

		// Token: 0x06001005 RID: 4101 RVA: 0x00012D9F File Offset: 0x00010F9F
		static void smethod_10(Stream stream_0, long long_0)
		{
			stream_0.SetLength(long_0);
		}

		// Token: 0x0400054D RID: 1357
		private Stream _s;

		// Token: 0x0400054E RID: 1358
		private long _bytesWritten;

		// Token: 0x0400054F RID: 1359
		private long _bytesRead;

		// Token: 0x04000550 RID: 1360
		private long _initialOffset;
	}
}
