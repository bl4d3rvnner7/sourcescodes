﻿using System;

namespace Ionic.Zip
{
	// Token: 0x02000125 RID: 293
	internal enum AddOrUpdateAction
	{
		// Token: 0x04000637 RID: 1591
		AddOnly,
		// Token: 0x04000638 RID: 1592
		AddOrUpdate
	}
}
