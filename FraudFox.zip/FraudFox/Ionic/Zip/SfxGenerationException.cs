﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace Ionic.Zip
{
	// Token: 0x02000106 RID: 262
	[ComVisible(true)]
	[Guid("ebc25cf6-9120-4283-b972-0e5520d00008")]
	[Serializable]
	public class SfxGenerationException : ZipException
	{
		// Token: 0x06000FAC RID: 4012 RVA: 0x00013292 File Offset: 0x00011492
		public SfxGenerationException()
		{
		}

		// Token: 0x06000FAD RID: 4013 RVA: 0x0001329A File Offset: 0x0001149A
		public SfxGenerationException(string message)
			: base(message)
		{
		}

		// Token: 0x06000FAE RID: 4014 RVA: 0x000132AD File Offset: 0x000114AD
		protected SfxGenerationException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
