﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x02000123 RID: 291
	[ComVisible(true)]
	public enum Zip64Option
	{
		// Token: 0x0400062D RID: 1581
		Default,
		// Token: 0x0400062E RID: 1582
		Never = 0,
		// Token: 0x0400062F RID: 1583
		AsNecessary,
		// Token: 0x04000630 RID: 1584
		Always
	}
}
