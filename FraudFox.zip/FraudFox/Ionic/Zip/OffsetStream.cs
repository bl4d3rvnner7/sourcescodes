﻿using System;
using System.IO;

namespace Ionic.Zip
{
	// Token: 0x020000ED RID: 237
	internal class OffsetStream : Stream, IDisposable
	{
		// Token: 0x06000EA1 RID: 3745 RVA: 0x00012DDE File Offset: 0x00010FDE
		public OffsetStream(Stream s)
		{
			this._originalPosition = OffsetStream.smethod_0(s);
			this._innerStream = s;
		}

		// Token: 0x06000EA2 RID: 3746 RVA: 0x00012DF9 File Offset: 0x00010FF9
		public override int Read(byte[] buffer, int offset, int count)
		{
			return OffsetStream.smethod_1(this._innerStream, buffer, offset, count);
		}

		// Token: 0x06000EA3 RID: 3747 RVA: 0x00012E09 File Offset: 0x00011009
		public override void Write(byte[] buffer, int offset, int count)
		{
			throw OffsetStream.smethod_2();
		}

		// Token: 0x1700022F RID: 559
		// (get) Token: 0x06000EA4 RID: 3748 RVA: 0x00012E10 File Offset: 0x00011010
		public override bool CanRead
		{
			get
			{
				return OffsetStream.smethod_3(this._innerStream);
			}
		}

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x06000EA5 RID: 3749 RVA: 0x00012E1D File Offset: 0x0001101D
		public override bool CanSeek
		{
			get
			{
				return OffsetStream.smethod_4(this._innerStream);
			}
		}

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x06000EA6 RID: 3750 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanWrite
		{
			get
			{
				return false;
			}
		}

		// Token: 0x06000EA7 RID: 3751 RVA: 0x00012E2A File Offset: 0x0001102A
		public override void Flush()
		{
			OffsetStream.smethod_5(this._innerStream);
		}

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x06000EA8 RID: 3752 RVA: 0x00012E37 File Offset: 0x00011037
		public override long Length
		{
			get
			{
				return OffsetStream.smethod_6(this._innerStream);
			}
		}

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x06000EA9 RID: 3753 RVA: 0x00012E44 File Offset: 0x00011044
		// (set) Token: 0x06000EAA RID: 3754 RVA: 0x00012E58 File Offset: 0x00011058
		public override long Position
		{
			get
			{
				return OffsetStream.smethod_0(this._innerStream) - this._originalPosition;
			}
			set
			{
				OffsetStream.smethod_7(this._innerStream, this._originalPosition + value);
			}
		}

		// Token: 0x06000EAB RID: 3755 RVA: 0x00012E6D File Offset: 0x0001106D
		public override long Seek(long offset, SeekOrigin origin)
		{
			return OffsetStream.smethod_8(this._innerStream, this._originalPosition + offset, origin) - this._originalPosition;
		}

		// Token: 0x06000EAC RID: 3756 RVA: 0x00012E09 File Offset: 0x00011009
		public override void SetLength(long value)
		{
			throw OffsetStream.smethod_2();
		}

		// Token: 0x06000EAD RID: 3757 RVA: 0x00012E8A File Offset: 0x0001108A
		void IDisposable.Dispose()
		{
			OffsetStream.smethod_9(this);
		}

		// Token: 0x06000EAE RID: 3758 RVA: 0x00012E92 File Offset: 0x00011092
		public override void Close()
		{
			this.method_0();
		}

		// Token: 0x06000EAF RID: 3759 RVA: 0x00012846 File Offset: 0x00010A46
		static long smethod_0(Stream stream_0)
		{
			return stream_0.Position;
		}

		// Token: 0x06000EB0 RID: 3760 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_1(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06000EB1 RID: 3761 RVA: 0x000109B6 File Offset: 0x0000EBB6
		static NotImplementedException smethod_2()
		{
			return new NotImplementedException();
		}

		// Token: 0x06000EB2 RID: 3762 RVA: 0x00012837 File Offset: 0x00010A37
		static bool smethod_3(Stream stream_0)
		{
			return stream_0.CanRead;
		}

		// Token: 0x06000EB3 RID: 3763 RVA: 0x00012BF7 File Offset: 0x00010DF7
		static bool smethod_4(Stream stream_0)
		{
			return stream_0.CanSeek;
		}

		// Token: 0x06000EB4 RID: 3764 RVA: 0x00012D8E File Offset: 0x00010F8E
		static void smethod_5(Stream stream_0)
		{
			stream_0.Flush();
		}

		// Token: 0x06000EB5 RID: 3765 RVA: 0x00012BE5 File Offset: 0x00010DE5
		static long smethod_6(Stream stream_0)
		{
			return stream_0.Length;
		}

		// Token: 0x06000EB6 RID: 3766 RVA: 0x00012D96 File Offset: 0x00010F96
		static void smethod_7(Stream stream_0, long long_0)
		{
			stream_0.Position = long_0;
		}

		// Token: 0x06000EB7 RID: 3767 RVA: 0x00012BED File Offset: 0x00010DED
		static long smethod_8(Stream stream_0, long long_0, SeekOrigin seekOrigin_0)
		{
			return stream_0.Seek(long_0, seekOrigin_0);
		}

		// Token: 0x06000EB8 RID: 3768 RVA: 0x00012E9A File Offset: 0x0001109A
		static void smethod_9(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x06000EB9 RID: 3769 RVA: 0x00012EA2 File Offset: 0x000110A2
		void method_0()
		{
			base.Close();
		}

		// Token: 0x040004E0 RID: 1248
		private long _originalPosition;

		// Token: 0x040004E1 RID: 1249
		private Stream _innerStream;
	}
}
