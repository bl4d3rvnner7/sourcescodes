﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using Ionic.Crc;
using Ionic.Zlib;

namespace Ionic.Zip
{
	// Token: 0x020000E7 RID: 231
	[ComVisible(true)]
	public class ZipOutputStream : Stream
	{
		// Token: 0x06000DDB RID: 3547 RVA: 0x00012532 File Offset: 0x00010732
		public ZipOutputStream(Stream stream)
			: this(stream, false)
		{
		}

		// Token: 0x06000DDC RID: 3548 RVA: 0x00053894 File Offset: 0x00051A94
		public ZipOutputStream(string fileName)
		{
			this._alternateEncoding = ZipOutputStream.smethod_0(<Module>.smethod_23<string>(2015004539U));
			this._maxBufferPairs = 16;
			base..ctor();
			Stream stream = ZipOutputStream.smethod_1(fileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None);
			this._Init(stream, false, fileName);
		}

		// Token: 0x06000DDD RID: 3549 RVA: 0x0001253C File Offset: 0x0001073C
		public ZipOutputStream(Stream stream, bool leaveOpen)
		{
			this._alternateEncoding = ZipOutputStream.smethod_0(<Module>.smethod_26<string>(1542074113U));
			this._maxBufferPairs = 16;
			base..ctor();
			this._Init(stream, leaveOpen, null);
		}

		// Token: 0x06000DDE RID: 3550 RVA: 0x000538D8 File Offset: 0x00051AD8
		private void _Init(Stream stream, bool leaveOpen, string name)
		{
			this._outputStream = (ZipOutputStream.smethod_2(stream) ? stream : new CountingStream(stream));
			this.CompressionLevel = CompressionLevel.Default;
			this.CompressionMethod = CompressionMethod.Deflate;
			this._encryption = EncryptionAlgorithm.None;
			this._entriesWritten = new Dictionary<string, ZipEntry>(ZipOutputStream.smethod_3());
			this._zip64 = Zip64Option.Default;
			this._leaveUnderlyingStreamOpen = leaveOpen;
			this.Strategy = CompressionStrategy.Default;
			this._name = name ?? <Module>.smethod_24<string>(1509499167U);
			this.ParallelDeflateThreshold = -1L;
		}

		// Token: 0x06000DDF RID: 3551 RVA: 0x0001256A File Offset: 0x0001076A
		public override string ToString()
		{
			return ZipOutputStream.smethod_4(<Module>.smethod_27<string>(4012757741U), this._name, this._leaveUnderlyingStreamOpen);
		}

		// Token: 0x170001F4 RID: 500
		// (set) Token: 0x06000DE0 RID: 3552 RVA: 0x0005395C File Offset: 0x00051B5C
		public string Password
		{
			set
			{
				if (this._disposed)
				{
					this._exceptionPending = true;
					throw ZipOutputStream.smethod_5(<Module>.smethod_24<string>(113749109U));
				}
				this._password = value;
				if (this._password != null)
				{
					if (this._encryption == EncryptionAlgorithm.None)
					{
						this._encryption = EncryptionAlgorithm.PkzipWeak;
					}
					return;
				}
				this._encryption = EncryptionAlgorithm.None;
			}
		}

		// Token: 0x170001F5 RID: 501
		// (get) Token: 0x06000DE1 RID: 3553 RVA: 0x0001258C File Offset: 0x0001078C
		// (set) Token: 0x06000DE2 RID: 3554 RVA: 0x000539B0 File Offset: 0x00051BB0
		public EncryptionAlgorithm Encryption
		{
			get
			{
				return this._encryption;
			}
			set
			{
				if (this._disposed)
				{
					this._exceptionPending = true;
					throw ZipOutputStream.smethod_5(<Module>.smethod_27<string>(3966136048U));
				}
				if (value == EncryptionAlgorithm.Unsupported)
				{
					this._exceptionPending = true;
					throw ZipOutputStream.smethod_5(<Module>.smethod_27<string>(3593162504U));
				}
				this._encryption = value;
			}
		}

		// Token: 0x170001F6 RID: 502
		// (get) Token: 0x06000DE3 RID: 3555 RVA: 0x00012594 File Offset: 0x00010794
		// (set) Token: 0x06000DE4 RID: 3556 RVA: 0x0001259C File Offset: 0x0001079C
		public int CodecBufferSize { get; set; }

		// Token: 0x170001F7 RID: 503
		// (get) Token: 0x06000DE5 RID: 3557 RVA: 0x000125A5 File Offset: 0x000107A5
		// (set) Token: 0x06000DE6 RID: 3558 RVA: 0x000125AD File Offset: 0x000107AD
		public CompressionStrategy Strategy { get; set; }

		// Token: 0x170001F8 RID: 504
		// (get) Token: 0x06000DE7 RID: 3559 RVA: 0x000125B6 File Offset: 0x000107B6
		// (set) Token: 0x06000DE8 RID: 3560 RVA: 0x000125BE File Offset: 0x000107BE
		public ZipEntryTimestamp Timestamp
		{
			get
			{
				return this._timestamp;
			}
			set
			{
				if (this._disposed)
				{
					this._exceptionPending = true;
					throw ZipOutputStream.smethod_5(<Module>.smethod_25<string>(2360351543U));
				}
				this._timestamp = value;
			}
		}

		// Token: 0x170001F9 RID: 505
		// (get) Token: 0x06000DE9 RID: 3561 RVA: 0x000125E6 File Offset: 0x000107E6
		// (set) Token: 0x06000DEA RID: 3562 RVA: 0x000125EE File Offset: 0x000107EE
		public CompressionLevel CompressionLevel { get; set; }

		// Token: 0x170001FA RID: 506
		// (get) Token: 0x06000DEB RID: 3563 RVA: 0x000125F7 File Offset: 0x000107F7
		// (set) Token: 0x06000DEC RID: 3564 RVA: 0x000125FF File Offset: 0x000107FF
		public CompressionMethod CompressionMethod { get; set; }

		// Token: 0x170001FB RID: 507
		// (get) Token: 0x06000DED RID: 3565 RVA: 0x00012608 File Offset: 0x00010808
		// (set) Token: 0x06000DEE RID: 3566 RVA: 0x00012610 File Offset: 0x00010810
		public string Comment
		{
			get
			{
				return this._comment;
			}
			set
			{
				if (this._disposed)
				{
					this._exceptionPending = true;
					throw ZipOutputStream.smethod_5(<Module>.smethod_27<string>(3966136048U));
				}
				this._comment = value;
			}
		}

		// Token: 0x170001FC RID: 508
		// (get) Token: 0x06000DEF RID: 3567 RVA: 0x00012638 File Offset: 0x00010838
		// (set) Token: 0x06000DF0 RID: 3568 RVA: 0x00012640 File Offset: 0x00010840
		public Zip64Option EnableZip64
		{
			get
			{
				return this._zip64;
			}
			set
			{
				if (this._disposed)
				{
					this._exceptionPending = true;
					throw ZipOutputStream.smethod_5(<Module>.smethod_26<string>(2285035112U));
				}
				this._zip64 = value;
			}
		}

		// Token: 0x170001FD RID: 509
		// (get) Token: 0x06000DF1 RID: 3569 RVA: 0x00012668 File Offset: 0x00010868
		public bool OutputUsedZip64
		{
			get
			{
				return this._anyEntriesUsedZip64 || this._directoryNeededZip64;
			}
		}

		// Token: 0x170001FE RID: 510
		// (get) Token: 0x06000DF2 RID: 3570 RVA: 0x0001267A File Offset: 0x0001087A
		// (set) Token: 0x06000DF3 RID: 3571 RVA: 0x00012685 File Offset: 0x00010885
		public bool IgnoreCase
		{
			get
			{
				return !this._DontIgnoreCase;
			}
			set
			{
				this._DontIgnoreCase = !value;
			}
		}

		// Token: 0x170001FF RID: 511
		// (get) Token: 0x06000DF4 RID: 3572 RVA: 0x00012691 File Offset: 0x00010891
		// (set) Token: 0x06000DF5 RID: 3573 RVA: 0x000126AB File Offset: 0x000108AB
		[Obsolete("Beginning with v1.9.1.6 of DotNetZip, this property is obsolete. It will be removed in a future version of the library. Use AlternateEncoding and AlternateEncodingUsage instead.")]
		public bool UseUnicodeAsNecessary
		{
			get
			{
				return this._alternateEncoding == ZipOutputStream.smethod_6() && this.AlternateEncodingUsage == ZipOption.AsNecessary;
			}
			set
			{
				if (value)
				{
					this._alternateEncoding = ZipOutputStream.smethod_6();
					this._alternateEncodingUsage = ZipOption.AsNecessary;
					return;
				}
				this._alternateEncoding = ZipOutputStream.DefaultEncoding;
				this._alternateEncodingUsage = ZipOption.Default;
			}
		}

		// Token: 0x17000200 RID: 512
		// (get) Token: 0x06000DF6 RID: 3574 RVA: 0x000126D5 File Offset: 0x000108D5
		// (set) Token: 0x06000DF7 RID: 3575 RVA: 0x000126E8 File Offset: 0x000108E8
		[Obsolete("use AlternateEncoding and AlternateEncodingUsage instead.")]
		public Encoding ProvisionalAlternateEncoding
		{
			get
			{
				if (this._alternateEncodingUsage == ZipOption.AsNecessary)
				{
					return this._alternateEncoding;
				}
				return null;
			}
			set
			{
				this._alternateEncoding = value;
				this._alternateEncodingUsage = ZipOption.AsNecessary;
			}
		}

		// Token: 0x17000201 RID: 513
		// (get) Token: 0x06000DF8 RID: 3576 RVA: 0x000126F8 File Offset: 0x000108F8
		// (set) Token: 0x06000DF9 RID: 3577 RVA: 0x00012700 File Offset: 0x00010900
		public Encoding AlternateEncoding
		{
			get
			{
				return this._alternateEncoding;
			}
			set
			{
				this._alternateEncoding = value;
			}
		}

		// Token: 0x17000202 RID: 514
		// (get) Token: 0x06000DFA RID: 3578 RVA: 0x00012709 File Offset: 0x00010909
		// (set) Token: 0x06000DFB RID: 3579 RVA: 0x00012711 File Offset: 0x00010911
		public ZipOption AlternateEncodingUsage
		{
			get
			{
				return this._alternateEncodingUsage;
			}
			set
			{
				this._alternateEncodingUsage = value;
			}
		}

		// Token: 0x17000203 RID: 515
		// (get) Token: 0x06000DFC RID: 3580 RVA: 0x0001271A File Offset: 0x0001091A
		public static Encoding DefaultEncoding
		{
			get
			{
				return ZipOutputStream.smethod_0(<Module>.smethod_23<string>(2015004539U));
			}
		}

		// Token: 0x17000204 RID: 516
		// (get) Token: 0x06000DFE RID: 3582 RVA: 0x00012768 File Offset: 0x00010968
		// (set) Token: 0x06000DFD RID: 3581 RVA: 0x0001272B File Offset: 0x0001092B
		public long ParallelDeflateThreshold
		{
			get
			{
				return this._ParallelDeflateThreshold;
			}
			set
			{
				if (value != 0L && value != -1L && value < 65536L)
				{
					throw ZipOutputStream.smethod_7(<Module>.smethod_27<string>(2660728644U));
				}
				this._ParallelDeflateThreshold = value;
			}
		}

		// Token: 0x17000205 RID: 517
		// (get) Token: 0x06000DFF RID: 3583 RVA: 0x00012770 File Offset: 0x00010970
		// (set) Token: 0x06000E00 RID: 3584 RVA: 0x00012778 File Offset: 0x00010978
		public int ParallelDeflateMaxBufferPairs
		{
			get
			{
				return this._maxBufferPairs;
			}
			set
			{
				if (value < 4)
				{
					throw ZipOutputStream.smethod_8(<Module>.smethod_23<string>(1067409904U), <Module>.smethod_24<string>(2023696100U));
				}
				this._maxBufferPairs = value;
			}
		}

		// Token: 0x06000E01 RID: 3585 RVA: 0x0001279F File Offset: 0x0001099F
		private void InsureUniqueEntry(ZipEntry ze1)
		{
			if (this._entriesWritten.ContainsKey(ze1.FileName))
			{
				this._exceptionPending = true;
				throw ZipOutputStream.smethod_10(ZipOutputStream.smethod_9(<Module>.smethod_27<string>(3261039113U), ze1.FileName));
			}
		}

		// Token: 0x17000206 RID: 518
		// (get) Token: 0x06000E02 RID: 3586 RVA: 0x000127D6 File Offset: 0x000109D6
		internal Stream OutputStream
		{
			get
			{
				return this._outputStream;
			}
		}

		// Token: 0x17000207 RID: 519
		// (get) Token: 0x06000E03 RID: 3587 RVA: 0x000127DE File Offset: 0x000109DE
		internal string Name
		{
			get
			{
				return this._name;
			}
		}

		// Token: 0x06000E04 RID: 3588 RVA: 0x000127E6 File Offset: 0x000109E6
		public bool ContainsEntry(string name)
		{
			return this._entriesWritten.ContainsKey(SharedUtilities.NormalizePathForUseInZipFile(name));
		}

		// Token: 0x06000E05 RID: 3589 RVA: 0x00053A00 File Offset: 0x00051C00
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (this._disposed)
			{
				this._exceptionPending = true;
				throw ZipOutputStream.smethod_5(<Module>.smethod_26<string>(2285035112U));
			}
			if (buffer == null)
			{
				this._exceptionPending = true;
				throw ZipOutputStream.smethod_11(<Module>.smethod_24<string>(3757332466U));
			}
			if (this._currentEntry == null)
			{
				this._exceptionPending = true;
				throw ZipOutputStream.smethod_5(<Module>.smethod_24<string>(3350852655U));
			}
			if (this._currentEntry.IsDirectory)
			{
				this._exceptionPending = true;
				throw ZipOutputStream.smethod_5(<Module>.smethod_24<string>(1955102597U));
			}
			if (this._needToWriteEntryHeader)
			{
				this._InitiateCurrentEntry(false);
			}
			if (count != 0)
			{
				ZipOutputStream.smethod_12(this._entryOutputStream, buffer, offset, count);
			}
		}

		// Token: 0x06000E06 RID: 3590 RVA: 0x00053AAC File Offset: 0x00051CAC
		public ZipEntry PutNextEntry(string entryName)
		{
			if (ZipOutputStream.smethod_13(entryName))
			{
				throw ZipOutputStream.smethod_11(<Module>.smethod_27<string>(1163062928U));
			}
			if (!this._disposed)
			{
				this._FinishCurrentEntry();
				this._currentEntry = ZipEntry.CreateForZipOutputStream(entryName);
				this._currentEntry._container = new ZipContainer(this);
				ZipEntry currentEntry = this._currentEntry;
				currentEntry._BitField |= 8;
				this._currentEntry.SetEntryTimes(DateTime.Now, DateTime.Now, DateTime.Now);
				this._currentEntry.CompressionLevel = this.CompressionLevel;
				this._currentEntry.CompressionMethod = this.CompressionMethod;
				this._currentEntry.Password = this._password;
				this._currentEntry.Encryption = this.Encryption;
				this._currentEntry.AlternateEncoding = this.AlternateEncoding;
				this._currentEntry.AlternateEncodingUsage = this.AlternateEncodingUsage;
				if (ZipOutputStream.smethod_14(entryName, <Module>.smethod_25<string>(2443307951U)))
				{
					this._currentEntry.MarkAsDirectory();
				}
				this._currentEntry.EmitTimesInWindowsFormatWhenSaving = (this._timestamp & ZipEntryTimestamp.Windows) != ZipEntryTimestamp.None;
				this._currentEntry.EmitTimesInUnixFormatWhenSaving = (this._timestamp & ZipEntryTimestamp.Unix) != ZipEntryTimestamp.None;
				this.InsureUniqueEntry(this._currentEntry);
				this._needToWriteEntryHeader = true;
				return this._currentEntry;
			}
			this._exceptionPending = true;
			throw ZipOutputStream.smethod_5(<Module>.smethod_26<string>(2285035112U));
		}

		// Token: 0x06000E07 RID: 3591 RVA: 0x00053C14 File Offset: 0x00051E14
		private void _InitiateCurrentEntry(bool finishing)
		{
			this._entriesWritten.Add(this._currentEntry.FileName, this._currentEntry);
			this._entryCount++;
			if (this._entryCount > 65534 && this._zip64 == Zip64Option.Default)
			{
				this._exceptionPending = true;
				throw ZipOutputStream.smethod_5(<Module>.smethod_27<string>(603602612U));
			}
			this._currentEntry.WriteHeader(this._outputStream, finishing ? 99 : 0);
			this._currentEntry.StoreRelativeOffset();
			if (!this._currentEntry.IsDirectory)
			{
				this._currentEntry.WriteSecurityMetadata(this._outputStream);
				this._currentEntry.PrepOutputStream(this._outputStream, finishing ? 0L : (-1L), out this._outputCounter, out this._encryptor, out this._deflater, out this._entryOutputStream);
			}
			this._needToWriteEntryHeader = false;
		}

		// Token: 0x06000E08 RID: 3592 RVA: 0x00053CF4 File Offset: 0x00051EF4
		private void _FinishCurrentEntry()
		{
			if (this._currentEntry != null)
			{
				if (this._needToWriteEntryHeader)
				{
					this._InitiateCurrentEntry(true);
				}
				this._currentEntry.FinishOutputStream(this._outputStream, this._outputCounter, this._encryptor, this._deflater, this._entryOutputStream);
				this._currentEntry.PostProcessOutput(this._outputStream);
				if (this._currentEntry.OutputUsedZip64 != null)
				{
					this._anyEntriesUsedZip64 |= this._currentEntry.OutputUsedZip64.Value;
				}
				this._outputCounter = null;
				this._encryptor = (this._deflater = null);
				this._entryOutputStream = null;
			}
		}

		// Token: 0x06000E09 RID: 3593 RVA: 0x00053DA8 File Offset: 0x00051FA8
		protected override void Dispose(bool disposing)
		{
			if (this._disposed)
			{
				return;
			}
			if (disposing && !this._exceptionPending)
			{
				this._FinishCurrentEntry();
				this._directoryNeededZip64 = ZipOutput.WriteCentralDirectoryStructure(this._outputStream, this._entriesWritten.Values, 1U, this._zip64, this.Comment, new ZipContainer(this));
				CountingStream countingStream = this._outputStream as CountingStream;
				Stream stream;
				if (countingStream == null)
				{
					stream = this._outputStream;
				}
				else
				{
					stream = countingStream.WrappedStream;
					ZipOutputStream.smethod_15(countingStream);
				}
				if (!this._leaveUnderlyingStreamOpen)
				{
					ZipOutputStream.smethod_15(stream);
				}
				this._outputStream = null;
			}
			this._disposed = true;
		}

		// Token: 0x17000208 RID: 520
		// (get) Token: 0x06000E0A RID: 3594 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanRead
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000209 RID: 521
		// (get) Token: 0x06000E0B RID: 3595 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700020A RID: 522
		// (get) Token: 0x06000E0C RID: 3596 RVA: 0x0000ED8C File Offset: 0x0000CF8C
		public override bool CanWrite
		{
			get
			{
				return true;
			}
		}

		// Token: 0x1700020B RID: 523
		// (get) Token: 0x06000E0D RID: 3597 RVA: 0x000127F9 File Offset: 0x000109F9
		public override long Length
		{
			get
			{
				throw ZipOutputStream.smethod_16();
			}
		}

		// Token: 0x1700020C RID: 524
		// (get) Token: 0x06000E0E RID: 3598 RVA: 0x00012800 File Offset: 0x00010A00
		// (set) Token: 0x06000E0F RID: 3599 RVA: 0x000127F9 File Offset: 0x000109F9
		public override long Position
		{
			get
			{
				return ZipOutputStream.smethod_17(this._outputStream);
			}
			set
			{
				throw ZipOutputStream.smethod_16();
			}
		}

		// Token: 0x06000E10 RID: 3600 RVA: 0x0000C600 File Offset: 0x0000A800
		public override void Flush()
		{
		}

		// Token: 0x06000E11 RID: 3601 RVA: 0x0001280D File Offset: 0x00010A0D
		public override int Read(byte[] buffer, int offset, int count)
		{
			throw ZipOutputStream.smethod_18(<Module>.smethod_27<string>(1886373229U));
		}

		// Token: 0x06000E12 RID: 3602 RVA: 0x0001281E File Offset: 0x00010A1E
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw ZipOutputStream.smethod_18(<Module>.smethod_27<string>(2166103387U));
		}

		// Token: 0x06000E13 RID: 3603 RVA: 0x000127F9 File Offset: 0x000109F9
		public override void SetLength(long value)
		{
			throw ZipOutputStream.smethod_16();
		}

		// Token: 0x06000E14 RID: 3604 RVA: 0x0001282F File Offset: 0x00010A2F
		static Encoding smethod_0(string string_0)
		{
			return Encoding.GetEncoding(string_0);
		}

		// Token: 0x06000E15 RID: 3605 RVA: 0x0000FB08 File Offset: 0x0000DD08
		static FileStream smethod_1(string string_0, FileMode fileMode_0, FileAccess fileAccess_0, FileShare fileShare_0)
		{
			return File.Open(string_0, fileMode_0, fileAccess_0, fileShare_0);
		}

		// Token: 0x06000E16 RID: 3606 RVA: 0x00012837 File Offset: 0x00010A37
		static bool smethod_2(Stream stream_0)
		{
			return stream_0.CanRead;
		}

		// Token: 0x06000E17 RID: 3607 RVA: 0x0001283F File Offset: 0x00010A3F
		static StringComparer smethod_3()
		{
			return StringComparer.Ordinal;
		}

		// Token: 0x06000E18 RID: 3608 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_4(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x06000E19 RID: 3609 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_5(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x06000E1A RID: 3610 RVA: 0x0000DB1A File Offset: 0x0000BD1A
		static Encoding smethod_6()
		{
			return Encoding.UTF8;
		}

		// Token: 0x06000E1B RID: 3611 RVA: 0x0000F870 File Offset: 0x0000DA70
		static ArgumentOutOfRangeException smethod_7(string string_0)
		{
			return new ArgumentOutOfRangeException(string_0);
		}

		// Token: 0x06000E1C RID: 3612 RVA: 0x0000DECA File Offset: 0x0000C0CA
		static ArgumentOutOfRangeException smethod_8(string string_0, string string_1)
		{
			return new ArgumentOutOfRangeException(string_0, string_1);
		}

		// Token: 0x06000E1D RID: 3613 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_9(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x06000E1E RID: 3614 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_10(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x06000E1F RID: 3615 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_11(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x06000E20 RID: 3616 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_12(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x06000E21 RID: 3617 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_13(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06000E22 RID: 3618 RVA: 0x0000D9AC File Offset: 0x0000BBAC
		static bool smethod_14(string string_0, string string_1)
		{
			return string_0.EndsWith(string_1);
		}

		// Token: 0x06000E23 RID: 3619 RVA: 0x0000FB13 File Offset: 0x0000DD13
		static void smethod_15(Stream stream_0)
		{
			stream_0.Dispose();
		}

		// Token: 0x06000E24 RID: 3620 RVA: 0x0000E031 File Offset: 0x0000C231
		static NotSupportedException smethod_16()
		{
			return new NotSupportedException();
		}

		// Token: 0x06000E25 RID: 3621 RVA: 0x00012846 File Offset: 0x00010A46
		static long smethod_17(Stream stream_0)
		{
			return stream_0.Position;
		}

		// Token: 0x06000E26 RID: 3622 RVA: 0x0001284E File Offset: 0x00010A4E
		static NotSupportedException smethod_18(string string_0)
		{
			return new NotSupportedException(string_0);
		}

		// Token: 0x040004A0 RID: 1184
		private EncryptionAlgorithm _encryption;

		// Token: 0x040004A1 RID: 1185
		private ZipEntryTimestamp _timestamp;

		// Token: 0x040004A2 RID: 1186
		internal string _password;

		// Token: 0x040004A3 RID: 1187
		private string _comment;

		// Token: 0x040004A4 RID: 1188
		private Stream _outputStream;

		// Token: 0x040004A5 RID: 1189
		private ZipEntry _currentEntry;

		// Token: 0x040004A6 RID: 1190
		internal Zip64Option _zip64;

		// Token: 0x040004A7 RID: 1191
		private Dictionary<string, ZipEntry> _entriesWritten;

		// Token: 0x040004A8 RID: 1192
		private int _entryCount;

		// Token: 0x040004A9 RID: 1193
		private ZipOption _alternateEncodingUsage;

		// Token: 0x040004AA RID: 1194
		private Encoding _alternateEncoding;

		// Token: 0x040004AB RID: 1195
		private bool _leaveUnderlyingStreamOpen;

		// Token: 0x040004AC RID: 1196
		private bool _disposed;

		// Token: 0x040004AD RID: 1197
		private bool _exceptionPending;

		// Token: 0x040004AE RID: 1198
		private bool _anyEntriesUsedZip64;

		// Token: 0x040004AF RID: 1199
		private bool _directoryNeededZip64;

		// Token: 0x040004B0 RID: 1200
		private CountingStream _outputCounter;

		// Token: 0x040004B1 RID: 1201
		private Stream _encryptor;

		// Token: 0x040004B2 RID: 1202
		private Stream _deflater;

		// Token: 0x040004B3 RID: 1203
		private CrcCalculatorStream _entryOutputStream;

		// Token: 0x040004B4 RID: 1204
		private bool _needToWriteEntryHeader;

		// Token: 0x040004B5 RID: 1205
		private string _name;

		// Token: 0x040004B6 RID: 1206
		private bool _DontIgnoreCase;

		// Token: 0x040004B7 RID: 1207
		internal ParallelDeflateOutputStream ParallelDeflater;

		// Token: 0x040004B8 RID: 1208
		private long _ParallelDeflateThreshold;

		// Token: 0x040004B9 RID: 1209
		private int _maxBufferPairs;
	}
}
