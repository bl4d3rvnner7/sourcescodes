﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using Ionic.Crc;

namespace Ionic.Zip
{
	// Token: 0x0200010A RID: 266
	internal class ZipCrypto
	{
		// Token: 0x06001006 RID: 4102 RVA: 0x00013466 File Offset: 0x00011666
		private ZipCrypto()
		{
			uint[] array = new uint[3];
			ZipCrypto.smethod_0(array, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x6000132-1).FieldHandle);
			this._Keys = array;
			this.crc32 = new CRC32();
			base..ctor();
		}

		// Token: 0x06001007 RID: 4103 RVA: 0x0005762C File Offset: 0x0005582C
		public static ZipCrypto ForWrite(string password)
		{
			ZipCrypto zipCrypto = new ZipCrypto();
			if (password == null)
			{
				throw new BadPasswordException(<Module>.smethod_27<string>(3599383417U));
			}
			zipCrypto.InitCipher(password);
			return zipCrypto;
		}

		// Token: 0x06001008 RID: 4104 RVA: 0x0005765C File Offset: 0x0005585C
		public static ZipCrypto ForRead(string password, ZipEntry e)
		{
			Stream archiveStream = e._archiveStream;
			e._WeakEncryptionHeader = new byte[12];
			byte[] weakEncryptionHeader = e._WeakEncryptionHeader;
			ZipCrypto zipCrypto = new ZipCrypto();
			if (password != null)
			{
				zipCrypto.InitCipher(password);
				ZipEntry.ReadWeakEncryptionHeader(archiveStream, weakEncryptionHeader);
				byte[] array = zipCrypto.DecryptMessage(weakEncryptionHeader, weakEncryptionHeader.Length);
				if (array[11] != (byte)((e._Crc32 >> 24) & 255))
				{
					if ((e._BitField & 8) != 8)
					{
						throw new BadPasswordException(<Module>.smethod_26<string>(2296192434U));
					}
					if (array[11] != (byte)((e._TimeBlob >> 8) & 255))
					{
						throw new BadPasswordException(<Module>.smethod_24<string>(933315975U));
					}
				}
				return zipCrypto;
			}
			throw new BadPasswordException(<Module>.smethod_25<string>(4191361450U));
		}

		// Token: 0x17000251 RID: 593
		// (get) Token: 0x06001009 RID: 4105 RVA: 0x00057710 File Offset: 0x00055910
		private byte MagicByte
		{
			get
			{
				ushort num = (ushort)(this._Keys[2] & 65535U) | 2;
				return (byte)(num * (num ^ 1) >> 8);
			}
		}

		// Token: 0x0600100A RID: 4106 RVA: 0x00057738 File Offset: 0x00055938
		public byte[] DecryptMessage(byte[] cipherText, int length)
		{
			if (cipherText == null)
			{
				throw ZipCrypto.smethod_1(<Module>.smethod_25<string>(940355949U));
			}
			if (length <= cipherText.Length)
			{
				byte[] array = new byte[length];
				for (int i = 0; i < length; i++)
				{
					byte b = cipherText[i] ^ this.MagicByte;
					this.UpdateKeys(b);
					array[i] = b;
				}
				return array;
			}
			throw ZipCrypto.smethod_2(<Module>.smethod_27<string>(191646716U), <Module>.smethod_24<string>(1393654347U));
		}

		// Token: 0x0600100B RID: 4107 RVA: 0x000577A8 File Offset: 0x000559A8
		public byte[] EncryptMessage(byte[] plainText, int length)
		{
			if (plainText == null)
			{
				throw ZipCrypto.smethod_1(<Module>.smethod_24<string>(864722472U));
			}
			if (length > plainText.Length)
			{
				throw ZipCrypto.smethod_2(<Module>.smethod_23<string>(1692900796U), <Module>.smethod_27<string>(2661178017U));
			}
			byte[] array = new byte[length];
			for (int i = 0; i < length; i++)
			{
				byte b = plainText[i];
				array[i] = plainText[i] ^ this.MagicByte;
				this.UpdateKeys(b);
			}
			return array;
		}

		// Token: 0x0600100C RID: 4108 RVA: 0x00057818 File Offset: 0x00055A18
		public void InitCipher(string passphrase)
		{
			byte[] array = SharedUtilities.StringToByteArray(passphrase);
			for (int i = 0; i < ZipCrypto.smethod_3(passphrase); i++)
			{
				this.UpdateKeys(array[i]);
			}
		}

		// Token: 0x0600100D RID: 4109 RVA: 0x00057848 File Offset: 0x00055A48
		private void UpdateKeys(byte byteValue)
		{
			this._Keys[0] = (uint)this.crc32.ComputeCrc32((int)this._Keys[0], byteValue);
			this._Keys[1] = this._Keys[1] + (uint)((byte)this._Keys[0]);
			this._Keys[1] = this._Keys[1] * 134775813U + 1U;
			this._Keys[2] = (uint)this.crc32.ComputeCrc32((int)this._Keys[2], (byte)(this._Keys[1] >> 24));
		}

		// Token: 0x0600100E RID: 4110 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_0(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x0600100F RID: 4111 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_1(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x06001010 RID: 4112 RVA: 0x0000DECA File Offset: 0x0000C0CA
		static ArgumentOutOfRangeException smethod_2(string string_0, string string_1)
		{
			return new ArgumentOutOfRangeException(string_0, string_1);
		}

		// Token: 0x06001011 RID: 4113 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_3(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x04000551 RID: 1361
		private uint[] _Keys;

		// Token: 0x04000552 RID: 1362
		private CRC32 crc32;
	}
}
