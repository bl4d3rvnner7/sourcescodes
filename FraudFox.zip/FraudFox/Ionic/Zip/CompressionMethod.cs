﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x0200011E RID: 286
	[ComVisible(true)]
	public enum CompressionMethod
	{
		// Token: 0x040005E0 RID: 1504
		None,
		// Token: 0x040005E1 RID: 1505
		Deflate = 8,
		// Token: 0x040005E2 RID: 1506
		BZip2 = 12
	}
}
