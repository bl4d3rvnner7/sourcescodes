﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x020000EF RID: 239
	[ComVisible(true)]
	public enum EncryptionAlgorithm
	{
		// Token: 0x040004E8 RID: 1256
		None,
		// Token: 0x040004E9 RID: 1257
		PkzipWeak,
		// Token: 0x040004EA RID: 1258
		WinZipAes128,
		// Token: 0x040004EB RID: 1259
		WinZipAes256,
		// Token: 0x040004EC RID: 1260
		Unsupported
	}
}
