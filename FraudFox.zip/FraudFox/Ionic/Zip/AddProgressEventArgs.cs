﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x02000114 RID: 276
	[ComVisible(true)]
	public class AddProgressEventArgs : ZipProgressEventArgs
	{
		// Token: 0x0600104A RID: 4170 RVA: 0x0001357D File Offset: 0x0001177D
		internal AddProgressEventArgs()
		{
		}

		// Token: 0x0600104B RID: 4171 RVA: 0x00013585 File Offset: 0x00011785
		private AddProgressEventArgs(string archiveName, ZipProgressEventType flavor)
			: base(archiveName, flavor)
		{
		}

		// Token: 0x0600104C RID: 4172 RVA: 0x00057AE8 File Offset: 0x00055CE8
		internal static AddProgressEventArgs AfterEntry(string archiveName, ZipEntry entry, int entriesTotal)
		{
			return new AddProgressEventArgs(archiveName, ZipProgressEventType.Adding_AfterAddEntry)
			{
				EntriesTotal = entriesTotal,
				CurrentEntry = entry
			};
		}

		// Token: 0x0600104D RID: 4173 RVA: 0x00057B0C File Offset: 0x00055D0C
		internal static AddProgressEventArgs Started(string archiveName)
		{
			return new AddProgressEventArgs(archiveName, ZipProgressEventType.Adding_Started);
		}

		// Token: 0x0600104E RID: 4174 RVA: 0x00057B24 File Offset: 0x00055D24
		internal static AddProgressEventArgs Completed(string archiveName)
		{
			return new AddProgressEventArgs(archiveName, ZipProgressEventType.Adding_Completed);
		}
	}
}
