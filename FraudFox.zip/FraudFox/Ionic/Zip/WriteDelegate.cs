﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x0200010D RID: 269
	// (Invoke) Token: 0x06001024 RID: 4132
	[ComVisible(true)]
	public delegate void WriteDelegate(string entryName, Stream stream);
}
