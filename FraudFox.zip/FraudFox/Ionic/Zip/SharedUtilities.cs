﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace Ionic.Zip
{
	// Token: 0x02000108 RID: 264
	internal static class SharedUtilities
	{
		// Token: 0x06000FB3 RID: 4019 RVA: 0x00056C50 File Offset: 0x00054E50
		public static long GetFileLength(string fileName)
		{
			if (!SharedUtilities.smethod_0(fileName))
			{
				throw SharedUtilities.smethod_1(fileName);
			}
			FileStream fileStream = SharedUtilities.smethod_2(fileName, FileMode.Open, FileAccess.Read, FileShare.Read | FileShare.Write | FileShare.Delete);
			long num;
			try
			{
				num = SharedUtilities.smethod_3(fileStream);
			}
			finally
			{
				if (fileStream != null)
				{
					SharedUtilities.smethod_4(fileStream);
				}
			}
			return num;
		}

		// Token: 0x06000FB4 RID: 4020 RVA: 0x000132B7 File Offset: 0x000114B7
		[Conditional("NETCF")]
		public static void Workaround_Ladybug318918(Stream s)
		{
			SharedUtilities.smethod_5(s);
		}

		// Token: 0x06000FB5 RID: 4021 RVA: 0x00056C9C File Offset: 0x00054E9C
		private static string SimplifyFwdSlashPath(string path)
		{
			if (SharedUtilities.smethod_6(path, <Module>.smethod_24<string>(1251386134U)))
			{
				path = SharedUtilities.smethod_7(path, 2);
			}
			path = SharedUtilities.smethod_8(path, <Module>.smethod_23<string>(230848989U), <Module>.smethod_24<string>(3061240605U));
			path = SharedUtilities.smethod_9(SharedUtilities.doubleDotRegex1, path, <Module>.smethod_26<string>(1851680577U));
			return path;
		}

		// Token: 0x06000FB6 RID: 4022 RVA: 0x00056CF8 File Offset: 0x00054EF8
		public static string NormalizePathForUseInZipFile(string pathName)
		{
			if (SharedUtilities.smethod_10(pathName))
			{
				return pathName;
			}
			if (SharedUtilities.smethod_11(pathName) >= 2 && SharedUtilities.smethod_12(pathName, 1) == ':' && SharedUtilities.smethod_12(pathName, 2) == '\\')
			{
				pathName = SharedUtilities.smethod_7(pathName, 3);
			}
			pathName = SharedUtilities.smethod_13(pathName, '\\', '/');
			while (SharedUtilities.smethod_6(pathName, <Module>.smethod_23<string>(1912091352U)))
			{
				pathName = SharedUtilities.smethod_7(pathName, 1);
			}
			return SharedUtilities.SimplifyFwdSlashPath(pathName);
		}

		// Token: 0x06000FB7 RID: 4023 RVA: 0x00056D68 File Offset: 0x00054F68
		internal static byte[] StringToByteArray(string value, Encoding encoding)
		{
			return SharedUtilities.smethod_14(encoding, value);
		}

		// Token: 0x06000FB8 RID: 4024 RVA: 0x000132BF File Offset: 0x000114BF
		internal static byte[] StringToByteArray(string value)
		{
			return SharedUtilities.StringToByteArray(value, SharedUtilities.ibm437);
		}

		// Token: 0x06000FB9 RID: 4025 RVA: 0x000132CC File Offset: 0x000114CC
		internal static string Utf8StringFromBuffer(byte[] buf)
		{
			return SharedUtilities.StringFromBuffer(buf, SharedUtilities.utf8);
		}

		// Token: 0x06000FBA RID: 4026 RVA: 0x00056D80 File Offset: 0x00054F80
		internal static string StringFromBuffer(byte[] buf, Encoding encoding)
		{
			return SharedUtilities.smethod_15(encoding, buf, 0, buf.Length);
		}

		// Token: 0x06000FBB RID: 4027 RVA: 0x00056D9C File Offset: 0x00054F9C
		internal static int ReadSignature(Stream s)
		{
			int num = 0;
			try
			{
				num = SharedUtilities._ReadFourBytes(s, <Module>.smethod_26<string>(3280144211U));
			}
			catch (BadReadException)
			{
			}
			return num;
		}

		// Token: 0x06000FBC RID: 4028 RVA: 0x00056DD4 File Offset: 0x00054FD4
		internal static int ReadEntrySignature(Stream s)
		{
			int num = 0;
			try
			{
				num = SharedUtilities._ReadFourBytes(s, <Module>.smethod_24<string>(2064345756U));
				if (num == 134695760)
				{
					SharedUtilities.smethod_16(s, 12L, SeekOrigin.Current);
					num = SharedUtilities._ReadFourBytes(s, <Module>.smethod_23<string>(2281691761U));
					if (num != 67324752)
					{
						SharedUtilities.smethod_16(s, 8L, SeekOrigin.Current);
						num = SharedUtilities._ReadFourBytes(s, <Module>.smethod_26<string>(3280144211U));
						if (num != 67324752)
						{
							SharedUtilities.smethod_16(s, -24L, SeekOrigin.Current);
							num = SharedUtilities._ReadFourBytes(s, <Module>.smethod_27<string>(1857515529U));
						}
					}
				}
			}
			catch (BadReadException)
			{
			}
			return num;
		}

		// Token: 0x06000FBD RID: 4029 RVA: 0x000132D9 File Offset: 0x000114D9
		internal static int ReadInt(Stream s)
		{
			return SharedUtilities._ReadFourBytes(s, <Module>.smethod_27<string>(1391298599U));
		}

		// Token: 0x06000FBE RID: 4030 RVA: 0x00056E88 File Offset: 0x00055088
		private static int _ReadFourBytes(Stream s, string message)
		{
			byte[] array = new byte[4];
			int num = SharedUtilities.smethod_17(s, array, 0, array.Length);
			if (num != array.Length)
			{
				throw new BadReadException(SharedUtilities.smethod_19(message, SharedUtilities.smethod_18(s)));
			}
			return (((int)array[3] * 256 + (int)array[2]) * 256 + (int)array[1]) * 256 + (int)array[0];
		}

		// Token: 0x06000FBF RID: 4031 RVA: 0x00056EEC File Offset: 0x000550EC
		internal static long FindSignature(Stream stream, int SignatureToFind)
		{
			long num = SharedUtilities.smethod_18(stream);
			byte[] array = new byte[]
			{
				(byte)(SignatureToFind >> 24),
				(byte)((SignatureToFind & 16711680) >> 16),
				(byte)((SignatureToFind & 65280) >> 8),
				(byte)(SignatureToFind & 255)
			};
			byte[] array2 = new byte[65536];
			bool flag = false;
			do
			{
				int num2 = SharedUtilities.smethod_17(stream, array2, 0, array2.Length);
				if (num2 == 0)
				{
					break;
				}
				for (int i = 0; i < num2; i++)
				{
					if (array2[i] == array[3])
					{
						long num3 = SharedUtilities.smethod_18(stream);
						SharedUtilities.smethod_16(stream, (long)(i - num2), SeekOrigin.Current);
						int num4 = SharedUtilities.ReadSignature(stream);
						if (flag = num4 == SignatureToFind)
						{
							break;
						}
						SharedUtilities.smethod_16(stream, num3, SeekOrigin.Begin);
					}
				}
			}
			while (!flag);
			if (!flag)
			{
				SharedUtilities.smethod_16(stream, num, SeekOrigin.Begin);
				return -1L;
			}
			return SharedUtilities.smethod_18(stream) - num - 4L;
		}

		// Token: 0x06000FC0 RID: 4032 RVA: 0x00056FD4 File Offset: 0x000551D4
		internal static DateTime AdjustTime_Reverse(DateTime time)
		{
			if (time.Kind == DateTimeKind.Utc)
			{
				return time;
			}
			DateTime dateTime = time;
			if (DateTime.Now.IsDaylightSavingTime() && !time.IsDaylightSavingTime())
			{
				dateTime = time - new TimeSpan(1, 0, 0);
			}
			else if (!DateTime.Now.IsDaylightSavingTime() && time.IsDaylightSavingTime())
			{
				dateTime = time + new TimeSpan(1, 0, 0);
			}
			return dateTime;
		}

		// Token: 0x06000FC1 RID: 4033 RVA: 0x00057040 File Offset: 0x00055240
		internal static DateTime PackedToDateTime(int packedDateTime)
		{
			if (packedDateTime == 65535 || packedDateTime == 0)
			{
				return new DateTime(1995, 1, 1, 0, 0, 0, 0);
			}
			short num = (short)(packedDateTime & 65535);
			short num2 = (short)(((long)packedDateTime & 4294901760L) >> 16);
			int i = 1980 + (((int)num2 & 65024) >> 9);
			int j = (num2 & 480) >> 5;
			int k = (int)(num2 & 31);
			int num3 = ((int)num & 63488) >> 11;
			int l = (num & 2016) >> 5;
			int m = (int)((num & 31) * 2);
			if (m >= 60)
			{
				l++;
				m = 0;
			}
			if (l >= 60)
			{
				num3++;
				l = 0;
			}
			if (num3 >= 24)
			{
				k++;
				num3 = 0;
			}
			DateTime dateTime = DateTime.Now;
			bool flag = false;
			try
			{
				dateTime = new DateTime(i, j, k, num3, l, m, 0);
				flag = true;
			}
			catch (ArgumentOutOfRangeException)
			{
				for (;;)
				{
					IL_00F8:
					int num4 = -2000141260;
					for (;;)
					{
						switch (num4 ^ -2000141259)
						{
						case 1:
							if (i == 1980)
							{
								num4 = -2000141258;
								continue;
							}
							goto IL_0106;
						case 2:
							goto IL_00F8;
						case 3:
							if (j != 0)
							{
								num4 = -2000141259;
								continue;
							}
							goto IL_01A3;
						}
						goto Block_10;
					}
				}
				Block_10:
				if (k == 0)
				{
					goto IL_01A3;
				}
				try
				{
					IL_0106:
					while (i < 1980)
					{
						i++;
					}
					while (i > 2030)
					{
						i--;
					}
					while (j < 1)
					{
						j++;
					}
					while (j > 12)
					{
						j--;
					}
					while (k < 1)
					{
						k++;
					}
					while (k > 28)
					{
						k--;
					}
					while (l < 0)
					{
						l++;
					}
					while (l > 59)
					{
						l--;
					}
					while (m < 0)
					{
						m++;
					}
					while (m > 59)
					{
						m--;
					}
					dateTime = new DateTime(i, j, k, num3, l, m, 0);
					flag = true;
					goto IL_01DA;
				}
				catch (ArgumentOutOfRangeException)
				{
					goto IL_01DA;
				}
				try
				{
					IL_01A3:
					dateTime = new DateTime(1980, 1, 1, num3, l, m, 0);
					flag = true;
				}
				catch (ArgumentOutOfRangeException)
				{
					try
					{
						dateTime = new DateTime(1980, 1, 1, 0, 0, 0, 0);
						flag = true;
					}
					catch (ArgumentOutOfRangeException)
					{
					}
				}
				IL_01DA:;
			}
			if (!flag)
			{
				string text = string.Format(<Module>.smethod_24<string>(4150603372U), new object[] { i, j, k, num3, l, m });
				throw new ZipException(string.Format(<Module>.smethod_24<string>(315974448U), text));
			}
			dateTime = DateTime.SpecifyKind(dateTime, DateTimeKind.Local);
			return dateTime;
		}

		// Token: 0x06000FC2 RID: 4034 RVA: 0x00057320 File Offset: 0x00055520
		internal static int DateTimeToPacked(DateTime time)
		{
			time = time.ToLocalTime();
			ushort num = (ushort)((time.Day & 31) | ((time.Month << 5) & 480) | ((time.Year - 1980 << 9) & 65024));
			ushort num2 = (ushort)(((time.Second / 2) & 31) | ((time.Minute << 5) & 2016) | ((time.Hour << 11) & 63488));
			return ((int)num << 16) | (int)num2;
		}

		// Token: 0x06000FC3 RID: 4035 RVA: 0x000573A0 File Offset: 0x000555A0
		public static void CreateAndOpenUniqueTempFile(string dir, out Stream fs, out string filename)
		{
			for (int i = 0; i < 3; i++)
			{
				try
				{
					filename = SharedUtilities.smethod_20(dir, SharedUtilities.InternalGetTempFileName());
					fs = SharedUtilities.smethod_21(filename, FileMode.CreateNew);
					return;
				}
				catch (IOException)
				{
					for (;;)
					{
						IL_004F:
						int num = 1778789995;
						for (;;)
						{
							switch (num ^ 1778789992)
							{
							case 0:
								goto IL_004F;
							case 2:
								goto IL_0056;
							case 3:
								num = ((i == 2) ? 1778789994 : 1778789993);
								continue;
							}
							goto Block_4;
						}
					}
					Block_4:
					goto IL_0058;
					IL_0056:
					throw;
					IL_0058:;
				}
			}
			throw SharedUtilities.smethod_22();
		}

		// Token: 0x06000FC4 RID: 4036 RVA: 0x000132EB File Offset: 0x000114EB
		public static string InternalGetTempFileName()
		{
			return SharedUtilities.smethod_25(<Module>.smethod_26<string>(480675307U), SharedUtilities.smethod_24(SharedUtilities.smethod_23(), 0, 8), <Module>.smethod_24<string>(2402232064U));
		}

		// Token: 0x06000FC5 RID: 4037 RVA: 0x00057428 File Offset: 0x00055628
		internal static int ReadWithRetry(Stream s, byte[] buffer, int offset, int count, string FileName)
		{
			int num = 0;
			bool flag = false;
			int num2 = 0;
			do
			{
				try
				{
					num = SharedUtilities.smethod_17(s, buffer, offset, count);
					flag = true;
				}
				catch (IOException ex)
				{
					for (;;)
					{
						IL_00C9:
						int num3 = -1236467;
						for (;;)
						{
							switch (num3 ^ -1236471)
							{
							case 0:
								goto IL_00C9;
							case 1:
							{
								uint num4 = SharedUtilities._HRForException(ex);
								num3 = -1236470;
								continue;
							}
							case 2:
								num3 = -1236466;
								continue;
							case 3:
							{
								uint num4;
								if (num4 != 2147942433U)
								{
									goto Block_7;
								}
								goto IL_0085;
							}
							case 4:
							{
								SecurityPermission securityPermission = SharedUtilities.smethod_26(SecurityPermissionFlag.UnmanagedCode);
								num3 = -1236479;
								continue;
							}
							case 5:
								goto IL_0085;
							case 6:
								goto IL_0109;
							case 8:
							{
								SecurityPermission securityPermission;
								num3 = ((!SharedUtilities.smethod_27(securityPermission)) ? (-1236465) : (-1236472));
								continue;
							}
							case 9:
								goto IL_0055;
							}
							goto Block_4;
							IL_0055:
							SharedUtilities.smethod_30(250 + num2 * 550);
							num3 = -1236469;
							continue;
							IL_0085:
							num2++;
							if (num2 > 10)
							{
								goto Block_6;
							}
							goto IL_0055;
						}
					}
					Block_4:
					goto IL_010B;
					Block_6:
					throw SharedUtilities.smethod_28(SharedUtilities.smethod_29(<Module>.smethod_23<string>(37567237U), FileName, offset), ex);
					Block_7:
					throw SharedUtilities.smethod_28(SharedUtilities.smethod_19(<Module>.smethod_24<string>(546143634U), FileName), ex);
					IL_0109:
					throw;
					IL_010B:;
				}
			}
			while (!flag);
			return num;
		}

		// Token: 0x06000FC6 RID: 4038 RVA: 0x00013312 File Offset: 0x00011512
		private static uint _HRForException(Exception ex1)
		{
			return (uint)SharedUtilities.smethod_31(ex1);
		}

		// Token: 0x06000FC8 RID: 4040 RVA: 0x0000C681 File Offset: 0x0000A881
		static bool smethod_0(string string_0)
		{
			return File.Exists(string_0);
		}

		// Token: 0x06000FC9 RID: 4041 RVA: 0x00013358 File Offset: 0x00011558
		static FileNotFoundException smethod_1(string string_0)
		{
			return new FileNotFoundException(string_0);
		}

		// Token: 0x06000FCA RID: 4042 RVA: 0x0000FB08 File Offset: 0x0000DD08
		static FileStream smethod_2(string string_0, FileMode fileMode_0, FileAccess fileAccess_0, FileShare fileShare_0)
		{
			return File.Open(string_0, fileMode_0, fileAccess_0, fileShare_0);
		}

		// Token: 0x06000FCB RID: 4043 RVA: 0x00012BE5 File Offset: 0x00010DE5
		static long smethod_3(Stream stream_0)
		{
			return stream_0.Length;
		}

		// Token: 0x06000FCC RID: 4044 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_4(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06000FCD RID: 4045 RVA: 0x00012D8E File Offset: 0x00010F8E
		static void smethod_5(Stream stream_0)
		{
			stream_0.Flush();
		}

		// Token: 0x06000FCE RID: 4046 RVA: 0x0000DB96 File Offset: 0x0000BD96
		static bool smethod_6(string string_0, string string_1)
		{
			return string_0.StartsWith(string_1);
		}

		// Token: 0x06000FCF RID: 4047 RVA: 0x0000D416 File Offset: 0x0000B616
		static string smethod_7(string string_0, int int_0)
		{
			return string_0.Substring(int_0);
		}

		// Token: 0x06000FD0 RID: 4048 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_8(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x06000FD1 RID: 4049 RVA: 0x00013360 File Offset: 0x00011560
		static string smethod_9(Regex regex_0, string string_0, string string_1)
		{
			return regex_0.Replace(string_0, string_1);
		}

		// Token: 0x06000FD2 RID: 4050 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_10(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06000FD3 RID: 4051 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_11(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06000FD4 RID: 4052 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_12(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x06000FD5 RID: 4053 RVA: 0x0000CD69 File Offset: 0x0000AF69
		static string smethod_13(string string_0, char char_0, char char_1)
		{
			return string_0.Replace(char_0, char_1);
		}

		// Token: 0x06000FD6 RID: 4054 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_14(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x06000FD7 RID: 4055 RVA: 0x0000DF79 File Offset: 0x0000C179
		static string smethod_15(Encoding encoding_0, byte[] byte_0, int int_0, int int_1)
		{
			return encoding_0.GetString(byte_0, int_0, int_1);
		}

		// Token: 0x06000FD8 RID: 4056 RVA: 0x00012BED File Offset: 0x00010DED
		static long smethod_16(Stream stream_0, long long_0, SeekOrigin seekOrigin_0)
		{
			return stream_0.Seek(long_0, seekOrigin_0);
		}

		// Token: 0x06000FD9 RID: 4057 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_17(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06000FDA RID: 4058 RVA: 0x00012846 File Offset: 0x00010A46
		static long smethod_18(Stream stream_0)
		{
			return stream_0.Position;
		}

		// Token: 0x06000FDB RID: 4059 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_19(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x06000FDC RID: 4060 RVA: 0x0000C656 File Offset: 0x0000A856
		static string smethod_20(string string_0, string string_1)
		{
			return Path.Combine(string_0, string_1);
		}

		// Token: 0x06000FDD RID: 4061 RVA: 0x00012D7D File Offset: 0x00010F7D
		static FileStream smethod_21(string string_0, FileMode fileMode_0)
		{
			return new FileStream(string_0, fileMode_0);
		}

		// Token: 0x06000FDE RID: 4062 RVA: 0x0001336A File Offset: 0x0001156A
		static IOException smethod_22()
		{
			return new IOException();
		}

		// Token: 0x06000FDF RID: 4063 RVA: 0x00013371 File Offset: 0x00011571
		static string smethod_23()
		{
			return Path.GetRandomFileName();
		}

		// Token: 0x06000FE0 RID: 4064 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_24(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x06000FE1 RID: 4065 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_25(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x06000FE2 RID: 4066 RVA: 0x00013378 File Offset: 0x00011578
		static SecurityPermission smethod_26(SecurityPermissionFlag securityPermissionFlag_0)
		{
			return new SecurityPermission(securityPermissionFlag_0);
		}

		// Token: 0x06000FE3 RID: 4067 RVA: 0x00013380 File Offset: 0x00011580
		static bool smethod_27(SecurityPermission securityPermission_0)
		{
			return securityPermission_0.IsUnrestricted();
		}

		// Token: 0x06000FE4 RID: 4068 RVA: 0x00013388 File Offset: 0x00011588
		static IOException smethod_28(string string_0, Exception exception_0)
		{
			return new IOException(string_0, exception_0);
		}

		// Token: 0x06000FE5 RID: 4069 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_29(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x06000FE6 RID: 4070 RVA: 0x0000C7D5 File Offset: 0x0000A9D5
		static void smethod_30(int int_0)
		{
			Thread.Sleep(int_0);
		}

		// Token: 0x06000FE7 RID: 4071 RVA: 0x00013391 File Offset: 0x00011591
		static int smethod_31(Exception exception_0)
		{
			return Marshal.GetHRForException(exception_0);
		}

		// Token: 0x06000FE8 RID: 4072 RVA: 0x00013399 File Offset: 0x00011599
		static Regex smethod_32(string string_0)
		{
			return new Regex(string_0);
		}

		// Token: 0x06000FE9 RID: 4073 RVA: 0x0001282F File Offset: 0x00010A2F
		static Encoding smethod_33(string string_0)
		{
			return Encoding.GetEncoding(string_0);
		}

		// Token: 0x0400054A RID: 1354
		private static Regex doubleDotRegex1 = SharedUtilities.smethod_32(<Module>.smethod_23<string>(1282795253U));

		// Token: 0x0400054B RID: 1355
		private static Encoding ibm437 = SharedUtilities.smethod_33(<Module>.smethod_23<string>(2015004539U));

		// Token: 0x0400054C RID: 1356
		private static Encoding utf8 = SharedUtilities.smethod_33(<Module>.smethod_23<string>(915045874U));
	}
}
