﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x02000115 RID: 277
	[ComVisible(true)]
	public class SaveProgressEventArgs : ZipProgressEventArgs
	{
		// Token: 0x0600104F RID: 4175 RVA: 0x0001358F File Offset: 0x0001178F
		internal SaveProgressEventArgs(string archiveName, bool before, int entriesTotal, int entriesSaved, ZipEntry entry)
			: base(archiveName, before ? ZipProgressEventType.Saving_BeforeWriteEntry : ZipProgressEventType.Saving_AfterWriteEntry)
		{
			base.EntriesTotal = entriesTotal;
			base.CurrentEntry = entry;
			this._entriesSaved = entriesSaved;
		}

		// Token: 0x06001050 RID: 4176 RVA: 0x0001357D File Offset: 0x0001177D
		internal SaveProgressEventArgs()
		{
		}

		// Token: 0x06001051 RID: 4177 RVA: 0x00013585 File Offset: 0x00011785
		internal SaveProgressEventArgs(string archiveName, ZipProgressEventType flavor)
			: base(archiveName, flavor)
		{
		}

		// Token: 0x06001052 RID: 4178 RVA: 0x00057B3C File Offset: 0x00055D3C
		internal static SaveProgressEventArgs ByteUpdate(string archiveName, ZipEntry entry, long bytesXferred, long totalBytes)
		{
			return new SaveProgressEventArgs(archiveName, ZipProgressEventType.Saving_EntryBytesRead)
			{
				ArchiveName = archiveName,
				CurrentEntry = entry,
				BytesTransferred = bytesXferred,
				TotalBytesToTransfer = totalBytes
			};
		}

		// Token: 0x06001053 RID: 4179 RVA: 0x00057B70 File Offset: 0x00055D70
		internal static SaveProgressEventArgs Started(string archiveName)
		{
			return new SaveProgressEventArgs(archiveName, ZipProgressEventType.Saving_Started);
		}

		// Token: 0x06001054 RID: 4180 RVA: 0x00057B88 File Offset: 0x00055D88
		internal static SaveProgressEventArgs Completed(string archiveName)
		{
			return new SaveProgressEventArgs(archiveName, ZipProgressEventType.Saving_Completed);
		}

		// Token: 0x1700025E RID: 606
		// (get) Token: 0x06001055 RID: 4181 RVA: 0x000135B8 File Offset: 0x000117B8
		public int EntriesSaved
		{
			get
			{
				return this._entriesSaved;
			}
		}

		// Token: 0x04000579 RID: 1401
		private int _entriesSaved;
	}
}
