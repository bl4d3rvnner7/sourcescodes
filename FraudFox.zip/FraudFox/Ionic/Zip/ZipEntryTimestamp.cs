﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x0200011D RID: 285
	[Flags]
	[ComVisible(true)]
	public enum ZipEntryTimestamp
	{
		// Token: 0x040005DA RID: 1498
		None = 0,
		// Token: 0x040005DB RID: 1499
		DOS = 1,
		// Token: 0x040005DC RID: 1500
		Windows = 2,
		// Token: 0x040005DD RID: 1501
		Unix = 4,
		// Token: 0x040005DE RID: 1502
		InfoZip1 = 8
	}
}
