﻿using System;
using System.IO;

namespace Ionic.Zip
{
	// Token: 0x0200010C RID: 268
	internal class ZipCipherStream : Stream
	{
		// Token: 0x06001012 RID: 4114 RVA: 0x00013490 File Offset: 0x00011690
		public ZipCipherStream(Stream s, ZipCrypto cipher, CryptoMode mode)
		{
			if (s == null)
			{
				throw ZipCipherStream.smethod_0(<Module>.smethod_27<string>(1759848722U));
			}
			this._cipher = cipher;
			this._s = s;
			this._mode = mode;
		}

		// Token: 0x06001013 RID: 4115 RVA: 0x000578CC File Offset: 0x00055ACC
		public override int Read(byte[] buffer, int offset, int count)
		{
			if (this._mode == CryptoMode.Encrypt)
			{
				throw ZipCipherStream.smethod_1(<Module>.smethod_27<string>(1309148920U));
			}
			if (buffer == null)
			{
				throw ZipCipherStream.smethod_0(<Module>.smethod_27<string>(2608335411U));
			}
			byte[] array = new byte[count];
			int num = ZipCipherStream.smethod_2(this._s, array, 0, count);
			byte[] array2 = this._cipher.DecryptMessage(array, num);
			for (int i = 0; i < num; i++)
			{
				buffer[offset + i] = array2[i];
			}
			return num;
		}

		// Token: 0x06001014 RID: 4116 RVA: 0x00057940 File Offset: 0x00055B40
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (this._mode == CryptoMode.Decrypt)
			{
				throw ZipCipherStream.smethod_1(<Module>.smethod_23<string>(2522882767U));
			}
			byte[] array;
			for (;;)
			{
				IL_00D2:
				int num = ((buffer != null) ? (-2042823327) : (-2042823328));
				for (;;)
				{
					byte[] array2;
					int num2;
					switch (num ^ -2042823328)
					{
					case 0:
						goto IL_00DA;
					case 1:
						if (count == 0)
						{
							return;
						}
						goto IL_0064;
					case 2:
						goto IL_002E;
					case 3:
						array = this._cipher.EncryptMessage(array2, count);
						num = -2042823317;
						continue;
					case 4:
						goto IL_005B;
					case 5:
						num = -2042823318;
						continue;
					case 6:
						goto IL_00D2;
					case 7:
						goto IL_0064;
					case 8:
						if (offset != 0)
						{
							array2 = new byte[count];
							num2 = 0;
							num = -2042823323;
							continue;
						}
						goto IL_005B;
					case 9:
						num = -2042823322;
						continue;
					case 10:
						if (num2 >= count)
						{
							num = -2042823325;
							continue;
						}
						goto IL_002E;
					}
					goto Block_5;
					IL_002E:
					array2[num2] = buffer[offset + num2];
					num2++;
					num = -2042823318;
					continue;
					IL_005B:
					array2 = buffer;
					num = -2042823325;
					continue;
					IL_0064:
					array2 = null;
					num = -2042823320;
				}
			}
			return;
			Block_5:
			goto IL_00EB;
			IL_00DA:
			throw ZipCipherStream.smethod_0(<Module>.smethod_25<string>(2270679300U));
			IL_00EB:
			ZipCipherStream.smethod_3(this._s, array, 0, array.Length);
		}

		// Token: 0x17000252 RID: 594
		// (get) Token: 0x06001015 RID: 4117 RVA: 0x000134C0 File Offset: 0x000116C0
		public override bool CanRead
		{
			get
			{
				return this._mode == CryptoMode.Decrypt;
			}
		}

		// Token: 0x17000253 RID: 595
		// (get) Token: 0x06001016 RID: 4118 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000254 RID: 596
		// (get) Token: 0x06001017 RID: 4119 RVA: 0x000134CB File Offset: 0x000116CB
		public override bool CanWrite
		{
			get
			{
				return this._mode == CryptoMode.Encrypt;
			}
		}

		// Token: 0x06001018 RID: 4120 RVA: 0x0000C600 File Offset: 0x0000A800
		public override void Flush()
		{
		}

		// Token: 0x17000255 RID: 597
		// (get) Token: 0x06001019 RID: 4121 RVA: 0x000134D6 File Offset: 0x000116D6
		public override long Length
		{
			get
			{
				throw ZipCipherStream.smethod_4();
			}
		}

		// Token: 0x17000256 RID: 598
		// (get) Token: 0x0600101A RID: 4122 RVA: 0x000134D6 File Offset: 0x000116D6
		// (set) Token: 0x0600101B RID: 4123 RVA: 0x000134D6 File Offset: 0x000116D6
		public override long Position
		{
			get
			{
				throw ZipCipherStream.smethod_4();
			}
			set
			{
				throw ZipCipherStream.smethod_4();
			}
		}

		// Token: 0x0600101C RID: 4124 RVA: 0x000134D6 File Offset: 0x000116D6
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw ZipCipherStream.smethod_4();
		}

		// Token: 0x0600101D RID: 4125 RVA: 0x000134D6 File Offset: 0x000116D6
		public override void SetLength(long value)
		{
			throw ZipCipherStream.smethod_4();
		}

		// Token: 0x0600101E RID: 4126 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_0(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x0600101F RID: 4127 RVA: 0x0001284E File Offset: 0x00010A4E
		static NotSupportedException smethod_1(string string_0)
		{
			return new NotSupportedException(string_0);
		}

		// Token: 0x06001020 RID: 4128 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_2(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06001021 RID: 4129 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_3(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x06001022 RID: 4130 RVA: 0x0000E031 File Offset: 0x0000C231
		static NotSupportedException smethod_4()
		{
			return new NotSupportedException();
		}

		// Token: 0x04000556 RID: 1366
		private ZipCrypto _cipher;

		// Token: 0x04000557 RID: 1367
		private Stream _s;

		// Token: 0x04000558 RID: 1368
		private CryptoMode _mode;
	}
}
