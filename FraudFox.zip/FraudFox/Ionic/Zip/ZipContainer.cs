﻿using System;
using System.IO;
using System.Text;
using Ionic.Zlib;

namespace Ionic.Zip
{
	// Token: 0x020000E8 RID: 232
	internal class ZipContainer
	{
		// Token: 0x06000E27 RID: 3623 RVA: 0x00012856 File Offset: 0x00010A56
		public ZipContainer(object o)
		{
			this._zf = o as ZipFile;
			this._zos = o as ZipOutputStream;
			this._zis = o as ZipInputStream;
		}

		// Token: 0x1700020D RID: 525
		// (get) Token: 0x06000E28 RID: 3624 RVA: 0x00012882 File Offset: 0x00010A82
		public ZipFile ZipFile
		{
			get
			{
				return this._zf;
			}
		}

		// Token: 0x1700020E RID: 526
		// (get) Token: 0x06000E29 RID: 3625 RVA: 0x0001288A File Offset: 0x00010A8A
		public ZipOutputStream ZipOutputStream
		{
			get
			{
				return this._zos;
			}
		}

		// Token: 0x1700020F RID: 527
		// (get) Token: 0x06000E2A RID: 3626 RVA: 0x00012892 File Offset: 0x00010A92
		public string Name
		{
			get
			{
				if (this._zf != null)
				{
					return this._zf.Name;
				}
				if (this._zis != null)
				{
					throw ZipContainer.smethod_0();
				}
				return this._zos.Name;
			}
		}

		// Token: 0x17000210 RID: 528
		// (get) Token: 0x06000E2B RID: 3627 RVA: 0x000128C1 File Offset: 0x00010AC1
		public string Password
		{
			get
			{
				if (this._zf != null)
				{
					return this._zf._Password;
				}
				if (this._zis != null)
				{
					return this._zis._Password;
				}
				return this._zos._password;
			}
		}

		// Token: 0x17000211 RID: 529
		// (get) Token: 0x06000E2C RID: 3628 RVA: 0x000128F6 File Offset: 0x00010AF6
		public Zip64Option Zip64
		{
			get
			{
				if (this._zf != null)
				{
					return this._zf._zip64;
				}
				if (this._zis != null)
				{
					throw ZipContainer.smethod_0();
				}
				return this._zos._zip64;
			}
		}

		// Token: 0x17000212 RID: 530
		// (get) Token: 0x06000E2D RID: 3629 RVA: 0x00012925 File Offset: 0x00010B25
		public int BufferSize
		{
			get
			{
				if (this._zf != null)
				{
					return this._zf.BufferSize;
				}
				if (this._zis != null)
				{
					throw ZipContainer.smethod_0();
				}
				return 0;
			}
		}

		// Token: 0x17000213 RID: 531
		// (get) Token: 0x06000E2E RID: 3630 RVA: 0x00053E44 File Offset: 0x00052044
		// (set) Token: 0x06000E2F RID: 3631 RVA: 0x0001294A File Offset: 0x00010B4A
		public ParallelDeflateOutputStream ParallelDeflater
		{
			get
			{
				if (this._zf != null)
				{
					goto IL_003C;
				}
				if (this._zis == null)
				{
					return this._zos.ParallelDeflater;
				}
				int num = 336711027;
				IL_0023:
				switch (num ^ 336711026)
				{
				case 0:
					IL_003C:
					num = 336711024;
					goto IL_0023;
				case 2:
					return this._zf.ParallelDeflater;
				}
				return null;
			}
			set
			{
				if (this._zf != null)
				{
					this._zf.ParallelDeflater = value;
					return;
				}
				if (this._zos != null)
				{
					this._zos.ParallelDeflater = value;
				}
			}
		}

		// Token: 0x17000214 RID: 532
		// (get) Token: 0x06000E30 RID: 3632 RVA: 0x00012975 File Offset: 0x00010B75
		public long ParallelDeflateThreshold
		{
			get
			{
				if (this._zf != null)
				{
					return this._zf.ParallelDeflateThreshold;
				}
				return this._zos.ParallelDeflateThreshold;
			}
		}

		// Token: 0x17000215 RID: 533
		// (get) Token: 0x06000E31 RID: 3633 RVA: 0x00012996 File Offset: 0x00010B96
		public int ParallelDeflateMaxBufferPairs
		{
			get
			{
				if (this._zf != null)
				{
					return this._zf.ParallelDeflateMaxBufferPairs;
				}
				return this._zos.ParallelDeflateMaxBufferPairs;
			}
		}

		// Token: 0x17000216 RID: 534
		// (get) Token: 0x06000E32 RID: 3634 RVA: 0x000129B7 File Offset: 0x00010BB7
		public int CodecBufferSize
		{
			get
			{
				if (this._zf != null)
				{
					return this._zf.CodecBufferSize;
				}
				if (this._zis != null)
				{
					return this._zis.CodecBufferSize;
				}
				return this._zos.CodecBufferSize;
			}
		}

		// Token: 0x17000217 RID: 535
		// (get) Token: 0x06000E33 RID: 3635 RVA: 0x000129EC File Offset: 0x00010BEC
		public CompressionStrategy Strategy
		{
			get
			{
				if (this._zf != null)
				{
					return this._zf.Strategy;
				}
				return this._zos.Strategy;
			}
		}

		// Token: 0x17000218 RID: 536
		// (get) Token: 0x06000E34 RID: 3636 RVA: 0x00012A0D File Offset: 0x00010C0D
		public Zip64Option UseZip64WhenSaving
		{
			get
			{
				if (this._zf != null)
				{
					return this._zf.UseZip64WhenSaving;
				}
				return this._zos.EnableZip64;
			}
		}

		// Token: 0x17000219 RID: 537
		// (get) Token: 0x06000E35 RID: 3637 RVA: 0x00012A2E File Offset: 0x00010C2E
		public Encoding AlternateEncoding
		{
			get
			{
				if (this._zf != null)
				{
					return this._zf.AlternateEncoding;
				}
				if (this._zos != null)
				{
					return this._zos.AlternateEncoding;
				}
				return null;
			}
		}

		// Token: 0x1700021A RID: 538
		// (get) Token: 0x06000E36 RID: 3638 RVA: 0x00012A59 File Offset: 0x00010C59
		public Encoding DefaultEncoding
		{
			get
			{
				if (this._zf != null)
				{
					return ZipFile.DefaultEncoding;
				}
				if (this._zos != null)
				{
					return ZipOutputStream.DefaultEncoding;
				}
				return null;
			}
		}

		// Token: 0x1700021B RID: 539
		// (get) Token: 0x06000E37 RID: 3639 RVA: 0x00053EA4 File Offset: 0x000520A4
		public ZipOption AlternateEncodingUsage
		{
			get
			{
				if (this._zf != null)
				{
					goto IL_0032;
				}
				if (this._zos == null)
				{
					return ZipOption.Default;
				}
				int num = 1551608596;
				IL_0019:
				switch (num ^ 1551608596)
				{
				case 1:
					return this._zf.AlternateEncodingUsage;
				case 2:
					IL_0032:
					num = 1551608597;
					goto IL_0019;
				}
				return this._zos.AlternateEncodingUsage;
			}
		}

		// Token: 0x1700021C RID: 540
		// (get) Token: 0x06000E38 RID: 3640 RVA: 0x00012A78 File Offset: 0x00010C78
		public Stream ReadStream
		{
			get
			{
				if (this._zf != null)
				{
					return this._zf.ReadStream;
				}
				return this._zis.ReadStream;
			}
		}

		// Token: 0x06000E39 RID: 3641 RVA: 0x0000E031 File Offset: 0x0000C231
		static NotSupportedException smethod_0()
		{
			return new NotSupportedException();
		}

		// Token: 0x040004BE RID: 1214
		private ZipFile _zf;

		// Token: 0x040004BF RID: 1215
		private ZipOutputStream _zos;

		// Token: 0x040004C0 RID: 1216
		private ZipInputStream _zis;
	}
}
