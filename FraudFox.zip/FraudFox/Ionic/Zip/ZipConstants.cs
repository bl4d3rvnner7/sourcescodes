﻿using System;

namespace Ionic.Zip
{
	// Token: 0x02000101 RID: 257
	internal static class ZipConstants
	{
		// Token: 0x0400053D RID: 1341
		public const uint PackedToRemovableMedia = 808471376U;

		// Token: 0x0400053E RID: 1342
		public const uint Zip64EndOfCentralDirectoryRecordSignature = 101075792U;

		// Token: 0x0400053F RID: 1343
		public const uint Zip64EndOfCentralDirectoryLocatorSignature = 117853008U;

		// Token: 0x04000540 RID: 1344
		public const uint EndOfCentralDirectorySignature = 101010256U;

		// Token: 0x04000541 RID: 1345
		public const int ZipEntrySignature = 67324752;

		// Token: 0x04000542 RID: 1346
		public const int ZipEntryDataDescriptorSignature = 134695760;

		// Token: 0x04000543 RID: 1347
		public const int SplitArchiveSignature = 134695760;

		// Token: 0x04000544 RID: 1348
		public const int ZipDirEntrySignature = 33639248;

		// Token: 0x04000545 RID: 1349
		public const int AesKeySize = 192;

		// Token: 0x04000546 RID: 1350
		public const int AesBlockSize = 128;

		// Token: 0x04000547 RID: 1351
		public const ushort AesAlgId128 = 26126;

		// Token: 0x04000548 RID: 1352
		public const ushort AesAlgId192 = 26127;

		// Token: 0x04000549 RID: 1353
		public const ushort AesAlgId256 = 26128;
	}
}
