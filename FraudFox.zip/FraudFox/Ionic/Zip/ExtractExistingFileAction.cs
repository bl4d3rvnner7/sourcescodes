﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x020000F0 RID: 240
	[ComVisible(true)]
	public enum ExtractExistingFileAction
	{
		// Token: 0x040004EE RID: 1262
		Throw,
		// Token: 0x040004EF RID: 1263
		OverwriteSilently,
		// Token: 0x040004F0 RID: 1264
		DoNotOverwrite,
		// Token: 0x040004F1 RID: 1265
		InvokeExtractProgressEvent
	}
}
