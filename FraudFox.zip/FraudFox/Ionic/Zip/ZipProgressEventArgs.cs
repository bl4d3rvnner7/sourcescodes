﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x02000112 RID: 274
	[ComVisible(true)]
	public class ZipProgressEventArgs : EventArgs
	{
		// Token: 0x06001033 RID: 4147 RVA: 0x000134DD File Offset: 0x000116DD
		internal ZipProgressEventArgs()
		{
		}

		// Token: 0x06001034 RID: 4148 RVA: 0x000134E5 File Offset: 0x000116E5
		internal ZipProgressEventArgs(string archiveName, ZipProgressEventType flavor)
		{
			this._archiveName = archiveName;
			this._flavor = flavor;
		}

		// Token: 0x17000257 RID: 599
		// (get) Token: 0x06001035 RID: 4149 RVA: 0x000134FB File Offset: 0x000116FB
		// (set) Token: 0x06001036 RID: 4150 RVA: 0x00013503 File Offset: 0x00011703
		public int EntriesTotal
		{
			get
			{
				return this._entriesTotal;
			}
			set
			{
				this._entriesTotal = value;
			}
		}

		// Token: 0x17000258 RID: 600
		// (get) Token: 0x06001037 RID: 4151 RVA: 0x0001350C File Offset: 0x0001170C
		// (set) Token: 0x06001038 RID: 4152 RVA: 0x00013514 File Offset: 0x00011714
		public ZipEntry CurrentEntry
		{
			get
			{
				return this._latestEntry;
			}
			set
			{
				this._latestEntry = value;
			}
		}

		// Token: 0x17000259 RID: 601
		// (get) Token: 0x06001039 RID: 4153 RVA: 0x0001351D File Offset: 0x0001171D
		// (set) Token: 0x0600103A RID: 4154 RVA: 0x00013525 File Offset: 0x00011725
		public bool Cancel
		{
			get
			{
				return this._cancel;
			}
			set
			{
				this._cancel = this._cancel || value;
			}
		}

		// Token: 0x1700025A RID: 602
		// (get) Token: 0x0600103B RID: 4155 RVA: 0x00013539 File Offset: 0x00011739
		// (set) Token: 0x0600103C RID: 4156 RVA: 0x00013541 File Offset: 0x00011741
		public ZipProgressEventType EventType
		{
			get
			{
				return this._flavor;
			}
			set
			{
				this._flavor = value;
			}
		}

		// Token: 0x1700025B RID: 603
		// (get) Token: 0x0600103D RID: 4157 RVA: 0x0001354A File Offset: 0x0001174A
		// (set) Token: 0x0600103E RID: 4158 RVA: 0x00013552 File Offset: 0x00011752
		public string ArchiveName
		{
			get
			{
				return this._archiveName;
			}
			set
			{
				this._archiveName = value;
			}
		}

		// Token: 0x1700025C RID: 604
		// (get) Token: 0x0600103F RID: 4159 RVA: 0x0001355B File Offset: 0x0001175B
		// (set) Token: 0x06001040 RID: 4160 RVA: 0x00013563 File Offset: 0x00011763
		public long BytesTransferred
		{
			get
			{
				return this._bytesTransferred;
			}
			set
			{
				this._bytesTransferred = value;
			}
		}

		// Token: 0x1700025D RID: 605
		// (get) Token: 0x06001041 RID: 4161 RVA: 0x0001356C File Offset: 0x0001176C
		// (set) Token: 0x06001042 RID: 4162 RVA: 0x00013574 File Offset: 0x00011774
		public long TotalBytesToTransfer
		{
			get
			{
				return this._totalBytesToTransfer;
			}
			set
			{
				this._totalBytesToTransfer = value;
			}
		}

		// Token: 0x04000572 RID: 1394
		private int _entriesTotal;

		// Token: 0x04000573 RID: 1395
		private bool _cancel;

		// Token: 0x04000574 RID: 1396
		private ZipEntry _latestEntry;

		// Token: 0x04000575 RID: 1397
		private ZipProgressEventType _flavor;

		// Token: 0x04000576 RID: 1398
		private string _archiveName;

		// Token: 0x04000577 RID: 1399
		private long _bytesTransferred;

		// Token: 0x04000578 RID: 1400
		private long _totalBytesToTransfer;
	}
}
