﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x02000128 RID: 296
	[ComVisible(true)]
	public enum SelfExtractorFlavor
	{
		// Token: 0x0400063D RID: 1597
		ConsoleApplication,
		// Token: 0x0400063E RID: 1598
		WinFormsApplication
	}
}
