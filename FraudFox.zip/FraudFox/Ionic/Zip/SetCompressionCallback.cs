﻿using System;
using System.Runtime.InteropServices;
using Ionic.Zlib;

namespace Ionic.Zip
{
	// Token: 0x02000110 RID: 272
	// (Invoke) Token: 0x06001030 RID: 4144
	[ComVisible(true)]
	public delegate CompressionLevel SetCompressionCallback(string localFileName, string fileNameInArchive);
}
