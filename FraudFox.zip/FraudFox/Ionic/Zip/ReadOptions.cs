﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace Ionic.Zip
{
	// Token: 0x02000126 RID: 294
	[ComVisible(true)]
	public class ReadOptions
	{
		// Token: 0x170002C1 RID: 705
		// (get) Token: 0x060012CA RID: 4810 RVA: 0x00014815 File Offset: 0x00012A15
		// (set) Token: 0x060012CB RID: 4811 RVA: 0x0001481D File Offset: 0x00012A1D
		public EventHandler<ReadProgressEventArgs> ReadProgress { get; set; }

		// Token: 0x170002C2 RID: 706
		// (get) Token: 0x060012CC RID: 4812 RVA: 0x00014826 File Offset: 0x00012A26
		// (set) Token: 0x060012CD RID: 4813 RVA: 0x0001482E File Offset: 0x00012A2E
		public TextWriter StatusMessageWriter { get; set; }

		// Token: 0x170002C3 RID: 707
		// (get) Token: 0x060012CE RID: 4814 RVA: 0x00014837 File Offset: 0x00012A37
		// (set) Token: 0x060012CF RID: 4815 RVA: 0x0001483F File Offset: 0x00012A3F
		public Encoding Encoding { get; set; }
	}
}
