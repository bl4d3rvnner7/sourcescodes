﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace Ionic.Zip
{
	// Token: 0x02000104 RID: 260
	[ComVisible(true)]
	[Guid("ebc25cf6-9120-4283-b972-0e5520d0000A")]
	[Serializable]
	public class BadReadException : ZipException
	{
		// Token: 0x06000FA5 RID: 4005 RVA: 0x00013292 File Offset: 0x00011492
		public BadReadException()
		{
		}

		// Token: 0x06000FA6 RID: 4006 RVA: 0x0001329A File Offset: 0x0001149A
		public BadReadException(string message)
			: base(message)
		{
		}

		// Token: 0x06000FA7 RID: 4007 RVA: 0x000132A3 File Offset: 0x000114A3
		public BadReadException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

		// Token: 0x06000FA8 RID: 4008 RVA: 0x000132AD File Offset: 0x000114AD
		protected BadReadException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
