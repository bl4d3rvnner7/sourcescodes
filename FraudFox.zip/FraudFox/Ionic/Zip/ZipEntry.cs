﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Ionic.BZip2;
using Ionic.Crc;
using Ionic.Zlib;

namespace Ionic.Zip
{
	// Token: 0x02000118 RID: 280
	[ComVisible(true)]
	[ClassInterface(ClassInterfaceType.AutoDispatch)]
	[Guid("ebc25cf6-9120-4283-b972-0e5520d00004")]
	public class ZipEntry
	{
		// Token: 0x17000263 RID: 611
		// (get) Token: 0x06001065 RID: 4197 RVA: 0x00013616 File Offset: 0x00011816
		internal bool AttributesIndicateDirectory
		{
			get
			{
				return this._InternalFileAttrs == 0 && (this._ExternalFileAttrs & 16) == 16;
			}
		}

		// Token: 0x06001066 RID: 4198 RVA: 0x0001362F File Offset: 0x0001182F
		internal void ResetDirEntry()
		{
			this.__FileDataPosition = -1L;
			this._LengthOfHeader = 0;
		}

		// Token: 0x17000264 RID: 612
		// (get) Token: 0x06001067 RID: 4199 RVA: 0x00057CE4 File Offset: 0x00055EE4
		public string Info
		{
			get
			{
				StringBuilder stringBuilder = ZipEntry.smethod_0();
				ZipEntry.smethod_2(ZipEntry.smethod_2(ZipEntry.smethod_2(stringBuilder, ZipEntry.smethod_1(<Module>.smethod_27<string>(1583107538U), this.FileName)), ZipEntry.smethod_1(<Module>.smethod_23<string>(80335989U), this._VersionMadeBy)), ZipEntry.smethod_1(<Module>.smethod_25<string>(4220809323U), this.VersionNeeded));
				if (this._IsDirectory)
				{
					ZipEntry.smethod_2(stringBuilder, <Module>.smethod_26<string>(3211528525U));
				}
				else
				{
					ZipEntry.smethod_2(ZipEntry.smethod_2(ZipEntry.smethod_2(ZipEntry.smethod_2(ZipEntry.smethod_2(stringBuilder, ZipEntry.smethod_1(<Module>.smethod_25<string>(1039401275U), this._IsText ? <Module>.smethod_26<string>(4039096142U) : <Module>.smethod_24<string>(1310325902U))), ZipEntry.smethod_1(<Module>.smethod_24<string>(903846091U), this.CompressionMethod)), ZipEntry.smethod_1(<Module>.smethod_27<string>(3593611877U), this.CompressedSize)), ZipEntry.smethod_1(<Module>.smethod_24<string>(2583623896U), this.UncompressedSize)), ZipEntry.smethod_1(<Module>.smethod_26<string>(3067882615U), this._Crc32));
				}
				ZipEntry.smethod_2(stringBuilder, ZipEntry.smethod_1(<Module>.smethod_27<string>(4193922346U), this._diskNumber));
				if (this._RelativeOffsetOfLocalHeader > 4294967295L)
				{
					ZipEntry.smethod_2(stringBuilder, ZipEntry.smethod_1(<Module>.smethod_25<string>(3991942174U), this._RelativeOffsetOfLocalHeader));
				}
				else
				{
					ZipEntry.smethod_2(stringBuilder, ZipEntry.smethod_1(<Module>.smethod_26<string>(2391956374U), this._RelativeOffsetOfLocalHeader));
				}
				ZipEntry.smethod_2(ZipEntry.smethod_2(ZipEntry.smethod_2(ZipEntry.smethod_2(stringBuilder, ZipEntry.smethod_1(<Module>.smethod_27<string>(3308110179U), this._BitField)), ZipEntry.smethod_1(<Module>.smethod_23<string>(2423671640U), this._sourceIsEncrypted)), ZipEntry.smethod_1(<Module>.smethod_24<string>(1525760146U), this._TimeBlob)), ZipEntry.smethod_1(<Module>.smethod_23<string>(2810235144U), SharedUtilities.PackedToDateTime(this._TimeBlob)));
				ZipEntry.smethod_2(stringBuilder, ZipEntry.smethod_1(<Module>.smethod_24<string>(1276283490U), this._InputUsesZip64));
				if (!ZipEntry.smethod_3(this._Comment))
				{
					ZipEntry.smethod_2(stringBuilder, ZipEntry.smethod_1(<Module>.smethod_23<string>(3126682650U), this._Comment));
				}
				ZipEntry.smethod_2(stringBuilder, <Module>.smethod_27<string>(3511083134U));
				return ZipEntry.smethod_4(stringBuilder);
			}
		}

		// Token: 0x06001068 RID: 4200 RVA: 0x00057F7C File Offset: 0x0005617C
		internal static ZipEntry ReadDirEntry(ZipFile zf, Dictionary<string, object> previouslySeen)
		{
			Stream readStream = zf.ReadStream;
			Encoding encoding = ((zf.AlternateEncodingUsage == ZipOption.Always) ? zf.AlternateEncoding : ZipFile.DefaultEncoding);
			int num = SharedUtilities.ReadSignature(readStream);
			if (ZipEntry.IsNotValidZipDirEntrySig(num))
			{
				ZipEntry.smethod_5(readStream, -4L, SeekOrigin.Current);
				if ((long)num != 101010256L && (long)num != 101075792L)
				{
					if (num != 67324752)
					{
						throw new BadReadException(ZipEntry.smethod_7(<Module>.smethod_27<string>(2463148165U), num, ZipEntry.smethod_6(readStream)));
					}
				}
				return null;
			}
			int num2 = 46;
			byte[] array = new byte[42];
			int num3 = ZipEntry.smethod_8(readStream, array, 0, array.Length);
			if (num3 != array.Length)
			{
				return null;
			}
			ZipEntry zipEntry = new ZipEntry();
			zipEntry.AlternateEncoding = encoding;
			zipEntry._Source = ZipEntrySource.ZipFile;
			zipEntry._container = new ZipContainer(zf);
			zipEntry._VersionMadeBy = (short)((int)array[0] + (int)array[1] * 256);
			zipEntry._VersionNeeded = (short)((int)array[2] + (int)array[3] * 256);
			zipEntry._BitField = (short)((int)array[4] + (int)array[5] * 256);
			zipEntry._CompressionMethod = (short)((int)array[6] + (int)array[7] * 256);
			zipEntry._TimeBlob = (int)array[8] + (int)array[9] * 256 + (int)array[10] * 256 * 256 + (int)array[11] * 256 * 256 * 256;
			zipEntry._LastModified = SharedUtilities.PackedToDateTime(zipEntry._TimeBlob);
			zipEntry._timestamp |= ZipEntryTimestamp.DOS;
			zipEntry._Crc32 = (int)array[12] + (int)array[13] * 256 + (int)array[14] * 256 * 256 + (int)array[15] * 256 * 256 * 256;
			zipEntry._CompressedSize = (long)((ulong)((int)array[16] + (int)array[17] * 256 + (int)array[18] * 256 * 256 + (int)array[19] * 256 * 256 * 256));
			zipEntry._UncompressedSize = (long)((ulong)((int)array[20] + (int)array[21] * 256 + (int)array[22] * 256 * 256 + (int)array[23] * 256 * 256 * 256));
			zipEntry._CompressionMethod_FromZipFile = zipEntry._CompressionMethod;
			zipEntry._filenameLength = (short)((int)array[24] + (int)array[25] * 256);
			zipEntry._extraFieldLength = (short)((int)array[26] + (int)array[27] * 256);
			zipEntry._commentLength = (short)((int)array[28] + (int)array[29] * 256);
			zipEntry._diskNumber = (uint)array[30] + (uint)array[31] * 256U;
			zipEntry._InternalFileAttrs = (short)((int)array[32] + (int)array[33] * 256);
			zipEntry._ExternalFileAttrs = (int)array[34] + (int)array[35] * 256 + (int)array[36] * 256 * 256 + (int)array[37] * 256 * 256 * 256;
			zipEntry._RelativeOffsetOfLocalHeader = (long)((ulong)((int)array[38] + (int)array[39] * 256 + (int)array[40] * 256 * 256 + (int)array[41] * 256 * 256 * 256));
			zipEntry.IsText = (zipEntry._InternalFileAttrs & 1) == 1;
			array = new byte[(int)zipEntry._filenameLength];
			num3 = ZipEntry.smethod_8(readStream, array, 0, array.Length);
			num2 += num3;
			if ((zipEntry._BitField & 2048) != 2048)
			{
				zipEntry._FileNameInArchive = SharedUtilities.StringFromBuffer(array, encoding);
			}
			else
			{
				zipEntry._FileNameInArchive = SharedUtilities.Utf8StringFromBuffer(array);
			}
			while (previouslySeen.ContainsKey(zipEntry._FileNameInArchive))
			{
				zipEntry._FileNameInArchive = ZipEntry.CopyHelper.AppendCopyToFileName(zipEntry._FileNameInArchive);
				zipEntry._metadataChanged = true;
			}
			if (!zipEntry.AttributesIndicateDirectory)
			{
				if (ZipEntry.smethod_9(zipEntry._FileNameInArchive, <Module>.smethod_24<string>(3061240605U)))
				{
					zipEntry.MarkAsDirectory();
				}
			}
			else
			{
				zipEntry.MarkAsDirectory();
			}
			zipEntry._CompressedFileDataSize = zipEntry._CompressedSize;
			if ((zipEntry._BitField & 1) == 1)
			{
				ZipEntry zipEntry2 = zipEntry;
				zipEntry._Encryption = EncryptionAlgorithm.PkzipWeak;
				zipEntry2._Encryption_FromZipFile = EncryptionAlgorithm.PkzipWeak;
				zipEntry._sourceIsEncrypted = true;
			}
			if (zipEntry._extraFieldLength > 0)
			{
				zipEntry._InputUsesZip64 = zipEntry._CompressedSize == 4294967295L || zipEntry._UncompressedSize == 4294967295L || zipEntry._RelativeOffsetOfLocalHeader == 4294967295L;
				num2 += zipEntry.ProcessExtraField(readStream, zipEntry._extraFieldLength);
				zipEntry._CompressedFileDataSize = zipEntry._CompressedSize;
			}
			if (zipEntry._Encryption == EncryptionAlgorithm.PkzipWeak)
			{
				zipEntry._CompressedFileDataSize -= 12L;
			}
			else if (zipEntry.Encryption == EncryptionAlgorithm.WinZipAes128 || zipEntry.Encryption == EncryptionAlgorithm.WinZipAes256)
			{
				zipEntry._CompressedFileDataSize = zipEntry.CompressedSize - (long)(ZipEntry.GetLengthOfCryptoHeaderBytes(zipEntry.Encryption) + 10);
				zipEntry._LengthOfTrailer = 10;
			}
			if ((zipEntry._BitField & 8) == 8)
			{
				if (!zipEntry._InputUsesZip64)
				{
					zipEntry._LengthOfTrailer += 16;
				}
				else
				{
					zipEntry._LengthOfTrailer += 24;
				}
			}
			zipEntry.AlternateEncoding = (((zipEntry._BitField & 2048) == 2048) ? ZipEntry.smethod_10() : encoding);
			zipEntry.AlternateEncodingUsage = ZipOption.Always;
			if (zipEntry._commentLength > 0)
			{
				array = new byte[(int)zipEntry._commentLength];
				num3 = ZipEntry.smethod_8(readStream, array, 0, array.Length);
				num2 += num3;
				if ((zipEntry._BitField & 2048) != 2048)
				{
					zipEntry._Comment = SharedUtilities.StringFromBuffer(array, encoding);
				}
				else
				{
					zipEntry._Comment = SharedUtilities.Utf8StringFromBuffer(array);
				}
			}
			return zipEntry;
		}

		// Token: 0x06001069 RID: 4201 RVA: 0x00013647 File Offset: 0x00011847
		internal static bool IsNotValidZipDirEntrySig(int signature)
		{
			return signature != 33639248;
		}

		// Token: 0x0600106A RID: 4202 RVA: 0x0005857C File Offset: 0x0005677C
		public ZipEntry()
		{
			this._CompressionMethod = 8;
			this._CompressionLevel = CompressionLevel.Default;
			this._Encryption = EncryptionAlgorithm.None;
			this._Source = ZipEntrySource.None;
			this.AlternateEncoding = ZipEntry.smethod_12(<Module>.smethod_24<string>(1915978978U));
			this.AlternateEncodingUsage = ZipOption.Default;
		}

		// Token: 0x17000265 RID: 613
		// (get) Token: 0x0600106B RID: 4203 RVA: 0x00013654 File Offset: 0x00011854
		// (set) Token: 0x0600106C RID: 4204 RVA: 0x000585F0 File Offset: 0x000567F0
		public DateTime LastModified
		{
			get
			{
				return this._LastModified.ToLocalTime();
			}
			set
			{
				this._LastModified = ((value.Kind == DateTimeKind.Unspecified) ? DateTime.SpecifyKind(value, DateTimeKind.Local) : value.ToLocalTime());
				this._Mtime = SharedUtilities.AdjustTime_Reverse(this._LastModified).ToUniversalTime();
				this._metadataChanged = true;
			}
		}

		// Token: 0x17000266 RID: 614
		// (get) Token: 0x0600106D RID: 4205 RVA: 0x00013661 File Offset: 0x00011861
		private int BufferSize
		{
			get
			{
				return this._container.BufferSize;
			}
		}

		// Token: 0x17000267 RID: 615
		// (get) Token: 0x0600106E RID: 4206 RVA: 0x0001366E File Offset: 0x0001186E
		// (set) Token: 0x0600106F RID: 4207 RVA: 0x00013676 File Offset: 0x00011876
		public DateTime ModifiedTime
		{
			get
			{
				return this._Mtime;
			}
			set
			{
				this.SetEntryTimes(this._Ctime, this._Atime, value);
			}
		}

		// Token: 0x17000268 RID: 616
		// (get) Token: 0x06001070 RID: 4208 RVA: 0x0001368B File Offset: 0x0001188B
		// (set) Token: 0x06001071 RID: 4209 RVA: 0x00013693 File Offset: 0x00011893
		public DateTime AccessedTime
		{
			get
			{
				return this._Atime;
			}
			set
			{
				this.SetEntryTimes(this._Ctime, value, this._Mtime);
			}
		}

		// Token: 0x17000269 RID: 617
		// (get) Token: 0x06001072 RID: 4210 RVA: 0x000136A8 File Offset: 0x000118A8
		// (set) Token: 0x06001073 RID: 4211 RVA: 0x000136B0 File Offset: 0x000118B0
		public DateTime CreationTime
		{
			get
			{
				return this._Ctime;
			}
			set
			{
				this.SetEntryTimes(value, this._Atime, this._Mtime);
			}
		}

		// Token: 0x06001074 RID: 4212 RVA: 0x0005863C File Offset: 0x0005683C
		public void SetEntryTimes(DateTime created, DateTime accessed, DateTime modified)
		{
			this._ntfsTimesAreSet = true;
			if (created == ZipEntry._zeroHour)
			{
				if (created.Kind == ZipEntry._zeroHour.Kind)
				{
					created = ZipEntry._win32Epoch;
				}
			}
			if (accessed == ZipEntry._zeroHour && accessed.Kind == ZipEntry._zeroHour.Kind)
			{
				accessed = ZipEntry._win32Epoch;
			}
			if (modified == ZipEntry._zeroHour && modified.Kind == ZipEntry._zeroHour.Kind)
			{
				modified = ZipEntry._win32Epoch;
			}
			this._Ctime = created.ToUniversalTime();
			this._Atime = accessed.ToUniversalTime();
			this._Mtime = modified.ToUniversalTime();
			this._LastModified = this._Mtime;
			if (!this._emitUnixTimes && !this._emitNtfsTimes)
			{
				this._emitNtfsTimes = true;
			}
			this._metadataChanged = true;
		}

		// Token: 0x1700026A RID: 618
		// (get) Token: 0x06001075 RID: 4213 RVA: 0x000136C5 File Offset: 0x000118C5
		// (set) Token: 0x06001076 RID: 4214 RVA: 0x000136CD File Offset: 0x000118CD
		public bool EmitTimesInWindowsFormatWhenSaving
		{
			get
			{
				return this._emitNtfsTimes;
			}
			set
			{
				this._emitNtfsTimes = value;
				this._metadataChanged = true;
			}
		}

		// Token: 0x1700026B RID: 619
		// (get) Token: 0x06001077 RID: 4215 RVA: 0x000136DD File Offset: 0x000118DD
		// (set) Token: 0x06001078 RID: 4216 RVA: 0x000136E5 File Offset: 0x000118E5
		public bool EmitTimesInUnixFormatWhenSaving
		{
			get
			{
				return this._emitUnixTimes;
			}
			set
			{
				this._emitUnixTimes = value;
				this._metadataChanged = true;
			}
		}

		// Token: 0x1700026C RID: 620
		// (get) Token: 0x06001079 RID: 4217 RVA: 0x000136F5 File Offset: 0x000118F5
		public ZipEntryTimestamp Timestamp
		{
			get
			{
				return this._timestamp;
			}
		}

		// Token: 0x1700026D RID: 621
		// (get) Token: 0x0600107A RID: 4218 RVA: 0x000136FD File Offset: 0x000118FD
		// (set) Token: 0x0600107B RID: 4219 RVA: 0x00013705 File Offset: 0x00011905
		public FileAttributes Attributes
		{
			get
			{
				return (FileAttributes)this._ExternalFileAttrs;
			}
			set
			{
				this._ExternalFileAttrs = (int)value;
				this._VersionMadeBy = 45;
				this._metadataChanged = true;
			}
		}

		// Token: 0x1700026E RID: 622
		// (get) Token: 0x0600107C RID: 4220 RVA: 0x0001371D File Offset: 0x0001191D
		internal string LocalFileName
		{
			get
			{
				return this._LocalFileName;
			}
		}

		// Token: 0x1700026F RID: 623
		// (get) Token: 0x0600107D RID: 4221 RVA: 0x00013725 File Offset: 0x00011925
		// (set) Token: 0x0600107E RID: 4222 RVA: 0x00058718 File Offset: 0x00056918
		public string FileName
		{
			get
			{
				return this._FileNameInArchive;
			}
			set
			{
				if (this._container.ZipFile == null)
				{
					throw new ZipException(<Module>.smethod_26<string>(455943858U));
				}
				if (ZipEntry.smethod_3(value))
				{
					throw new ZipException(<Module>.smethod_25<string>(1764823678U));
				}
				string text = ZipEntry.NameInArchive(value, null);
				if (!ZipEntry.smethod_13(this._FileNameInArchive, text))
				{
					this._container.ZipFile.RemoveEntry(this);
					this._container.ZipFile.InternalAddEntry(text, this);
					this._FileNameInArchive = text;
					this._container.ZipFile.NotifyEntryChanged();
					this._metadataChanged = true;
					return;
				}
			}
		}

		// Token: 0x17000270 RID: 624
		// (get) Token: 0x0600107F RID: 4223 RVA: 0x0001372D File Offset: 0x0001192D
		// (set) Token: 0x06001080 RID: 4224 RVA: 0x00013735 File Offset: 0x00011935
		public Stream InputStream
		{
			get
			{
				return this._sourceStream;
			}
			set
			{
				if (this._Source != ZipEntrySource.Stream)
				{
					throw new ZipException(<Module>.smethod_24<string>(1384000612U));
				}
				this._sourceWasJitProvided = true;
				this._sourceStream = value;
			}
		}

		// Token: 0x17000271 RID: 625
		// (get) Token: 0x06001081 RID: 4225 RVA: 0x0001375E File Offset: 0x0001195E
		public bool InputStreamWasJitProvided
		{
			get
			{
				return this._sourceWasJitProvided;
			}
		}

		// Token: 0x17000272 RID: 626
		// (get) Token: 0x06001082 RID: 4226 RVA: 0x00013766 File Offset: 0x00011966
		public ZipEntrySource Source
		{
			get
			{
				return this._Source;
			}
		}

		// Token: 0x17000273 RID: 627
		// (get) Token: 0x06001083 RID: 4227 RVA: 0x0001376E File Offset: 0x0001196E
		public short VersionNeeded
		{
			get
			{
				return this._VersionNeeded;
			}
		}

		// Token: 0x17000274 RID: 628
		// (get) Token: 0x06001084 RID: 4228 RVA: 0x00013776 File Offset: 0x00011976
		// (set) Token: 0x06001085 RID: 4229 RVA: 0x0001377E File Offset: 0x0001197E
		public string Comment
		{
			get
			{
				return this._Comment;
			}
			set
			{
				this._Comment = value;
				this._metadataChanged = true;
			}
		}

		// Token: 0x17000275 RID: 629
		// (get) Token: 0x06001086 RID: 4230 RVA: 0x0001378E File Offset: 0x0001198E
		public bool? RequiresZip64
		{
			get
			{
				return this._entryRequiresZip64;
			}
		}

		// Token: 0x17000276 RID: 630
		// (get) Token: 0x06001087 RID: 4231 RVA: 0x00013796 File Offset: 0x00011996
		public bool? OutputUsedZip64
		{
			get
			{
				return this._OutputUsesZip64;
			}
		}

		// Token: 0x17000277 RID: 631
		// (get) Token: 0x06001088 RID: 4232 RVA: 0x0001379E File Offset: 0x0001199E
		public short BitField
		{
			get
			{
				return this._BitField;
			}
		}

		// Token: 0x17000278 RID: 632
		// (get) Token: 0x06001089 RID: 4233 RVA: 0x000137A6 File Offset: 0x000119A6
		// (set) Token: 0x0600108A RID: 4234 RVA: 0x000587B4 File Offset: 0x000569B4
		public CompressionMethod CompressionMethod
		{
			get
			{
				return (CompressionMethod)this._CompressionMethod;
			}
			set
			{
				if (value == (CompressionMethod)this._CompressionMethod)
				{
					return;
				}
				if (value != CompressionMethod.None)
				{
					if (value != CompressionMethod.Deflate)
					{
						if (value != CompressionMethod.BZip2)
						{
							throw ZipEntry.smethod_14(<Module>.smethod_25<string>(2977428252U));
						}
					}
				}
				this._CompressionMethod = (short)value;
				if (this._CompressionMethod != 0)
				{
					if (this.CompressionLevel == CompressionLevel.None)
					{
						this._CompressionLevel = CompressionLevel.Default;
					}
				}
				else
				{
					this._CompressionLevel = CompressionLevel.None;
				}
				if (this._container.ZipFile != null)
				{
					this._container.ZipFile.NotifyEntryChanged();
				}
				this._restreamRequiredOnSave = true;
			}
		}

		// Token: 0x17000279 RID: 633
		// (get) Token: 0x0600108B RID: 4235 RVA: 0x000137AE File Offset: 0x000119AE
		// (set) Token: 0x0600108C RID: 4236 RVA: 0x00058838 File Offset: 0x00056A38
		public CompressionLevel CompressionLevel
		{
			get
			{
				return this._CompressionLevel;
			}
			set
			{
				if (this._CompressionMethod != 8 && this._CompressionMethod != 0)
				{
					return;
				}
				if (value == CompressionLevel.Default)
				{
					if (this._CompressionMethod == 8)
					{
						return;
					}
				}
				this._CompressionLevel = value;
				if (value == CompressionLevel.None && this._CompressionMethod == 0)
				{
					return;
				}
				if (this._CompressionLevel == CompressionLevel.None)
				{
					this._CompressionMethod = 0;
				}
				else
				{
					this._CompressionMethod = 8;
				}
				if (this._container.ZipFile != null)
				{
					this._container.ZipFile.NotifyEntryChanged();
				}
				this._restreamRequiredOnSave = true;
			}
		}

		// Token: 0x1700027A RID: 634
		// (get) Token: 0x0600108D RID: 4237 RVA: 0x000137B6 File Offset: 0x000119B6
		public long CompressedSize
		{
			get
			{
				return this._CompressedSize;
			}
		}

		// Token: 0x1700027B RID: 635
		// (get) Token: 0x0600108E RID: 4238 RVA: 0x000137BE File Offset: 0x000119BE
		public long UncompressedSize
		{
			get
			{
				return this._UncompressedSize;
			}
		}

		// Token: 0x1700027C RID: 636
		// (get) Token: 0x0600108F RID: 4239 RVA: 0x000588B8 File Offset: 0x00056AB8
		public double CompressionRatio
		{
			get
			{
				if (this.UncompressedSize == 0L)
				{
					return 0.0;
				}
				return 100.0 * (1.0 - 1.0 * (double)this.CompressedSize / (1.0 * (double)this.UncompressedSize));
			}
		}

		// Token: 0x1700027D RID: 637
		// (get) Token: 0x06001090 RID: 4240 RVA: 0x000137C6 File Offset: 0x000119C6
		public int Crc
		{
			get
			{
				return this._Crc32;
			}
		}

		// Token: 0x1700027E RID: 638
		// (get) Token: 0x06001091 RID: 4241 RVA: 0x000137CE File Offset: 0x000119CE
		public bool IsDirectory
		{
			get
			{
				return this._IsDirectory;
			}
		}

		// Token: 0x1700027F RID: 639
		// (get) Token: 0x06001092 RID: 4242 RVA: 0x000137D6 File Offset: 0x000119D6
		public bool UsesEncryption
		{
			get
			{
				return this._Encryption_FromZipFile != EncryptionAlgorithm.None;
			}
		}

		// Token: 0x17000280 RID: 640
		// (get) Token: 0x06001093 RID: 4243 RVA: 0x000137E4 File Offset: 0x000119E4
		// (set) Token: 0x06001094 RID: 4244 RVA: 0x00058918 File Offset: 0x00056B18
		public EncryptionAlgorithm Encryption
		{
			get
			{
				return this._Encryption;
			}
			set
			{
				if (value == this._Encryption)
				{
					return;
				}
				if (value != EncryptionAlgorithm.Unsupported)
				{
					this._Encryption = value;
					this._restreamRequiredOnSave = true;
					if (this._container.ZipFile != null)
					{
						this._container.ZipFile.NotifyEntryChanged();
					}
					return;
				}
				throw ZipEntry.smethod_14(<Module>.smethod_26<string>(866147872U));
			}
		}

		// Token: 0x17000281 RID: 641
		// (get) Token: 0x06001096 RID: 4246 RVA: 0x0001382C File Offset: 0x00011A2C
		// (set) Token: 0x06001095 RID: 4245 RVA: 0x000137EC File Offset: 0x000119EC
		public string Password
		{
			private get
			{
				return this._Password;
			}
			set
			{
				this._Password = value;
				if (this._Password == null)
				{
					this._Encryption = EncryptionAlgorithm.None;
					return;
				}
				if (this._Source == ZipEntrySource.ZipFile && !this._sourceIsEncrypted)
				{
					this._restreamRequiredOnSave = true;
				}
				if (this.Encryption == EncryptionAlgorithm.None)
				{
					this._Encryption = EncryptionAlgorithm.PkzipWeak;
				}
			}
		}

		// Token: 0x17000282 RID: 642
		// (get) Token: 0x06001097 RID: 4247 RVA: 0x00013834 File Offset: 0x00011A34
		internal bool IsChanged
		{
			get
			{
				return this._restreamRequiredOnSave | this._metadataChanged;
			}
		}

		// Token: 0x17000283 RID: 643
		// (get) Token: 0x06001098 RID: 4248 RVA: 0x00013843 File Offset: 0x00011A43
		// (set) Token: 0x06001099 RID: 4249 RVA: 0x0001384B File Offset: 0x00011A4B
		public ExtractExistingFileAction ExtractExistingFile { get; set; }

		// Token: 0x17000284 RID: 644
		// (get) Token: 0x0600109A RID: 4250 RVA: 0x00013854 File Offset: 0x00011A54
		// (set) Token: 0x0600109B RID: 4251 RVA: 0x0001385C File Offset: 0x00011A5C
		public ZipErrorAction ZipErrorAction { get; set; }

		// Token: 0x17000285 RID: 645
		// (get) Token: 0x0600109C RID: 4252 RVA: 0x00013865 File Offset: 0x00011A65
		public bool IncludedInMostRecentSave
		{
			get
			{
				return !this._skippedDuringSave;
			}
		}

		// Token: 0x17000286 RID: 646
		// (get) Token: 0x0600109D RID: 4253 RVA: 0x00013870 File Offset: 0x00011A70
		// (set) Token: 0x0600109E RID: 4254 RVA: 0x00013878 File Offset: 0x00011A78
		public SetCompressionCallback SetCompression { get; set; }

		// Token: 0x17000287 RID: 647
		// (get) Token: 0x0600109F RID: 4255 RVA: 0x00013881 File Offset: 0x00011A81
		// (set) Token: 0x060010A0 RID: 4256 RVA: 0x000138A5 File Offset: 0x00011AA5
		[Obsolete("Beginning with v1.9.1.6 of DotNetZip, this property is obsolete.  It will be removed in a future version of the library. Your applications should  use AlternateEncoding and AlternateEncodingUsage instead.")]
		public bool UseUnicodeAsNecessary
		{
			get
			{
				return this.AlternateEncoding == ZipEntry.smethod_12(<Module>.smethod_26<string>(2277039646U)) && this.AlternateEncodingUsage == ZipOption.AsNecessary;
			}
			set
			{
				if (value)
				{
					this.AlternateEncoding = ZipEntry.smethod_12(<Module>.smethod_24<string>(350525539U));
					this.AlternateEncodingUsage = ZipOption.AsNecessary;
					return;
				}
				this.AlternateEncoding = ZipFile.DefaultEncoding;
				this.AlternateEncodingUsage = ZipOption.Default;
			}
		}

		// Token: 0x17000288 RID: 648
		// (get) Token: 0x060010A1 RID: 4257 RVA: 0x000138D9 File Offset: 0x00011AD9
		// (set) Token: 0x060010A2 RID: 4258 RVA: 0x000138E1 File Offset: 0x00011AE1
		[Obsolete("This property is obsolete since v1.9.1.6. Use AlternateEncoding and AlternateEncodingUsage instead.", true)]
		public Encoding ProvisionalAlternateEncoding { get; set; }

		// Token: 0x17000289 RID: 649
		// (get) Token: 0x060010A3 RID: 4259 RVA: 0x000138EA File Offset: 0x00011AEA
		// (set) Token: 0x060010A4 RID: 4260 RVA: 0x000138F2 File Offset: 0x00011AF2
		public Encoding AlternateEncoding { get; set; }

		// Token: 0x1700028A RID: 650
		// (get) Token: 0x060010A5 RID: 4261 RVA: 0x000138FB File Offset: 0x00011AFB
		// (set) Token: 0x060010A6 RID: 4262 RVA: 0x00013903 File Offset: 0x00011B03
		public ZipOption AlternateEncodingUsage { get; set; }

		// Token: 0x060010A7 RID: 4263 RVA: 0x00058970 File Offset: 0x00056B70
		internal static string NameInArchive(string filename, string directoryPathInArchive)
		{
			string text;
			if (directoryPathInArchive == null)
			{
				text = filename;
			}
			else if (!ZipEntry.smethod_3(directoryPathInArchive))
			{
				text = ZipEntry.smethod_16(directoryPathInArchive, ZipEntry.smethod_15(filename));
			}
			else
			{
				text = ZipEntry.smethod_15(filename);
			}
			return SharedUtilities.NormalizePathForUseInZipFile(text);
		}

		// Token: 0x060010A8 RID: 4264 RVA: 0x0001390C File Offset: 0x00011B0C
		internal static ZipEntry CreateFromNothing(string nameInArchive)
		{
			return ZipEntry.Create(nameInArchive, ZipEntrySource.None, null, null);
		}

		// Token: 0x060010A9 RID: 4265 RVA: 0x00013917 File Offset: 0x00011B17
		internal static ZipEntry CreateFromFile(string filename, string nameInArchive)
		{
			return ZipEntry.Create(nameInArchive, ZipEntrySource.FileSystem, filename, null);
		}

		// Token: 0x060010AA RID: 4266 RVA: 0x00013922 File Offset: 0x00011B22
		internal static ZipEntry CreateForStream(string entryName, Stream s)
		{
			return ZipEntry.Create(entryName, ZipEntrySource.Stream, s, null);
		}

		// Token: 0x060010AB RID: 4267 RVA: 0x0001392D File Offset: 0x00011B2D
		internal static ZipEntry CreateForWriter(string entryName, WriteDelegate d)
		{
			return ZipEntry.Create(entryName, ZipEntrySource.WriteDelegate, d, null);
		}

		// Token: 0x060010AC RID: 4268 RVA: 0x00013938 File Offset: 0x00011B38
		internal static ZipEntry CreateForJitStreamProvider(string nameInArchive, OpenDelegate opener, CloseDelegate closer)
		{
			return ZipEntry.Create(nameInArchive, ZipEntrySource.JitStream, opener, closer);
		}

		// Token: 0x060010AD RID: 4269 RVA: 0x00013943 File Offset: 0x00011B43
		internal static ZipEntry CreateForZipOutputStream(string nameInArchive)
		{
			return ZipEntry.Create(nameInArchive, ZipEntrySource.ZipOutputStream, null, null);
		}

		// Token: 0x060010AE RID: 4270 RVA: 0x000589AC File Offset: 0x00056BAC
		private static ZipEntry Create(string nameInArchive, ZipEntrySource source, object arg1, object arg2)
		{
			if (ZipEntry.smethod_3(nameInArchive))
			{
				throw new ZipException(<Module>.smethod_27<string>(1478321072U));
			}
			ZipEntry zipEntry = new ZipEntry();
			zipEntry._VersionMadeBy = 45;
			zipEntry._Source = source;
			zipEntry._Mtime = (zipEntry._Atime = (zipEntry._Ctime = DateTime.UtcNow));
			if (source == ZipEntrySource.Stream)
			{
				zipEntry._sourceStream = arg1 as Stream;
			}
			else if (source == ZipEntrySource.WriteDelegate)
			{
				zipEntry._WriteDelegate = arg1 as WriteDelegate;
			}
			else if (source == ZipEntrySource.JitStream)
			{
				zipEntry._OpenDelegate = arg1 as OpenDelegate;
				zipEntry._CloseDelegate = arg2 as CloseDelegate;
			}
			else if (source != ZipEntrySource.ZipOutputStream)
			{
				if (source != ZipEntrySource.None)
				{
					string text = arg1 as string;
					if (ZipEntry.smethod_3(text))
					{
						throw new ZipException(<Module>.smethod_25<string>(491994734U));
					}
					try
					{
						zipEntry._Mtime = ZipEntry.smethod_17(text).ToUniversalTime();
						zipEntry._Ctime = File.GetCreationTime(text).ToUniversalTime();
						zipEntry._Atime = File.GetLastAccessTime(text).ToUniversalTime();
						if (File.Exists(text) || Directory.Exists(text))
						{
							zipEntry._ExternalFileAttrs = (int)File.GetAttributes(text);
						}
						zipEntry._ntfsTimesAreSet = true;
						zipEntry._LocalFileName = Path.GetFullPath(text);
						goto IL_017F;
					}
					catch (PathTooLongException ex)
					{
						string text2;
						for (;;)
						{
							IL_0167:
							int num = -1432822139;
							for (;;)
							{
								switch (num ^ -1432822137)
								{
								case 0:
									goto IL_0167;
								case 2:
									text2 = string.Format(<Module>.smethod_23<string>(3419175529U), text);
									num = -1432822138;
									continue;
								}
								goto Block_11;
							}
						}
						Block_11:
						throw new ZipException(text2, ex);
					}
				}
				zipEntry._Source = ZipEntrySource.FileSystem;
			}
			IL_017F:
			zipEntry._LastModified = zipEntry._Mtime;
			zipEntry._FileNameInArchive = SharedUtilities.NormalizePathForUseInZipFile(nameInArchive);
			return zipEntry;
		}

		// Token: 0x060010AF RID: 4271 RVA: 0x0001394E File Offset: 0x00011B4E
		internal void MarkAsDirectory()
		{
			this._IsDirectory = true;
			if (!ZipEntry.smethod_9(this._FileNameInArchive, <Module>.smethod_26<string>(2625042512U)))
			{
				this._FileNameInArchive = ZipEntry.smethod_18(this._FileNameInArchive, <Module>.smethod_24<string>(3061240605U));
			}
		}

		// Token: 0x1700028B RID: 651
		// (get) Token: 0x060010B0 RID: 4272 RVA: 0x00013989 File Offset: 0x00011B89
		// (set) Token: 0x060010B1 RID: 4273 RVA: 0x00013991 File Offset: 0x00011B91
		public bool IsText
		{
			get
			{
				return this._IsText;
			}
			set
			{
				this._IsText = value;
			}
		}

		// Token: 0x060010B2 RID: 4274 RVA: 0x0001399A File Offset: 0x00011B9A
		public override string ToString()
		{
			return ZipEntry.smethod_1(<Module>.smethod_24<string>(326136862U), this.FileName);
		}

		// Token: 0x1700028C RID: 652
		// (get) Token: 0x060010B3 RID: 4275 RVA: 0x00058B64 File Offset: 0x00056D64
		internal Stream ArchiveStream
		{
			get
			{
				if (this._archiveStream == null)
				{
					if (this._container.ZipFile != null)
					{
						ZipFile zipFile = this._container.ZipFile;
						zipFile.Reset(false);
						this._archiveStream = zipFile.StreamForDiskNumber(this._diskNumber);
					}
					else
					{
						this._archiveStream = this._container.ZipOutputStream.OutputStream;
					}
				}
				return this._archiveStream;
			}
		}

		// Token: 0x060010B4 RID: 4276 RVA: 0x00058BCC File Offset: 0x00056DCC
		private void SetFdpLoh()
		{
			long num = ZipEntry.smethod_6(this.ArchiveStream);
			try
			{
				ZipEntry.smethod_5(this.ArchiveStream, this._RelativeOffsetOfLocalHeader, SeekOrigin.Begin);
			}
			catch (IOException ex)
			{
				string text = ZipEntry.smethod_20(<Module>.smethod_25<string>(1953541247U), this.FileName, this._RelativeOffsetOfLocalHeader, ZipEntry.smethod_19(this.ArchiveStream));
				throw new BadStateException(text, ex);
			}
			byte[] array = new byte[30];
			ZipEntry.smethod_8(this.ArchiveStream, array, 0, array.Length);
			short num2 = (short)((int)array[26] + (int)array[27] * 256);
			short num3 = (short)((int)array[28] + (int)array[29] * 256);
			ZipEntry.smethod_5(this.ArchiveStream, (long)(num2 + num3), SeekOrigin.Current);
			this._LengthOfHeader = (int)(30 + num3 + num2) + ZipEntry.GetLengthOfCryptoHeaderBytes(this._Encryption_FromZipFile);
			this.__FileDataPosition = this._RelativeOffsetOfLocalHeader + (long)this._LengthOfHeader;
			ZipEntry.smethod_5(this.ArchiveStream, num, SeekOrigin.Begin);
		}

		// Token: 0x060010B5 RID: 4277 RVA: 0x000139B1 File Offset: 0x00011BB1
		private static int GetKeyStrengthInBits(EncryptionAlgorithm a)
		{
			if (a == EncryptionAlgorithm.WinZipAes256)
			{
				return 256;
			}
			if (a == EncryptionAlgorithm.WinZipAes128)
			{
				return 128;
			}
			return -1;
		}

		// Token: 0x060010B6 RID: 4278 RVA: 0x00058CD0 File Offset: 0x00056ED0
		internal static int GetLengthOfCryptoHeaderBytes(EncryptionAlgorithm a)
		{
			if (a != EncryptionAlgorithm.None)
			{
				if (a != EncryptionAlgorithm.WinZipAes128)
				{
					if (a != EncryptionAlgorithm.WinZipAes256)
					{
						if (a == EncryptionAlgorithm.PkzipWeak)
						{
							return 12;
						}
						throw new ZipException(<Module>.smethod_23<string>(2853003896U));
					}
				}
				int keyStrengthInBits = ZipEntry.GetKeyStrengthInBits(a);
				return keyStrengthInBits / 8 / 2 + 2;
			}
			return 0;
		}

		// Token: 0x1700028D RID: 653
		// (get) Token: 0x060010B7 RID: 4279 RVA: 0x000139C8 File Offset: 0x00011BC8
		internal long FileDataPosition
		{
			get
			{
				if (this.__FileDataPosition == -1L)
				{
					this.SetFdpLoh();
				}
				return this.__FileDataPosition;
			}
		}

		// Token: 0x1700028E RID: 654
		// (get) Token: 0x060010B8 RID: 4280 RVA: 0x000139E7 File Offset: 0x00011BE7
		private int LengthOfHeader
		{
			get
			{
				if (this._LengthOfHeader == 0)
				{
					this.SetFdpLoh();
				}
				return this._LengthOfHeader;
			}
		}

		// Token: 0x060010B9 RID: 4281 RVA: 0x000139FD File Offset: 0x00011BFD
		public void Extract()
		{
			this.InternalExtractToBaseDir(<Module>.smethod_25<string>(1403186598U), null, this._container, this._Source, this.FileName);
		}

		// Token: 0x060010BA RID: 4282 RVA: 0x00013A22 File Offset: 0x00011C22
		public void Extract(ExtractExistingFileAction extractExistingFile)
		{
			this.ExtractExistingFile = extractExistingFile;
			this.InternalExtractToBaseDir(<Module>.smethod_27<string>(859418173U), null, this._container, this._Source, this.FileName);
		}

		// Token: 0x060010BB RID: 4283 RVA: 0x00013A4E File Offset: 0x00011C4E
		public void Extract(Stream stream)
		{
			this.InternalExtractToStream(stream, null, this._container, this._Source, this.FileName);
		}

		// Token: 0x060010BC RID: 4284 RVA: 0x00013A6A File Offset: 0x00011C6A
		public void Extract(string baseDirectory)
		{
			this.InternalExtractToBaseDir(baseDirectory, null, this._container, this._Source, this.FileName);
		}

		// Token: 0x060010BD RID: 4285 RVA: 0x00013A86 File Offset: 0x00011C86
		public void Extract(string baseDirectory, ExtractExistingFileAction extractExistingFile)
		{
			this.ExtractExistingFile = extractExistingFile;
			this.InternalExtractToBaseDir(baseDirectory, null, this._container, this._Source, this.FileName);
		}

		// Token: 0x060010BE RID: 4286 RVA: 0x00013AA9 File Offset: 0x00011CA9
		public void ExtractWithPassword(string password)
		{
			this.InternalExtractToBaseDir(<Module>.smethod_27<string>(859418173U), password, this._container, this._Source, this.FileName);
		}

		// Token: 0x060010BF RID: 4287 RVA: 0x00013ACE File Offset: 0x00011CCE
		public void ExtractWithPassword(string baseDirectory, string password)
		{
			this.InternalExtractToBaseDir(baseDirectory, password, this._container, this._Source, this.FileName);
		}

		// Token: 0x060010C0 RID: 4288 RVA: 0x00013AEA File Offset: 0x00011CEA
		public void ExtractWithPassword(ExtractExistingFileAction extractExistingFile, string password)
		{
			this.ExtractExistingFile = extractExistingFile;
			this.InternalExtractToBaseDir(<Module>.smethod_27<string>(859418173U), password, this._container, this._Source, this.FileName);
		}

		// Token: 0x060010C1 RID: 4289 RVA: 0x00013B16 File Offset: 0x00011D16
		public void ExtractWithPassword(string baseDirectory, ExtractExistingFileAction extractExistingFile, string password)
		{
			this.ExtractExistingFile = extractExistingFile;
			this.InternalExtractToBaseDir(baseDirectory, password, this._container, this._Source, this.FileName);
		}

		// Token: 0x060010C2 RID: 4290 RVA: 0x00013B39 File Offset: 0x00011D39
		public void ExtractWithPassword(Stream stream, string password)
		{
			this.InternalExtractToStream(stream, password, this._container, this._Source, this.FileName);
		}

		// Token: 0x060010C3 RID: 4291 RVA: 0x00013B55 File Offset: 0x00011D55
		public CrcCalculatorStream OpenReader()
		{
			if (this._container.ZipFile == null)
			{
				throw ZipEntry.smethod_14(<Module>.smethod_26<string>(4218630823U));
			}
			return this.InternalOpenReader(this._Password ?? this._container.Password);
		}

		// Token: 0x060010C4 RID: 4292 RVA: 0x00013B8F File Offset: 0x00011D8F
		public CrcCalculatorStream OpenReader(string password)
		{
			if (this._container.ZipFile == null)
			{
				throw ZipEntry.smethod_14(<Module>.smethod_23<string>(2678536269U));
			}
			return this.InternalOpenReader(password);
		}

		// Token: 0x060010C5 RID: 4293 RVA: 0x00058D14 File Offset: 0x00056F14
		internal CrcCalculatorStream InternalOpenReader(string password)
		{
			ZipEntry.ValidateCompression(this._CompressionMethod_FromZipFile, this.FileName, ZipEntry.GetUnsupportedCompressionMethod(this._CompressionMethod));
			ZipEntry.ValidateEncryption(this.Encryption, this.FileName, this._UnsupportedAlgorithmId);
			this.SetupCryptoForExtract(password);
			if (this._Source != ZipEntrySource.ZipFile)
			{
				throw new BadStateException(<Module>.smethod_26<string>(2809319977U));
			}
			long num = ((this._CompressionMethod_FromZipFile == 0) ? this._CompressedFileDataSize : this.UncompressedSize);
			ZipEntry.smethod_5(this.ArchiveStream, this.FileDataPosition, SeekOrigin.Begin);
			this._inputDecryptorStream = this.GetExtractDecryptor(this.ArchiveStream);
			Stream extractDecompressor = this.GetExtractDecompressor(this._inputDecryptorStream);
			return new CrcCalculatorStream(extractDecompressor, num);
		}

		// Token: 0x060010C6 RID: 4294 RVA: 0x00013BB5 File Offset: 0x00011DB5
		private void OnExtractProgress(long bytesWritten, long totalBytesToWrite)
		{
			if (this._container.ZipFile != null)
			{
				this._ioOperationCanceled = this._container.ZipFile.OnExtractBlock(this, bytesWritten, totalBytesToWrite);
			}
		}

		// Token: 0x060010C7 RID: 4295 RVA: 0x00013BDD File Offset: 0x00011DDD
		private static void OnBeforeExtract(ZipEntry zipEntryInstance, string path, ZipFile zipFile)
		{
			if (zipFile == null)
			{
				return;
			}
			if (!zipFile._inExtractAll)
			{
				zipFile.OnSingleEntryExtract(zipEntryInstance, path, true);
				return;
			}
		}

		// Token: 0x060010C8 RID: 4296 RVA: 0x00013BF6 File Offset: 0x00011DF6
		private void OnAfterExtract(string path)
		{
			if (this._container.ZipFile == null)
			{
				return;
			}
			if (this._container.ZipFile._inExtractAll)
			{
				return;
			}
			this._container.ZipFile.OnSingleEntryExtract(this, path, false);
		}

		// Token: 0x060010C9 RID: 4297 RVA: 0x00013C2D File Offset: 0x00011E2D
		private void OnExtractExisting(string path)
		{
			if (this._container.ZipFile != null)
			{
				this._ioOperationCanceled = this._container.ZipFile.OnExtractExisting(this, path);
			}
		}

		// Token: 0x060010CA RID: 4298 RVA: 0x00013C54 File Offset: 0x00011E54
		private static void ReallyDelete(string fileName)
		{
			if ((ZipEntry.smethod_21(fileName) & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
			{
				ZipEntry.smethod_22(fileName, FileAttributes.Normal);
			}
			ZipEntry.smethod_23(fileName);
		}

		// Token: 0x060010CB RID: 4299 RVA: 0x00013C72 File Offset: 0x00011E72
		private void WriteStatus(string format, params object[] args)
		{
			if (this._container.ZipFile != null && this._container.ZipFile.Verbose)
			{
				ZipEntry.smethod_24(this._container.ZipFile.StatusMessageTextWriter, format, args);
			}
		}

		// Token: 0x060010CC RID: 4300 RVA: 0x00058DC4 File Offset: 0x00056FC4
		private void InternalExtractToBaseDir(string baseDir, string password, ZipContainer zipContainer, ZipEntrySource zipEntrySource, string fileName)
		{
			if (baseDir == null)
			{
				throw ZipEntry.smethod_25(<Module>.smethod_25<string>(889504662U));
			}
			if (zipContainer == null)
			{
				throw new BadStateException(<Module>.smethod_26<string>(3552280976U));
			}
			if (zipContainer.ZipFile == null)
			{
				throw ZipEntry.smethod_14(<Module>.smethod_24<string>(2750280786U));
			}
			zipContainer.ZipFile.Reset(false);
			if (zipEntrySource == ZipEntrySource.ZipFile)
			{
				ZipEntry.OnBeforeExtract(this, baseDir, zipContainer.ZipFile);
				this._ioOperationCanceled = false;
				bool flag = false;
				bool flag2 = false;
				string text = null;
				try
				{
					try
					{
						ZipEntry.ValidateCompression(this._CompressionMethod_FromZipFile, fileName, ZipEntry.GetUnsupportedCompressionMethod(this._CompressionMethod));
						ZipEntry.ValidateEncryption(this.Encryption, fileName, this._UnsupportedAlgorithmId);
						if (this.IsDoneWithOutputToBaseDir(baseDir, out text))
						{
							this.WriteStatus(<Module>.smethod_23<string>(1306749880U), new object[] { text });
							this.OnAfterExtract(baseDir);
						}
						else
						{
							if (ZipEntry.smethod_26(text))
							{
								flag = true;
								int num = this.CheckExtractExistingFile(baseDir, text);
								if (num == 2)
								{
									goto IL_0185;
								}
								if (num == 1)
								{
									return;
								}
							}
							if (this._Encryption_FromZipFile != EncryptionAlgorithm.None)
							{
								this.EnsurePassword(password);
							}
							string text2 = ZipEntry.smethod_27();
							string text3 = ZipEntry.smethod_16(ZipEntry.smethod_28(text), text2);
							this.WriteStatus(<Module>.smethod_25<string>(3285265937U), new object[] { text });
							Stream stream = this.OpenFileStream(text3, ref flag2);
							try
							{
								if (this.ExtractToStream(this.ArchiveStream, stream, this.Encryption, this._Crc32))
								{
									goto IL_0185;
								}
								ZipEntry.smethod_29(stream);
							}
							finally
							{
								if (stream != null)
								{
									ZipEntry.smethod_30(stream);
								}
							}
							this.MoveFileInPlace(flag, text, text3, flag2);
							this.OnAfterExtract(baseDir);
							IL_0185:;
						}
					}
					catch (Exception)
					{
						for (;;)
						{
							IL_01B1:
							int num2 = -1312030884;
							for (;;)
							{
								switch (num2 ^ -1312030883)
								{
								case 1:
									this._ioOperationCanceled = true;
									num2 = -1312030883;
									continue;
								case 2:
									goto IL_01B1;
								}
								goto Block_19;
							}
						}
						Block_19:
						throw;
					}
					return;
				}
				finally
				{
					if (this._ioOperationCanceled && text != null && ZipEntry.smethod_26(text) && !flag)
					{
						ZipEntry.smethod_23(text);
					}
				}
			}
			throw new BadStateException(<Module>.smethod_23<string>(2466440392U));
		}

		// Token: 0x060010CD RID: 4301 RVA: 0x00059008 File Offset: 0x00057208
		private void InternalExtractToStream(Stream outStream, string password, ZipContainer zipContainer, ZipEntrySource zipEntrySource, string fileName)
		{
			if (zipContainer == null)
			{
				throw new BadStateException(<Module>.smethod_25<string>(680712303U));
			}
			if (zipContainer.ZipFile == null)
			{
				throw ZipEntry.smethod_14(<Module>.smethod_24<string>(2750280786U));
			}
			zipContainer.ZipFile.Reset(false);
			if (zipEntrySource == ZipEntrySource.ZipFile)
			{
				ZipEntry.OnBeforeExtract(this, null, zipContainer.ZipFile);
				this._ioOperationCanceled = false;
				try
				{
					ZipEntry.ValidateCompression(this._CompressionMethod_FromZipFile, fileName, ZipEntry.GetUnsupportedCompressionMethod(this._CompressionMethod));
					ZipEntry.ValidateEncryption(this.Encryption, fileName, this._UnsupportedAlgorithmId);
					if (this.IsDoneWithOutputToStream())
					{
						this.WriteStatus(<Module>.smethod_25<string>(2589291407U), null);
						this.OnAfterExtract(null);
						return;
					}
					if (this._Encryption_FromZipFile != EncryptionAlgorithm.None)
					{
						this.EnsurePassword(password);
					}
					this.WriteStatus(<Module>.smethod_23<string>(3937437908U), new object[] { fileName });
					Stream archiveStream = this.ArchiveStream;
					if (!this.ExtractToStream(archiveStream, outStream, this.Encryption, this._Crc32))
					{
						this.OnAfterExtract(null);
					}
					return;
				}
				catch (Exception)
				{
					this._ioOperationCanceled = true;
					throw;
				}
			}
			throw new BadStateException(<Module>.smethod_24<string>(2113631789U));
		}

		// Token: 0x060010CE RID: 4302 RVA: 0x00059134 File Offset: 0x00057334
		private bool ExtractToStream(Stream archiveStream, Stream output, EncryptionAlgorithm encryptionAlgorithm, int expectedCrc32)
		{
			if (this._ioOperationCanceled)
			{
				goto IL_005E;
			}
			int num = this.ExtractAndCrc(archiveStream, output, this._CompressionMethod_FromZipFile, this._CompressedFileDataSize, this.UncompressedSize);
			if (!this._ioOperationCanceled)
			{
				this.VerifyCrcAfterExtract(num, encryptionAlgorithm, expectedCrc32, archiveStream, this.UncompressedSize);
				return false;
			}
			int num2 = 1464734220;
			IL_0045:
			switch (num2 ^ 1464734220)
			{
			case 1:
				return true;
			case 2:
				IL_005E:
				num2 = 1464734221;
				goto IL_0045;
			}
			return true;
		}

		// Token: 0x060010CF RID: 4303 RVA: 0x000591AC File Offset: 0x000573AC
		private void MoveFileInPlace(bool fileExistsBeforeExtraction, string targetFileName, string tmpPath, bool checkLaterForResetDirTimes)
		{
			string text = null;
			if (fileExistsBeforeExtraction)
			{
				text = ZipEntry.smethod_31(targetFileName, ZipEntry.smethod_27(), <Module>.smethod_24<string>(2275207472U));
				ZipEntry.smethod_32(targetFileName, text);
			}
			ZipEntry.smethod_32(tmpPath, targetFileName);
			this._SetTimes(targetFileName, true);
			if (text != null && ZipEntry.smethod_26(text))
			{
				ZipEntry.ReallyDelete(text);
			}
			if (checkLaterForResetDirTimes)
			{
				if (ZipEntry.smethod_33(this.FileName, '/') != -1)
				{
					string text2 = ZipEntry.smethod_28(this.FileName);
					if (this._container.ZipFile[text2] == null)
					{
						this._SetTimes(ZipEntry.smethod_28(targetFileName), false);
					}
				}
			}
			if (((int)this._VersionMadeBy & 65280) == 2560 || ((int)this._VersionMadeBy & 65280) == 0)
			{
				ZipEntry.smethod_22(targetFileName, (FileAttributes)this._ExternalFileAttrs);
			}
		}

		// Token: 0x060010D0 RID: 4304 RVA: 0x0005926C File Offset: 0x0005746C
		private void EnsurePassword(string password)
		{
			string text = password ?? this._Password ?? this._container.Password;
			if (text == null)
			{
				throw new BadPasswordException();
			}
			this.SetupCryptoForExtract(text);
		}

		// Token: 0x060010D1 RID: 4305 RVA: 0x000592A4 File Offset: 0x000574A4
		private Stream OpenFileStream(string tmpPath, ref bool checkLaterForResetDirTimes)
		{
			string text = ZipEntry.smethod_28(tmpPath);
			if (ZipEntry.smethod_34(text))
			{
				if (this._container.ZipFile != null)
				{
					checkLaterForResetDirTimes = this._container.ZipFile._inExtractAll;
				}
			}
			else
			{
				ZipEntry.smethod_35(text);
			}
			return ZipEntry.smethod_36(tmpPath, FileMode.CreateNew);
		}

		// Token: 0x060010D2 RID: 4306 RVA: 0x000592F0 File Offset: 0x000574F0
		internal void VerifyCrcAfterExtract(int calculatedCrc32, EncryptionAlgorithm encryptionAlgorithm, int expectedCrc32, Stream archiveStream, long uncompressedSize)
		{
			if (calculatedCrc32 != expectedCrc32 && ((encryptionAlgorithm != EncryptionAlgorithm.WinZipAes128 && encryptionAlgorithm != EncryptionAlgorithm.WinZipAes256) || this._WinZipAesMethod != 2))
			{
				throw new BadCrcException(ZipEntry.smethod_18(<Module>.smethod_25<string>(869429872U), ZipEntry.smethod_7(<Module>.smethod_25<string>(1913391667U), expectedCrc32, calculatedCrc32)));
			}
			if (uncompressedSize == 0L)
			{
				return;
			}
			if (encryptionAlgorithm != EncryptionAlgorithm.WinZipAes128)
			{
				if (encryptionAlgorithm != EncryptionAlgorithm.WinZipAes256)
				{
					return;
				}
			}
			WinZipAesCipherStream winZipAesCipherStream = this._inputDecryptorStream as WinZipAesCipherStream;
			this._aesCrypto_forExtract.CalculatedMac = winZipAesCipherStream.FinalAuthentication;
			this._aesCrypto_forExtract.ReadAndVerifyMac(archiveStream);
		}

		// Token: 0x060010D3 RID: 4307 RVA: 0x00059388 File Offset: 0x00057588
		private int CheckExtractExistingFile(string baseDir, string targetFileName)
		{
			int num = 0;
			for (;;)
			{
				switch (this.ExtractExistingFile)
				{
				default:
					goto IL_003E;
				case ExtractExistingFileAction.OverwriteSilently:
					goto IL_0054;
				case ExtractExistingFileAction.DoNotOverwrite:
					goto IL_0072;
				case ExtractExistingFileAction.InvokeExtractProgressEvent:
					if (num > 0)
					{
						goto IL_009C;
					}
					this.OnExtractExisting(baseDir);
					if (this._ioOperationCanceled)
					{
						return 2;
					}
					num++;
					break;
				}
			}
			IL_003E:
			throw new ZipException(ZipEntry.smethod_1(<Module>.smethod_27<string>(1683021210U), targetFileName));
			IL_0054:
			this.WriteStatus(<Module>.smethod_26<string>(2663257262U), new object[] { targetFileName });
			return 0;
			IL_0072:
			this.WriteStatus(<Module>.smethod_26<string>(2682410050U), new object[] { this.FileName });
			this.OnAfterExtract(baseDir);
			return 1;
			IL_009C:
			throw new ZipException(ZipEntry.smethod_1(<Module>.smethod_23<string>(1623197386U), targetFileName));
		}

		// Token: 0x060010D4 RID: 4308 RVA: 0x00013CAA File Offset: 0x00011EAA
		private void _CheckRead(int nbytes)
		{
			if (nbytes == 0)
			{
				throw new BadReadException(ZipEntry.smethod_1(<Module>.smethod_25<string>(746251169U), this.FileName));
			}
		}

		// Token: 0x060010D5 RID: 4309 RVA: 0x00059448 File Offset: 0x00057648
		private int ExtractAndCrc(Stream archiveStream, Stream targetOutput, short compressionMethod, long compressedFileDataSize, long uncompressedSize)
		{
			int crc;
			try
			{
				ZipEntry.smethod_5(archiveStream, this.FileDataPosition, SeekOrigin.Begin);
				byte[] array = new byte[this.BufferSize];
				long num = ((compressionMethod != 0) ? uncompressedSize : compressedFileDataSize);
				this._inputDecryptorStream = this.GetExtractDecryptor(archiveStream);
				Stream extractDecompressor = this.GetExtractDecompressor(this._inputDecryptorStream);
				long num2 = 0L;
				CrcCalculatorStream crcCalculatorStream = new CrcCalculatorStream(extractDecompressor);
				try
				{
					while (num > 0L)
					{
						int num3 = ((num > (long)array.Length) ? array.Length : ((int)num));
						int num4 = ZipEntry.smethod_8(crcCalculatorStream, array, 0, num3);
						this._CheckRead(num4);
						ZipEntry.smethod_37(targetOutput, array, 0, num4);
						num -= (long)num4;
						num2 += (long)num4;
						this.OnExtractProgress(num2, uncompressedSize);
						if (this._ioOperationCanceled)
						{
							break;
						}
					}
					crc = crcCalculatorStream.Crc;
				}
				finally
				{
					if (crcCalculatorStream != null)
					{
						ZipEntry.smethod_30(crcCalculatorStream);
					}
				}
			}
			finally
			{
				ZipSegmentedStream zipSegmentedStream = archiveStream as ZipSegmentedStream;
				if (zipSegmentedStream != null)
				{
					ZipEntry.smethod_38(zipSegmentedStream);
					this._archiveStream = null;
				}
			}
			return crc;
		}

		// Token: 0x060010D6 RID: 4310 RVA: 0x00059558 File Offset: 0x00057758
		private Stream GetExtractDecompressor(Stream input2)
		{
			if (input2 == null)
			{
				throw ZipEntry.smethod_25(<Module>.smethod_24<string>(3346788806U));
			}
			short compressionMethod_FromZipFile = this._CompressionMethod_FromZipFile;
			if (compressionMethod_FromZipFile == 0)
			{
				return input2;
			}
			if (compressionMethod_FromZipFile == 8)
			{
				return new DeflateStream(input2, CompressionMode.Decompress, true);
			}
			if (compressionMethod_FromZipFile != 12)
			{
				throw ZipEntry.smethod_39(ZipEntry.smethod_1(<Module>.smethod_23<string>(656788626U), this._CompressionMethod_FromZipFile));
			}
			return new BZip2InputStream(input2, true);
		}

		// Token: 0x060010D7 RID: 4311 RVA: 0x000595C0 File Offset: 0x000577C0
		private Stream GetExtractDecryptor(Stream input)
		{
			if (input == null)
			{
				throw ZipEntry.smethod_25(<Module>.smethod_26<string>(2368060802U));
			}
			Stream stream;
			if (this._Encryption_FromZipFile != EncryptionAlgorithm.PkzipWeak)
			{
				if (this._Encryption_FromZipFile != EncryptionAlgorithm.WinZipAes128 && this._Encryption_FromZipFile != EncryptionAlgorithm.WinZipAes256)
				{
					stream = input;
				}
				else
				{
					stream = new WinZipAesCipherStream(input, this._aesCrypto_forExtract, this._CompressedFileDataSize, CryptoMode.Decrypt);
				}
			}
			else
			{
				stream = new ZipCipherStream(input, this._zipCrypto_forExtract, CryptoMode.Decrypt);
			}
			return stream;
		}

		// Token: 0x060010D8 RID: 4312 RVA: 0x00059624 File Offset: 0x00057824
		internal void _SetTimes(string fileOrDirectory, bool isFile)
		{
			try
			{
				if (this._ntfsTimesAreSet)
				{
					if (isFile)
					{
						if (ZipEntry.smethod_26(fileOrDirectory))
						{
							ZipEntry.smethod_40(fileOrDirectory, this._Ctime);
							ZipEntry.smethod_41(fileOrDirectory, this._Atime);
							ZipEntry.smethod_42(fileOrDirectory, this._Mtime);
						}
					}
					else if (ZipEntry.smethod_34(fileOrDirectory))
					{
						ZipEntry.smethod_43(fileOrDirectory, this._Ctime);
						ZipEntry.smethod_44(fileOrDirectory, this._Atime);
						ZipEntry.smethod_45(fileOrDirectory, this._Mtime);
					}
				}
				else
				{
					DateTime dateTime = SharedUtilities.AdjustTime_Reverse(this.LastModified);
					if (isFile)
					{
						ZipEntry.smethod_46(fileOrDirectory, dateTime);
					}
					else
					{
						ZipEntry.smethod_47(fileOrDirectory, dateTime);
					}
				}
			}
			catch (IOException ex)
			{
				for (;;)
				{
					IL_00D0:
					int num = -1122232408;
					for (;;)
					{
						switch (num ^ -1122232406)
						{
						case 0:
							goto IL_00D0;
						case 2:
							this.WriteStatus(<Module>.smethod_24<string>(3116619620U), new object[]
							{
								fileOrDirectory,
								ZipEntry.smethod_48(ex)
							});
							num = -1122232405;
							continue;
						}
						goto Block_8;
					}
				}
				Block_8:;
			}
		}

		// Token: 0x060010D9 RID: 4313 RVA: 0x0005971C File Offset: 0x0005791C
		private static string GetUnsupportedAlgorithm(uint unsupportedAlgorithmId)
		{
			if (unsupportedAlgorithmId <= 26128U)
			{
				if (unsupportedAlgorithmId <= 26115U)
				{
					if (unsupportedAlgorithmId == 0U)
					{
						return <Module>.smethod_23<string>(1547940886U);
					}
					switch (unsupportedAlgorithmId)
					{
					case 26113U:
						return <Module>.smethod_23<string>(2863284900U);
					case 26114U:
						return <Module>.smethod_27<string>(1117789354U);
					case 26115U:
						return <Module>.smethod_25<string>(3072414991U);
					}
				}
				else
				{
					if (unsupportedAlgorithmId == 26121U)
					{
						return <Module>.smethod_25<string>(3977181880U);
					}
					switch (unsupportedAlgorithmId)
					{
					case 26126U:
						return <Module>.smethod_24<string>(2817856931U);
					case 26127U:
						return <Module>.smethod_25<string>(238994208U);
					case 26128U:
						return <Module>.smethod_25<string>(4185974239U);
					}
				}
			}
			else if (unsupportedAlgorithmId <= 26401U)
			{
				if (unsupportedAlgorithmId == 26370U)
				{
					return <Module>.smethod_24<string>(3983437803U);
				}
				switch (unsupportedAlgorithmId)
				{
				case 26400U:
					return <Module>.smethod_23<string>(3579969533U);
				case 26401U:
					return <Module>.smethod_25<string>(447786567U);
				}
			}
			else
			{
				if (unsupportedAlgorithmId == 26625U)
				{
					return <Module>.smethod_24<string>(4267465550U);
				}
				if (unsupportedAlgorithmId != 65535U)
				{
				}
			}
			return ZipEntry.smethod_1(<Module>.smethod_27<string>(3874240781U), unsupportedAlgorithmId);
		}

		// Token: 0x060010DA RID: 4314 RVA: 0x00059888 File Offset: 0x00057A88
		private static string GetUnsupportedCompressionMethod(short compressionMethod)
		{
			if (compressionMethod <= 14)
			{
				switch (compressionMethod)
				{
				case 0:
					return <Module>.smethod_24<string>(3101884678U);
				case 1:
					return <Module>.smethod_23<string>(3405501906U);
				default:
					switch (compressionMethod)
					{
					case 8:
						return <Module>.smethod_23<string>(1722408513U);
					case 9:
						return <Module>.smethod_23<string>(2476721396U);
					case 12:
						return <Module>.smethod_23<string>(232596872U);
					case 14:
						return <Module>.smethod_24<string>(893174998U);
					}
					break;
				}
			}
			else
			{
				if (compressionMethod == 19)
				{
					return <Module>.smethod_24<string>(80215376U);
				}
				if (compressionMethod == 98)
				{
					return <Module>.smethod_23<string>(1330704507U);
				}
			}
			return ZipEntry.smethod_1(<Module>.smethod_26<string>(3339183503U), compressionMethod);
		}

		// Token: 0x060010DB RID: 4315 RVA: 0x0005995C File Offset: 0x00057B5C
		private static void ValidateEncryption(EncryptionAlgorithm encryptionAlgorithm, string fileName, uint unsupportedAlgorithmId)
		{
			if (encryptionAlgorithm == EncryptionAlgorithm.PkzipWeak || encryptionAlgorithm == EncryptionAlgorithm.WinZipAes128 || encryptionAlgorithm == EncryptionAlgorithm.WinZipAes256 || encryptionAlgorithm == EncryptionAlgorithm.None)
			{
				return;
			}
			if (unsupportedAlgorithmId != 0U)
			{
				throw new ZipException(ZipEntry.smethod_7(<Module>.smethod_23<string>(2452766769U), fileName, ZipEntry.GetUnsupportedAlgorithm(unsupportedAlgorithmId)));
			}
			throw new ZipException(ZipEntry.smethod_7(<Module>.smethod_24<string>(3968702861U), fileName, (int)encryptionAlgorithm));
		}

		// Token: 0x060010DC RID: 4316 RVA: 0x00013CCA File Offset: 0x00011ECA
		private static void ValidateCompression(short compressionMethod, string fileName, string compressionMethodName)
		{
			if (compressionMethod != 0)
			{
				if (compressionMethod != 8)
				{
					if (compressionMethod != 12)
					{
						throw new ZipException(ZipEntry.smethod_20(<Module>.smethod_23<string>(2627234396U), fileName, compressionMethod, compressionMethodName));
					}
				}
			}
		}

		// Token: 0x060010DD RID: 4317 RVA: 0x000599B4 File Offset: 0x00057BB4
		private void SetupCryptoForExtract(string password)
		{
			if (this._Encryption_FromZipFile == EncryptionAlgorithm.None)
			{
				return;
			}
			if (this._Encryption_FromZipFile != EncryptionAlgorithm.PkzipWeak)
			{
				if (this._Encryption_FromZipFile == EncryptionAlgorithm.WinZipAes128 || this._Encryption_FromZipFile == EncryptionAlgorithm.WinZipAes256)
				{
					if (password == null)
					{
						throw new ZipException(<Module>.smethod_24<string>(4130278544U));
					}
					if (this._aesCrypto_forExtract != null)
					{
						this._aesCrypto_forExtract.Password = password;
						return;
					}
					int lengthOfCryptoHeaderBytes = ZipEntry.GetLengthOfCryptoHeaderBytes(this._Encryption_FromZipFile);
					ZipEntry.smethod_5(this.ArchiveStream, this.FileDataPosition - (long)lengthOfCryptoHeaderBytes, SeekOrigin.Begin);
					int keyStrengthInBits = ZipEntry.GetKeyStrengthInBits(this._Encryption_FromZipFile);
					this._aesCrypto_forExtract = WinZipAesCrypto.ReadFromStream(password, keyStrengthInBits, this.ArchiveStream);
				}
				return;
			}
			if (password == null)
			{
				throw new ZipException(<Module>.smethod_23<string>(3150637277U));
			}
			ZipEntry.smethod_5(this.ArchiveStream, this.FileDataPosition - 12L, SeekOrigin.Begin);
			this._zipCrypto_forExtract = ZipCrypto.ForRead(password, this);
		}

		// Token: 0x060010DE RID: 4318 RVA: 0x00059A90 File Offset: 0x00057C90
		private bool IsDoneWithOutputToBaseDir(string baseDir, out string outFileName)
		{
			if (baseDir == null)
			{
				throw ZipEntry.smethod_25(<Module>.smethod_23<string>(1712127509U));
			}
			string text = ZipEntry.smethod_49(this.FileName, Path.DirectorySeparatorChar, '/');
			if (ZipEntry.smethod_33(text, ':') == 1)
			{
				text = ZipEntry.smethod_50(text, 2);
			}
			if (ZipEntry.smethod_51(text, <Module>.smethod_26<string>(2625042512U)))
			{
				text = ZipEntry.smethod_50(text, 1);
			}
			outFileName = (this._container.ZipFile.FlattenFoldersOnExtract ? ZipEntry.smethod_16(baseDir, (ZipEntry.smethod_33(text, '/') != -1) ? ZipEntry.smethod_15(text) : text) : ZipEntry.smethod_16(baseDir, text));
			outFileName = ZipEntry.smethod_49(outFileName, '/', Path.DirectorySeparatorChar);
			if (!this.IsDirectory && !ZipEntry.smethod_9(this.FileName, <Module>.smethod_24<string>(3061240605U)))
			{
				return false;
			}
			if (!ZipEntry.smethod_34(outFileName))
			{
				ZipEntry.smethod_35(outFileName);
				this._SetTimes(outFileName, false);
			}
			else if (this.ExtractExistingFile == ExtractExistingFileAction.OverwriteSilently)
			{
				this._SetTimes(outFileName, false);
			}
			return true;
		}

		// Token: 0x060010DF RID: 4319 RVA: 0x00013CF7 File Offset: 0x00011EF7
		private bool IsDoneWithOutputToStream()
		{
			return this.IsDirectory || ZipEntry.smethod_9(this.FileName, <Module>.smethod_26<string>(2625042512U));
		}

		// Token: 0x060010E0 RID: 4320 RVA: 0x00059B88 File Offset: 0x00057D88
		private void ReadExtraField()
		{
			this._readExtraDepth++;
			long num = ZipEntry.smethod_6(this.ArchiveStream);
			ZipEntry.smethod_5(this.ArchiveStream, this._RelativeOffsetOfLocalHeader, SeekOrigin.Begin);
			byte[] array = new byte[30];
			ZipEntry.smethod_8(this.ArchiveStream, array, 0, array.Length);
			short num2 = (short)((int)array[26] + (int)array[27] * 256);
			short num3 = (short)((int)array[28] + (int)array[29] * 256);
			ZipEntry.smethod_5(this.ArchiveStream, (long)num2, SeekOrigin.Current);
			this.ProcessExtraField(this.ArchiveStream, num3);
			ZipEntry.smethod_5(this.ArchiveStream, num, SeekOrigin.Begin);
			this._readExtraDepth--;
		}

		// Token: 0x060010E1 RID: 4321 RVA: 0x00059C38 File Offset: 0x00057E38
		private static bool ReadHeader(ZipEntry ze, Encoding defaultEncoding)
		{
			ze._RelativeOffsetOfLocalHeader = ZipEntry.smethod_6(ze.ArchiveStream);
			int num = SharedUtilities.ReadEntrySignature(ze.ArchiveStream);
			int num2 = 4;
			if (ZipEntry.IsNotValidSig(num))
			{
				ZipEntry.smethod_5(ze.ArchiveStream, -4L, SeekOrigin.Current);
				if (ZipEntry.IsNotValidZipDirEntrySig(num))
				{
					if ((long)num != 101010256L)
					{
						throw new BadReadException(ZipEntry.smethod_7(<Module>.smethod_27<string>(2837020455U), num, ZipEntry.smethod_6(ze.ArchiveStream)));
					}
				}
				return false;
			}
			byte[] array = new byte[26];
			int num3 = ZipEntry.smethod_8(ze.ArchiveStream, array, 0, array.Length);
			if (num3 != array.Length)
			{
				return false;
			}
			num2 += num3;
			ze._VersionNeeded = (short)((int)array[0] + (int)array[1] * 256);
			ze._BitField = (short)((int)array[2] + (int)array[3] * 256);
			ze._CompressionMethod_FromZipFile = (ze._CompressionMethod = (short)((int)array[4] + (int)array[5] * 256));
			int num4 = (int)array[6] + (int)array[7] * 256 + (int)array[8] * 256 * 256;
			byte[] array2 = array;
			int num5 = 9;
			int num6 = 10;
			ze._TimeBlob = num4 + array2[num5] * 256 * 256 * 256;
			ze._LastModified = SharedUtilities.PackedToDateTime(ze._TimeBlob);
			ze._timestamp |= ZipEntryTimestamp.DOS;
			if ((ze._BitField & 1) == 1)
			{
				ze._Encryption = EncryptionAlgorithm.PkzipWeak;
				ze._Encryption_FromZipFile = EncryptionAlgorithm.PkzipWeak;
				ze._sourceIsEncrypted = true;
			}
			ze._Crc32 = (int)array[num6++] + (int)array[num6++] * 256 + (int)array[num6++] * 256 * 256 + (int)array[num6++] * 256 * 256 * 256;
			ze._CompressedSize = (long)((ulong)((int)array[num6++] + (int)array[num6++] * 256 + (int)array[num6++] * 256 * 256 + (int)array[num6++] * 256 * 256 * 256));
			ze._UncompressedSize = (long)((ulong)((int)array[num6++] + (int)array[num6++] * 256 + (int)array[num6++] * 256 * 256 + (int)array[num6++] * 256 * 256 * 256));
			if ((uint)ze._CompressedSize != 4294967295U)
			{
				if ((uint)ze._UncompressedSize != 4294967295U)
				{
					goto IL_02A1;
				}
			}
			ze._InputUsesZip64 = true;
			IL_02A1:
			short num7 = (short)((int)array[num6++] + (int)array[num6++] * 256);
			short num8 = (short)((int)array[num6++] + (int)array[num6++] * 256);
			array = new byte[(int)num7];
			num3 = ZipEntry.smethod_8(ze.ArchiveStream, array, 0, array.Length);
			num2 += num3;
			if ((ze._BitField & 2048) == 2048)
			{
				ze.AlternateEncoding = ZipEntry.smethod_10();
				ze.AlternateEncodingUsage = ZipOption.Always;
			}
			ze._FileNameInArchive = ZipEntry.smethod_52(ze.AlternateEncoding, array, 0, array.Length);
			if (ZipEntry.smethod_9(ze._FileNameInArchive, <Module>.smethod_23<string>(1912091352U)))
			{
				ze.MarkAsDirectory();
			}
			num2 += ze.ProcessExtraField(ze.ArchiveStream, num8);
			ze._LengthOfTrailer = 0;
			if (!ZipEntry.smethod_9(ze._FileNameInArchive, <Module>.smethod_27<string>(2343293944U)))
			{
				if ((ze._BitField & 8) == 8)
				{
					long num9 = ZipEntry.smethod_6(ze.ArchiveStream);
					bool flag = true;
					long num10 = 0L;
					int num11 = 0;
					while (flag)
					{
						num11++;
						if (ze._container.ZipFile != null)
						{
							ze._container.ZipFile.OnReadBytes(ze);
						}
						long num12 = SharedUtilities.FindSignature(ze.ArchiveStream, 134695760);
						if (num12 == -1L)
						{
							return false;
						}
						num10 += num12;
						if (ze._InputUsesZip64)
						{
							array = new byte[20];
							num3 = ZipEntry.smethod_8(ze.ArchiveStream, array, 0, array.Length);
							if (num3 != 20)
							{
								return false;
							}
							ze._Crc32 = (int)array[0] + (int)array[1] * 256 + (int)array[2] * 256 * 256 + (int)array[3] * 256 * 256 * 256;
							ze._CompressedSize = ZipEntry.smethod_53(array, 4);
							ze._UncompressedSize = ZipEntry.smethod_53(array, 12);
							ze._LengthOfTrailer += 24;
						}
						else
						{
							array = new byte[12];
							num3 = ZipEntry.smethod_8(ze.ArchiveStream, array, 0, array.Length);
							if (num3 != 12)
							{
								return false;
							}
							ze._Crc32 = (int)array[0] + (int)array[1] * 256 + (int)array[2] * 256 * 256 + (int)array[3] * 256 * 256 * 256;
							ze._CompressedSize = (long)((ulong)((int)array[4] + (int)array[5] * 256 + (int)array[6] * 256 * 256 + (int)array[7] * 256 * 256 * 256));
							ze._UncompressedSize = (long)((ulong)((int)array[8] + (int)array[9] * 256 + (int)array[10] * 256 * 256 + (int)array[11] * 256 * 256 * 256));
							ze._LengthOfTrailer += 16;
						}
						if (flag = num10 != ze._CompressedSize)
						{
							ZipEntry.smethod_5(ze.ArchiveStream, -12L, SeekOrigin.Current);
							num10 += 4L;
						}
					}
					ZipEntry.smethod_5(ze.ArchiveStream, num9, SeekOrigin.Begin);
				}
			}
			ze._CompressedFileDataSize = ze._CompressedSize;
			if ((ze._BitField & 1) == 1)
			{
				if (ze.Encryption != EncryptionAlgorithm.WinZipAes128)
				{
					if (ze.Encryption != EncryptionAlgorithm.WinZipAes256)
					{
						ze._WeakEncryptionHeader = new byte[12];
						num2 += ZipEntry.ReadWeakEncryptionHeader(ze._archiveStream, ze._WeakEncryptionHeader);
						ze._CompressedFileDataSize -= 12L;
						goto IL_06D3;
					}
				}
				int keyStrengthInBits = ZipEntry.GetKeyStrengthInBits(ze._Encryption_FromZipFile);
				ze._aesCrypto_forExtract = WinZipAesCrypto.ReadFromStream(null, keyStrengthInBits, ze.ArchiveStream);
				num2 += ze._aesCrypto_forExtract.SizeOfEncryptionMetadata - 10;
				ze._CompressedFileDataSize -= (long)ze._aesCrypto_forExtract.SizeOfEncryptionMetadata;
				ze._LengthOfTrailer += 10;
			}
			IL_06D3:
			ze._LengthOfHeader = num2;
			ze._TotalEntrySize = (long)ze._LengthOfHeader + ze._CompressedFileDataSize + (long)ze._LengthOfTrailer;
			return true;
		}

		// Token: 0x060010E2 RID: 4322 RVA: 0x0005A33C File Offset: 0x0005853C
		internal static int ReadWeakEncryptionHeader(Stream s, byte[] buffer)
		{
			int num = ZipEntry.smethod_8(s, buffer, 0, 12);
			if (num != 12)
			{
				throw new ZipException(ZipEntry.smethod_1(<Module>.smethod_26<string>(1368863144U), ZipEntry.smethod_6(s)));
			}
			return num;
		}

		// Token: 0x060010E3 RID: 4323 RVA: 0x00013D18 File Offset: 0x00011F18
		private static bool IsNotValidSig(int signature)
		{
			return signature != 67324752;
		}

		// Token: 0x060010E4 RID: 4324 RVA: 0x0005A37C File Offset: 0x0005857C
		internal static ZipEntry ReadEntry(ZipContainer zc, bool first)
		{
			ZipFile zipFile = zc.ZipFile;
			Stream readStream = zc.ReadStream;
			Encoding alternateEncoding = zc.AlternateEncoding;
			ZipEntry zipEntry = new ZipEntry();
			zipEntry._Source = ZipEntrySource.ZipFile;
			zipEntry._container = zc;
			zipEntry._archiveStream = readStream;
			if (zipFile != null)
			{
				zipFile.OnReadEntry(true, null);
			}
			if (first)
			{
				ZipEntry.HandlePK00Prefix(readStream);
			}
			if (!ZipEntry.ReadHeader(zipEntry, alternateEncoding))
			{
				return null;
			}
			zipEntry.__FileDataPosition = ZipEntry.smethod_6(zipEntry.ArchiveStream);
			ZipEntry.smethod_5(readStream, zipEntry._CompressedFileDataSize + (long)zipEntry._LengthOfTrailer, SeekOrigin.Current);
			ZipEntry.HandleUnexpectedDataDescriptor(zipEntry);
			if (zipFile != null)
			{
				zipFile.OnReadBytes(zipEntry);
				zipFile.OnReadEntry(false, zipEntry);
			}
			return zipEntry;
		}

		// Token: 0x060010E5 RID: 4325 RVA: 0x0005A418 File Offset: 0x00058618
		internal static void HandlePK00Prefix(Stream s)
		{
			uint num = (uint)SharedUtilities.ReadInt(s);
			if (num != 808471376U)
			{
				ZipEntry.smethod_5(s, -4L, SeekOrigin.Current);
			}
		}

		// Token: 0x060010E6 RID: 4326 RVA: 0x0005A448 File Offset: 0x00058648
		private static void HandleUnexpectedDataDescriptor(ZipEntry entry)
		{
			Stream archiveStream = entry.ArchiveStream;
			uint num = (uint)SharedUtilities.ReadInt(archiveStream);
			if ((ulong)num != (ulong)((long)entry._Crc32))
			{
				ZipEntry.smethod_5(archiveStream, -4L, SeekOrigin.Current);
				return;
			}
			int num2 = SharedUtilities.ReadInt(archiveStream);
			if ((long)num2 != entry._CompressedSize)
			{
				ZipEntry.smethod_5(archiveStream, -8L, SeekOrigin.Current);
				return;
			}
			num2 = SharedUtilities.ReadInt(archiveStream);
			if ((long)num2 == entry._UncompressedSize)
			{
				return;
			}
			ZipEntry.smethod_5(archiveStream, -12L, SeekOrigin.Current);
		}

		// Token: 0x060010E7 RID: 4327 RVA: 0x0005A4C8 File Offset: 0x000586C8
		internal static int FindExtraFieldSegment(byte[] extra, int offx, ushort targetHeaderId)
		{
			int num = offx;
			while (num + 3 < extra.Length)
			{
				ushort num2 = (ushort)((int)extra[num++] + (int)extra[num++] * 256);
				if (num2 == targetHeaderId)
				{
					return num - 2;
				}
				short num3 = (short)((int)extra[num++] + (int)extra[num++] * 256);
				num += (int)num3;
			}
			return -1;
		}

		// Token: 0x060010E8 RID: 4328 RVA: 0x0005A520 File Offset: 0x00058720
		internal int ProcessExtraField(Stream s, short extraFieldLength)
		{
			int num = 0;
			if (extraFieldLength > 0)
			{
				byte[] array = (this._Extra = new byte[(int)extraFieldLength]);
				num = ZipEntry.smethod_8(s, array, 0, array.Length);
				long num2 = ZipEntry.smethod_6(s) - (long)num;
				int num3 = 0;
				while (num3 + 3 < array.Length)
				{
					int num4 = num3;
					ushort num5 = (ushort)((int)array[num3++] + (int)array[num3++] * 256);
					ushort num6 = (ushort)((int)array[num3++] + (int)array[num3++] * 256);
					ushort num7 = num5;
					if (num7 <= 21589)
					{
						if (num7 <= 10)
						{
							if (num7 == 1)
							{
								num3 = this.ProcessExtraFieldZip64(array, num3, num6, num2);
							}
							else if (num7 == 10)
							{
								num3 = this.ProcessExtraFieldWindowsTimes(array, num3, num6, num2);
							}
						}
						else if (num7 != 23)
						{
							if (num7 == 21589)
							{
								num3 = this.ProcessExtraFieldUnixTimes(array, num3, num6, num2);
							}
						}
						else
						{
							num3 = this.ProcessExtraFieldPkwareStrongEncryption(array, num3);
						}
					}
					else if (num7 <= 30805)
					{
						if (num7 != 22613)
						{
							if (num7 != 30805)
							{
							}
						}
						else
						{
							num3 = this.ProcessExtraFieldInfoZipTimes(array, num3, num6, num2);
						}
					}
					else if (num7 != 30837 && num7 == 39169)
					{
						num3 = this.ProcessExtraFieldWinZipAes(array, num3, num6, num2);
					}
					num3 = num4 + (int)num6 + 4;
				}
			}
			return num;
		}

		// Token: 0x060010E9 RID: 4329 RVA: 0x00013D25 File Offset: 0x00011F25
		private int ProcessExtraFieldPkwareStrongEncryption(byte[] Buffer, int j)
		{
			j += 2;
			this._UnsupportedAlgorithmId = (uint)((ushort)((int)Buffer[j++] + (int)Buffer[j++] * 256));
			this._Encryption = EncryptionAlgorithm.Unsupported;
			this._Encryption_FromZipFile = EncryptionAlgorithm.Unsupported;
			return j;
		}

		// Token: 0x060010EA RID: 4330 RVA: 0x0005A678 File Offset: 0x00058878
		private int ProcessExtraFieldWinZipAes(byte[] buffer, int j, ushort dataSize, long posn)
		{
			if (this._CompressionMethod == 99)
			{
				if ((this._BitField & 1) != 1)
				{
					goto IL_00C6;
				}
				goto IL_017D;
				int num;
				short num2;
				int num4;
				for (;;)
				{
					IL_0115:
					int num3;
					switch (num ^ -1422459413)
					{
					case 0:
						goto IL_01AA;
					case 1:
						goto IL_0169;
					case 2:
						if (num2 != 17729)
						{
							goto Block_9;
						}
						goto IL_0062;
					case 3:
						if (buffer[j] != 3)
						{
							num = -1422459409;
							continue;
						}
						num3 = 256;
						goto IL_0077;
					case 4:
						num3 = -1;
						goto IL_0077;
					case 5:
						j += 2;
						num = -1422459423;
						continue;
					case 6:
						num = ((num4 >= 0) ? (-1422459421) : (-1422459413));
						continue;
					case 7:
						goto IL_00C6;
					case 8:
						this._Encryption_FromZipFile = (this._Encryption = ((num4 == 128) ? EncryptionAlgorithm.WinZipAes128 : EncryptionAlgorithm.WinZipAes256));
						j++;
						num = -1422459422;
						continue;
					case 9:
						this._CompressionMethod_FromZipFile = (this._CompressionMethod = ZipEntry.smethod_54(buffer, j));
						num = -1422459410;
						continue;
					case 11:
						goto IL_0062;
					case 12:
						goto IL_017D;
					case 13:
						goto IL_01E7;
					case 14:
						goto IL_020E;
					case 15:
						goto IL_004B;
					case 16:
						j += 2;
						if (this._WinZipAesMethod != 1)
						{
							num = ((this._WinZipAesMethod != 2) ? (-1422459418) : (-1422459420));
							continue;
						}
						goto IL_004B;
					}
					goto Block_10;
					IL_004B:
					num2 = ZipEntry.smethod_54(buffer, j);
					j += 2;
					num = -1422459415;
					continue;
					IL_0062:
					if (buffer[j] != 1)
					{
						num = -1422459416;
						continue;
					}
					num3 = 128;
					IL_0077:
					num4 = num3;
					num = -1422459411;
				}
				Block_9:
				throw new BadReadException(ZipEntry.smethod_7(<Module>.smethod_26<string>(3727817924U), num2, posn));
				Block_10:
				return j;
				IL_01AA:
				throw new BadReadException(ZipEntry.smethod_1(<Module>.smethod_26<string>(175811627U), num4));
				IL_01E7:
				throw new BadReadException(ZipEntry.smethod_7(<Module>.smethod_24<string>(2769079577U), this._WinZipAesMethod, posn));
				IL_020E:
				throw new BadReadException(ZipEntry.smethod_1(<Module>.smethod_26<string>(1388015932U), posn));
				IL_00C6:
				num = -1422459419;
				goto IL_0115;
				IL_0169:
				this._WinZipAesMethod = ZipEntry.smethod_54(buffer, j);
				num = -1422459397;
				goto IL_0115;
				IL_017D:
				this._sourceIsEncrypted = true;
				if (dataSize != 7)
				{
					throw new BadReadException(ZipEntry.smethod_7(<Module>.smethod_26<string>(3549864171U), dataSize, posn));
				}
				goto IL_0169;
			}
			return j;
		}

		// Token: 0x060010EB RID: 4331 RVA: 0x0005A8B0 File Offset: 0x00058AB0
		private int ProcessExtraFieldZip64(byte[] buffer, int j, ushort dataSize, long posn)
		{
			this._InputUsesZip64 = true;
			if (dataSize > 28)
			{
				throw new BadReadException(ZipEntry.smethod_7(<Module>.smethod_24<string>(844397644U), dataSize, posn));
			}
			int remainingData = (int)dataSize;
			ZipEntry.Func<long> func = delegate
			{
				if (remainingData < 8)
				{
					throw new BadReadException(ZipEntry.<>c__DisplayClass1.smethod_0(<Module>.smethod_25<string>(864042661U), posn));
				}
				long num = ZipEntry.<>c__DisplayClass1.smethod_1(buffer, j);
				j += 8;
				remainingData -= 8;
				return num;
			};
			if (this._UncompressedSize == 4294967295L)
			{
				this._UncompressedSize = func();
			}
			if (this._CompressedSize == 4294967295L)
			{
				this._CompressedSize = func();
			}
			if (this._RelativeOffsetOfLocalHeader == 4294967295L)
			{
				this._RelativeOffsetOfLocalHeader = func();
			}
			return j;
		}

		// Token: 0x060010EC RID: 4332 RVA: 0x0005A97C File Offset: 0x00058B7C
		private int ProcessExtraFieldInfoZipTimes(byte[] buffer, int j, ushort dataSize, long posn)
		{
			if (dataSize != 12 && dataSize != 8)
			{
				throw new BadReadException(ZipEntry.smethod_7(<Module>.smethod_25<string>(2644128566U), dataSize, posn));
			}
			int num = ZipEntry.smethod_55(buffer, j);
			this._Mtime = ZipEntry._unixEpoch.AddSeconds((double)num);
			j += 4;
			num = BitConverter.ToInt32(buffer, j);
			this._Atime = ZipEntry._unixEpoch.AddSeconds((double)num);
			j += 4;
			this._Ctime = DateTime.UtcNow;
			this._ntfsTimesAreSet = true;
			this._timestamp |= ZipEntryTimestamp.InfoZip1;
			return j;
		}

		// Token: 0x060010ED RID: 4333 RVA: 0x0005AA14 File Offset: 0x00058C14
		private int ProcessExtraFieldUnixTimes(byte[] buffer, int j, ushort dataSize, long posn)
		{
			if (dataSize != 13)
			{
				if (dataSize != 9)
				{
					if (dataSize != 5)
					{
						throw new BadReadException(ZipEntry.smethod_7(<Module>.smethod_26<string>(765550322U), dataSize, posn));
					}
				}
			}
			int remainingData = (int)dataSize;
			ZipEntry.Func<DateTime> func = delegate
			{
				int num = ZipEntry.<>c__DisplayClass4.smethod_0(buffer, j);
				j += 4;
				remainingData -= 4;
				return ZipEntry._unixEpoch.AddSeconds((double)num);
			};
			if (dataSize != 13 && this._readExtraDepth <= 0)
			{
				this.ReadExtraField();
			}
			else
			{
				byte b = buffer[j++];
				remainingData--;
				if ((b & 1) != 0 && remainingData >= 4)
				{
					this._Mtime = func();
				}
				this._Atime = (((b & 2) == 0 || remainingData < 4) ? DateTime.UtcNow : func());
				this._Ctime = (((b & 4) == 0 || remainingData < 4) ? DateTime.UtcNow : func());
				this._timestamp |= ZipEntryTimestamp.Unix;
				this._ntfsTimesAreSet = true;
				this._emitUnixTimes = true;
			}
			return j;
		}

		// Token: 0x060010EE RID: 4334 RVA: 0x0005AB3C File Offset: 0x00058D3C
		private int ProcessExtraFieldWindowsTimes(byte[] buffer, int j, ushort dataSize, long posn)
		{
			if (dataSize != 32)
			{
				throw new BadReadException(ZipEntry.smethod_7(<Module>.smethod_25<string>(854669578U), dataSize, posn));
			}
			j += 4;
			short num = (short)((int)buffer[j] + (int)buffer[j + 1] * 256);
			short num2 = (short)((int)buffer[j + 2] + (int)buffer[j + 3] * 256);
			j += 4;
			if (num == 1 && num2 == 24)
			{
				long num3 = ZipEntry.smethod_53(buffer, j);
				this._Mtime = DateTime.FromFileTimeUtc(num3);
				j += 8;
				num3 = ZipEntry.smethod_53(buffer, j);
				this._Atime = DateTime.FromFileTimeUtc(num3);
				j += 8;
				num3 = ZipEntry.smethod_53(buffer, j);
				this._Ctime = DateTime.FromFileTimeUtc(num3);
				j += 8;
				this._ntfsTimesAreSet = true;
				this._timestamp |= ZipEntryTimestamp.Windows;
				this._emitNtfsTimes = true;
			}
			return j;
		}

		// Token: 0x060010EF RID: 4335 RVA: 0x0005AC10 File Offset: 0x00058E10
		internal void WriteCentralDirectoryEntry(Stream s)
		{
			byte[] array = new byte[8192];
			array[0] = 80;
			array[1] = 75;
			array[2] = 1;
			array[3] = 2;
			array[4] = (byte)(this._VersionMadeBy & 255);
			byte[] array2 = array;
			int num = 5;
			int num2 = 6;
			array2[num] = (byte)(((int)this._VersionMadeBy & 65280) >> 8);
			short num3 = ((this.VersionNeeded != 0) ? this.VersionNeeded : 20);
			if (this._OutputUsesZip64 == null)
			{
				this._OutputUsesZip64 = new bool?(this._container.Zip64 == Zip64Option.Always);
			}
			short num4 = (this._OutputUsesZip64.Value ? 45 : num3);
			if (this.CompressionMethod == CompressionMethod.BZip2)
			{
				num4 = 46;
			}
			array[num2++] = (byte)(num4 & 255);
			array[num2++] = (byte)(((int)num4 & 65280) >> 8);
			array[num2++] = (byte)(this._BitField & 255);
			array[num2++] = (byte)(((int)this._BitField & 65280) >> 8);
			array[num2++] = (byte)(this._CompressionMethod & 255);
			array[num2++] = (byte)(((int)this._CompressionMethod & 65280) >> 8);
			if (this.Encryption == EncryptionAlgorithm.WinZipAes128 || this.Encryption == EncryptionAlgorithm.WinZipAes256)
			{
				num2 -= 2;
				array[num2++] = 99;
				array[num2++] = 0;
			}
			array[num2++] = (byte)(this._TimeBlob & 255);
			array[num2++] = (byte)((this._TimeBlob & 65280) >> 8);
			array[num2++] = (byte)((this._TimeBlob & 16711680) >> 16);
			array[num2++] = (byte)(((long)this._TimeBlob & 4278190080L) >> 24);
			array[num2++] = (byte)(this._Crc32 & 255);
			array[num2++] = (byte)((this._Crc32 & 65280) >> 8);
			array[num2++] = (byte)((this._Crc32 & 16711680) >> 16);
			array[num2++] = (byte)(((long)this._Crc32 & 4278190080L) >> 24);
			if (!this._OutputUsesZip64.Value)
			{
				array[num2++] = (byte)(this._CompressedSize & 255L);
				array[num2++] = (byte)((this._CompressedSize & 65280L) >> 8);
				array[num2++] = (byte)((this._CompressedSize & 16711680L) >> 16);
				array[num2++] = (byte)((this._CompressedSize & 4278190080L) >> 24);
				array[num2++] = (byte)(this._UncompressedSize & 255L);
				array[num2++] = (byte)((this._UncompressedSize & 65280L) >> 8);
				array[num2++] = (byte)((this._UncompressedSize & 16711680L) >> 16);
				array[num2++] = (byte)((this._UncompressedSize & 4278190080L) >> 24);
			}
			else
			{
				for (int i = 0; i < 8; i++)
				{
					array[num2++] = byte.MaxValue;
				}
			}
			byte[] encodedFileNameBytes = this.GetEncodedFileNameBytes();
			short num5 = (short)encodedFileNameBytes.Length;
			array[num2++] = (byte)(num5 & 255);
			array[num2++] = (byte)(((int)num5 & 65280) >> 8);
			this._presumeZip64 = this._OutputUsesZip64.Value;
			this._Extra = this.ConstructExtraField(true);
			short num6 = (short)((this._Extra == null) ? 0 : this._Extra.Length);
			array[num2++] = (byte)(num6 & 255);
			array[num2++] = (byte)(((int)num6 & 65280) >> 8);
			int num7 = ((this._CommentBytes == null) ? 0 : this._CommentBytes.Length);
			num2 += 2;
			if (this._container.ZipFile != null && this._container.ZipFile.MaxOutputSegmentSize != 0)
			{
				array[num2++] = (byte)(this._diskNumber & 255U);
				array[num2++] = (byte)((this._diskNumber & 65280U) >> 8);
			}
			else
			{
				array[num2++] = 0;
				array[num2++] = 0;
			}
			array[num2++] = (this._IsText ? 1 : 0);
			array[num2++] = 0;
			array[num2++] = (byte)(this._ExternalFileAttrs & 255);
			array[num2++] = (byte)((this._ExternalFileAttrs & 65280) >> 8);
			array[num2++] = (byte)((this._ExternalFileAttrs & 16711680) >> 16);
			array[num2++] = (byte)(((long)this._ExternalFileAttrs & 4278190080L) >> 24);
			if (this._RelativeOffsetOfLocalHeader <= 4294967295L)
			{
				array[num2++] = (byte)(this._RelativeOffsetOfLocalHeader & 255L);
				array[num2++] = (byte)((this._RelativeOffsetOfLocalHeader & 65280L) >> 8);
				array[num2++] = (byte)((this._RelativeOffsetOfLocalHeader & 16711680L) >> 16);
				array[num2++] = (byte)((this._RelativeOffsetOfLocalHeader & 4278190080L) >> 24);
			}
			else
			{
				array[num2++] = byte.MaxValue;
				array[num2++] = byte.MaxValue;
				array[num2++] = byte.MaxValue;
				array[num2++] = byte.MaxValue;
			}
			ZipEntry.smethod_56(encodedFileNameBytes, 0, array, num2, (int)num5);
			num2 += (int)num5;
			if (this._Extra != null)
			{
				byte[] extra = this._Extra;
				ZipEntry.smethod_56(extra, 0, array, num2, (int)num6);
				num2 += (int)num6;
			}
			if (num7 != 0)
			{
				if (num7 + num2 > array.Length)
				{
					num7 = array.Length - num2;
				}
				ZipEntry.smethod_56(this._CommentBytes, 0, array, num2, num7);
				num2 += num7;
			}
			array[32] = (byte)(num7 & 255);
			array[33] = (byte)((num7 & 65280) >> 8);
			ZipEntry.smethod_37(s, array, 0, num2);
		}

		// Token: 0x060010F0 RID: 4336 RVA: 0x0005B1C8 File Offset: 0x000593C8
		private byte[] ConstructExtraField(bool forCentralDirectory)
		{
			List<byte[]> list = new List<byte[]>();
			byte[] array;
			if (this._container.Zip64 == Zip64Option.Always || (this._container.Zip64 == Zip64Option.AsNecessary && (!forCentralDirectory || this._entryRequiresZip64.Value)))
			{
				int num = 4 + (forCentralDirectory ? 28 : 16);
				array = new byte[num];
				int num2 = 0;
				if (!this._presumeZip64 && !forCentralDirectory)
				{
					array[num2++] = 153;
					array[num2++] = 153;
				}
				else
				{
					array[num2++] = 1;
					array[num2++] = 0;
				}
				array[num2++] = (byte)(num - 4);
				array[num2++] = 0;
				ZipEntry.smethod_58(ZipEntry.smethod_57(this._UncompressedSize), 0, array, num2, 8);
				num2 += 8;
				ZipEntry.smethod_58(ZipEntry.smethod_57(this._CompressedSize), 0, array, num2, 8);
				num2 += 8;
				if (forCentralDirectory)
				{
					ZipEntry.smethod_58(ZipEntry.smethod_57(this._RelativeOffsetOfLocalHeader), 0, array, num2, 8);
					num2 += 8;
					ZipEntry.smethod_58(ZipEntry.smethod_59(0), 0, array, num2, 4);
				}
				list.Add(array);
			}
			if (this.Encryption != EncryptionAlgorithm.WinZipAes128)
			{
				if (this.Encryption != EncryptionAlgorithm.WinZipAes256)
				{
					goto IL_01C7;
				}
			}
			array = new byte[11];
			array[0] = 1;
			array[1] = 153;
			array[2] = 7;
			array[3] = 0;
			array[4] = 1;
			array[5] = 0;
			array[6] = 65;
			byte[] array2 = array;
			int num3 = 7;
			int num4 = 8;
			array2[num3] = 69;
			int keyStrengthInBits = ZipEntry.GetKeyStrengthInBits(this.Encryption);
			if (keyStrengthInBits == 128)
			{
				array[num4] = 1;
			}
			else if (keyStrengthInBits == 256)
			{
				array[num4] = 3;
			}
			else
			{
				array[num4] = byte.MaxValue;
			}
			num4++;
			array[num4++] = (byte)(this._CompressionMethod & 255);
			array[num4++] = (byte)((int)this._CompressionMethod & 65280);
			list.Add(array);
			IL_01C7:
			if (this._ntfsTimesAreSet && this._emitNtfsTimes)
			{
				array = new byte[36];
				array[0] = 10;
				array[1] = 0;
				array[2] = 32;
				array[3] = 0;
				array[8] = 1;
				array[9] = 0;
				array[10] = 24;
				array[11] = 0;
				long num5 = this._Mtime.ToFileTime();
				Array.Copy(BitConverter.GetBytes(num5), 0, array, 12, 8);
				num5 = this._Atime.ToFileTime();
				Array.Copy(BitConverter.GetBytes(num5), 0, array, 20, 8);
				num5 = this._Ctime.ToFileTime();
				Array.Copy(BitConverter.GetBytes(num5), 0, array, 28, 8);
				list.Add(array);
			}
			if (this._ntfsTimesAreSet && this._emitUnixTimes)
			{
				int num6 = 9;
				if (!forCentralDirectory)
				{
					num6 += 8;
				}
				array = new byte[num6];
				array[0] = 85;
				array[1] = 84;
				array[2] = (byte)(num6 - 4);
				array[3] = 0;
				array[4] = 7;
				int num7 = (int)(this._Mtime - ZipEntry._unixEpoch).TotalSeconds;
				Array.Copy(BitConverter.GetBytes(num7), 0, array, 5, 4);
				int num8 = 9;
				if (!forCentralDirectory)
				{
					num7 = (int)(this._Atime - ZipEntry._unixEpoch).TotalSeconds;
					Array.Copy(BitConverter.GetBytes(num7), 0, array, num8, 4);
					num8 += 4;
					num7 = (int)(this._Ctime - ZipEntry._unixEpoch).TotalSeconds;
					Array.Copy(BitConverter.GetBytes(num7), 0, array, num8, 4);
					num8 += 4;
				}
				list.Add(array);
			}
			byte[] array3 = null;
			if (list.Count > 0)
			{
				int num9 = 0;
				int num10 = 0;
				for (int i = 0; i < list.Count; i++)
				{
					num9 += list[i].Length;
				}
				array3 = new byte[num9];
				for (int i = 0; i < list.Count; i++)
				{
					Array.Copy(list[i], 0, array3, num10, list[i].Length);
					num10 += list[i].Length;
				}
			}
			return array3;
		}

		// Token: 0x060010F1 RID: 4337 RVA: 0x0005B5BC File Offset: 0x000597BC
		private string NormalizeFileName()
		{
			string text = ZipEntry.smethod_60(this.FileName, <Module>.smethod_24<string>(1184318668U), <Module>.smethod_25<string>(2443307951U));
			if (this._TrimVolumeFromFullyQualifiedPaths && ZipEntry.smethod_61(this.FileName) >= 3 && ZipEntry.smethod_62(this.FileName, 1) == ':')
			{
				if (ZipEntry.smethod_62(text, 2) == '/')
				{
					return ZipEntry.smethod_50(text, 3);
				}
			}
			if (ZipEntry.smethod_61(this.FileName) >= 4 && ZipEntry.smethod_62(text, 0) == '/')
			{
				if (ZipEntry.smethod_62(text, 1) == '/')
				{
					int num = ZipEntry.smethod_63(text, '/', 2);
					if (num == -1)
					{
						throw ZipEntry.smethod_64(<Module>.smethod_26<string>(2471729382U));
					}
					return ZipEntry.smethod_50(text, num + 1);
				}
			}
			if (ZipEntry.smethod_61(this.FileName) >= 3)
			{
				if (ZipEntry.smethod_62(text, 0) == '.')
				{
					if (ZipEntry.smethod_62(text, 1) == '/')
					{
						return ZipEntry.smethod_50(text, 2);
					}
				}
			}
			return text;
		}

		// Token: 0x060010F2 RID: 4338 RVA: 0x0005B6B0 File Offset: 0x000598B0
		private byte[] GetEncodedFileNameBytes()
		{
			string text = this.NormalizeFileName();
			switch (this.AlternateEncodingUsage)
			{
			case ZipOption.Default:
				if (this._Comment != null && ZipEntry.smethod_61(this._Comment) != 0)
				{
					this._CommentBytes = ZipEntry.smethod_65(ZipEntry.ibm437, this._Comment);
				}
				this._actualEncoding = ZipEntry.ibm437;
				return ZipEntry.smethod_65(ZipEntry.ibm437, text);
			case ZipOption.Always:
				if (this._Comment != null && ZipEntry.smethod_61(this._Comment) != 0)
				{
					this._CommentBytes = ZipEntry.smethod_65(this.AlternateEncoding, this._Comment);
				}
				this._actualEncoding = this.AlternateEncoding;
				return ZipEntry.smethod_65(this.AlternateEncoding, text);
			}
			byte[] array = ZipEntry.smethod_65(ZipEntry.ibm437, text);
			string text2 = ZipEntry.smethod_52(ZipEntry.ibm437, array, 0, array.Length);
			this._CommentBytes = null;
			if (ZipEntry.smethod_66(text2, text))
			{
				array = ZipEntry.smethod_65(this.AlternateEncoding, text);
				if (this._Comment != null && ZipEntry.smethod_61(this._Comment) != 0)
				{
					this._CommentBytes = ZipEntry.smethod_65(this.AlternateEncoding, this._Comment);
				}
				this._actualEncoding = this.AlternateEncoding;
				return array;
			}
			this._actualEncoding = ZipEntry.ibm437;
			if (this._Comment == null || ZipEntry.smethod_61(this._Comment) == 0)
			{
				return array;
			}
			byte[] array2 = ZipEntry.smethod_65(ZipEntry.ibm437, this._Comment);
			string text3 = ZipEntry.smethod_52(ZipEntry.ibm437, array2, 0, array2.Length);
			if (ZipEntry.smethod_66(text3, this.Comment))
			{
				array = ZipEntry.smethod_65(this.AlternateEncoding, text);
				this._CommentBytes = ZipEntry.smethod_65(this.AlternateEncoding, this._Comment);
				this._actualEncoding = this.AlternateEncoding;
				return array;
			}
			this._CommentBytes = array2;
			return array;
		}

		// Token: 0x060010F3 RID: 4339 RVA: 0x0005B86C File Offset: 0x00059A6C
		private bool WantReadAgain()
		{
			return this._UncompressedSize >= 16L && this._CompressionMethod != 0 && this.CompressionLevel != CompressionLevel.None && this._CompressedSize >= this._UncompressedSize && (this._Source != ZipEntrySource.Stream || ZipEntry.smethod_67(this._sourceStream)) && (this._aesCrypto_forWrite == null || this.CompressedSize - (long)this._aesCrypto_forWrite.SizeOfEncryptionMetadata > this.UncompressedSize + 16L) && (this._zipCrypto_forWrite == null || this.CompressedSize - 12L > this.UncompressedSize);
		}

		// Token: 0x060010F4 RID: 4340 RVA: 0x0005B920 File Offset: 0x00059B20
		private void MaybeUnsetCompressionMethodForWriting(int cycle)
		{
			if (cycle > 1)
			{
				this._CompressionMethod = 0;
				return;
			}
			if (this.IsDirectory)
			{
				this._CompressionMethod = 0;
				return;
			}
			if (this._Source == ZipEntrySource.ZipFile)
			{
				return;
			}
			if (this._Source != ZipEntrySource.Stream)
			{
				if (this._Source == ZipEntrySource.FileSystem && SharedUtilities.GetFileLength(this.LocalFileName) == 0L)
				{
					this._CompressionMethod = 0;
					return;
				}
			}
			else if (this._sourceStream != null && ZipEntry.smethod_67(this._sourceStream))
			{
				long num = ZipEntry.smethod_19(this._sourceStream);
				if (num == 0L)
				{
					this._CompressionMethod = 0;
					return;
				}
			}
			if (this.SetCompression != null)
			{
				this.CompressionLevel = this.SetCompression(this.LocalFileName, this._FileNameInArchive);
			}
			if (this.CompressionLevel == CompressionLevel.None && this.CompressionMethod == CompressionMethod.Deflate)
			{
				this._CompressionMethod = 0;
			}
		}

		// Token: 0x060010F5 RID: 4341 RVA: 0x0005B9FC File Offset: 0x00059BFC
		internal void WriteHeader(Stream s, int cycle)
		{
			CountingStream countingStream = s as CountingStream;
			this._future_ROLH = ((countingStream != null) ? countingStream.ComputedPosition : ZipEntry.smethod_6(s));
			byte[] array = new byte[30];
			array[0] = 80;
			array[1] = 75;
			array[2] = 3;
			byte[] array2 = array;
			int num = 3;
			int num2 = 4;
			array2[num] = 4;
			this._presumeZip64 = this._container.Zip64 == Zip64Option.Always || (this._container.Zip64 == Zip64Option.AsNecessary && !ZipEntry.smethod_67(s));
			short num3 = (this._presumeZip64 ? 45 : 20);
			if (this.CompressionMethod == CompressionMethod.BZip2)
			{
				num3 = 46;
			}
			array[num2++] = (byte)(num3 & 255);
			array[num2++] = (byte)(((int)num3 & 65280) >> 8);
			byte[] encodedFileNameBytes = this.GetEncodedFileNameBytes();
			short num4 = (short)encodedFileNameBytes.Length;
			if (this._Encryption == EncryptionAlgorithm.None)
			{
				this._BitField &= -2;
			}
			else
			{
				this._BitField |= 1;
			}
			if (ZipEntry.smethod_68(this._actualEncoding) == ZipEntry.smethod_68(ZipEntry.smethod_10()))
			{
				this._BitField |= 2048;
			}
			if (!this.IsDirectory && cycle != 99)
			{
				if (!ZipEntry.smethod_67(s))
				{
					this._BitField |= 8;
				}
			}
			else
			{
				this._BitField &= -9;
				this._BitField &= -2;
				this.Encryption = EncryptionAlgorithm.None;
				this.Password = null;
			}
			array[num2++] = (byte)(this._BitField & 255);
			array[num2++] = (byte)(((int)this._BitField & 65280) >> 8);
			if (this.__FileDataPosition == -1L)
			{
				this._CompressedSize = 0L;
				this._crcCalculated = false;
			}
			this.MaybeUnsetCompressionMethodForWriting(cycle);
			array[num2++] = (byte)(this._CompressionMethod & 255);
			array[num2++] = (byte)(((int)this._CompressionMethod & 65280) >> 8);
			if (cycle == 99)
			{
				this.SetZip64Flags();
			}
			else if (this.Encryption == EncryptionAlgorithm.WinZipAes128 || this.Encryption == EncryptionAlgorithm.WinZipAes256)
			{
				num2 -= 2;
				array[num2++] = 99;
				array[num2++] = 0;
			}
			this._TimeBlob = SharedUtilities.DateTimeToPacked(this.LastModified);
			array[num2++] = (byte)(this._TimeBlob & 255);
			array[num2++] = (byte)((this._TimeBlob & 65280) >> 8);
			array[num2++] = (byte)((this._TimeBlob & 16711680) >> 16);
			array[num2++] = (byte)(((long)this._TimeBlob & 4278190080L) >> 24);
			array[num2++] = (byte)(this._Crc32 & 255);
			array[num2++] = (byte)((this._Crc32 & 65280) >> 8);
			array[num2++] = (byte)((this._Crc32 & 16711680) >> 16);
			array[num2++] = (byte)(((long)this._Crc32 & 4278190080L) >> 24);
			if (this._presumeZip64)
			{
				for (int i = 0; i < 8; i++)
				{
					array[num2++] = byte.MaxValue;
				}
			}
			else
			{
				array[num2++] = (byte)(this._CompressedSize & 255L);
				array[num2++] = (byte)((this._CompressedSize & 65280L) >> 8);
				array[num2++] = (byte)((this._CompressedSize & 16711680L) >> 16);
				array[num2++] = (byte)((this._CompressedSize & 4278190080L) >> 24);
				array[num2++] = (byte)(this._UncompressedSize & 255L);
				array[num2++] = (byte)((this._UncompressedSize & 65280L) >> 8);
				array[num2++] = (byte)((this._UncompressedSize & 16711680L) >> 16);
				array[num2++] = (byte)((this._UncompressedSize & 4278190080L) >> 24);
			}
			array[num2++] = (byte)(num4 & 255);
			array[num2++] = (byte)(((int)num4 & 65280) >> 8);
			this._Extra = this.ConstructExtraField(false);
			short num5 = (short)((this._Extra == null) ? 0 : this._Extra.Length);
			array[num2++] = (byte)(num5 & 255);
			array[num2++] = (byte)(((int)num5 & 65280) >> 8);
			byte[] array3 = new byte[num2 + (int)num4 + (int)num5];
			ZipEntry.smethod_56(array, 0, array3, 0, num2);
			ZipEntry.smethod_56(encodedFileNameBytes, 0, array3, num2, encodedFileNameBytes.Length);
			num2 += encodedFileNameBytes.Length;
			if (this._Extra != null)
			{
				ZipEntry.smethod_56(this._Extra, 0, array3, num2, this._Extra.Length);
				num2 += this._Extra.Length;
			}
			this._LengthOfHeader = num2;
			ZipSegmentedStream zipSegmentedStream = s as ZipSegmentedStream;
			if (zipSegmentedStream != null)
			{
				zipSegmentedStream.ContiguousWrite = true;
				uint num6 = zipSegmentedStream.ComputeSegment(num2);
				if (num6 != zipSegmentedStream.CurrentSegment)
				{
					this._future_ROLH = 0L;
				}
				else
				{
					this._future_ROLH = ZipEntry.smethod_6(zipSegmentedStream);
				}
				this._diskNumber = num6;
			}
			if (this._container.Zip64 == Zip64Option.Default && (uint)this._RelativeOffsetOfLocalHeader >= 4294967295U)
			{
				throw new ZipException(<Module>.smethod_26<string>(348186719U));
			}
			ZipEntry.smethod_37(s, array3, 0, num2);
			if (zipSegmentedStream != null)
			{
				zipSegmentedStream.ContiguousWrite = false;
			}
			this._EntryHeader = array3;
		}

		// Token: 0x060010F6 RID: 4342 RVA: 0x0005BF4C File Offset: 0x0005A14C
		private int FigureCrc32()
		{
			if (!this._crcCalculated)
			{
				Stream stream = null;
				if (this._Source == ZipEntrySource.WriteDelegate)
				{
					CrcCalculatorStream crcCalculatorStream = new CrcCalculatorStream(Stream.Null);
					this._WriteDelegate(this.FileName, crcCalculatorStream);
					this._Crc32 = crcCalculatorStream.Crc;
				}
				else if (this._Source != ZipEntrySource.ZipFile)
				{
					if (this._Source != ZipEntrySource.Stream)
					{
						if (this._Source != ZipEntrySource.JitStream)
						{
							if (this._Source != ZipEntrySource.ZipOutputStream)
							{
								stream = ZipEntry.smethod_69(this.LocalFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
							}
						}
						else
						{
							if (this._sourceStream == null)
							{
								this._sourceStream = this._OpenDelegate(this.FileName);
							}
							this.PrepSourceStream();
							stream = this._sourceStream;
						}
					}
					else
					{
						this.PrepSourceStream();
						stream = this._sourceStream;
					}
					CRC32 crc = new CRC32();
					this._Crc32 = crc.GetCrc32(stream);
					if (this._sourceStream == null)
					{
						ZipEntry.smethod_38(stream);
					}
				}
				this._crcCalculated = true;
			}
			return this._Crc32;
		}

		// Token: 0x060010F7 RID: 4343 RVA: 0x0005C044 File Offset: 0x0005A244
		private void PrepSourceStream()
		{
			if (this._sourceStream == null)
			{
				throw new ZipException(ZipEntry.smethod_1(<Module>.smethod_24<string>(1980508632U), this.FileName));
			}
			if (this._sourceStreamOriginalPosition != null)
			{
				ZipEntry.smethod_70(this._sourceStream, this._sourceStreamOriginalPosition.Value);
				return;
			}
			if (!ZipEntry.smethod_67(this._sourceStream))
			{
				if (this.Encryption == EncryptionAlgorithm.PkzipWeak)
				{
					if (this._Source != ZipEntrySource.ZipFile)
					{
						if ((this._BitField & 8) != 8)
						{
							throw new ZipException(<Module>.smethod_26<string>(214117203U));
						}
					}
				}
				return;
			}
			this._sourceStreamOriginalPosition = new long?(ZipEntry.smethod_6(this._sourceStream));
		}

		// Token: 0x060010F8 RID: 4344 RVA: 0x0005C0F0 File Offset: 0x0005A2F0
		internal void CopyMetaData(ZipEntry source)
		{
			this.__FileDataPosition = source.__FileDataPosition;
			this.CompressionMethod = source.CompressionMethod;
			this._CompressionMethod_FromZipFile = source._CompressionMethod_FromZipFile;
			this._CompressedFileDataSize = source._CompressedFileDataSize;
			this._UncompressedSize = source._UncompressedSize;
			this._BitField = source._BitField;
			this._Source = source._Source;
			this._LastModified = source._LastModified;
			this._Mtime = source._Mtime;
			this._Atime = source._Atime;
			this._Ctime = source._Ctime;
			this._ntfsTimesAreSet = source._ntfsTimesAreSet;
			this._emitUnixTimes = source._emitUnixTimes;
			this._emitNtfsTimes = source._emitNtfsTimes;
		}

		// Token: 0x060010F9 RID: 4345 RVA: 0x00013D59 File Offset: 0x00011F59
		private void OnWriteBlock(long bytesXferred, long totalBytesToXfer)
		{
			if (this._container.ZipFile != null)
			{
				this._ioOperationCanceled = this._container.ZipFile.OnSaveBlock(this, bytesXferred, totalBytesToXfer);
			}
		}

		// Token: 0x060010FA RID: 4346 RVA: 0x0005C1A8 File Offset: 0x0005A3A8
		private void _WriteEntryData(Stream s)
		{
			Stream stream = null;
			long num = -1L;
			try
			{
				num = ZipEntry.smethod_6(s);
			}
			catch (Exception)
			{
			}
			try
			{
				long num2 = this.SetInputAndFigureFileLength(ref stream);
				CountingStream countingStream = new CountingStream(s);
				Stream stream3;
				Stream stream2;
				if (num2 == 0L)
				{
					stream2 = (stream3 = countingStream);
				}
				else
				{
					stream3 = this.MaybeApplyEncryption(countingStream);
					stream2 = this.MaybeApplyCompression(stream3, num2);
				}
				CrcCalculatorStream crcCalculatorStream = new CrcCalculatorStream(stream2, true);
				if (this._Source != ZipEntrySource.WriteDelegate)
				{
					byte[] array = new byte[this.BufferSize];
					int num3;
					while ((num3 = SharedUtilities.ReadWithRetry(stream, array, 0, array.Length, this.FileName)) != 0)
					{
						ZipEntry.smethod_37(crcCalculatorStream, array, 0, num3);
						this.OnWriteBlock(crcCalculatorStream.TotalBytesSlurped, num2);
						if (this._ioOperationCanceled)
						{
							break;
						}
					}
				}
				else
				{
					this._WriteDelegate(this.FileName, crcCalculatorStream);
				}
				this.FinishOutputStream(s, countingStream, stream3, stream2, crcCalculatorStream);
			}
			finally
			{
				if (this._Source == ZipEntrySource.JitStream)
				{
					if (this._CloseDelegate != null)
					{
						this._CloseDelegate(this.FileName, stream);
					}
					this._sourceStream = null;
				}
				else if (stream is FileStream)
				{
					ZipEntry.smethod_38(stream);
				}
			}
			if (this._ioOperationCanceled)
			{
				return;
			}
			this.__FileDataPosition = num;
			this.PostProcessOutput(s);
		}

		// Token: 0x060010FB RID: 4347 RVA: 0x0005C2F4 File Offset: 0x0005A4F4
		private long SetInputAndFigureFileLength(ref Stream input)
		{
			long num = -1L;
			if (this._Source == ZipEntrySource.Stream)
			{
				this.PrepSourceStream();
				input = this._sourceStream;
				try
				{
					return ZipEntry.smethod_19(this._sourceStream);
				}
				catch (NotSupportedException)
				{
					return num;
				}
			}
			if (this._Source == ZipEntrySource.ZipFile)
			{
				string text = ((this._Encryption_FromZipFile == EncryptionAlgorithm.None) ? null : (this._Password ?? this._container.Password));
				this._sourceStream = this.InternalOpenReader(text);
				this.PrepSourceStream();
				input = this._sourceStream;
				num = ZipEntry.smethod_19(this._sourceStream);
			}
			else
			{
				if (this._Source == ZipEntrySource.JitStream)
				{
					if (this._sourceStream == null)
					{
						this._sourceStream = this._OpenDelegate(this.FileName);
					}
					this.PrepSourceStream();
					input = this._sourceStream;
					try
					{
						return ZipEntry.smethod_19(this._sourceStream);
					}
					catch (NotSupportedException)
					{
						return num;
					}
				}
				if (this._Source == ZipEntrySource.FileSystem)
				{
					input = ZipEntry.smethod_69(this.LocalFileName, FileMode.Open, FileAccess.Read, FileShare.Read | FileShare.Write | FileShare.Delete);
					num = ZipEntry.smethod_19(input);
				}
			}
			return num;
		}

		// Token: 0x060010FC RID: 4348 RVA: 0x0005C414 File Offset: 0x0005A614
		internal void FinishOutputStream(Stream s, CountingStream entryCounter, Stream encryptor, Stream compressor, CrcCalculatorStream output)
		{
			if (output == null)
			{
				return;
			}
			ZipEntry.smethod_29(output);
			if (compressor is DeflateStream)
			{
				ZipEntry.smethod_29(compressor);
			}
			else if (!(compressor is BZip2OutputStream))
			{
				if (compressor is ParallelBZip2OutputStream)
				{
					ZipEntry.smethod_29(compressor);
				}
				else if (compressor is ParallelDeflateOutputStream)
				{
					ZipEntry.smethod_29(compressor);
				}
			}
			else
			{
				ZipEntry.smethod_29(compressor);
			}
			ZipEntry.smethod_71(encryptor);
			ZipEntry.smethod_29(encryptor);
			this._LengthOfTrailer = 0;
			this._UncompressedSize = output.TotalBytesSlurped;
			WinZipAesCipherStream winZipAesCipherStream = encryptor as WinZipAesCipherStream;
			if (winZipAesCipherStream != null && this._UncompressedSize > 0L)
			{
				ZipEntry.smethod_37(s, winZipAesCipherStream.FinalAuthentication, 0, 10);
				this._LengthOfTrailer += 10;
			}
			this._CompressedFileDataSize = entryCounter.BytesWritten;
			this._CompressedSize = this._CompressedFileDataSize;
			this._Crc32 = output.Crc;
			this.StoreRelativeOffset();
		}

		// Token: 0x060010FD RID: 4349 RVA: 0x0005C4F8 File Offset: 0x0005A6F8
		internal void PostProcessOutput(Stream s)
		{
			CountingStream countingStream = s as CountingStream;
			if (this._UncompressedSize == 0L && this._CompressedSize == 0L)
			{
				if (this._Source == ZipEntrySource.ZipOutputStream)
				{
					return;
				}
				if (this._Password != null)
				{
					int num = 0;
					if (this.Encryption != EncryptionAlgorithm.PkzipWeak)
					{
						if (this.Encryption != EncryptionAlgorithm.WinZipAes128)
						{
							if (this.Encryption != EncryptionAlgorithm.WinZipAes256)
							{
								goto IL_0088;
							}
						}
						num = this._aesCrypto_forWrite._Salt.Length + this._aesCrypto_forWrite.GeneratedPV.Length;
					}
					else
					{
						num = 12;
					}
					IL_0088:
					if (this._Source == ZipEntrySource.ZipOutputStream && !ZipEntry.smethod_67(s))
					{
						throw new ZipException(<Module>.smethod_25<string>(3439148422U));
					}
					if (this.Encryption != EncryptionAlgorithm.None)
					{
						ZipEntry.smethod_5(s, (long)(-1 * num), SeekOrigin.Current);
						ZipEntry.smethod_72(s, ZipEntry.smethod_6(s));
						if (countingStream != null)
						{
							countingStream.Adjust((long)num);
						}
						this._LengthOfHeader -= num;
						this.__FileDataPosition -= (long)num;
					}
					this._Password = null;
					this._BitField &= -2;
					this._EntryHeader[6] = (byte)(this._BitField & 255);
					this._EntryHeader[7] = (byte)(((int)this._BitField & 65280) >> 8);
					if (this.Encryption == EncryptionAlgorithm.WinZipAes128 || this.Encryption == EncryptionAlgorithm.WinZipAes256)
					{
						short num2 = (short)((int)this._EntryHeader[26] + (int)this._EntryHeader[27] * 256);
						int num3 = (int)(30 + num2);
						int num4 = ZipEntry.FindExtraFieldSegment(this._EntryHeader, num3, 39169);
						if (num4 >= 0)
						{
							this._EntryHeader[num4++] = 153;
							this._EntryHeader[num4++] = 153;
						}
					}
				}
				this.CompressionMethod = CompressionMethod.None;
				this.Encryption = EncryptionAlgorithm.None;
			}
			else if (this._zipCrypto_forWrite != null || this._aesCrypto_forWrite != null)
			{
				if (this.Encryption == EncryptionAlgorithm.PkzipWeak)
				{
					this._CompressedSize += 12L;
				}
				else
				{
					if (this.Encryption != EncryptionAlgorithm.WinZipAes128)
					{
						if (this.Encryption != EncryptionAlgorithm.WinZipAes256)
						{
							goto IL_0215;
						}
					}
					this._CompressedSize += (long)this._aesCrypto_forWrite.SizeOfEncryptionMetadata;
				}
			}
			IL_0215:
			this._EntryHeader[8] = (byte)(this._CompressionMethod & 255);
			this._EntryHeader[9] = (byte)(((int)this._CompressionMethod & 65280) >> 8);
			this._EntryHeader[14] = (byte)(this._Crc32 & 255);
			this._EntryHeader[15] = (byte)((this._Crc32 & 65280) >> 8);
			this._EntryHeader[16] = (byte)((this._Crc32 & 16711680) >> 16);
			byte[] entryHeader = this._EntryHeader;
			int num5 = 17;
			int num6 = 18;
			entryHeader[num5] = (byte)(((long)this._Crc32 & 4278190080L) >> 24);
			this.SetZip64Flags();
			short num7 = (short)((int)this._EntryHeader[26] + (int)this._EntryHeader[27] * 256);
			short num8 = (short)((int)this._EntryHeader[28] + (int)this._EntryHeader[29] * 256);
			if (!this._OutputUsesZip64.Value)
			{
				this._EntryHeader[4] = 20;
				this._EntryHeader[5] = 0;
				this._EntryHeader[18] = (byte)(this._CompressedSize & 255L);
				this._EntryHeader[19] = (byte)((this._CompressedSize & 65280L) >> 8);
				this._EntryHeader[20] = (byte)((this._CompressedSize & 16711680L) >> 16);
				this._EntryHeader[21] = (byte)((this._CompressedSize & 4278190080L) >> 24);
				this._EntryHeader[22] = (byte)(this._UncompressedSize & 255L);
				this._EntryHeader[23] = (byte)((this._UncompressedSize & 65280L) >> 8);
				this._EntryHeader[24] = (byte)((this._UncompressedSize & 16711680L) >> 16);
				this._EntryHeader[25] = (byte)((this._UncompressedSize & 4278190080L) >> 24);
				if (num8 != 0)
				{
					num6 = (int)(30 + num7);
					short num9 = (short)((int)this._EntryHeader[num6 + 2] + (int)this._EntryHeader[num6 + 3] * 256);
					if (num9 == 16)
					{
						this._EntryHeader[num6++] = 153;
						this._EntryHeader[num6++] = 153;
					}
				}
			}
			else
			{
				this._EntryHeader[4] = 45;
				this._EntryHeader[5] = 0;
				for (int i = 0; i < 8; i++)
				{
					this._EntryHeader[num6++] = byte.MaxValue;
				}
				num6 = (int)(30 + num7);
				this._EntryHeader[num6++] = 1;
				this._EntryHeader[num6++] = 0;
				num6 += 2;
				ZipEntry.smethod_58(ZipEntry.smethod_57(this._UncompressedSize), 0, this._EntryHeader, num6, 8);
				num6 += 8;
				ZipEntry.smethod_58(ZipEntry.smethod_57(this._CompressedSize), 0, this._EntryHeader, num6, 8);
			}
			if (this.Encryption == EncryptionAlgorithm.WinZipAes128 || this.Encryption == EncryptionAlgorithm.WinZipAes256)
			{
				this._EntryHeader[8] = 99;
				this._EntryHeader[9] = 0;
				num6 = (int)(30 + num7);
				do
				{
					ushort num10 = (ushort)((int)this._EntryHeader[num6] + (int)this._EntryHeader[num6 + 1] * 256);
					short num11 = (short)((int)this._EntryHeader[num6 + 2] + (int)this._EntryHeader[num6 + 3] * 256);
					if (num10 != 39169)
					{
						num6 += (int)(num11 + 4);
					}
					else
					{
						num6 += 9;
						this._EntryHeader[num6++] = (byte)(this._CompressionMethod & 255);
						this._EntryHeader[num6++] = (byte)((int)this._CompressionMethod & 65280);
					}
				}
				while (num6 < (int)(num8 - 30 - num7));
			}
			if ((this._BitField & 8) == 8)
			{
				if (this._Source != ZipEntrySource.ZipOutputStream || !ZipEntry.smethod_67(s))
				{
					goto IL_06DB;
				}
			}
			ZipSegmentedStream zipSegmentedStream = s as ZipSegmentedStream;
			if (zipSegmentedStream != null && this._diskNumber != zipSegmentedStream.CurrentSegment)
			{
				Stream stream = ZipSegmentedStream.ForUpdate(this._container.ZipFile.Name, this._diskNumber);
				try
				{
					ZipEntry.smethod_5(stream, this._RelativeOffsetOfLocalHeader, SeekOrigin.Begin);
					ZipEntry.smethod_37(stream, this._EntryHeader, 0, this._EntryHeader.Length);
					goto IL_06DB;
				}
				finally
				{
					if (stream != null)
					{
						ZipEntry.smethod_30(stream);
					}
				}
			}
			ZipEntry.smethod_5(s, this._RelativeOffsetOfLocalHeader, SeekOrigin.Begin);
			ZipEntry.smethod_37(s, this._EntryHeader, 0, this._EntryHeader.Length);
			if (countingStream != null)
			{
				countingStream.Adjust((long)this._EntryHeader.Length);
			}
			ZipEntry.smethod_5(s, this._CompressedSize, SeekOrigin.Current);
			IL_06DB:
			if ((this._BitField & 8) == 8 && !this.IsDirectory)
			{
				byte[] array = new byte[16 + (this._OutputUsesZip64.Value ? 8 : 0)];
				ZipEntry.smethod_58(ZipEntry.smethod_59(134695760), 0, array, 0, 4);
				ZipEntry.smethod_58(ZipEntry.smethod_59(this._Crc32), 0, array, 4, 4);
				num6 = 8;
				if (this._OutputUsesZip64.Value)
				{
					ZipEntry.smethod_58(ZipEntry.smethod_57(this._CompressedSize), 0, array, num6, 8);
					num6 += 8;
					ZipEntry.smethod_58(ZipEntry.smethod_57(this._UncompressedSize), 0, array, num6, 8);
					num6 += 8;
				}
				else
				{
					array[num6++] = (byte)(this._CompressedSize & 255L);
					array[num6++] = (byte)((this._CompressedSize & 65280L) >> 8);
					array[num6++] = (byte)((this._CompressedSize & 16711680L) >> 16);
					array[num6++] = (byte)((this._CompressedSize & 4278190080L) >> 24);
					array[num6++] = (byte)(this._UncompressedSize & 255L);
					array[num6++] = (byte)((this._UncompressedSize & 65280L) >> 8);
					array[num6++] = (byte)((this._UncompressedSize & 16711680L) >> 16);
					array[num6++] = (byte)((this._UncompressedSize & 4278190080L) >> 24);
				}
				ZipEntry.smethod_37(s, array, 0, array.Length);
				this._LengthOfTrailer += array.Length;
			}
		}

		// Token: 0x060010FE RID: 4350 RVA: 0x0005CDA8 File Offset: 0x0005AFA8
		private void SetZip64Flags()
		{
			this._entryRequiresZip64 = new bool?(this._CompressedSize >= 4294967295L || this._UncompressedSize >= 4294967295L || this._RelativeOffsetOfLocalHeader >= 4294967295L);
			if (this._container.Zip64 == Zip64Option.Default && this._entryRequiresZip64.Value)
			{
				throw new ZipException(<Module>.smethod_24<string>(55826699U));
			}
			this._OutputUsesZip64 = new bool?(this._container.Zip64 == Zip64Option.Always || this._entryRequiresZip64.Value);
		}

		// Token: 0x060010FF RID: 4351 RVA: 0x0005CE4C File Offset: 0x0005B04C
		internal void PrepOutputStream(Stream s, long streamLength, out CountingStream outputCounter, out Stream encryptor, out Stream compressor, out CrcCalculatorStream output)
		{
			outputCounter = new CountingStream(s);
			if (streamLength != 0L)
			{
				encryptor = this.MaybeApplyEncryption(outputCounter);
				compressor = this.MaybeApplyCompression(encryptor, streamLength);
			}
			else
			{
				Stream stream;
				compressor = (stream = outputCounter);
				encryptor = stream;
			}
			output = new CrcCalculatorStream(compressor, true);
		}

		// Token: 0x06001100 RID: 4352 RVA: 0x0005CEA0 File Offset: 0x0005B0A0
		private Stream MaybeApplyCompression(Stream s, long streamLength)
		{
			if (this._CompressionMethod == 8 && this.CompressionLevel != CompressionLevel.None)
			{
				if (this._container.ParallelDeflateThreshold != 0L && (streamLength <= this._container.ParallelDeflateThreshold || this._container.ParallelDeflateThreshold <= 0L))
				{
					DeflateStream deflateStream = new DeflateStream(s, CompressionMode.Compress, this.CompressionLevel, true);
					if (this._container.CodecBufferSize > 0)
					{
						deflateStream.BufferSize = this._container.CodecBufferSize;
					}
					deflateStream.Strategy = this._container.Strategy;
					return deflateStream;
				}
				if (this._container.ParallelDeflater == null)
				{
					this._container.ParallelDeflater = new ParallelDeflateOutputStream(s, this.CompressionLevel, this._container.Strategy, true);
					if (this._container.CodecBufferSize > 0)
					{
						this._container.ParallelDeflater.BufferSize = this._container.CodecBufferSize;
					}
					if (this._container.ParallelDeflateMaxBufferPairs > 0)
					{
						this._container.ParallelDeflater.MaxBufferPairs = this._container.ParallelDeflateMaxBufferPairs;
					}
				}
				ParallelDeflateOutputStream parallelDeflater = this._container.ParallelDeflater;
				parallelDeflater.Reset(s);
				return parallelDeflater;
			}
			else
			{
				if (this._CompressionMethod == 12)
				{
					if (this._container.ParallelDeflateThreshold != 0L)
					{
						if (streamLength <= this._container.ParallelDeflateThreshold || this._container.ParallelDeflateThreshold <= 0L)
						{
							return new BZip2OutputStream(s, true);
						}
					}
					return new ParallelBZip2OutputStream(s, true);
				}
				return s;
			}
		}

		// Token: 0x06001101 RID: 4353 RVA: 0x00013D81 File Offset: 0x00011F81
		private Stream MaybeApplyEncryption(Stream s)
		{
			if (this.Encryption == EncryptionAlgorithm.PkzipWeak)
			{
				return new ZipCipherStream(s, this._zipCrypto_forWrite, CryptoMode.Encrypt);
			}
			if (this.Encryption != EncryptionAlgorithm.WinZipAes128)
			{
				if (this.Encryption != EncryptionAlgorithm.WinZipAes256)
				{
					return s;
				}
			}
			return new WinZipAesCipherStream(s, this._aesCrypto_forWrite, CryptoMode.Encrypt);
		}

		// Token: 0x06001102 RID: 4354 RVA: 0x00013DBD File Offset: 0x00011FBD
		private void OnZipErrorWhileSaving(Exception e)
		{
			if (this._container.ZipFile != null)
			{
				this._ioOperationCanceled = this._container.ZipFile.OnZipErrorSaving(this, e);
			}
		}

		// Token: 0x06001103 RID: 4355 RVA: 0x0005D034 File Offset: 0x0005B234
		internal void Write(Stream s)
		{
			CountingStream countingStream = s as CountingStream;
			ZipSegmentedStream zipSegmentedStream = s as ZipSegmentedStream;
			bool flag = false;
			do
			{
				try
				{
					if (this._Source == ZipEntrySource.ZipFile && !this._restreamRequiredOnSave)
					{
						this.CopyThroughOneEntry(s);
						break;
					}
					if (this.IsDirectory)
					{
						this.WriteHeader(s, 1);
						this.StoreRelativeOffset();
						this._entryRequiresZip64 = new bool?(this._RelativeOffsetOfLocalHeader >= 4294967295L);
						this._OutputUsesZip64 = new bool?(this._container.Zip64 == Zip64Option.Always || this._entryRequiresZip64.Value);
						if (zipSegmentedStream != null)
						{
							this._diskNumber = zipSegmentedStream.CurrentSegment;
						}
						break;
					}
					int num = 0;
					bool flag2;
					do
					{
						num++;
						this.WriteHeader(s, num);
						this.WriteSecurityMetadata(s);
						this._WriteEntryData(s);
						this._TotalEntrySize = (long)this._LengthOfHeader + this._CompressedFileDataSize + (long)this._LengthOfTrailer;
						flag2 = num <= 1 && ZipEntry.smethod_67(s) && this.WantReadAgain();
						if (flag2)
						{
							if (zipSegmentedStream != null)
							{
								zipSegmentedStream.TruncateBackward(this._diskNumber, this._RelativeOffsetOfLocalHeader);
							}
							else
							{
								ZipEntry.smethod_5(s, this._RelativeOffsetOfLocalHeader, SeekOrigin.Begin);
							}
							ZipEntry.smethod_72(s, ZipEntry.smethod_6(s));
							if (countingStream != null)
							{
								countingStream.Adjust(this._TotalEntrySize);
							}
						}
					}
					while (flag2);
					this._skippedDuringSave = false;
					flag = true;
				}
				catch (Exception ex)
				{
					for (;;)
					{
						IL_03E8:
						int num2 = -1887158887;
						for (;;)
						{
							long num3;
							int num5;
							long num6;
							long num7;
							switch (num2 ^ -1887158893)
							{
							case 0:
								num2 = -1887158886;
								continue;
							case 1:
								if (countingStream != null)
								{
									long num4;
									countingStream.Adjust(num3 - num4);
									num2 = -1887158883;
									continue;
								}
								goto IL_02B2;
							case 2:
								num2 = ((!this._ioOperationCanceled) ? (-1887158891) : (-1887158903));
								continue;
							case 3:
								num5 = 0;
								num2 = -1887158907;
								continue;
							case 4:
								ZipEntry.smethod_72(s, ZipEntry.smethod_6(s));
								num2 = -1887158894;
								continue;
							case 5:
								num2 = ((this.ZipErrorAction == ZipErrorAction.Retry) ? (-1887158911) : (-1887158912));
								continue;
							case 6:
								goto IL_0307;
							case 7:
								this._skippedDuringSave = true;
								num2 = -1887158885;
								continue;
							case 8:
								flag = true;
								num2 = -1887158886;
								continue;
							case 10:
							{
								ZipErrorAction zipErrorAction = this.ZipErrorAction;
								num2 = -1887158896;
								continue;
							}
							case 11:
								if (num6 > 0L)
								{
									ZipEntry.smethod_5(s, num6, SeekOrigin.Current);
									num2 = -1887158910;
									continue;
								}
								goto IL_02B2;
							case 12:
								if (this.ZipErrorAction == ZipErrorAction.InvokeErrorEvent)
								{
									this.OnZipErrorWhileSaving(ex);
									num2 = -1887158895;
									continue;
								}
								goto IL_0307;
							case 13:
								num2 = ((this.ZipErrorAction != ZipErrorAction.Skip) ? (-1887158890) : (-1887158911));
								continue;
							case 14:
								goto IL_02B2;
							case 15:
								this.WriteStatus(<Module>.smethod_24<string>(1133506598U), new object[]
								{
									this.LocalFileName,
									ZipEntry.smethod_4(ex)
								});
								num2 = -1887158892;
								continue;
							case 16:
								goto IL_03F2;
							case 17:
							{
								long num4 = ZipEntry.smethod_6(s);
								num2 = -1887158889;
								continue;
							}
							case 18:
								if (countingStream == null)
								{
									num2 = -1887158906;
									continue;
								}
								num7 = countingStream.ComputedPosition;
								goto IL_0218;
							case 19:
								num2 = ((num5 <= 0) ? (-1887158881) : (-1887158908));
								continue;
							case 20:
								num2 = -1887158907;
								continue;
							case 21:
								num7 = ZipEntry.smethod_6(s);
								goto IL_0218;
							case 22:
								num2 = ((this.ZipErrorAction != ZipErrorAction.Throw) ? (-1887158882) : (-1887158909));
								continue;
							case 23:
								goto IL_03F4;
							case 24:
								goto IL_03E8;
							case 25:
							{
								ZipErrorAction zipErrorAction;
								this.ZipErrorAction = zipErrorAction;
								num2 = -1887158886;
								continue;
							}
							case 26:
								flag = true;
								num2 = -1887158893;
								continue;
							}
							goto Block_14;
							IL_0218:
							num3 = num7;
							num6 = num3 - this._future_ROLH;
							num2 = -1887158888;
							continue;
							IL_02B2:
							num2 = ((this.ZipErrorAction == ZipErrorAction.Skip) ? (-1887158884) : (-1887158902));
							continue;
							IL_0307:
							num5++;
							num2 = -1887158905;
						}
					}
					Block_14:
					goto IL_03F6;
					IL_03F2:
					throw;
					IL_03F4:
					throw;
					IL_03F6:;
				}
			}
			while (!flag);
		}

		// Token: 0x06001104 RID: 4356 RVA: 0x00013DE4 File Offset: 0x00011FE4
		internal void StoreRelativeOffset()
		{
			this._RelativeOffsetOfLocalHeader = this._future_ROLH;
		}

		// Token: 0x06001105 RID: 4357 RVA: 0x00013DF2 File Offset: 0x00011FF2
		internal void NotifySaveComplete()
		{
			this._Encryption_FromZipFile = this._Encryption;
			this._CompressionMethod_FromZipFile = this._CompressionMethod;
			this._restreamRequiredOnSave = false;
			this._metadataChanged = false;
			this._Source = ZipEntrySource.ZipFile;
		}

		// Token: 0x06001106 RID: 4358 RVA: 0x0005D45C File Offset: 0x0005B65C
		internal void WriteSecurityMetadata(Stream outstream)
		{
			if (this.Encryption == EncryptionAlgorithm.None)
			{
				return;
			}
			string text = this._Password;
			if (this._Source == ZipEntrySource.ZipFile)
			{
				if (text == null)
				{
					text = this._container.Password;
				}
			}
			if (text == null)
			{
				this._zipCrypto_forWrite = null;
				this._aesCrypto_forWrite = null;
				return;
			}
			if (this.Encryption == EncryptionAlgorithm.PkzipWeak)
			{
				this._zipCrypto_forWrite = ZipCrypto.ForWrite(text);
				Random random = ZipEntry.smethod_73();
				byte[] array = new byte[12];
				ZipEntry.smethod_74(random, array);
				if ((this._BitField & 8) == 8)
				{
					this._TimeBlob = SharedUtilities.DateTimeToPacked(this.LastModified);
					array[11] = (byte)((this._TimeBlob >> 8) & 255);
				}
				else
				{
					this.FigureCrc32();
					array[11] = (byte)((this._Crc32 >> 24) & 255);
				}
				byte[] array2 = this._zipCrypto_forWrite.EncryptMessage(array, array.Length);
				ZipEntry.smethod_37(outstream, array2, 0, array2.Length);
				this._LengthOfHeader += array2.Length;
				return;
			}
			if (this.Encryption != EncryptionAlgorithm.WinZipAes128)
			{
				if (this.Encryption != EncryptionAlgorithm.WinZipAes256)
				{
					return;
				}
			}
			int keyStrengthInBits = ZipEntry.GetKeyStrengthInBits(this.Encryption);
			this._aesCrypto_forWrite = WinZipAesCrypto.Generate(text, keyStrengthInBits);
			ZipEntry.smethod_37(outstream, this._aesCrypto_forWrite.Salt, 0, this._aesCrypto_forWrite._Salt.Length);
			ZipEntry.smethod_37(outstream, this._aesCrypto_forWrite.GeneratedPV, 0, this._aesCrypto_forWrite.GeneratedPV.Length);
			this._LengthOfHeader += this._aesCrypto_forWrite._Salt.Length + this._aesCrypto_forWrite.GeneratedPV.Length;
		}

		// Token: 0x06001107 RID: 4359 RVA: 0x0005D5E8 File Offset: 0x0005B7E8
		private void CopyThroughOneEntry(Stream outStream)
		{
			if (this.LengthOfHeader == 0)
			{
				throw new BadStateException(<Module>.smethod_24<string>(3572385464U));
			}
			if (this._metadataChanged || this.ArchiveStream is ZipSegmentedStream || outStream is ZipSegmentedStream || (this._InputUsesZip64 && this._container.UseZip64WhenSaving == Zip64Option.Default) || (!this._InputUsesZip64 && this._container.UseZip64WhenSaving == Zip64Option.Always))
			{
				this.CopyThroughWithRecompute(outStream);
			}
			else
			{
				this.CopyThroughWithNoChange(outStream);
			}
			this._entryRequiresZip64 = new bool?(this._CompressedSize >= 4294967295L || this._UncompressedSize >= 4294967295L || this._RelativeOffsetOfLocalHeader >= 4294967295L);
			this._OutputUsesZip64 = new bool?(this._container.Zip64 == Zip64Option.Always || this._entryRequiresZip64.Value);
		}

		// Token: 0x06001108 RID: 4360 RVA: 0x0005D6D8 File Offset: 0x0005B8D8
		private void CopyThroughWithRecompute(Stream outstream)
		{
			byte[] array = new byte[this.BufferSize];
			CountingStream countingStream = new CountingStream(this.ArchiveStream);
			long relativeOffsetOfLocalHeader = this._RelativeOffsetOfLocalHeader;
			int lengthOfHeader = this.LengthOfHeader;
			this.WriteHeader(outstream, 0);
			this.StoreRelativeOffset();
			if (!ZipEntry.smethod_9(this.FileName, <Module>.smethod_24<string>(3061240605U)))
			{
				long num = relativeOffsetOfLocalHeader + (long)lengthOfHeader;
				int num2 = ZipEntry.GetLengthOfCryptoHeaderBytes(this._Encryption_FromZipFile);
				num -= (long)num2;
				this._LengthOfHeader += num2;
				ZipEntry.smethod_5(countingStream, num, SeekOrigin.Begin);
				long num3 = this._CompressedSize;
				while (num3 > 0L)
				{
					num2 = ((num3 > (long)array.Length) ? array.Length : ((int)num3));
					int num4 = ZipEntry.smethod_8(countingStream, array, 0, num2);
					this._CheckRead(num4);
					ZipEntry.smethod_37(outstream, array, 0, num4);
					num3 -= (long)num4;
					this.OnWriteBlock(countingStream.BytesRead, this._CompressedSize);
					if (this._ioOperationCanceled)
					{
						break;
					}
				}
				if ((this._BitField & 8) == 8)
				{
					int num5 = 16;
					if (this._InputUsesZip64)
					{
						num5 += 8;
					}
					byte[] array2 = new byte[num5];
					ZipEntry.smethod_8(countingStream, array2, 0, num5);
					if (this._InputUsesZip64 && this._container.UseZip64WhenSaving == Zip64Option.Default)
					{
						ZipEntry.smethod_37(outstream, array2, 0, 8);
						if (this._CompressedSize > 4294967295L)
						{
							throw ZipEntry.smethod_14(<Module>.smethod_24<string>(3219764214U));
						}
						ZipEntry.smethod_37(outstream, array2, 8, 4);
						if (this._UncompressedSize > 4294967295L)
						{
							throw ZipEntry.smethod_14(<Module>.smethod_24<string>(3219764214U));
						}
						ZipEntry.smethod_37(outstream, array2, 16, 4);
						this._LengthOfTrailer -= 8;
					}
					else
					{
						if (!this._InputUsesZip64)
						{
							if (this._container.UseZip64WhenSaving == Zip64Option.Always)
							{
								byte[] array3 = new byte[4];
								ZipEntry.smethod_37(outstream, array2, 0, 8);
								ZipEntry.smethod_37(outstream, array2, 8, 4);
								ZipEntry.smethod_37(outstream, array3, 0, 4);
								ZipEntry.smethod_37(outstream, array2, 12, 4);
								ZipEntry.smethod_37(outstream, array3, 0, 4);
								this._LengthOfTrailer += 8;
								goto IL_0216;
							}
						}
						ZipEntry.smethod_37(outstream, array2, 0, num5);
					}
				}
			}
			IL_0216:
			this._TotalEntrySize = (long)this._LengthOfHeader + this._CompressedFileDataSize + (long)this._LengthOfTrailer;
		}

		// Token: 0x06001109 RID: 4361 RVA: 0x0005D918 File Offset: 0x0005BB18
		private void CopyThroughWithNoChange(Stream outstream)
		{
			byte[] array = new byte[this.BufferSize];
			for (;;)
			{
				IL_0179:
				int num = 1163433982;
				for (;;)
				{
					long num3;
					int num4;
					int num5;
					switch (num ^ 1163433979)
					{
					case 0:
					{
						int num2;
						this._CheckRead(num2);
						ZipEntry.smethod_37(outstream, array, 0, num2);
						num3 -= (long)num2;
						CountingStream countingStream;
						this.OnWriteBlock(countingStream.BytesRead, this._TotalEntrySize);
						if (this._ioOperationCanceled)
						{
							return;
						}
						goto IL_00F4;
					}
					case 1:
						goto IL_00F4;
					case 2:
					{
						CountingStream countingStream;
						ZipEntry.smethod_5(countingStream, this._RelativeOffsetOfLocalHeader, SeekOrigin.Begin);
						num = 1163433970;
						continue;
					}
					case 3:
						this._TotalEntrySize = (long)this._LengthOfHeader + this._CompressedFileDataSize + (long)this._LengthOfTrailer;
						num = 1163433983;
						continue;
					case 4:
					{
						CountingStream countingStream2 = outstream as CountingStream;
						num = 1163433981;
						continue;
					}
					case 5:
					{
						CountingStream countingStream = new CountingStream(this.ArchiveStream);
						num = 1163433977;
						continue;
					}
					case 6:
					{
						CountingStream countingStream2;
						this._RelativeOffsetOfLocalHeader = ((countingStream2 != null) ? countingStream2.ComputedPosition : ZipEntry.smethod_6(outstream));
						num3 = this._TotalEntrySize;
						num = 1163433978;
						continue;
					}
					case 7:
						goto IL_0179;
					case 8:
						num4 = (int)num3;
						goto IL_003B;
					case 9:
						num = ((this._TotalEntrySize != 0L) ? 1163433983 : 1163433976);
						continue;
					case 10:
						break;
					case 11:
					{
						CountingStream countingStream;
						int num2 = ZipEntry.smethod_8(countingStream, array, 0, num5);
						num = 1163433979;
						continue;
					}
					default:
						goto IL_00F4;
					}
					IL_0027:
					if (num3 <= (long)array.Length)
					{
						num = 1163433971;
						continue;
					}
					num4 = array.Length;
					goto IL_003B;
					IL_00F4:
					if (num3 <= 0L)
					{
						return;
					}
					goto IL_0027;
					IL_003B:
					num5 = num4;
					num = 1163433968;
				}
			}
		}

		// Token: 0x0600110A RID: 4362 RVA: 0x0005DAA8 File Offset: 0x0005BCA8
		[Conditional("Trace")]
		private void TraceWriteLine(string format, params object[] varParams)
		{
			object outputLock;
			ZipEntry.smethod_75(outputLock = this._outputLock);
			try
			{
				int num = ZipEntry.smethod_77(ZipEntry.smethod_76());
				ZipEntry.smethod_78(num % 8 + ConsoleColor.DarkGray);
				ZipEntry.smethod_79(<Module>.smethod_27<string>(3349409705U), num);
				ZipEntry.smethod_80(format, varParams);
				ZipEntry.smethod_81();
			}
			finally
			{
				ZipEntry.smethod_82(outputLock);
			}
		}

		// Token: 0x0600110C RID: 4364 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_0()
		{
			return new StringBuilder();
		}

		// Token: 0x0600110D RID: 4365 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_1(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x0600110E RID: 4366 RVA: 0x0000DB11 File Offset: 0x0000BD11
		static StringBuilder smethod_2(StringBuilder stringBuilder_0, string string_0)
		{
			return stringBuilder_0.Append(string_0);
		}

		// Token: 0x0600110F RID: 4367 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_3(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06001110 RID: 4368 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_4(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06001111 RID: 4369 RVA: 0x00012BED File Offset: 0x00010DED
		static long smethod_5(Stream stream_0, long long_0, SeekOrigin seekOrigin_0)
		{
			return stream_0.Seek(long_0, seekOrigin_0);
		}

		// Token: 0x06001112 RID: 4370 RVA: 0x00012846 File Offset: 0x00010A46
		static long smethod_6(Stream stream_0)
		{
			return stream_0.Position;
		}

		// Token: 0x06001113 RID: 4371 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_7(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x06001114 RID: 4372 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_8(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06001115 RID: 4373 RVA: 0x0000D9AC File Offset: 0x0000BBAC
		static bool smethod_9(string string_0, string string_1)
		{
			return string_0.EndsWith(string_1);
		}

		// Token: 0x06001116 RID: 4374 RVA: 0x0000DB1A File Offset: 0x0000BD1A
		static Encoding smethod_10()
		{
			return Encoding.UTF8;
		}

		// Token: 0x06001117 RID: 4375 RVA: 0x00013209 File Offset: 0x00011409
		static object smethod_11()
		{
			return new object();
		}

		// Token: 0x06001118 RID: 4376 RVA: 0x0001282F File Offset: 0x00010A2F
		static Encoding smethod_12(string string_0)
		{
			return Encoding.GetEncoding(string_0);
		}

		// Token: 0x06001119 RID: 4377 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_13(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x0600111A RID: 4378 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_14(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x0600111B RID: 4379 RVA: 0x0000CFF4 File Offset: 0x0000B1F4
		static string smethod_15(string string_0)
		{
			return Path.GetFileName(string_0);
		}

		// Token: 0x0600111C RID: 4380 RVA: 0x0000C656 File Offset: 0x0000A856
		static string smethod_16(string string_0, string string_1)
		{
			return Path.Combine(string_0, string_1);
		}

		// Token: 0x0600111D RID: 4381 RVA: 0x00013E21 File Offset: 0x00012021
		static DateTime smethod_17(string string_0)
		{
			return File.GetLastWriteTime(string_0);
		}

		// Token: 0x0600111E RID: 4382 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_18(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x0600111F RID: 4383 RVA: 0x00012BE5 File Offset: 0x00010DE5
		static long smethod_19(Stream stream_0)
		{
			return stream_0.Length;
		}

		// Token: 0x06001120 RID: 4384 RVA: 0x0000CD96 File Offset: 0x0000AF96
		static string smethod_20(string string_0, object object_0, object object_1, object object_2)
		{
			return string.Format(string_0, object_0, object_1, object_2);
		}

		// Token: 0x06001121 RID: 4385 RVA: 0x00012F3E File Offset: 0x0001113E
		static FileAttributes smethod_21(string string_0)
		{
			return File.GetAttributes(string_0);
		}

		// Token: 0x06001122 RID: 4386 RVA: 0x00013E29 File Offset: 0x00012029
		static void smethod_22(string string_0, FileAttributes fileAttributes_0)
		{
			File.SetAttributes(string_0, fileAttributes_0);
		}

		// Token: 0x06001123 RID: 4387 RVA: 0x0000C7ED File Offset: 0x0000A9ED
		static void smethod_23(string string_0)
		{
			File.Delete(string_0);
		}

		// Token: 0x06001124 RID: 4388 RVA: 0x00013E32 File Offset: 0x00012032
		static void smethod_24(TextWriter textWriter_0, string string_0, object[] object_0)
		{
			textWriter_0.WriteLine(string_0, object_0);
		}

		// Token: 0x06001125 RID: 4389 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_25(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x06001126 RID: 4390 RVA: 0x0000C681 File Offset: 0x0000A881
		static bool smethod_26(string string_0)
		{
			return File.Exists(string_0);
		}

		// Token: 0x06001127 RID: 4391 RVA: 0x00013371 File Offset: 0x00011571
		static string smethod_27()
		{
			return Path.GetRandomFileName();
		}

		// Token: 0x06001128 RID: 4392 RVA: 0x0000C66E File Offset: 0x0000A86E
		static string smethod_28(string string_0)
		{
			return Path.GetDirectoryName(string_0);
		}

		// Token: 0x06001129 RID: 4393 RVA: 0x00012E9A File Offset: 0x0001109A
		static void smethod_29(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x0600112A RID: 4394 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_30(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x0600112B RID: 4395 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_31(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x0600112C RID: 4396 RVA: 0x0000CD60 File Offset: 0x0000AF60
		static void smethod_32(string string_0, string string_1)
		{
			File.Move(string_0, string_1);
		}

		// Token: 0x0600112D RID: 4397 RVA: 0x0000FABD File Offset: 0x0000DCBD
		static int smethod_33(string string_0, char char_0)
		{
			return string_0.IndexOf(char_0);
		}

		// Token: 0x0600112E RID: 4398 RVA: 0x0000D8B1 File Offset: 0x0000BAB1
		static bool smethod_34(string string_0)
		{
			return Directory.Exists(string_0);
		}

		// Token: 0x0600112F RID: 4399 RVA: 0x00013E3C File Offset: 0x0001203C
		static DirectoryInfo smethod_35(string string_0)
		{
			return Directory.CreateDirectory(string_0);
		}

		// Token: 0x06001130 RID: 4400 RVA: 0x00012D7D File Offset: 0x00010F7D
		static FileStream smethod_36(string string_0, FileMode fileMode_0)
		{
			return new FileStream(string_0, fileMode_0);
		}

		// Token: 0x06001131 RID: 4401 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_37(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x06001132 RID: 4402 RVA: 0x0000FB13 File Offset: 0x0000DD13
		static void smethod_38(Stream stream_0)
		{
			stream_0.Dispose();
		}

		// Token: 0x06001133 RID: 4403 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_39(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x06001134 RID: 4404 RVA: 0x00013E44 File Offset: 0x00012044
		static void smethod_40(string string_0, DateTime dateTime_0)
		{
			File.SetCreationTimeUtc(string_0, dateTime_0);
		}

		// Token: 0x06001135 RID: 4405 RVA: 0x00013E4D File Offset: 0x0001204D
		static void smethod_41(string string_0, DateTime dateTime_0)
		{
			File.SetLastAccessTimeUtc(string_0, dateTime_0);
		}

		// Token: 0x06001136 RID: 4406 RVA: 0x00013E56 File Offset: 0x00012056
		static void smethod_42(string string_0, DateTime dateTime_0)
		{
			File.SetLastWriteTimeUtc(string_0, dateTime_0);
		}

		// Token: 0x06001137 RID: 4407 RVA: 0x00013E5F File Offset: 0x0001205F
		static void smethod_43(string string_0, DateTime dateTime_0)
		{
			Directory.SetCreationTimeUtc(string_0, dateTime_0);
		}

		// Token: 0x06001138 RID: 4408 RVA: 0x00013E68 File Offset: 0x00012068
		static void smethod_44(string string_0, DateTime dateTime_0)
		{
			Directory.SetLastAccessTimeUtc(string_0, dateTime_0);
		}

		// Token: 0x06001139 RID: 4409 RVA: 0x00013E71 File Offset: 0x00012071
		static void smethod_45(string string_0, DateTime dateTime_0)
		{
			Directory.SetLastWriteTimeUtc(string_0, dateTime_0);
		}

		// Token: 0x0600113A RID: 4410 RVA: 0x00013E7A File Offset: 0x0001207A
		static void smethod_46(string string_0, DateTime dateTime_0)
		{
			File.SetLastWriteTime(string_0, dateTime_0);
		}

		// Token: 0x0600113B RID: 4411 RVA: 0x00013E83 File Offset: 0x00012083
		static void smethod_47(string string_0, DateTime dateTime_0)
		{
			Directory.SetLastWriteTime(string_0, dateTime_0);
		}

		// Token: 0x0600113C RID: 4412 RVA: 0x0000D3E3 File Offset: 0x0000B5E3
		static string smethod_48(Exception exception_0)
		{
			return exception_0.Message;
		}

		// Token: 0x0600113D RID: 4413 RVA: 0x0000CD69 File Offset: 0x0000AF69
		static string smethod_49(string string_0, char char_0, char char_1)
		{
			return string_0.Replace(char_0, char_1);
		}

		// Token: 0x0600113E RID: 4414 RVA: 0x0000D416 File Offset: 0x0000B616
		static string smethod_50(string string_0, int int_0)
		{
			return string_0.Substring(int_0);
		}

		// Token: 0x0600113F RID: 4415 RVA: 0x0000DB96 File Offset: 0x0000BD96
		static bool smethod_51(string string_0, string string_1)
		{
			return string_0.StartsWith(string_1);
		}

		// Token: 0x06001140 RID: 4416 RVA: 0x0000DF79 File Offset: 0x0000C179
		static string smethod_52(Encoding encoding_0, byte[] byte_0, int int_0, int int_1)
		{
			return encoding_0.GetString(byte_0, int_0, int_1);
		}

		// Token: 0x06001141 RID: 4417 RVA: 0x00013E8C File Offset: 0x0001208C
		static long smethod_53(byte[] byte_0, int int_0)
		{
			return BitConverter.ToInt64(byte_0, int_0);
		}

		// Token: 0x06001142 RID: 4418 RVA: 0x00013E95 File Offset: 0x00012095
		static short smethod_54(byte[] byte_0, int int_0)
		{
			return BitConverter.ToInt16(byte_0, int_0);
		}

		// Token: 0x06001143 RID: 4419 RVA: 0x00013E9E File Offset: 0x0001209E
		static int smethod_55(byte[] byte_0, int int_0)
		{
			return BitConverter.ToInt32(byte_0, int_0);
		}

		// Token: 0x06001144 RID: 4420 RVA: 0x00013254 File Offset: 0x00011454
		static void smethod_56(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Buffer.BlockCopy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x06001145 RID: 4421 RVA: 0x00013EA7 File Offset: 0x000120A7
		static byte[] smethod_57(long long_0)
		{
			return BitConverter.GetBytes(long_0);
		}

		// Token: 0x06001146 RID: 4422 RVA: 0x0000C3EE File Offset: 0x0000A5EE
		static void smethod_58(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Array.Copy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x06001147 RID: 4423 RVA: 0x00012D75 File Offset: 0x00010F75
		static byte[] smethod_59(int int_0)
		{
			return BitConverter.GetBytes(int_0);
		}

		// Token: 0x06001148 RID: 4424 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_60(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x06001149 RID: 4425 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_61(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x0600114A RID: 4426 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_62(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x0600114B RID: 4427 RVA: 0x0000EE25 File Offset: 0x0000D025
		static int smethod_63(string string_0, char char_0, int int_0)
		{
			return string_0.IndexOf(char_0, int_0);
		}

		// Token: 0x0600114C RID: 4428 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_64(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x0600114D RID: 4429 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_65(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x0600114E RID: 4430 RVA: 0x0000CDA1 File Offset: 0x0000AFA1
		static bool smethod_66(string string_0, string string_1)
		{
			return string_0 != string_1;
		}

		// Token: 0x0600114F RID: 4431 RVA: 0x00012BF7 File Offset: 0x00010DF7
		static bool smethod_67(Stream stream_0)
		{
			return stream_0.CanSeek;
		}

		// Token: 0x06001150 RID: 4432 RVA: 0x00013EAF File Offset: 0x000120AF
		static int smethod_68(Encoding encoding_0)
		{
			return encoding_0.CodePage;
		}

		// Token: 0x06001151 RID: 4433 RVA: 0x0000FB08 File Offset: 0x0000DD08
		static FileStream smethod_69(string string_0, FileMode fileMode_0, FileAccess fileAccess_0, FileShare fileShare_0)
		{
			return File.Open(string_0, fileMode_0, fileAccess_0, fileShare_0);
		}

		// Token: 0x06001152 RID: 4434 RVA: 0x00012D96 File Offset: 0x00010F96
		static void smethod_70(Stream stream_0, long long_0)
		{
			stream_0.Position = long_0;
		}

		// Token: 0x06001153 RID: 4435 RVA: 0x00012D8E File Offset: 0x00010F8E
		static void smethod_71(Stream stream_0)
		{
			stream_0.Flush();
		}

		// Token: 0x06001154 RID: 4436 RVA: 0x00012D9F File Offset: 0x00010F9F
		static void smethod_72(Stream stream_0, long long_0)
		{
			stream_0.SetLength(long_0);
		}

		// Token: 0x06001155 RID: 4437 RVA: 0x0000D808 File Offset: 0x0000BA08
		static Random smethod_73()
		{
			return new Random();
		}

		// Token: 0x06001156 RID: 4438 RVA: 0x0001319A File Offset: 0x0001139A
		static void smethod_74(Random random_0, byte[] byte_0)
		{
			random_0.NextBytes(byte_0);
		}

		// Token: 0x06001157 RID: 4439 RVA: 0x00013261 File Offset: 0x00011461
		static void smethod_75(object object_0)
		{
			Monitor.Enter(object_0);
		}

		// Token: 0x06001158 RID: 4440 RVA: 0x00013269 File Offset: 0x00011469
		static Thread smethod_76()
		{
			return Thread.CurrentThread;
		}

		// Token: 0x06001159 RID: 4441 RVA: 0x0000CF7A File Offset: 0x0000B17A
		static int smethod_77(object object_0)
		{
			return object_0.GetHashCode();
		}

		// Token: 0x0600115A RID: 4442 RVA: 0x00013270 File Offset: 0x00011470
		static void smethod_78(ConsoleColor consoleColor_0)
		{
			Console.ForegroundColor = consoleColor_0;
		}

		// Token: 0x0600115B RID: 4443 RVA: 0x00013278 File Offset: 0x00011478
		static void smethod_79(string string_0, object object_0)
		{
			Console.Write(string_0, object_0);
		}

		// Token: 0x0600115C RID: 4444 RVA: 0x00013082 File Offset: 0x00011282
		static void smethod_80(string string_0, object[] object_0)
		{
			Console.WriteLine(string_0, object_0);
		}

		// Token: 0x0600115D RID: 4445 RVA: 0x00013281 File Offset: 0x00011481
		static void smethod_81()
		{
			Console.ResetColor();
		}

		// Token: 0x0600115E RID: 4446 RVA: 0x0000DBEF File Offset: 0x0000BDEF
		static void smethod_82(object object_0)
		{
			Monitor.Exit(object_0);
		}

		// Token: 0x0400057D RID: 1405
		private short _VersionMadeBy;

		// Token: 0x0400057E RID: 1406
		private short _InternalFileAttrs;

		// Token: 0x0400057F RID: 1407
		private int _ExternalFileAttrs;

		// Token: 0x04000580 RID: 1408
		private short _filenameLength;

		// Token: 0x04000581 RID: 1409
		private short _extraFieldLength;

		// Token: 0x04000582 RID: 1410
		private short _commentLength;

		// Token: 0x04000583 RID: 1411
		private ZipCrypto _zipCrypto_forExtract;

		// Token: 0x04000584 RID: 1412
		private ZipCrypto _zipCrypto_forWrite;

		// Token: 0x04000585 RID: 1413
		private WinZipAesCrypto _aesCrypto_forExtract;

		// Token: 0x04000586 RID: 1414
		private WinZipAesCrypto _aesCrypto_forWrite;

		// Token: 0x04000587 RID: 1415
		private short _WinZipAesMethod;

		// Token: 0x04000588 RID: 1416
		internal DateTime _LastModified;

		// Token: 0x04000589 RID: 1417
		private DateTime _Mtime;

		// Token: 0x0400058A RID: 1418
		private DateTime _Atime;

		// Token: 0x0400058B RID: 1419
		private DateTime _Ctime;

		// Token: 0x0400058C RID: 1420
		private bool _ntfsTimesAreSet;

		// Token: 0x0400058D RID: 1421
		private bool _emitNtfsTimes = true;

		// Token: 0x0400058E RID: 1422
		private bool _emitUnixTimes;

		// Token: 0x0400058F RID: 1423
		private bool _TrimVolumeFromFullyQualifiedPaths = true;

		// Token: 0x04000590 RID: 1424
		internal string _LocalFileName;

		// Token: 0x04000591 RID: 1425
		private string _FileNameInArchive;

		// Token: 0x04000592 RID: 1426
		internal short _VersionNeeded;

		// Token: 0x04000593 RID: 1427
		internal short _BitField;

		// Token: 0x04000594 RID: 1428
		internal short _CompressionMethod;

		// Token: 0x04000595 RID: 1429
		private short _CompressionMethod_FromZipFile;

		// Token: 0x04000596 RID: 1430
		private CompressionLevel _CompressionLevel;

		// Token: 0x04000597 RID: 1431
		internal string _Comment;

		// Token: 0x04000598 RID: 1432
		private bool _IsDirectory;

		// Token: 0x04000599 RID: 1433
		private byte[] _CommentBytes;

		// Token: 0x0400059A RID: 1434
		internal long _CompressedSize;

		// Token: 0x0400059B RID: 1435
		internal long _CompressedFileDataSize;

		// Token: 0x0400059C RID: 1436
		internal long _UncompressedSize;

		// Token: 0x0400059D RID: 1437
		internal int _TimeBlob;

		// Token: 0x0400059E RID: 1438
		private bool _crcCalculated;

		// Token: 0x0400059F RID: 1439
		internal int _Crc32;

		// Token: 0x040005A0 RID: 1440
		internal byte[] _Extra;

		// Token: 0x040005A1 RID: 1441
		private bool _metadataChanged;

		// Token: 0x040005A2 RID: 1442
		private bool _restreamRequiredOnSave;

		// Token: 0x040005A3 RID: 1443
		private bool _sourceIsEncrypted;

		// Token: 0x040005A4 RID: 1444
		private bool _skippedDuringSave;

		// Token: 0x040005A5 RID: 1445
		private uint _diskNumber;

		// Token: 0x040005A6 RID: 1446
		private static Encoding ibm437 = ZipEntry.smethod_12(<Module>.smethod_25<string>(1316389748U));

		// Token: 0x040005A7 RID: 1447
		private Encoding _actualEncoding;

		// Token: 0x040005A8 RID: 1448
		internal ZipContainer _container;

		// Token: 0x040005A9 RID: 1449
		private long __FileDataPosition = -1L;

		// Token: 0x040005AA RID: 1450
		private byte[] _EntryHeader;

		// Token: 0x040005AB RID: 1451
		internal long _RelativeOffsetOfLocalHeader;

		// Token: 0x040005AC RID: 1452
		private long _future_ROLH;

		// Token: 0x040005AD RID: 1453
		private long _TotalEntrySize;

		// Token: 0x040005AE RID: 1454
		private int _LengthOfHeader;

		// Token: 0x040005AF RID: 1455
		private int _LengthOfTrailer;

		// Token: 0x040005B0 RID: 1456
		internal bool _InputUsesZip64;

		// Token: 0x040005B1 RID: 1457
		private uint _UnsupportedAlgorithmId;

		// Token: 0x040005B2 RID: 1458
		internal string _Password;

		// Token: 0x040005B3 RID: 1459
		internal ZipEntrySource _Source;

		// Token: 0x040005B4 RID: 1460
		internal EncryptionAlgorithm _Encryption;

		// Token: 0x040005B5 RID: 1461
		internal EncryptionAlgorithm _Encryption_FromZipFile;

		// Token: 0x040005B6 RID: 1462
		internal byte[] _WeakEncryptionHeader;

		// Token: 0x040005B7 RID: 1463
		internal Stream _archiveStream;

		// Token: 0x040005B8 RID: 1464
		private Stream _sourceStream;

		// Token: 0x040005B9 RID: 1465
		private long? _sourceStreamOriginalPosition;

		// Token: 0x040005BA RID: 1466
		private bool _sourceWasJitProvided;

		// Token: 0x040005BB RID: 1467
		private bool _ioOperationCanceled;

		// Token: 0x040005BC RID: 1468
		private bool _presumeZip64;

		// Token: 0x040005BD RID: 1469
		private bool? _entryRequiresZip64;

		// Token: 0x040005BE RID: 1470
		private bool? _OutputUsesZip64;

		// Token: 0x040005BF RID: 1471
		private bool _IsText;

		// Token: 0x040005C0 RID: 1472
		private ZipEntryTimestamp _timestamp;

		// Token: 0x040005C1 RID: 1473
		private static DateTime _unixEpoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

		// Token: 0x040005C2 RID: 1474
		private static DateTime _win32Epoch = DateTime.FromFileTimeUtc(0L);

		// Token: 0x040005C3 RID: 1475
		private static DateTime _zeroHour = new DateTime(1, 1, 1, 0, 0, 0, DateTimeKind.Utc);

		// Token: 0x040005C4 RID: 1476
		private WriteDelegate _WriteDelegate;

		// Token: 0x040005C5 RID: 1477
		private OpenDelegate _OpenDelegate;

		// Token: 0x040005C6 RID: 1478
		private CloseDelegate _CloseDelegate;

		// Token: 0x040005C7 RID: 1479
		private Stream _inputDecryptorStream;

		// Token: 0x040005C8 RID: 1480
		private int _readExtraDepth;

		// Token: 0x040005C9 RID: 1481
		private object _outputLock = ZipEntry.smethod_11();

		// Token: 0x02000119 RID: 281
		private class CopyHelper
		{
			// Token: 0x0600115F RID: 4447 RVA: 0x0005DB70 File Offset: 0x0005BD70
			internal static string AppendCopyToFileName(string f)
			{
				ZipEntry.CopyHelper.callCount++;
				if (ZipEntry.CopyHelper.callCount > 25)
				{
					throw ZipEntry.CopyHelper.smethod_0(<Module>.smethod_26<string>(3553861904U));
				}
				int num = 1;
				int num2 = ZipEntry.CopyHelper.smethod_1(f, <Module>.smethod_23<string>(386296197U));
				if (num2 != -1)
				{
					Match match = ZipEntry.CopyHelper.smethod_2(ZipEntry.CopyHelper.re, ZipEntry.CopyHelper.smethod_9(f, 0, num2));
					if (ZipEntry.CopyHelper.smethod_3(match))
					{
						num = int.Parse(ZipEntry.CopyHelper.smethod_6(ZipEntry.CopyHelper.smethod_5(ZipEntry.CopyHelper.smethod_4(match), 1))) + 1;
						string text = ZipEntry.CopyHelper.smethod_7(<Module>.smethod_26<string>(4277670115U), num);
						f = ZipEntry.CopyHelper.smethod_12(ZipEntry.CopyHelper.smethod_9(f, 0, ZipEntry.CopyHelper.smethod_8(match)), text, ZipEntry.CopyHelper.smethod_11(f, num2));
					}
					else
					{
						string text2 = ZipEntry.CopyHelper.smethod_7(<Module>.smethod_27<string>(2603462617U), num);
						f = ZipEntry.CopyHelper.smethod_12(ZipEntry.CopyHelper.smethod_9(f, 0, num2), text2, ZipEntry.CopyHelper.smethod_11(f, num2));
					}
				}
				else
				{
					Match match2 = ZipEntry.CopyHelper.smethod_2(ZipEntry.CopyHelper.re, f);
					if (ZipEntry.CopyHelper.smethod_3(match2))
					{
						num = int.Parse(ZipEntry.CopyHelper.smethod_6(ZipEntry.CopyHelper.smethod_5(ZipEntry.CopyHelper.smethod_4(match2), 1))) + 1;
						string text3 = ZipEntry.CopyHelper.smethod_7(<Module>.smethod_27<string>(2603462617U), num);
						f = ZipEntry.CopyHelper.smethod_10(ZipEntry.CopyHelper.smethod_9(f, 0, ZipEntry.CopyHelper.smethod_8(match2)), text3);
					}
					else
					{
						string text4 = ZipEntry.CopyHelper.smethod_7(<Module>.smethod_25<string>(376860490U), num);
						f = ZipEntry.CopyHelper.smethod_10(f, text4);
					}
				}
				return f;
			}

			// Token: 0x06001162 RID: 4450 RVA: 0x00013ED3 File Offset: 0x000120D3
			static OverflowException smethod_0(string string_0)
			{
				return new OverflowException(string_0);
			}

			// Token: 0x06001163 RID: 4451 RVA: 0x00013EDB File Offset: 0x000120DB
			static int smethod_1(string string_0, string string_1)
			{
				return string_0.LastIndexOf(string_1);
			}

			// Token: 0x06001164 RID: 4452 RVA: 0x00013EE4 File Offset: 0x000120E4
			static Match smethod_2(Regex regex_0, string string_0)
			{
				return regex_0.Match(string_0);
			}

			// Token: 0x06001165 RID: 4453 RVA: 0x00013EED File Offset: 0x000120ED
			static bool smethod_3(Group group_0)
			{
				return group_0.Success;
			}

			// Token: 0x06001166 RID: 4454 RVA: 0x00013EF5 File Offset: 0x000120F5
			static GroupCollection smethod_4(Match match_0)
			{
				return match_0.Groups;
			}

			// Token: 0x06001167 RID: 4455 RVA: 0x00013EFD File Offset: 0x000120FD
			static Group smethod_5(GroupCollection groupCollection_0, int int_0)
			{
				return groupCollection_0[int_0];
			}

			// Token: 0x06001168 RID: 4456 RVA: 0x0000EAD9 File Offset: 0x0000CCD9
			static string smethod_6(Capture capture_0)
			{
				return capture_0.Value;
			}

			// Token: 0x06001169 RID: 4457 RVA: 0x0000CD57 File Offset: 0x0000AF57
			static string smethod_7(string string_0, object object_0)
			{
				return string.Format(string_0, object_0);
			}

			// Token: 0x0600116A RID: 4458 RVA: 0x0000FE66 File Offset: 0x0000E066
			static int smethod_8(Capture capture_0)
			{
				return capture_0.Index;
			}

			// Token: 0x0600116B RID: 4459 RVA: 0x0000CD73 File Offset: 0x0000AF73
			static string smethod_9(string string_0, int int_0, int int_1)
			{
				return string_0.Substring(int_0, int_1);
			}

			// Token: 0x0600116C RID: 4460 RVA: 0x0000D41F File Offset: 0x0000B61F
			static string smethod_10(string string_0, string string_1)
			{
				return string_0 + string_1;
			}

			// Token: 0x0600116D RID: 4461 RVA: 0x0000D416 File Offset: 0x0000B616
			static string smethod_11(string string_0, int int_0)
			{
				return string_0.Substring(int_0);
			}

			// Token: 0x0600116E RID: 4462 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
			static string smethod_12(string string_0, string string_1, string string_2)
			{
				return string_0 + string_1 + string_2;
			}

			// Token: 0x0600116F RID: 4463 RVA: 0x00013399 File Offset: 0x00011599
			static Regex smethod_13(string string_0)
			{
				return new Regex(string_0);
			}

			// Token: 0x040005D0 RID: 1488
			private static Regex re = ZipEntry.CopyHelper.smethod_13(<Module>.smethod_25<string>(1212029926U));

			// Token: 0x040005D1 RID: 1489
			private static int callCount = 0;
		}

		// Token: 0x0200011A RID: 282
		// (Invoke) Token: 0x06001171 RID: 4465
		private delegate T Func<T>();
	}
}
