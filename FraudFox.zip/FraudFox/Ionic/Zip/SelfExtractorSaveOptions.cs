﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x02000129 RID: 297
	[ComVisible(true)]
	public class SelfExtractorSaveOptions
	{
		// Token: 0x170002C4 RID: 708
		// (get) Token: 0x060012E8 RID: 4840 RVA: 0x00014870 File Offset: 0x00012A70
		// (set) Token: 0x060012E9 RID: 4841 RVA: 0x00014878 File Offset: 0x00012A78
		public SelfExtractorFlavor Flavor { get; set; }

		// Token: 0x170002C5 RID: 709
		// (get) Token: 0x060012EA RID: 4842 RVA: 0x00014881 File Offset: 0x00012A81
		// (set) Token: 0x060012EB RID: 4843 RVA: 0x00014889 File Offset: 0x00012A89
		public string PostExtractCommandLine { get; set; }

		// Token: 0x170002C6 RID: 710
		// (get) Token: 0x060012EC RID: 4844 RVA: 0x00014892 File Offset: 0x00012A92
		// (set) Token: 0x060012ED RID: 4845 RVA: 0x0001489A File Offset: 0x00012A9A
		public string DefaultExtractDirectory { get; set; }

		// Token: 0x170002C7 RID: 711
		// (get) Token: 0x060012EE RID: 4846 RVA: 0x000148A3 File Offset: 0x00012AA3
		// (set) Token: 0x060012EF RID: 4847 RVA: 0x000148AB File Offset: 0x00012AAB
		public string IconFile { get; set; }

		// Token: 0x170002C8 RID: 712
		// (get) Token: 0x060012F0 RID: 4848 RVA: 0x000148B4 File Offset: 0x00012AB4
		// (set) Token: 0x060012F1 RID: 4849 RVA: 0x000148BC File Offset: 0x00012ABC
		public bool Quiet { get; set; }

		// Token: 0x170002C9 RID: 713
		// (get) Token: 0x060012F2 RID: 4850 RVA: 0x000148C5 File Offset: 0x00012AC5
		// (set) Token: 0x060012F3 RID: 4851 RVA: 0x000148CD File Offset: 0x00012ACD
		public ExtractExistingFileAction ExtractExistingFile { get; set; }

		// Token: 0x170002CA RID: 714
		// (get) Token: 0x060012F4 RID: 4852 RVA: 0x000148D6 File Offset: 0x00012AD6
		// (set) Token: 0x060012F5 RID: 4853 RVA: 0x000148DE File Offset: 0x00012ADE
		public bool RemoveUnpackedFilesAfterExecute { get; set; }

		// Token: 0x170002CB RID: 715
		// (get) Token: 0x060012F6 RID: 4854 RVA: 0x000148E7 File Offset: 0x00012AE7
		// (set) Token: 0x060012F7 RID: 4855 RVA: 0x000148EF File Offset: 0x00012AEF
		public Version FileVersion { get; set; }

		// Token: 0x170002CC RID: 716
		// (get) Token: 0x060012F8 RID: 4856 RVA: 0x000148F8 File Offset: 0x00012AF8
		// (set) Token: 0x060012F9 RID: 4857 RVA: 0x00014900 File Offset: 0x00012B00
		public string ProductVersion { get; set; }

		// Token: 0x170002CD RID: 717
		// (get) Token: 0x060012FA RID: 4858 RVA: 0x00014909 File Offset: 0x00012B09
		// (set) Token: 0x060012FB RID: 4859 RVA: 0x00014911 File Offset: 0x00012B11
		public string Copyright { get; set; }

		// Token: 0x170002CE RID: 718
		// (get) Token: 0x060012FC RID: 4860 RVA: 0x0001491A File Offset: 0x00012B1A
		// (set) Token: 0x060012FD RID: 4861 RVA: 0x00014922 File Offset: 0x00012B22
		public string Description { get; set; }

		// Token: 0x170002CF RID: 719
		// (get) Token: 0x060012FE RID: 4862 RVA: 0x0001492B File Offset: 0x00012B2B
		// (set) Token: 0x060012FF RID: 4863 RVA: 0x00014933 File Offset: 0x00012B33
		public string ProductName { get; set; }

		// Token: 0x170002D0 RID: 720
		// (get) Token: 0x06001300 RID: 4864 RVA: 0x0001493C File Offset: 0x00012B3C
		// (set) Token: 0x06001301 RID: 4865 RVA: 0x00014944 File Offset: 0x00012B44
		public string SfxExeWindowTitle { get; set; }

		// Token: 0x170002D1 RID: 721
		// (get) Token: 0x06001302 RID: 4866 RVA: 0x0001494D File Offset: 0x00012B4D
		// (set) Token: 0x06001303 RID: 4867 RVA: 0x00014955 File Offset: 0x00012B55
		public string AdditionalCompilerSwitches { get; set; }
	}
}
