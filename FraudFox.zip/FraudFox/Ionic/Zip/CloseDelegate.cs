﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x0200010F RID: 271
	// (Invoke) Token: 0x0600102C RID: 4140
	[ComVisible(true)]
	public delegate void CloseDelegate(string entryName, Stream stream);
}
