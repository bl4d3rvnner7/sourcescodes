﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;

namespace Ionic.Zip
{
	// Token: 0x02000127 RID: 295
	internal static class ZipOutput
	{
		// Token: 0x060012D1 RID: 4817 RVA: 0x0006238C File Offset: 0x0006058C
		public static bool WriteCentralDirectoryStructure(Stream s, ICollection<ZipEntry> entries, uint numSegments, Zip64Option zip64, string comment, ZipContainer container)
		{
			ZipSegmentedStream zipSegmentedStream = s as ZipSegmentedStream;
			if (zipSegmentedStream != null)
			{
				zipSegmentedStream.ContiguousWrite = true;
			}
			long num = 0L;
			MemoryStream memoryStream = ZipOutput.smethod_0();
			try
			{
				IEnumerator<ZipEntry> enumerator = entries.GetEnumerator();
				try
				{
					while (ZipOutput.smethod_1(enumerator))
					{
						ZipEntry zipEntry = enumerator.Current;
						if (zipEntry.IncludedInMostRecentSave)
						{
							zipEntry.WriteCentralDirectoryEntry(memoryStream);
						}
					}
				}
				finally
				{
					if (enumerator != null)
					{
						ZipOutput.smethod_2(enumerator);
					}
				}
				byte[] array = ZipOutput.smethod_3(memoryStream);
				ZipOutput.smethod_4(s, array, 0, array.Length);
				num = (long)array.Length;
			}
			finally
			{
				if (memoryStream != null)
				{
					ZipOutput.smethod_2(memoryStream);
				}
			}
			CountingStream countingStream = s as CountingStream;
			long num2 = ((countingStream != null) ? countingStream.ComputedPosition : ZipOutput.smethod_5(s));
			long num3 = num2 - num;
			uint num4 = ((zipSegmentedStream != null) ? zipSegmentedStream.CurrentSegment : 0U);
			long num5 = num2 - num3;
			int num6 = ZipOutput.CountEntries(entries);
			bool flag = zip64 == Zip64Option.Always || num6 >= 65535 || num5 > 4294967295L || num3 > 4294967295L;
			byte[] array3;
			if (flag)
			{
				if (zip64 == Zip64Option.Default)
				{
					StackFrame stackFrame = ZipOutput.smethod_6(1);
					if (ZipOutput.smethod_8(ZipOutput.smethod_7(stackFrame)) == ZipOutput.smethod_9(typeof(ZipFile).TypeHandle))
					{
						throw new ZipException(<Module>.smethod_25<string>(3747058822U));
					}
					throw new ZipException(<Module>.smethod_23<string>(3296623041U));
				}
				else
				{
					byte[] array2 = ZipOutput.GenZip64EndOfCentralDirectory(num3, num2, num6, numSegments);
					array3 = ZipOutput.GenCentralDirectoryFooter(num3, num2, zip64, num6, comment, container);
					if (num4 != 0U)
					{
						uint num7 = zipSegmentedStream.ComputeSegment(array2.Length + array3.Length);
						ZipOutput.smethod_11(ZipOutput.smethod_10(num7), 0, array2, 16, 4);
						ZipOutput.smethod_11(ZipOutput.smethod_10(num7), 0, array2, 20, 4);
						ZipOutput.smethod_11(ZipOutput.smethod_10(num7), 0, array2, 60, 4);
						ZipOutput.smethod_11(ZipOutput.smethod_10(num7), 0, array2, 72, 4);
					}
					ZipOutput.smethod_4(s, array2, 0, array2.Length);
				}
			}
			else
			{
				array3 = ZipOutput.GenCentralDirectoryFooter(num3, num2, zip64, num6, comment, container);
			}
			if (num4 != 0U)
			{
				ushort num8 = (ushort)zipSegmentedStream.ComputeSegment(array3.Length);
				ZipOutput.smethod_11(ZipOutput.smethod_12(num8), 0, array3, 4, 2);
				ZipOutput.smethod_11(ZipOutput.smethod_12(num8), 0, array3, 6, 2);
			}
			ZipOutput.smethod_4(s, array3, 0, array3.Length);
			if (zipSegmentedStream != null)
			{
				zipSegmentedStream.ContiguousWrite = false;
			}
			return flag;
		}

		// Token: 0x060012D2 RID: 4818 RVA: 0x000625D8 File Offset: 0x000607D8
		private static Encoding GetEncoding(ZipContainer container, string t)
		{
			switch (container.AlternateEncodingUsage)
			{
			case ZipOption.Default:
				return container.DefaultEncoding;
			case ZipOption.Always:
				return container.AlternateEncoding;
			}
			Encoding defaultEncoding = container.DefaultEncoding;
			if (t == null)
			{
				return defaultEncoding;
			}
			byte[] array = ZipOutput.smethod_13(defaultEncoding, t);
			string text = ZipOutput.smethod_14(defaultEncoding, array, 0, array.Length);
			if (ZipOutput.smethod_15(text, t))
			{
				return defaultEncoding;
			}
			return container.AlternateEncoding;
		}

		// Token: 0x060012D3 RID: 4819 RVA: 0x00062640 File Offset: 0x00060840
		private static byte[] GenCentralDirectoryFooter(long StartOfCentralDirectory, long EndOfCentralDirectory, Zip64Option zip64, int entryCount, string comment, ZipContainer container)
		{
			Encoding encoding = ZipOutput.GetEncoding(container, comment);
			int num = 22;
			byte[] array = null;
			short num2 = 0;
			if (comment != null && ZipOutput.smethod_16(comment) != 0)
			{
				array = ZipOutput.smethod_13(encoding, comment);
				num2 = (short)array.Length;
			}
			num += (int)num2;
			byte[] array2 = new byte[num];
			byte[] array3 = ZipOutput.smethod_10(101010256U);
			ZipOutput.smethod_11(array3, 0, array2, 0, 4);
			array2[4] = 0;
			array2[5] = 0;
			array2[6] = 0;
			byte[] array4 = array2;
			int num3 = 7;
			int num4 = 8;
			array4[num3] = 0;
			if (entryCount < 65535 && zip64 != Zip64Option.Always)
			{
				array2[num4++] = (byte)(entryCount & 255);
				array2[num4++] = (byte)((entryCount & 65280) >> 8);
				array2[num4++] = (byte)(entryCount & 255);
				array2[num4++] = (byte)((entryCount & 65280) >> 8);
			}
			else
			{
				for (int i = 0; i < 4; i++)
				{
					array2[num4++] = byte.MaxValue;
				}
			}
			long num5 = EndOfCentralDirectory - StartOfCentralDirectory;
			if (num5 < 4294967295L && StartOfCentralDirectory < 4294967295L)
			{
				array2[num4++] = (byte)(num5 & 255L);
				array2[num4++] = (byte)((num5 & 65280L) >> 8);
				array2[num4++] = (byte)((num5 & 16711680L) >> 16);
				array2[num4++] = (byte)((num5 & 4278190080L) >> 24);
				array2[num4++] = (byte)(StartOfCentralDirectory & 255L);
				array2[num4++] = (byte)((StartOfCentralDirectory & 65280L) >> 8);
				array2[num4++] = (byte)((StartOfCentralDirectory & 16711680L) >> 16);
				array2[num4++] = (byte)((StartOfCentralDirectory & 4278190080L) >> 24);
			}
			else
			{
				for (int i = 0; i < 8; i++)
				{
					array2[num4++] = byte.MaxValue;
				}
			}
			if (comment != null && ZipOutput.smethod_16(comment) != 0)
			{
				if ((int)num2 + num4 + 2 > array2.Length)
				{
					num2 = (short)(array2.Length - num4 - 2);
				}
				array2[num4++] = (byte)(num2 & 255);
				array2[num4++] = (byte)(((int)num2 & 65280) >> 8);
				if (num2 != 0)
				{
					int i = 0;
					while (i < (int)num2 && num4 + i < array2.Length)
					{
						array2[num4 + i] = array[i];
						i++;
					}
					num4 += i;
				}
			}
			else
			{
				array2[num4++] = 0;
				array2[num4++] = 0;
			}
			return array2;
		}

		// Token: 0x060012D4 RID: 4820 RVA: 0x000628D8 File Offset: 0x00060AD8
		private static byte[] GenZip64EndOfCentralDirectory(long StartOfCentralDirectory, long EndOfCentralDirectory, int entryCount, uint numSegments)
		{
			byte[] array = new byte[76];
			byte[] array2 = ZipOutput.smethod_10(101075792U);
			ZipOutput.smethod_11(array2, 0, array, 0, 4);
			ZipOutput.smethod_11(ZipOutput.smethod_17(44L), 0, array, 4, 8);
			array[12] = 45;
			array[13] = 0;
			array[14] = 45;
			byte[] array3 = array;
			int num = 15;
			int num2 = 16;
			array3[num] = 0;
			for (int i = 0; i < 8; i++)
			{
				array[num2++] = 0;
			}
			long num3 = (long)entryCount;
			ZipOutput.smethod_11(ZipOutput.smethod_17(num3), 0, array, num2, 8);
			num2 += 8;
			ZipOutput.smethod_11(ZipOutput.smethod_17(num3), 0, array, num2, 8);
			num2 += 8;
			long num4 = EndOfCentralDirectory - StartOfCentralDirectory;
			ZipOutput.smethod_11(ZipOutput.smethod_17(num4), 0, array, num2, 8);
			num2 += 8;
			ZipOutput.smethod_11(ZipOutput.smethod_17(StartOfCentralDirectory), 0, array, num2, 8);
			num2 += 8;
			array2 = ZipOutput.smethod_10(117853008U);
			ZipOutput.smethod_11(array2, 0, array, num2, 4);
			num2 += 4;
			uint num5 = ((numSegments == 0U) ? 0U : (numSegments - 1U));
			ZipOutput.smethod_11(ZipOutput.smethod_10(num5), 0, array, num2, 4);
			num2 += 4;
			ZipOutput.smethod_11(ZipOutput.smethod_17(EndOfCentralDirectory), 0, array, num2, 8);
			num2 += 8;
			ZipOutput.smethod_11(ZipOutput.smethod_10(numSegments), 0, array, num2, 4);
			num2 += 4;
			return array;
		}

		// Token: 0x060012D5 RID: 4821 RVA: 0x00062A10 File Offset: 0x00060C10
		private static int CountEntries(ICollection<ZipEntry> _entries)
		{
			int num = 0;
			IEnumerator<ZipEntry> enumerator = _entries.GetEnumerator();
			try
			{
				while (ZipOutput.smethod_1(enumerator))
				{
					ZipEntry zipEntry = enumerator.Current;
					if (zipEntry.IncludedInMostRecentSave)
					{
						num++;
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					ZipOutput.smethod_2(enumerator);
				}
			}
			return num;
		}

		// Token: 0x060012D6 RID: 4822 RVA: 0x0000C8A7 File Offset: 0x0000AAA7
		static MemoryStream smethod_0()
		{
			return new MemoryStream();
		}

		// Token: 0x060012D7 RID: 4823 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_1(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060012D8 RID: 4824 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_2(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060012D9 RID: 4825 RVA: 0x0000C8C1 File Offset: 0x0000AAC1
		static byte[] smethod_3(MemoryStream memoryStream_0)
		{
			return memoryStream_0.ToArray();
		}

		// Token: 0x060012DA RID: 4826 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_4(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x060012DB RID: 4827 RVA: 0x00012846 File Offset: 0x00010A46
		static long smethod_5(Stream stream_0)
		{
			return stream_0.Position;
		}

		// Token: 0x060012DC RID: 4828 RVA: 0x00014848 File Offset: 0x00012A48
		static StackFrame smethod_6(int int_0)
		{
			return new StackFrame(int_0);
		}

		// Token: 0x060012DD RID: 4829 RVA: 0x00014850 File Offset: 0x00012A50
		static MethodBase smethod_7(StackFrame stackFrame_0)
		{
			return stackFrame_0.GetMethod();
		}

		// Token: 0x060012DE RID: 4830 RVA: 0x00014858 File Offset: 0x00012A58
		static Type smethod_8(MemberInfo memberInfo_0)
		{
			return memberInfo_0.DeclaringType;
		}

		// Token: 0x060012DF RID: 4831 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_9(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060012E0 RID: 4832 RVA: 0x00014860 File Offset: 0x00012A60
		static byte[] smethod_10(uint uint_0)
		{
			return BitConverter.GetBytes(uint_0);
		}

		// Token: 0x060012E1 RID: 4833 RVA: 0x0000C3EE File Offset: 0x0000A5EE
		static void smethod_11(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Array.Copy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x060012E2 RID: 4834 RVA: 0x00014868 File Offset: 0x00012A68
		static byte[] smethod_12(ushort ushort_0)
		{
			return BitConverter.GetBytes(ushort_0);
		}

		// Token: 0x060012E3 RID: 4835 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_13(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x060012E4 RID: 4836 RVA: 0x0000DF79 File Offset: 0x0000C179
		static string smethod_14(Encoding encoding_0, byte[] byte_0, int int_0, int int_1)
		{
			return encoding_0.GetString(byte_0, int_0, int_1);
		}

		// Token: 0x060012E5 RID: 4837 RVA: 0x0000DBC7 File Offset: 0x0000BDC7
		static bool smethod_15(string string_0, string string_1)
		{
			return string_0.Equals(string_1);
		}

		// Token: 0x060012E6 RID: 4838 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_16(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x060012E7 RID: 4839 RVA: 0x00013EA7 File Offset: 0x000120A7
		static byte[] smethod_17(long long_0)
		{
			return BitConverter.GetBytes(long_0);
		}
	}
}
