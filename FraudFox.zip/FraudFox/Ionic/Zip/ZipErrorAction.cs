﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x020000EE RID: 238
	[ComVisible(true)]
	public enum ZipErrorAction
	{
		// Token: 0x040004E3 RID: 1251
		Throw,
		// Token: 0x040004E4 RID: 1252
		Skip,
		// Token: 0x040004E5 RID: 1253
		Retry,
		// Token: 0x040004E6 RID: 1254
		InvokeErrorEvent
	}
}
