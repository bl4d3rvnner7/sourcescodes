﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zip
{
	// Token: 0x02000117 RID: 279
	[ComVisible(true)]
	public class ZipErrorEventArgs : ZipProgressEventArgs
	{
		// Token: 0x06001061 RID: 4193 RVA: 0x0001357D File Offset: 0x0001177D
		private ZipErrorEventArgs()
		{
		}

		// Token: 0x06001062 RID: 4194 RVA: 0x00057CB0 File Offset: 0x00055EB0
		internal static ZipErrorEventArgs Saving(string archiveName, ZipEntry entry, Exception exception)
		{
			return new ZipErrorEventArgs
			{
				EventType = ZipProgressEventType.Error_Saving,
				ArchiveName = archiveName,
				CurrentEntry = entry,
				_exc = exception
			};
		}

		// Token: 0x17000261 RID: 609
		// (get) Token: 0x06001063 RID: 4195 RVA: 0x00013601 File Offset: 0x00011801
		public Exception Exception
		{
			get
			{
				return this._exc;
			}
		}

		// Token: 0x17000262 RID: 610
		// (get) Token: 0x06001064 RID: 4196 RVA: 0x00013609 File Offset: 0x00011809
		public string FileName
		{
			get
			{
				return base.CurrentEntry.LocalFileName;
			}
		}

		// Token: 0x0400057C RID: 1404
		private Exception _exc;
	}
}
