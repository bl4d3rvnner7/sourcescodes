﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace Ionic.Zip
{
	// Token: 0x02000105 RID: 261
	[ComVisible(true)]
	[Guid("ebc25cf6-9120-4283-b972-0e5520d00009")]
	[Serializable]
	public class BadCrcException : ZipException
	{
		// Token: 0x06000FA9 RID: 4009 RVA: 0x00013292 File Offset: 0x00011492
		public BadCrcException()
		{
		}

		// Token: 0x06000FAA RID: 4010 RVA: 0x0001329A File Offset: 0x0001149A
		public BadCrcException(string message)
			: base(message)
		{
		}

		// Token: 0x06000FAB RID: 4011 RVA: 0x000132AD File Offset: 0x000114AD
		protected BadCrcException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
