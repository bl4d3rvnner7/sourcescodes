﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace Ionic.Zip
{
	// Token: 0x02000103 RID: 259
	[Guid("ebc25cf6-9120-4283-b972-0e5520d0000B")]
	[ComVisible(true)]
	[Serializable]
	public class BadPasswordException : ZipException
	{
		// Token: 0x06000FA1 RID: 4001 RVA: 0x00013292 File Offset: 0x00011492
		public BadPasswordException()
		{
		}

		// Token: 0x06000FA2 RID: 4002 RVA: 0x0001329A File Offset: 0x0001149A
		public BadPasswordException(string message)
			: base(message)
		{
		}

		// Token: 0x06000FA3 RID: 4003 RVA: 0x000132A3 File Offset: 0x000114A3
		public BadPasswordException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

		// Token: 0x06000FA4 RID: 4004 RVA: 0x000132AD File Offset: 0x000114AD
		protected BadPasswordException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}
