﻿using System;

namespace Ionic.Zip
{
	// Token: 0x0200010B RID: 267
	internal enum CryptoMode
	{
		// Token: 0x04000554 RID: 1364
		Encrypt,
		// Token: 0x04000555 RID: 1365
		Decrypt
	}
}
