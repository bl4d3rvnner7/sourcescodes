﻿using System;
using System.Text;
using Ionic.Zip;

namespace Ionic
{
	// Token: 0x020000FA RID: 250
	internal class CompoundCriterion : SelectionCriterion
	{
		// Token: 0x17000238 RID: 568
		// (get) Token: 0x06000F09 RID: 3849 RVA: 0x00012F46 File Offset: 0x00011146
		// (set) Token: 0x06000F0A RID: 3850 RVA: 0x00012F4E File Offset: 0x0001114E
		internal SelectionCriterion Right
		{
			get
			{
				return this._Right;
			}
			set
			{
				this._Right = value;
				if (value == null)
				{
					this.Conjunction = LogicalConjunction.NONE;
					return;
				}
				if (this.Conjunction == LogicalConjunction.NONE)
				{
					this.Conjunction = LogicalConjunction.AND;
				}
			}
		}

		// Token: 0x06000F0B RID: 3851 RVA: 0x00055044 File Offset: 0x00053244
		internal override bool Evaluate(string filename)
		{
			bool flag = this.Left.Evaluate(filename);
			switch (this.Conjunction)
			{
			case LogicalConjunction.AND:
				if (flag)
				{
					flag = this.Right.Evaluate(filename);
				}
				break;
			case LogicalConjunction.OR:
				if (!flag)
				{
					flag = this.Right.Evaluate(filename);
				}
				break;
			case LogicalConjunction.XOR:
				flag ^= this.Right.Evaluate(filename);
				break;
			default:
				throw CompoundCriterion.smethod_0(<Module>.smethod_23<string>(88869110U));
			}
			return flag;
		}

		// Token: 0x06000F0C RID: 3852 RVA: 0x000550C0 File Offset: 0x000532C0
		public override string ToString()
		{
			StringBuilder stringBuilder = CompoundCriterion.smethod_1();
			CompoundCriterion.smethod_2(CompoundCriterion.smethod_2(CompoundCriterion.smethod_2(CompoundCriterion.smethod_2(CompoundCriterion.smethod_2(CompoundCriterion.smethod_2(CompoundCriterion.smethod_2(stringBuilder, <Module>.smethod_23<string>(2809822556U)), (this.Left != null) ? CompoundCriterion.smethod_3(this.Left) : <Module>.smethod_27<string>(2113710154U)), <Module>.smethod_27<string>(2931232896U)), CompoundCriterion.smethod_3(this.Conjunction)), <Module>.smethod_27<string>(2931232896U)), (this.Right != null) ? CompoundCriterion.smethod_3(this.Right) : <Module>.smethod_25<string>(2731143561U)), <Module>.smethod_26<string>(1712032400U));
			return CompoundCriterion.smethod_3(stringBuilder);
		}

		// Token: 0x06000F0D RID: 3853 RVA: 0x00055174 File Offset: 0x00053374
		internal override bool Evaluate(ZipEntry entry)
		{
			bool flag = this.Left.Evaluate(entry);
			switch (this.Conjunction)
			{
			case LogicalConjunction.AND:
				if (flag)
				{
					flag = this.Right.Evaluate(entry);
				}
				break;
			case LogicalConjunction.OR:
				if (!flag)
				{
					flag = this.Right.Evaluate(entry);
				}
				break;
			case LogicalConjunction.XOR:
				flag ^= this.Right.Evaluate(entry);
				break;
			}
			return flag;
		}

		// Token: 0x06000F0F RID: 3855 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_0(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x06000F10 RID: 3856 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_1()
		{
			return new StringBuilder();
		}

		// Token: 0x06000F11 RID: 3857 RVA: 0x0000DB11 File Offset: 0x0000BD11
		static StringBuilder smethod_2(StringBuilder stringBuilder_0, string string_0)
		{
			return stringBuilder_0.Append(string_0);
		}

		// Token: 0x06000F12 RID: 3858 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_3(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x04000510 RID: 1296
		internal LogicalConjunction Conjunction;

		// Token: 0x04000511 RID: 1297
		internal SelectionCriterion Left;

		// Token: 0x04000512 RID: 1298
		private SelectionCriterion _Right;
	}
}
