﻿using System;
using System.IO;
using System.Text;
using Ionic.Zip;

namespace Ionic
{
	// Token: 0x020000F5 RID: 245
	internal class SizeCriterion : SelectionCriterion
	{
		// Token: 0x06000EC0 RID: 3776 RVA: 0x00054664 File Offset: 0x00052864
		public override string ToString()
		{
			StringBuilder stringBuilder = SizeCriterion.smethod_0();
			SizeCriterion.smethod_1(SizeCriterion.smethod_1(SizeCriterion.smethod_1(stringBuilder, <Module>.smethod_23<string>(3148889394U)), EnumUtil.GetDescription(this.Operator)), <Module>.smethod_24<string>(2570929253U)).Append(this.Size.ToString());
			return stringBuilder.ToString();
		}

		// Token: 0x06000EC1 RID: 3777 RVA: 0x000546C4 File Offset: 0x000528C4
		internal override bool Evaluate(string filename)
		{
			FileInfo fileInfo = SizeCriterion.smethod_2(filename);
			return this._Evaluate(SizeCriterion.smethod_3(fileInfo));
		}

		// Token: 0x06000EC2 RID: 3778 RVA: 0x000546E4 File Offset: 0x000528E4
		private bool _Evaluate(long Length)
		{
			bool flag;
			switch (this.Operator)
			{
			case ComparisonOperator.GreaterThan:
				flag = Length > this.Size;
				break;
			case ComparisonOperator.GreaterThanOrEqualTo:
				flag = Length >= this.Size;
				break;
			case ComparisonOperator.LesserThan:
				flag = Length < this.Size;
				break;
			case ComparisonOperator.LesserThanOrEqualTo:
				flag = Length <= this.Size;
				break;
			case ComparisonOperator.EqualTo:
				flag = Length == this.Size;
				break;
			case ComparisonOperator.NotEqualTo:
				flag = Length != this.Size;
				break;
			default:
				throw SizeCriterion.smethod_4(<Module>.smethod_26<string>(3509977667U));
			}
			return flag;
		}

		// Token: 0x06000EC3 RID: 3779 RVA: 0x00012EBB File Offset: 0x000110BB
		internal override bool Evaluate(ZipEntry entry)
		{
			return this._Evaluate(entry.UncompressedSize);
		}

		// Token: 0x06000EC5 RID: 3781 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_0()
		{
			return new StringBuilder();
		}

		// Token: 0x06000EC6 RID: 3782 RVA: 0x0000DB11 File Offset: 0x0000BD11
		static StringBuilder smethod_1(StringBuilder stringBuilder_0, string string_0)
		{
			return stringBuilder_0.Append(string_0);
		}

		// Token: 0x06000EC7 RID: 3783 RVA: 0x0000D4D5 File Offset: 0x0000B6D5
		static FileInfo smethod_2(string string_0)
		{
			return new FileInfo(string_0);
		}

		// Token: 0x06000EC8 RID: 3784 RVA: 0x0000D4DD File Offset: 0x0000B6DD
		static long smethod_3(FileInfo fileInfo_0)
		{
			return fileInfo_0.Length;
		}

		// Token: 0x06000EC9 RID: 3785 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_4(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x04000503 RID: 1283
		internal ComparisonOperator Operator;

		// Token: 0x04000504 RID: 1284
		internal long Size;
	}
}
