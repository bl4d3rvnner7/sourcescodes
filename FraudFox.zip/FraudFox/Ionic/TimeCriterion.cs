﻿using System;
using System.IO;
using System.Text;
using Ionic.Zip;

namespace Ionic
{
	// Token: 0x020000F6 RID: 246
	internal class TimeCriterion : SelectionCriterion
	{
		// Token: 0x06000ECA RID: 3786 RVA: 0x00054778 File Offset: 0x00052978
		public override string ToString()
		{
			StringBuilder stringBuilder = TimeCriterion.smethod_0();
			TimeCriterion.smethod_2(TimeCriterion.smethod_2(TimeCriterion.smethod_2(TimeCriterion.smethod_2(stringBuilder, TimeCriterion.smethod_1(this.Which)), <Module>.smethod_25<string>(482330791U)), EnumUtil.GetDescription(this.Operator)), <Module>.smethod_26<string>(2342675128U)).Append(this.Time.ToString(<Module>.smethod_24<string>(2211186497U)));
			return stringBuilder.ToString();
		}

		// Token: 0x06000ECB RID: 3787 RVA: 0x000547F8 File Offset: 0x000529F8
		internal override bool Evaluate(string filename)
		{
			DateTime dateTime;
			switch (this.Which)
			{
			case WhichTime.atime:
				dateTime = TimeCriterion.smethod_3(filename).ToUniversalTime();
				break;
			case WhichTime.mtime:
				dateTime = File.GetLastWriteTime(filename).ToUniversalTime();
				break;
			case WhichTime.ctime:
				dateTime = File.GetCreationTime(filename).ToUniversalTime();
				break;
			default:
				throw new ArgumentException(<Module>.smethod_23<string>(1465796001U));
			}
			return this._Evaluate(dateTime);
		}

		// Token: 0x06000ECC RID: 3788 RVA: 0x00054868 File Offset: 0x00052A68
		private bool _Evaluate(DateTime x)
		{
			bool flag;
			switch (this.Operator)
			{
			case ComparisonOperator.GreaterThan:
				flag = x > this.Time;
				break;
			case ComparisonOperator.GreaterThanOrEqualTo:
				flag = x >= this.Time;
				break;
			case ComparisonOperator.LesserThan:
				flag = x < this.Time;
				break;
			case ComparisonOperator.LesserThanOrEqualTo:
				flag = x <= this.Time;
				break;
			case ComparisonOperator.EqualTo:
				flag = x == this.Time;
				break;
			case ComparisonOperator.NotEqualTo:
				flag = x != this.Time;
				break;
			default:
				throw TimeCriterion.smethod_4(<Module>.smethod_25<string>(1011282026U));
			}
			return flag;
		}

		// Token: 0x06000ECD RID: 3789 RVA: 0x00054908 File Offset: 0x00052B08
		internal override bool Evaluate(ZipEntry entry)
		{
			DateTime dateTime;
			switch (this.Which)
			{
			case WhichTime.atime:
				dateTime = entry.AccessedTime;
				break;
			case WhichTime.mtime:
				dateTime = entry.ModifiedTime;
				break;
			case WhichTime.ctime:
				dateTime = entry.CreationTime;
				break;
			default:
				throw TimeCriterion.smethod_4(<Module>.smethod_25<string>(1498464197U));
			}
			return this._Evaluate(dateTime);
		}

		// Token: 0x06000ECF RID: 3791 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_0()
		{
			return new StringBuilder();
		}

		// Token: 0x06000ED0 RID: 3792 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_1(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06000ED1 RID: 3793 RVA: 0x0000DB11 File Offset: 0x0000BD11
		static StringBuilder smethod_2(StringBuilder stringBuilder_0, string string_0)
		{
			return stringBuilder_0.Append(string_0);
		}

		// Token: 0x06000ED2 RID: 3794 RVA: 0x00012ED1 File Offset: 0x000110D1
		static DateTime smethod_3(string string_0)
		{
			return File.GetLastAccessTime(string_0);
		}

		// Token: 0x06000ED3 RID: 3795 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_4(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x04000505 RID: 1285
		internal ComparisonOperator Operator;

		// Token: 0x04000506 RID: 1286
		internal WhichTime Which;

		// Token: 0x04000507 RID: 1287
		internal DateTime Time;
	}
}
