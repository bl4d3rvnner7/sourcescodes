﻿using System;
using System.IO;
using System.Text;
using Ionic.Zip;

namespace Ionic
{
	// Token: 0x020000F8 RID: 248
	internal class TypeCriterion : SelectionCriterion
	{
		// Token: 0x17000236 RID: 566
		// (get) Token: 0x06000EE7 RID: 3815 RVA: 0x00012EF3 File Offset: 0x000110F3
		// (set) Token: 0x06000EE8 RID: 3816 RVA: 0x00012F00 File Offset: 0x00011100
		internal string AttributeString
		{
			get
			{
				return this.ObjectType.ToString();
			}
			set
			{
				if (TypeCriterion.smethod_0(value) != 1 || (TypeCriterion.smethod_1(value, 0) != 'D' && TypeCriterion.smethod_1(value, 0) != 'F'))
				{
					throw TypeCriterion.smethod_2(<Module>.smethod_26<string>(2368805853U));
				}
				this.ObjectType = TypeCriterion.smethod_1(value, 0);
			}
		}

		// Token: 0x06000EE9 RID: 3817 RVA: 0x00054B50 File Offset: 0x00052D50
		public override string ToString()
		{
			StringBuilder stringBuilder = TypeCriterion.smethod_3();
			TypeCriterion.smethod_4(TypeCriterion.smethod_4(TypeCriterion.smethod_4(TypeCriterion.smethod_4(stringBuilder, <Module>.smethod_25<string>(991207236U)), EnumUtil.GetDescription(this.Operator)), <Module>.smethod_27<string>(2931232896U)), this.AttributeString);
			return TypeCriterion.smethod_5(stringBuilder);
		}

		// Token: 0x06000EEA RID: 3818 RVA: 0x00054BAC File Offset: 0x00052DAC
		internal override bool Evaluate(string filename)
		{
			bool flag = ((this.ObjectType == 'D') ? TypeCriterion.smethod_7(filename) : TypeCriterion.smethod_6(filename));
			if (this.Operator != ComparisonOperator.EqualTo)
			{
				flag = !flag;
			}
			return flag;
		}

		// Token: 0x06000EEB RID: 3819 RVA: 0x00054BE4 File Offset: 0x00052DE4
		internal override bool Evaluate(ZipEntry entry)
		{
			bool flag = ((this.ObjectType == 'D') ? entry.IsDirectory : (!entry.IsDirectory));
			if (this.Operator != ComparisonOperator.EqualTo)
			{
				flag = !flag;
			}
			return flag;
		}

		// Token: 0x06000EED RID: 3821 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_0(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06000EEE RID: 3822 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_1(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x06000EEF RID: 3823 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_2(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x06000EF0 RID: 3824 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_3()
		{
			return new StringBuilder();
		}

		// Token: 0x06000EF1 RID: 3825 RVA: 0x0000DB11 File Offset: 0x0000BD11
		static StringBuilder smethod_4(StringBuilder stringBuilder_0, string string_0)
		{
			return stringBuilder_0.Append(string_0);
		}

		// Token: 0x06000EF2 RID: 3826 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_5(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06000EF3 RID: 3827 RVA: 0x0000C681 File Offset: 0x0000A881
		static bool smethod_6(string string_0)
		{
			return File.Exists(string_0);
		}

		// Token: 0x06000EF4 RID: 3828 RVA: 0x0000D8B1 File Offset: 0x0000BAB1
		static bool smethod_7(string string_0)
		{
			return Directory.Exists(string_0);
		}

		// Token: 0x0400050C RID: 1292
		private char ObjectType;

		// Token: 0x0400050D RID: 1293
		internal ComparisonOperator Operator;
	}
}
