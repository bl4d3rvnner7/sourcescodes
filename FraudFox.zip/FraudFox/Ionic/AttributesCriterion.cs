﻿using System;
using System.IO;
using System.Text;
using Ionic.Zip;

namespace Ionic
{
	// Token: 0x020000F9 RID: 249
	internal class AttributesCriterion : SelectionCriterion
	{
		// Token: 0x17000237 RID: 567
		// (get) Token: 0x06000EF5 RID: 3829 RVA: 0x00054C1C File Offset: 0x00052E1C
		// (set) Token: 0x06000EF6 RID: 3830 RVA: 0x00054CDC File Offset: 0x00052EDC
		internal string AttributeString
		{
			get
			{
				string text = "";
				if ((this._Attributes & FileAttributes.Hidden) != (FileAttributes)0)
				{
					text = AttributesCriterion.smethod_0(text, <Module>.smethod_27<string>(3419117558U));
				}
				if ((this._Attributes & FileAttributes.System) != (FileAttributes)0)
				{
					text = AttributesCriterion.smethod_0(text, <Module>.smethod_23<string>(2563903636U));
				}
				if ((this._Attributes & FileAttributes.ReadOnly) != (FileAttributes)0)
				{
					text = AttributesCriterion.smethod_0(text, <Module>.smethod_27<string>(1325635103U));
				}
				if ((this._Attributes & FileAttributes.Archive) != (FileAttributes)0)
				{
					text = AttributesCriterion.smethod_0(text, <Module>.smethod_23<string>(3685965898U));
				}
				if ((this._Attributes & FileAttributes.ReparsePoint) != (FileAttributes)0)
				{
					text = AttributesCriterion.smethod_0(text, <Module>.smethod_25<string>(130357654U));
				}
				if ((this._Attributes & FileAttributes.NotContentIndexed) != (FileAttributes)0)
				{
					text = AttributesCriterion.smethod_0(text, <Module>.smethod_25<string>(271026614U));
				}
				return text;
			}
			set
			{
				this._Attributes = FileAttributes.Normal;
				string text = AttributesCriterion.smethod_1(value);
				for (int i = 0; i < AttributesCriterion.smethod_6(text); i++)
				{
					char c = AttributesCriterion.smethod_2(text, i);
					char c2 = c;
					if (c2 != 'A')
					{
						switch (c2)
						{
						case 'H':
							if ((this._Attributes & FileAttributes.Hidden) == (FileAttributes)0)
							{
								this._Attributes |= FileAttributes.Hidden;
								goto IL_0122;
							}
							throw AttributesCriterion.smethod_4(AttributesCriterion.smethod_3(<Module>.smethod_26<string>(254839584U), c), <Module>.smethod_24<string>(4014942403U));
						case 'I':
							if ((this._Attributes & FileAttributes.NotContentIndexed) == (FileAttributes)0)
							{
								this._Attributes |= FileAttributes.NotContentIndexed;
								goto IL_0122;
							}
							throw AttributesCriterion.smethod_4(AttributesCriterion.smethod_3(<Module>.smethod_27<string>(3139387400U), c), <Module>.smethod_25<string>(3622406065U));
						case 'J':
						case 'K':
							break;
						case 'L':
							if ((this._Attributes & FileAttributes.ReparsePoint) == (FileAttributes)0)
							{
								this._Attributes |= FileAttributes.ReparsePoint;
								goto IL_0122;
							}
							throw AttributesCriterion.smethod_4(AttributesCriterion.smethod_3(<Module>.smethod_25<string>(1478389407U), c), <Module>.smethod_25<string>(3622406065U));
						default:
							switch (c2)
							{
							case 'R':
								if ((this._Attributes & FileAttributes.ReadOnly) == (FileAttributes)0)
								{
									this._Attributes |= FileAttributes.ReadOnly;
									goto IL_0122;
								}
								throw AttributesCriterion.smethod_4(AttributesCriterion.smethod_3(<Module>.smethod_23<string>(319779112U), c), <Module>.smethod_25<string>(3622406065U));
							case 'S':
								if ((this._Attributes & FileAttributes.System) == (FileAttributes)0)
								{
									this._Attributes |= FileAttributes.System;
									goto IL_0122;
								}
								throw AttributesCriterion.smethod_4(AttributesCriterion.smethod_3(<Module>.smethod_24<string>(3592201613U), c), <Module>.smethod_26<string>(1806306238U));
							}
							break;
						}
						throw AttributesCriterion.smethod_5(value);
					}
					if ((this._Attributes & FileAttributes.Archive) != (FileAttributes)0)
					{
						throw AttributesCriterion.smethod_4(AttributesCriterion.smethod_3(<Module>.smethod_23<string>(319779112U), c), <Module>.smethod_23<string>(2033612370U));
					}
					this._Attributes |= FileAttributes.Archive;
					IL_0122:;
				}
			}
		}

		// Token: 0x06000EF7 RID: 3831 RVA: 0x00054F08 File Offset: 0x00053108
		public override string ToString()
		{
			StringBuilder stringBuilder = AttributesCriterion.smethod_7();
			AttributesCriterion.smethod_8(AttributesCriterion.smethod_8(AttributesCriterion.smethod_8(AttributesCriterion.smethod_8(stringBuilder, <Module>.smethod_26<string>(3121343246U)), EnumUtil.GetDescription(this.Operator)), <Module>.smethod_25<string>(482330791U)), this.AttributeString);
			return AttributesCriterion.smethod_9(stringBuilder);
		}

		// Token: 0x06000EF8 RID: 3832 RVA: 0x00054F64 File Offset: 0x00053164
		private bool _EvaluateOne(FileAttributes fileAttrs, FileAttributes criterionAttrs)
		{
			return (this._Attributes & criterionAttrs) != criterionAttrs || (fileAttrs & criterionAttrs) == criterionAttrs;
		}

		// Token: 0x06000EF9 RID: 3833 RVA: 0x00054F8C File Offset: 0x0005318C
		internal override bool Evaluate(string filename)
		{
			if (!AttributesCriterion.smethod_10(filename))
			{
				FileAttributes fileAttributes = AttributesCriterion.smethod_11(filename);
				return this._Evaluate(fileAttributes);
			}
			return this.Operator != ComparisonOperator.EqualTo;
		}

		// Token: 0x06000EFA RID: 3834 RVA: 0x00054FBC File Offset: 0x000531BC
		private bool _Evaluate(FileAttributes fileAttrs)
		{
			bool flag;
			if (flag = this._EvaluateOne(fileAttrs, FileAttributes.Hidden))
			{
				flag = this._EvaluateOne(fileAttrs, FileAttributes.System);
			}
			if (flag)
			{
				flag = this._EvaluateOne(fileAttrs, FileAttributes.ReadOnly);
			}
			if (flag)
			{
				flag = this._EvaluateOne(fileAttrs, FileAttributes.Archive);
			}
			if (flag)
			{
				flag = this._EvaluateOne(fileAttrs, FileAttributes.NotContentIndexed);
			}
			if (flag)
			{
				flag = this._EvaluateOne(fileAttrs, FileAttributes.ReparsePoint);
			}
			if (this.Operator != ComparisonOperator.EqualTo)
			{
				flag = !flag;
			}
			return flag;
		}

		// Token: 0x06000EFB RID: 3835 RVA: 0x00055028 File Offset: 0x00053228
		internal override bool Evaluate(ZipEntry entry)
		{
			FileAttributes attributes = entry.Attributes;
			return this._Evaluate(attributes);
		}

		// Token: 0x06000EFD RID: 3837 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_0(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x06000EFE RID: 3838 RVA: 0x0000DAEE File Offset: 0x0000BCEE
		static string smethod_1(string string_0)
		{
			return string_0.ToUpper();
		}

		// Token: 0x06000EFF RID: 3839 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_2(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x06000F00 RID: 3840 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_3(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x06000F01 RID: 3841 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_4(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}

		// Token: 0x06000F02 RID: 3842 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_5(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x06000F03 RID: 3843 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_6(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06000F04 RID: 3844 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_7()
		{
			return new StringBuilder();
		}

		// Token: 0x06000F05 RID: 3845 RVA: 0x0000DB11 File Offset: 0x0000BD11
		static StringBuilder smethod_8(StringBuilder stringBuilder_0, string string_0)
		{
			return stringBuilder_0.Append(string_0);
		}

		// Token: 0x06000F06 RID: 3846 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_9(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06000F07 RID: 3847 RVA: 0x0000D8B1 File Offset: 0x0000BAB1
		static bool smethod_10(string string_0)
		{
			return Directory.Exists(string_0);
		}

		// Token: 0x06000F08 RID: 3848 RVA: 0x00012F3E File Offset: 0x0001113E
		static FileAttributes smethod_11(string string_0)
		{
			return File.GetAttributes(string_0);
		}

		// Token: 0x0400050E RID: 1294
		private FileAttributes _Attributes;

		// Token: 0x0400050F RID: 1295
		internal ComparisonOperator Operator;
	}
}
