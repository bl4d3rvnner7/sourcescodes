﻿using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using Ionic.Zip;

namespace Ionic
{
	// Token: 0x020000F7 RID: 247
	internal class NameCriterion : SelectionCriterion
	{
		// Token: 0x17000235 RID: 565
		// (set) Token: 0x06000ED4 RID: 3796 RVA: 0x00054960 File Offset: 0x00052B60
		internal virtual string MatchingFileSpec
		{
			set
			{
				if (NameCriterion.smethod_0(value))
				{
					this._MatchingFileSpec = NameCriterion.smethod_1(new object[]
					{
						<Module>.smethod_23<string>(386296197U),
						Path.DirectorySeparatorChar,
						value,
						Path.DirectorySeparatorChar,
						<Module>.smethod_24<string>(4121133488U)
					});
				}
				else
				{
					this._MatchingFileSpec = value;
				}
				this._regexString = NameCriterion.smethod_4(<Module>.smethod_23<string>(3479010523U), NameCriterion.smethod_3(NameCriterion.smethod_3(NameCriterion.smethod_3(NameCriterion.smethod_3(NameCriterion.smethod_2(this._MatchingFileSpec), <Module>.smethod_26<string>(672203187U), <Module>.smethod_26<string>(4262515060U)), <Module>.smethod_24<string>(2725383430U), <Module>.smethod_27<string>(3005293861U)), <Module>.smethod_25<string>(3238400522U), <Module>.smethod_25<string>(4212764864U)), <Module>.smethod_25<string>(4073569958U), <Module>.smethod_27<string>(2912050475U)), <Module>.smethod_27<string>(2865428782U));
				this._re = NameCriterion.smethod_5(this._regexString, RegexOptions.IgnoreCase);
			}
		}

		// Token: 0x06000ED5 RID: 3797 RVA: 0x00054A6C File Offset: 0x00052C6C
		public override string ToString()
		{
			StringBuilder stringBuilder = NameCriterion.smethod_6();
			NameCriterion.smethod_7(NameCriterion.smethod_7(NameCriterion.smethod_7(NameCriterion.smethod_7(NameCriterion.smethod_7(stringBuilder, <Module>.smethod_23<string>(1984058380U)), EnumUtil.GetDescription(this.Operator)), <Module>.smethod_24<string>(2142592994U)), this._MatchingFileSpec), <Module>.smethod_24<string>(1329633372U));
			return NameCriterion.smethod_8(stringBuilder);
		}

		// Token: 0x06000ED6 RID: 3798 RVA: 0x00012ED9 File Offset: 0x000110D9
		internal override bool Evaluate(string filename)
		{
			return this._Evaluate(filename);
		}

		// Token: 0x06000ED7 RID: 3799 RVA: 0x00054AD4 File Offset: 0x00052CD4
		private bool _Evaluate(string fullpath)
		{
			string text = ((NameCriterion.smethod_9(this._MatchingFileSpec, Path.DirectorySeparatorChar) == -1) ? NameCriterion.smethod_10(fullpath) : fullpath);
			bool flag = NameCriterion.smethod_11(this._re, text);
			if (this.Operator != ComparisonOperator.EqualTo)
			{
				flag = !flag;
			}
			return flag;
		}

		// Token: 0x06000ED8 RID: 3800 RVA: 0x00054B1C File Offset: 0x00052D1C
		internal override bool Evaluate(ZipEntry entry)
		{
			string text = NameCriterion.smethod_12(entry.FileName, (Path.DirectorySeparatorChar == '/') ? '\\' : '/', Path.DirectorySeparatorChar);
			return this._Evaluate(text);
		}

		// Token: 0x06000EDA RID: 3802 RVA: 0x0000D8B1 File Offset: 0x0000BAB1
		static bool smethod_0(string string_0)
		{
			return Directory.Exists(string_0);
		}

		// Token: 0x06000EDB RID: 3803 RVA: 0x00010764 File Offset: 0x0000E964
		static string smethod_1(object[] object_0)
		{
			return string.Concat(object_0);
		}

		// Token: 0x06000EDC RID: 3804 RVA: 0x00012EE2 File Offset: 0x000110E2
		static string smethod_2(string string_0)
		{
			return Regex.Escape(string_0);
		}

		// Token: 0x06000EDD RID: 3805 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_3(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x06000EDE RID: 3806 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_4(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x06000EDF RID: 3807 RVA: 0x0000FE6E File Offset: 0x0000E06E
		static Regex smethod_5(string string_0, RegexOptions regexOptions_0)
		{
			return new Regex(string_0, regexOptions_0);
		}

		// Token: 0x06000EE0 RID: 3808 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_6()
		{
			return new StringBuilder();
		}

		// Token: 0x06000EE1 RID: 3809 RVA: 0x0000DB11 File Offset: 0x0000BD11
		static StringBuilder smethod_7(StringBuilder stringBuilder_0, string string_0)
		{
			return stringBuilder_0.Append(string_0);
		}

		// Token: 0x06000EE2 RID: 3810 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_8(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06000EE3 RID: 3811 RVA: 0x0000FABD File Offset: 0x0000DCBD
		static int smethod_9(string string_0, char char_0)
		{
			return string_0.IndexOf(char_0);
		}

		// Token: 0x06000EE4 RID: 3812 RVA: 0x0000CFF4 File Offset: 0x0000B1F4
		static string smethod_10(string string_0)
		{
			return Path.GetFileName(string_0);
		}

		// Token: 0x06000EE5 RID: 3813 RVA: 0x00012EEA File Offset: 0x000110EA
		static bool smethod_11(Regex regex_0, string string_0)
		{
			return regex_0.IsMatch(string_0);
		}

		// Token: 0x06000EE6 RID: 3814 RVA: 0x0000CD69 File Offset: 0x0000AF69
		static string smethod_12(string string_0, char char_0, char char_1)
		{
			return string_0.Replace(char_0, char_1);
		}

		// Token: 0x04000508 RID: 1288
		private Regex _re;

		// Token: 0x04000509 RID: 1289
		private string _regexString;

		// Token: 0x0400050A RID: 1290
		internal ComparisonOperator Operator;

		// Token: 0x0400050B RID: 1291
		private string _MatchingFileSpec;
	}
}
