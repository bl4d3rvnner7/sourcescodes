﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zlib
{
	// Token: 0x0200014C RID: 332
	[ComVisible(true)]
	public enum CompressionMode
	{
		// Token: 0x0400082A RID: 2090
		Compress,
		// Token: 0x0400082B RID: 2091
		Decompress
	}
}
