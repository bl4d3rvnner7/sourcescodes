﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace Ionic.Zlib
{
	// Token: 0x0200013C RID: 316
	[ComVisible(true)]
	public class DeflateStream : Stream
	{
		// Token: 0x0600140F RID: 5135 RVA: 0x00014E35 File Offset: 0x00013035
		public DeflateStream(Stream stream, CompressionMode mode)
			: this(stream, mode, CompressionLevel.Default, false)
		{
		}

		// Token: 0x06001410 RID: 5136 RVA: 0x00014E41 File Offset: 0x00013041
		public DeflateStream(Stream stream, CompressionMode mode, CompressionLevel level)
			: this(stream, mode, level, false)
		{
		}

		// Token: 0x06001411 RID: 5137 RVA: 0x00014E4D File Offset: 0x0001304D
		public DeflateStream(Stream stream, CompressionMode mode, bool leaveOpen)
			: this(stream, mode, CompressionLevel.Default, leaveOpen)
		{
		}

		// Token: 0x06001412 RID: 5138 RVA: 0x00014E59 File Offset: 0x00013059
		public DeflateStream(Stream stream, CompressionMode mode, CompressionLevel level, bool leaveOpen)
		{
			this._innerStream = stream;
			this._baseStream = new ZlibBaseStream(stream, mode, level, ZlibStreamFlavor.DEFLATE, leaveOpen);
		}

		// Token: 0x170002EE RID: 750
		// (get) Token: 0x06001413 RID: 5139 RVA: 0x00014E7D File Offset: 0x0001307D
		// (set) Token: 0x06001414 RID: 5140 RVA: 0x00014E8A File Offset: 0x0001308A
		public virtual FlushType FlushMode
		{
			get
			{
				return this._baseStream._flushMode;
			}
			set
			{
				if (this._disposed)
				{
					throw DeflateStream.smethod_0(<Module>.smethod_26<string>(3788438144U));
				}
				this._baseStream._flushMode = value;
			}
		}

		// Token: 0x170002EF RID: 751
		// (get) Token: 0x06001415 RID: 5141 RVA: 0x00014EB0 File Offset: 0x000130B0
		// (set) Token: 0x06001416 RID: 5142 RVA: 0x00069788 File Offset: 0x00067988
		public int BufferSize
		{
			get
			{
				return this._baseStream._bufferSize;
			}
			set
			{
				if (this._disposed)
				{
					throw DeflateStream.smethod_0(<Module>.smethod_23<string>(775427144U));
				}
				if (this._baseStream._workingBuffer != null)
				{
					throw new ZlibException(<Module>.smethod_23<string>(3349672797U));
				}
				if (value < 1024)
				{
					throw new ZlibException(DeflateStream.smethod_1(<Module>.smethod_26<string>(2892254841U), value, 1024));
				}
				this._baseStream._bufferSize = value;
			}
		}

		// Token: 0x170002F0 RID: 752
		// (get) Token: 0x06001417 RID: 5143 RVA: 0x00014EBD File Offset: 0x000130BD
		// (set) Token: 0x06001418 RID: 5144 RVA: 0x00014ECA File Offset: 0x000130CA
		public CompressionStrategy Strategy
		{
			get
			{
				return this._baseStream.Strategy;
			}
			set
			{
				if (this._disposed)
				{
					throw DeflateStream.smethod_0(<Module>.smethod_24<string>(2300099245U));
				}
				this._baseStream.Strategy = value;
			}
		}

		// Token: 0x170002F1 RID: 753
		// (get) Token: 0x06001419 RID: 5145 RVA: 0x00014EF0 File Offset: 0x000130F0
		public virtual long TotalIn
		{
			get
			{
				return this._baseStream._z.TotalBytesIn;
			}
		}

		// Token: 0x170002F2 RID: 754
		// (get) Token: 0x0600141A RID: 5146 RVA: 0x00014F02 File Offset: 0x00013102
		public virtual long TotalOut
		{
			get
			{
				return this._baseStream._z.TotalBytesOut;
			}
		}

		// Token: 0x0600141B RID: 5147 RVA: 0x00069804 File Offset: 0x00067A04
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (!this._disposed)
				{
					if (disposing && this._baseStream != null)
					{
						DeflateStream.smethod_2(this._baseStream);
					}
					this._disposed = true;
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x170002F3 RID: 755
		// (get) Token: 0x0600141C RID: 5148 RVA: 0x00014F14 File Offset: 0x00013114
		public override bool CanRead
		{
			get
			{
				if (this._disposed)
				{
					throw DeflateStream.smethod_0(<Module>.smethod_24<string>(2300099245U));
				}
				return DeflateStream.smethod_3(this._baseStream._stream);
			}
		}

		// Token: 0x170002F4 RID: 756
		// (get) Token: 0x0600141D RID: 5149 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170002F5 RID: 757
		// (get) Token: 0x0600141E RID: 5150 RVA: 0x00014F3E File Offset: 0x0001313E
		public override bool CanWrite
		{
			get
			{
				if (this._disposed)
				{
					throw DeflateStream.smethod_0(<Module>.smethod_25<string>(1475732159U));
				}
				return DeflateStream.smethod_4(this._baseStream._stream);
			}
		}

		// Token: 0x0600141F RID: 5151 RVA: 0x00014F68 File Offset: 0x00013168
		public override void Flush()
		{
			if (this._disposed)
			{
				throw DeflateStream.smethod_0(<Module>.smethod_24<string>(2300099245U));
			}
			DeflateStream.smethod_5(this._baseStream);
		}

		// Token: 0x170002F6 RID: 758
		// (get) Token: 0x06001420 RID: 5152 RVA: 0x00014F8D File Offset: 0x0001318D
		public override long Length
		{
			get
			{
				throw DeflateStream.smethod_6();
			}
		}

		// Token: 0x170002F7 RID: 759
		// (get) Token: 0x06001421 RID: 5153 RVA: 0x00069850 File Offset: 0x00067A50
		// (set) Token: 0x06001422 RID: 5154 RVA: 0x00014F8D File Offset: 0x0001318D
		public override long Position
		{
			get
			{
				if (this._baseStream._streamMode == ZlibBaseStream.StreamMode.Writer)
				{
					return this._baseStream._z.TotalBytesOut;
				}
				if (this._baseStream._streamMode == ZlibBaseStream.StreamMode.Reader)
				{
					return this._baseStream._z.TotalBytesIn;
				}
				return 0L;
			}
			set
			{
				throw DeflateStream.smethod_6();
			}
		}

		// Token: 0x06001423 RID: 5155 RVA: 0x00014F94 File Offset: 0x00013194
		public override int Read(byte[] buffer, int offset, int count)
		{
			if (this._disposed)
			{
				throw DeflateStream.smethod_0(<Module>.smethod_23<string>(775427144U));
			}
			return DeflateStream.smethod_7(this._baseStream, buffer, offset, count);
		}

		// Token: 0x06001424 RID: 5156 RVA: 0x00014F8D File Offset: 0x0001318D
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw DeflateStream.smethod_6();
		}

		// Token: 0x06001425 RID: 5157 RVA: 0x00014F8D File Offset: 0x0001318D
		public override void SetLength(long value)
		{
			throw DeflateStream.smethod_6();
		}

		// Token: 0x06001426 RID: 5158 RVA: 0x00014FBC File Offset: 0x000131BC
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (this._disposed)
			{
				throw DeflateStream.smethod_0(<Module>.smethod_25<string>(1475732159U));
			}
			DeflateStream.smethod_8(this._baseStream, buffer, offset, count);
		}

		// Token: 0x06001427 RID: 5159 RVA: 0x000698A4 File Offset: 0x00067AA4
		public static byte[] CompressString(string s)
		{
			MemoryStream memoryStream = DeflateStream.smethod_9();
			byte[] array;
			try
			{
				Stream stream = new DeflateStream(memoryStream, CompressionMode.Compress, CompressionLevel.BestCompression);
				ZlibBaseStream.CompressString(s, stream);
				array = DeflateStream.smethod_10(memoryStream);
			}
			finally
			{
				if (memoryStream != null)
				{
					DeflateStream.smethod_11(memoryStream);
				}
			}
			return array;
		}

		// Token: 0x06001428 RID: 5160 RVA: 0x000698EC File Offset: 0x00067AEC
		public static byte[] CompressBuffer(byte[] b)
		{
			MemoryStream memoryStream = DeflateStream.smethod_9();
			byte[] array;
			try
			{
				Stream stream = new DeflateStream(memoryStream, CompressionMode.Compress, CompressionLevel.BestCompression);
				ZlibBaseStream.CompressBuffer(b, stream);
				array = DeflateStream.smethod_10(memoryStream);
			}
			finally
			{
				if (memoryStream != null)
				{
					DeflateStream.smethod_11(memoryStream);
				}
			}
			return array;
		}

		// Token: 0x06001429 RID: 5161 RVA: 0x00069934 File Offset: 0x00067B34
		public static string UncompressString(byte[] compressed)
		{
			MemoryStream memoryStream = DeflateStream.smethod_12(compressed);
			string text;
			try
			{
				Stream stream = new DeflateStream(memoryStream, CompressionMode.Decompress);
				text = ZlibBaseStream.UncompressString(compressed, stream);
			}
			finally
			{
				if (memoryStream != null)
				{
					DeflateStream.smethod_11(memoryStream);
				}
			}
			return text;
		}

		// Token: 0x0600142A RID: 5162 RVA: 0x00069978 File Offset: 0x00067B78
		public static byte[] UncompressBuffer(byte[] compressed)
		{
			MemoryStream memoryStream = DeflateStream.smethod_12(compressed);
			byte[] array;
			try
			{
				Stream stream = new DeflateStream(memoryStream, CompressionMode.Decompress);
				array = ZlibBaseStream.UncompressBuffer(compressed, stream);
			}
			finally
			{
				if (memoryStream != null)
				{
					DeflateStream.smethod_11(memoryStream);
				}
			}
			return array;
		}

		// Token: 0x0600142B RID: 5163 RVA: 0x00014B41 File Offset: 0x00012D41
		static ObjectDisposedException smethod_0(string string_0)
		{
			return new ObjectDisposedException(string_0);
		}

		// Token: 0x0600142C RID: 5164 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_1(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x0600142D RID: 5165 RVA: 0x00012E9A File Offset: 0x0001109A
		static void smethod_2(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x0600142E RID: 5166 RVA: 0x00012837 File Offset: 0x00010A37
		static bool smethod_3(Stream stream_0)
		{
			return stream_0.CanRead;
		}

		// Token: 0x0600142F RID: 5167 RVA: 0x00012D86 File Offset: 0x00010F86
		static bool smethod_4(Stream stream_0)
		{
			return stream_0.CanWrite;
		}

		// Token: 0x06001430 RID: 5168 RVA: 0x00012D8E File Offset: 0x00010F8E
		static void smethod_5(Stream stream_0)
		{
			stream_0.Flush();
		}

		// Token: 0x06001431 RID: 5169 RVA: 0x000109B6 File Offset: 0x0000EBB6
		static NotImplementedException smethod_6()
		{
			return new NotImplementedException();
		}

		// Token: 0x06001432 RID: 5170 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_7(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06001433 RID: 5171 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_8(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x06001434 RID: 5172 RVA: 0x0000C8A7 File Offset: 0x0000AAA7
		static MemoryStream smethod_9()
		{
			return new MemoryStream();
		}

		// Token: 0x06001435 RID: 5173 RVA: 0x0000C8C1 File Offset: 0x0000AAC1
		static byte[] smethod_10(MemoryStream memoryStream_0)
		{
			return memoryStream_0.ToArray();
		}

		// Token: 0x06001436 RID: 5174 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_11(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06001437 RID: 5175 RVA: 0x0000C877 File Offset: 0x0000AA77
		static MemoryStream smethod_12(byte[] byte_0)
		{
			return new MemoryStream(byte_0);
		}

		// Token: 0x04000751 RID: 1873
		internal ZlibBaseStream _baseStream;

		// Token: 0x04000752 RID: 1874
		internal Stream _innerStream;

		// Token: 0x04000753 RID: 1875
		private bool _disposed;
	}
}
