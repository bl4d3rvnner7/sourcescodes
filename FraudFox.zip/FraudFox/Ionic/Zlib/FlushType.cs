﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zlib
{
	// Token: 0x02000149 RID: 329
	[ComVisible(true)]
	public enum FlushType
	{
		// Token: 0x04000811 RID: 2065
		None,
		// Token: 0x04000812 RID: 2066
		Partial,
		// Token: 0x04000813 RID: 2067
		Sync,
		// Token: 0x04000814 RID: 2068
		Full,
		// Token: 0x04000815 RID: 2069
		Finish
	}
}
