﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zlib
{
	// Token: 0x02000151 RID: 337
	[ComVisible(true)]
	public sealed class Adler
	{
		// Token: 0x060014EE RID: 5358 RVA: 0x0006E408 File Offset: 0x0006C608
		public static uint Adler32(uint adler, byte[] buf, int index, int len)
		{
			if (buf != null)
			{
				uint num = adler & 65535U;
				uint num2 = (adler >> 16) & 65535U;
				while (len > 0)
				{
					int i = ((len < Adler.NMAX) ? len : Adler.NMAX);
					len -= i;
					while (i >= 16)
					{
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						i -= 16;
					}
					if (i != 0)
					{
						do
						{
							num += (uint)buf[index++];
							num2 += num;
						}
						while (--i != 0);
					}
					num %= Adler.BASE;
					num2 %= Adler.BASE;
				}
				return (num2 << 16) | num;
			}
			return 1U;
		}

		// Token: 0x04000840 RID: 2112
		private static readonly uint BASE = 65521U;

		// Token: 0x04000841 RID: 2113
		private static readonly int NMAX = 5552;
	}
}
