﻿using System;
using System.Runtime.CompilerServices;

namespace Ionic.Zlib
{
	// Token: 0x0200013E RID: 318
	internal sealed class InflateBlocks
	{
		// Token: 0x0600146D RID: 5229 RVA: 0x00069F70 File Offset: 0x00068170
		internal InflateBlocks(ZlibCodec codec, object checkfn, int w)
		{
			this._codec = codec;
			this.hufts = new int[4320];
			this.window = new byte[w];
			this.end = w;
			this.checkfn = checkfn;
			this.mode = InflateBlocks.InflateBlockMode.TYPE;
			this.Reset();
		}

		// Token: 0x0600146E RID: 5230 RVA: 0x00069FF0 File Offset: 0x000681F0
		internal uint Reset()
		{
			uint num = this.check;
			this.mode = InflateBlocks.InflateBlockMode.TYPE;
			this.bitk = 0;
			this.bitb = 0;
			this.writeAt = 0;
			this.readAt = 0;
			if (this.checkfn != null)
			{
				this._codec._Adler32 = (this.check = Adler.Adler32(0U, null, 0, 0));
			}
			return num;
		}

		// Token: 0x0600146F RID: 5231 RVA: 0x0006A050 File Offset: 0x00068250
		internal int Process(int r)
		{
			int num = this._codec.NextIn;
			int num2 = this._codec.AvailableBytesIn;
			int num3 = this.bitb;
			int i = this.bitk;
			int num4 = this.writeAt;
			int num5 = ((num4 < this.readAt) ? (this.readAt - num4 - 1) : (this.end - num4));
			int num6;
			for (;;)
			{
				switch (this.mode)
				{
				case InflateBlocks.InflateBlockMode.TYPE:
					while (i < 3)
					{
						if (num2 == 0)
						{
							goto IL_092F;
						}
						r = 0;
						num2--;
						num3 |= (int)(this._codec.InputBuffer[num++] & byte.MaxValue) << i;
						i += 8;
					}
					num6 = num3 & 7;
					this.last = num6 & 1;
					switch ((uint)num6 >> 1)
					{
					case 0U:
						num3 >>= 3;
						i -= 3;
						num6 = i & 7;
						num3 >>= num6;
						i -= num6;
						this.mode = InflateBlocks.InflateBlockMode.LENS;
						continue;
					case 1U:
					{
						int[] array = new int[1];
						int[] array2 = new int[1];
						int[][] array3 = new int[1][];
						int[][] array4 = new int[1][];
						InfTree.inflate_trees_fixed(array, array2, array3, array4, this._codec);
						this.codes.Init(array[0], array2[0], array3[0], 0, array4[0], 0);
						num3 >>= 3;
						i -= 3;
						this.mode = InflateBlocks.InflateBlockMode.CODES;
						continue;
					}
					case 2U:
						num3 >>= 3;
						i -= 3;
						this.mode = InflateBlocks.InflateBlockMode.TABLE;
						continue;
					case 3U:
						goto IL_08AF;
					default:
						continue;
					}
					break;
				case InflateBlocks.InflateBlockMode.LENS:
				{
					while (i < 32)
					{
						if (num2 == 0)
						{
							goto IL_09FD;
						}
						r = 0;
						num2--;
						num3 |= (int)(this._codec.InputBuffer[num++] & byte.MaxValue) << i;
						i += 8;
					}
					if (((~num3 >> 16) & 65535) != (num3 & 65535))
					{
						goto Block_45;
					}
					this.left = num3 & 65535;
					int num7 = 0;
					i = 0;
					num3 = num7;
					this.mode = ((this.left != 0) ? InflateBlocks.InflateBlockMode.STORED : ((this.last != 0) ? InflateBlocks.InflateBlockMode.DRY : InflateBlocks.InflateBlockMode.TYPE));
					continue;
				}
				case InflateBlocks.InflateBlockMode.STORED:
					if (num2 == 0)
					{
						goto IL_0AA9;
					}
					if (num5 == 0)
					{
						if (num4 == this.end)
						{
							if (this.readAt != 0)
							{
								num4 = 0;
								num5 = ((0 < this.readAt) ? (this.readAt - num4 - 1) : (this.end - num4));
							}
						}
						if (num5 == 0)
						{
							this.writeAt = num4;
							r = this.Flush(r);
							num4 = this.writeAt;
							num5 = ((num4 < this.readAt) ? (this.readAt - num4 - 1) : (this.end - num4));
							if (num4 == this.end && this.readAt != 0)
							{
								num4 = 0;
								num5 = ((0 < this.readAt) ? (this.readAt - num4 - 1) : (this.end - num4));
							}
							if (num5 == 0)
							{
								goto IL_0A53;
							}
						}
					}
					r = 0;
					num6 = this.left;
					if (num6 > num2)
					{
						num6 = num2;
					}
					if (num6 > num5)
					{
						num6 = num5;
					}
					InflateBlocks.smethod_0(this._codec.InputBuffer, num, this.window, num4, num6);
					num += num6;
					num2 -= num6;
					num4 += num6;
					num5 -= num6;
					if ((this.left -= num6) == 0)
					{
						this.mode = ((this.last != 0) ? InflateBlocks.InflateBlockMode.DRY : InflateBlocks.InflateBlockMode.TYPE);
						continue;
					}
					continue;
				case InflateBlocks.InflateBlockMode.TABLE:
					while (i < 14)
					{
						if (num2 == 0)
						{
							goto IL_0B77;
						}
						r = 0;
						num2--;
						num3 |= (int)(this._codec.InputBuffer[num++] & byte.MaxValue) << i;
						i += 8;
					}
					num6 = (this.table = num3 & 16383);
					if ((num6 & 31) <= 29 && ((num6 >> 5) & 31) <= 29)
					{
						num6 = 258 + (num6 & 31) + ((num6 >> 5) & 31);
						if (this.blens != null && this.blens.Length >= num6)
						{
							InflateBlocks.smethod_1(this.blens, 0, num6);
						}
						else
						{
							this.blens = new int[num6];
						}
						num3 >>= 14;
						i -= 14;
						this.index = 0;
						this.mode = InflateBlocks.InflateBlockMode.BTREE;
						goto IL_040A;
					}
					goto IL_0AFF;
				case InflateBlocks.InflateBlockMode.BTREE:
					goto IL_040A;
				case InflateBlocks.InflateBlockMode.DTREE:
					goto IL_02CC;
				case InflateBlocks.InflateBlockMode.CODES:
					goto IL_0055;
				case InflateBlocks.InflateBlockMode.DRY:
					goto IL_0E3A;
				case InflateBlocks.InflateBlockMode.DONE:
					goto IL_0EE0;
				case InflateBlocks.InflateBlockMode.BAD:
					goto IL_0F39;
				}
				goto Block_51;
				for (;;)
				{
					IL_02CC:
					num6 = this.table;
					if (this.index >= 258 + (num6 & 31) + ((num6 >> 5) & 31))
					{
						break;
					}
					num6 = this.bb[0];
					while (i < num6)
					{
						if (num2 == 0)
						{
							goto IL_0DD5;
						}
						r = 0;
						num2--;
						num3 |= (int)(this._codec.InputBuffer[num++] & byte.MaxValue) << i;
						i += 8;
					}
					num6 = this.hufts[(this.tb[0] + (num3 & InternalInflateConstants.InflateMask[num6])) * 3 + 1];
					int num8 = this.hufts[(this.tb[0] + (num3 & InternalInflateConstants.InflateMask[num6])) * 3 + 2];
					if (num8 < 16)
					{
						num3 >>= num6;
						i -= num6;
						this.blens[this.index++] = num8;
					}
					else
					{
						int num9 = ((num8 == 18) ? 7 : (num8 - 14));
						int num10 = ((num8 == 18) ? 11 : 3);
						while (i < num6 + num9)
						{
							if (num2 == 0)
							{
								goto IL_0D7F;
							}
							r = 0;
							num2--;
							num3 |= (int)(this._codec.InputBuffer[num++] & byte.MaxValue) << i;
							i += 8;
						}
						num3 >>= num6;
						i -= num6;
						num10 += num3 & InternalInflateConstants.InflateMask[num9];
						num3 >>= num9;
						i -= num9;
						num9 = this.index;
						num6 = this.table;
						if (num9 + num10 > 258 + (num6 & 31) + ((num6 >> 5) & 31) || (num8 == 16 && num9 < 1))
						{
							goto IL_0D00;
						}
						num8 = ((num8 == 16) ? this.blens[num9 - 1] : 0);
						do
						{
							this.blens[num9++] = num8;
						}
						while (--num10 != 0);
						this.index = num9;
					}
				}
				this.tb[0] = -1;
				int[] array5 = new int[] { 9 };
				int[] array6 = new int[] { 6 };
				int[] array7 = new int[1];
				int[] array8 = new int[1];
				num6 = this.table;
				num6 = this.inftree.inflate_trees_dynamic(257 + (num6 & 31), 1 + ((num6 >> 5) & 31), this.blens, array5, array6, array7, array8, this.hufts, this._codec);
				if (num6 == 0)
				{
					this.codes.Init(array5[0], array6[0], this.hufts, array7[0], this.hufts, array8[0]);
					this.mode = InflateBlocks.InflateBlockMode.CODES;
					goto IL_0055;
				}
				goto IL_0C91;
				IL_040A:
				while (this.index < 4 + (this.table >> 10))
				{
					while (i < 3)
					{
						if (num2 == 0)
						{
							goto IL_0C3B;
						}
						r = 0;
						num2--;
						num3 |= (int)(this._codec.InputBuffer[num++] & byte.MaxValue) << i;
						i += 8;
					}
					this.blens[InflateBlocks.border[this.index++]] = num3 & 7;
					num3 >>= 3;
					i -= 3;
				}
				while (this.index < 19)
				{
					this.blens[InflateBlocks.border[this.index++]] = 0;
				}
				this.bb[0] = 7;
				num6 = this.inftree.inflate_trees_bits(this.blens, this.bb, this.tb, this.hufts, this._codec);
				if (num6 == 0)
				{
					this.index = 0;
					this.mode = InflateBlocks.InflateBlockMode.DTREE;
					goto IL_02CC;
				}
				goto IL_0BCD;
				IL_0055:
				this.bitb = num3;
				this.bitk = i;
				this._codec.AvailableBytesIn = num2;
				this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
				this._codec.NextIn = num;
				this.writeAt = num4;
				r = this.codes.Process(this, r);
				if (r != 1)
				{
					break;
				}
				r = 0;
				num = this._codec.NextIn;
				num2 = this._codec.AvailableBytesIn;
				num3 = this.bitb;
				i = this.bitk;
				num4 = this.writeAt;
				num5 = ((num4 < this.readAt) ? (this.readAt - num4 - 1) : (this.end - num4));
				if (this.last != 0)
				{
					goto IL_0E33;
				}
				this.mode = InflateBlocks.InflateBlockMode.TYPE;
			}
			return this.Flush(r);
			Block_45:
			this.mode = InflateBlocks.InflateBlockMode.BAD;
			this._codec.Message = <Module>.smethod_25<string>(1107670104U);
			r = -3;
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(-3);
			Block_51:
			r = -2;
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(-2);
			IL_08AF:
			num3 >>= 3;
			i -= 3;
			this.mode = InflateBlocks.InflateBlockMode.BAD;
			this._codec.Message = <Module>.smethod_26<string>(1502096783U);
			r = -3;
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(-3);
			IL_092F:
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(r);
			IL_09FD:
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(r);
			IL_0A53:
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(r);
			IL_0AA9:
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(r);
			IL_0AFF:
			this.mode = InflateBlocks.InflateBlockMode.BAD;
			this._codec.Message = <Module>.smethod_23<string>(2034328783U);
			r = -3;
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(-3);
			IL_0B77:
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(r);
			IL_0BCD:
			r = num6;
			if (r == -3)
			{
				this.blens = null;
				this.mode = InflateBlocks.InflateBlockMode.BAD;
			}
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(r);
			IL_0C3B:
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(r);
			IL_0C91:
			if (num6 == -3)
			{
				this.blens = null;
				this.mode = InflateBlocks.InflateBlockMode.BAD;
			}
			r = num6;
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(r);
			IL_0D00:
			this.blens = null;
			this.mode = InflateBlocks.InflateBlockMode.BAD;
			this._codec.Message = <Module>.smethod_27<string>(1452089301U);
			r = -3;
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(-3);
			IL_0D7F:
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(r);
			IL_0DD5:
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(r);
			IL_0E33:
			this.mode = InflateBlocks.InflateBlockMode.DRY;
			IL_0E3A:
			this.writeAt = num4;
			r = this.Flush(r);
			num4 = this.writeAt;
			int num11 = ((num4 < this.readAt) ? (this.readAt - num4 - 1) : (this.end - num4));
			if (this.readAt != this.writeAt)
			{
				this.bitb = num3;
				this.bitk = i;
				this._codec.AvailableBytesIn = num2;
				this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
				this._codec.NextIn = num;
				this.writeAt = num4;
				return this.Flush(r);
			}
			this.mode = InflateBlocks.InflateBlockMode.DONE;
			IL_0EE0:
			r = 1;
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(1);
			IL_0F39:
			r = -3;
			this.bitb = num3;
			this.bitk = i;
			this._codec.AvailableBytesIn = num2;
			this._codec.TotalBytesIn += (long)(num - this._codec.NextIn);
			this._codec.NextIn = num;
			this.writeAt = num4;
			return this.Flush(-3);
		}

		// Token: 0x06001470 RID: 5232 RVA: 0x0001516D File Offset: 0x0001336D
		internal void Free()
		{
			this.Reset();
			this.window = null;
			this.hufts = null;
		}

		// Token: 0x06001471 RID: 5233 RVA: 0x0006AFF0 File Offset: 0x000691F0
		internal void SetDictionary(byte[] d, int start, int n)
		{
			InflateBlocks.smethod_0(d, start, this.window, 0, n);
			this.writeAt = n;
			this.readAt = n;
		}

		// Token: 0x06001472 RID: 5234 RVA: 0x00015184 File Offset: 0x00013384
		internal int SyncPoint()
		{
			if (this.mode != InflateBlocks.InflateBlockMode.LENS)
			{
				return 0;
			}
			return 1;
		}

		// Token: 0x06001473 RID: 5235 RVA: 0x0006B01C File Offset: 0x0006921C
		internal int Flush(int r)
		{
			for (int i = 0; i < 2; i++)
			{
				int num;
				if (i == 0)
				{
					num = ((this.readAt <= this.writeAt) ? this.writeAt : this.end) - this.readAt;
				}
				else
				{
					num = this.writeAt - this.readAt;
				}
				if (num == 0)
				{
					if (r == -5)
					{
						r = 0;
					}
					return r;
				}
				if (num > this._codec.AvailableBytesOut)
				{
					num = this._codec.AvailableBytesOut;
				}
				if (num != 0 && r == -5)
				{
					r = 0;
				}
				this._codec.AvailableBytesOut -= num;
				this._codec.TotalBytesOut += (long)num;
				if (this.checkfn != null)
				{
					this._codec._Adler32 = (this.check = Adler.Adler32(this.check, this.window, this.readAt, num));
				}
				InflateBlocks.smethod_0(this.window, this.readAt, this._codec.OutputBuffer, this._codec.NextOut, num);
				this._codec.NextOut += num;
				this.readAt += num;
				if (this.readAt == this.end && i == 0)
				{
					this.readAt = 0;
					if (this.writeAt == this.end)
					{
						this.writeAt = 0;
					}
				}
				else
				{
					i++;
				}
			}
			return r;
		}

		// Token: 0x06001474 RID: 5236 RVA: 0x00015192 File Offset: 0x00013392
		// Note: this type is marked as 'beforefieldinit'.
		static InflateBlocks()
		{
			int[] array = new int[19];
			InflateBlocks.smethod_2(array, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050a-1).FieldHandle);
			InflateBlocks.border = array;
		}

		// Token: 0x06001475 RID: 5237 RVA: 0x0000C3EE File Offset: 0x0000A5EE
		static void smethod_0(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Array.Copy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x06001476 RID: 5238 RVA: 0x00014DF1 File Offset: 0x00012FF1
		static void smethod_1(Array array_0, int int_0, int int_1)
		{
			Array.Clear(array_0, int_0, int_1);
		}

		// Token: 0x06001477 RID: 5239 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_2(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x0400075E RID: 1886
		private const int MANY = 1440;

		// Token: 0x0400075F RID: 1887
		internal static readonly int[] border;

		// Token: 0x04000760 RID: 1888
		private InflateBlocks.InflateBlockMode mode;

		// Token: 0x04000761 RID: 1889
		internal int left;

		// Token: 0x04000762 RID: 1890
		internal int table;

		// Token: 0x04000763 RID: 1891
		internal int index;

		// Token: 0x04000764 RID: 1892
		internal int[] blens;

		// Token: 0x04000765 RID: 1893
		internal int[] bb = new int[1];

		// Token: 0x04000766 RID: 1894
		internal int[] tb = new int[1];

		// Token: 0x04000767 RID: 1895
		internal InflateCodes codes = new InflateCodes();

		// Token: 0x04000768 RID: 1896
		internal int last;

		// Token: 0x04000769 RID: 1897
		internal ZlibCodec _codec;

		// Token: 0x0400076A RID: 1898
		internal int bitk;

		// Token: 0x0400076B RID: 1899
		internal int bitb;

		// Token: 0x0400076C RID: 1900
		internal int[] hufts;

		// Token: 0x0400076D RID: 1901
		internal byte[] window;

		// Token: 0x0400076E RID: 1902
		internal int end;

		// Token: 0x0400076F RID: 1903
		internal int readAt;

		// Token: 0x04000770 RID: 1904
		internal int writeAt;

		// Token: 0x04000771 RID: 1905
		internal object checkfn;

		// Token: 0x04000772 RID: 1906
		internal uint check;

		// Token: 0x04000773 RID: 1907
		internal InfTree inftree = new InfTree();

		// Token: 0x0200013F RID: 319
		private enum InflateBlockMode
		{
			// Token: 0x04000775 RID: 1909
			TYPE,
			// Token: 0x04000776 RID: 1910
			LENS,
			// Token: 0x04000777 RID: 1911
			STORED,
			// Token: 0x04000778 RID: 1912
			TABLE,
			// Token: 0x04000779 RID: 1913
			BTREE,
			// Token: 0x0400077A RID: 1914
			DTREE,
			// Token: 0x0400077B RID: 1915
			CODES,
			// Token: 0x0400077C RID: 1916
			DRY,
			// Token: 0x0400077D RID: 1917
			DONE,
			// Token: 0x0400077E RID: 1918
			BAD
		}
	}
}
