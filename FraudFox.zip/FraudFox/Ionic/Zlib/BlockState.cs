﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x02000137 RID: 311
	internal enum BlockState
	{
		// Token: 0x040006F9 RID: 1785
		NeedMore,
		// Token: 0x040006FA RID: 1786
		BlockDone,
		// Token: 0x040006FB RID: 1787
		FinishStarted,
		// Token: 0x040006FC RID: 1788
		FinishDone
	}
}
