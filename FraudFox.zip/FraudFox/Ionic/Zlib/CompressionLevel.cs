﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zlib
{
	// Token: 0x0200014A RID: 330
	[ComVisible(true)]
	public enum CompressionLevel
	{
		// Token: 0x04000817 RID: 2071
		None,
		// Token: 0x04000818 RID: 2072
		Level0 = 0,
		// Token: 0x04000819 RID: 2073
		BestSpeed,
		// Token: 0x0400081A RID: 2074
		Level1 = 1,
		// Token: 0x0400081B RID: 2075
		Level2,
		// Token: 0x0400081C RID: 2076
		Level3,
		// Token: 0x0400081D RID: 2077
		Level4,
		// Token: 0x0400081E RID: 2078
		Level5,
		// Token: 0x0400081F RID: 2079
		Default,
		// Token: 0x04000820 RID: 2080
		Level6 = 6,
		// Token: 0x04000821 RID: 2081
		Level7,
		// Token: 0x04000822 RID: 2082
		Level8,
		// Token: 0x04000823 RID: 2083
		BestCompression,
		// Token: 0x04000824 RID: 2084
		Level9 = 9
	}
}
