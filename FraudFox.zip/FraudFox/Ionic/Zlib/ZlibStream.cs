﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace Ionic.Zlib
{
	// Token: 0x02000157 RID: 343
	[ComVisible(true)]
	public class ZlibStream : Stream
	{
		// Token: 0x06001542 RID: 5442 RVA: 0x00015695 File Offset: 0x00013895
		public ZlibStream(Stream stream, CompressionMode mode)
			: this(stream, mode, CompressionLevel.Default, false)
		{
		}

		// Token: 0x06001543 RID: 5443 RVA: 0x000156A1 File Offset: 0x000138A1
		public ZlibStream(Stream stream, CompressionMode mode, CompressionLevel level)
			: this(stream, mode, level, false)
		{
		}

		// Token: 0x06001544 RID: 5444 RVA: 0x000156AD File Offset: 0x000138AD
		public ZlibStream(Stream stream, CompressionMode mode, bool leaveOpen)
			: this(stream, mode, CompressionLevel.Default, leaveOpen)
		{
		}

		// Token: 0x06001545 RID: 5445 RVA: 0x000156B9 File Offset: 0x000138B9
		public ZlibStream(Stream stream, CompressionMode mode, CompressionLevel level, bool leaveOpen)
		{
			this._baseStream = new ZlibBaseStream(stream, mode, level, ZlibStreamFlavor.ZLIB, leaveOpen);
		}

		// Token: 0x17000319 RID: 793
		// (get) Token: 0x06001546 RID: 5446 RVA: 0x000156D6 File Offset: 0x000138D6
		// (set) Token: 0x06001547 RID: 5447 RVA: 0x000156E3 File Offset: 0x000138E3
		public virtual FlushType FlushMode
		{
			get
			{
				return this._baseStream._flushMode;
			}
			set
			{
				if (this._disposed)
				{
					throw ZlibStream.smethod_0(<Module>.smethod_27<string>(4109076429U));
				}
				this._baseStream._flushMode = value;
			}
		}

		// Token: 0x1700031A RID: 794
		// (get) Token: 0x06001548 RID: 5448 RVA: 0x00015709 File Offset: 0x00013909
		// (set) Token: 0x06001549 RID: 5449 RVA: 0x0006F828 File Offset: 0x0006DA28
		public int BufferSize
		{
			get
			{
				return this._baseStream._bufferSize;
			}
			set
			{
				if (this._disposed)
				{
					throw ZlibStream.smethod_0(<Module>.smethod_24<string>(3622683272U));
				}
				if (this._baseStream._workingBuffer != null)
				{
					throw new ZlibException(<Module>.smethod_25<string>(1922764750U));
				}
				if (value < 1024)
				{
					throw new ZlibException(ZlibStream.smethod_1(<Module>.smethod_24<string>(3979877050U), value, 1024));
				}
				this._baseStream._bufferSize = value;
			}
		}

		// Token: 0x1700031B RID: 795
		// (get) Token: 0x0600154A RID: 5450 RVA: 0x00015716 File Offset: 0x00013916
		public virtual long TotalIn
		{
			get
			{
				return this._baseStream._z.TotalBytesIn;
			}
		}

		// Token: 0x1700031C RID: 796
		// (get) Token: 0x0600154B RID: 5451 RVA: 0x00015728 File Offset: 0x00013928
		public virtual long TotalOut
		{
			get
			{
				return this._baseStream._z.TotalBytesOut;
			}
		}

		// Token: 0x0600154C RID: 5452 RVA: 0x0006F8A4 File Offset: 0x0006DAA4
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (!this._disposed)
				{
					if (disposing && this._baseStream != null)
					{
						ZlibStream.smethod_2(this._baseStream);
					}
					this._disposed = true;
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x1700031D RID: 797
		// (get) Token: 0x0600154D RID: 5453 RVA: 0x0001573A File Offset: 0x0001393A
		public override bool CanRead
		{
			get
			{
				if (this._disposed)
				{
					throw ZlibStream.smethod_0(<Module>.smethod_26<string>(2421430607U));
				}
				return ZlibStream.smethod_3(this._baseStream._stream);
			}
		}

		// Token: 0x1700031E RID: 798
		// (get) Token: 0x0600154E RID: 5454 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700031F RID: 799
		// (get) Token: 0x0600154F RID: 5455 RVA: 0x00015764 File Offset: 0x00013964
		public override bool CanWrite
		{
			get
			{
				if (this._disposed)
				{
					throw ZlibStream.smethod_0(<Module>.smethod_24<string>(3622683272U));
				}
				return ZlibStream.smethod_4(this._baseStream._stream);
			}
		}

		// Token: 0x06001550 RID: 5456 RVA: 0x0001578E File Offset: 0x0001398E
		public override void Flush()
		{
			if (this._disposed)
			{
				throw ZlibStream.smethod_0(<Module>.smethod_27<string>(4109076429U));
			}
			ZlibStream.smethod_5(this._baseStream);
		}

		// Token: 0x17000320 RID: 800
		// (get) Token: 0x06001551 RID: 5457 RVA: 0x000157B3 File Offset: 0x000139B3
		public override long Length
		{
			get
			{
				throw ZlibStream.smethod_6();
			}
		}

		// Token: 0x17000321 RID: 801
		// (get) Token: 0x06001552 RID: 5458 RVA: 0x0006F8F0 File Offset: 0x0006DAF0
		// (set) Token: 0x06001553 RID: 5459 RVA: 0x000157B3 File Offset: 0x000139B3
		public override long Position
		{
			get
			{
				if (this._baseStream._streamMode == ZlibBaseStream.StreamMode.Writer)
				{
					goto IL_0045;
				}
				if (this._baseStream._streamMode != ZlibBaseStream.StreamMode.Reader)
				{
					return 0L;
				}
				int num = -777733241;
				IL_002C:
				switch (num ^ -777733242)
				{
				case 0:
					IL_0045:
					num = -777733244;
					goto IL_002C;
				case 2:
					return this._baseStream._z.TotalBytesOut;
				}
				return this._baseStream._z.TotalBytesIn;
			}
			set
			{
				throw ZlibStream.smethod_6();
			}
		}

		// Token: 0x06001554 RID: 5460 RVA: 0x000157BA File Offset: 0x000139BA
		public override int Read(byte[] buffer, int offset, int count)
		{
			if (this._disposed)
			{
				throw ZlibStream.smethod_0(<Module>.smethod_24<string>(3622683272U));
			}
			return ZlibStream.smethod_7(this._baseStream, buffer, offset, count);
		}

		// Token: 0x06001555 RID: 5461 RVA: 0x000157B3 File Offset: 0x000139B3
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw ZlibStream.smethod_6();
		}

		// Token: 0x06001556 RID: 5462 RVA: 0x000157B3 File Offset: 0x000139B3
		public override void SetLength(long value)
		{
			throw ZlibStream.smethod_6();
		}

		// Token: 0x06001557 RID: 5463 RVA: 0x000157E2 File Offset: 0x000139E2
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (this._disposed)
			{
				throw ZlibStream.smethod_0(<Module>.smethod_23<string>(535984021U));
			}
			ZlibStream.smethod_8(this._baseStream, buffer, offset, count);
		}

		// Token: 0x06001558 RID: 5464 RVA: 0x0006F96C File Offset: 0x0006DB6C
		public static byte[] CompressString(string s)
		{
			MemoryStream memoryStream = ZlibStream.smethod_9();
			byte[] array;
			try
			{
				Stream stream = new ZlibStream(memoryStream, CompressionMode.Compress, CompressionLevel.BestCompression);
				ZlibBaseStream.CompressString(s, stream);
				array = ZlibStream.smethod_10(memoryStream);
			}
			finally
			{
				if (memoryStream != null)
				{
					ZlibStream.smethod_11(memoryStream);
				}
			}
			return array;
		}

		// Token: 0x06001559 RID: 5465 RVA: 0x0006F9B4 File Offset: 0x0006DBB4
		public static byte[] CompressBuffer(byte[] b)
		{
			MemoryStream memoryStream = ZlibStream.smethod_9();
			byte[] array;
			try
			{
				Stream stream = new ZlibStream(memoryStream, CompressionMode.Compress, CompressionLevel.BestCompression);
				ZlibBaseStream.CompressBuffer(b, stream);
				array = ZlibStream.smethod_10(memoryStream);
			}
			finally
			{
				if (memoryStream != null)
				{
					ZlibStream.smethod_11(memoryStream);
				}
			}
			return array;
		}

		// Token: 0x0600155A RID: 5466 RVA: 0x0006F9FC File Offset: 0x0006DBFC
		public static string UncompressString(byte[] compressed)
		{
			MemoryStream memoryStream = ZlibStream.smethod_12(compressed);
			string text;
			try
			{
				Stream stream = new ZlibStream(memoryStream, CompressionMode.Decompress);
				text = ZlibBaseStream.UncompressString(compressed, stream);
			}
			finally
			{
				if (memoryStream != null)
				{
					ZlibStream.smethod_11(memoryStream);
				}
			}
			return text;
		}

		// Token: 0x0600155B RID: 5467 RVA: 0x0006FA40 File Offset: 0x0006DC40
		public static byte[] UncompressBuffer(byte[] compressed)
		{
			MemoryStream memoryStream = ZlibStream.smethod_12(compressed);
			byte[] array;
			try
			{
				Stream stream = new ZlibStream(memoryStream, CompressionMode.Decompress);
				array = ZlibBaseStream.UncompressBuffer(compressed, stream);
			}
			finally
			{
				if (memoryStream != null)
				{
					ZlibStream.smethod_11(memoryStream);
				}
			}
			return array;
		}

		// Token: 0x0600155C RID: 5468 RVA: 0x00014B41 File Offset: 0x00012D41
		static ObjectDisposedException smethod_0(string string_0)
		{
			return new ObjectDisposedException(string_0);
		}

		// Token: 0x0600155D RID: 5469 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_1(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x0600155E RID: 5470 RVA: 0x00012E9A File Offset: 0x0001109A
		static void smethod_2(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x0600155F RID: 5471 RVA: 0x00012837 File Offset: 0x00010A37
		static bool smethod_3(Stream stream_0)
		{
			return stream_0.CanRead;
		}

		// Token: 0x06001560 RID: 5472 RVA: 0x00012D86 File Offset: 0x00010F86
		static bool smethod_4(Stream stream_0)
		{
			return stream_0.CanWrite;
		}

		// Token: 0x06001561 RID: 5473 RVA: 0x00012D8E File Offset: 0x00010F8E
		static void smethod_5(Stream stream_0)
		{
			stream_0.Flush();
		}

		// Token: 0x06001562 RID: 5474 RVA: 0x0000E031 File Offset: 0x0000C231
		static NotSupportedException smethod_6()
		{
			return new NotSupportedException();
		}

		// Token: 0x06001563 RID: 5475 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_7(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06001564 RID: 5476 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_8(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x06001565 RID: 5477 RVA: 0x0000C8A7 File Offset: 0x0000AAA7
		static MemoryStream smethod_9()
		{
			return new MemoryStream();
		}

		// Token: 0x06001566 RID: 5478 RVA: 0x0000C8C1 File Offset: 0x0000AAC1
		static byte[] smethod_10(MemoryStream memoryStream_0)
		{
			return memoryStream_0.ToArray();
		}

		// Token: 0x06001567 RID: 5479 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_11(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06001568 RID: 5480 RVA: 0x0000C877 File Offset: 0x0000AA77
		static MemoryStream smethod_12(byte[] byte_0)
		{
			return new MemoryStream(byte_0);
		}

		// Token: 0x04000875 RID: 2165
		internal ZlibBaseStream _baseStream;

		// Token: 0x04000876 RID: 2166
		private bool _disposed;
	}
}
