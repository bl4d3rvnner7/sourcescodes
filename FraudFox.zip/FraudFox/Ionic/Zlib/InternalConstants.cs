﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x0200014F RID: 335
	internal static class InternalConstants
	{
		// Token: 0x0400082C RID: 2092
		internal static readonly int MAX_BITS = 15;

		// Token: 0x0400082D RID: 2093
		internal static readonly int BL_CODES = 19;

		// Token: 0x0400082E RID: 2094
		internal static readonly int D_CODES = 30;

		// Token: 0x0400082F RID: 2095
		internal static readonly int LITERALS = 256;

		// Token: 0x04000830 RID: 2096
		internal static readonly int LENGTH_CODES = 29;

		// Token: 0x04000831 RID: 2097
		internal static readonly int L_CODES = InternalConstants.LITERALS + 1 + InternalConstants.LENGTH_CODES;

		// Token: 0x04000832 RID: 2098
		internal static readonly int MAX_BL_BITS = 7;

		// Token: 0x04000833 RID: 2099
		internal static readonly int REP_3_6 = 16;

		// Token: 0x04000834 RID: 2100
		internal static readonly int REPZ_3_10 = 17;

		// Token: 0x04000835 RID: 2101
		internal static readonly int REPZ_11_138 = 18;
	}
}
