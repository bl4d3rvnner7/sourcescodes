﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x02000139 RID: 313
	internal sealed class DeflateManager
	{
		// Token: 0x060013DC RID: 5084 RVA: 0x000671B0 File Offset: 0x000653B0
		internal DeflateManager()
		{
			this.dyn_ltree = new short[DeflateManager.HEAP_SIZE * 2];
			this.dyn_dtree = new short[(2 * InternalConstants.D_CODES + 1) * 2];
			this.bl_tree = new short[(2 * InternalConstants.BL_CODES + 1) * 2];
		}

		// Token: 0x060013DD RID: 5085 RVA: 0x00067264 File Offset: 0x00065464
		private void _InitializeLazyMatch()
		{
			this.window_size = 2 * this.w_size;
			DeflateManager.smethod_0(this.head, 0, this.hash_size);
			this.config = DeflateManager.Config.Lookup(this.compressionLevel);
			this.SetDeflater();
			this.strstart = 0;
			this.block_start = 0;
			this.lookahead = 0;
			this.match_length = (this.prev_length = DeflateManager.MIN_MATCH - 1);
			this.match_available = 0;
			this.ins_h = 0;
		}

		// Token: 0x060013DE RID: 5086 RVA: 0x000672E4 File Offset: 0x000654E4
		private void _InitializeTreeData()
		{
			this.treeLiterals.dyn_tree = this.dyn_ltree;
			this.treeLiterals.staticTree = StaticTree.Literals;
			this.treeDistances.dyn_tree = this.dyn_dtree;
			this.treeDistances.staticTree = StaticTree.Distances;
			this.treeBitLengths.dyn_tree = this.bl_tree;
			this.treeBitLengths.staticTree = StaticTree.BitLengths;
			this.bi_buf = 0;
			this.bi_valid = 0;
			this.last_eob_len = 8;
			this._InitializeBlocks();
		}

		// Token: 0x060013DF RID: 5087 RVA: 0x00067370 File Offset: 0x00065570
		internal void _InitializeBlocks()
		{
			for (int i = 0; i < InternalConstants.L_CODES; i++)
			{
				this.dyn_ltree[i * 2] = 0;
			}
			for (int j = 0; j < InternalConstants.D_CODES; j++)
			{
				this.dyn_dtree[j * 2] = 0;
			}
			for (int k = 0; k < InternalConstants.BL_CODES; k++)
			{
				this.bl_tree[k * 2] = 0;
			}
			this.dyn_ltree[DeflateManager.END_BLOCK * 2] = 1;
			this.static_len = 0;
			this.opt_len = 0;
			this.matches = 0;
			this.last_lit = 0;
		}

		// Token: 0x060013E0 RID: 5088 RVA: 0x000673FC File Offset: 0x000655FC
		internal void pqdownheap(short[] tree, int k)
		{
			int num = this.heap[k];
			for (int i = k << 1; i <= this.heap_len; i <<= 1)
			{
				if (i < this.heap_len && DeflateManager._IsSmaller(tree, this.heap[i + 1], this.heap[i], this.depth))
				{
					i++;
				}
				if (DeflateManager._IsSmaller(tree, num, this.heap[i], this.depth))
				{
					break;
				}
				this.heap[k] = this.heap[i];
				k = i;
			}
			this.heap[k] = num;
		}

		// Token: 0x060013E1 RID: 5089 RVA: 0x00067488 File Offset: 0x00065688
		internal static bool _IsSmaller(short[] tree, int n, int m, sbyte[] depth)
		{
			short num = tree[n * 2];
			short num2 = tree[m * 2];
			return num < num2 || (num == num2 && depth[n] <= depth[m]);
		}

		// Token: 0x060013E2 RID: 5090 RVA: 0x000674B8 File Offset: 0x000656B8
		internal void scan_tree(short[] tree, int max_code)
		{
			int num = -1;
			int num2 = (int)tree[1];
			int num3 = 0;
			int num4 = 7;
			int num5 = 4;
			if (num2 == 0)
			{
				num4 = 138;
				num5 = 3;
			}
			tree[(max_code + 1) * 2 + 1] = short.MaxValue;
			for (int i = 0; i <= max_code; i++)
			{
				int num6 = num2;
				num2 = (int)tree[(i + 1) * 2 + 1];
				if (++num3 >= num4 || num6 != num2)
				{
					if (num3 < num5)
					{
						this.bl_tree[num6 * 2] = (short)((int)this.bl_tree[num6 * 2] + num3);
					}
					else if (num6 != 0)
					{
						if (num6 != num)
						{
							short[] array = this.bl_tree;
							int num7 = num6 * 2;
							array[num7] += 1;
						}
						short[] array2 = this.bl_tree;
						int num8 = InternalConstants.REP_3_6 * 2;
						array2[num8] += 1;
					}
					else if (num3 > 10)
					{
						short[] array3 = this.bl_tree;
						int num9 = InternalConstants.REPZ_11_138 * 2;
						array3[num9] += 1;
					}
					else
					{
						short[] array4 = this.bl_tree;
						int num10 = InternalConstants.REPZ_3_10 * 2;
						array4[num10] += 1;
					}
					num3 = 0;
					num = num6;
					if (num2 == 0)
					{
						num4 = 138;
						num5 = 3;
					}
					else if (num6 == num2)
					{
						num4 = 6;
						num5 = 3;
					}
					else
					{
						num4 = 7;
						num5 = 4;
					}
				}
			}
		}

		// Token: 0x060013E3 RID: 5091 RVA: 0x000675D4 File Offset: 0x000657D4
		internal int build_bl_tree()
		{
			this.scan_tree(this.dyn_ltree, this.treeLiterals.max_code);
			this.scan_tree(this.dyn_dtree, this.treeDistances.max_code);
			this.treeBitLengths.build_tree(this);
			int num = InternalConstants.BL_CODES - 1;
			while (num >= 3 && this.bl_tree[(int)(Tree.bl_order[num] * 2 + 1)] == 0)
			{
				num--;
			}
			this.opt_len += 3 * (num + 1) + 5 + 5 + 4;
			return num;
		}

		// Token: 0x060013E4 RID: 5092 RVA: 0x0006765C File Offset: 0x0006585C
		internal void send_all_trees(int lcodes, int dcodes, int blcodes)
		{
			this.send_bits(lcodes - 257, 5);
			this.send_bits(dcodes - 1, 5);
			this.send_bits(blcodes - 4, 4);
			for (int i = 0; i < blcodes; i++)
			{
				this.send_bits((int)this.bl_tree[(int)(Tree.bl_order[i] * 2 + 1)], 3);
			}
			this.send_tree(this.dyn_ltree, lcodes - 1);
			this.send_tree(this.dyn_dtree, dcodes - 1);
		}

		// Token: 0x060013E5 RID: 5093 RVA: 0x000676D0 File Offset: 0x000658D0
		internal void send_tree(short[] tree, int max_code)
		{
			int num = -1;
			int num2 = (int)tree[1];
			int num3 = 0;
			int num4 = 7;
			int num5 = 4;
			if (num2 == 0)
			{
				num4 = 138;
				num5 = 3;
			}
			for (int i = 0; i <= max_code; i++)
			{
				int num6 = num2;
				num2 = (int)tree[(i + 1) * 2 + 1];
				if (++num3 >= num4 || num6 != num2)
				{
					if (num3 < num5)
					{
						do
						{
							this.send_code(num6, this.bl_tree);
						}
						while (--num3 != 0);
					}
					else if (num6 != 0)
					{
						if (num6 != num)
						{
							this.send_code(num6, this.bl_tree);
							num3--;
						}
						this.send_code(InternalConstants.REP_3_6, this.bl_tree);
						this.send_bits(num3 - 3, 2);
					}
					else if (num3 <= 10)
					{
						this.send_code(InternalConstants.REPZ_3_10, this.bl_tree);
						this.send_bits(num3 - 3, 3);
					}
					else
					{
						this.send_code(InternalConstants.REPZ_11_138, this.bl_tree);
						this.send_bits(num3 - 11, 7);
					}
					num3 = 0;
					num = num6;
					if (num2 == 0)
					{
						num4 = 138;
						num5 = 3;
					}
					else if (num6 == num2)
					{
						num4 = 6;
						num5 = 3;
					}
					else
					{
						num4 = 7;
						num5 = 4;
					}
				}
			}
		}

		// Token: 0x060013E6 RID: 5094 RVA: 0x00014D2D File Offset: 0x00012F2D
		private void put_bytes(byte[] p, int start, int len)
		{
			DeflateManager.smethod_1(p, start, this.pending, this.pendingCount, len);
			this.pendingCount += len;
		}

		// Token: 0x060013E7 RID: 5095 RVA: 0x000677E4 File Offset: 0x000659E4
		internal void send_code(int c, short[] tree)
		{
			int num = c * 2;
			this.send_bits((int)tree[num] & 65535, (int)tree[num + 1] & 65535);
		}

		// Token: 0x060013E8 RID: 5096 RVA: 0x00067810 File Offset: 0x00065A10
		internal void send_bits(int value, int length)
		{
			if (this.bi_valid > DeflateManager.Buf_size - length)
			{
				this.bi_buf |= (short)((value << this.bi_valid) & 65535);
				this.pending[this.pendingCount++] = (byte)this.bi_buf;
				this.pending[this.pendingCount++] = (byte)(this.bi_buf >> 8);
				this.bi_buf = (short)((uint)value >> DeflateManager.Buf_size - this.bi_valid);
				this.bi_valid += length - DeflateManager.Buf_size;
				return;
			}
			this.bi_buf |= (short)((value << this.bi_valid) & 65535);
			this.bi_valid += length;
		}

		// Token: 0x060013E9 RID: 5097 RVA: 0x000678EC File Offset: 0x00065AEC
		internal void _tr_align()
		{
			this.send_bits(DeflateManager.STATIC_TREES << 1, 3);
			this.send_code(DeflateManager.END_BLOCK, StaticTree.lengthAndLiteralsTreeCodes);
			this.bi_flush();
			if (1 + this.last_eob_len + 10 - this.bi_valid < 9)
			{
				this.send_bits(DeflateManager.STATIC_TREES << 1, 3);
				this.send_code(DeflateManager.END_BLOCK, StaticTree.lengthAndLiteralsTreeCodes);
				this.bi_flush();
			}
			this.last_eob_len = 7;
		}

		// Token: 0x060013EA RID: 5098 RVA: 0x00067960 File Offset: 0x00065B60
		internal bool _tr_tally(int dist, int lc)
		{
			this.pending[this._distanceOffset + this.last_lit * 2] = (byte)((uint)dist >> 8);
			this.pending[this._distanceOffset + this.last_lit * 2 + 1] = (byte)dist;
			this.pending[this._lengthOffset + this.last_lit] = (byte)lc;
			this.last_lit++;
			if (dist == 0)
			{
				short[] array = this.dyn_ltree;
				int num = lc * 2;
				array[num] += 1;
			}
			else
			{
				this.matches++;
				dist--;
				short[] array2 = this.dyn_ltree;
				int num2 = ((int)Tree.LengthCode[lc] + InternalConstants.LITERALS + 1) * 2;
				array2[num2] += 1;
				short[] array3 = this.dyn_dtree;
				int num3 = Tree.DistanceCode(dist) * 2;
				array3[num3] += 1;
			}
			if ((this.last_lit & 8191) == 0 && this.compressionLevel > CompressionLevel.Level2)
			{
				int num4 = this.last_lit << 3;
				int num5 = this.strstart - this.block_start;
				for (int i = 0; i < InternalConstants.D_CODES; i++)
				{
					num4 = (int)((long)num4 + (long)this.dyn_dtree[i * 2] * (5L + (long)Tree.ExtraDistanceBits[i]));
				}
				num4 >>= 3;
				if (this.matches < this.last_lit / 2 && num4 < num5 / 2)
				{
					return true;
				}
			}
			return this.last_lit == this.lit_bufsize - 1 || this.last_lit == this.lit_bufsize;
		}

		// Token: 0x060013EB RID: 5099 RVA: 0x00067ACC File Offset: 0x00065CCC
		internal void send_compressed_block(short[] ltree, short[] dtree)
		{
			int num = 0;
			if (this.last_lit != 0)
			{
				do
				{
					int num2 = this._distanceOffset + num * 2;
					int num3 = (((int)this.pending[num2] << 8) & 65280) | (int)(this.pending[num2 + 1] & byte.MaxValue);
					int num4 = (int)(this.pending[this._lengthOffset + num] & byte.MaxValue);
					num++;
					if (num3 == 0)
					{
						this.send_code(num4, ltree);
					}
					else
					{
						int num5 = (int)Tree.LengthCode[num4];
						this.send_code(num5 + InternalConstants.LITERALS + 1, ltree);
						int num6 = Tree.ExtraLengthBits[num5];
						if (num6 != 0)
						{
							num4 -= Tree.LengthBase[num5];
							this.send_bits(num4, num6);
						}
						num3--;
						num5 = Tree.DistanceCode(num3);
						this.send_code(num5, dtree);
						num6 = Tree.ExtraDistanceBits[num5];
						if (num6 != 0)
						{
							num3 -= Tree.DistanceBase[num5];
							this.send_bits(num3, num6);
						}
					}
				}
				while (num < this.last_lit);
			}
			this.send_code(DeflateManager.END_BLOCK, ltree);
			this.last_eob_len = (int)ltree[DeflateManager.END_BLOCK * 2 + 1];
		}

		// Token: 0x060013EC RID: 5100 RVA: 0x00067BE0 File Offset: 0x00065DE0
		internal void set_data_type()
		{
			int i = 0;
			int num = 0;
			int num2 = 0;
			while (i < 7)
			{
				num2 += (int)this.dyn_ltree[i * 2];
				i++;
			}
			while (i < 128)
			{
				num += (int)this.dyn_ltree[i * 2];
				i++;
			}
			while (i < InternalConstants.LITERALS)
			{
				num2 += (int)this.dyn_ltree[i * 2];
				i++;
			}
			this.data_type = (sbyte)((num2 > num >> 2) ? DeflateManager.Z_BINARY : DeflateManager.Z_ASCII);
		}

		// Token: 0x060013ED RID: 5101 RVA: 0x00067C5C File Offset: 0x00065E5C
		internal void bi_flush()
		{
			if (this.bi_valid == 16)
			{
				this.pending[this.pendingCount++] = (byte)this.bi_buf;
				this.pending[this.pendingCount++] = (byte)(this.bi_buf >> 8);
				this.bi_buf = 0;
				this.bi_valid = 0;
				return;
			}
			if (this.bi_valid >= 8)
			{
				this.pending[this.pendingCount++] = (byte)this.bi_buf;
				this.bi_buf = (short)(this.bi_buf >> 8);
				this.bi_valid -= 8;
			}
		}

		// Token: 0x060013EE RID: 5102 RVA: 0x00067D08 File Offset: 0x00065F08
		internal void bi_windup()
		{
			if (this.bi_valid > 8)
			{
				this.pending[this.pendingCount++] = (byte)this.bi_buf;
				this.pending[this.pendingCount++] = (byte)(this.bi_buf >> 8);
			}
			else if (this.bi_valid > 0)
			{
				this.pending[this.pendingCount++] = (byte)this.bi_buf;
			}
			this.bi_buf = 0;
			this.bi_valid = 0;
		}

		// Token: 0x060013EF RID: 5103 RVA: 0x00067D98 File Offset: 0x00065F98
		internal void copy_block(int buf, int len, bool header)
		{
			this.bi_windup();
			this.last_eob_len = 8;
			if (header)
			{
				this.pending[this.pendingCount++] = (byte)len;
				this.pending[this.pendingCount++] = (byte)(len >> 8);
				this.pending[this.pendingCount++] = (byte)(~(byte)len);
				this.pending[this.pendingCount++] = (byte)(~len >> 8);
			}
			this.put_bytes(this.window, buf, len);
		}

		// Token: 0x060013F0 RID: 5104 RVA: 0x00014D51 File Offset: 0x00012F51
		internal void flush_block_only(bool eof)
		{
			this._tr_flush_block((this.block_start >= 0) ? this.block_start : (-1), this.strstart - this.block_start, eof);
			this.block_start = this.strstart;
			this._codec.flush_pending();
		}

		// Token: 0x060013F1 RID: 5105 RVA: 0x00067E34 File Offset: 0x00066034
		internal BlockState DeflateNone(FlushType flush)
		{
			int num = 65535;
			if (65535 > this.pending.Length - 5)
			{
				num = this.pending.Length - 5;
			}
			for (;;)
			{
				if (this.lookahead <= 1)
				{
					this._fillWindow();
					if (this.lookahead == 0 && flush == FlushType.None)
					{
						break;
					}
					if (this.lookahead == 0)
					{
						goto IL_00EC;
					}
				}
				this.strstart += this.lookahead;
				this.lookahead = 0;
				int num2 = this.block_start + num;
				if (this.strstart == 0 || this.strstart >= num2)
				{
					this.lookahead = this.strstart - num2;
					this.strstart = num2;
					this.flush_block_only(false);
					if (this._codec.AvailableBytesOut == 0)
					{
						return BlockState.NeedMore;
					}
				}
				if (this.strstart - this.block_start >= this.w_size - DeflateManager.MIN_LOOKAHEAD)
				{
					this.flush_block_only(false);
					if (this._codec.AvailableBytesOut == 0)
					{
						return BlockState.NeedMore;
					}
				}
			}
			return BlockState.NeedMore;
			IL_00EC:
			this.flush_block_only(flush == FlushType.Finish);
			if (this._codec.AvailableBytesOut == 0)
			{
				if (flush != FlushType.Finish)
				{
					return BlockState.NeedMore;
				}
				return BlockState.FinishStarted;
			}
			else
			{
				if (flush != FlushType.Finish)
				{
					return BlockState.BlockDone;
				}
				return BlockState.FinishDone;
			}
		}

		// Token: 0x060013F2 RID: 5106 RVA: 0x00014D90 File Offset: 0x00012F90
		internal void _tr_stored_block(int buf, int stored_len, bool eof)
		{
			this.send_bits((DeflateManager.STORED_BLOCK << 1) + (eof ? 1 : 0), 3);
			this.copy_block(buf, stored_len, true);
		}

		// Token: 0x060013F3 RID: 5107 RVA: 0x00067F54 File Offset: 0x00066154
		internal void _tr_flush_block(int buf, int stored_len, bool eof)
		{
			int num = 0;
			int num2;
			int num3;
			if (this.compressionLevel > CompressionLevel.None)
			{
				if ((int)this.data_type == DeflateManager.Z_UNKNOWN)
				{
					this.set_data_type();
				}
				this.treeLiterals.build_tree(this);
				this.treeDistances.build_tree(this);
				num = this.build_bl_tree();
				num2 = this.opt_len + 3 + 7 >> 3;
				num3 = this.static_len + 3 + 7 >> 3;
				if (num3 <= num2)
				{
					num2 = num3;
				}
			}
			else
			{
				num3 = (num2 = stored_len + 5);
			}
			if (stored_len + 4 <= num2)
			{
				if (buf != -1)
				{
					this._tr_stored_block(buf, stored_len, eof);
					goto IL_00F5;
				}
			}
			if (num3 == num2)
			{
				this.send_bits((DeflateManager.STATIC_TREES << 1) + (eof ? 1 : 0), 3);
				this.send_compressed_block(StaticTree.lengthAndLiteralsTreeCodes, StaticTree.distTreeCodes);
			}
			else
			{
				this.send_bits((DeflateManager.DYN_TREES << 1) + (eof ? 1 : 0), 3);
				this.send_all_trees(this.treeLiterals.max_code + 1, this.treeDistances.max_code + 1, num + 1);
				this.send_compressed_block(this.dyn_ltree, this.dyn_dtree);
			}
			IL_00F5:
			this._InitializeBlocks();
			if (eof)
			{
				this.bi_windup();
			}
		}

		// Token: 0x060013F4 RID: 5108 RVA: 0x00068068 File Offset: 0x00066268
		private void _fillWindow()
		{
			do
			{
				int num = this.window_size - this.lookahead - this.strstart;
				int num2;
				if (num == 0 && this.strstart == 0 && this.lookahead == 0)
				{
					num = this.w_size;
				}
				else if (num == -1)
				{
					num--;
				}
				else if (this.strstart >= this.w_size + this.w_size - DeflateManager.MIN_LOOKAHEAD)
				{
					DeflateManager.smethod_1(this.window, this.w_size, this.window, 0, this.w_size);
					this.match_start -= this.w_size;
					this.strstart -= this.w_size;
					this.block_start -= this.w_size;
					num2 = this.hash_size;
					int num3 = num2;
					do
					{
						int num4 = (int)this.head[--num3] & 65535;
						this.head[num3] = (short)((num4 >= this.w_size) ? (num4 - this.w_size) : 0);
					}
					while (--num2 != 0);
					num2 = this.w_size;
					num3 = num2;
					do
					{
						int num4 = (int)this.prev[--num3] & 65535;
						this.prev[num3] = (short)((num4 >= this.w_size) ? (num4 - this.w_size) : 0);
					}
					while (--num2 != 0);
					num += this.w_size;
				}
				if (this._codec.AvailableBytesIn == 0)
				{
					return;
				}
				num2 = this._codec.read_buf(this.window, this.strstart + this.lookahead, num);
				this.lookahead += num2;
				if (this.lookahead >= DeflateManager.MIN_MATCH)
				{
					this.ins_h = (int)(this.window[this.strstart] & byte.MaxValue);
					this.ins_h = ((this.ins_h << this.hash_shift) ^ (int)(this.window[this.strstart + 1] & byte.MaxValue)) & this.hash_mask;
				}
				if (this.lookahead >= DeflateManager.MIN_LOOKAHEAD)
				{
					break;
				}
			}
			while (this._codec.AvailableBytesIn != 0);
		}

		// Token: 0x060013F5 RID: 5109 RVA: 0x00068278 File Offset: 0x00066478
		internal BlockState DeflateFast(FlushType flush)
		{
			int num = 0;
			for (;;)
			{
				if (this.lookahead < DeflateManager.MIN_LOOKAHEAD)
				{
					this._fillWindow();
					if (this.lookahead < DeflateManager.MIN_LOOKAHEAD && flush == FlushType.None)
					{
						break;
					}
					if (this.lookahead == 0)
					{
						goto IL_02FA;
					}
				}
				if (this.lookahead >= DeflateManager.MIN_MATCH)
				{
					this.ins_h = ((this.ins_h << this.hash_shift) ^ (int)(this.window[this.strstart + (DeflateManager.MIN_MATCH - 1)] & byte.MaxValue)) & this.hash_mask;
					num = (int)this.head[this.ins_h] & 65535;
					this.prev[this.strstart & this.w_mask] = this.head[this.ins_h];
					this.head[this.ins_h] = (short)this.strstart;
				}
				if ((long)num != 0L && ((this.strstart - num) & 65535) <= this.w_size - DeflateManager.MIN_LOOKAHEAD && this.compressionStrategy != CompressionStrategy.HuffmanOnly)
				{
					this.match_length = this.longest_match(num);
				}
				bool flag;
				if (this.match_length >= DeflateManager.MIN_MATCH)
				{
					flag = this._tr_tally(this.strstart - this.match_start, this.match_length - DeflateManager.MIN_MATCH);
					this.lookahead -= this.match_length;
					if (this.match_length <= this.config.MaxLazy && this.lookahead >= DeflateManager.MIN_MATCH)
					{
						this.match_length--;
						do
						{
							this.strstart++;
							this.ins_h = ((this.ins_h << this.hash_shift) ^ (int)(this.window[this.strstart + (DeflateManager.MIN_MATCH - 1)] & byte.MaxValue)) & this.hash_mask;
							num = (int)this.head[this.ins_h] & 65535;
							this.prev[this.strstart & this.w_mask] = this.head[this.ins_h];
							this.head[this.ins_h] = (short)this.strstart;
						}
						while (--this.match_length != 0);
						this.strstart++;
					}
					else
					{
						this.strstart += this.match_length;
						this.match_length = 0;
						this.ins_h = (int)(this.window[this.strstart] & byte.MaxValue);
						this.ins_h = ((this.ins_h << this.hash_shift) ^ (int)(this.window[this.strstart + 1] & byte.MaxValue)) & this.hash_mask;
					}
				}
				else
				{
					flag = this._tr_tally(0, (int)(this.window[this.strstart] & byte.MaxValue));
					this.lookahead--;
					this.strstart++;
				}
				if (flag)
				{
					this.flush_block_only(false);
					if (this._codec.AvailableBytesOut == 0)
					{
						return BlockState.NeedMore;
					}
				}
			}
			return BlockState.NeedMore;
			IL_02FA:
			this.flush_block_only(flush == FlushType.Finish);
			if (this._codec.AvailableBytesOut == 0)
			{
				if (flush == FlushType.Finish)
				{
					return BlockState.FinishStarted;
				}
				return BlockState.NeedMore;
			}
			else
			{
				if (flush != FlushType.Finish)
				{
					return BlockState.BlockDone;
				}
				return BlockState.FinishDone;
			}
			return BlockState.NeedMore;
		}

		// Token: 0x060013F6 RID: 5110 RVA: 0x000685A8 File Offset: 0x000667A8
		internal BlockState DeflateSlow(FlushType flush)
		{
			int num = 0;
			for (;;)
			{
				if (this.lookahead < DeflateManager.MIN_LOOKAHEAD)
				{
					this._fillWindow();
					if (this.lookahead < DeflateManager.MIN_LOOKAHEAD && flush == FlushType.None)
					{
						return BlockState.NeedMore;
					}
					if (this.lookahead == 0)
					{
						goto IL_037A;
					}
				}
				if (this.lookahead >= DeflateManager.MIN_MATCH)
				{
					this.ins_h = ((this.ins_h << this.hash_shift) ^ (int)(this.window[this.strstart + (DeflateManager.MIN_MATCH - 1)] & byte.MaxValue)) & this.hash_mask;
					num = (int)this.head[this.ins_h] & 65535;
					this.prev[this.strstart & this.w_mask] = this.head[this.ins_h];
					this.head[this.ins_h] = (short)this.strstart;
				}
				this.prev_length = this.match_length;
				this.prev_match = this.match_start;
				this.match_length = DeflateManager.MIN_MATCH - 1;
				if (num != 0 && this.prev_length < this.config.MaxLazy && ((this.strstart - num) & 65535) <= this.w_size - DeflateManager.MIN_LOOKAHEAD)
				{
					if (this.compressionStrategy != CompressionStrategy.HuffmanOnly)
					{
						this.match_length = this.longest_match(num);
					}
					if (this.match_length <= 5)
					{
						if (this.compressionStrategy != CompressionStrategy.Filtered)
						{
							if (this.match_length != DeflateManager.MIN_MATCH || this.strstart - this.match_start <= 4096)
							{
								goto IL_016F;
							}
						}
						this.match_length = DeflateManager.MIN_MATCH - 1;
					}
				}
				IL_016F:
				if (this.prev_length >= DeflateManager.MIN_MATCH && this.match_length <= this.prev_length)
				{
					int num2 = this.strstart + this.lookahead - DeflateManager.MIN_MATCH;
					bool flag = this._tr_tally(this.strstart - 1 - this.prev_match, this.prev_length - DeflateManager.MIN_MATCH);
					this.lookahead -= this.prev_length - 1;
					this.prev_length -= 2;
					do
					{
						if (++this.strstart <= num2)
						{
							this.ins_h = ((this.ins_h << this.hash_shift) ^ (int)(this.window[this.strstart + (DeflateManager.MIN_MATCH - 1)] & byte.MaxValue)) & this.hash_mask;
							num = (int)this.head[this.ins_h] & 65535;
							this.prev[this.strstart & this.w_mask] = this.head[this.ins_h];
							this.head[this.ins_h] = (short)this.strstart;
						}
					}
					while (--this.prev_length != 0);
					this.match_available = 0;
					this.match_length = DeflateManager.MIN_MATCH - 1;
					this.strstart++;
					if (flag)
					{
						this.flush_block_only(false);
						if (this._codec.AvailableBytesOut == 0)
						{
							break;
						}
					}
				}
				else if (this.match_available != 0)
				{
					if (this._tr_tally(0, (int)(this.window[this.strstart - 1] & 255)))
					{
						this.flush_block_only(false);
					}
					this.strstart++;
					this.lookahead--;
					if (this._codec.AvailableBytesOut == 0)
					{
						return BlockState.NeedMore;
					}
				}
				else
				{
					this.match_available = 1;
					this.strstart++;
					this.lookahead--;
				}
			}
			return BlockState.NeedMore;
			IL_037A:
			if (this.match_available != 0)
			{
				bool flag = this._tr_tally(0, (int)(this.window[this.strstart - 1] & byte.MaxValue));
				this.match_available = 0;
			}
			this.flush_block_only(flush == FlushType.Finish);
			if (this._codec.AvailableBytesOut == 0)
			{
				if (flush == FlushType.Finish)
				{
					return BlockState.FinishStarted;
				}
				return BlockState.NeedMore;
			}
			else
			{
				if (flush != FlushType.Finish)
				{
					return BlockState.BlockDone;
				}
				return BlockState.FinishDone;
			}
		}

		// Token: 0x060013F7 RID: 5111 RVA: 0x00068984 File Offset: 0x00066B84
		internal int longest_match(int cur_match)
		{
			int num = this.config.MaxChainLength;
			int num2 = this.strstart;
			int num3 = this.prev_length;
			int num4 = ((this.strstart > this.w_size - DeflateManager.MIN_LOOKAHEAD) ? (this.strstart - (this.w_size - DeflateManager.MIN_LOOKAHEAD)) : 0);
			int niceLength = this.config.NiceLength;
			int num5 = this.w_mask;
			int num6 = this.strstart + DeflateManager.MAX_MATCH;
			byte b = this.window[num2 + num3 - 1];
			byte b2 = this.window[num2 + num3];
			if (this.prev_length >= this.config.GoodLength)
			{
				num >>= 2;
			}
			if (niceLength > this.lookahead)
			{
				niceLength = this.lookahead;
			}
			do
			{
				int num7 = cur_match;
				if (this.window[num7 + num3] == b2)
				{
					if (this.window[num7 + num3 - 1] == b)
					{
						if (this.window[num7] == this.window[num2] && this.window[++num7] == this.window[num2 + 1])
						{
							num2 += 2;
							num7++;
							while (this.window[++num2] == this.window[++num7] && this.window[++num2] == this.window[++num7] && this.window[++num2] == this.window[++num7])
							{
								if (this.window[++num2] != this.window[++num7])
								{
									break;
								}
								if (this.window[++num2] != this.window[++num7] || this.window[++num2] != this.window[++num7] || this.window[++num2] != this.window[++num7] || this.window[++num2] != this.window[++num7] || num2 >= num6)
								{
									break;
								}
							}
							int num8 = DeflateManager.MAX_MATCH - (num6 - num2);
							num2 = num6 - DeflateManager.MAX_MATCH;
							if (num8 > num3)
							{
								this.match_start = cur_match;
								num3 = num8;
								if (num8 >= niceLength)
								{
									break;
								}
								b = this.window[num2 + num3 - 1];
								b2 = this.window[num2 + num3];
							}
						}
					}
				}
			}
			while ((cur_match = (int)this.prev[cur_match & num5] & 65535) > num4 && --num != 0);
			if (num3 <= this.lookahead)
			{
				return num3;
			}
			return this.lookahead;
		}

		// Token: 0x170002ED RID: 749
		// (get) Token: 0x060013F8 RID: 5112 RVA: 0x00014DB1 File Offset: 0x00012FB1
		// (set) Token: 0x060013F9 RID: 5113 RVA: 0x00014DB9 File Offset: 0x00012FB9
		internal bool WantRfc1950HeaderBytes
		{
			get
			{
				return this._WantRfc1950HeaderBytes;
			}
			set
			{
				this._WantRfc1950HeaderBytes = value;
			}
		}

		// Token: 0x060013FA RID: 5114 RVA: 0x00014DC2 File Offset: 0x00012FC2
		internal int Initialize(ZlibCodec codec, CompressionLevel level)
		{
			return this.Initialize(codec, level, 15);
		}

		// Token: 0x060013FB RID: 5115 RVA: 0x00014DCE File Offset: 0x00012FCE
		internal int Initialize(ZlibCodec codec, CompressionLevel level, int bits)
		{
			return this.Initialize(codec, level, bits, DeflateManager.MEM_LEVEL_DEFAULT, CompressionStrategy.Default);
		}

		// Token: 0x060013FC RID: 5116 RVA: 0x00014DDF File Offset: 0x00012FDF
		internal int Initialize(ZlibCodec codec, CompressionLevel level, int bits, CompressionStrategy compressionStrategy)
		{
			return this.Initialize(codec, level, bits, DeflateManager.MEM_LEVEL_DEFAULT, compressionStrategy);
		}

		// Token: 0x060013FD RID: 5117 RVA: 0x00068C1C File Offset: 0x00066E1C
		internal int Initialize(ZlibCodec codec, CompressionLevel level, int windowBits, int memLevel, CompressionStrategy strategy)
		{
			this._codec = codec;
			this._codec.Message = null;
			if (windowBits < 9 || windowBits > 15)
			{
				throw new ZlibException(<Module>.smethod_23<string>(2934014164U));
			}
			if (memLevel < 1 || memLevel > DeflateManager.MEM_LEVEL_MAX)
			{
				throw new ZlibException(DeflateManager.smethod_2(<Module>.smethod_26<string>(2314509345U), DeflateManager.MEM_LEVEL_MAX));
			}
			this._codec.dstate = this;
			this.w_bits = windowBits;
			this.w_size = 1 << this.w_bits;
			this.w_mask = this.w_size - 1;
			this.hash_bits = memLevel + 7;
			this.hash_size = 1 << this.hash_bits;
			this.hash_mask = this.hash_size - 1;
			this.hash_shift = (this.hash_bits + DeflateManager.MIN_MATCH - 1) / DeflateManager.MIN_MATCH;
			this.window = new byte[this.w_size * 2];
			this.prev = new short[this.w_size];
			this.head = new short[this.hash_size];
			this.lit_bufsize = 1 << memLevel + 6;
			this.pending = new byte[this.lit_bufsize * 4];
			this._distanceOffset = this.lit_bufsize;
			this._lengthOffset = 3 * this.lit_bufsize;
			this.compressionLevel = level;
			this.compressionStrategy = strategy;
			this.Reset();
			return 0;
		}

		// Token: 0x060013FE RID: 5118 RVA: 0x00068D80 File Offset: 0x00066F80
		internal void Reset()
		{
			ZlibCodec codec = this._codec;
			this._codec.TotalBytesOut = 0L;
			codec.TotalBytesIn = 0L;
			this._codec.Message = null;
			this.pendingCount = 0;
			this.nextPending = 0;
			this.Rfc1950BytesEmitted = false;
			this.status = (this.WantRfc1950HeaderBytes ? DeflateManager.INIT_STATE : DeflateManager.BUSY_STATE);
			this._codec._Adler32 = Adler.Adler32(0U, null, 0, 0);
			this.last_flush = 0;
			this._InitializeTreeData();
			this._InitializeLazyMatch();
		}

		// Token: 0x060013FF RID: 5119 RVA: 0x00068E18 File Offset: 0x00067018
		internal int End()
		{
			if (this.status != DeflateManager.INIT_STATE && this.status != DeflateManager.BUSY_STATE && this.status != DeflateManager.FINISH_STATE)
			{
				return -2;
			}
			this.pending = null;
			this.head = null;
			this.prev = null;
			this.window = null;
			if (this.status != DeflateManager.BUSY_STATE)
			{
				return 0;
			}
			return -3;
		}

		// Token: 0x06001400 RID: 5120 RVA: 0x00068E7C File Offset: 0x0006707C
		private void SetDeflater()
		{
			switch (this.config.Flavor)
			{
			case DeflateFlavor.Store:
				this.DeflateFunction = new DeflateManager.CompressFunc(this.DeflateNone);
				return;
			case DeflateFlavor.Fast:
				this.DeflateFunction = new DeflateManager.CompressFunc(this.DeflateFast);
				return;
			case DeflateFlavor.Slow:
				this.DeflateFunction = new DeflateManager.CompressFunc(this.DeflateSlow);
				return;
			default:
				return;
			}
		}

		// Token: 0x06001401 RID: 5121 RVA: 0x00068EE0 File Offset: 0x000670E0
		internal int SetParams(CompressionLevel level, CompressionStrategy strategy)
		{
			int num = 0;
			if (this.compressionLevel != level)
			{
				DeflateManager.Config config = DeflateManager.Config.Lookup(level);
				if (config.Flavor != this.config.Flavor && this._codec.TotalBytesIn != 0L)
				{
					num = this._codec.Deflate(FlushType.Partial);
				}
				this.compressionLevel = level;
				this.config = config;
				this.SetDeflater();
			}
			this.compressionStrategy = strategy;
			return num;
		}

		// Token: 0x06001402 RID: 5122 RVA: 0x00068F54 File Offset: 0x00067154
		internal int SetDictionary(byte[] dictionary)
		{
			int num = dictionary.Length;
			int num2 = 0;
			if (dictionary != null)
			{
				if (this.status == DeflateManager.INIT_STATE)
				{
					this._codec._Adler32 = Adler.Adler32(this._codec._Adler32, dictionary, 0, dictionary.Length);
					if (num >= DeflateManager.MIN_MATCH)
					{
						if (num > this.w_size - DeflateManager.MIN_LOOKAHEAD)
						{
							num = this.w_size - DeflateManager.MIN_LOOKAHEAD;
							num2 = dictionary.Length - num;
						}
						DeflateManager.smethod_1(dictionary, num2, this.window, 0, num);
						this.strstart = num;
						this.block_start = num;
						this.ins_h = (int)(this.window[0] & byte.MaxValue);
						this.ins_h = ((this.ins_h << this.hash_shift) ^ (int)(this.window[1] & byte.MaxValue)) & this.hash_mask;
						for (int i = 0; i <= num - DeflateManager.MIN_MATCH; i++)
						{
							this.ins_h = ((this.ins_h << this.hash_shift) ^ (int)(this.window[i + (DeflateManager.MIN_MATCH - 1)] & byte.MaxValue)) & this.hash_mask;
							this.prev[i & this.w_mask] = this.head[this.ins_h];
							this.head[this.ins_h] = (short)i;
						}
						return 0;
					}
					return 0;
				}
			}
			throw new ZlibException(<Module>.smethod_27<string>(3257893502U));
		}

		// Token: 0x06001403 RID: 5123 RVA: 0x000690B0 File Offset: 0x000672B0
		internal int Deflate(FlushType flush)
		{
			if (this._codec.OutputBuffer != null && (this._codec.InputBuffer != null || this._codec.AvailableBytesIn == 0))
			{
				if (this.status == DeflateManager.FINISH_STATE)
				{
					if (flush != FlushType.Finish)
					{
						goto IL_0441;
					}
				}
				if (this._codec.AvailableBytesOut == 0)
				{
					this._codec.Message = DeflateManager._ErrorMessage[7];
					throw new ZlibException(<Module>.smethod_25<string>(902936332U));
				}
				int num = this.last_flush;
				this.last_flush = (int)flush;
				if (this.status == DeflateManager.INIT_STATE)
				{
					int num2 = DeflateManager.Z_DEFLATED + (this.w_bits - 8 << 4) << 8;
					int num3 = ((this.compressionLevel - CompressionLevel.BestSpeed) & 255) >> 1;
					if (num3 > 3)
					{
						num3 = 3;
					}
					num2 |= num3 << 6;
					if (this.strstart != 0)
					{
						num2 |= DeflateManager.PRESET_DICT;
					}
					num2 += 31 - num2 % 31;
					this.status = DeflateManager.BUSY_STATE;
					this.pending[this.pendingCount++] = (byte)(num2 >> 8);
					this.pending[this.pendingCount++] = (byte)num2;
					if (this.strstart != 0)
					{
						this.pending[this.pendingCount++] = (byte)((this._codec._Adler32 & 4278190080U) >> 24);
						this.pending[this.pendingCount++] = (byte)((this._codec._Adler32 & 16711680U) >> 16);
						this.pending[this.pendingCount++] = (byte)((this._codec._Adler32 & 65280U) >> 8);
						this.pending[this.pendingCount++] = (byte)(this._codec._Adler32 & 255U);
					}
					this._codec._Adler32 = Adler.Adler32(0U, null, 0, 0);
				}
				if (this.pendingCount != 0)
				{
					this._codec.flush_pending();
					if (this._codec.AvailableBytesOut == 0)
					{
						this.last_flush = -1;
						return 0;
					}
				}
				else if (this._codec.AvailableBytesIn == 0 && flush <= (FlushType)num && flush != FlushType.Finish)
				{
					return 0;
				}
				if (this.status == DeflateManager.FINISH_STATE && this._codec.AvailableBytesIn != 0)
				{
					this._codec.Message = DeflateManager._ErrorMessage[7];
					throw new ZlibException(<Module>.smethod_23<string>(3406115172U));
				}
				if (this._codec.AvailableBytesIn != 0 || this.lookahead != 0 || (flush != FlushType.None && this.status != DeflateManager.FINISH_STATE))
				{
					BlockState blockState = this.DeflateFunction(flush);
					if (blockState != BlockState.FinishStarted)
					{
						if (blockState != BlockState.FinishDone)
						{
							goto IL_02C8;
						}
					}
					this.status = DeflateManager.FINISH_STATE;
					IL_02C8:
					if (blockState != BlockState.NeedMore)
					{
						if (blockState != BlockState.FinishStarted)
						{
							if (blockState != BlockState.BlockDone)
							{
								goto IL_0337;
							}
							if (flush == FlushType.Partial)
							{
								this._tr_align();
							}
							else
							{
								this._tr_stored_block(0, 0, false);
								if (flush == FlushType.Full)
								{
									for (int i = 0; i < this.hash_size; i++)
									{
										this.head[i] = 0;
									}
								}
							}
							this._codec.flush_pending();
							if (this._codec.AvailableBytesOut == 0)
							{
								this.last_flush = -1;
								return 0;
							}
							goto IL_0337;
						}
					}
					if (this._codec.AvailableBytesOut == 0)
					{
						this.last_flush = -1;
					}
					return 0;
				}
				IL_0337:
				if (flush != FlushType.Finish)
				{
					return 0;
				}
				if (!this.WantRfc1950HeaderBytes || this.Rfc1950BytesEmitted)
				{
					return 1;
				}
				this.pending[this.pendingCount++] = (byte)((this._codec._Adler32 & 4278190080U) >> 24);
				this.pending[this.pendingCount++] = (byte)((this._codec._Adler32 & 16711680U) >> 16);
				this.pending[this.pendingCount++] = (byte)((this._codec._Adler32 & 65280U) >> 8);
				this.pending[this.pendingCount++] = (byte)(this._codec._Adler32 & 255U);
				this._codec.flush_pending();
				this.Rfc1950BytesEmitted = true;
				if (this.pendingCount == 0)
				{
					return 1;
				}
				return 0;
			}
			IL_0441:
			this._codec.Message = DeflateManager._ErrorMessage[4];
			throw new ZlibException(DeflateManager.smethod_2(<Module>.smethod_24<string>(469416850U), this._codec.Message));
		}

		// Token: 0x06001405 RID: 5125 RVA: 0x00014DF1 File Offset: 0x00012FF1
		static void smethod_0(Array array_0, int int_0, int int_1)
		{
			Array.Clear(array_0, int_0, int_1);
		}

		// Token: 0x06001406 RID: 5126 RVA: 0x0000C3EE File Offset: 0x0000A5EE
		static void smethod_1(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Array.Copy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x06001407 RID: 5127 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_2(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x04000701 RID: 1793
		private static readonly int MEM_LEVEL_MAX = 9;

		// Token: 0x04000702 RID: 1794
		private static readonly int MEM_LEVEL_DEFAULT = 8;

		// Token: 0x04000703 RID: 1795
		private DeflateManager.CompressFunc DeflateFunction;

		// Token: 0x04000704 RID: 1796
		private static readonly string[] _ErrorMessage = new string[]
		{
			<Module>.smethod_27<string>(3048769943U),
			<Module>.smethod_27<string>(3281878408U),
			"",
			<Module>.smethod_24<string>(3926018489U),
			<Module>.smethod_27<string>(2908904864U),
			<Module>.smethod_26<string>(893205300U),
			<Module>.smethod_26<string>(2331245328U),
			<Module>.smethod_27<string>(1883227618U),
			<Module>.smethod_23<string>(1704207654U),
			""
		};

		// Token: 0x04000705 RID: 1797
		private static readonly int PRESET_DICT = 32;

		// Token: 0x04000706 RID: 1798
		private static readonly int INIT_STATE = 42;

		// Token: 0x04000707 RID: 1799
		private static readonly int BUSY_STATE = 113;

		// Token: 0x04000708 RID: 1800
		private static readonly int FINISH_STATE = 666;

		// Token: 0x04000709 RID: 1801
		private static readonly int Z_DEFLATED = 8;

		// Token: 0x0400070A RID: 1802
		private static readonly int STORED_BLOCK = 0;

		// Token: 0x0400070B RID: 1803
		private static readonly int STATIC_TREES = 1;

		// Token: 0x0400070C RID: 1804
		private static readonly int DYN_TREES = 2;

		// Token: 0x0400070D RID: 1805
		private static readonly int Z_BINARY = 0;

		// Token: 0x0400070E RID: 1806
		private static readonly int Z_ASCII = 1;

		// Token: 0x0400070F RID: 1807
		private static readonly int Z_UNKNOWN = 2;

		// Token: 0x04000710 RID: 1808
		private static readonly int Buf_size = 16;

		// Token: 0x04000711 RID: 1809
		private static readonly int MIN_MATCH = 3;

		// Token: 0x04000712 RID: 1810
		private static readonly int MAX_MATCH = 258;

		// Token: 0x04000713 RID: 1811
		private static readonly int MIN_LOOKAHEAD = DeflateManager.MAX_MATCH + DeflateManager.MIN_MATCH + 1;

		// Token: 0x04000714 RID: 1812
		private static readonly int HEAP_SIZE = 2 * InternalConstants.L_CODES + 1;

		// Token: 0x04000715 RID: 1813
		private static readonly int END_BLOCK = 256;

		// Token: 0x04000716 RID: 1814
		internal ZlibCodec _codec;

		// Token: 0x04000717 RID: 1815
		internal int status;

		// Token: 0x04000718 RID: 1816
		internal byte[] pending;

		// Token: 0x04000719 RID: 1817
		internal int nextPending;

		// Token: 0x0400071A RID: 1818
		internal int pendingCount;

		// Token: 0x0400071B RID: 1819
		internal sbyte data_type;

		// Token: 0x0400071C RID: 1820
		internal int last_flush;

		// Token: 0x0400071D RID: 1821
		internal int w_size;

		// Token: 0x0400071E RID: 1822
		internal int w_bits;

		// Token: 0x0400071F RID: 1823
		internal int w_mask;

		// Token: 0x04000720 RID: 1824
		internal byte[] window;

		// Token: 0x04000721 RID: 1825
		internal int window_size;

		// Token: 0x04000722 RID: 1826
		internal short[] prev;

		// Token: 0x04000723 RID: 1827
		internal short[] head;

		// Token: 0x04000724 RID: 1828
		internal int ins_h;

		// Token: 0x04000725 RID: 1829
		internal int hash_size;

		// Token: 0x04000726 RID: 1830
		internal int hash_bits;

		// Token: 0x04000727 RID: 1831
		internal int hash_mask;

		// Token: 0x04000728 RID: 1832
		internal int hash_shift;

		// Token: 0x04000729 RID: 1833
		internal int block_start;

		// Token: 0x0400072A RID: 1834
		private DeflateManager.Config config;

		// Token: 0x0400072B RID: 1835
		internal int match_length;

		// Token: 0x0400072C RID: 1836
		internal int prev_match;

		// Token: 0x0400072D RID: 1837
		internal int match_available;

		// Token: 0x0400072E RID: 1838
		internal int strstart;

		// Token: 0x0400072F RID: 1839
		internal int match_start;

		// Token: 0x04000730 RID: 1840
		internal int lookahead;

		// Token: 0x04000731 RID: 1841
		internal int prev_length;

		// Token: 0x04000732 RID: 1842
		internal CompressionLevel compressionLevel;

		// Token: 0x04000733 RID: 1843
		internal CompressionStrategy compressionStrategy;

		// Token: 0x04000734 RID: 1844
		internal short[] dyn_ltree;

		// Token: 0x04000735 RID: 1845
		internal short[] dyn_dtree;

		// Token: 0x04000736 RID: 1846
		internal short[] bl_tree;

		// Token: 0x04000737 RID: 1847
		internal Tree treeLiterals = new Tree();

		// Token: 0x04000738 RID: 1848
		internal Tree treeDistances = new Tree();

		// Token: 0x04000739 RID: 1849
		internal Tree treeBitLengths = new Tree();

		// Token: 0x0400073A RID: 1850
		internal short[] bl_count = new short[InternalConstants.MAX_BITS + 1];

		// Token: 0x0400073B RID: 1851
		internal int[] heap = new int[2 * InternalConstants.L_CODES + 1];

		// Token: 0x0400073C RID: 1852
		internal int heap_len;

		// Token: 0x0400073D RID: 1853
		internal int heap_max;

		// Token: 0x0400073E RID: 1854
		internal sbyte[] depth = new sbyte[2 * InternalConstants.L_CODES + 1];

		// Token: 0x0400073F RID: 1855
		internal int _lengthOffset;

		// Token: 0x04000740 RID: 1856
		internal int lit_bufsize;

		// Token: 0x04000741 RID: 1857
		internal int last_lit;

		// Token: 0x04000742 RID: 1858
		internal int _distanceOffset;

		// Token: 0x04000743 RID: 1859
		internal int opt_len;

		// Token: 0x04000744 RID: 1860
		internal int static_len;

		// Token: 0x04000745 RID: 1861
		internal int matches;

		// Token: 0x04000746 RID: 1862
		internal int last_eob_len;

		// Token: 0x04000747 RID: 1863
		internal short bi_buf;

		// Token: 0x04000748 RID: 1864
		internal int bi_valid;

		// Token: 0x04000749 RID: 1865
		private bool Rfc1950BytesEmitted;

		// Token: 0x0400074A RID: 1866
		private bool _WantRfc1950HeaderBytes = true;

		// Token: 0x0200013A RID: 314
		// (Invoke) Token: 0x06001409 RID: 5129
		internal delegate BlockState CompressFunc(FlushType flush);

		// Token: 0x0200013B RID: 315
		internal class Config
		{
			// Token: 0x0600140C RID: 5132 RVA: 0x00014DFB File Offset: 0x00012FFB
			private Config(int goodLength, int maxLazy, int niceLength, int maxChainLength, DeflateFlavor flavor)
			{
				this.GoodLength = goodLength;
				this.MaxLazy = maxLazy;
				this.NiceLength = niceLength;
				this.MaxChainLength = maxChainLength;
				this.Flavor = flavor;
			}

			// Token: 0x0600140D RID: 5133 RVA: 0x00014E28 File Offset: 0x00013028
			public static DeflateManager.Config Lookup(CompressionLevel level)
			{
				return DeflateManager.Config.Table[(int)level];
			}

			// Token: 0x0400074B RID: 1867
			internal int GoodLength;

			// Token: 0x0400074C RID: 1868
			internal int MaxLazy;

			// Token: 0x0400074D RID: 1869
			internal int NiceLength;

			// Token: 0x0400074E RID: 1870
			internal int MaxChainLength;

			// Token: 0x0400074F RID: 1871
			internal DeflateFlavor Flavor;

			// Token: 0x04000750 RID: 1872
			private static readonly DeflateManager.Config[] Table = new DeflateManager.Config[]
			{
				new DeflateManager.Config(0, 0, 0, 0, DeflateFlavor.Store),
				new DeflateManager.Config(4, 4, 8, 4, DeflateFlavor.Fast),
				new DeflateManager.Config(4, 5, 16, 8, DeflateFlavor.Fast),
				new DeflateManager.Config(4, 6, 32, 32, DeflateFlavor.Fast),
				new DeflateManager.Config(4, 4, 16, 16, DeflateFlavor.Slow),
				new DeflateManager.Config(8, 16, 32, 32, DeflateFlavor.Slow),
				new DeflateManager.Config(8, 16, 128, 128, DeflateFlavor.Slow),
				new DeflateManager.Config(8, 32, 128, 256, DeflateFlavor.Slow),
				new DeflateManager.Config(32, 128, 258, 1024, DeflateFlavor.Slow),
				new DeflateManager.Config(32, 258, 258, 4096, DeflateFlavor.Slow)
			};
		}
	}
}
