﻿using System;
using System.Runtime.CompilerServices;

namespace Ionic.Zlib
{
	// Token: 0x02000150 RID: 336
	internal sealed class StaticTree
	{
		// Token: 0x060014EB RID: 5355 RVA: 0x000153F0 File Offset: 0x000135F0
		private StaticTree(short[] treeCodes, int[] extraBits, int extraBase, int elems, int maxLength)
		{
			this.treeCodes = treeCodes;
			this.extraBits = extraBits;
			this.extraBase = extraBase;
			this.elems = elems;
			this.maxLength = maxLength;
		}

		// Token: 0x060014EC RID: 5356 RVA: 0x0006E368 File Offset: 0x0006C568
		static StaticTree()
		{
			short[] array = new short[576];
			StaticTree.smethod_0(array, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600047b-1).FieldHandle);
			StaticTree.lengthAndLiteralsTreeCodes = array;
			short[] array2 = new short[60];
			StaticTree.smethod_0(array2, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600047b-2).FieldHandle);
			StaticTree.distTreeCodes = array2;
			StaticTree.Literals = new StaticTree(StaticTree.lengthAndLiteralsTreeCodes, Tree.ExtraLengthBits, InternalConstants.LITERALS + 1, InternalConstants.L_CODES, InternalConstants.MAX_BITS);
			StaticTree.Distances = new StaticTree(StaticTree.distTreeCodes, Tree.ExtraDistanceBits, 0, InternalConstants.D_CODES, InternalConstants.MAX_BITS);
			StaticTree.BitLengths = new StaticTree(null, Tree.extra_blbits, 0, InternalConstants.BL_CODES, InternalConstants.MAX_BL_BITS);
		}

		// Token: 0x060014ED RID: 5357 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_0(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x04000836 RID: 2102
		internal static readonly short[] lengthAndLiteralsTreeCodes;

		// Token: 0x04000837 RID: 2103
		internal static readonly short[] distTreeCodes;

		// Token: 0x04000838 RID: 2104
		internal static readonly StaticTree Literals;

		// Token: 0x04000839 RID: 2105
		internal static readonly StaticTree Distances;

		// Token: 0x0400083A RID: 2106
		internal static readonly StaticTree BitLengths;

		// Token: 0x0400083B RID: 2107
		internal short[] treeCodes;

		// Token: 0x0400083C RID: 2108
		internal int[] extraBits;

		// Token: 0x0400083D RID: 2109
		internal int extraBase;

		// Token: 0x0400083E RID: 2110
		internal int elems;

		// Token: 0x0400083F RID: 2111
		internal int maxLength;
	}
}
