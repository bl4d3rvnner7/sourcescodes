﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x02000142 RID: 322
	internal sealed class InflateManager
	{
		// Token: 0x17000304 RID: 772
		// (get) Token: 0x0600147F RID: 5247 RVA: 0x00015203 File Offset: 0x00013403
		// (set) Token: 0x06001480 RID: 5248 RVA: 0x0001520B File Offset: 0x0001340B
		internal bool HandleRfc1950HeaderBytes
		{
			get
			{
				return this._handleRfc1950HeaderBytes;
			}
			set
			{
				this._handleRfc1950HeaderBytes = value;
			}
		}

		// Token: 0x06001481 RID: 5249 RVA: 0x00015214 File Offset: 0x00013414
		public InflateManager()
		{
		}

		// Token: 0x06001482 RID: 5250 RVA: 0x00015223 File Offset: 0x00013423
		public InflateManager(bool expectRfc1950HeaderBytes)
		{
			this._handleRfc1950HeaderBytes = expectRfc1950HeaderBytes;
		}

		// Token: 0x06001483 RID: 5251 RVA: 0x0006C228 File Offset: 0x0006A428
		internal int Reset()
		{
			ZlibCodec codec = this._codec;
			this._codec.TotalBytesOut = 0L;
			codec.TotalBytesIn = 0L;
			this._codec.Message = null;
			this.mode = (this.HandleRfc1950HeaderBytes ? InflateManager.InflateManagerMode.METHOD : InflateManager.InflateManagerMode.BLOCKS);
			this.blocks.Reset();
			return 0;
		}

		// Token: 0x06001484 RID: 5252 RVA: 0x00015239 File Offset: 0x00013439
		internal int End()
		{
			if (this.blocks != null)
			{
				this.blocks.Free();
			}
			this.blocks = null;
			return 0;
		}

		// Token: 0x06001485 RID: 5253 RVA: 0x0006C288 File Offset: 0x0006A488
		internal int Initialize(ZlibCodec codec, int w)
		{
			this._codec = codec;
			this._codec.Message = null;
			this.blocks = null;
			if (w >= 8 && w <= 15)
			{
				this.wbits = w;
				this.blocks = new InflateBlocks(codec, this.HandleRfc1950HeaderBytes ? this : null, 1 << w);
				this.Reset();
				return 0;
			}
			this.End();
			throw new ZlibException(<Module>.smethod_27<string>(473033748U));
		}

		// Token: 0x06001486 RID: 5254 RVA: 0x0006C300 File Offset: 0x0006A500
		internal int Inflate(FlushType flush)
		{
			if (this._codec.InputBuffer == null)
			{
				throw new ZlibException(<Module>.smethod_23<string>(2029188281U));
			}
			int num = 0;
			int num2 = -5;
			for (;;)
			{
				switch (this.mode)
				{
				case InflateManager.InflateManagerMode.METHOD:
					if (this._codec.AvailableBytesIn == 0)
					{
						return num2;
					}
					num2 = num;
					this._codec.AvailableBytesIn--;
					this._codec.TotalBytesIn += 1L;
					if (((this.method = (int)this._codec.InputBuffer[this._codec.NextIn++]) & 15) != 8)
					{
						this.mode = InflateManager.InflateManagerMode.BAD;
						this._codec.Message = InflateManager.smethod_0(<Module>.smethod_26<string>(2522773208U), this.method);
						this.marker = 5;
						continue;
					}
					if ((this.method >> 4) + 8 > this.wbits)
					{
						this.mode = InflateManager.InflateManagerMode.BAD;
						this._codec.Message = InflateManager.smethod_0(<Module>.smethod_26<string>(3256157813U), (this.method >> 4) + 8);
						this.marker = 5;
						continue;
					}
					this.mode = InflateManager.InflateManagerMode.FLAG;
					continue;
				case InflateManager.InflateManagerMode.FLAG:
				{
					if (this._codec.AvailableBytesIn == 0)
					{
						return num2;
					}
					num2 = num;
					this._codec.AvailableBytesIn--;
					this._codec.TotalBytesIn += 1L;
					int num3 = (int)(this._codec.InputBuffer[this._codec.NextIn++] & byte.MaxValue);
					if (((this.method << 8) + num3) % 31 == 0)
					{
						this.mode = (((num3 & 32) == 0) ? InflateManager.InflateManagerMode.BLOCKS : InflateManager.InflateManagerMode.DICT4);
						continue;
					}
					this.mode = InflateManager.InflateManagerMode.BAD;
					this._codec.Message = <Module>.smethod_27<string>(3229485175U);
					this.marker = 5;
					continue;
				}
				case InflateManager.InflateManagerMode.DICT4:
					if (this._codec.AvailableBytesIn != 0)
					{
						num2 = num;
						this._codec.AvailableBytesIn--;
						this._codec.TotalBytesIn += 1L;
						this.expectedCheck = (uint)((long)((long)this._codec.InputBuffer[this._codec.NextIn++] << 24) & 4278190080L);
						this.mode = InflateManager.InflateManagerMode.DICT3;
						continue;
					}
					return num2;
				case InflateManager.InflateManagerMode.DICT3:
					if (this._codec.AvailableBytesIn != 0)
					{
						num2 = num;
						this._codec.AvailableBytesIn--;
						this._codec.TotalBytesIn += 1L;
						this.expectedCheck += (uint)(((int)this._codec.InputBuffer[this._codec.NextIn++] << 16) & 16711680);
						this.mode = InflateManager.InflateManagerMode.DICT2;
						continue;
					}
					return num2;
				case InflateManager.InflateManagerMode.DICT2:
					if (this._codec.AvailableBytesIn != 0)
					{
						num2 = num;
						this._codec.AvailableBytesIn--;
						this._codec.TotalBytesIn += 1L;
						this.expectedCheck += (uint)(((int)this._codec.InputBuffer[this._codec.NextIn++] << 8) & 65280);
						this.mode = InflateManager.InflateManagerMode.DICT1;
						continue;
					}
					return num2;
				case InflateManager.InflateManagerMode.DICT1:
					goto IL_066F;
				case InflateManager.InflateManagerMode.DICT0:
					goto IL_06FF;
				case InflateManager.InflateManagerMode.BLOCKS:
					num2 = this.blocks.Process(num2);
					if (num2 == -3)
					{
						this.mode = InflateManager.InflateManagerMode.BAD;
						this.marker = 0;
						continue;
					}
					if (num2 == 0)
					{
						num2 = num;
					}
					if (num2 != 1)
					{
						return num2;
					}
					num2 = num;
					this.computedCheck = this.blocks.Reset();
					if (this.HandleRfc1950HeaderBytes)
					{
						this.mode = InflateManager.InflateManagerMode.CHECK4;
						continue;
					}
					goto IL_0728;
				case InflateManager.InflateManagerMode.CHECK4:
					if (this._codec.AvailableBytesIn != 0)
					{
						num2 = num;
						this._codec.AvailableBytesIn--;
						this._codec.TotalBytesIn += 1L;
						this.expectedCheck = (uint)((long)((long)this._codec.InputBuffer[this._codec.NextIn++] << 24) & 4278190080L);
						this.mode = InflateManager.InflateManagerMode.CHECK3;
						continue;
					}
					return num2;
				case InflateManager.InflateManagerMode.CHECK3:
					if (this._codec.AvailableBytesIn != 0)
					{
						num2 = num;
						this._codec.AvailableBytesIn--;
						this._codec.TotalBytesIn += 1L;
						this.expectedCheck += (uint)(((int)this._codec.InputBuffer[this._codec.NextIn++] << 16) & 16711680);
						this.mode = InflateManager.InflateManagerMode.CHECK2;
						continue;
					}
					return num2;
				case InflateManager.InflateManagerMode.CHECK2:
					if (this._codec.AvailableBytesIn != 0)
					{
						num2 = num;
						this._codec.AvailableBytesIn--;
						this._codec.TotalBytesIn += 1L;
						this.expectedCheck += (uint)(((int)this._codec.InputBuffer[this._codec.NextIn++] << 8) & 65280);
						this.mode = InflateManager.InflateManagerMode.CHECK1;
						continue;
					}
					return num2;
				case InflateManager.InflateManagerMode.CHECK1:
					if (this._codec.AvailableBytesIn == 0)
					{
						return num2;
					}
					num2 = num;
					this._codec.AvailableBytesIn--;
					this._codec.TotalBytesIn += 1L;
					this.expectedCheck += (uint)(this._codec.InputBuffer[this._codec.NextIn++] & byte.MaxValue);
					if (this.computedCheck != this.expectedCheck)
					{
						this.mode = InflateManager.InflateManagerMode.BAD;
						this._codec.Message = <Module>.smethod_23<string>(695030142U);
						this.marker = 5;
						continue;
					}
					goto IL_0738;
				case InflateManager.InflateManagerMode.DONE:
					return 1;
				case InflateManager.InflateManagerMode.BAD:
					goto IL_0744;
				}
				goto Block_20;
			}
			return num2;
			Block_20:
			throw new ZlibException(<Module>.smethod_27<string>(3257893502U));
			IL_066F:
			if (this._codec.AvailableBytesIn == 0)
			{
				return num2;
			}
			this._codec.AvailableBytesIn--;
			this._codec.TotalBytesIn += 1L;
			this.expectedCheck += (uint)(this._codec.InputBuffer[this._codec.NextIn++] & byte.MaxValue);
			this._codec._Adler32 = this.expectedCheck;
			this.mode = InflateManager.InflateManagerMode.DICT0;
			return 2;
			IL_06FF:
			this.mode = InflateManager.InflateManagerMode.BAD;
			this._codec.Message = <Module>.smethod_27<string>(3048769943U);
			this.marker = 0;
			return -2;
			IL_0728:
			this.mode = InflateManager.InflateManagerMode.DONE;
			return 1;
			IL_0738:
			this.mode = InflateManager.InflateManagerMode.DONE;
			return 1;
			IL_0744:
			throw new ZlibException(InflateManager.smethod_0(<Module>.smethod_26<string>(2369550904U), this._codec.Message));
		}

		// Token: 0x06001487 RID: 5255 RVA: 0x0006CA74 File Offset: 0x0006AC74
		internal int SetDictionary(byte[] dictionary)
		{
			int num = 0;
			int num2 = dictionary.Length;
			if (this.mode != InflateManager.InflateManagerMode.DICT0)
			{
				throw new ZlibException(<Module>.smethod_26<string>(1609853922U));
			}
			if (Adler.Adler32(1U, dictionary, 0, dictionary.Length) != this._codec._Adler32)
			{
				return -3;
			}
			this._codec._Adler32 = Adler.Adler32(0U, null, 0, 0);
			if (num2 >= 1 << this.wbits)
			{
				num2 = (1 << this.wbits) - 1;
				num = dictionary.Length - num2;
			}
			this.blocks.SetDictionary(dictionary, num, num2);
			this.mode = InflateManager.InflateManagerMode.BLOCKS;
			return 0;
		}

		// Token: 0x06001488 RID: 5256 RVA: 0x0006CB08 File Offset: 0x0006AD08
		internal int Sync()
		{
			if (this.mode != InflateManager.InflateManagerMode.BAD)
			{
				this.mode = InflateManager.InflateManagerMode.BAD;
				this.marker = 0;
			}
			int num;
			if ((num = this._codec.AvailableBytesIn) == 0)
			{
				return -5;
			}
			int num2 = this._codec.NextIn;
			int num3 = this.marker;
			while (num != 0 && num3 < 4)
			{
				if (this._codec.InputBuffer[num2] == InflateManager.mark[num3])
				{
					num3++;
				}
				else if (this._codec.InputBuffer[num2] == 0)
				{
					num3 = 4 - num3;
				}
				else
				{
					num3 = 0;
				}
				num2++;
				num--;
			}
			this._codec.TotalBytesIn += (long)(num2 - this._codec.NextIn);
			this._codec.NextIn = num2;
			this._codec.AvailableBytesIn = num;
			this.marker = num3;
			if (num3 != 4)
			{
				return -3;
			}
			long totalBytesIn = this._codec.TotalBytesIn;
			long totalBytesOut = this._codec.TotalBytesOut;
			this.Reset();
			this._codec.TotalBytesIn = totalBytesIn;
			this._codec.TotalBytesOut = totalBytesOut;
			this.mode = InflateManager.InflateManagerMode.BLOCKS;
			return 0;
		}

		// Token: 0x06001489 RID: 5257 RVA: 0x00015256 File Offset: 0x00013456
		internal int SyncPoint(ZlibCodec z)
		{
			return this.blocks.SyncPoint();
		}

		// Token: 0x0600148B RID: 5259 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_0(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x04000798 RID: 1944
		private const int PRESET_DICT = 32;

		// Token: 0x04000799 RID: 1945
		private const int Z_DEFLATED = 8;

		// Token: 0x0400079A RID: 1946
		private InflateManager.InflateManagerMode mode;

		// Token: 0x0400079B RID: 1947
		internal ZlibCodec _codec;

		// Token: 0x0400079C RID: 1948
		internal int method;

		// Token: 0x0400079D RID: 1949
		internal uint computedCheck;

		// Token: 0x0400079E RID: 1950
		internal uint expectedCheck;

		// Token: 0x0400079F RID: 1951
		internal int marker;

		// Token: 0x040007A0 RID: 1952
		private bool _handleRfc1950HeaderBytes = true;

		// Token: 0x040007A1 RID: 1953
		internal int wbits;

		// Token: 0x040007A2 RID: 1954
		internal InflateBlocks blocks;

		// Token: 0x040007A3 RID: 1955
		private static readonly byte[] mark = new byte[] { 0, 0, byte.MaxValue, byte.MaxValue };

		// Token: 0x02000143 RID: 323
		private enum InflateManagerMode
		{
			// Token: 0x040007A5 RID: 1957
			METHOD,
			// Token: 0x040007A6 RID: 1958
			FLAG,
			// Token: 0x040007A7 RID: 1959
			DICT4,
			// Token: 0x040007A8 RID: 1960
			DICT3,
			// Token: 0x040007A9 RID: 1961
			DICT2,
			// Token: 0x040007AA RID: 1962
			DICT1,
			// Token: 0x040007AB RID: 1963
			DICT0,
			// Token: 0x040007AC RID: 1964
			BLOCKS,
			// Token: 0x040007AD RID: 1965
			CHECK4,
			// Token: 0x040007AE RID: 1966
			CHECK3,
			// Token: 0x040007AF RID: 1967
			CHECK2,
			// Token: 0x040007B0 RID: 1968
			CHECK1,
			// Token: 0x040007B1 RID: 1969
			DONE,
			// Token: 0x040007B2 RID: 1970
			BAD
		}
	}
}
