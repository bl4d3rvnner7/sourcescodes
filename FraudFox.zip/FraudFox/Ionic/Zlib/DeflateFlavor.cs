﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x02000138 RID: 312
	internal enum DeflateFlavor
	{
		// Token: 0x040006FE RID: 1790
		Store,
		// Token: 0x040006FF RID: 1791
		Fast,
		// Token: 0x04000700 RID: 1792
		Slow
	}
}
