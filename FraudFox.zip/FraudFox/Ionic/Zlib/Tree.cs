﻿using System;
using System.Runtime.CompilerServices;

namespace Ionic.Zlib
{
	// Token: 0x02000148 RID: 328
	internal sealed class Tree
	{
		// Token: 0x060014D6 RID: 5334 RVA: 0x0001538C File Offset: 0x0001358C
		internal static int DistanceCode(int dist)
		{
			if (dist >= 256)
			{
				return (int)Tree._dist_code[256 + SharedUtils.URShift(dist, 7)];
			}
			return (int)Tree._dist_code[dist];
		}

		// Token: 0x060014D7 RID: 5335 RVA: 0x0006DCDC File Offset: 0x0006BEDC
		internal void gen_bitlen(DeflateManager s)
		{
			short[] array = this.dyn_tree;
			short[] treeCodes = this.staticTree.treeCodes;
			int[] extraBits = this.staticTree.extraBits;
			int extraBase = this.staticTree.extraBase;
			int maxLength = this.staticTree.maxLength;
			int num = 0;
			for (int i = 0; i <= InternalConstants.MAX_BITS; i++)
			{
				s.bl_count[i] = 0;
			}
			array[s.heap[s.heap_max] * 2 + 1] = 0;
			int j;
			for (j = s.heap_max + 1; j < Tree.HEAP_SIZE; j++)
			{
				int num2 = s.heap[j];
				int i = (int)(array[(int)(array[num2 * 2 + 1] * 2 + 1)] + 1);
				if (i > maxLength)
				{
					i = maxLength;
					num++;
				}
				array[num2 * 2 + 1] = (short)i;
				if (num2 <= this.max_code)
				{
					short[] bl_count = s.bl_count;
					int num3 = i;
					bl_count[num3] += 1;
					int num4 = 0;
					if (num2 >= extraBase)
					{
						num4 = extraBits[num2 - extraBase];
					}
					short num5 = array[num2 * 2];
					s.opt_len += (int)num5 * (i + num4);
					if (treeCodes != null)
					{
						s.static_len += (int)num5 * ((int)treeCodes[num2 * 2 + 1] + num4);
					}
				}
			}
			if (num == 0)
			{
				return;
			}
			do
			{
				int i = maxLength - 1;
				while (s.bl_count[i] == 0)
				{
					i--;
				}
				short[] bl_count2 = s.bl_count;
				int num6 = i;
				bl_count2[num6] -= 1;
				s.bl_count[i + 1] = s.bl_count[i + 1] + 2;
				short[] bl_count3 = s.bl_count;
				int num7 = maxLength;
				bl_count3[num7] -= 1;
				num -= 2;
			}
			while (num > 0);
			for (int i = maxLength; i != 0; i--)
			{
				int num2 = (int)s.bl_count[i];
				while (num2 != 0)
				{
					int num8 = s.heap[--j];
					if (num8 <= this.max_code)
					{
						if ((int)array[num8 * 2 + 1] != i)
						{
							s.opt_len = (int)((long)s.opt_len + ((long)i - (long)array[num8 * 2 + 1]) * (long)array[num8 * 2]);
							array[num8 * 2 + 1] = (short)i;
						}
						num2--;
					}
				}
			}
		}

		// Token: 0x060014D8 RID: 5336 RVA: 0x0006DEFC File Offset: 0x0006C0FC
		internal void build_tree(DeflateManager s)
		{
			short[] array = this.dyn_tree;
			short[] treeCodes = this.staticTree.treeCodes;
			int elems = this.staticTree.elems;
			int num = -1;
			s.heap_len = 0;
			s.heap_max = Tree.HEAP_SIZE;
			for (int i = 0; i < elems; i++)
			{
				if (array[i * 2] != 0)
				{
					num = (s.heap[++s.heap_len] = i);
					s.depth[i] = 0;
				}
				else
				{
					array[i * 2 + 1] = 0;
				}
			}
			int num2;
			while (s.heap_len < 2)
			{
				num2 = (s.heap[++s.heap_len] = ((num < 2) ? (++num) : 0));
				array[num2 * 2] = 1;
				s.depth[num2] = 0;
				s.opt_len--;
				if (treeCodes != null)
				{
					s.static_len -= (int)treeCodes[num2 * 2 + 1];
				}
			}
			this.max_code = num;
			for (int i = s.heap_len / 2; i >= 1; i--)
			{
				s.pqdownheap(array, i);
			}
			num2 = elems;
			do
			{
				int i = s.heap[1];
				s.heap[1] = s.heap[s.heap_len--];
				s.pqdownheap(array, 1);
				int num3 = s.heap[1];
				s.heap[--s.heap_max] = i;
				s.heap[--s.heap_max] = num3;
				array[num2 * 2] = array[i * 2] + array[num3 * 2];
				s.depth[num2] = (sbyte)(Tree.smethod_0((byte)s.depth[i], (byte)s.depth[num3]) + 1);
				array[i * 2 + 1] = (array[num3 * 2 + 1] = (short)num2);
				s.heap[1] = num2++;
				s.pqdownheap(array, 1);
			}
			while (s.heap_len >= 2);
			s.heap[--s.heap_max] = s.heap[1];
			this.gen_bitlen(s);
			Tree.gen_codes(array, num, s.bl_count);
		}

		// Token: 0x060014D9 RID: 5337 RVA: 0x0006E144 File Offset: 0x0006C344
		internal static void gen_codes(short[] tree, int max_code, short[] bl_count)
		{
			short[] array = new short[InternalConstants.MAX_BITS + 1];
			short num = 0;
			for (int i = 1; i <= InternalConstants.MAX_BITS; i++)
			{
				num = (array[i] = (short)(num + bl_count[i - 1] << 1));
			}
			for (int j = 0; j <= max_code; j++)
			{
				int num2 = (int)tree[j * 2 + 1];
				if (num2 != 0)
				{
					int num3 = j * 2;
					short[] array2 = array;
					int num4 = num2;
					short num5;
					array2[num4] = (num5 = array2[num4]) + 1;
					tree[num3] = (short)Tree.bi_reverse((int)num5, num2);
				}
			}
		}

		// Token: 0x060014DA RID: 5338 RVA: 0x0006E1B8 File Offset: 0x0006C3B8
		internal static int bi_reverse(int code, int len)
		{
			int num = 0;
			do
			{
				num |= code & 1;
				code >>= 1;
				num <<= 1;
			}
			while (--len > 0);
			return num >> 1;
		}

		// Token: 0x060014DC RID: 5340 RVA: 0x0006E1E8 File Offset: 0x0006C3E8
		// Note: this type is marked as 'beforefieldinit'.
		static Tree()
		{
			int[] array = new int[29];
			Tree.smethod_1(array, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050f-1).FieldHandle);
			Tree.ExtraLengthBits = array;
			int[] array2 = new int[30];
			Tree.smethod_1(array2, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050f-2).FieldHandle);
			Tree.ExtraDistanceBits = array2;
			int[] array3 = new int[19];
			Tree.smethod_1(array3, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050f-3).FieldHandle);
			Tree.extra_blbits = array3;
			sbyte[] array4 = new sbyte[19];
			Tree.smethod_1(array4, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050f-4).FieldHandle);
			Tree.bl_order = array4;
			sbyte[] array5 = new sbyte[512];
			Tree.smethod_1(array5, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050f-5).FieldHandle);
			Tree._dist_code = array5;
			sbyte[] array6 = new sbyte[256];
			Tree.smethod_1(array6, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050f-6).FieldHandle);
			Tree.LengthCode = array6;
			int[] array7 = new int[29];
			Tree.smethod_1(array7, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050f-7).FieldHandle);
			Tree.LengthBase = array7;
			int[] array8 = new int[30];
			Tree.smethod_1(array8, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050f-8).FieldHandle);
			Tree.DistanceBase = array8;
		}

		// Token: 0x060014DD RID: 5341 RVA: 0x000153B1 File Offset: 0x000135B1
		static byte smethod_0(byte byte_0, byte byte_1)
		{
			return Math.Max(byte_0, byte_1);
		}

		// Token: 0x060014DE RID: 5342 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_1(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x04000803 RID: 2051
		internal const int Buf_size = 16;

		// Token: 0x04000804 RID: 2052
		private static readonly int HEAP_SIZE = 2 * InternalConstants.L_CODES + 1;

		// Token: 0x04000805 RID: 2053
		internal static readonly int[] ExtraLengthBits;

		// Token: 0x04000806 RID: 2054
		internal static readonly int[] ExtraDistanceBits;

		// Token: 0x04000807 RID: 2055
		internal static readonly int[] extra_blbits;

		// Token: 0x04000808 RID: 2056
		internal static readonly sbyte[] bl_order;

		// Token: 0x04000809 RID: 2057
		private static readonly sbyte[] _dist_code;

		// Token: 0x0400080A RID: 2058
		internal static readonly sbyte[] LengthCode;

		// Token: 0x0400080B RID: 2059
		internal static readonly int[] LengthBase;

		// Token: 0x0400080C RID: 2060
		internal static readonly int[] DistanceBase;

		// Token: 0x0400080D RID: 2061
		internal short[] dyn_tree;

		// Token: 0x0400080E RID: 2062
		internal int max_code;

		// Token: 0x0400080F RID: 2063
		internal StaticTree staticTree;
	}
}
