﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zlib
{
	// Token: 0x02000155 RID: 341
	[ClassInterface(ClassInterfaceType.AutoDispatch)]
	[Guid("ebc25cf6-9120-4283-b972-0e5520d0000D")]
	[ComVisible(true)]
	public sealed class ZlibCodec
	{
		// Token: 0x17000318 RID: 792
		// (get) Token: 0x06001529 RID: 5417 RVA: 0x00015512 File Offset: 0x00013712
		public int Adler32
		{
			get
			{
				return (int)this._Adler32;
			}
		}

		// Token: 0x0600152A RID: 5418 RVA: 0x0001551A File Offset: 0x0001371A
		public ZlibCodec()
		{
		}

		// Token: 0x0600152B RID: 5419 RVA: 0x0006F454 File Offset: 0x0006D654
		public ZlibCodec(CompressionMode mode)
		{
			if (mode == CompressionMode.Compress)
			{
				int num = this.InitializeDeflate();
				if (num != 0)
				{
					throw new ZlibException(<Module>.smethod_26<string>(1957765962U));
				}
			}
			else
			{
				if (mode != CompressionMode.Decompress)
				{
					throw new ZlibException(<Module>.smethod_27<string>(2507073620U));
				}
				int num2 = this.InitializeInflate();
				if (num2 != 0)
				{
					throw new ZlibException(<Module>.smethod_23<string>(3816633303U));
				}
			}
		}

		// Token: 0x0600152C RID: 5420 RVA: 0x00015531 File Offset: 0x00013731
		public int InitializeInflate()
		{
			return this.InitializeInflate(this.WindowBits);
		}

		// Token: 0x0600152D RID: 5421 RVA: 0x0001553F File Offset: 0x0001373F
		public int InitializeInflate(bool expectRfc1950Header)
		{
			return this.InitializeInflate(this.WindowBits, expectRfc1950Header);
		}

		// Token: 0x0600152E RID: 5422 RVA: 0x0001554E File Offset: 0x0001374E
		public int InitializeInflate(int windowBits)
		{
			this.WindowBits = windowBits;
			return this.InitializeInflate(windowBits, true);
		}

		// Token: 0x0600152F RID: 5423 RVA: 0x0006F4C4 File Offset: 0x0006D6C4
		public int InitializeInflate(int windowBits, bool expectRfc1950Header)
		{
			this.WindowBits = windowBits;
			for (;;)
			{
				IL_0043:
				int num = -1628952268;
				for (;;)
				{
					switch (num ^ -1628952266)
					{
					case 0:
						goto IL_0043;
					case 2:
						if (this.dstate != null)
						{
							goto Block_1;
						}
						goto IL_0009;
					case 3:
						goto IL_0009;
					}
					goto Block_2;
					IL_0009:
					this.istate = new InflateManager(expectRfc1950Header);
					num = -1628952265;
				}
			}
			Block_1:
			throw new ZlibException(<Module>.smethod_27<string>(2134100076U));
			Block_2:
			return this.istate.Initialize(this, windowBits);
		}

		// Token: 0x06001530 RID: 5424 RVA: 0x0001555F File Offset: 0x0001375F
		public int Inflate(FlushType flush)
		{
			if (this.istate == null)
			{
				throw new ZlibException(<Module>.smethod_27<string>(1528018067U));
			}
			return this.istate.Inflate(flush);
		}

		// Token: 0x06001531 RID: 5425 RVA: 0x0006F538 File Offset: 0x0006D738
		public int EndInflate()
		{
			if (this.istate == null)
			{
				throw new ZlibException(<Module>.smethod_24<string>(3181652370U));
			}
			int num = this.istate.End();
			this.istate = null;
			return num;
		}

		// Token: 0x06001532 RID: 5426 RVA: 0x00015585 File Offset: 0x00013785
		public int SyncInflate()
		{
			if (this.istate == null)
			{
				throw new ZlibException(<Module>.smethod_27<string>(1528018067U));
			}
			return this.istate.Sync();
		}

		// Token: 0x06001533 RID: 5427 RVA: 0x000155AA File Offset: 0x000137AA
		public int InitializeDeflate()
		{
			return this._InternalInitializeDeflate(true);
		}

		// Token: 0x06001534 RID: 5428 RVA: 0x000155B3 File Offset: 0x000137B3
		public int InitializeDeflate(CompressionLevel level)
		{
			this.CompressLevel = level;
			return this._InternalInitializeDeflate(true);
		}

		// Token: 0x06001535 RID: 5429 RVA: 0x000155C3 File Offset: 0x000137C3
		public int InitializeDeflate(CompressionLevel level, bool wantRfc1950Header)
		{
			this.CompressLevel = level;
			return this._InternalInitializeDeflate(wantRfc1950Header);
		}

		// Token: 0x06001536 RID: 5430 RVA: 0x000155D3 File Offset: 0x000137D3
		public int InitializeDeflate(CompressionLevel level, int bits)
		{
			this.CompressLevel = level;
			this.WindowBits = bits;
			return this._InternalInitializeDeflate(true);
		}

		// Token: 0x06001537 RID: 5431 RVA: 0x000155EA File Offset: 0x000137EA
		public int InitializeDeflate(CompressionLevel level, int bits, bool wantRfc1950Header)
		{
			this.CompressLevel = level;
			this.WindowBits = bits;
			return this._InternalInitializeDeflate(wantRfc1950Header);
		}

		// Token: 0x06001538 RID: 5432 RVA: 0x0006F574 File Offset: 0x0006D774
		private int _InternalInitializeDeflate(bool wantRfc1950Header)
		{
			if (this.istate != null)
			{
				throw new ZlibException(<Module>.smethod_24<string>(3994611992U));
			}
			this.dstate = new DeflateManager();
			this.dstate.WantRfc1950HeaderBytes = wantRfc1950Header;
			return this.dstate.Initialize(this, this.CompressLevel, this.WindowBits, this.Strategy);
		}

		// Token: 0x06001539 RID: 5433 RVA: 0x00015601 File Offset: 0x00013801
		public int Deflate(FlushType flush)
		{
			if (this.dstate == null)
			{
				throw new ZlibException(<Module>.smethod_27<string>(1632355160U));
			}
			return this.dstate.Deflate(flush);
		}

		// Token: 0x0600153A RID: 5434 RVA: 0x00015627 File Offset: 0x00013827
		public int EndDeflate()
		{
			if (this.dstate == null)
			{
				throw new ZlibException(<Module>.smethod_23<string>(1676860408U));
			}
			this.dstate = null;
			return 0;
		}

		// Token: 0x0600153B RID: 5435 RVA: 0x00015649 File Offset: 0x00013849
		public void ResetDeflate()
		{
			if (this.dstate == null)
			{
				throw new ZlibException(<Module>.smethod_24<string>(2295526717U));
			}
			this.dstate.Reset();
		}

		// Token: 0x0600153C RID: 5436 RVA: 0x0001566E File Offset: 0x0001386E
		public int SetDeflateParams(CompressionLevel level, CompressionStrategy strategy)
		{
			if (this.dstate == null)
			{
				throw new ZlibException(<Module>.smethod_27<string>(1632355160U));
			}
			return this.dstate.SetParams(level, strategy);
		}

		// Token: 0x0600153D RID: 5437 RVA: 0x0006F5D0 File Offset: 0x0006D7D0
		public int SetDictionary(byte[] dictionary)
		{
			if (this.istate != null)
			{
				goto IL_0040;
			}
			if (this.dstate == null)
			{
				throw new ZlibException(<Module>.smethod_24<string>(2986034275U));
			}
			int num = -663144526;
			IL_0027:
			switch (num ^ -663144525)
			{
			case 0:
				IL_0040:
				num = -663144527;
				goto IL_0027;
			case 2:
				return this.istate.SetDictionary(dictionary);
			}
			return this.dstate.SetDictionary(dictionary);
		}

		// Token: 0x0600153E RID: 5438 RVA: 0x0006F640 File Offset: 0x0006D840
		internal void flush_pending()
		{
			int num = this.dstate.pendingCount;
			if (num > this.AvailableBytesOut)
			{
				num = this.AvailableBytesOut;
			}
			if (num == 0)
			{
				return;
			}
			if (this.dstate.pending.Length > this.dstate.nextPending && this.OutputBuffer.Length > this.NextOut && this.dstate.pending.Length >= this.dstate.nextPending + num && this.OutputBuffer.Length >= this.NextOut + num)
			{
				ZlibCodec.smethod_1(this.dstate.pending, this.dstate.nextPending, this.OutputBuffer, this.NextOut, num);
				this.NextOut += num;
				this.dstate.nextPending += num;
				this.TotalBytesOut += (long)num;
				this.AvailableBytesOut -= num;
				this.dstate.pendingCount -= num;
				if (this.dstate.pendingCount == 0)
				{
					this.dstate.nextPending = 0;
				}
				return;
			}
			throw new ZlibException(ZlibCodec.smethod_0(<Module>.smethod_26<string>(250005974U), this.dstate.pending.Length, this.dstate.pendingCount));
		}

		// Token: 0x0600153F RID: 5439 RVA: 0x0006F79C File Offset: 0x0006D99C
		internal int read_buf(byte[] buf, int start, int size)
		{
			int num = this.AvailableBytesIn;
			if (num > size)
			{
				num = size;
			}
			if (num == 0)
			{
				return 0;
			}
			this.AvailableBytesIn -= num;
			if (this.dstate.WantRfc1950HeaderBytes)
			{
				this._Adler32 = Adler.Adler32(this._Adler32, this.InputBuffer, this.NextIn, num);
			}
			ZlibCodec.smethod_1(this.InputBuffer, this.NextIn, buf, start, num);
			this.NextIn += num;
			this.TotalBytesIn += (long)num;
			return num;
		}

		// Token: 0x06001540 RID: 5440 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_0(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x06001541 RID: 5441 RVA: 0x0000C3EE File Offset: 0x0000A5EE
		static void smethod_1(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Array.Copy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x0400085C RID: 2140
		public byte[] InputBuffer;

		// Token: 0x0400085D RID: 2141
		public int NextIn;

		// Token: 0x0400085E RID: 2142
		public int AvailableBytesIn;

		// Token: 0x0400085F RID: 2143
		public long TotalBytesIn;

		// Token: 0x04000860 RID: 2144
		public byte[] OutputBuffer;

		// Token: 0x04000861 RID: 2145
		public int NextOut;

		// Token: 0x04000862 RID: 2146
		public int AvailableBytesOut;

		// Token: 0x04000863 RID: 2147
		public long TotalBytesOut;

		// Token: 0x04000864 RID: 2148
		public string Message;

		// Token: 0x04000865 RID: 2149
		internal DeflateManager dstate;

		// Token: 0x04000866 RID: 2150
		internal InflateManager istate;

		// Token: 0x04000867 RID: 2151
		internal uint _Adler32;

		// Token: 0x04000868 RID: 2152
		public CompressionLevel CompressLevel = CompressionLevel.Default;

		// Token: 0x04000869 RID: 2153
		public int WindowBits = 15;

		// Token: 0x0400086A RID: 2154
		public CompressionStrategy Strategy;
	}
}
