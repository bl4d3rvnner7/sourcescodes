﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using Ionic.Crc;

namespace Ionic.Zlib
{
	// Token: 0x02000146 RID: 326
	[ComVisible(true)]
	public class ParallelDeflateOutputStream : Stream
	{
		// Token: 0x06001497 RID: 5271 RVA: 0x00015287 File Offset: 0x00013487
		public ParallelDeflateOutputStream(Stream stream)
			: this(stream, CompressionLevel.Default, CompressionStrategy.Default, false)
		{
		}

		// Token: 0x06001498 RID: 5272 RVA: 0x00015293 File Offset: 0x00013493
		public ParallelDeflateOutputStream(Stream stream, CompressionLevel level)
			: this(stream, level, CompressionStrategy.Default, false)
		{
		}

		// Token: 0x06001499 RID: 5273 RVA: 0x0001529F File Offset: 0x0001349F
		public ParallelDeflateOutputStream(Stream stream, bool leaveOpen)
			: this(stream, CompressionLevel.Default, CompressionStrategy.Default, leaveOpen)
		{
		}

		// Token: 0x0600149A RID: 5274 RVA: 0x000152AB File Offset: 0x000134AB
		public ParallelDeflateOutputStream(Stream stream, CompressionLevel level, bool leaveOpen)
			: this(stream, CompressionLevel.Default, CompressionStrategy.Default, leaveOpen)
		{
		}

		// Token: 0x0600149B RID: 5275 RVA: 0x0006D3C8 File Offset: 0x0006B5C8
		public ParallelDeflateOutputStream(Stream stream, CompressionLevel level, CompressionStrategy strategy, bool leaveOpen)
		{
			this._outStream = stream;
			this._compressLevel = level;
			this.Strategy = strategy;
			this._leaveOpen = leaveOpen;
			this.MaxBufferPairs = 16;
		}

		// Token: 0x17000305 RID: 773
		// (get) Token: 0x0600149C RID: 5276 RVA: 0x000152B7 File Offset: 0x000134B7
		// (set) Token: 0x0600149D RID: 5277 RVA: 0x000152BF File Offset: 0x000134BF
		public CompressionStrategy Strategy { get; private set; }

		// Token: 0x17000306 RID: 774
		// (get) Token: 0x0600149E RID: 5278 RVA: 0x000152C8 File Offset: 0x000134C8
		// (set) Token: 0x0600149F RID: 5279 RVA: 0x000152D0 File Offset: 0x000134D0
		public int MaxBufferPairs
		{
			get
			{
				return this._maxBufferPairs;
			}
			set
			{
				if (value < 4)
				{
					throw ParallelDeflateOutputStream.smethod_1(<Module>.smethod_23<string>(3199159797U), <Module>.smethod_27<string>(1961403249U));
				}
				this._maxBufferPairs = value;
			}
		}

		// Token: 0x17000307 RID: 775
		// (get) Token: 0x060014A0 RID: 5280 RVA: 0x000152F7 File Offset: 0x000134F7
		// (set) Token: 0x060014A1 RID: 5281 RVA: 0x000152FF File Offset: 0x000134FF
		public int BufferSize
		{
			get
			{
				return this._bufferSize;
			}
			set
			{
				if (value < 1024)
				{
					throw ParallelDeflateOutputStream.smethod_2(<Module>.smethod_25<string>(1653748021U), <Module>.smethod_23<string>(2831410418U));
				}
				this._bufferSize = value;
			}
		}

		// Token: 0x17000308 RID: 776
		// (get) Token: 0x060014A2 RID: 5282 RVA: 0x0001532A File Offset: 0x0001352A
		public int Crc32
		{
			get
			{
				return this._Crc32;
			}
		}

		// Token: 0x17000309 RID: 777
		// (get) Token: 0x060014A3 RID: 5283 RVA: 0x00015332 File Offset: 0x00013532
		public long BytesProcessed
		{
			get
			{
				return this._totalBytesProcessed;
			}
		}

		// Token: 0x060014A4 RID: 5284 RVA: 0x0006D438 File Offset: 0x0006B638
		private void _InitializePoolOfWorkItems()
		{
			this._toWrite = new Queue<int>();
			this._toFill = new Queue<int>();
			this._pool = new List<WorkItem>();
			int num = ParallelDeflateOutputStream.BufferPairsPerCore * ParallelDeflateOutputStream.smethod_3();
			num = ParallelDeflateOutputStream.smethod_4(num, this._maxBufferPairs);
			for (int i = 0; i < num; i++)
			{
				this._pool.Add(new WorkItem(this._bufferSize, this._compressLevel, this.Strategy, i));
				this._toFill.Enqueue(i);
			}
			this._newlyCompressedBlob = ParallelDeflateOutputStream.smethod_5(false);
			this._runningCrc = new CRC32();
			this._currentlyFilling = -1;
			this._lastFilled = -1;
			this._lastWritten = -1;
			this._latestCompressed = -1;
		}

		// Token: 0x060014A5 RID: 5285 RVA: 0x0006D4F0 File Offset: 0x0006B6F0
		public override void Write(byte[] buffer, int offset, int count)
		{
			bool flag = false;
			if (this._isClosed)
			{
				throw ParallelDeflateOutputStream.smethod_6();
			}
			if (this._pendingException != null)
			{
				this._handlingException = true;
				Exception pendingException = this._pendingException;
				this._pendingException = null;
				throw pendingException;
			}
			if (count != 0)
			{
				if (!this._firstWriteDone)
				{
					this._InitializePoolOfWorkItems();
					this._firstWriteDone = true;
				}
				for (;;)
				{
					this.EmitPendingBuffers(false, flag);
					flag = false;
					int num;
					if (this._currentlyFilling >= 0)
					{
						num = this._currentlyFilling;
						goto IL_006E;
					}
					if (this._toFill.Count != 0)
					{
						num = this._toFill.Dequeue();
						this._lastFilled++;
						goto IL_006E;
					}
					flag = true;
					IL_0111:
					if (count > 0)
					{
						continue;
					}
					return;
					IL_006E:
					WorkItem workItem = this._pool[num];
					int num2 = ((workItem.buffer.Length - workItem.inputBytesAvailable > count) ? count : (workItem.buffer.Length - workItem.inputBytesAvailable));
					workItem.ordinal = this._lastFilled;
					ParallelDeflateOutputStream.smethod_7(buffer, offset, workItem.buffer, workItem.inputBytesAvailable, num2);
					count -= num2;
					offset += num2;
					workItem.inputBytesAvailable += num2;
					if (workItem.inputBytesAvailable != workItem.buffer.Length)
					{
						this._currentlyFilling = num;
						goto IL_0111;
					}
					if (ParallelDeflateOutputStream.smethod_8(new WaitCallback(this._DeflateOne), workItem))
					{
						this._currentlyFilling = -1;
						goto IL_0111;
					}
					break;
				}
				throw ParallelDeflateOutputStream.smethod_9(<Module>.smethod_23<string>(128858509U));
			}
		}

		// Token: 0x060014A6 RID: 5286 RVA: 0x0006D668 File Offset: 0x0006B868
		private void _FlushFinish()
		{
			byte[] array = new byte[128];
			ZlibCodec zlibCodec = new ZlibCodec();
			int num = zlibCodec.InitializeDeflate(this._compressLevel, false);
			zlibCodec.InputBuffer = null;
			zlibCodec.NextIn = 0;
			zlibCodec.AvailableBytesIn = 0;
			zlibCodec.OutputBuffer = array;
			zlibCodec.NextOut = 0;
			zlibCodec.AvailableBytesOut = array.Length;
			num = zlibCodec.Deflate(FlushType.Finish);
			if (num != 1)
			{
				if (num != 0)
				{
					throw ParallelDeflateOutputStream.smethod_9(ParallelDeflateOutputStream.smethod_10(<Module>.smethod_23<string>(780567646U), zlibCodec.Message));
				}
			}
			if (array.Length - zlibCodec.AvailableBytesOut > 0)
			{
				ParallelDeflateOutputStream.smethod_11(this._outStream, array, 0, array.Length - zlibCodec.AvailableBytesOut);
			}
			zlibCodec.EndDeflate();
			this._Crc32 = this._runningCrc.Crc32Result;
		}

		// Token: 0x060014A7 RID: 5287 RVA: 0x0006D72C File Offset: 0x0006B92C
		private void _Flush(bool lastInput)
		{
			if (this._isClosed)
			{
				throw ParallelDeflateOutputStream.smethod_6();
			}
			if (this.emitting)
			{
				return;
			}
			if (this._currentlyFilling >= 0)
			{
				WorkItem workItem = this._pool[this._currentlyFilling];
				this._DeflateOne(workItem);
				this._currentlyFilling = -1;
			}
			if (lastInput)
			{
				this.EmitPendingBuffers(true, false);
				this._FlushFinish();
				return;
			}
			this.EmitPendingBuffers(false, false);
		}

		// Token: 0x060014A8 RID: 5288 RVA: 0x0006D794 File Offset: 0x0006B994
		public override void Flush()
		{
			if (this._pendingException != null)
			{
				this._handlingException = true;
				Exception pendingException = this._pendingException;
				this._pendingException = null;
				throw pendingException;
			}
			if (this._handlingException)
			{
				return;
			}
			this._Flush(false);
		}

		// Token: 0x060014A9 RID: 5289 RVA: 0x0006D7D8 File Offset: 0x0006B9D8
		public override void Close()
		{
			if (this._pendingException != null)
			{
				this._handlingException = true;
				Exception pendingException = this._pendingException;
				this._pendingException = null;
				throw pendingException;
			}
			if (this._handlingException)
			{
				return;
			}
			if (this._isClosed)
			{
				return;
			}
			this._Flush(true);
			if (!this._leaveOpen)
			{
				ParallelDeflateOutputStream.smethod_12(this._outStream);
			}
			this._isClosed = true;
		}

		// Token: 0x060014AA RID: 5290 RVA: 0x0001533A File Offset: 0x0001353A
		public new void Dispose()
		{
			ParallelDeflateOutputStream.smethod_12(this);
			this._pool = null;
			this.Dispose(true);
		}

		// Token: 0x060014AB RID: 5291 RVA: 0x00015350 File Offset: 0x00013550
		protected override void Dispose(bool disposing)
		{
			base.Dispose(disposing);
		}

		// Token: 0x060014AC RID: 5292 RVA: 0x0006D840 File Offset: 0x0006BA40
		public void Reset(Stream stream)
		{
			if (!this._firstWriteDone)
			{
				return;
			}
			this._toWrite.Clear();
			this._toFill.Clear();
			foreach (WorkItem workItem in this._pool)
			{
				this._toFill.Enqueue(workItem.index);
				workItem.ordinal = -1;
			}
			this._firstWriteDone = false;
			this._totalBytesProcessed = 0L;
			this._runningCrc = new CRC32();
			this._isClosed = false;
			this._currentlyFilling = -1;
			this._lastFilled = -1;
			this._lastWritten = -1;
			this._latestCompressed = -1;
			this._outStream = stream;
		}

		// Token: 0x060014AD RID: 5293 RVA: 0x0006D910 File Offset: 0x0006BB10
		private void EmitPendingBuffers(bool doAll, bool mustWait)
		{
			if (this.emitting)
			{
				return;
			}
			this.emitting = true;
			if (doAll || mustWait)
			{
				ParallelDeflateOutputStream.smethod_13(this._newlyCompressedBlob);
			}
			do
			{
				int num = -1;
				int num2 = (doAll ? 200 : (mustWait ? (-1) : 0));
				int num3 = -1;
				do
				{
					if (ParallelDeflateOutputStream.smethod_14(this._toWrite, num2))
					{
						num3 = -1;
						try
						{
							if (this._toWrite.Count > 0)
							{
								num3 = this._toWrite.Dequeue();
							}
						}
						finally
						{
							ParallelDeflateOutputStream.smethod_15(this._toWrite);
						}
						if (num3 >= 0)
						{
							WorkItem workItem = this._pool[num3];
							if (workItem.ordinal != this._lastWritten + 1)
							{
								Queue<int> toWrite;
								ParallelDeflateOutputStream.smethod_16(toWrite = this._toWrite);
								try
								{
									this._toWrite.Enqueue(num3);
								}
								finally
								{
									ParallelDeflateOutputStream.smethod_15(toWrite);
								}
								if (num == num3)
								{
									ParallelDeflateOutputStream.smethod_13(this._newlyCompressedBlob);
									num = -1;
								}
								else if (num == -1)
								{
									num = num3;
								}
							}
							else
							{
								num = -1;
								ParallelDeflateOutputStream.smethod_11(this._outStream, workItem.compressed, 0, workItem.compressedBytesAvailable);
								this._runningCrc.Combine(workItem.crc, workItem.inputBytesAvailable);
								this._totalBytesProcessed += (long)workItem.inputBytesAvailable;
								workItem.inputBytesAvailable = 0;
								this._lastWritten = workItem.ordinal;
								this._toFill.Enqueue(workItem.index);
								if (num2 == -1)
								{
									num2 = 0;
								}
							}
						}
					}
					else
					{
						num3 = -1;
					}
				}
				while (num3 >= 0);
				if (!doAll)
				{
					break;
				}
			}
			while (this._lastWritten != this._latestCompressed || this._lastWritten != this._lastFilled);
			this.emitting = false;
		}

		// Token: 0x060014AE RID: 5294 RVA: 0x0006DAE4 File Offset: 0x0006BCE4
		private void _DeflateOne(object wi)
		{
			WorkItem workItem = (WorkItem)wi;
			try
			{
				CRC32 crc = new CRC32();
				crc.SlurpBlock(workItem.buffer, 0, workItem.inputBytesAvailable);
				this.DeflateOneSegment(workItem);
				workItem.crc = crc.Crc32Result;
				object latestLock;
				ParallelDeflateOutputStream.smethod_16(latestLock = this._latestLock);
				try
				{
					if (workItem.ordinal > this._latestCompressed)
					{
						this._latestCompressed = workItem.ordinal;
					}
				}
				finally
				{
					ParallelDeflateOutputStream.smethod_15(latestLock);
				}
				Queue<int> toWrite;
				ParallelDeflateOutputStream.smethod_16(toWrite = this._toWrite);
				try
				{
					this._toWrite.Enqueue(workItem.index);
				}
				finally
				{
					ParallelDeflateOutputStream.smethod_15(toWrite);
				}
				ParallelDeflateOutputStream.smethod_17(this._newlyCompressedBlob);
			}
			catch (Exception ex)
			{
				object eLock;
				ParallelDeflateOutputStream.smethod_16(eLock = this._eLock);
				try
				{
					if (this._pendingException != null)
					{
						this._pendingException = ex;
					}
				}
				finally
				{
					ParallelDeflateOutputStream.smethod_15(eLock);
				}
			}
		}

		// Token: 0x060014AF RID: 5295 RVA: 0x0006DBF0 File Offset: 0x0006BDF0
		private bool DeflateOneSegment(WorkItem workitem)
		{
			ZlibCodec compressor = workitem.compressor;
			compressor.ResetDeflate();
			compressor.NextIn = 0;
			compressor.AvailableBytesIn = workitem.inputBytesAvailable;
			compressor.NextOut = 0;
			compressor.AvailableBytesOut = workitem.compressed.Length;
			for (;;)
			{
				compressor.Deflate(FlushType.None);
				if (compressor.AvailableBytesIn <= 0)
				{
					if (compressor.AvailableBytesOut != 0)
					{
						break;
					}
				}
			}
			compressor.Deflate(FlushType.Sync);
			workitem.compressedBytesAvailable = (int)compressor.TotalBytesOut;
			return true;
		}

		// Token: 0x060014B0 RID: 5296 RVA: 0x0006DC68 File Offset: 0x0006BE68
		[Conditional("Trace")]
		private void TraceOutput(ParallelDeflateOutputStream.TraceBits bits, string format, params object[] varParams)
		{
			if ((bits & this._DesiredTrace) != ParallelDeflateOutputStream.TraceBits.None)
			{
				object outputLock;
				ParallelDeflateOutputStream.smethod_16(outputLock = this._outputLock);
				try
				{
					int num = ParallelDeflateOutputStream.smethod_19(ParallelDeflateOutputStream.smethod_18());
					ParallelDeflateOutputStream.smethod_20(num % 8 + ConsoleColor.DarkGray);
					ParallelDeflateOutputStream.smethod_21(<Module>.smethod_23<string>(1671719906U), num);
					ParallelDeflateOutputStream.smethod_22(format, varParams);
					ParallelDeflateOutputStream.smethod_23();
				}
				finally
				{
					ParallelDeflateOutputStream.smethod_15(outputLock);
				}
			}
		}

		// Token: 0x1700030A RID: 778
		// (get) Token: 0x060014B1 RID: 5297 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700030B RID: 779
		// (get) Token: 0x060014B2 RID: 5298 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanRead
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700030C RID: 780
		// (get) Token: 0x060014B3 RID: 5299 RVA: 0x00015359 File Offset: 0x00013559
		public override bool CanWrite
		{
			get
			{
				return ParallelDeflateOutputStream.smethod_24(this._outStream);
			}
		}

		// Token: 0x1700030D RID: 781
		// (get) Token: 0x060014B4 RID: 5300 RVA: 0x00015366 File Offset: 0x00013566
		public override long Length
		{
			get
			{
				throw ParallelDeflateOutputStream.smethod_25();
			}
		}

		// Token: 0x1700030E RID: 782
		// (get) Token: 0x060014B5 RID: 5301 RVA: 0x0001536D File Offset: 0x0001356D
		// (set) Token: 0x060014B6 RID: 5302 RVA: 0x00015366 File Offset: 0x00013566
		public override long Position
		{
			get
			{
				return ParallelDeflateOutputStream.smethod_26(this._outStream);
			}
			set
			{
				throw ParallelDeflateOutputStream.smethod_25();
			}
		}

		// Token: 0x060014B7 RID: 5303 RVA: 0x00015366 File Offset: 0x00013566
		public override int Read(byte[] buffer, int offset, int count)
		{
			throw ParallelDeflateOutputStream.smethod_25();
		}

		// Token: 0x060014B8 RID: 5304 RVA: 0x00015366 File Offset: 0x00013566
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw ParallelDeflateOutputStream.smethod_25();
		}

		// Token: 0x060014B9 RID: 5305 RVA: 0x00015366 File Offset: 0x00013566
		public override void SetLength(long value)
		{
			throw ParallelDeflateOutputStream.smethod_25();
		}

		// Token: 0x060014BB RID: 5307 RVA: 0x00013209 File Offset: 0x00011409
		static object smethod_0()
		{
			return new object();
		}

		// Token: 0x060014BC RID: 5308 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_1(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}

		// Token: 0x060014BD RID: 5309 RVA: 0x0000DECA File Offset: 0x0000C0CA
		static ArgumentOutOfRangeException smethod_2(string string_0, string string_1)
		{
			return new ArgumentOutOfRangeException(string_0, string_1);
		}

		// Token: 0x060014BE RID: 5310 RVA: 0x00014CE8 File Offset: 0x00012EE8
		static int smethod_3()
		{
			return Environment.ProcessorCount;
		}

		// Token: 0x060014BF RID: 5311 RVA: 0x0000F046 File Offset: 0x0000D246
		static int smethod_4(int int_0, int int_1)
		{
			return Math.Min(int_0, int_1);
		}

		// Token: 0x060014C0 RID: 5312 RVA: 0x00014CEF File Offset: 0x00012EEF
		static AutoResetEvent smethod_5(bool bool_0)
		{
			return new AutoResetEvent(bool_0);
		}

		// Token: 0x060014C1 RID: 5313 RVA: 0x0000C331 File Offset: 0x0000A531
		static InvalidOperationException smethod_6()
		{
			return new InvalidOperationException();
		}

		// Token: 0x060014C2 RID: 5314 RVA: 0x00013254 File Offset: 0x00011454
		static void smethod_7(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Buffer.BlockCopy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x060014C3 RID: 5315 RVA: 0x0000F95E File Offset: 0x0000DB5E
		static bool smethod_8(WaitCallback waitCallback_0, object object_0)
		{
			return ThreadPool.QueueUserWorkItem(waitCallback_0, object_0);
		}

		// Token: 0x060014C4 RID: 5316 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_9(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x060014C5 RID: 5317 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_10(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x060014C6 RID: 5318 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_11(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x060014C7 RID: 5319 RVA: 0x00012E9A File Offset: 0x0001109A
		static void smethod_12(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x060014C8 RID: 5320 RVA: 0x00014CF7 File Offset: 0x00012EF7
		static bool smethod_13(WaitHandle waitHandle_0)
		{
			return waitHandle_0.WaitOne();
		}

		// Token: 0x060014C9 RID: 5321 RVA: 0x00014CFF File Offset: 0x00012EFF
		static bool smethod_14(object object_0, int int_0)
		{
			return Monitor.TryEnter(object_0, int_0);
		}

		// Token: 0x060014CA RID: 5322 RVA: 0x0000DBEF File Offset: 0x0000BDEF
		static void smethod_15(object object_0)
		{
			Monitor.Exit(object_0);
		}

		// Token: 0x060014CB RID: 5323 RVA: 0x00013261 File Offset: 0x00011461
		static void smethod_16(object object_0)
		{
			Monitor.Enter(object_0);
		}

		// Token: 0x060014CC RID: 5324 RVA: 0x0000C1B8 File Offset: 0x0000A3B8
		static bool smethod_17(EventWaitHandle eventWaitHandle_0)
		{
			return eventWaitHandle_0.Set();
		}

		// Token: 0x060014CD RID: 5325 RVA: 0x00013269 File Offset: 0x00011469
		static Thread smethod_18()
		{
			return Thread.CurrentThread;
		}

		// Token: 0x060014CE RID: 5326 RVA: 0x0000CF7A File Offset: 0x0000B17A
		static int smethod_19(object object_0)
		{
			return object_0.GetHashCode();
		}

		// Token: 0x060014CF RID: 5327 RVA: 0x00013270 File Offset: 0x00011470
		static void smethod_20(ConsoleColor consoleColor_0)
		{
			Console.ForegroundColor = consoleColor_0;
		}

		// Token: 0x060014D0 RID: 5328 RVA: 0x00013278 File Offset: 0x00011478
		static void smethod_21(string string_0, object object_0)
		{
			Console.Write(string_0, object_0);
		}

		// Token: 0x060014D1 RID: 5329 RVA: 0x00013082 File Offset: 0x00011282
		static void smethod_22(string string_0, object[] object_0)
		{
			Console.WriteLine(string_0, object_0);
		}

		// Token: 0x060014D2 RID: 5330 RVA: 0x00013281 File Offset: 0x00011481
		static void smethod_23()
		{
			Console.ResetColor();
		}

		// Token: 0x060014D3 RID: 5331 RVA: 0x00012D86 File Offset: 0x00010F86
		static bool smethod_24(Stream stream_0)
		{
			return stream_0.CanWrite;
		}

		// Token: 0x060014D4 RID: 5332 RVA: 0x0000E031 File Offset: 0x0000C231
		static NotSupportedException smethod_25()
		{
			return new NotSupportedException();
		}

		// Token: 0x060014D5 RID: 5333 RVA: 0x00012846 File Offset: 0x00010A46
		static long smethod_26(Stream stream_0)
		{
			return stream_0.Position;
		}

		// Token: 0x040007D4 RID: 2004
		private static readonly int IO_BUFFER_SIZE_DEFAULT = 65536;

		// Token: 0x040007D5 RID: 2005
		private static readonly int BufferPairsPerCore = 4;

		// Token: 0x040007D6 RID: 2006
		private List<WorkItem> _pool;

		// Token: 0x040007D7 RID: 2007
		private bool _leaveOpen;

		// Token: 0x040007D8 RID: 2008
		private bool emitting;

		// Token: 0x040007D9 RID: 2009
		private Stream _outStream;

		// Token: 0x040007DA RID: 2010
		private int _maxBufferPairs;

		// Token: 0x040007DB RID: 2011
		private int _bufferSize = ParallelDeflateOutputStream.IO_BUFFER_SIZE_DEFAULT;

		// Token: 0x040007DC RID: 2012
		private AutoResetEvent _newlyCompressedBlob;

		// Token: 0x040007DD RID: 2013
		private object _outputLock = ParallelDeflateOutputStream.smethod_0();

		// Token: 0x040007DE RID: 2014
		private bool _isClosed;

		// Token: 0x040007DF RID: 2015
		private bool _firstWriteDone;

		// Token: 0x040007E0 RID: 2016
		private int _currentlyFilling;

		// Token: 0x040007E1 RID: 2017
		private int _lastFilled;

		// Token: 0x040007E2 RID: 2018
		private int _lastWritten;

		// Token: 0x040007E3 RID: 2019
		private int _latestCompressed;

		// Token: 0x040007E4 RID: 2020
		private int _Crc32;

		// Token: 0x040007E5 RID: 2021
		private CRC32 _runningCrc;

		// Token: 0x040007E6 RID: 2022
		private object _latestLock = ParallelDeflateOutputStream.smethod_0();

		// Token: 0x040007E7 RID: 2023
		private Queue<int> _toWrite;

		// Token: 0x040007E8 RID: 2024
		private Queue<int> _toFill;

		// Token: 0x040007E9 RID: 2025
		private long _totalBytesProcessed;

		// Token: 0x040007EA RID: 2026
		private CompressionLevel _compressLevel;

		// Token: 0x040007EB RID: 2027
		private volatile Exception _pendingException;

		// Token: 0x040007EC RID: 2028
		private bool _handlingException;

		// Token: 0x040007ED RID: 2029
		private object _eLock = ParallelDeflateOutputStream.smethod_0();

		// Token: 0x040007EE RID: 2030
		private ParallelDeflateOutputStream.TraceBits _DesiredTrace = ParallelDeflateOutputStream.TraceBits.EmitLock | ParallelDeflateOutputStream.TraceBits.EmitEnter | ParallelDeflateOutputStream.TraceBits.EmitBegin | ParallelDeflateOutputStream.TraceBits.EmitDone | ParallelDeflateOutputStream.TraceBits.EmitSkip | ParallelDeflateOutputStream.TraceBits.Session | ParallelDeflateOutputStream.TraceBits.Compress | ParallelDeflateOutputStream.TraceBits.WriteEnter | ParallelDeflateOutputStream.TraceBits.WriteTake;

		// Token: 0x02000147 RID: 327
		[Flags]
		private enum TraceBits : uint
		{
			// Token: 0x040007F1 RID: 2033
			None = 0U,
			// Token: 0x040007F2 RID: 2034
			NotUsed1 = 1U,
			// Token: 0x040007F3 RID: 2035
			EmitLock = 2U,
			// Token: 0x040007F4 RID: 2036
			EmitEnter = 4U,
			// Token: 0x040007F5 RID: 2037
			EmitBegin = 8U,
			// Token: 0x040007F6 RID: 2038
			EmitDone = 16U,
			// Token: 0x040007F7 RID: 2039
			EmitSkip = 32U,
			// Token: 0x040007F8 RID: 2040
			EmitAll = 58U,
			// Token: 0x040007F9 RID: 2041
			Flush = 64U,
			// Token: 0x040007FA RID: 2042
			Lifecycle = 128U,
			// Token: 0x040007FB RID: 2043
			Session = 256U,
			// Token: 0x040007FC RID: 2044
			Synch = 512U,
			// Token: 0x040007FD RID: 2045
			Instance = 1024U,
			// Token: 0x040007FE RID: 2046
			Compress = 2048U,
			// Token: 0x040007FF RID: 2047
			Write = 4096U,
			// Token: 0x04000800 RID: 2048
			WriteEnter = 8192U,
			// Token: 0x04000801 RID: 2049
			WriteTake = 16384U,
			// Token: 0x04000802 RID: 2050
			All = 4294967295U
		}
	}
}
