﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zlib
{
	// Token: 0x02000156 RID: 342
	[ComVisible(true)]
	public static class ZlibConstants
	{
		// Token: 0x0400086B RID: 2155
		public const int WindowBitsMax = 15;

		// Token: 0x0400086C RID: 2156
		public const int WindowBitsDefault = 15;

		// Token: 0x0400086D RID: 2157
		public const int Z_OK = 0;

		// Token: 0x0400086E RID: 2158
		public const int Z_STREAM_END = 1;

		// Token: 0x0400086F RID: 2159
		public const int Z_NEED_DICT = 2;

		// Token: 0x04000870 RID: 2160
		public const int Z_STREAM_ERROR = -2;

		// Token: 0x04000871 RID: 2161
		public const int Z_DATA_ERROR = -3;

		// Token: 0x04000872 RID: 2162
		public const int Z_BUF_ERROR = -5;

		// Token: 0x04000873 RID: 2163
		public const int WorkingBufferSizeDefault = 16384;

		// Token: 0x04000874 RID: 2164
		public const int WorkingBufferSizeMin = 1024;
	}
}
