﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace Ionic.Zlib
{
	// Token: 0x0200013D RID: 317
	[ComVisible(true)]
	public class GZipStream : Stream
	{
		// Token: 0x170002F8 RID: 760
		// (get) Token: 0x06001438 RID: 5176 RVA: 0x00014FE4 File Offset: 0x000131E4
		// (set) Token: 0x06001439 RID: 5177 RVA: 0x00014FEC File Offset: 0x000131EC
		public string Comment
		{
			get
			{
				return this._Comment;
			}
			set
			{
				if (this._disposed)
				{
					throw GZipStream.smethod_0(<Module>.smethod_26<string>(3635215840U));
				}
				this._Comment = value;
			}
		}

		// Token: 0x170002F9 RID: 761
		// (get) Token: 0x0600143A RID: 5178 RVA: 0x0001500D File Offset: 0x0001320D
		// (set) Token: 0x0600143B RID: 5179 RVA: 0x000699BC File Offset: 0x00067BBC
		public string FileName
		{
			get
			{
				return this._FileName;
			}
			set
			{
				if (this._disposed)
				{
					throw GZipStream.smethod_0(<Module>.smethod_27<string>(1970699464U));
				}
				this._FileName = value;
				if (this._FileName == null)
				{
					return;
				}
				if (GZipStream.smethod_1(this._FileName, <Module>.smethod_27<string>(2343293944U)) != -1)
				{
					this._FileName = GZipStream.smethod_2(this._FileName, <Module>.smethod_27<string>(2343293944U), <Module>.smethod_23<string>(1896772993U));
				}
				if (!GZipStream.smethod_3(this._FileName, <Module>.smethod_27<string>(3822296921U)))
				{
					if (GZipStream.smethod_1(this._FileName, <Module>.smethod_24<string>(1184318668U)) != -1)
					{
						this._FileName = GZipStream.smethod_5(this._FileName);
					}
					return;
				}
				throw GZipStream.smethod_4(<Module>.smethod_23<string>(893452396U));
			}
		}

		// Token: 0x170002FA RID: 762
		// (get) Token: 0x0600143C RID: 5180 RVA: 0x00015015 File Offset: 0x00013215
		public int Crc32
		{
			get
			{
				return this._Crc32;
			}
		}

		// Token: 0x0600143D RID: 5181 RVA: 0x0001501D File Offset: 0x0001321D
		public GZipStream(Stream stream, CompressionMode mode)
			: this(stream, mode, CompressionLevel.Default, false)
		{
		}

		// Token: 0x0600143E RID: 5182 RVA: 0x00015029 File Offset: 0x00013229
		public GZipStream(Stream stream, CompressionMode mode, CompressionLevel level)
			: this(stream, mode, level, false)
		{
		}

		// Token: 0x0600143F RID: 5183 RVA: 0x00015035 File Offset: 0x00013235
		public GZipStream(Stream stream, CompressionMode mode, bool leaveOpen)
			: this(stream, mode, CompressionLevel.Default, leaveOpen)
		{
		}

		// Token: 0x06001440 RID: 5184 RVA: 0x00015041 File Offset: 0x00013241
		public GZipStream(Stream stream, CompressionMode mode, CompressionLevel level, bool leaveOpen)
		{
			this._baseStream = new ZlibBaseStream(stream, mode, level, ZlibStreamFlavor.GZIP, leaveOpen);
		}

		// Token: 0x170002FB RID: 763
		// (get) Token: 0x06001441 RID: 5185 RVA: 0x0001505E File Offset: 0x0001325E
		// (set) Token: 0x06001442 RID: 5186 RVA: 0x0001506B File Offset: 0x0001326B
		public virtual FlushType FlushMode
		{
			get
			{
				return this._baseStream._flushMode;
			}
			set
			{
				if (this._disposed)
				{
					throw GZipStream.smethod_0(<Module>.smethod_27<string>(1970699464U));
				}
				this._baseStream._flushMode = value;
			}
		}

		// Token: 0x170002FC RID: 764
		// (get) Token: 0x06001443 RID: 5187 RVA: 0x00015091 File Offset: 0x00013291
		// (set) Token: 0x06001444 RID: 5188 RVA: 0x00069A84 File Offset: 0x00067C84
		public int BufferSize
		{
			get
			{
				return this._baseStream._bufferSize;
			}
			set
			{
				if (this._disposed)
				{
					throw GZipStream.smethod_0(<Module>.smethod_27<string>(1970699464U));
				}
				if (this._baseStream._workingBuffer != null)
				{
					throw new ZlibException(<Module>.smethod_25<string>(1922764750U));
				}
				if (value < 1024)
				{
					throw new ZlibException(GZipStream.smethod_6(<Module>.smethod_25<string>(2340349468U), value, 1024));
				}
				this._baseStream._bufferSize = value;
			}
		}

		// Token: 0x170002FD RID: 765
		// (get) Token: 0x06001445 RID: 5189 RVA: 0x0001509E File Offset: 0x0001329E
		public virtual long TotalIn
		{
			get
			{
				return this._baseStream._z.TotalBytesIn;
			}
		}

		// Token: 0x170002FE RID: 766
		// (get) Token: 0x06001446 RID: 5190 RVA: 0x000150B0 File Offset: 0x000132B0
		public virtual long TotalOut
		{
			get
			{
				return this._baseStream._z.TotalBytesOut;
			}
		}

		// Token: 0x06001447 RID: 5191 RVA: 0x00069B00 File Offset: 0x00067D00
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (!this._disposed)
				{
					if (disposing && this._baseStream != null)
					{
						GZipStream.smethod_7(this._baseStream);
						this._Crc32 = this._baseStream.Crc32;
					}
					this._disposed = true;
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x170002FF RID: 767
		// (get) Token: 0x06001448 RID: 5192 RVA: 0x000150C2 File Offset: 0x000132C2
		public override bool CanRead
		{
			get
			{
				if (this._disposed)
				{
					throw GZipStream.smethod_0(<Module>.smethod_25<string>(3384311263U));
				}
				return GZipStream.smethod_8(this._baseStream._stream);
			}
		}

		// Token: 0x17000300 RID: 768
		// (get) Token: 0x06001449 RID: 5193 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000301 RID: 769
		// (get) Token: 0x0600144A RID: 5194 RVA: 0x000150EC File Offset: 0x000132EC
		public override bool CanWrite
		{
			get
			{
				if (this._disposed)
				{
					throw GZipStream.smethod_0(<Module>.smethod_24<string>(2177647181U));
				}
				return GZipStream.smethod_9(this._baseStream._stream);
			}
		}

		// Token: 0x0600144B RID: 5195 RVA: 0x00015116 File Offset: 0x00013316
		public override void Flush()
		{
			if (this._disposed)
			{
				throw GZipStream.smethod_0(<Module>.smethod_27<string>(1970699464U));
			}
			GZipStream.smethod_10(this._baseStream);
		}

		// Token: 0x17000302 RID: 770
		// (get) Token: 0x0600144C RID: 5196 RVA: 0x0001513B File Offset: 0x0001333B
		public override long Length
		{
			get
			{
				throw GZipStream.smethod_11();
			}
		}

		// Token: 0x17000303 RID: 771
		// (get) Token: 0x0600144D RID: 5197 RVA: 0x00069B60 File Offset: 0x00067D60
		// (set) Token: 0x0600144E RID: 5198 RVA: 0x0001513B File Offset: 0x0001333B
		public override long Position
		{
			get
			{
				if (this._baseStream._streamMode == ZlibBaseStream.StreamMode.Writer)
				{
					goto IL_0045;
				}
				if (this._baseStream._streamMode != ZlibBaseStream.StreamMode.Reader)
				{
					return 0L;
				}
				int num = -1180490578;
				IL_002C:
				switch (num ^ -1180490578)
				{
				case 1:
					return this._baseStream._z.TotalBytesOut + (long)this._headerByteCount;
				case 2:
					IL_0045:
					num = -1180490577;
					goto IL_002C;
				}
				return this._baseStream._z.TotalBytesIn + (long)this._baseStream._gzipHeaderByteCount;
			}
			set
			{
				throw GZipStream.smethod_11();
			}
		}

		// Token: 0x0600144F RID: 5199 RVA: 0x00069BF0 File Offset: 0x00067DF0
		public override int Read(byte[] buffer, int offset, int count)
		{
			if (this._disposed)
			{
				throw GZipStream.smethod_0(<Module>.smethod_24<string>(2177647181U));
			}
			int num = GZipStream.smethod_12(this._baseStream, buffer, offset, count);
			if (!this._firstReadDone)
			{
				this._firstReadDone = true;
				this.FileName = this._baseStream._GzipFileName;
				this.Comment = this._baseStream._GzipComment;
			}
			return num;
		}

		// Token: 0x06001450 RID: 5200 RVA: 0x0001513B File Offset: 0x0001333B
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw GZipStream.smethod_11();
		}

		// Token: 0x06001451 RID: 5201 RVA: 0x0001513B File Offset: 0x0001333B
		public override void SetLength(long value)
		{
			throw GZipStream.smethod_11();
		}

		// Token: 0x06001452 RID: 5202 RVA: 0x00069C58 File Offset: 0x00067E58
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (this._disposed)
			{
				throw GZipStream.smethod_0(<Module>.smethod_26<string>(3635215840U));
			}
			if (this._baseStream._streamMode == ZlibBaseStream.StreamMode.Undefined)
			{
				if (!this._baseStream._wantCompress)
				{
					throw GZipStream.smethod_13();
				}
				this._headerByteCount = this.EmitHeader();
			}
			GZipStream.smethod_14(this._baseStream, buffer, offset, count);
		}

		// Token: 0x06001453 RID: 5203 RVA: 0x00069CBC File Offset: 0x00067EBC
		private int EmitHeader()
		{
			byte[] array = ((this.Comment != null) ? GZipStream.smethod_15(GZipStream.iso8859dash1, this.Comment) : null);
			byte[] array2 = ((this.FileName == null) ? null : GZipStream.smethod_15(GZipStream.iso8859dash1, this.FileName));
			int num = ((this.Comment == null) ? 0 : (array.Length + 1));
			int num2 = ((this.FileName == null) ? 0 : (array2.Length + 1));
			int num3 = 10 + num + num2;
			byte[] array3 = new byte[num3];
			array3[0] = 31;
			array3[1] = 139;
			byte[] array4 = array3;
			int num4 = 2;
			int num5 = 3;
			array4[num4] = 8;
			byte b = 0;
			if (this.Comment != null)
			{
				b ^= 16;
			}
			if (this.FileName != null)
			{
				b ^= 8;
			}
			array3[num5++] = b;
			if (this.LastModified == null)
			{
				this.LastModified = new DateTime?(DateTime.Now);
			}
			int num6 = (int)(this.LastModified.Value - GZipStream._unixEpoch).TotalSeconds;
			Array.Copy(BitConverter.GetBytes(num6), 0, array3, num5, 4);
			num5 += 4;
			array3[num5++] = 0;
			array3[num5++] = byte.MaxValue;
			if (num2 != 0)
			{
				Array.Copy(array2, 0, array3, num5, num2 - 1);
				num5 += num2 - 1;
				array3[num5++] = 0;
			}
			if (num != 0)
			{
				Array.Copy(array, 0, array3, num5, num - 1);
				num5 += num - 1;
				array3[num5++] = 0;
			}
			this._baseStream._stream.Write(array3, 0, array3.Length);
			return array3.Length;
		}

		// Token: 0x06001454 RID: 5204 RVA: 0x00069E58 File Offset: 0x00068058
		public static byte[] CompressString(string s)
		{
			MemoryStream memoryStream = GZipStream.smethod_16();
			byte[] array;
			try
			{
				Stream stream = new GZipStream(memoryStream, CompressionMode.Compress, CompressionLevel.BestCompression);
				ZlibBaseStream.CompressString(s, stream);
				array = GZipStream.smethod_17(memoryStream);
			}
			finally
			{
				if (memoryStream != null)
				{
					GZipStream.smethod_18(memoryStream);
				}
			}
			return array;
		}

		// Token: 0x06001455 RID: 5205 RVA: 0x00069EA0 File Offset: 0x000680A0
		public static byte[] CompressBuffer(byte[] b)
		{
			MemoryStream memoryStream = GZipStream.smethod_16();
			byte[] array;
			try
			{
				Stream stream = new GZipStream(memoryStream, CompressionMode.Compress, CompressionLevel.BestCompression);
				ZlibBaseStream.CompressBuffer(b, stream);
				array = GZipStream.smethod_17(memoryStream);
			}
			finally
			{
				if (memoryStream != null)
				{
					GZipStream.smethod_18(memoryStream);
				}
			}
			return array;
		}

		// Token: 0x06001456 RID: 5206 RVA: 0x00069EE8 File Offset: 0x000680E8
		public static string UncompressString(byte[] compressed)
		{
			MemoryStream memoryStream = GZipStream.smethod_19(compressed);
			string text;
			try
			{
				Stream stream = new GZipStream(memoryStream, CompressionMode.Decompress);
				text = ZlibBaseStream.UncompressString(compressed, stream);
			}
			finally
			{
				if (memoryStream != null)
				{
					GZipStream.smethod_18(memoryStream);
				}
			}
			return text;
		}

		// Token: 0x06001457 RID: 5207 RVA: 0x00069F2C File Offset: 0x0006812C
		public static byte[] UncompressBuffer(byte[] compressed)
		{
			MemoryStream memoryStream = GZipStream.smethod_19(compressed);
			byte[] array;
			try
			{
				Stream stream = new GZipStream(memoryStream, CompressionMode.Decompress);
				array = ZlibBaseStream.UncompressBuffer(compressed, stream);
			}
			finally
			{
				if (memoryStream != null)
				{
					GZipStream.smethod_18(memoryStream);
				}
			}
			return array;
		}

		// Token: 0x06001459 RID: 5209 RVA: 0x00014B41 File Offset: 0x00012D41
		static ObjectDisposedException smethod_0(string string_0)
		{
			return new ObjectDisposedException(string_0);
		}

		// Token: 0x0600145A RID: 5210 RVA: 0x0000E038 File Offset: 0x0000C238
		static int smethod_1(string string_0, string string_1)
		{
			return string_0.IndexOf(string_1);
		}

		// Token: 0x0600145B RID: 5211 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_2(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x0600145C RID: 5212 RVA: 0x0000D9AC File Offset: 0x0000BBAC
		static bool smethod_3(string string_0, string string_1)
		{
			return string_0.EndsWith(string_1);
		}

		// Token: 0x0600145D RID: 5213 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_4(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x0600145E RID: 5214 RVA: 0x0000CFF4 File Offset: 0x0000B1F4
		static string smethod_5(string string_0)
		{
			return Path.GetFileName(string_0);
		}

		// Token: 0x0600145F RID: 5215 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_6(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x06001460 RID: 5216 RVA: 0x00012E9A File Offset: 0x0001109A
		static void smethod_7(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x06001461 RID: 5217 RVA: 0x00012837 File Offset: 0x00010A37
		static bool smethod_8(Stream stream_0)
		{
			return stream_0.CanRead;
		}

		// Token: 0x06001462 RID: 5218 RVA: 0x00012D86 File Offset: 0x00010F86
		static bool smethod_9(Stream stream_0)
		{
			return stream_0.CanWrite;
		}

		// Token: 0x06001463 RID: 5219 RVA: 0x00012D8E File Offset: 0x00010F8E
		static void smethod_10(Stream stream_0)
		{
			stream_0.Flush();
		}

		// Token: 0x06001464 RID: 5220 RVA: 0x000109B6 File Offset: 0x0000EBB6
		static NotImplementedException smethod_11()
		{
			return new NotImplementedException();
		}

		// Token: 0x06001465 RID: 5221 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_12(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06001466 RID: 5222 RVA: 0x0000C331 File Offset: 0x0000A531
		static InvalidOperationException smethod_13()
		{
			return new InvalidOperationException();
		}

		// Token: 0x06001467 RID: 5223 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_14(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x06001468 RID: 5224 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_15(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x06001469 RID: 5225 RVA: 0x0000C8A7 File Offset: 0x0000AAA7
		static MemoryStream smethod_16()
		{
			return new MemoryStream();
		}

		// Token: 0x0600146A RID: 5226 RVA: 0x0000C8C1 File Offset: 0x0000AAC1
		static byte[] smethod_17(MemoryStream memoryStream_0)
		{
			return memoryStream_0.ToArray();
		}

		// Token: 0x0600146B RID: 5227 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_18(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x0600146C RID: 5228 RVA: 0x0000C877 File Offset: 0x0000AA77
		static MemoryStream smethod_19(byte[] byte_0)
		{
			return new MemoryStream(byte_0);
		}

		// Token: 0x04000754 RID: 1876
		public DateTime? LastModified;

		// Token: 0x04000755 RID: 1877
		private int _headerByteCount;

		// Token: 0x04000756 RID: 1878
		internal ZlibBaseStream _baseStream;

		// Token: 0x04000757 RID: 1879
		private bool _disposed;

		// Token: 0x04000758 RID: 1880
		private bool _firstReadDone;

		// Token: 0x04000759 RID: 1881
		private string _FileName;

		// Token: 0x0400075A RID: 1882
		private string _Comment;

		// Token: 0x0400075B RID: 1883
		private int _Crc32;

		// Token: 0x0400075C RID: 1884
		internal static readonly DateTime _unixEpoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

		// Token: 0x0400075D RID: 1885
		internal static readonly Encoding iso8859dash1 = Encoding.GetEncoding(<Module>.smethod_23<string>(332421265U));
	}
}
