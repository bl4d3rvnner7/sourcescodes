﻿using System;
using System.Runtime.CompilerServices;

namespace Ionic.Zlib
{
	// Token: 0x02000144 RID: 324
	internal sealed class InfTree
	{
		// Token: 0x0600148C RID: 5260 RVA: 0x0006CC4C File Offset: 0x0006AE4C
		private int huft_build(int[] b, int bindex, int n, int s, int[] d, int[] e, int[] t, int[] m, int[] hp, int[] hn, int[] v)
		{
			int num = 0;
			int num2 = n;
			do
			{
				this.c[b[bindex + num]]++;
				num++;
				num2--;
			}
			while (num2 != 0);
			if (this.c[0] == n)
			{
				t[0] = -1;
				m[0] = 0;
				return 0;
			}
			int num3 = m[0];
			int i = 1;
			while (i <= 15 && this.c[i] == 0)
			{
				i++;
			}
			int j = i;
			if (num3 < i)
			{
				num3 = i;
			}
			num2 = 15;
			while (num2 != 0 && this.c[num2] == 0)
			{
				num2--;
			}
			int num4 = num2;
			if (num3 > num2)
			{
				num3 = num2;
			}
			m[0] = num3;
			int num5 = 1 << i;
			while (i < num2)
			{
				if ((num5 -= this.c[i]) < 0)
				{
					return -3;
				}
				i++;
				num5 <<= 1;
			}
			if ((num5 -= this.c[num2]) < 0)
			{
				return -3;
			}
			this.c[num2] += num5;
			int[] array = this.x;
			int num6 = 1;
			int num7 = 0;
			i = 0;
			array[num6] = num7;
			num = 1;
			int num8 = 2;
			while (--num2 != 0)
			{
				i = (this.x[num8] = i + this.c[num]);
				num8++;
				num++;
			}
			num2 = 0;
			num = 0;
			do
			{
				if ((i = b[bindex + num]) != 0)
				{
					v[this.x[i]++] = num2;
				}
				num++;
			}
			while (++num2 < n);
			n = this.x[num4];
			int[] array2 = this.x;
			int num9 = 0;
			int num10 = 0;
			num2 = 0;
			array2[num9] = num10;
			num = 0;
			int num11 = -1;
			int num12 = -num3;
			this.u[0] = 0;
			int num13 = 0;
			int num14 = 0;
			while (j <= num4)
			{
				int num15 = this.c[j];
				while (num15-- != 0)
				{
					int num16;
					while (j > num12 + num3)
					{
						num11++;
						num12 += num3;
						num14 = num4 - num12;
						num14 = ((num14 > num3) ? num3 : num14);
						if ((num16 = 1 << ((i = j - num12) & 31)) > num15 + 1)
						{
							num16 -= num15 + 1;
							num8 = j;
							if (i < num14)
							{
								while (++i < num14 && (num16 <<= 1) > this.c[++num8])
								{
									num16 -= this.c[num8];
								}
							}
						}
						num14 = 1 << i;
						if (hn[0] + num14 > 1440)
						{
							return -3;
						}
						num13 = (this.u[num11] = hn[0]);
						hn[0] += num14;
						if (num11 != 0)
						{
							this.x[num11] = num2;
							this.r[0] = (int)((sbyte)i);
							this.r[1] = (int)((sbyte)num3);
							i = SharedUtils.URShift(num2, num12 - num3);
							this.r[2] = num13 - this.u[num11 - 1] - i;
							InfTree.smethod_0(this.r, 0, hp, (this.u[num11 - 1] + i) * 3, 3);
						}
						else
						{
							t[0] = num13;
						}
					}
					this.r[1] = (int)((sbyte)(j - num12));
					if (num >= n)
					{
						this.r[0] = 192;
					}
					else if (v[num] >= s)
					{
						this.r[0] = (int)((sbyte)(e[v[num] - s] + 16 + 64));
						this.r[2] = d[v[num++] - s];
					}
					else
					{
						this.r[0] = (int)((v[num] < 256) ? 0 : 96);
						this.r[2] = v[num++];
					}
					num16 = 1 << j - num12;
					for (i = SharedUtils.URShift(num2, num12); i < num14; i += num16)
					{
						InfTree.smethod_0(this.r, 0, hp, (num13 + i) * 3, 3);
					}
					i = 1 << j - 1;
					while ((num2 & i) != 0)
					{
						num2 ^= i;
						i = SharedUtils.URShift(i, 1);
					}
					num2 ^= i;
					int num17 = (1 << num12) - 1;
					while ((num2 & num17) != this.x[num11])
					{
						num11--;
						num12 -= num3;
						num17 = (1 << num12) - 1;
					}
				}
				j++;
			}
			if (num5 != 0)
			{
				if (num4 != 1)
				{
					return -5;
				}
			}
			return 0;
		}

		// Token: 0x0600148D RID: 5261 RVA: 0x0006D048 File Offset: 0x0006B248
		internal int inflate_trees_bits(int[] c, int[] bb, int[] tb, int[] hp, ZlibCodec z)
		{
			this.initWorkArea(19);
			this.hn[0] = 0;
			int num = this.huft_build(c, 0, 19, 19, null, null, tb, bb, hp, this.hn, this.v);
			if (num == -3)
			{
				z.Message = <Module>.smethod_26<string>(1655319087U);
			}
			else if (num == -5 || bb[0] == 0)
			{
				z.Message = <Module>.smethod_24<string>(2730967733U);
				num = -3;
			}
			return num;
		}

		// Token: 0x0600148E RID: 5262 RVA: 0x0006D0BC File Offset: 0x0006B2BC
		internal int inflate_trees_dynamic(int nl, int nd, int[] c, int[] bl, int[] bd, int[] tl, int[] td, int[] hp, ZlibCodec z)
		{
			this.initWorkArea(288);
			this.hn[0] = 0;
			int num = this.huft_build(c, 0, nl, 257, InfTree.cplens, InfTree.cplext, tl, bl, hp, this.hn, this.v);
			if (num != 0 || bl[0] == 0)
			{
				if (num != -3)
				{
					if (num != -4)
					{
						z.Message = <Module>.smethod_24<string>(2148177297U);
						num = -3;
					}
				}
				else
				{
					z.Message = <Module>.smethod_25<string>(2926576965U);
				}
				return num;
			}
			this.initWorkArea(288);
			num = this.huft_build(c, nl, nd, 0, InfTree.cpdist, InfTree.cpdext, td, bd, hp, this.hn, this.v);
			if (num == 0 && (bd[0] != 0 || nl <= 257))
			{
				return 0;
			}
			if (num == -3)
			{
				z.Message = <Module>.smethod_25<string>(649935806U);
			}
			else if (num == -5)
			{
				z.Message = <Module>.smethod_23<string>(1953931781U);
				num = -3;
			}
			else if (num != -4)
			{
				z.Message = <Module>.smethod_24<string>(733119769U);
				num = -3;
			}
			return num;
		}

		// Token: 0x0600148F RID: 5263 RVA: 0x00015263 File Offset: 0x00013463
		internal static int inflate_trees_fixed(int[] bl, int[] bd, int[][] tl, int[][] td, ZlibCodec z)
		{
			bl[0] = 9;
			bd[0] = 5;
			tl[0] = InfTree.fixed_tl;
			td[0] = InfTree.fixed_td;
			return 0;
		}

		// Token: 0x06001490 RID: 5264 RVA: 0x0006D1E0 File Offset: 0x0006B3E0
		private void initWorkArea(int vsize)
		{
			if (this.hn == null)
			{
				this.hn = new int[1];
				this.v = new int[vsize];
				this.c = new int[16];
				this.r = new int[3];
				this.u = new int[15];
				this.x = new int[16];
				return;
			}
			if (this.v.Length < vsize)
			{
				this.v = new int[vsize];
			}
			InfTree.smethod_1(this.v, 0, vsize);
			InfTree.smethod_1(this.c, 0, 16);
			this.r[0] = 0;
			this.r[1] = 0;
			this.r[2] = 0;
			InfTree.smethod_1(this.u, 0, 15);
			InfTree.smethod_1(this.x, 0, 16);
		}

		// Token: 0x06001492 RID: 5266 RVA: 0x0006D2AC File Offset: 0x0006B4AC
		// Note: this type is marked as 'beforefieldinit'.
		static InfTree()
		{
			int[] array = new int[1536];
			InfTree.smethod_2(array, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050d-1).FieldHandle);
			InfTree.fixed_tl = array;
			int[] array2 = new int[96];
			InfTree.smethod_2(array2, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050d-2).FieldHandle);
			InfTree.fixed_td = array2;
			int[] array3 = new int[31];
			InfTree.smethod_2(array3, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050d-3).FieldHandle);
			InfTree.cplens = array3;
			int[] array4 = new int[31];
			InfTree.smethod_2(array4, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050d-4).FieldHandle);
			InfTree.cplext = array4;
			int[] array5 = new int[30];
			InfTree.smethod_2(array5, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050d-5).FieldHandle);
			InfTree.cpdist = array5;
			int[] array6 = new int[30];
			InfTree.smethod_2(array6, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050d-6).FieldHandle);
			InfTree.cpdext = array6;
		}

		// Token: 0x06001493 RID: 5267 RVA: 0x0000C3EE File Offset: 0x0000A5EE
		static void smethod_0(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Array.Copy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x06001494 RID: 5268 RVA: 0x00014DF1 File Offset: 0x00012FF1
		static void smethod_1(Array array_0, int int_0, int int_1)
		{
			Array.Clear(array_0, int_0, int_1);
		}

		// Token: 0x06001495 RID: 5269 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_2(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x040007B3 RID: 1971
		private const int MANY = 1440;

		// Token: 0x040007B4 RID: 1972
		private const int Z_OK = 0;

		// Token: 0x040007B5 RID: 1973
		private const int Z_STREAM_END = 1;

		// Token: 0x040007B6 RID: 1974
		private const int Z_NEED_DICT = 2;

		// Token: 0x040007B7 RID: 1975
		private const int Z_ERRNO = -1;

		// Token: 0x040007B8 RID: 1976
		private const int Z_STREAM_ERROR = -2;

		// Token: 0x040007B9 RID: 1977
		private const int Z_DATA_ERROR = -3;

		// Token: 0x040007BA RID: 1978
		private const int Z_MEM_ERROR = -4;

		// Token: 0x040007BB RID: 1979
		private const int Z_BUF_ERROR = -5;

		// Token: 0x040007BC RID: 1980
		private const int Z_VERSION_ERROR = -6;

		// Token: 0x040007BD RID: 1981
		internal const int fixed_bl = 9;

		// Token: 0x040007BE RID: 1982
		internal const int fixed_bd = 5;

		// Token: 0x040007BF RID: 1983
		internal const int BMAX = 15;

		// Token: 0x040007C0 RID: 1984
		internal static readonly int[] fixed_tl;

		// Token: 0x040007C1 RID: 1985
		internal static readonly int[] fixed_td;

		// Token: 0x040007C2 RID: 1986
		internal static readonly int[] cplens;

		// Token: 0x040007C3 RID: 1987
		internal static readonly int[] cplext;

		// Token: 0x040007C4 RID: 1988
		internal static readonly int[] cpdist;

		// Token: 0x040007C5 RID: 1989
		internal static readonly int[] cpdext;

		// Token: 0x040007C6 RID: 1990
		internal int[] hn;

		// Token: 0x040007C7 RID: 1991
		internal int[] v;

		// Token: 0x040007C8 RID: 1992
		internal int[] c;

		// Token: 0x040007C9 RID: 1993
		internal int[] r;

		// Token: 0x040007CA RID: 1994
		internal int[] u;

		// Token: 0x040007CB RID: 1995
		internal int[] x;
	}
}
