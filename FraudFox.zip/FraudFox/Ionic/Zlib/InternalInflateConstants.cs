﻿using System;
using System.Runtime.CompilerServices;

namespace Ionic.Zlib
{
	// Token: 0x02000140 RID: 320
	internal static class InternalInflateConstants
	{
		// Token: 0x06001478 RID: 5240 RVA: 0x000151AB File Offset: 0x000133AB
		// Note: this type is marked as 'beforefieldinit'.
		static InternalInflateConstants()
		{
			int[] array = new int[17];
			InternalInflateConstants.smethod_0(array, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x600050b-1).FieldHandle);
			InternalInflateConstants.InflateMask = array;
		}

		// Token: 0x06001479 RID: 5241 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_0(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x0400077F RID: 1919
		internal static readonly int[] InflateMask;
	}
}
