﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x02000152 RID: 338
	internal enum ZlibStreamFlavor
	{
		// Token: 0x04000843 RID: 2115
		ZLIB = 1950,
		// Token: 0x04000844 RID: 2116
		DEFLATE,
		// Token: 0x04000845 RID: 2117
		GZIP
	}
}
