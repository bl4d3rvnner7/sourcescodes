﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x02000145 RID: 325
	internal class WorkItem
	{
		// Token: 0x06001496 RID: 5270 RVA: 0x0006D348 File Offset: 0x0006B548
		public WorkItem(int size, CompressionLevel compressLevel, CompressionStrategy strategy, int ix)
		{
			this.buffer = new byte[size];
			int num = size + (size / 32768 + 1) * 5 * 2;
			this.compressed = new byte[num];
			this.compressor = new ZlibCodec();
			this.compressor.InitializeDeflate(compressLevel, false);
			this.compressor.OutputBuffer = this.compressed;
			this.compressor.InputBuffer = this.buffer;
			this.index = ix;
		}

		// Token: 0x040007CC RID: 1996
		public byte[] buffer;

		// Token: 0x040007CD RID: 1997
		public byte[] compressed;

		// Token: 0x040007CE RID: 1998
		public int crc;

		// Token: 0x040007CF RID: 1999
		public int index;

		// Token: 0x040007D0 RID: 2000
		public int ordinal;

		// Token: 0x040007D1 RID: 2001
		public int inputBytesAvailable;

		// Token: 0x040007D2 RID: 2002
		public int compressedBytesAvailable;

		// Token: 0x040007D3 RID: 2003
		public ZlibCodec compressor;
	}
}
