﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zlib
{
	// Token: 0x0200014D RID: 333
	[Guid("ebc25cf6-9120-4283-b972-0e5520d0000E")]
	[ComVisible(true)]
	public class ZlibException : Exception
	{
		// Token: 0x060014DF RID: 5343 RVA: 0x0000F665 File Offset: 0x0000D865
		public ZlibException()
		{
		}

		// Token: 0x060014E0 RID: 5344 RVA: 0x0000C1DA File Offset: 0x0000A3DA
		public ZlibException(string s)
			: base(s)
		{
		}
	}
}
