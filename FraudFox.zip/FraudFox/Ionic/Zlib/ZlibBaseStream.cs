﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Ionic.Crc;

namespace Ionic.Zlib
{
	// Token: 0x02000153 RID: 339
	internal class ZlibBaseStream : Stream
	{
		// Token: 0x1700030F RID: 783
		// (get) Token: 0x060014F1 RID: 5361 RVA: 0x00015433 File Offset: 0x00013633
		internal int Crc32
		{
			get
			{
				if (this.crc == null)
				{
					return 0;
				}
				return this.crc.Crc32Result;
			}
		}

		// Token: 0x060014F2 RID: 5362 RVA: 0x0006E588 File Offset: 0x0006C788
		public ZlibBaseStream(Stream stream, CompressionMode compressionMode, CompressionLevel level, ZlibStreamFlavor flavor, bool leaveOpen)
		{
			this._flushMode = FlushType.None;
			this._stream = stream;
			this._leaveOpen = leaveOpen;
			this._compressionMode = compressionMode;
			this._flavor = flavor;
			this._level = level;
			if (flavor == ZlibStreamFlavor.GZIP)
			{
				this.crc = new CRC32();
			}
		}

		// Token: 0x17000310 RID: 784
		// (get) Token: 0x060014F3 RID: 5363 RVA: 0x0001544A File Offset: 0x0001364A
		protected internal bool _wantCompress
		{
			get
			{
				return this._compressionMode == CompressionMode.Compress;
			}
		}

		// Token: 0x17000311 RID: 785
		// (get) Token: 0x060014F4 RID: 5364 RVA: 0x0006E5FC File Offset: 0x0006C7FC
		private ZlibCodec z
		{
			get
			{
				if (this._z == null)
				{
					bool flag = this._flavor == ZlibStreamFlavor.ZLIB;
					this._z = new ZlibCodec();
					if (this._compressionMode == CompressionMode.Decompress)
					{
						this._z.InitializeInflate(flag);
					}
					else
					{
						this._z.Strategy = this.Strategy;
						this._z.InitializeDeflate(this._level, flag);
					}
				}
				return this._z;
			}
		}

		// Token: 0x17000312 RID: 786
		// (get) Token: 0x060014F5 RID: 5365 RVA: 0x00015455 File Offset: 0x00013655
		private byte[] workingBuffer
		{
			get
			{
				if (this._workingBuffer == null)
				{
					this._workingBuffer = new byte[this._bufferSize];
				}
				return this._workingBuffer;
			}
		}

		// Token: 0x060014F6 RID: 5366 RVA: 0x0006E66C File Offset: 0x0006C86C
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (this.crc != null)
			{
				this.crc.SlurpBlock(buffer, offset, count);
			}
			if (this._streamMode == ZlibBaseStream.StreamMode.Undefined)
			{
				this._streamMode = ZlibBaseStream.StreamMode.Writer;
			}
			else if (this._streamMode != ZlibBaseStream.StreamMode.Writer)
			{
				throw new ZlibException(<Module>.smethod_27<string>(1353074375U));
			}
			if (count == 0)
			{
				return;
			}
			this.z.InputBuffer = buffer;
			this._z.NextIn = offset;
			this._z.AvailableBytesIn = count;
			for (;;)
			{
				this._z.OutputBuffer = this.workingBuffer;
				this._z.NextOut = 0;
				this._z.AvailableBytesOut = this._workingBuffer.Length;
				int num = (this._wantCompress ? this._z.Deflate(this._flushMode) : this._z.Inflate(this._flushMode));
				if (num != 0 && num != 1)
				{
					break;
				}
				ZlibBaseStream.smethod_1(this._stream, this._workingBuffer, 0, this._workingBuffer.Length - this._z.AvailableBytesOut);
				bool flag = this._z.AvailableBytesIn == 0 && this._z.AvailableBytesOut != 0;
				if (this._flavor == ZlibStreamFlavor.GZIP)
				{
					if (!this._wantCompress)
					{
						flag = this._z.AvailableBytesIn == 8 && this._z.AvailableBytesOut != 0;
					}
				}
				if (flag)
				{
					return;
				}
			}
			throw new ZlibException(ZlibBaseStream.smethod_0(this._wantCompress ? <Module>.smethod_23<string>(3916875900U) : <Module>.smethod_23<string>(2379155005U), <Module>.smethod_23<string>(1497252279U), this._z.Message));
		}

		// Token: 0x060014F7 RID: 5367 RVA: 0x0006E824 File Offset: 0x0006CA24
		private void finish()
		{
			if (this._z == null)
			{
				return;
			}
			int num5;
			int crc32Result2;
			int num7;
			int num8;
			int num9;
			for (;;)
			{
				IL_0474:
				if (this._streamMode != ZlibBaseStream.StreamMode.Writer)
				{
					goto IL_0457;
				}
				bool flag = false;
				int num = -931315966;
				for (;;)
				{
					IL_03B7:
					bool flag2;
					byte[] array;
					int num2;
					bool flag3;
					int num6;
					switch (num ^ -931315938)
					{
					case 0:
						if (this._z.AvailableBytesIn == 0)
						{
							num = -931315958;
							continue;
						}
						flag2 = false;
						goto IL_0177;
					case 1:
						goto IL_0474;
					case 2:
						ZlibBaseStream.smethod_6(this._z.InputBuffer, this._z.NextIn, array, 0, array.Length);
						num = -931315965;
						continue;
					case 3:
						num = ((this._flavor == ZlibStreamFlavor.GZIP) ? (-931315944) : (-931315968));
						continue;
					case 4:
						num2 = this._z.Inflate(FlushType.Finish);
						goto IL_02B4;
					case 5:
					{
						int num3;
						ZlibBaseStream.smethod_1(this._stream, ZlibBaseStream.smethod_5(num3), 0, 4);
						num = -931315959;
						continue;
					}
					case 6:
						if (this._wantCompress)
						{
							goto IL_008C;
						}
						if (this._z.AvailableBytesIn == 8)
						{
							num = -931315908;
							continue;
						}
						flag3 = false;
						goto IL_0048;
					case 7:
						if (this._wantCompress)
						{
							goto IL_0554;
						}
						if (this._z.TotalBytesOut == 0L)
						{
							return;
						}
						goto IL_0182;
					case 8:
					{
						int num4;
						if (num4 != num5)
						{
							goto Block_12;
						}
						goto IL_00DD;
					}
					case 9:
						this._z.AvailableBytesOut = this._workingBuffer.Length;
						if (!this._wantCompress)
						{
							num = -931315942;
							continue;
						}
						num2 = this._z.Deflate(FlushType.Finish);
						goto IL_02B4;
					case 10:
						goto IL_04A7;
					case 11:
						goto IL_0457;
					case 12:
						goto IL_0109;
					case 13:
					{
						int num4 = 8 - this._z.AvailableBytesIn;
						num = -931315951;
						continue;
					}
					case 14:
						ZlibBaseStream.smethod_1(this._stream, this._workingBuffer, 0, this._workingBuffer.Length - this._z.AvailableBytesOut);
						num = -931315938;
						continue;
					case 15:
					{
						int num4;
						num5 = ZlibBaseStream.smethod_7(this._stream, array, this._z.AvailableBytesIn, num4);
						num = -931315946;
						continue;
					}
					case 16:
						ZlibBaseStream.smethod_6(this._z.InputBuffer, this._z.NextIn, array, 0, this._z.AvailableBytesIn);
						num = -931315949;
						continue;
					case 17:
						goto IL_04B7;
					case 18:
					{
						int crc32Result;
						ZlibBaseStream.smethod_1(this._stream, ZlibBaseStream.smethod_5(crc32Result), 0, 4);
						int num3 = (int)(this.crc.TotalBytesRead & 4294967295L);
						num = -931315941;
						continue;
					}
					case 19:
						goto IL_0182;
					case 20:
						flag2 = this._z.AvailableBytesOut != 0;
						goto IL_0177;
					case 21:
					{
						int crc32Result = this.crc.Crc32Result;
						num = -931315956;
						continue;
					}
					case 22:
						num = ((!this._wantCompress) ? (-931315948) : (-931315957));
						continue;
					case 23:
						return;
					case 24:
						if (num6 == 0)
						{
							goto IL_0109;
						}
						if (!this._wantCompress)
						{
							num = -931315964;
							continue;
						}
						goto IL_04E4;
					case 25:
						goto IL_0533;
					case 26:
						goto IL_04F0;
					case 28:
						goto IL_00B6;
					case 29:
						goto IL_00DD;
					case 30:
						goto IL_008C;
					case 31:
						goto IL_0554;
					case 32:
						crc32Result2 = this.crc.Crc32Result;
						num7 = ZlibBaseStream.smethod_9(array, 4);
						num8 = (int)(this._z.TotalBytesOut & 4294967295L);
						num = -931315953;
						continue;
					case 33:
						goto IL_0564;
					case 34:
						flag3 = this._z.AvailableBytesOut != 0;
						goto IL_0048;
					case 35:
						num = -931315937;
						continue;
					}
					goto Block_19;
					IL_0048:
					flag = flag3;
					num = -931315968;
					continue;
					IL_008C:
					if (flag)
					{
						ZlibBaseStream.smethod_4(this);
						num = ((this._flavor != ZlibStreamFlavor.GZIP) ? (-931315963) : (-931315960));
						continue;
					}
					IL_00B6:
					this._z.OutputBuffer = this.workingBuffer;
					this._z.NextOut = 0;
					num = -931315945;
					continue;
					IL_00DD:
					num9 = ZlibBaseStream.smethod_9(array, 0);
					num = -931315906;
					continue;
					IL_0109:
					num = ((this._workingBuffer.Length - this._z.AvailableBytesOut > 0) ? (-931315952) : (-931315938));
					continue;
					IL_0177:
					flag = flag2;
					num = -931315939;
					continue;
					IL_0182:
					array = new byte[8];
					num = ((this._z.AvailableBytesIn >= 8) ? (-931315940) : (-931315954));
					continue;
					IL_02B4:
					num6 = num2;
					num = ((num6 == 1) ? (-931315950) : (-931315962));
				}
				IL_0457:
				if (this._streamMode == ZlibBaseStream.StreamMode.Reader)
				{
					num = ((this._flavor != ZlibStreamFlavor.GZIP) ? (-931315963) : (-931315943));
					goto IL_03B7;
				}
				return;
			}
			Block_12:
			throw new ZlibException(ZlibBaseStream.smethod_8(<Module>.smethod_26<string>(3908933533U), this._z.AvailableBytesIn + num5));
			Block_19:
			return;
			IL_04A7:
			throw new ZlibException(<Module>.smethod_24<string>(2873235946U));
			IL_04B7:
			if (crc32Result2 != num9)
			{
				throw new ZlibException(ZlibBaseStream.smethod_3(<Module>.smethod_23<string>(356375892U), crc32Result2, num9));
			}
			goto IL_0564;
			IL_04E4:
			string text = <Module>.smethod_26<string>(4214723916U);
			goto IL_04FA;
			IL_04F0:
			text = <Module>.smethod_23<string>(2379155005U);
			IL_04FA:
			string text2 = ZlibBaseStream.smethod_2(text, <Module>.smethod_26<string>(4081308625U));
			if (this._z.Message == null)
			{
				int num6;
				throw new ZlibException(ZlibBaseStream.smethod_3(<Module>.smethod_24<string>(3509884943U), text2, num6));
			}
			IL_0533:
			throw new ZlibException(ZlibBaseStream.smethod_0(text2, <Module>.smethod_23<string>(1234679705U), this._z.Message));
			IL_0554:
			throw new ZlibException(<Module>.smethod_25<string>(957773491U));
			IL_0564:
			if (num8 != num7)
			{
				throw new ZlibException(ZlibBaseStream.smethod_3(<Module>.smethod_24<string>(2398162632U), num8, num7));
			}
		}

		// Token: 0x060014F8 RID: 5368 RVA: 0x00015476 File Offset: 0x00013676
		private void end()
		{
			if (this.z == null)
			{
				return;
			}
			if (!this._wantCompress)
			{
				this._z.EndInflate();
			}
			else
			{
				this._z.EndDeflate();
			}
			this._z = null;
		}

		// Token: 0x060014F9 RID: 5369 RVA: 0x0006EDC0 File Offset: 0x0006CFC0
		public override void Close()
		{
			if (this._stream == null)
			{
				return;
			}
			try
			{
				this.finish();
			}
			finally
			{
				this.end();
				if (!this._leaveOpen)
				{
					ZlibBaseStream.smethod_10(this._stream);
				}
				this._stream = null;
			}
		}

		// Token: 0x060014FA RID: 5370 RVA: 0x000154AA File Offset: 0x000136AA
		public override void Flush()
		{
			ZlibBaseStream.smethod_4(this._stream);
		}

		// Token: 0x060014FB RID: 5371 RVA: 0x000154B7 File Offset: 0x000136B7
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw ZlibBaseStream.smethod_11();
		}

		// Token: 0x060014FC RID: 5372 RVA: 0x000154BE File Offset: 0x000136BE
		public override void SetLength(long value)
		{
			ZlibBaseStream.smethod_12(this._stream, value);
		}

		// Token: 0x060014FD RID: 5373 RVA: 0x0006EE10 File Offset: 0x0006D010
		private string ReadZeroTerminatedString()
		{
			List<byte> list = new List<byte>();
			bool flag = false;
			for (;;)
			{
				int num = ZlibBaseStream.smethod_7(this._stream, this._buf1, 0, 1);
				if (num != 1)
				{
					break;
				}
				if (this._buf1[0] != 0)
				{
					list.Add(this._buf1[0]);
				}
				else
				{
					flag = true;
				}
				if (flag)
				{
					goto IL_0053;
				}
			}
			throw new ZlibException(<Module>.smethod_24<string>(1869230757U));
			IL_0053:
			byte[] array = list.ToArray();
			return ZlibBaseStream.smethod_13(GZipStream.iso8859dash1, array, 0, array.Length);
		}

		// Token: 0x060014FE RID: 5374 RVA: 0x0006EE88 File Offset: 0x0006D088
		private int _ReadAndValidateGzipHeader()
		{
			int num = 0;
			byte[] array = new byte[10];
			int num2 = ZlibBaseStream.smethod_7(this._stream, array, 0, array.Length);
			if (num2 == 0)
			{
				return 0;
			}
			if (num2 != 10)
			{
				throw new ZlibException(<Module>.smethod_23<string>(3486512174U));
			}
			if (array[0] == 31 && array[1] == 139)
			{
				if (array[2] == 8)
				{
					int num3 = ZlibBaseStream.smethod_9(array, 4);
					this._GzipMtime = GZipStream._unixEpoch.AddSeconds((double)num3);
					num += num2;
					if ((array[3] & 4) == 4)
					{
						num2 = this._stream.Read(array, 0, 2);
						num += num2;
						short num4 = (short)((int)array[0] + (int)array[1] * 256);
						byte[] array2 = new byte[(int)num4];
						num2 = this._stream.Read(array2, 0, array2.Length);
						if (num2 != (int)num4)
						{
							throw new ZlibException(<Module>.smethod_23<string>(1822232906U));
						}
						num += num2;
					}
					if ((array[3] & 8) == 8)
					{
						this._GzipFileName = this.ReadZeroTerminatedString();
					}
					if ((array[3] & 16) == 16)
					{
						this._GzipComment = this.ReadZeroTerminatedString();
					}
					if ((array[3] & 2) == 2)
					{
						this.Read(this._buf1, 0, 1);
					}
					return num;
				}
			}
			throw new ZlibException(<Module>.smethod_24<string>(2736048940U));
		}

		// Token: 0x060014FF RID: 5375 RVA: 0x0006EFC8 File Offset: 0x0006D1C8
		public override int Read(byte[] buffer, int offset, int count)
		{
			if (this._streamMode == ZlibBaseStream.StreamMode.Undefined)
			{
				if (!ZlibBaseStream.smethod_14(this._stream))
				{
					throw new ZlibException(<Module>.smethod_26<string>(2110988266U));
				}
				this._streamMode = ZlibBaseStream.StreamMode.Reader;
				this.z.AvailableBytesIn = 0;
				if (this._flavor == ZlibStreamFlavor.GZIP)
				{
					this._gzipHeaderByteCount = this._ReadAndValidateGzipHeader();
					if (this._gzipHeaderByteCount == 0)
					{
						return 0;
					}
				}
			}
			if (this._streamMode != ZlibBaseStream.StreamMode.Reader)
			{
				throw new ZlibException(<Module>.smethod_27<string>(3165548862U));
			}
			if (count == 0)
			{
				return 0;
			}
			if (this.nomoreinput && this._wantCompress)
			{
				return 0;
			}
			if (buffer == null)
			{
				throw ZlibBaseStream.smethod_15(<Module>.smethod_23<string>(855314027U));
			}
			if (count < 0)
			{
				throw ZlibBaseStream.smethod_16(<Module>.smethod_24<string>(4165338314U));
			}
			if (offset < ZlibBaseStream.smethod_17(buffer, 0))
			{
				throw ZlibBaseStream.smethod_16(<Module>.smethod_25<string>(562920811U));
			}
			if (offset + count > ZlibBaseStream.smethod_18(buffer, 0))
			{
				throw ZlibBaseStream.smethod_16(<Module>.smethod_26<string>(3423790121U));
			}
			this._z.OutputBuffer = buffer;
			this._z.NextOut = offset;
			this._z.AvailableBytesOut = count;
			this._z.InputBuffer = this.workingBuffer;
			int num;
			for (;;)
			{
				if (this._z.AvailableBytesIn == 0 && !this.nomoreinput)
				{
					this._z.NextIn = 0;
					this._z.AvailableBytesIn = ZlibBaseStream.smethod_7(this._stream, this._workingBuffer, 0, this._workingBuffer.Length);
					if (this._z.AvailableBytesIn == 0)
					{
						this.nomoreinput = true;
					}
				}
				num = (this._wantCompress ? this._z.Deflate(this._flushMode) : this._z.Inflate(this._flushMode));
				if (this.nomoreinput && num == -5)
				{
					break;
				}
				if (num != 0 && num != 1)
				{
					goto IL_0212;
				}
				if (this.nomoreinput || num == 1)
				{
					if (this._z.AvailableBytesOut == count)
					{
						goto Block_19;
					}
				}
				if (this._z.AvailableBytesOut <= 0 || this.nomoreinput || num != 0)
				{
					goto IL_0256;
				}
			}
			return 0;
			Block_19:
			goto IL_0256;
			IL_0212:
			throw new ZlibException(ZlibBaseStream.smethod_19(<Module>.smethod_23<string>(2906666918U), this._wantCompress ? <Module>.smethod_24<string>(1521696297U) : <Module>.smethod_26<string>(1371370775U), num, this._z.Message));
			IL_0256:
			if (this._z.AvailableBytesOut > 0)
			{
				if (num != 0)
				{
				}
				if (this.nomoreinput && this._wantCompress)
				{
					num = this._z.Deflate(FlushType.Finish);
					if (num != 0 && num != 1)
					{
						throw new ZlibException(ZlibBaseStream.smethod_3(<Module>.smethod_23<string>(3099948670U), num, this._z.Message));
					}
				}
			}
			num = count - this._z.AvailableBytesOut;
			if (this.crc != null)
			{
				this.crc.SlurpBlock(buffer, offset, num);
			}
			return num;
		}

		// Token: 0x17000313 RID: 787
		// (get) Token: 0x06001500 RID: 5376 RVA: 0x000154CC File Offset: 0x000136CC
		public override bool CanRead
		{
			get
			{
				return ZlibBaseStream.smethod_14(this._stream);
			}
		}

		// Token: 0x17000314 RID: 788
		// (get) Token: 0x06001501 RID: 5377 RVA: 0x000154D9 File Offset: 0x000136D9
		public override bool CanSeek
		{
			get
			{
				return ZlibBaseStream.smethod_20(this._stream);
			}
		}

		// Token: 0x17000315 RID: 789
		// (get) Token: 0x06001502 RID: 5378 RVA: 0x000154E6 File Offset: 0x000136E6
		public override bool CanWrite
		{
			get
			{
				return ZlibBaseStream.smethod_21(this._stream);
			}
		}

		// Token: 0x17000316 RID: 790
		// (get) Token: 0x06001503 RID: 5379 RVA: 0x000154F3 File Offset: 0x000136F3
		public override long Length
		{
			get
			{
				return ZlibBaseStream.smethod_22(this._stream);
			}
		}

		// Token: 0x17000317 RID: 791
		// (get) Token: 0x06001504 RID: 5380 RVA: 0x000154B7 File Offset: 0x000136B7
		// (set) Token: 0x06001505 RID: 5381 RVA: 0x000154B7 File Offset: 0x000136B7
		public override long Position
		{
			get
			{
				throw ZlibBaseStream.smethod_11();
			}
			set
			{
				throw ZlibBaseStream.smethod_11();
			}
		}

		// Token: 0x06001506 RID: 5382 RVA: 0x0006F2C0 File Offset: 0x0006D4C0
		public static void CompressString(string s, Stream compressor)
		{
			byte[] array = ZlibBaseStream.smethod_24(ZlibBaseStream.smethod_23(), s);
			try
			{
				ZlibBaseStream.smethod_1(compressor, array, 0, array.Length);
			}
			finally
			{
				if (compressor != null)
				{
					ZlibBaseStream.smethod_25(compressor);
				}
			}
		}

		// Token: 0x06001507 RID: 5383 RVA: 0x0006F304 File Offset: 0x0006D504
		public static void CompressBuffer(byte[] b, Stream compressor)
		{
			try
			{
				ZlibBaseStream.smethod_1(compressor, b, 0, b.Length);
			}
			finally
			{
				if (compressor != null)
				{
					ZlibBaseStream.smethod_25(compressor);
				}
			}
		}

		// Token: 0x06001508 RID: 5384 RVA: 0x0006F33C File Offset: 0x0006D53C
		public static string UncompressString(byte[] compressed, Stream decompressor)
		{
			byte[] array = new byte[1024];
			Encoding encoding = ZlibBaseStream.smethod_23();
			MemoryStream memoryStream = ZlibBaseStream.smethod_26();
			string text;
			try
			{
				try
				{
					int num;
					while ((num = ZlibBaseStream.smethod_7(decompressor, array, 0, array.Length)) != 0)
					{
						ZlibBaseStream.smethod_1(memoryStream, array, 0, num);
					}
				}
				finally
				{
					if (decompressor != null)
					{
						ZlibBaseStream.smethod_25(decompressor);
					}
				}
				ZlibBaseStream.smethod_27(memoryStream, 0L, SeekOrigin.Begin);
				StreamReader streamReader = ZlibBaseStream.smethod_28(memoryStream, encoding);
				text = ZlibBaseStream.smethod_29(streamReader);
			}
			finally
			{
				if (memoryStream != null)
				{
					ZlibBaseStream.smethod_25(memoryStream);
				}
			}
			return text;
		}

		// Token: 0x06001509 RID: 5385 RVA: 0x0006F3D8 File Offset: 0x0006D5D8
		public static byte[] UncompressBuffer(byte[] compressed, Stream decompressor)
		{
			byte[] array = new byte[1024];
			MemoryStream memoryStream = ZlibBaseStream.smethod_26();
			byte[] array2;
			try
			{
				try
				{
					int num;
					while ((num = ZlibBaseStream.smethod_7(decompressor, array, 0, array.Length)) != 0)
					{
						ZlibBaseStream.smethod_1(memoryStream, array, 0, num);
					}
				}
				finally
				{
					if (decompressor != null)
					{
						ZlibBaseStream.smethod_25(decompressor);
					}
				}
				array2 = ZlibBaseStream.smethod_30(memoryStream);
			}
			finally
			{
				if (memoryStream != null)
				{
					ZlibBaseStream.smethod_25(memoryStream);
				}
			}
			return array2;
		}

		// Token: 0x0600150A RID: 5386 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_0(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x0600150B RID: 5387 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_1(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x0600150C RID: 5388 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_2(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x0600150D RID: 5389 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_3(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x0600150E RID: 5390 RVA: 0x00012D8E File Offset: 0x00010F8E
		static void smethod_4(Stream stream_0)
		{
			stream_0.Flush();
		}

		// Token: 0x0600150F RID: 5391 RVA: 0x00012D75 File Offset: 0x00010F75
		static byte[] smethod_5(int int_0)
		{
			return BitConverter.GetBytes(int_0);
		}

		// Token: 0x06001510 RID: 5392 RVA: 0x0000C3EE File Offset: 0x0000A5EE
		static void smethod_6(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Array.Copy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x06001511 RID: 5393 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_7(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06001512 RID: 5394 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_8(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x06001513 RID: 5395 RVA: 0x00013E9E File Offset: 0x0001209E
		static int smethod_9(byte[] byte_0, int int_0)
		{
			return BitConverter.ToInt32(byte_0, int_0);
		}

		// Token: 0x06001514 RID: 5396 RVA: 0x00012E9A File Offset: 0x0001109A
		static void smethod_10(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x06001515 RID: 5397 RVA: 0x000109B6 File Offset: 0x0000EBB6
		static NotImplementedException smethod_11()
		{
			return new NotImplementedException();
		}

		// Token: 0x06001516 RID: 5398 RVA: 0x00012D9F File Offset: 0x00010F9F
		static void smethod_12(Stream stream_0, long long_0)
		{
			stream_0.SetLength(long_0);
		}

		// Token: 0x06001517 RID: 5399 RVA: 0x0000DF79 File Offset: 0x0000C179
		static string smethod_13(Encoding encoding_0, byte[] byte_0, int int_0, int int_1)
		{
			return encoding_0.GetString(byte_0, int_0, int_1);
		}

		// Token: 0x06001518 RID: 5400 RVA: 0x00012837 File Offset: 0x00010A37
		static bool smethod_14(Stream stream_0)
		{
			return stream_0.CanRead;
		}

		// Token: 0x06001519 RID: 5401 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_15(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x0600151A RID: 5402 RVA: 0x0000F870 File Offset: 0x0000DA70
		static ArgumentOutOfRangeException smethod_16(string string_0)
		{
			return new ArgumentOutOfRangeException(string_0);
		}

		// Token: 0x0600151B RID: 5403 RVA: 0x00015500 File Offset: 0x00013700
		static int smethod_17(Array array_0, int int_0)
		{
			return array_0.GetLowerBound(int_0);
		}

		// Token: 0x0600151C RID: 5404 RVA: 0x00010011 File Offset: 0x0000E211
		static int smethod_18(Array array_0, int int_0)
		{
			return array_0.GetLength(int_0);
		}

		// Token: 0x0600151D RID: 5405 RVA: 0x0000CD96 File Offset: 0x0000AF96
		static string smethod_19(string string_0, object object_0, object object_1, object object_2)
		{
			return string.Format(string_0, object_0, object_1, object_2);
		}

		// Token: 0x0600151E RID: 5406 RVA: 0x00012BF7 File Offset: 0x00010DF7
		static bool smethod_20(Stream stream_0)
		{
			return stream_0.CanSeek;
		}

		// Token: 0x0600151F RID: 5407 RVA: 0x00012D86 File Offset: 0x00010F86
		static bool smethod_21(Stream stream_0)
		{
			return stream_0.CanWrite;
		}

		// Token: 0x06001520 RID: 5408 RVA: 0x00012BE5 File Offset: 0x00010DE5
		static long smethod_22(Stream stream_0)
		{
			return stream_0.Length;
		}

		// Token: 0x06001521 RID: 5409 RVA: 0x0000DB1A File Offset: 0x0000BD1A
		static Encoding smethod_23()
		{
			return Encoding.UTF8;
		}

		// Token: 0x06001522 RID: 5410 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_24(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x06001523 RID: 5411 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_25(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06001524 RID: 5412 RVA: 0x0000C8A7 File Offset: 0x0000AAA7
		static MemoryStream smethod_26()
		{
			return new MemoryStream();
		}

		// Token: 0x06001525 RID: 5413 RVA: 0x00012BED File Offset: 0x00010DED
		static long smethod_27(Stream stream_0, long long_0, SeekOrigin seekOrigin_0)
		{
			return stream_0.Seek(long_0, seekOrigin_0);
		}

		// Token: 0x06001526 RID: 5414 RVA: 0x00015509 File Offset: 0x00013709
		static StreamReader smethod_28(Stream stream_0, Encoding encoding_0)
		{
			return new StreamReader(stream_0, encoding_0);
		}

		// Token: 0x06001527 RID: 5415 RVA: 0x0000DF57 File Offset: 0x0000C157
		static string smethod_29(TextReader textReader_0)
		{
			return textReader_0.ReadToEnd();
		}

		// Token: 0x06001528 RID: 5416 RVA: 0x0000C8C1 File Offset: 0x0000AAC1
		static byte[] smethod_30(MemoryStream memoryStream_0)
		{
			return memoryStream_0.ToArray();
		}

		// Token: 0x04000846 RID: 2118
		protected internal ZlibCodec _z;

		// Token: 0x04000847 RID: 2119
		protected internal ZlibBaseStream.StreamMode _streamMode = ZlibBaseStream.StreamMode.Undefined;

		// Token: 0x04000848 RID: 2120
		protected internal FlushType _flushMode;

		// Token: 0x04000849 RID: 2121
		protected internal ZlibStreamFlavor _flavor;

		// Token: 0x0400084A RID: 2122
		protected internal CompressionMode _compressionMode;

		// Token: 0x0400084B RID: 2123
		protected internal CompressionLevel _level;

		// Token: 0x0400084C RID: 2124
		protected internal bool _leaveOpen;

		// Token: 0x0400084D RID: 2125
		protected internal byte[] _workingBuffer;

		// Token: 0x0400084E RID: 2126
		protected internal int _bufferSize = 16384;

		// Token: 0x0400084F RID: 2127
		protected internal byte[] _buf1 = new byte[1];

		// Token: 0x04000850 RID: 2128
		protected internal Stream _stream;

		// Token: 0x04000851 RID: 2129
		protected internal CompressionStrategy Strategy;

		// Token: 0x04000852 RID: 2130
		private CRC32 crc;

		// Token: 0x04000853 RID: 2131
		protected internal string _GzipFileName;

		// Token: 0x04000854 RID: 2132
		protected internal string _GzipComment;

		// Token: 0x04000855 RID: 2133
		protected internal DateTime _GzipMtime;

		// Token: 0x04000856 RID: 2134
		protected internal int _gzipHeaderByteCount;

		// Token: 0x04000857 RID: 2135
		private bool nomoreinput;

		// Token: 0x02000154 RID: 340
		internal enum StreamMode
		{
			// Token: 0x04000859 RID: 2137
			Writer,
			// Token: 0x0400085A RID: 2138
			Reader,
			// Token: 0x0400085B RID: 2139
			Undefined
		}
	}
}
