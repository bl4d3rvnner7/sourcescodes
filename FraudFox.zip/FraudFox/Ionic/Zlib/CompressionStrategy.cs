﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zlib
{
	// Token: 0x0200014B RID: 331
	[ComVisible(true)]
	public enum CompressionStrategy
	{
		// Token: 0x04000826 RID: 2086
		Default,
		// Token: 0x04000827 RID: 2087
		Filtered,
		// Token: 0x04000828 RID: 2088
		HuffmanOnly
	}
}
