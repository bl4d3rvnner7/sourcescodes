﻿using System;
using System.IO;
using System.Text;

namespace Ionic.Zlib
{
	// Token: 0x0200014E RID: 334
	internal class SharedUtils
	{
		// Token: 0x060014E1 RID: 5345 RVA: 0x000153BA File Offset: 0x000135BA
		public static int URShift(int number, int bits)
		{
			return (int)((uint)number >> bits);
		}

		// Token: 0x060014E2 RID: 5346 RVA: 0x0006E2C4 File Offset: 0x0006C4C4
		public static int ReadInput(TextReader sourceTextReader, byte[] target, int start, int count)
		{
			if (target.Length == 0)
			{
				return 0;
			}
			char[] array = new char[target.Length];
			int num = SharedUtils.smethod_0(sourceTextReader, array, start, count);
			if (num == 0)
			{
				return -1;
			}
			for (int i = start; i < start + num; i++)
			{
				target[i] = (byte)array[i];
			}
			return num;
		}

		// Token: 0x060014E3 RID: 5347 RVA: 0x000153C2 File Offset: 0x000135C2
		internal static byte[] ToByteArray(string sourceString)
		{
			return SharedUtils.smethod_2(SharedUtils.smethod_1(), sourceString);
		}

		// Token: 0x060014E4 RID: 5348 RVA: 0x000153CF File Offset: 0x000135CF
		internal static char[] ToCharArray(byte[] byteArray)
		{
			return SharedUtils.smethod_3(SharedUtils.smethod_1(), byteArray);
		}

		// Token: 0x060014E6 RID: 5350 RVA: 0x000153DC File Offset: 0x000135DC
		static int smethod_0(TextReader textReader_0, char[] char_0, int int_0, int int_1)
		{
			return textReader_0.Read(char_0, int_0, int_1);
		}

		// Token: 0x060014E7 RID: 5351 RVA: 0x0000DB1A File Offset: 0x0000BD1A
		static Encoding smethod_1()
		{
			return Encoding.UTF8;
		}

		// Token: 0x060014E8 RID: 5352 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_2(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x060014E9 RID: 5353 RVA: 0x000153E7 File Offset: 0x000135E7
		static char[] smethod_3(Encoding encoding_0, byte[] byte_0)
		{
			return encoding_0.GetChars(byte_0);
		}
	}
}
