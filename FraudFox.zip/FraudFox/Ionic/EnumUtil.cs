﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Reflection;

namespace Ionic
{
	// Token: 0x020000FE RID: 254
	internal sealed class EnumUtil
	{
		// Token: 0x06000F40 RID: 3904 RVA: 0x0000C6A8 File Offset: 0x0000A8A8
		private EnumUtil()
		{
		}

		// Token: 0x06000F41 RID: 3905 RVA: 0x00056170 File Offset: 0x00054370
		internal static string GetDescription(Enum value)
		{
			FieldInfo fieldInfo = EnumUtil.smethod_2(EnumUtil.smethod_0(value), EnumUtil.smethod_1(value));
			DescriptionAttribute[] array = (DescriptionAttribute[])EnumUtil.smethod_4(fieldInfo, EnumUtil.smethod_3(typeof(DescriptionAttribute).TypeHandle), false);
			if (array.Length > 0)
			{
				return EnumUtil.smethod_5(array[0]);
			}
			return EnumUtil.smethod_1(value);
		}

		// Token: 0x06000F42 RID: 3906 RVA: 0x000130D9 File Offset: 0x000112D9
		internal static object Parse(Type enumType, string stringRepresentation)
		{
			return EnumUtil.Parse(enumType, stringRepresentation, false);
		}

		// Token: 0x06000F43 RID: 3907 RVA: 0x000561C0 File Offset: 0x000543C0
		internal static object Parse(Type enumType, string stringRepresentation, bool ignoreCase)
		{
			if (ignoreCase)
			{
				stringRepresentation = EnumUtil.smethod_6(stringRepresentation);
			}
			IEnumerator enumerator = EnumUtil.smethod_8(EnumUtil.smethod_7(enumType));
			try
			{
				while (EnumUtil.smethod_11(enumerator))
				{
					Enum @enum = (Enum)EnumUtil.smethod_9(enumerator);
					string text = EnumUtil.GetDescription(@enum);
					if (ignoreCase)
					{
						text = EnumUtil.smethod_6(text);
					}
					if (EnumUtil.smethod_10(text, stringRepresentation))
					{
						return @enum;
					}
				}
				goto IL_0064;
			}
			finally
			{
				IDisposable disposable = enumerator as IDisposable;
				if (disposable != null)
				{
					EnumUtil.smethod_12(disposable);
				}
			}
			object obj;
			return obj;
			IL_0064:
			return EnumUtil.smethod_13(enumType, stringRepresentation, ignoreCase);
		}

		// Token: 0x06000F44 RID: 3908 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_0(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06000F45 RID: 3909 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_1(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06000F46 RID: 3910 RVA: 0x000130E3 File Offset: 0x000112E3
		static FieldInfo smethod_2(Type type_0, string string_0)
		{
			return type_0.GetField(string_0);
		}

		// Token: 0x06000F47 RID: 3911 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_3(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06000F48 RID: 3912 RVA: 0x000130EC File Offset: 0x000112EC
		static object[] smethod_4(MemberInfo memberInfo_0, Type type_0, bool bool_0)
		{
			return memberInfo_0.GetCustomAttributes(type_0, bool_0);
		}

		// Token: 0x06000F49 RID: 3913 RVA: 0x000130F6 File Offset: 0x000112F6
		static string smethod_5(DescriptionAttribute descriptionAttribute_0)
		{
			return descriptionAttribute_0.Description;
		}

		// Token: 0x06000F4A RID: 3914 RVA: 0x0000FD9A File Offset: 0x0000DF9A
		static string smethod_6(string string_0)
		{
			return string_0.ToLower();
		}

		// Token: 0x06000F4B RID: 3915 RVA: 0x000130FE File Offset: 0x000112FE
		static Array smethod_7(Type type_0)
		{
			return Enum.GetValues(type_0);
		}

		// Token: 0x06000F4C RID: 3916 RVA: 0x00013106 File Offset: 0x00011306
		static IEnumerator smethod_8(Array array_0)
		{
			return array_0.GetEnumerator();
		}

		// Token: 0x06000F4D RID: 3917 RVA: 0x0000D8E2 File Offset: 0x0000BAE2
		static object smethod_9(IEnumerator ienumerator_0)
		{
			return ienumerator_0.Current;
		}

		// Token: 0x06000F4E RID: 3918 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_10(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06000F4F RID: 3919 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_11(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06000F50 RID: 3920 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_12(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06000F51 RID: 3921 RVA: 0x00013078 File Offset: 0x00011278
		static object smethod_13(Type type_0, string string_0, bool bool_0)
		{
			return Enum.Parse(type_0, string_0, bool_0);
		}
	}
}
