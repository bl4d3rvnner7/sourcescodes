﻿using System;

namespace Ionic
{
	// Token: 0x020000F1 RID: 241
	internal enum LogicalConjunction
	{
		// Token: 0x040004F3 RID: 1267
		NONE,
		// Token: 0x040004F4 RID: 1268
		AND,
		// Token: 0x040004F5 RID: 1269
		OR,
		// Token: 0x040004F6 RID: 1270
		XOR
	}
}
