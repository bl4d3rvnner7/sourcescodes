﻿using System;
using System.Runtime.CompilerServices;

namespace Ionic.BZip2
{
	// Token: 0x02000136 RID: 310
	internal static class Rand
	{
		// Token: 0x060013D9 RID: 5081 RVA: 0x00014D08 File Offset: 0x00012F08
		internal static int Rnums(int i)
		{
			return Rand.RNUMS[i];
		}

		// Token: 0x060013DA RID: 5082 RVA: 0x00014D11 File Offset: 0x00012F11
		// Note: this type is marked as 'beforefieldinit'.
		static Rand()
		{
			int[] array = new int[512];
			Rand.smethod_0(array, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x6000507-1).FieldHandle);
			Rand.RNUMS = array;
		}

		// Token: 0x060013DB RID: 5083 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_0(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x040006F7 RID: 1783
		private static int[] RNUMS;
	}
}
