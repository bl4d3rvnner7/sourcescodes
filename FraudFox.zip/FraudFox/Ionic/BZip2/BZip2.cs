﻿using System;

namespace Ionic.BZip2
{
	// Token: 0x02000130 RID: 304
	internal static class BZip2
	{
		// Token: 0x06001371 RID: 4977 RVA: 0x00066380 File Offset: 0x00064580
		internal static T[][] InitRectangularArray<T>(int d1, int d2)
		{
			T[][] array = new T[d1][];
			for (int i = 0; i < d1; i++)
			{
				array[i] = new T[d2];
			}
			return array;
		}

		// Token: 0x040006BA RID: 1722
		public static readonly int BlockSizeMultiple = 100000;

		// Token: 0x040006BB RID: 1723
		public static readonly int MinBlockSize = 1;

		// Token: 0x040006BC RID: 1724
		public static readonly int MaxBlockSize = 9;

		// Token: 0x040006BD RID: 1725
		public static readonly int MaxAlphaSize = 258;

		// Token: 0x040006BE RID: 1726
		public static readonly int MaxCodeLength = 23;

		// Token: 0x040006BF RID: 1727
		public static readonly char RUNA = '\0';

		// Token: 0x040006C0 RID: 1728
		public static readonly char RUNB = '\u0001';

		// Token: 0x040006C1 RID: 1729
		public static readonly int NGroups = 6;

		// Token: 0x040006C2 RID: 1730
		public static readonly int G_SIZE = 50;

		// Token: 0x040006C3 RID: 1731
		public static readonly int N_ITERS = 4;

		// Token: 0x040006C4 RID: 1732
		public static readonly int MaxSelectors = 2 + 900000 / BZip2.G_SIZE;

		// Token: 0x040006C5 RID: 1733
		public static readonly int NUM_OVERSHOOT_BYTES = 20;

		// Token: 0x040006C6 RID: 1734
		internal static readonly int QSORT_STACK_SIZE = 1000;
	}
}
