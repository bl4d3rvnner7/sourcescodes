﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using Ionic.Crc;

namespace Ionic.BZip2
{
	// Token: 0x0200012D RID: 301
	[ComVisible(true)]
	public class BZip2InputStream : Stream
	{
		// Token: 0x06001339 RID: 4921 RVA: 0x00014A3A File Offset: 0x00012C3A
		public BZip2InputStream(Stream input)
			: this(input, false)
		{
		}

		// Token: 0x0600133A RID: 4922 RVA: 0x00014A44 File Offset: 0x00012C44
		public BZip2InputStream(Stream input, bool leaveOpen)
		{
			this.input = input;
			this._leaveOpen = leaveOpen;
			this.init();
		}

		// Token: 0x0600133B RID: 4923 RVA: 0x00064D68 File Offset: 0x00062F68
		public override int Read(byte[] buffer, int offset, int count)
		{
			if (offset < 0)
			{
				throw BZip2InputStream.smethod_1(BZip2InputStream.smethod_0(<Module>.smethod_26<string>(2913824434U), offset));
			}
			if (count < 0)
			{
				throw BZip2InputStream.smethod_1(BZip2InputStream.smethod_0(<Module>.smethod_24<string>(2599879292U), count));
			}
			if (offset + count > buffer.Length)
			{
				throw BZip2InputStream.smethod_1(BZip2InputStream.smethod_2(<Module>.smethod_23<string>(2278912408U), offset, count, buffer.Length));
			}
			if (this.input == null)
			{
				throw BZip2InputStream.smethod_3(<Module>.smethod_27<string>(2523489494U));
			}
			int num = offset + count;
			int num2 = offset;
			int num3;
			while (num2 < num && (num3 = BZip2InputStream.smethod_4(this)) >= 0)
			{
				buffer[num2++] = (byte)num3;
			}
			return num2 - offset;
		}

		// Token: 0x0600133C RID: 4924 RVA: 0x00064E20 File Offset: 0x00063020
		private void MakeMaps()
		{
			bool[] inUse = this.data.inUse;
			byte[] seqToUnseq = this.data.seqToUnseq;
			int num = 0;
			for (int i = 0; i < 256; i++)
			{
				if (inUse[i])
				{
					seqToUnseq[num++] = (byte)i;
				}
			}
			this.nInUse = num;
		}

		// Token: 0x0600133D RID: 4925 RVA: 0x00064E6C File Offset: 0x0006306C
		public override int ReadByte()
		{
			int num = this.currentChar;
			this.totalBytesRead += 1L;
			switch (this.currentState)
			{
			case BZip2InputStream.CState.EOF:
				return -1;
			case BZip2InputStream.CState.START_BLOCK:
				throw BZip2InputStream.smethod_3(<Module>.smethod_25<string>(1241550514U));
			case BZip2InputStream.CState.RAND_PART_A:
				throw BZip2InputStream.smethod_3(<Module>.smethod_24<string>(3643008100U));
			case BZip2InputStream.CState.RAND_PART_B:
				this.SetupRandPartB();
				break;
			case BZip2InputStream.CState.RAND_PART_C:
				this.SetupRandPartC();
				break;
			case BZip2InputStream.CState.NO_RAND_PART_A:
				throw BZip2InputStream.smethod_3(<Module>.smethod_24<string>(3643008100U));
			case BZip2InputStream.CState.NO_RAND_PART_B:
				this.SetupNoRandPartB();
				break;
			case BZip2InputStream.CState.NO_RAND_PART_C:
				this.SetupNoRandPartC();
				break;
			default:
				throw BZip2InputStream.smethod_3(<Module>.smethod_23<string>(53602009U));
			}
			return num;
		}

		// Token: 0x170002D9 RID: 729
		// (get) Token: 0x0600133E RID: 4926 RVA: 0x00014A7A File Offset: 0x00012C7A
		public override bool CanRead
		{
			get
			{
				if (this._disposed)
				{
					throw BZip2InputStream.smethod_5(<Module>.smethod_25<string>(1758180558U));
				}
				return BZip2InputStream.smethod_6(this.input);
			}
		}

		// Token: 0x170002DA RID: 730
		// (get) Token: 0x0600133F RID: 4927 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170002DB RID: 731
		// (get) Token: 0x06001340 RID: 4928 RVA: 0x00014A9F File Offset: 0x00012C9F
		public override bool CanWrite
		{
			get
			{
				if (this._disposed)
				{
					throw BZip2InputStream.smethod_5(<Module>.smethod_24<string>(851507984U));
				}
				return BZip2InputStream.smethod_7(this.input);
			}
		}

		// Token: 0x06001341 RID: 4929 RVA: 0x00014AC4 File Offset: 0x00012CC4
		public override void Flush()
		{
			if (this._disposed)
			{
				throw BZip2InputStream.smethod_5(<Module>.smethod_24<string>(851507984U));
			}
			BZip2InputStream.smethod_8(this.input);
		}

		// Token: 0x170002DC RID: 732
		// (get) Token: 0x06001342 RID: 4930 RVA: 0x00014AE9 File Offset: 0x00012CE9
		public override long Length
		{
			get
			{
				throw BZip2InputStream.smethod_9();
			}
		}

		// Token: 0x170002DD RID: 733
		// (get) Token: 0x06001343 RID: 4931 RVA: 0x00014AF0 File Offset: 0x00012CF0
		// (set) Token: 0x06001344 RID: 4932 RVA: 0x00014AE9 File Offset: 0x00012CE9
		public override long Position
		{
			get
			{
				return this.totalBytesRead;
			}
			set
			{
				throw BZip2InputStream.smethod_9();
			}
		}

		// Token: 0x06001345 RID: 4933 RVA: 0x00014AE9 File Offset: 0x00012CE9
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw BZip2InputStream.smethod_9();
		}

		// Token: 0x06001346 RID: 4934 RVA: 0x00014AE9 File Offset: 0x00012CE9
		public override void SetLength(long value)
		{
			throw BZip2InputStream.smethod_9();
		}

		// Token: 0x06001347 RID: 4935 RVA: 0x00014AE9 File Offset: 0x00012CE9
		public override void Write(byte[] buffer, int offset, int count)
		{
			throw BZip2InputStream.smethod_9();
		}

		// Token: 0x06001348 RID: 4936 RVA: 0x00064F24 File Offset: 0x00063124
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (!this._disposed)
				{
					if (disposing && this.input != null)
					{
						BZip2InputStream.smethod_10(this.input);
					}
					this._disposed = true;
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06001349 RID: 4937 RVA: 0x00064F70 File Offset: 0x00063170
		private void init()
		{
			if (this.input == null)
			{
				throw BZip2InputStream.smethod_3(<Module>.smethod_26<string>(2055946707U));
			}
			if (!BZip2InputStream.smethod_6(this.input))
			{
				throw BZip2InputStream.smethod_3(<Module>.smethod_27<string>(2890691498U));
			}
			this.CheckMagicChar('B', 0);
			this.CheckMagicChar('Z', 1);
			this.CheckMagicChar('h', 2);
			int num = BZip2InputStream.smethod_4(this.input);
			if (num < 49 || num > 57)
			{
				throw BZip2InputStream.smethod_3(BZip2InputStream.smethod_11(<Module>.smethod_26<string>(2075099495U), (char)num));
			}
			this.blockSize100k = num - 48;
			this.InitBlock();
			this.SetupBlock();
		}

		// Token: 0x0600134A RID: 4938 RVA: 0x00065018 File Offset: 0x00063218
		private void CheckMagicChar(char expected, int position)
		{
			int num = BZip2InputStream.smethod_4(this.input);
			if (num != (int)expected)
			{
				string text = BZip2InputStream.smethod_2(<Module>.smethod_25<string>(4124493960U), position, (int)expected, num);
				throw BZip2InputStream.smethod_3(text);
			}
		}

		// Token: 0x0600134B RID: 4939 RVA: 0x00065060 File Offset: 0x00063260
		private void InitBlock()
		{
			char c = this.bsGetUByte();
			char c2 = this.bsGetUByte();
			char c3 = this.bsGetUByte();
			char c4 = this.bsGetUByte();
			char c5 = this.bsGetUByte();
			char c6 = this.bsGetUByte();
			if (c == '\u0017' && c2 == 'r' && c3 == 'E' && c4 == '8' && c5 == 'P' && c6 == '\u0090')
			{
				this.complete();
				return;
			}
			if (c == '1')
			{
				if (c2 == 'A' && c3 == 'Y' && c4 == '&' && c5 == 'S' && c6 == 'Y')
				{
					this.storedBlockCRC = this.bsGetInt();
					this.blockRandomised = this.GetBits(1) == 1;
					if (this.data == null)
					{
						this.data = new BZip2InputStream.DecompressionState(this.blockSize100k);
					}
					this.getAndMoveToFrontDecode();
					this.crc.Reset();
					this.currentState = BZip2InputStream.CState.START_BLOCK;
					return;
				}
			}
			this.currentState = BZip2InputStream.CState.EOF;
			string text = BZip2InputStream.smethod_0(<Module>.smethod_24<string>(4034752969U), BZip2InputStream.smethod_12(this.input));
			throw BZip2InputStream.smethod_3(text);
		}

		// Token: 0x0600134C RID: 4940 RVA: 0x00065164 File Offset: 0x00063364
		private void EndBlock()
		{
			this.computedBlockCRC = (uint)this.crc.Crc32Result;
			if (this.storedBlockCRC != this.computedBlockCRC)
			{
				string text = BZip2InputStream.smethod_13(<Module>.smethod_26<string>(2856366070U), this.storedBlockCRC, this.computedBlockCRC);
				throw BZip2InputStream.smethod_3(text);
			}
			this.computedCombinedCRC = (this.computedCombinedCRC << 1) | (this.computedCombinedCRC >> 31);
			this.computedCombinedCRC ^= this.computedBlockCRC;
		}

		// Token: 0x0600134D RID: 4941 RVA: 0x000651E8 File Offset: 0x000633E8
		private void complete()
		{
			this.storedCombinedCRC = this.bsGetInt();
			this.currentState = BZip2InputStream.CState.EOF;
			this.data = null;
			if (this.storedCombinedCRC != this.computedCombinedCRC)
			{
				string text = BZip2InputStream.smethod_13(<Module>.smethod_25<string>(1291073177U), this.storedCombinedCRC, this.computedCombinedCRC);
				throw BZip2InputStream.smethod_3(text);
			}
		}

		// Token: 0x0600134E RID: 4942 RVA: 0x0006524C File Offset: 0x0006344C
		public override void Close()
		{
			Stream stream = this.input;
			if (stream != null)
			{
				try
				{
					if (!this._leaveOpen)
					{
						BZip2InputStream.smethod_10(stream);
					}
				}
				finally
				{
					this.data = null;
					this.input = null;
				}
			}
		}

		// Token: 0x0600134F RID: 4943 RVA: 0x00065294 File Offset: 0x00063494
		private int GetBits(int n)
		{
			int num = this.bsLive;
			int num2 = this.bsBuff;
			if (num < n)
			{
				do
				{
					int num3 = BZip2InputStream.smethod_4(this.input);
					if (num3 < 0)
					{
						goto IL_003D;
					}
					num2 = (num2 << 8) | num3;
					num += 8;
				}
				while (num < n);
				this.bsBuff = num2;
				goto IL_004D;
				IL_003D:
				throw BZip2InputStream.smethod_3(<Module>.smethod_27<string>(1672755940U));
			}
			IL_004D:
			this.bsLive = num - n;
			return (num2 >> num - n) & ((1 << n) - 1);
		}

		// Token: 0x06001350 RID: 4944 RVA: 0x00065308 File Offset: 0x00063508
		private bool bsGetBit()
		{
			int bits = this.GetBits(1);
			return bits != 0;
		}

		// Token: 0x06001351 RID: 4945 RVA: 0x00014AF8 File Offset: 0x00012CF8
		private char bsGetUByte()
		{
			return (char)this.GetBits(8);
		}

		// Token: 0x06001352 RID: 4946 RVA: 0x00014B02 File Offset: 0x00012D02
		private uint bsGetInt()
		{
			return (uint)((((((this.GetBits(8) << 8) | this.GetBits(8)) << 8) | this.GetBits(8)) << 8) | this.GetBits(8));
		}

		// Token: 0x06001353 RID: 4947 RVA: 0x00065324 File Offset: 0x00063524
		private static void hbCreateDecodeTables(int[] limit, int[] bbase, int[] perm, char[] length, int minLen, int maxLen, int alphaSize)
		{
			int i = minLen;
			int num = 0;
			while (i <= maxLen)
			{
				for (int j = 0; j < alphaSize; j++)
				{
					if ((int)length[j] == i)
					{
						perm[num++] = j;
					}
				}
				i++;
			}
			int num2 = BZip2.MaxCodeLength;
			while (--num2 > 0)
			{
				bbase[num2] = 0;
				limit[num2] = 0;
			}
			for (int k = 0; k < alphaSize; k++)
			{
				bbase[(int)(length[k] + '\u0001')]++;
			}
			int l = 1;
			int num3 = bbase[0];
			while (l < BZip2.MaxCodeLength)
			{
				num3 += bbase[l];
				bbase[l] = num3;
				l++;
			}
			int m = minLen;
			int num4 = 0;
			int num5 = bbase[m];
			while (m <= maxLen)
			{
				int num6 = bbase[m + 1];
				num4 += num6 - num5;
				num5 = num6;
				limit[m] = num4 - 1;
				num4 <<= 1;
				m++;
			}
			for (int n = minLen + 1; n <= maxLen; n++)
			{
				bbase[n] = (limit[n - 1] + 1 << 1) - bbase[n];
			}
		}

		// Token: 0x06001354 RID: 4948 RVA: 0x00065424 File Offset: 0x00063624
		private void recvDecodingTables()
		{
			BZip2InputStream.DecompressionState decompressionState = this.data;
			bool[] inUse = decompressionState.inUse;
			byte[] recvDecodingTables_pos = decompressionState.recvDecodingTables_pos;
			int num = 0;
			for (int i = 0; i < 16; i++)
			{
				if (this.bsGetBit())
				{
					num |= 1 << i;
				}
			}
			int num2 = 256;
			while (--num2 >= 0)
			{
				inUse[num2] = false;
			}
			for (int j = 0; j < 16; j++)
			{
				if ((num & (1 << j)) != 0)
				{
					int num3 = j << 4;
					for (int k = 0; k < 16; k++)
					{
						if (this.bsGetBit())
						{
							inUse[num3 + k] = true;
						}
					}
				}
			}
			this.MakeMaps();
			int num4 = this.nInUse + 2;
			int bits = this.GetBits(3);
			int bits2 = this.GetBits(15);
			for (int l = 0; l < bits2; l++)
			{
				int num5 = 0;
				while (this.bsGetBit())
				{
					num5++;
				}
				decompressionState.selectorMtf[l] = (byte)num5;
			}
			int num6 = bits;
			while (--num6 >= 0)
			{
				recvDecodingTables_pos[num6] = (byte)num6;
			}
			for (int m = 0; m < bits2; m++)
			{
				int n = (int)decompressionState.selectorMtf[m];
				byte b = recvDecodingTables_pos[n];
				while (n > 0)
				{
					recvDecodingTables_pos[n] = recvDecodingTables_pos[n - 1];
					n--;
				}
				recvDecodingTables_pos[0] = b;
				decompressionState.selector[m] = b;
			}
			char[][] temp_charArray2d = decompressionState.temp_charArray2d;
			for (int num7 = 0; num7 < bits; num7++)
			{
				int num8 = this.GetBits(5);
				char[] array = temp_charArray2d[num7];
				for (int num9 = 0; num9 < num4; num9++)
				{
					while (this.bsGetBit())
					{
						num8 += (this.bsGetBit() ? (-1) : 1);
					}
					array[num9] = (char)num8;
				}
			}
			this.createHuffmanDecodingTables(num4, bits);
		}

		// Token: 0x06001355 RID: 4949 RVA: 0x000655E4 File Offset: 0x000637E4
		private void createHuffmanDecodingTables(int alphaSize, int nGroups)
		{
			BZip2InputStream.DecompressionState decompressionState = this.data;
			char[][] temp_charArray2d = decompressionState.temp_charArray2d;
			for (int i = 0; i < nGroups; i++)
			{
				int num = 32;
				int num2 = 0;
				char[] array = temp_charArray2d[i];
				int num3 = alphaSize;
				while (--num3 >= 0)
				{
					char c = array[num3];
					if ((int)c > num2)
					{
						num2 = (int)c;
					}
					if ((int)c < num)
					{
						num = (int)c;
					}
				}
				BZip2InputStream.hbCreateDecodeTables(decompressionState.gLimit[i], decompressionState.gBase[i], decompressionState.gPerm[i], temp_charArray2d[i], num, num2, alphaSize);
				decompressionState.gMinlen[i] = num;
			}
		}

		// Token: 0x06001356 RID: 4950 RVA: 0x00065680 File Offset: 0x00063880
		private void getAndMoveToFrontDecode()
		{
			BZip2InputStream.DecompressionState decompressionState = this.data;
			this.origPtr = this.GetBits(24);
			if (this.origPtr < 0)
			{
				throw BZip2InputStream.smethod_3(<Module>.smethod_27<string>(1253160703U));
			}
			if (this.origPtr > 10 + BZip2.BlockSizeMultiple * this.blockSize100k)
			{
				throw BZip2InputStream.smethod_3(<Module>.smethod_24<string>(3505821094U));
			}
			this.recvDecodingTables();
			byte[] getAndMoveToFrontDecode_yy = decompressionState.getAndMoveToFrontDecode_yy;
			int num = this.blockSize100k * BZip2.BlockSizeMultiple;
			int num2 = 256;
			while (--num2 >= 0)
			{
				getAndMoveToFrontDecode_yy[num2] = (byte)num2;
				decompressionState.unzftab[num2] = 0;
			}
			int num3 = 0;
			int num4 = BZip2.G_SIZE - 1;
			int num5 = this.nInUse + 1;
			int num6 = this.getAndMoveToFrontDecode0(0);
			int num7 = this.bsBuff;
			int i = this.bsLive;
			int num8 = -1;
			int num9 = (int)(decompressionState.selector[0] & byte.MaxValue);
			int[] array = decompressionState.gBase[num9];
			int[] array2 = decompressionState.gLimit[num9];
			int[] array3 = decompressionState.gPerm[num9];
			int num10 = decompressionState.gMinlen[num9];
			while (num6 != num5)
			{
				if (num6 != (int)BZip2.RUNA)
				{
					if (num6 != (int)BZip2.RUNB)
					{
						if (++num8 < num)
						{
							byte b = getAndMoveToFrontDecode_yy[num6 - 1];
							decompressionState.unzftab[(int)(decompressionState.seqToUnseq[(int)b] & byte.MaxValue)]++;
							decompressionState.ll8[num8] = decompressionState.seqToUnseq[(int)b];
							if (num6 <= 16)
							{
								int j = num6 - 1;
								while (j > 0)
								{
									getAndMoveToFrontDecode_yy[j] = getAndMoveToFrontDecode_yy[--j];
								}
							}
							else
							{
								BZip2InputStream.smethod_14(getAndMoveToFrontDecode_yy, 0, getAndMoveToFrontDecode_yy, 1, num6 - 1);
							}
							getAndMoveToFrontDecode_yy[0] = b;
							if (num4 == 0)
							{
								num4 = BZip2.G_SIZE - 1;
								num9 = (int)(decompressionState.selector[++num3] & byte.MaxValue);
								array = decompressionState.gBase[num9];
								array2 = decompressionState.gLimit[num9];
								array3 = decompressionState.gPerm[num9];
								num10 = decompressionState.gMinlen[num9];
							}
							else
							{
								num4--;
							}
							int num11 = num10;
							while (i < num11)
							{
								int num12 = BZip2InputStream.smethod_4(this.input);
								if (num12 < 0)
								{
									throw BZip2InputStream.smethod_3(<Module>.smethod_25<string>(2225287939U));
								}
								num7 = (num7 << 8) | num12;
								i += 8;
							}
							int k = (num7 >> i - num11) & ((1 << num11) - 1);
							i -= num11;
							while (k > array2[num11])
							{
								num11++;
								while (i < 1)
								{
									int num13 = BZip2InputStream.smethod_4(this.input);
									if (num13 < 0)
									{
										throw BZip2InputStream.smethod_3(<Module>.smethod_24<string>(782914481U));
									}
									num7 = (num7 << 8) | num13;
									i += 8;
								}
								i--;
								k = (k << 1) | ((num7 >> i) & 1);
							}
							num6 = array3[k - array[num11]];
							continue;
						}
						throw BZip2InputStream.smethod_3(<Module>.smethod_25<string>(2503677751U));
					}
				}
				int num14 = -1;
				int num15 = 1;
				for (;;)
				{
					if (num6 == (int)BZip2.RUNA)
					{
						num14 += num15;
					}
					else
					{
						if (num6 != (int)BZip2.RUNB)
						{
							break;
						}
						num14 += num15 << 1;
					}
					if (num4 != 0)
					{
						num4--;
					}
					else
					{
						num4 = BZip2.G_SIZE - 1;
						num9 = (int)(decompressionState.selector[++num3] & byte.MaxValue);
						array = decompressionState.gBase[num9];
						array2 = decompressionState.gLimit[num9];
						array3 = decompressionState.gPerm[num9];
						num10 = decompressionState.gMinlen[num9];
					}
					int num16 = num10;
					while (i < num16)
					{
						int num17 = BZip2InputStream.smethod_4(this.input);
						if (num17 < 0)
						{
							goto IL_049C;
						}
						num7 = (num7 << 8) | num17;
						i += 8;
					}
					int l = (num7 >> i - num16) & ((1 << num16) - 1);
					i -= num16;
					while (l > array2[num16])
					{
						num16++;
						while (i < 1)
						{
							int num18 = BZip2InputStream.smethod_4(this.input);
							if (num18 < 0)
							{
								goto IL_048C;
							}
							num7 = (num7 << 8) | num18;
							i += 8;
						}
						i--;
						l = (l << 1) | ((num7 >> i) & 1);
					}
					num6 = array3[l - array[num16]];
					num15 <<= 1;
				}
				byte b2 = decompressionState.seqToUnseq[(int)getAndMoveToFrontDecode_yy[0]];
				decompressionState.unzftab[(int)(b2 & byte.MaxValue)] += num14 + 1;
				while (num14-- >= 0)
				{
					decompressionState.ll8[++num8] = b2;
				}
				if (num8 < num)
				{
					continue;
				}
				throw BZip2InputStream.smethod_3(<Module>.smethod_23<string>(2042861904U));
				IL_048C:
				throw BZip2InputStream.smethod_3(<Module>.smethod_26<string>(1657735892U));
				IL_049C:
				throw BZip2InputStream.smethod_3(<Module>.smethod_24<string>(782914481U));
			}
			this.last = num8;
			this.bsLive = i;
			this.bsBuff = num7;
		}

		// Token: 0x06001357 RID: 4951 RVA: 0x00065B64 File Offset: 0x00063D64
		private int getAndMoveToFrontDecode0(int groupNo)
		{
			BZip2InputStream.DecompressionState decompressionState = this.data;
			int num = (int)(decompressionState.selector[groupNo] & byte.MaxValue);
			int[] array = decompressionState.gLimit[num];
			int num2 = decompressionState.gMinlen[num];
			int i = this.GetBits(num2);
			int j = this.bsLive;
			int num3 = this.bsBuff;
			while (i > array[num2])
			{
				num2++;
				while (j < 1)
				{
					int num4 = BZip2InputStream.smethod_4(this.input);
					if (num4 < 0)
					{
						throw BZip2InputStream.smethod_3(<Module>.smethod_27<string>(1672755940U));
					}
					num3 = (num3 << 8) | num4;
					j += 8;
				}
				j--;
				i = (i << 1) | ((num3 >> j) & 1);
			}
			this.bsLive = j;
			this.bsBuff = num3;
			return decompressionState.gPerm[num][i - decompressionState.gBase[num][num2]];
		}

		// Token: 0x06001358 RID: 4952 RVA: 0x00065C44 File Offset: 0x00063E44
		private void SetupBlock()
		{
			if (this.data == null)
			{
				return;
			}
			BZip2InputStream.DecompressionState decompressionState = this.data;
			int[] array = decompressionState.initTT(this.last + 1);
			int i;
			for (i = 0; i <= 255; i++)
			{
				if (decompressionState.unzftab[i] < 0 || decompressionState.unzftab[i] > this.last)
				{
					throw BZip2InputStream.smethod_15(<Module>.smethod_25<string>(2851665016U));
				}
			}
			decompressionState.cftab[0] = 0;
			for (i = 1; i <= 256; i++)
			{
				decompressionState.cftab[i] = decompressionState.unzftab[i - 1];
			}
			for (i = 1; i <= 256; i++)
			{
				decompressionState.cftab[i] += decompressionState.cftab[i - 1];
			}
			for (i = 0; i <= 256; i++)
			{
				if (decompressionState.cftab[i] < 0 || decompressionState.cftab[i] > this.last + 1)
				{
					string text = BZip2InputStream.smethod_2(<Module>.smethod_27<string>(786943773U), i, decompressionState.cftab[i], this.last);
					throw BZip2InputStream.smethod_15(text);
				}
			}
			for (i = 1; i <= 256; i++)
			{
				if (decompressionState.cftab[i - 1] > decompressionState.cftab[i])
				{
					throw BZip2InputStream.smethod_15(<Module>.smethod_26<string>(953080469U));
				}
			}
			i = 0;
			int num = this.last;
			while (i <= num)
			{
				array[decompressionState.cftab[(int)(decompressionState.ll8[i] & byte.MaxValue)]++] = i;
				i++;
			}
			if (this.origPtr < 0 || this.origPtr >= array.Length)
			{
				throw BZip2InputStream.smethod_3(<Module>.smethod_23<string>(883171392U));
			}
			this.su_tPos = array[this.origPtr];
			this.su_count = 0;
			this.su_i2 = 0;
			this.su_ch2 = 256;
			if (this.blockRandomised)
			{
				this.su_rNToGo = 0;
				this.su_rTPos = 0;
				this.SetupRandPartA();
				return;
			}
			this.SetupNoRandPartA();
		}

		// Token: 0x06001359 RID: 4953 RVA: 0x00065E4C File Offset: 0x0006404C
		private void SetupRandPartA()
		{
			if (this.su_i2 <= this.last)
			{
				this.su_chPrev = this.su_ch2;
				int num = (int)(this.data.ll8[this.su_tPos] & byte.MaxValue);
				this.su_tPos = this.data.tt[this.su_tPos];
				if (this.su_rNToGo == 0)
				{
					this.su_rNToGo = Rand.Rnums(this.su_rTPos) - 1;
					if (++this.su_rTPos == 512)
					{
						this.su_rTPos = 0;
					}
				}
				else
				{
					this.su_rNToGo--;
				}
				num = (this.su_ch2 = num ^ ((this.su_rNToGo == 1) ? 1 : 0));
				this.su_i2++;
				this.currentChar = num;
				this.currentState = BZip2InputStream.CState.RAND_PART_B;
				this.crc.UpdateCRC((byte)num);
				return;
			}
			this.EndBlock();
			this.InitBlock();
			this.SetupBlock();
		}

		// Token: 0x0600135A RID: 4954 RVA: 0x00065F44 File Offset: 0x00064144
		private void SetupNoRandPartA()
		{
			if (this.su_i2 <= this.last)
			{
				this.su_chPrev = this.su_ch2;
				int num = (int)(this.data.ll8[this.su_tPos] & byte.MaxValue);
				this.su_ch2 = num;
				this.su_tPos = this.data.tt[this.su_tPos];
				this.su_i2++;
				this.currentChar = num;
				this.currentState = BZip2InputStream.CState.NO_RAND_PART_B;
				this.crc.UpdateCRC((byte)num);
				return;
			}
			this.currentState = BZip2InputStream.CState.NO_RAND_PART_A;
			this.EndBlock();
			this.InitBlock();
			this.SetupBlock();
		}

		// Token: 0x0600135B RID: 4955 RVA: 0x00065FE8 File Offset: 0x000641E8
		private void SetupRandPartB()
		{
			if (this.su_ch2 != this.su_chPrev)
			{
				this.currentState = BZip2InputStream.CState.RAND_PART_A;
				this.su_count = 1;
				this.SetupRandPartA();
				return;
			}
			if (++this.su_count >= 4)
			{
				this.su_z = (char)(this.data.ll8[this.su_tPos] & byte.MaxValue);
				this.su_tPos = this.data.tt[this.su_tPos];
				if (this.su_rNToGo == 0)
				{
					this.su_rNToGo = Rand.Rnums(this.su_rTPos) - 1;
					if (++this.su_rTPos == 512)
					{
						this.su_rTPos = 0;
					}
				}
				else
				{
					this.su_rNToGo--;
				}
				this.su_j2 = 0;
				this.currentState = BZip2InputStream.CState.RAND_PART_C;
				if (this.su_rNToGo == 1)
				{
					this.su_z ^= '\u0001';
				}
				this.SetupRandPartC();
				return;
			}
			this.currentState = BZip2InputStream.CState.RAND_PART_A;
			this.SetupRandPartA();
		}

		// Token: 0x0600135C RID: 4956 RVA: 0x000660EC File Offset: 0x000642EC
		private void SetupRandPartC()
		{
			if (this.su_j2 < (int)this.su_z)
			{
				this.currentChar = this.su_ch2;
				this.crc.UpdateCRC((byte)this.su_ch2);
				this.su_j2++;
				return;
			}
			this.currentState = BZip2InputStream.CState.RAND_PART_A;
			this.su_i2++;
			this.su_count = 0;
			this.SetupRandPartA();
		}

		// Token: 0x0600135D RID: 4957 RVA: 0x00066158 File Offset: 0x00064358
		private void SetupNoRandPartB()
		{
			if (this.su_ch2 != this.su_chPrev)
			{
				this.su_count = 1;
				this.SetupNoRandPartA();
				return;
			}
			if (++this.su_count < 4)
			{
				this.SetupNoRandPartA();
				return;
			}
			this.su_z = (char)(this.data.ll8[this.su_tPos] & byte.MaxValue);
			this.su_tPos = this.data.tt[this.su_tPos];
			this.su_j2 = 0;
			this.SetupNoRandPartC();
		}

		// Token: 0x0600135E RID: 4958 RVA: 0x000661E0 File Offset: 0x000643E0
		private void SetupNoRandPartC()
		{
			if (this.su_j2 < (int)this.su_z)
			{
				int num = this.su_ch2;
				this.currentChar = num;
				this.crc.UpdateCRC((byte)num);
				this.su_j2++;
				this.currentState = BZip2InputStream.CState.NO_RAND_PART_C;
				return;
			}
			this.su_i2++;
			this.su_count = 0;
			this.SetupNoRandPartA();
		}

		// Token: 0x0600135F RID: 4959 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_0(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x06001360 RID: 4960 RVA: 0x00014B29 File Offset: 0x00012D29
		static IndexOutOfRangeException smethod_1(string string_0)
		{
			return new IndexOutOfRangeException(string_0);
		}

		// Token: 0x06001361 RID: 4961 RVA: 0x0000CD96 File Offset: 0x0000AF96
		static string smethod_2(string string_0, object object_0, object object_1, object object_2)
		{
			return string.Format(string_0, object_0, object_1, object_2);
		}

		// Token: 0x06001362 RID: 4962 RVA: 0x00014B31 File Offset: 0x00012D31
		static IOException smethod_3(string string_0)
		{
			return new IOException(string_0);
		}

		// Token: 0x06001363 RID: 4963 RVA: 0x00014B39 File Offset: 0x00012D39
		static int smethod_4(Stream stream_0)
		{
			return stream_0.ReadByte();
		}

		// Token: 0x06001364 RID: 4964 RVA: 0x00014B41 File Offset: 0x00012D41
		static ObjectDisposedException smethod_5(string string_0)
		{
			return new ObjectDisposedException(string_0);
		}

		// Token: 0x06001365 RID: 4965 RVA: 0x00012837 File Offset: 0x00010A37
		static bool smethod_6(Stream stream_0)
		{
			return stream_0.CanRead;
		}

		// Token: 0x06001366 RID: 4966 RVA: 0x00012D86 File Offset: 0x00010F86
		static bool smethod_7(Stream stream_0)
		{
			return stream_0.CanWrite;
		}

		// Token: 0x06001367 RID: 4967 RVA: 0x00012D8E File Offset: 0x00010F8E
		static void smethod_8(Stream stream_0)
		{
			stream_0.Flush();
		}

		// Token: 0x06001368 RID: 4968 RVA: 0x000109B6 File Offset: 0x0000EBB6
		static NotImplementedException smethod_9()
		{
			return new NotImplementedException();
		}

		// Token: 0x06001369 RID: 4969 RVA: 0x00012E9A File Offset: 0x0001109A
		static void smethod_10(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x0600136A RID: 4970 RVA: 0x0000EE96 File Offset: 0x0000D096
		static string smethod_11(object object_0, object object_1)
		{
			return object_0 + object_1;
		}

		// Token: 0x0600136B RID: 4971 RVA: 0x00012846 File Offset: 0x00010A46
		static long smethod_12(Stream stream_0)
		{
			return stream_0.Position;
		}

		// Token: 0x0600136C RID: 4972 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_13(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x0600136D RID: 4973 RVA: 0x00013254 File Offset: 0x00011454
		static void smethod_14(Array array_0, int int_0, Array array_1, int int_1, int int_2)
		{
			Buffer.BlockCopy(array_0, int_0, array_1, int_1, int_2);
		}

		// Token: 0x0600136E RID: 4974 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_15(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x04000686 RID: 1670
		private bool _disposed;

		// Token: 0x04000687 RID: 1671
		private bool _leaveOpen;

		// Token: 0x04000688 RID: 1672
		private long totalBytesRead;

		// Token: 0x04000689 RID: 1673
		private int last;

		// Token: 0x0400068A RID: 1674
		private int origPtr;

		// Token: 0x0400068B RID: 1675
		private int blockSize100k;

		// Token: 0x0400068C RID: 1676
		private bool blockRandomised;

		// Token: 0x0400068D RID: 1677
		private int bsBuff;

		// Token: 0x0400068E RID: 1678
		private int bsLive;

		// Token: 0x0400068F RID: 1679
		private readonly CRC32 crc = new CRC32(true);

		// Token: 0x04000690 RID: 1680
		private int nInUse;

		// Token: 0x04000691 RID: 1681
		private Stream input;

		// Token: 0x04000692 RID: 1682
		private int currentChar = -1;

		// Token: 0x04000693 RID: 1683
		private BZip2InputStream.CState currentState = BZip2InputStream.CState.START_BLOCK;

		// Token: 0x04000694 RID: 1684
		private uint storedBlockCRC;

		// Token: 0x04000695 RID: 1685
		private uint storedCombinedCRC;

		// Token: 0x04000696 RID: 1686
		private uint computedBlockCRC;

		// Token: 0x04000697 RID: 1687
		private uint computedCombinedCRC;

		// Token: 0x04000698 RID: 1688
		private int su_count;

		// Token: 0x04000699 RID: 1689
		private int su_ch2;

		// Token: 0x0400069A RID: 1690
		private int su_chPrev;

		// Token: 0x0400069B RID: 1691
		private int su_i2;

		// Token: 0x0400069C RID: 1692
		private int su_j2;

		// Token: 0x0400069D RID: 1693
		private int su_rNToGo;

		// Token: 0x0400069E RID: 1694
		private int su_rTPos;

		// Token: 0x0400069F RID: 1695
		private int su_tPos;

		// Token: 0x040006A0 RID: 1696
		private char su_z;

		// Token: 0x040006A1 RID: 1697
		private BZip2InputStream.DecompressionState data;

		// Token: 0x0200012E RID: 302
		private enum CState
		{
			// Token: 0x040006A3 RID: 1699
			EOF,
			// Token: 0x040006A4 RID: 1700
			START_BLOCK,
			// Token: 0x040006A5 RID: 1701
			RAND_PART_A,
			// Token: 0x040006A6 RID: 1702
			RAND_PART_B,
			// Token: 0x040006A7 RID: 1703
			RAND_PART_C,
			// Token: 0x040006A8 RID: 1704
			NO_RAND_PART_A,
			// Token: 0x040006A9 RID: 1705
			NO_RAND_PART_B,
			// Token: 0x040006AA RID: 1706
			NO_RAND_PART_C
		}

		// Token: 0x0200012F RID: 303
		private sealed class DecompressionState
		{
			// Token: 0x0600136F RID: 4975 RVA: 0x00066248 File Offset: 0x00064448
			public DecompressionState(int blockSize100k)
			{
				this.unzftab = new int[256];
				this.gLimit = BZip2.InitRectangularArray<int>(BZip2.NGroups, BZip2.MaxAlphaSize);
				this.gBase = BZip2.InitRectangularArray<int>(BZip2.NGroups, BZip2.MaxAlphaSize);
				this.gPerm = BZip2.InitRectangularArray<int>(BZip2.NGroups, BZip2.MaxAlphaSize);
				this.gMinlen = new int[BZip2.NGroups];
				this.cftab = new int[257];
				this.getAndMoveToFrontDecode_yy = new byte[256];
				this.temp_charArray2d = BZip2.InitRectangularArray<char>(BZip2.NGroups, BZip2.MaxAlphaSize);
				this.recvDecodingTables_pos = new byte[BZip2.NGroups];
				this.ll8 = new byte[blockSize100k * BZip2.BlockSizeMultiple];
			}

			// Token: 0x06001370 RID: 4976 RVA: 0x00066354 File Offset: 0x00064554
			public int[] initTT(int length)
			{
				int[] array = this.tt;
				if (array == null || array.Length < length)
				{
					array = (this.tt = new int[length]);
				}
				return array;
			}

			// Token: 0x040006AB RID: 1707
			public readonly bool[] inUse = new bool[256];

			// Token: 0x040006AC RID: 1708
			public readonly byte[] seqToUnseq = new byte[256];

			// Token: 0x040006AD RID: 1709
			public readonly byte[] selector = new byte[BZip2.MaxSelectors];

			// Token: 0x040006AE RID: 1710
			public readonly byte[] selectorMtf = new byte[BZip2.MaxSelectors];

			// Token: 0x040006AF RID: 1711
			public readonly int[] unzftab;

			// Token: 0x040006B0 RID: 1712
			public readonly int[][] gLimit;

			// Token: 0x040006B1 RID: 1713
			public readonly int[][] gBase;

			// Token: 0x040006B2 RID: 1714
			public readonly int[][] gPerm;

			// Token: 0x040006B3 RID: 1715
			public readonly int[] gMinlen;

			// Token: 0x040006B4 RID: 1716
			public readonly int[] cftab;

			// Token: 0x040006B5 RID: 1717
			public readonly byte[] getAndMoveToFrontDecode_yy;

			// Token: 0x040006B6 RID: 1718
			public readonly char[][] temp_charArray2d;

			// Token: 0x040006B7 RID: 1719
			public readonly byte[] recvDecodingTables_pos;

			// Token: 0x040006B8 RID: 1720
			public int[] tt;

			// Token: 0x040006B9 RID: 1721
			public byte[] ll8;
		}
	}
}
