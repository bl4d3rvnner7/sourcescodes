﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;

namespace Ionic.BZip2
{
	// Token: 0x02000131 RID: 305
	[ComVisible(true)]
	public class BZip2OutputStream : Stream
	{
		// Token: 0x06001373 RID: 4979 RVA: 0x00014B49 File Offset: 0x00012D49
		public BZip2OutputStream(Stream output)
			: this(output, BZip2.MaxBlockSize, false)
		{
		}

		// Token: 0x06001374 RID: 4980 RVA: 0x00014B58 File Offset: 0x00012D58
		public BZip2OutputStream(Stream output, int blockSize)
			: this(output, blockSize, false)
		{
		}

		// Token: 0x06001375 RID: 4981 RVA: 0x00014B63 File Offset: 0x00012D63
		public BZip2OutputStream(Stream output, bool leaveOpen)
			: this(output, BZip2.MaxBlockSize, leaveOpen)
		{
		}

		// Token: 0x06001376 RID: 4982 RVA: 0x00066428 File Offset: 0x00064628
		public BZip2OutputStream(Stream output, int blockSize, bool leaveOpen)
		{
			if (blockSize < BZip2.MinBlockSize || blockSize > BZip2.MaxBlockSize)
			{
				string text = BZip2OutputStream.smethod_0(<Module>.smethod_26<string>(2419849679U), blockSize, BZip2.MinBlockSize, BZip2.MaxBlockSize);
				throw BZip2OutputStream.smethod_1(text, <Module>.smethod_26<string>(3877042495U));
			}
			this.output = output;
			if (!BZip2OutputStream.smethod_2(this.output))
			{
				throw BZip2OutputStream.smethod_1(<Module>.smethod_25<string>(923011122U), <Module>.smethod_27<string>(781172233U));
			}
			this.bw = new BitWriter(this.output);
			this.blockSize100k = blockSize;
			this.compressor = new BZip2Compressor(this.bw, blockSize);
			this.leaveOpen = leaveOpen;
			this.combinedCRC = 0U;
			this.EmitHeader();
		}

		// Token: 0x06001377 RID: 4983 RVA: 0x000664FC File Offset: 0x000646FC
		public override void Close()
		{
			if (this.output != null)
			{
				Stream stream = this.output;
				this.Finish();
				if (!this.leaveOpen)
				{
					BZip2OutputStream.smethod_3(stream);
				}
			}
		}

		// Token: 0x06001378 RID: 4984 RVA: 0x00014B72 File Offset: 0x00012D72
		public override void Flush()
		{
			if (this.output != null)
			{
				this.bw.Flush();
				BZip2OutputStream.smethod_4(this.output);
			}
		}

		// Token: 0x06001379 RID: 4985 RVA: 0x0006652C File Offset: 0x0006472C
		private void EmitHeader()
		{
			byte[] array = new byte[4];
			BZip2OutputStream.smethod_5(array, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x6000394-1).FieldHandle);
			byte[] array2 = array;
			array2[3] = (byte)(48 + this.blockSize100k);
			byte[] array3 = array2;
			BZip2OutputStream.smethod_6(this.output, array3, 0, array3.Length);
		}

		// Token: 0x0600137A RID: 4986 RVA: 0x0006656C File Offset: 0x0006476C
		private void EmitTrailer()
		{
			this.bw.WriteByte(23);
			this.bw.WriteByte(114);
			this.bw.WriteByte(69);
			this.bw.WriteByte(56);
			this.bw.WriteByte(80);
			this.bw.WriteByte(144);
			this.bw.WriteInt(this.combinedCRC);
			this.bw.FinishAndPad();
		}

		// Token: 0x0600137B RID: 4987 RVA: 0x000665E8 File Offset: 0x000647E8
		private void Finish()
		{
			try
			{
				int totalBytesWrittenOut = this.bw.TotalBytesWrittenOut;
				this.compressor.CompressAndWrite();
				this.combinedCRC = (this.combinedCRC << 1) | (this.combinedCRC >> 31);
				this.combinedCRC ^= this.compressor.Crc32;
				this.EmitTrailer();
			}
			finally
			{
				this.output = null;
				this.compressor = null;
				this.bw = null;
			}
		}

		// Token: 0x170002DE RID: 734
		// (get) Token: 0x0600137C RID: 4988 RVA: 0x00014B92 File Offset: 0x00012D92
		public int BlockSize
		{
			get
			{
				return this.blockSize100k;
			}
		}

		// Token: 0x0600137D RID: 4989 RVA: 0x0006666C File Offset: 0x0006486C
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (offset < 0)
			{
				throw BZip2OutputStream.smethod_8(BZip2OutputStream.smethod_7(<Module>.smethod_26<string>(2913824434U), offset));
			}
			if (count < 0)
			{
				throw BZip2OutputStream.smethod_8(BZip2OutputStream.smethod_7(<Module>.smethod_23<string>(3768724049U), count));
			}
			if (offset + count > buffer.Length)
			{
				throw BZip2OutputStream.smethod_8(BZip2OutputStream.smethod_0(<Module>.smethod_27<string>(2989706424U), offset, count, buffer.Length));
			}
			if (this.output == null)
			{
				throw BZip2OutputStream.smethod_9(<Module>.smethod_24<string>(797649423U));
			}
			if (count != 0)
			{
				int num = 0;
				int num2 = count;
				do
				{
					int num3 = this.compressor.Fill(buffer, offset, num2);
					if (num3 != num2)
					{
						int totalBytesWrittenOut = this.bw.TotalBytesWrittenOut;
						this.compressor.CompressAndWrite();
						this.combinedCRC = (this.combinedCRC << 1) | (this.combinedCRC >> 31);
						this.combinedCRC ^= this.compressor.Crc32;
						offset += num3;
					}
					num2 -= num3;
					num += num3;
				}
				while (num2 > 0);
				this.totalBytesWrittenIn += num;
				return;
			}
		}

		// Token: 0x170002DF RID: 735
		// (get) Token: 0x0600137E RID: 4990 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanRead
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170002E0 RID: 736
		// (get) Token: 0x0600137F RID: 4991 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170002E1 RID: 737
		// (get) Token: 0x06001380 RID: 4992 RVA: 0x00014B9A File Offset: 0x00012D9A
		public override bool CanWrite
		{
			get
			{
				if (this.output == null)
				{
					throw BZip2OutputStream.smethod_10(<Module>.smethod_25<string>(1758180558U));
				}
				return BZip2OutputStream.smethod_2(this.output);
			}
		}

		// Token: 0x170002E2 RID: 738
		// (get) Token: 0x06001381 RID: 4993 RVA: 0x00014BBF File Offset: 0x00012DBF
		public override long Length
		{
			get
			{
				throw BZip2OutputStream.smethod_11();
			}
		}

		// Token: 0x170002E3 RID: 739
		// (get) Token: 0x06001382 RID: 4994 RVA: 0x00014BC6 File Offset: 0x00012DC6
		// (set) Token: 0x06001383 RID: 4995 RVA: 0x00014BBF File Offset: 0x00012DBF
		public override long Position
		{
			get
			{
				return (long)this.totalBytesWrittenIn;
			}
			set
			{
				throw BZip2OutputStream.smethod_11();
			}
		}

		// Token: 0x06001384 RID: 4996 RVA: 0x00014BBF File Offset: 0x00012DBF
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw BZip2OutputStream.smethod_11();
		}

		// Token: 0x06001385 RID: 4997 RVA: 0x00014BBF File Offset: 0x00012DBF
		public override void SetLength(long value)
		{
			throw BZip2OutputStream.smethod_11();
		}

		// Token: 0x06001386 RID: 4998 RVA: 0x00014BBF File Offset: 0x00012DBF
		public override int Read(byte[] buffer, int offset, int count)
		{
			throw BZip2OutputStream.smethod_11();
		}

		// Token: 0x06001387 RID: 4999 RVA: 0x00066794 File Offset: 0x00064994
		[Conditional("Trace")]
		private void TraceOutput(BZip2OutputStream.TraceBits bits, string format, params object[] varParams)
		{
			if ((bits & this.desiredTrace) != BZip2OutputStream.TraceBits.None)
			{
				int num = BZip2OutputStream.smethod_13(BZip2OutputStream.smethod_12());
				BZip2OutputStream.smethod_14(num % 8 + ConsoleColor.Green);
				BZip2OutputStream.smethod_15(<Module>.smethod_26<string>(123931924U), num);
				BZip2OutputStream.smethod_16(format, varParams);
				BZip2OutputStream.smethod_17();
			}
		}

		// Token: 0x06001388 RID: 5000 RVA: 0x0000CD96 File Offset: 0x0000AF96
		static string smethod_0(string string_0, object object_0, object object_1, object object_2)
		{
			return string.Format(string_0, object_0, object_1, object_2);
		}

		// Token: 0x06001389 RID: 5001 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_1(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}

		// Token: 0x0600138A RID: 5002 RVA: 0x00012D86 File Offset: 0x00010F86
		static bool smethod_2(Stream stream_0)
		{
			return stream_0.CanWrite;
		}

		// Token: 0x0600138B RID: 5003 RVA: 0x00012E9A File Offset: 0x0001109A
		static void smethod_3(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x0600138C RID: 5004 RVA: 0x00012D8E File Offset: 0x00010F8E
		static void smethod_4(Stream stream_0)
		{
			stream_0.Flush();
		}

		// Token: 0x0600138D RID: 5005 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_5(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x0600138E RID: 5006 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_6(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x0600138F RID: 5007 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_7(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x06001390 RID: 5008 RVA: 0x00014B29 File Offset: 0x00012D29
		static IndexOutOfRangeException smethod_8(string string_0)
		{
			return new IndexOutOfRangeException(string_0);
		}

		// Token: 0x06001391 RID: 5009 RVA: 0x00014B31 File Offset: 0x00012D31
		static IOException smethod_9(string string_0)
		{
			return new IOException(string_0);
		}

		// Token: 0x06001392 RID: 5010 RVA: 0x00014B41 File Offset: 0x00012D41
		static ObjectDisposedException smethod_10(string string_0)
		{
			return new ObjectDisposedException(string_0);
		}

		// Token: 0x06001393 RID: 5011 RVA: 0x000109B6 File Offset: 0x0000EBB6
		static NotImplementedException smethod_11()
		{
			return new NotImplementedException();
		}

		// Token: 0x06001394 RID: 5012 RVA: 0x00013269 File Offset: 0x00011469
		static Thread smethod_12()
		{
			return Thread.CurrentThread;
		}

		// Token: 0x06001395 RID: 5013 RVA: 0x0000CF7A File Offset: 0x0000B17A
		static int smethod_13(object object_0)
		{
			return object_0.GetHashCode();
		}

		// Token: 0x06001396 RID: 5014 RVA: 0x00013270 File Offset: 0x00011470
		static void smethod_14(ConsoleColor consoleColor_0)
		{
			Console.ForegroundColor = consoleColor_0;
		}

		// Token: 0x06001397 RID: 5015 RVA: 0x00013278 File Offset: 0x00011478
		static void smethod_15(string string_0, object object_0)
		{
			Console.Write(string_0, object_0);
		}

		// Token: 0x06001398 RID: 5016 RVA: 0x00013082 File Offset: 0x00011282
		static void smethod_16(string string_0, object[] object_0)
		{
			Console.WriteLine(string_0, object_0);
		}

		// Token: 0x06001399 RID: 5017 RVA: 0x00013281 File Offset: 0x00011481
		static void smethod_17()
		{
			Console.ResetColor();
		}

		// Token: 0x040006C7 RID: 1735
		private int totalBytesWrittenIn;

		// Token: 0x040006C8 RID: 1736
		private bool leaveOpen;

		// Token: 0x040006C9 RID: 1737
		private BZip2Compressor compressor;

		// Token: 0x040006CA RID: 1738
		private uint combinedCRC;

		// Token: 0x040006CB RID: 1739
		private Stream output;

		// Token: 0x040006CC RID: 1740
		private BitWriter bw;

		// Token: 0x040006CD RID: 1741
		private int blockSize100k;

		// Token: 0x040006CE RID: 1742
		private BZip2OutputStream.TraceBits desiredTrace = BZip2OutputStream.TraceBits.Crc | BZip2OutputStream.TraceBits.Write;

		// Token: 0x02000132 RID: 306
		[Flags]
		private enum TraceBits : uint
		{
			// Token: 0x040006D0 RID: 1744
			None = 0U,
			// Token: 0x040006D1 RID: 1745
			Crc = 1U,
			// Token: 0x040006D2 RID: 1746
			Write = 2U,
			// Token: 0x040006D3 RID: 1747
			All = 4294967295U
		}
	}
}
