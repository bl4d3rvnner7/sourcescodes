﻿using System;
using System.IO;

namespace Ionic.BZip2
{
	// Token: 0x02000133 RID: 307
	internal class WorkItem
	{
		// Token: 0x170002E4 RID: 740
		// (get) Token: 0x0600139A RID: 5018 RVA: 0x00014BCF File Offset: 0x00012DCF
		// (set) Token: 0x0600139B RID: 5019 RVA: 0x00014BD7 File Offset: 0x00012DD7
		public BZip2Compressor Compressor { get; private set; }

		// Token: 0x0600139C RID: 5020 RVA: 0x00014BE0 File Offset: 0x00012DE0
		public WorkItem(int ix, int blockSize)
		{
			this.ms = WorkItem.smethod_0();
			this.bw = new BitWriter(this.ms);
			this.Compressor = new BZip2Compressor(this.bw, blockSize);
			this.index = ix;
		}

		// Token: 0x0600139D RID: 5021 RVA: 0x0000C8A7 File Offset: 0x0000AAA7
		static MemoryStream smethod_0()
		{
			return new MemoryStream();
		}

		// Token: 0x040006D4 RID: 1748
		public int index;

		// Token: 0x040006D5 RID: 1749
		public MemoryStream ms;

		// Token: 0x040006D6 RID: 1750
		public int ordinal;

		// Token: 0x040006D7 RID: 1751
		public BitWriter bw;
	}
}
