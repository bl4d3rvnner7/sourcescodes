﻿using System;
using System.IO;

namespace Ionic.BZip2
{
	// Token: 0x0200012A RID: 298
	internal class BitWriter
	{
		// Token: 0x06001305 RID: 4869 RVA: 0x0001495E File Offset: 0x00012B5E
		public BitWriter(Stream s)
		{
			this.output = s;
		}

		// Token: 0x170002D2 RID: 722
		// (get) Token: 0x06001306 RID: 4870 RVA: 0x0001496D File Offset: 0x00012B6D
		public byte RemainingBits
		{
			get
			{
				return (byte)((this.accumulator >> 32 - this.nAccumulatedBits) & 255U);
			}
		}

		// Token: 0x170002D3 RID: 723
		// (get) Token: 0x06001307 RID: 4871 RVA: 0x00014989 File Offset: 0x00012B89
		public int NumRemainingBits
		{
			get
			{
				return this.nAccumulatedBits;
			}
		}

		// Token: 0x170002D4 RID: 724
		// (get) Token: 0x06001308 RID: 4872 RVA: 0x00014991 File Offset: 0x00012B91
		public int TotalBytesWrittenOut
		{
			get
			{
				return this.totalBytesWrittenOut;
			}
		}

		// Token: 0x06001309 RID: 4873 RVA: 0x00062A64 File Offset: 0x00060C64
		public void Reset()
		{
			this.accumulator = 0U;
			this.nAccumulatedBits = 0;
			this.totalBytesWrittenOut = 0;
			BitWriter.smethod_0(this.output, 0L, SeekOrigin.Begin);
			BitWriter.smethod_1(this.output, 0L);
		}

		// Token: 0x0600130A RID: 4874 RVA: 0x00062AB0 File Offset: 0x00060CB0
		public void WriteBits(int nbits, uint value)
		{
			int i = this.nAccumulatedBits;
			uint num = this.accumulator;
			while (i >= 8)
			{
				BitWriter.smethod_2(this.output, (byte)((num >> 24) & 255U));
				this.totalBytesWrittenOut++;
				num <<= 8;
				i -= 8;
			}
			this.accumulator = num | (value << 32 - i - nbits);
			this.nAccumulatedBits = i + nbits;
		}

		// Token: 0x0600130B RID: 4875 RVA: 0x00014999 File Offset: 0x00012B99
		public void WriteByte(byte b)
		{
			this.WriteBits(8, (uint)b);
		}

		// Token: 0x0600130C RID: 4876 RVA: 0x00062B1C File Offset: 0x00060D1C
		public void WriteInt(uint u)
		{
			this.WriteBits(8, (u >> 24) & 255U);
			this.WriteBits(8, (u >> 16) & 255U);
			this.WriteBits(8, (u >> 8) & 255U);
			this.WriteBits(8, u & 255U);
		}

		// Token: 0x0600130D RID: 4877 RVA: 0x000149A3 File Offset: 0x00012BA3
		public void Flush()
		{
			this.WriteBits(0, 0U);
		}

		// Token: 0x0600130E RID: 4878 RVA: 0x00062B6C File Offset: 0x00060D6C
		public void FinishAndPad()
		{
			this.Flush();
			if (this.NumRemainingBits > 0)
			{
				byte b = (byte)((this.accumulator >> 24) & 255U);
				BitWriter.smethod_2(this.output, b);
				this.totalBytesWrittenOut++;
			}
		}

		// Token: 0x0600130F RID: 4879 RVA: 0x00012BED File Offset: 0x00010DED
		static long smethod_0(Stream stream_0, long long_0, SeekOrigin seekOrigin_0)
		{
			return stream_0.Seek(long_0, seekOrigin_0);
		}

		// Token: 0x06001310 RID: 4880 RVA: 0x00012D9F File Offset: 0x00010F9F
		static void smethod_1(Stream stream_0, long long_0)
		{
			stream_0.SetLength(long_0);
		}

		// Token: 0x06001311 RID: 4881 RVA: 0x000149AD File Offset: 0x00012BAD
		static void smethod_2(Stream stream_0, byte byte_0)
		{
			stream_0.WriteByte(byte_0);
		}

		// Token: 0x0400064D RID: 1613
		private uint accumulator;

		// Token: 0x0400064E RID: 1614
		private int nAccumulatedBits;

		// Token: 0x0400064F RID: 1615
		private Stream output;

		// Token: 0x04000650 RID: 1616
		private int totalBytesWrittenOut;
	}
}
