﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;

namespace Ionic.BZip2
{
	// Token: 0x02000134 RID: 308
	[ComVisible(true)]
	public class ParallelBZip2OutputStream : Stream
	{
		// Token: 0x0600139E RID: 5022 RVA: 0x00014C1D File Offset: 0x00012E1D
		public ParallelBZip2OutputStream(Stream output)
			: this(output, BZip2.MaxBlockSize, false)
		{
		}

		// Token: 0x0600139F RID: 5023 RVA: 0x00014C2C File Offset: 0x00012E2C
		public ParallelBZip2OutputStream(Stream output, int blockSize)
			: this(output, blockSize, false)
		{
		}

		// Token: 0x060013A0 RID: 5024 RVA: 0x00014C37 File Offset: 0x00012E37
		public ParallelBZip2OutputStream(Stream output, bool leaveOpen)
			: this(output, BZip2.MaxBlockSize, leaveOpen)
		{
		}

		// Token: 0x060013A1 RID: 5025 RVA: 0x000667E4 File Offset: 0x000649E4
		public ParallelBZip2OutputStream(Stream output, int blockSize, bool leaveOpen)
		{
			for (;;)
			{
				IL_010B:
				int num = -1068872812;
				for (;;)
				{
					switch (num ^ -1068872811)
					{
					case 0:
						if (!ParallelBZip2OutputStream.smethod_3(this.output))
						{
							goto Block_3;
						}
						goto IL_0072;
					case 1:
						num = ((blockSize < BZip2.MinBlockSize) ? (-1068872810) : (-1068872801));
						continue;
					case 3:
						goto IL_012C;
					case 4:
						this.MaxWorkers = 16;
						this.EmitHeader();
						num = -1068872809;
						continue;
					case 5:
						this.output = output;
						num = -1068872811;
						continue;
					case 6:
						goto IL_0072;
					case 7:
						goto IL_010B;
					case 8:
						this.leaveOpen = leaveOpen;
						this.combinedCRC = 0U;
						num = -1068872815;
						continue;
					case 9:
						this.blockSize100k = blockSize;
						num = -1068872803;
						continue;
					case 10:
						num = ((blockSize > BZip2.MaxBlockSize) ? (-1068872810) : (-1068872816));
						continue;
					}
					goto Block_4;
					IL_0072:
					this.bw = new BitWriter(this.output);
					num = -1068872804;
				}
			}
			Block_3:
			throw ParallelBZip2OutputStream.smethod_2(<Module>.smethod_24<string>(3153199844U), <Module>.smethod_24<string>(1987618972U));
			Block_4:
			return;
			IL_012C:
			string text = ParallelBZip2OutputStream.smethod_1(<Module>.smethod_27<string>(40996685U), blockSize, BZip2.MinBlockSize, BZip2.MaxBlockSize);
			throw ParallelBZip2OutputStream.smethod_2(text, <Module>.smethod_27<string>(3590016893U));
		}

		// Token: 0x060013A2 RID: 5026 RVA: 0x00066958 File Offset: 0x00064B58
		private void InitializePoolOfWorkItems()
		{
			this.toWrite = new Queue<int>();
			this.toFill = new Queue<int>();
			this.pool = new List<WorkItem>();
			int num = ParallelBZip2OutputStream.BufferPairsPerCore * ParallelBZip2OutputStream.smethod_4();
			num = ParallelBZip2OutputStream.smethod_5(num, this.MaxWorkers);
			for (int i = 0; i < num; i++)
			{
				this.pool.Add(new WorkItem(i, this.blockSize100k));
				this.toFill.Enqueue(i);
			}
			this.newlyCompressedBlob = ParallelBZip2OutputStream.smethod_6(false);
			this.currentlyFilling = -1;
			this.lastFilled = -1;
			this.lastWritten = -1;
			this.latestCompressed = -1;
		}

		// Token: 0x170002E5 RID: 741
		// (get) Token: 0x060013A3 RID: 5027 RVA: 0x00014C46 File Offset: 0x00012E46
		// (set) Token: 0x060013A4 RID: 5028 RVA: 0x00014C4E File Offset: 0x00012E4E
		public int MaxWorkers
		{
			get
			{
				return this._maxWorkers;
			}
			set
			{
				if (value < 4)
				{
					throw ParallelBZip2OutputStream.smethod_2(<Module>.smethod_27<string>(408198689U), <Module>.smethod_24<string>(2023696100U));
				}
				this._maxWorkers = value;
			}
		}

		// Token: 0x060013A5 RID: 5029 RVA: 0x000669F8 File Offset: 0x00064BF8
		public override void Close()
		{
			if (this.pendingException != null)
			{
				this.handlingException = true;
				Exception ex = this.pendingException;
				this.pendingException = null;
				throw ex;
			}
			if (this.handlingException)
			{
				return;
			}
			if (this.output != null)
			{
				Stream stream = this.output;
				try
				{
					this.FlushOutput(true);
				}
				finally
				{
					this.output = null;
					this.bw = null;
				}
				if (!this.leaveOpen)
				{
					ParallelBZip2OutputStream.smethod_7(stream);
				}
				return;
			}
		}

		// Token: 0x060013A6 RID: 5030 RVA: 0x00066A7C File Offset: 0x00064C7C
		private void FlushOutput(bool lastInput)
		{
			if (this.emitting)
			{
				return;
			}
			if (this.currentlyFilling >= 0)
			{
				WorkItem workItem = this.pool[this.currentlyFilling];
				this.CompressOne(workItem);
				this.currentlyFilling = -1;
			}
			if (!lastInput)
			{
				this.EmitPendingBuffers(false, false);
				return;
			}
			this.EmitPendingBuffers(true, false);
			this.EmitTrailer();
		}

		// Token: 0x060013A7 RID: 5031 RVA: 0x00014C75 File Offset: 0x00012E75
		public override void Flush()
		{
			if (this.output != null)
			{
				this.FlushOutput(false);
				this.bw.Flush();
				ParallelBZip2OutputStream.smethod_8(this.output);
			}
		}

		// Token: 0x060013A8 RID: 5032 RVA: 0x00066AD8 File Offset: 0x00064CD8
		private void EmitHeader()
		{
			byte[] array = new byte[4];
			ParallelBZip2OutputStream.smethod_9(array, fieldof(<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x60003b0-1).FieldHandle);
			byte[] array2 = array;
			array2[3] = (byte)(48 + this.blockSize100k);
			byte[] array3 = array2;
			ParallelBZip2OutputStream.smethod_10(this.output, array3, 0, array3.Length);
		}

		// Token: 0x060013A9 RID: 5033 RVA: 0x00066B18 File Offset: 0x00064D18
		private void EmitTrailer()
		{
			this.bw.WriteByte(23);
			this.bw.WriteByte(114);
			this.bw.WriteByte(69);
			this.bw.WriteByte(56);
			this.bw.WriteByte(80);
			this.bw.WriteByte(144);
			this.bw.WriteInt(this.combinedCRC);
			this.bw.FinishAndPad();
		}

		// Token: 0x170002E6 RID: 742
		// (get) Token: 0x060013AA RID: 5034 RVA: 0x00014C9C File Offset: 0x00012E9C
		public int BlockSize
		{
			get
			{
				return this.blockSize100k;
			}
		}

		// Token: 0x060013AB RID: 5035 RVA: 0x00066B94 File Offset: 0x00064D94
		public override void Write(byte[] buffer, int offset, int count)
		{
			bool flag = false;
			if (this.output == null)
			{
				throw ParallelBZip2OutputStream.smethod_11(<Module>.smethod_25<string>(615173437U));
			}
			if (this.pendingException != null)
			{
				this.handlingException = true;
				Exception ex = this.pendingException;
				this.pendingException = null;
				throw ex;
			}
			if (offset < 0)
			{
				throw ParallelBZip2OutputStream.smethod_13(ParallelBZip2OutputStream.smethod_12(<Module>.smethod_24<string>(4171939975U), offset));
			}
			if (count < 0)
			{
				throw ParallelBZip2OutputStream.smethod_13(ParallelBZip2OutputStream.smethod_12(<Module>.smethod_25<string>(3866178938U), count));
			}
			if (offset + count > buffer.Length)
			{
				throw ParallelBZip2OutputStream.smethod_13(ParallelBZip2OutputStream.smethod_1(<Module>.smethod_23<string>(2278912408U), offset, count, buffer.Length));
			}
			if (count == 0)
			{
				return;
			}
			if (!this.firstWriteDone)
			{
				this.InitializePoolOfWorkItems();
				this.firstWriteDone = true;
			}
			int num = 0;
			int num2 = count;
			for (;;)
			{
				this.EmitPendingBuffers(false, flag);
				flag = false;
				int num3;
				if (this.currentlyFilling >= 0)
				{
					num3 = this.currentlyFilling;
					goto IL_00CC;
				}
				if (this.toFill.Count != 0)
				{
					num3 = this.toFill.Dequeue();
					this.lastFilled++;
					goto IL_00CC;
				}
				flag = true;
				IL_0134:
				if (num2 > 0)
				{
					continue;
				}
				goto IL_01A8;
				IL_00CC:
				WorkItem workItem = this.pool[num3];
				workItem.ordinal = this.lastFilled;
				int num4 = workItem.Compressor.Fill(buffer, offset, num2);
				if (num4 != num2)
				{
					if (!ParallelBZip2OutputStream.smethod_14(new WaitCallback(this.CompressOne), workItem))
					{
						break;
					}
					this.currentlyFilling = -1;
					offset += num4;
				}
				else
				{
					this.currentlyFilling = num3;
				}
				num2 -= num4;
				num += num4;
				goto IL_0134;
			}
			throw ParallelBZip2OutputStream.smethod_15(<Module>.smethod_23<string>(128858509U));
			IL_01A8:
			this.totalBytesWrittenIn += (long)num;
		}

		// Token: 0x060013AC RID: 5036 RVA: 0x00066D58 File Offset: 0x00064F58
		private void EmitPendingBuffers(bool doAll, bool mustWait)
		{
			if (this.emitting)
			{
				goto IL_0017;
			}
			goto IL_02B9;
			int num;
			for (;;)
			{
				IL_0276:
				int num2;
				int num4;
				int num5;
				switch (num ^ 725564625)
				{
				case 0:
					goto IL_00C3;
				case 1:
					if (!mustWait)
					{
						num = 725564627;
						continue;
					}
					num2 = -1;
					goto IL_00A3;
				case 2:
					num2 = 0;
					goto IL_00A3;
				case 3:
					if (!doAll)
					{
						num = 725564624;
						continue;
					}
					num2 = 200;
					goto IL_00A3;
				case 4:
					num = ((!mustWait) ? 725564628 : 725564631);
					continue;
				case 5:
				{
					IL_004E:
					int num3 = -1;
					num = 725564626;
					continue;
				}
				case 6:
					ParallelBZip2OutputStream.smethod_16(this.newlyCompressedBlob);
					num = 725564628;
					continue;
				case 7:
					IL_0021:
					if (ParallelBZip2OutputStream.smethod_17(this.toWrite, num4))
					{
						num = 725564625;
						continue;
					}
					num5 = -1;
					break;
				case 8:
					return;
				case 9:
					goto IL_02B9;
				case 10:
					goto IL_0017;
				default:
					goto IL_00C3;
				}
				IL_0031:
				if (num5 >= 0)
				{
					goto IL_0021;
				}
				if (!doAll)
				{
					break;
				}
				if (this.lastWritten == this.latestCompressed)
				{
					break;
				}
				goto IL_004E;
				IL_00A3:
				num4 = num2;
				num5 = -1;
				num = 725564630;
				continue;
				IL_00C3:
				num5 = -1;
				try
				{
					if (this.toWrite.Count > 0)
					{
						num5 = this.toWrite.Dequeue();
					}
				}
				finally
				{
					ParallelBZip2OutputStream.smethod_18(this.toWrite);
				}
				if (num5 < 0)
				{
					goto IL_0031;
				}
				WorkItem workItem = this.pool[num5];
				if (workItem.ordinal != this.lastWritten + 1)
				{
					Queue<int> queue;
					ParallelBZip2OutputStream.smethod_19(queue = this.toWrite);
					try
					{
						this.toWrite.Enqueue(num5);
					}
					finally
					{
						ParallelBZip2OutputStream.smethod_18(queue);
					}
					int num3;
					if (num3 == num5)
					{
						ParallelBZip2OutputStream.smethod_16(this.newlyCompressedBlob);
						num3 = -1;
						goto IL_0031;
					}
					if (num3 == -1)
					{
						num3 = num5;
						goto IL_0031;
					}
					goto IL_0031;
				}
				else
				{
					int num3 = -1;
					BitWriter bitWriter = workItem.bw;
					bitWriter.Flush();
					MemoryStream ms = workItem.ms;
					ParallelBZip2OutputStream.smethod_20(ms, 0L, SeekOrigin.Begin);
					long num6 = 0L;
					byte[] array = new byte[1024];
					int num7;
					while ((num7 = ParallelBZip2OutputStream.smethod_21(ms, array, 0, array.Length)) > 0)
					{
						for (int i = 0; i < num7; i++)
						{
							this.bw.WriteByte(array[i]);
						}
						num6 += (long)num7;
					}
					if (bitWriter.NumRemainingBits > 0)
					{
						this.bw.WriteBits(bitWriter.NumRemainingBits, (uint)bitWriter.RemainingBits);
					}
					this.combinedCRC = (this.combinedCRC << 1) | (this.combinedCRC >> 31);
					this.combinedCRC ^= workItem.Compressor.Crc32;
					this.totalBytesWrittenOut += num6;
					bitWriter.Reset();
					this.lastWritten = workItem.ordinal;
					workItem.ordinal = -1;
					this.toFill.Enqueue(workItem.index);
					if (num4 == -1)
					{
						num4 = 0;
						goto IL_0031;
					}
					goto IL_0031;
				}
			}
			this.emitting = false;
			return;
			IL_0017:
			num = 725564633;
			goto IL_0276;
			IL_02B9:
			this.emitting = true;
			num = (doAll ? 725564631 : 725564629);
			goto IL_0276;
		}

		// Token: 0x060013AD RID: 5037 RVA: 0x00067054 File Offset: 0x00065254
		private void CompressOne(object wi)
		{
			WorkItem workItem = (WorkItem)wi;
			try
			{
				workItem.Compressor.CompressAndWrite();
				object obj;
				ParallelBZip2OutputStream.smethod_19(obj = this.latestLock);
				try
				{
					if (workItem.ordinal > this.latestCompressed)
					{
						this.latestCompressed = workItem.ordinal;
					}
				}
				finally
				{
					ParallelBZip2OutputStream.smethod_18(obj);
				}
				Queue<int> queue;
				ParallelBZip2OutputStream.smethod_19(queue = this.toWrite);
				try
				{
					this.toWrite.Enqueue(workItem.index);
				}
				finally
				{
					ParallelBZip2OutputStream.smethod_18(queue);
				}
				ParallelBZip2OutputStream.smethod_22(this.newlyCompressedBlob);
			}
			catch (Exception ex)
			{
				object obj2;
				ParallelBZip2OutputStream.smethod_19(obj2 = this.eLock);
				try
				{
					if (this.pendingException != null)
					{
						this.pendingException = ex;
					}
				}
				finally
				{
					ParallelBZip2OutputStream.smethod_18(obj2);
				}
			}
		}

		// Token: 0x170002E7 RID: 743
		// (get) Token: 0x060013AE RID: 5038 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanRead
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170002E8 RID: 744
		// (get) Token: 0x060013AF RID: 5039 RVA: 0x0000C17A File Offset: 0x0000A37A
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x170002E9 RID: 745
		// (get) Token: 0x060013B0 RID: 5040 RVA: 0x00014CA4 File Offset: 0x00012EA4
		public override bool CanWrite
		{
			get
			{
				if (this.output == null)
				{
					throw ParallelBZip2OutputStream.smethod_23(<Module>.smethod_26<string>(617906679U));
				}
				return ParallelBZip2OutputStream.smethod_3(this.output);
			}
		}

		// Token: 0x170002EA RID: 746
		// (get) Token: 0x060013B1 RID: 5041 RVA: 0x00014CC9 File Offset: 0x00012EC9
		public override long Length
		{
			get
			{
				throw ParallelBZip2OutputStream.smethod_24();
			}
		}

		// Token: 0x170002EB RID: 747
		// (get) Token: 0x060013B2 RID: 5042 RVA: 0x00014CD0 File Offset: 0x00012ED0
		// (set) Token: 0x060013B3 RID: 5043 RVA: 0x00014CC9 File Offset: 0x00012EC9
		public override long Position
		{
			get
			{
				return this.totalBytesWrittenIn;
			}
			set
			{
				throw ParallelBZip2OutputStream.smethod_24();
			}
		}

		// Token: 0x170002EC RID: 748
		// (get) Token: 0x060013B4 RID: 5044 RVA: 0x00014CD8 File Offset: 0x00012ED8
		public long BytesWrittenOut
		{
			get
			{
				return this.totalBytesWrittenOut;
			}
		}

		// Token: 0x060013B5 RID: 5045 RVA: 0x00014CC9 File Offset: 0x00012EC9
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw ParallelBZip2OutputStream.smethod_24();
		}

		// Token: 0x060013B6 RID: 5046 RVA: 0x00014CC9 File Offset: 0x00012EC9
		public override void SetLength(long value)
		{
			throw ParallelBZip2OutputStream.smethod_24();
		}

		// Token: 0x060013B7 RID: 5047 RVA: 0x00014CC9 File Offset: 0x00012EC9
		public override int Read(byte[] buffer, int offset, int count)
		{
			throw ParallelBZip2OutputStream.smethod_24();
		}

		// Token: 0x060013B8 RID: 5048 RVA: 0x0006713C File Offset: 0x0006533C
		[Conditional("Trace")]
		private void TraceOutput(ParallelBZip2OutputStream.TraceBits bits, string format, params object[] varParams)
		{
			if ((bits & this.desiredTrace) != ParallelBZip2OutputStream.TraceBits.None)
			{
				object obj;
				ParallelBZip2OutputStream.smethod_19(obj = this.outputLock);
				try
				{
					int num = ParallelBZip2OutputStream.smethod_26(ParallelBZip2OutputStream.smethod_25());
					ParallelBZip2OutputStream.smethod_27(num % 8 + ConsoleColor.Green);
					ParallelBZip2OutputStream.smethod_28(<Module>.smethod_26<string>(123931924U), num);
					ParallelBZip2OutputStream.smethod_29(format, varParams);
					ParallelBZip2OutputStream.smethod_30();
				}
				finally
				{
					ParallelBZip2OutputStream.smethod_18(obj);
				}
			}
		}

		// Token: 0x060013BA RID: 5050 RVA: 0x00013209 File Offset: 0x00011409
		static object smethod_0()
		{
			return new object();
		}

		// Token: 0x060013BB RID: 5051 RVA: 0x0000CD96 File Offset: 0x0000AF96
		static string smethod_1(string string_0, object object_0, object object_1, object object_2)
		{
			return string.Format(string_0, object_0, object_1, object_2);
		}

		// Token: 0x060013BC RID: 5052 RVA: 0x0000FF21 File Offset: 0x0000E121
		static ArgumentException smethod_2(string string_0, string string_1)
		{
			return new ArgumentException(string_0, string_1);
		}

		// Token: 0x060013BD RID: 5053 RVA: 0x00012D86 File Offset: 0x00010F86
		static bool smethod_3(Stream stream_0)
		{
			return stream_0.CanWrite;
		}

		// Token: 0x060013BE RID: 5054 RVA: 0x00014CE8 File Offset: 0x00012EE8
		static int smethod_4()
		{
			return Environment.ProcessorCount;
		}

		// Token: 0x060013BF RID: 5055 RVA: 0x0000F046 File Offset: 0x0000D246
		static int smethod_5(int int_0, int int_1)
		{
			return Math.Min(int_0, int_1);
		}

		// Token: 0x060013C0 RID: 5056 RVA: 0x00014CEF File Offset: 0x00012EEF
		static AutoResetEvent smethod_6(bool bool_0)
		{
			return new AutoResetEvent(bool_0);
		}

		// Token: 0x060013C1 RID: 5057 RVA: 0x00012E9A File Offset: 0x0001109A
		static void smethod_7(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x060013C2 RID: 5058 RVA: 0x00012D8E File Offset: 0x00010F8E
		static void smethod_8(Stream stream_0)
		{
			stream_0.Flush();
		}

		// Token: 0x060013C3 RID: 5059 RVA: 0x0000C4F4 File Offset: 0x0000A6F4
		static void smethod_9(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x060013C4 RID: 5060 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_10(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x060013C5 RID: 5061 RVA: 0x00014B31 File Offset: 0x00012D31
		static IOException smethod_11(string string_0)
		{
			return new IOException(string_0);
		}

		// Token: 0x060013C6 RID: 5062 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_12(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x060013C7 RID: 5063 RVA: 0x00014B29 File Offset: 0x00012D29
		static IndexOutOfRangeException smethod_13(string string_0)
		{
			return new IndexOutOfRangeException(string_0);
		}

		// Token: 0x060013C8 RID: 5064 RVA: 0x0000F95E File Offset: 0x0000DB5E
		static bool smethod_14(WaitCallback waitCallback_0, object object_0)
		{
			return ThreadPool.QueueUserWorkItem(waitCallback_0, object_0);
		}

		// Token: 0x060013C9 RID: 5065 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_15(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x060013CA RID: 5066 RVA: 0x00014CF7 File Offset: 0x00012EF7
		static bool smethod_16(WaitHandle waitHandle_0)
		{
			return waitHandle_0.WaitOne();
		}

		// Token: 0x060013CB RID: 5067 RVA: 0x00014CFF File Offset: 0x00012EFF
		static bool smethod_17(object object_0, int int_0)
		{
			return Monitor.TryEnter(object_0, int_0);
		}

		// Token: 0x060013CC RID: 5068 RVA: 0x0000DBEF File Offset: 0x0000BDEF
		static void smethod_18(object object_0)
		{
			Monitor.Exit(object_0);
		}

		// Token: 0x060013CD RID: 5069 RVA: 0x00013261 File Offset: 0x00011461
		static void smethod_19(object object_0)
		{
			Monitor.Enter(object_0);
		}

		// Token: 0x060013CE RID: 5070 RVA: 0x00012BED File Offset: 0x00010DED
		static long smethod_20(Stream stream_0, long long_0, SeekOrigin seekOrigin_0)
		{
			return stream_0.Seek(long_0, seekOrigin_0);
		}

		// Token: 0x060013CF RID: 5071 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_21(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x060013D0 RID: 5072 RVA: 0x0000C1B8 File Offset: 0x0000A3B8
		static bool smethod_22(EventWaitHandle eventWaitHandle_0)
		{
			return eventWaitHandle_0.Set();
		}

		// Token: 0x060013D1 RID: 5073 RVA: 0x00014B41 File Offset: 0x00012D41
		static ObjectDisposedException smethod_23(string string_0)
		{
			return new ObjectDisposedException(string_0);
		}

		// Token: 0x060013D2 RID: 5074 RVA: 0x000109B6 File Offset: 0x0000EBB6
		static NotImplementedException smethod_24()
		{
			return new NotImplementedException();
		}

		// Token: 0x060013D3 RID: 5075 RVA: 0x00013269 File Offset: 0x00011469
		static Thread smethod_25()
		{
			return Thread.CurrentThread;
		}

		// Token: 0x060013D4 RID: 5076 RVA: 0x0000CF7A File Offset: 0x0000B17A
		static int smethod_26(object object_0)
		{
			return object_0.GetHashCode();
		}

		// Token: 0x060013D5 RID: 5077 RVA: 0x00013270 File Offset: 0x00011470
		static void smethod_27(ConsoleColor consoleColor_0)
		{
			Console.ForegroundColor = consoleColor_0;
		}

		// Token: 0x060013D6 RID: 5078 RVA: 0x00013278 File Offset: 0x00011478
		static void smethod_28(string string_0, object object_0)
		{
			Console.Write(string_0, object_0);
		}

		// Token: 0x060013D7 RID: 5079 RVA: 0x00013082 File Offset: 0x00011282
		static void smethod_29(string string_0, object[] object_0)
		{
			Console.WriteLine(string_0, object_0);
		}

		// Token: 0x060013D8 RID: 5080 RVA: 0x00013281 File Offset: 0x00011481
		static void smethod_30()
		{
			Console.ResetColor();
		}

		// Token: 0x040006D9 RID: 1753
		private static readonly int BufferPairsPerCore = 4;

		// Token: 0x040006DA RID: 1754
		private int _maxWorkers;

		// Token: 0x040006DB RID: 1755
		private bool firstWriteDone;

		// Token: 0x040006DC RID: 1756
		private int lastFilled;

		// Token: 0x040006DD RID: 1757
		private int lastWritten;

		// Token: 0x040006DE RID: 1758
		private int latestCompressed;

		// Token: 0x040006DF RID: 1759
		private int currentlyFilling;

		// Token: 0x040006E0 RID: 1760
		private volatile Exception pendingException;

		// Token: 0x040006E1 RID: 1761
		private bool handlingException;

		// Token: 0x040006E2 RID: 1762
		private bool emitting;

		// Token: 0x040006E3 RID: 1763
		private Queue<int> toWrite;

		// Token: 0x040006E4 RID: 1764
		private Queue<int> toFill;

		// Token: 0x040006E5 RID: 1765
		private List<WorkItem> pool;

		// Token: 0x040006E6 RID: 1766
		private object latestLock = ParallelBZip2OutputStream.smethod_0();

		// Token: 0x040006E7 RID: 1767
		private object eLock = ParallelBZip2OutputStream.smethod_0();

		// Token: 0x040006E8 RID: 1768
		private object outputLock = ParallelBZip2OutputStream.smethod_0();

		// Token: 0x040006E9 RID: 1769
		private AutoResetEvent newlyCompressedBlob;

		// Token: 0x040006EA RID: 1770
		private long totalBytesWrittenIn;

		// Token: 0x040006EB RID: 1771
		private long totalBytesWrittenOut;

		// Token: 0x040006EC RID: 1772
		private bool leaveOpen;

		// Token: 0x040006ED RID: 1773
		private uint combinedCRC;

		// Token: 0x040006EE RID: 1774
		private Stream output;

		// Token: 0x040006EF RID: 1775
		private BitWriter bw;

		// Token: 0x040006F0 RID: 1776
		private int blockSize100k;

		// Token: 0x040006F1 RID: 1777
		private ParallelBZip2OutputStream.TraceBits desiredTrace = ParallelBZip2OutputStream.TraceBits.Crc | ParallelBZip2OutputStream.TraceBits.Write;

		// Token: 0x02000135 RID: 309
		[Flags]
		private enum TraceBits : uint
		{
			// Token: 0x040006F3 RID: 1779
			None = 0U,
			// Token: 0x040006F4 RID: 1780
			Crc = 1U,
			// Token: 0x040006F5 RID: 1781
			Write = 2U,
			// Token: 0x040006F6 RID: 1782
			All = 4294967295U
		}
	}
}
