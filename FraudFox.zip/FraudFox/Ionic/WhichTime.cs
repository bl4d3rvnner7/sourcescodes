﻿using System;

namespace Ionic
{
	// Token: 0x020000F2 RID: 242
	internal enum WhichTime
	{
		// Token: 0x040004F8 RID: 1272
		atime,
		// Token: 0x040004F9 RID: 1273
		mtime,
		// Token: 0x040004FA RID: 1274
		ctime
	}
}
