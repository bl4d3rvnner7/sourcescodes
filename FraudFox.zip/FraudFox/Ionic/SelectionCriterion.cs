﻿using System;
using System.Diagnostics;
using Ionic.Zip;

namespace Ionic
{
	// Token: 0x020000F4 RID: 244
	internal abstract class SelectionCriterion
	{
		// Token: 0x17000234 RID: 564
		// (get) Token: 0x06000EBA RID: 3770 RVA: 0x00012EAA File Offset: 0x000110AA
		// (set) Token: 0x06000EBB RID: 3771 RVA: 0x00012EB2 File Offset: 0x000110B2
		internal virtual bool Verbose { get; set; }

		// Token: 0x06000EBC RID: 3772
		internal abstract bool Evaluate(string filename);

		// Token: 0x06000EBD RID: 3773 RVA: 0x0000C600 File Offset: 0x0000A800
		[Conditional("SelectorTrace")]
		protected static void CriterionTrace(string format, params object[] args)
		{
		}

		// Token: 0x06000EBE RID: 3774
		internal abstract bool Evaluate(ZipEntry entry);
	}
}
