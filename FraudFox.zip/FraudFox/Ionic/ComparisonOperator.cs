﻿using System;
using System.ComponentModel;

namespace Ionic
{
	// Token: 0x020000F3 RID: 243
	internal enum ComparisonOperator
	{
		// Token: 0x040004FC RID: 1276
		[Description(">")]
		GreaterThan,
		// Token: 0x040004FD RID: 1277
		[Description(">=")]
		GreaterThanOrEqualTo,
		// Token: 0x040004FE RID: 1278
		[Description("<")]
		LesserThan,
		// Token: 0x040004FF RID: 1279
		[Description("<=")]
		LesserThanOrEqualTo,
		// Token: 0x04000500 RID: 1280
		[Description("=")]
		EqualTo,
		// Token: 0x04000501 RID: 1281
		[Description("!=")]
		NotEqualTo
	}
}
