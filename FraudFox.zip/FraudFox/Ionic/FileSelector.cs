﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using Ionic.Zip;

namespace Ionic
{
	// Token: 0x020000FB RID: 251
	[ComVisible(true)]
	public class FileSelector
	{
		// Token: 0x06000F13 RID: 3859 RVA: 0x00012F71 File Offset: 0x00011171
		public FileSelector(string selectionCriteria)
			: this(selectionCriteria, true)
		{
		}

		// Token: 0x06000F14 RID: 3860 RVA: 0x00012F7B File Offset: 0x0001117B
		public FileSelector(string selectionCriteria, bool traverseDirectoryReparsePoints)
		{
			if (!FileSelector.smethod_0(selectionCriteria))
			{
				this._Criterion = FileSelector._ParseCriterion(selectionCriteria);
			}
			this.TraverseReparsePoints = traverseDirectoryReparsePoints;
		}

		// Token: 0x17000239 RID: 569
		// (get) Token: 0x06000F15 RID: 3861 RVA: 0x00012F9E File Offset: 0x0001119E
		// (set) Token: 0x06000F16 RID: 3862 RVA: 0x00012FB5 File Offset: 0x000111B5
		public string SelectionCriteria
		{
			get
			{
				if (this._Criterion == null)
				{
					return null;
				}
				return FileSelector.smethod_1(this._Criterion);
			}
			set
			{
				if (value == null)
				{
					this._Criterion = null;
					return;
				}
				if (FileSelector.smethod_3(FileSelector.smethod_2(value), ""))
				{
					this._Criterion = null;
					return;
				}
				this._Criterion = FileSelector._ParseCriterion(value);
			}
		}

		// Token: 0x1700023A RID: 570
		// (get) Token: 0x06000F17 RID: 3863 RVA: 0x00012FE8 File Offset: 0x000111E8
		// (set) Token: 0x06000F18 RID: 3864 RVA: 0x00012FF0 File Offset: 0x000111F0
		public bool TraverseReparsePoints { get; set; }

		// Token: 0x06000F19 RID: 3865 RVA: 0x000551E0 File Offset: 0x000533E0
		private static string NormalizeCriteriaExpression(string source)
		{
			string[][] array = new string[][]
			{
				new string[]
				{
					<Module>.smethod_26<string>(3140496034U),
					<Module>.smethod_24<string>(217911061U)
				},
				new string[]
				{
					<Module>.smethod_26<string>(2445417005U),
					<Module>.smethod_27<string>(1367763066U)
				},
				new string[]
				{
					<Module>.smethod_23<string>(1229745497U),
					<Module>.smethod_27<string>(2807264009U)
				},
				new string[]
				{
					<Module>.smethod_25<string>(553547728U),
					<Module>.smethod_27<string>(2294425386U)
				},
				new string[]
				{
					<Module>.smethod_24<string>(1261039869U),
					<Module>.smethod_27<string>(2480912158U)
				},
				new string[]
				{
					<Module>.smethod_23<string>(824367868U),
					<Module>.smethod_25<string>(831937540U)
				},
				new string[]
				{
					<Module>.smethod_24<string>(3170986860U),
					<Module>.smethod_27<string>(1688343377U)
				},
				new string[]
				{
					<Module>.smethod_24<string>(149317558U),
					<Module>.smethod_26<string>(2311347489U)
				},
				new string[]
				{
					<Module>.smethod_27<string>(1361991526U),
					<Module>.smethod_24<string>(1775236802U)
				},
				new string[]
				{
					<Module>.smethod_26<string>(178228432U),
					<Module>.smethod_24<string>(1775236802U)
				},
				new string[]
				{
					<Module>.smethod_24<string>(3061240605U),
					<Module>.smethod_24<string>(1184318668U)
				}
			};
			string text = source;
			for (int i = 0; i < array.Length; i++)
			{
				string text2 = FileSelector.smethod_4(FileSelector.RegexAssertions.PrecededByEvenNumberOfSingleQuotes, array[i][0], FileSelector.RegexAssertions.FollowedByEvenNumberOfSingleQuotesAndLineEnd);
				text = FileSelector.smethod_5(text, text2, array[i][1]);
			}
			string text3 = FileSelector.smethod_6(<Module>.smethod_24<string>(3061240605U), FileSelector.RegexAssertions.FollowedByOddNumberOfSingleQuotesAndLineEnd);
			text = FileSelector.smethod_5(text, text3, <Module>.smethod_25<string>(3572883402U));
			text3 = FileSelector.smethod_6(<Module>.smethod_27<string>(2931232896U), FileSelector.RegexAssertions.FollowedByOddNumberOfSingleQuotesAndLineEnd);
			return FileSelector.smethod_5(text, text3, <Module>.smethod_27<string>(429557666U));
		}

		// Token: 0x06000F1A RID: 3866 RVA: 0x000554B0 File Offset: 0x000536B0
		private static SelectionCriterion _ParseCriterion(string s)
		{
			if (s == null)
			{
				return null;
			}
			s = FileSelector.NormalizeCriteriaExpression(s);
			if (FileSelector.smethod_7(s, <Module>.smethod_23<string>(4219134048U)) == -1)
			{
				s = FileSelector.smethod_6(<Module>.smethod_25<string>(2989458583U), s);
			}
			string[] array = FileSelector.smethod_8(FileSelector.smethod_2(s), new char[] { ' ', '\t' });
			if (array.Length < 3)
			{
				throw FileSelector.smethod_9(s);
			}
			SelectionCriterion selectionCriterion = null;
			Stack<FileSelector.ParseState> stack = new Stack<FileSelector.ParseState>();
			Stack<SelectionCriterion> stack2 = new Stack<SelectionCriterion>();
			stack.Push(FileSelector.ParseState.Start);
			int i = 0;
			while (i < array.Length)
			{
				string text = FileSelector.smethod_10(array[i]);
				string text2;
				if ((text2 = text) != null)
				{
					if (<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x60000c7-1 == null)
					{
						<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x60000c7-1 = new Dictionary<string, int>(16)
						{
							{
								<Module>.smethod_25<string>(2419247289U),
								0
							},
							{
								<Module>.smethod_27<string>(103205815U),
								1
							},
							{
								<Module>.smethod_27<string>(1022818785U),
								2
							},
							{
								<Module>.smethod_23<string>(2809822556U),
								3
							},
							{
								<Module>.smethod_27<string>(2393440312U),
								4
							},
							{
								<Module>.smethod_23<string>(1927616005U),
								5
							},
							{
								<Module>.smethod_24<string>(3224845421U),
								6
							},
							{
								<Module>.smethod_27<string>(1402841679U),
								7
							},
							{
								<Module>.smethod_27<string>(191646716U),
								8
							},
							{
								<Module>.smethod_24<string>(2937771183U),
								9
							},
							{
								<Module>.smethod_23<string>(3008244810U),
								10
							},
							{
								<Module>.smethod_25<string>(978813330U),
								11
							},
							{
								<Module>.smethod_25<string>(3923673345U),
								12
							},
							{
								<Module>.smethod_25<string>(3714880986U),
								13
							},
							{
								<Module>.smethod_25<string>(965527090U),
								14
							},
							{ "", 15 }
						};
					}
					int num;
					if (<PrivateImplementationDetails>{3A1D4CC9-483E-443F-A955-ACA90F021E0D}.$$method0x60000c7-1.TryGetValue(text2, out num))
					{
						FileSelector.ParseState parseState;
						switch (num)
						{
						case 0:
						case 1:
						case 2:
						{
							parseState = stack.Peek();
							if (parseState != FileSelector.ParseState.CriterionDone)
							{
								throw FileSelector.smethod_9(FileSelector.smethod_11(<Module>.smethod_23<string>(4219134048U), array, i, array.Length - i));
							}
							if (array.Length <= i + 3)
							{
								throw FileSelector.smethod_9(FileSelector.smethod_11(<Module>.smethod_27<string>(2931232896U), array, i, array.Length - i));
							}
							LogicalConjunction logicalConjunction = (LogicalConjunction)FileSelector.smethod_14(FileSelector.smethod_12(typeof(LogicalConjunction).TypeHandle), FileSelector.smethod_13(array[i]), true);
							selectionCriterion = new CompoundCriterion
							{
								Left = selectionCriterion,
								Right = null,
								Conjunction = logicalConjunction
							};
							stack.Push(parseState);
							stack.Push(FileSelector.ParseState.ConjunctionPending);
							stack2.Push(selectionCriterion);
							break;
						}
						case 3:
							parseState = stack.Peek();
							if (parseState != FileSelector.ParseState.Start)
							{
								if (parseState != FileSelector.ParseState.ConjunctionPending)
								{
									if (parseState != FileSelector.ParseState.OpenParen)
									{
										throw FileSelector.smethod_9(FileSelector.smethod_11(<Module>.smethod_27<string>(2931232896U), array, i, array.Length - i));
									}
								}
							}
							if (array.Length <= i + 4)
							{
								throw FileSelector.smethod_9(FileSelector.smethod_11(<Module>.smethod_24<string>(2570929253U), array, i, array.Length - i));
							}
							stack.Push(FileSelector.ParseState.OpenParen);
							break;
						case 4:
							parseState = stack.Pop();
							if (stack.Peek() != FileSelector.ParseState.OpenParen)
							{
								throw FileSelector.smethod_9(FileSelector.smethod_11(<Module>.smethod_23<string>(4219134048U), array, i, array.Length - i));
							}
							stack.Pop();
							stack.Push(FileSelector.ParseState.CriterionDone);
							break;
						case 5:
						case 6:
						case 7:
						{
							if (array.Length <= i + 2)
							{
								throw FileSelector.smethod_9(FileSelector.smethod_11(<Module>.smethod_24<string>(2570929253U), array, i, array.Length - i));
							}
							DateTime dateTime;
							try
							{
								dateTime = DateTime.ParseExact(array[i + 2], <Module>.smethod_26<string>(2805322244U), null);
								goto IL_0832;
							}
							catch (FormatException)
							{
								try
								{
									dateTime = DateTime.ParseExact(array[i + 2], <Module>.smethod_25<string>(255083126U), null);
								}
								catch (FormatException)
								{
									try
									{
										dateTime = DateTime.ParseExact(array[i + 2], <Module>.smethod_24<string>(4072356134U), null);
									}
									catch (FormatException)
									{
										try
										{
											dateTime = DateTime.ParseExact(array[i + 2], <Module>.smethod_23<string>(4294906283U), null);
										}
										catch (FormatException)
										{
											for (;;)
											{
												IL_03DB:
												int num2 = -968550229;
												for (;;)
												{
													switch (num2 ^ -968550231)
													{
													case 0:
														goto IL_03DB;
													case 2:
														dateTime = DateTime.ParseExact(array[i + 2], <Module>.smethod_27<string>(283921047U), null);
														num2 = -968550232;
														continue;
													}
													goto Block_47;
												}
											}
											Block_47:;
										}
									}
								}
								goto IL_0832;
							}
							goto IL_03ED;
							IL_0832:
							dateTime = DateTime.SpecifyKind(dateTime, DateTimeKind.Local).ToUniversalTime();
							selectionCriterion = new TimeCriterion
							{
								Which = (WhichTime)Enum.Parse(typeof(WhichTime), array[i], true),
								Operator = (ComparisonOperator)EnumUtil.Parse(typeof(ComparisonOperator), array[i + 1]),
								Time = dateTime
							};
							i += 2;
							stack.Push(FileSelector.ParseState.CriterionDone);
							break;
						}
						case 8:
						case 9:
							goto IL_03ED;
						case 10:
						case 11:
						{
							if (array.Length <= i + 2)
							{
								throw new ArgumentException(string.Join(<Module>.smethod_23<string>(4219134048U), array, i, array.Length - i));
							}
							ComparisonOperator comparisonOperator = (ComparisonOperator)EnumUtil.Parse(typeof(ComparisonOperator), array[i + 1]);
							if (comparisonOperator != ComparisonOperator.NotEqualTo)
							{
								if (comparisonOperator != ComparisonOperator.EqualTo)
								{
									throw new ArgumentException(string.Join(<Module>.smethod_24<string>(2570929253U), array, i, array.Length - i));
								}
							}
							string text3 = array[i + 2];
							if (text3.StartsWith(<Module>.smethod_26<string>(2359229459U)) && text3.EndsWith(<Module>.smethod_25<string>(4033420378U)))
							{
								text3 = text3.Substring(1, text3.Length - 2).Replace(<Module>.smethod_23<string>(1173303122U), <Module>.smethod_25<string>(482330791U));
							}
							if (Path.DirectorySeparatorChar == '/')
							{
								text3 = text3.Replace('\\', Path.DirectorySeparatorChar);
							}
							selectionCriterion = new NameCriterion
							{
								MatchingFileSpec = text3,
								Operator = comparisonOperator
							};
							i += 2;
							stack.Push(FileSelector.ParseState.CriterionDone);
							break;
						}
						case 12:
						case 13:
						case 14:
						{
							if (array.Length <= i + 2)
							{
								throw new ArgumentException(string.Join(<Module>.smethod_27<string>(2931232896U), array, i, array.Length - i));
							}
							ComparisonOperator comparisonOperator2 = (ComparisonOperator)EnumUtil.Parse(typeof(ComparisonOperator), array[i + 1]);
							if (comparisonOperator2 != ComparisonOperator.NotEqualTo && comparisonOperator2 != ComparisonOperator.EqualTo)
							{
								throw new ArgumentException(string.Join(<Module>.smethod_27<string>(2931232896U), array, i, array.Length - i));
							}
							selectionCriterion = ((text == <Module>.smethod_26<string>(1001144091U)) ? new TypeCriterion
							{
								AttributeString = array[i + 2],
								Operator = comparisonOperator2
							} : new AttributesCriterion
							{
								AttributeString = array[i + 2],
								Operator = comparisonOperator2
							});
							i += 2;
							stack.Push(FileSelector.ParseState.CriterionDone);
							break;
						}
						case 15:
							stack.Push(FileSelector.ParseState.Whitespace);
							break;
						default:
							goto IL_0A0E;
						}
						IL_07AE:
						parseState = stack.Peek();
						if (parseState == FileSelector.ParseState.CriterionDone)
						{
							stack.Pop();
							if (stack.Peek() == FileSelector.ParseState.ConjunctionPending)
							{
								while (stack.Peek() == FileSelector.ParseState.ConjunctionPending)
								{
									CompoundCriterion compoundCriterion = stack2.Pop() as CompoundCriterion;
									compoundCriterion.Right = selectionCriterion;
									selectionCriterion = compoundCriterion;
									stack.Pop();
									parseState = stack.Pop();
									if (parseState != FileSelector.ParseState.CriterionDone)
									{
										throw new ArgumentException(<Module>.smethod_27<string>(4190889U));
									}
								}
							}
							else
							{
								stack.Push(FileSelector.ParseState.CriterionDone);
							}
						}
						if (parseState == FileSelector.ParseState.Whitespace)
						{
							stack.Pop();
						}
						i++;
						continue;
						IL_03ED:
						if (array.Length > i + 2)
						{
							string text4 = array[i + 2];
							long num3;
							if (text4.ToUpper().EndsWith(<Module>.smethod_26<string>(356182185U)))
							{
								num3 = long.Parse(text4.Substring(0, text4.Length - 1)) * 1024L;
							}
							else if (text4.ToUpper().EndsWith(<Module>.smethod_24<string>(3842186948U)))
							{
								num3 = long.Parse(text4.Substring(0, text4.Length - 2)) * 1024L;
							}
							else if (!text4.ToUpper().EndsWith(<Module>.smethod_27<string>(2769559467U)))
							{
								if (text4.ToUpper().EndsWith(<Module>.smethod_25<string>(2064616904U)))
								{
									num3 = long.Parse(text4.Substring(0, text4.Length - 2)) * 1024L * 1024L;
								}
								else if (!text4.ToUpper().EndsWith(<Module>.smethod_27<string>(4112671413U)))
								{
									if (text4.ToUpper().EndsWith(<Module>.smethod_27<string>(97434275U)))
									{
										num3 = long.Parse(text4.Substring(0, text4.Length - 2)) * 1024L * 1024L * 1024L;
									}
									else
									{
										num3 = long.Parse(array[i + 2]);
									}
								}
								else
								{
									num3 = long.Parse(text4.Substring(0, text4.Length - 1)) * 1024L * 1024L * 1024L;
								}
							}
							else
							{
								num3 = long.Parse(text4.Substring(0, text4.Length - 1)) * 1024L * 1024L;
							}
							selectionCriterion = new SizeCriterion
							{
								Size = num3,
								Operator = (ComparisonOperator)EnumUtil.Parse(typeof(ComparisonOperator), array[i + 1])
							};
							i += 2;
							stack.Push(FileSelector.ParseState.CriterionDone);
							goto IL_07AE;
						}
						throw new ArgumentException(string.Join(<Module>.smethod_27<string>(2931232896U), array, i, array.Length - i));
					}
				}
				IL_0A0E:
				throw new ArgumentException(<Module>.smethod_27<string>(4118442953U) + array[i] + <Module>.smethod_25<string>(4033420378U));
			}
			return selectionCriterion;
		}

		// Token: 0x06000F1B RID: 3867 RVA: 0x00012FF9 File Offset: 0x000111F9
		public override string ToString()
		{
			return FileSelector.smethod_4(<Module>.smethod_26<string>(375334973U), FileSelector.smethod_1(this._Criterion), <Module>.smethod_25<string>(2591948655U));
		}

		// Token: 0x06000F1C RID: 3868 RVA: 0x0001301F File Offset: 0x0001121F
		private bool Evaluate(string filename)
		{
			return this._Criterion.Evaluate(filename);
		}

		// Token: 0x06000F1D RID: 3869 RVA: 0x0001302D File Offset: 0x0001122D
		[Conditional("SelectorTrace")]
		private void SelectorTrace(string format, params object[] args)
		{
			if (this._Criterion != null && this._Criterion.Verbose)
			{
				FileSelector.smethod_15(format, args);
			}
		}

		// Token: 0x06000F1E RID: 3870 RVA: 0x0001304B File Offset: 0x0001124B
		public ICollection<string> SelectFiles(string directory)
		{
			return this.SelectFiles(directory, false);
		}

		// Token: 0x06000F1F RID: 3871 RVA: 0x00055F2C File Offset: 0x0005412C
		public ReadOnlyCollection<string> SelectFiles(string directory, bool recurseDirectories)
		{
			if (this._Criterion == null)
			{
				throw FileSelector.smethod_9(<Module>.smethod_24<string>(2852916701U));
			}
			List<string> list = new List<string>();
			try
			{
				if (FileSelector.smethod_16(directory))
				{
					string[] array = FileSelector.smethod_17(directory);
					foreach (string text in array)
					{
						if (this.Evaluate(text))
						{
							list.Add(text);
						}
					}
					if (recurseDirectories)
					{
						string[] array3 = FileSelector.smethod_18(directory);
						foreach (string text2 in array3)
						{
							if (this.TraverseReparsePoints || (FileSelector.smethod_19(text2) & FileAttributes.ReparsePoint) == (FileAttributes)0)
							{
								if (this.Evaluate(text2))
								{
									list.Add(text2);
								}
								list.AddRange(this.SelectFiles(text2, recurseDirectories));
							}
						}
					}
				}
			}
			catch (UnauthorizedAccessException)
			{
			}
			catch (IOException)
			{
			}
			return list.AsReadOnly();
		}

		// Token: 0x06000F20 RID: 3872 RVA: 0x00013055 File Offset: 0x00011255
		private bool Evaluate(ZipEntry entry)
		{
			return this._Criterion.Evaluate(entry);
		}

		// Token: 0x06000F21 RID: 3873 RVA: 0x00056024 File Offset: 0x00054224
		public ICollection<ZipEntry> SelectEntries(ZipFile zip)
		{
			if (zip == null)
			{
				throw FileSelector.smethod_20(<Module>.smethod_27<string>(3599832790U));
			}
			List<ZipEntry> list = new List<ZipEntry>();
			IEnumerator<ZipEntry> enumerator = zip.GetEnumerator();
			try
			{
				while (FileSelector.smethod_21(enumerator))
				{
					ZipEntry zipEntry = enumerator.Current;
					if (this.Evaluate(zipEntry))
					{
						list.Add(zipEntry);
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					FileSelector.smethod_22(enumerator);
				}
			}
			return list;
		}

		// Token: 0x06000F22 RID: 3874 RVA: 0x00056090 File Offset: 0x00054290
		public ICollection<ZipEntry> SelectEntries(ZipFile zip, string directoryPathInArchive)
		{
			if (zip == null)
			{
				throw FileSelector.smethod_20(<Module>.smethod_26<string>(1108719578U));
			}
			List<ZipEntry> list = new List<ZipEntry>();
			string text = ((directoryPathInArchive == null) ? null : FileSelector.smethod_23(directoryPathInArchive, <Module>.smethod_24<string>(3061240605U), <Module>.smethod_24<string>(1184318668U)));
			if (text != null)
			{
				while (FileSelector.smethod_26(text, <Module>.smethod_25<string>(3572883402U)))
				{
					text = FileSelector.smethod_25(text, 0, FileSelector.smethod_24(text) - 1);
				}
			}
			IEnumerator<ZipEntry> enumerator = zip.GetEnumerator();
			try
			{
				while (FileSelector.smethod_21(enumerator))
				{
					ZipEntry zipEntry = enumerator.Current;
					if ((directoryPathInArchive == null || FileSelector.smethod_3(FileSelector.smethod_27(zipEntry.FileName), directoryPathInArchive) || FileSelector.smethod_3(FileSelector.smethod_27(zipEntry.FileName), text)) && this.Evaluate(zipEntry))
					{
						list.Add(zipEntry);
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					FileSelector.smethod_22(enumerator);
				}
			}
			return list;
		}

		// Token: 0x06000F23 RID: 3875 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_0(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06000F24 RID: 3876 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_1(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06000F25 RID: 3877 RVA: 0x0000C6B8 File Offset: 0x0000A8B8
		static string smethod_2(string string_0)
		{
			return string_0.Trim();
		}

		// Token: 0x06000F26 RID: 3878 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_3(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06000F27 RID: 3879 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_4(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x06000F28 RID: 3880 RVA: 0x00013063 File Offset: 0x00011263
		static string smethod_5(string string_0, string string_1, string string_2)
		{
			return Regex.Replace(string_0, string_1, string_2);
		}

		// Token: 0x06000F29 RID: 3881 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_6(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x06000F2A RID: 3882 RVA: 0x0000E038 File Offset: 0x0000C238
		static int smethod_7(string string_0, string string_1)
		{
			return string_0.IndexOf(string_1);
		}

		// Token: 0x06000F2B RID: 3883 RVA: 0x0000C693 File Offset: 0x0000A893
		static string[] smethod_8(string string_0, char[] char_0)
		{
			return string_0.Split(char_0);
		}

		// Token: 0x06000F2C RID: 3884 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_9(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x06000F2D RID: 3885 RVA: 0x0000FD9A File Offset: 0x0000DF9A
		static string smethod_10(string string_0)
		{
			return string_0.ToLower();
		}

		// Token: 0x06000F2E RID: 3886 RVA: 0x0001306D File Offset: 0x0001126D
		static string smethod_11(string string_0, string[] string_1, int int_0, int int_1)
		{
			return string.Join(string_0, string_1, int_0, int_1);
		}

		// Token: 0x06000F2F RID: 3887 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_12(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06000F30 RID: 3888 RVA: 0x0000DAEE File Offset: 0x0000BCEE
		static string smethod_13(string string_0)
		{
			return string_0.ToUpper();
		}

		// Token: 0x06000F31 RID: 3889 RVA: 0x00013078 File Offset: 0x00011278
		static object smethod_14(Type type_0, string string_0, bool bool_0)
		{
			return Enum.Parse(type_0, string_0, bool_0);
		}

		// Token: 0x06000F32 RID: 3890 RVA: 0x00013082 File Offset: 0x00011282
		static void smethod_15(string string_0, object[] object_0)
		{
			Console.WriteLine(string_0, object_0);
		}

		// Token: 0x06000F33 RID: 3891 RVA: 0x0000D8B1 File Offset: 0x0000BAB1
		static bool smethod_16(string string_0)
		{
			return Directory.Exists(string_0);
		}

		// Token: 0x06000F34 RID: 3892 RVA: 0x0001308B File Offset: 0x0001128B
		static string[] smethod_17(string string_0)
		{
			return Directory.GetFiles(string_0);
		}

		// Token: 0x06000F35 RID: 3893 RVA: 0x00013093 File Offset: 0x00011293
		static string[] smethod_18(string string_0)
		{
			return Directory.GetDirectories(string_0);
		}

		// Token: 0x06000F36 RID: 3894 RVA: 0x00012F3E File Offset: 0x0001113E
		static FileAttributes smethod_19(string string_0)
		{
			return File.GetAttributes(string_0);
		}

		// Token: 0x06000F37 RID: 3895 RVA: 0x0000C338 File Offset: 0x0000A538
		static ArgumentNullException smethod_20(string string_0)
		{
			return new ArgumentNullException(string_0);
		}

		// Token: 0x06000F38 RID: 3896 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_21(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06000F39 RID: 3897 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_22(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06000F3A RID: 3898 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_23(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x06000F3B RID: 3899 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_24(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06000F3C RID: 3900 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_25(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x06000F3D RID: 3901 RVA: 0x0000D9AC File Offset: 0x0000BBAC
		static bool smethod_26(string string_0, string string_1)
		{
			return string_0.EndsWith(string_1);
		}

		// Token: 0x06000F3E RID: 3902 RVA: 0x0000C66E File Offset: 0x0000A86E
		static string smethod_27(string string_0)
		{
			return Path.GetDirectoryName(string_0);
		}

		// Token: 0x04000513 RID: 1299
		internal SelectionCriterion _Criterion;

		// Token: 0x020000FC RID: 252
		private enum ParseState
		{
			// Token: 0x04000516 RID: 1302
			Start,
			// Token: 0x04000517 RID: 1303
			OpenParen,
			// Token: 0x04000518 RID: 1304
			CriterionDone,
			// Token: 0x04000519 RID: 1305
			ConjunctionPending,
			// Token: 0x0400051A RID: 1306
			Whitespace
		}

		// Token: 0x020000FD RID: 253
		private static class RegexAssertions
		{
			// Token: 0x0400051B RID: 1307
			public static readonly string PrecededByOddNumberOfSingleQuotes = <Module>.smethod_25<string>(3665358323U);

			// Token: 0x0400051C RID: 1308
			public static readonly string FollowedByOddNumberOfSingleQuotesAndLineEnd = <Module>.smethod_26<string>(926768092U);

			// Token: 0x0400051D RID: 1309
			public static readonly string PrecededByEvenNumberOfSingleQuotes = <Module>.smethod_24<string>(291585771U);

			// Token: 0x0400051E RID: 1310
			public static readonly string FollowedByEvenNumberOfSingleQuotesAndLineEnd = <Module>.smethod_25<string>(582995601U);
		}
	}
}
