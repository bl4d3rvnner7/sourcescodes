﻿using System;
using System.IO;
using System.Reflection;

namespace FraudFox
{
	// Token: 0x02000014 RID: 20
	public static class ConfigManager
	{
		// Token: 0x06000118 RID: 280 RVA: 0x0000C656 File Offset: 0x0000A856
		static string smethod_0(string string_0, string string_1)
		{
			return Path.Combine(string_0, string_1);
		}

		// Token: 0x06000119 RID: 281 RVA: 0x0000C65F File Offset: 0x0000A85F
		static Assembly smethod_1()
		{
			return Assembly.GetExecutingAssembly();
		}

		// Token: 0x0600011A RID: 282 RVA: 0x0000C666 File Offset: 0x0000A866
		static string smethod_2(Assembly assembly_0)
		{
			return assembly_0.Location;
		}

		// Token: 0x0600011B RID: 283 RVA: 0x0000C66E File Offset: 0x0000A86E
		static string smethod_3(string string_0)
		{
			return Path.GetDirectoryName(string_0);
		}

		// Token: 0x0600011C RID: 284 RVA: 0x0000C676 File Offset: 0x0000A876
		static string smethod_4(string string_0, string string_1, string string_2, string string_3)
		{
			return Path.Combine(string_0, string_1, string_2, string_3);
		}

		// Token: 0x04000044 RID: 68
		public static ConfigFile UserConfigFile = new ConfigFile(ConfigManager.smethod_0(<Module>.smethod_24<string>(3666899264U), <Module>.smethod_24<string>(2217290645U)));

		// Token: 0x04000045 RID: 69
		public static ConfigFile SystemConfigFile = new ConfigFile(ConfigManager.smethod_4(ConfigManager.smethod_3(ConfigManager.smethod_2(ConfigManager.smethod_1())), <Module>.smethod_23<string>(1078819909U), <Module>.smethod_27<string>(3984869096U), <Module>.smethod_27<string>(756429199U)));
	}
}
