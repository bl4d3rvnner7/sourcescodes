﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

// Token: 0x02000001 RID: 1
internal class <Module>
{
	// Token: 0x06000001 RID: 1 RVA: 0x000200E0 File Offset: 0x0001E2E0
	static <Module>()
	{
		/*
An exception occurred when decompiling this method (06000001)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void <Module>::.cctor()
 ---> System.ArgumentOutOfRangeException: Nicht negative Zahl erforderlich.
Parametername: length
   bei System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   bei System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   bei ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:Zeile 53.
   bei ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:Zeile 403.
   bei ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:Zeile 278.
   bei ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:Zeile 112.
   bei ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:Zeile 88.
   --- Ende der internen Ausnahmestapelüberwachung ---
   bei ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:Zeile 92.
   bei ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:Zeile 1686.
*/;
	}

	// Token: 0x06000002 RID: 2 RVA: 0x000200F8 File Offset: 0x0001E2F8
	private static void smethod_0()
	{
		string text = <Module>.smethod_24<string>(1536436822U);
		if (<Module>.smethod_3(<Module>.smethod_2(text, <Module>.smethod_26<string>(2123253943U))) != null || <Module>.smethod_5(<Module>.smethod_4(text, <Module>.smethod_25<string>(1373666010U))) != null)
		{
			<Module>.smethod_6(null);
		}
		Thread thread = <Module>.smethod_7(new ParameterizedThreadStart(<Module>.smethod_1));
		<Module>.smethod_8(thread, true);
		<Module>.smethod_9(thread, null);
	}

	// Token: 0x06000003 RID: 3 RVA: 0x00020164 File Offset: 0x0001E364
	private static void smethod_1(object object_0)
	{
		Thread thread = object_0 as Thread;
		if (thread == null)
		{
			thread = <Module>.smethod_10(new ParameterizedThreadStart(<Module>.smethod_1));
			<Module>.smethod_11(thread, true);
			<Module>.smethod_13(thread, <Module>.smethod_12());
			<Module>.smethod_14(500);
		}
		for (;;)
		{
			if (<Module>.smethod_15() || <Module>.smethod_16())
			{
				<Module>.smethod_17(null);
			}
			if (!<Module>.smethod_18(thread))
			{
				<Module>.smethod_19(null);
			}
			<Module>.smethod_20(1000);
		}
	}

	// Token: 0x06000004 RID: 4 RVA: 0x0000BF24 File Offset: 0x0000A124
	static string smethod_2(string string_0, string string_1)
	{
		return string_0 + string_1;
	}

	// Token: 0x06000005 RID: 5 RVA: 0x0000BF2D File Offset: 0x0000A12D
	static string smethod_3(string string_0)
	{
		return Environment.GetEnvironmentVariable(string_0);
	}

	// Token: 0x06000006 RID: 6 RVA: 0x0000BF24 File Offset: 0x0000A124
	static string smethod_4(string string_0, string string_1)
	{
		return string_0 + string_1;
	}

	// Token: 0x06000007 RID: 7 RVA: 0x0000BF2D File Offset: 0x0000A12D
	static string smethod_5(string string_0)
	{
		return Environment.GetEnvironmentVariable(string_0);
	}

	// Token: 0x06000008 RID: 8 RVA: 0x0000BF35 File Offset: 0x0000A135
	static void smethod_6(string string_0)
	{
		Environment.FailFast(string_0);
	}

	// Token: 0x06000009 RID: 9 RVA: 0x0000BF3D File Offset: 0x0000A13D
	static Thread smethod_7(ParameterizedThreadStart parameterizedThreadStart_0)
	{
		return new Thread(parameterizedThreadStart_0);
	}

	// Token: 0x0600000A RID: 10 RVA: 0x0000BF45 File Offset: 0x0000A145
	static void smethod_8(Thread thread_0, bool bool_0)
	{
		thread_0.IsBackground = bool_0;
	}

	// Token: 0x0600000B RID: 11 RVA: 0x0000BF4E File Offset: 0x0000A14E
	static void smethod_9(Thread thread_0, object object_0)
	{
		thread_0.Start(object_0);
	}

	// Token: 0x0600000C RID: 12 RVA: 0x0000BF3D File Offset: 0x0000A13D
	static Thread smethod_10(ParameterizedThreadStart parameterizedThreadStart_0)
	{
		return new Thread(parameterizedThreadStart_0);
	}

	// Token: 0x0600000D RID: 13 RVA: 0x0000BF45 File Offset: 0x0000A145
	static void smethod_11(Thread thread_0, bool bool_0)
	{
		thread_0.IsBackground = bool_0;
	}

	// Token: 0x0600000E RID: 14 RVA: 0x0000BF57 File Offset: 0x0000A157
	static Thread smethod_12()
	{
		return Thread.CurrentThread;
	}

	// Token: 0x0600000F RID: 15 RVA: 0x0000BF4E File Offset: 0x0000A14E
	static void smethod_13(Thread thread_0, object object_0)
	{
		thread_0.Start(object_0);
	}

	// Token: 0x06000010 RID: 16 RVA: 0x0000BF5E File Offset: 0x0000A15E
	static void smethod_14(int int_0)
	{
		Thread.Sleep(int_0);
	}

	// Token: 0x06000011 RID: 17 RVA: 0x0000BF66 File Offset: 0x0000A166
	static bool smethod_15()
	{
		return Debugger.IsAttached;
	}

	// Token: 0x06000012 RID: 18 RVA: 0x0000BF6D File Offset: 0x0000A16D
	static bool smethod_16()
	{
		return Debugger.IsLogging();
	}

	// Token: 0x06000013 RID: 19 RVA: 0x0000BF35 File Offset: 0x0000A135
	static void smethod_17(string string_0)
	{
		Environment.FailFast(string_0);
	}

	// Token: 0x06000014 RID: 20 RVA: 0x0000BF74 File Offset: 0x0000A174
	static bool smethod_18(Thread thread_0)
	{
		return thread_0.IsAlive;
	}

	// Token: 0x06000015 RID: 21 RVA: 0x0000BF35 File Offset: 0x0000A135
	static void smethod_19(string string_0)
	{
		Environment.FailFast(string_0);
	}

	// Token: 0x06000016 RID: 22 RVA: 0x0000BF5E File Offset: 0x0000A15E
	static void smethod_20(int int_0)
	{
		Thread.Sleep(int_0);
	}

	// Token: 0x06000017 RID: 23 RVA: 0x000201DC File Offset: 0x0001E3DC
	internal static byte[] smethod_22(byte[] A_0)
	{
		uint num = 7152U;
		uint[] array = new uint[16];
		uint num2 = 586095161U;
		for (int i = 0; i < 16; i++)
		{
			num2 ^= num2 >> 12;
			num2 ^= num2 << 25;
			num2 ^= num2 >> 27;
			array[i] = num2;
		}
		int num3 = 0;
		int num4 = 0;
		uint[] array2 = new uint[16];
		byte[] array3 = new byte[num * 4U];
		while ((long)num3 < (long)((ulong)num))
		{
			for (int j = 0; j < 16; j++)
			{
				array2[j] = (uint)A_0[num3 + j];
			}
			array2[0] = array2[0] ^ array[0];
			array2[1] = array2[1] ^ array[1];
			array2[2] = array2[2] ^ array[2];
			array2[3] = array2[3] ^ array[3];
			array2[4] = array2[4] ^ array[4];
			array2[5] = array2[5] ^ array[5];
			array2[6] = array2[6] ^ array[6];
			array2[7] = array2[7] ^ array[7];
			array2[8] = array2[8] ^ array[8];
			array2[9] = array2[9] ^ array[9];
			array2[10] = array2[10] ^ array[10];
			array2[11] = array2[11] ^ array[11];
			array2[12] = array2[12] ^ array[12];
			array2[13] = array2[13] ^ array[13];
			array2[14] = array2[14] ^ array[14];
			array2[15] = array2[15] ^ array[15];
			for (int k = 0; k < 16; k++)
			{
				uint num5 = array2[k];
				array3[num4++] = (byte)num5;
				array3[num4++] = (byte)(num5 >> 8);
				array3[num4++] = (byte)(num5 >> 16);
				array3[num4++] = (byte)(num5 >> 24);
				array[k] ^= num5;
			}
			num3 += 16;
		}
		return array3;
	}

	// Token: 0x06000018 RID: 24 RVA: 0x000203B8 File Offset: 0x0001E5B8
	internal static T smethod_23<T>(uint uint_0)
	{
		uint_0 = (uint_0 * 3575315539U) ^ 2809476965U;
		uint num = uint_0 >> 30;
		T t = default(T);
		uint_0 &= 1073741823U;
		uint_0 <<= 2;
		if ((ulong)num == 2UL)
		{
			int num2 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			t = (T)((object)Encoding.UTF8.GetString(<Module>.byte_0, (int)uint_0, num2));
		}
		else if ((ulong)num == 3UL)
		{
			T[] array = new T[1];
			Buffer.BlockCopy(<Module>.byte_0, (int)uint_0, array, 0, sizeof(T));
			t = array[0];
		}
		else if ((ulong)num == 0UL)
		{
			int num3 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			int num4 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			Array array2 = Array.CreateInstance(typeof(T).GetElementType(), num4);
			Buffer.BlockCopy(<Module>.byte_0, (int)uint_0, array2, 0, num3 - 4);
			t = (T)((object)array2);
		}
		return t;
	}

	// Token: 0x06000019 RID: 25 RVA: 0x00020554 File Offset: 0x0001E754
	internal static T smethod_24<T>(uint uint_0)
	{
		uint_0 = (uint_0 * 926229739U) ^ 2764371186U;
		uint num = uint_0 >> 30;
		T t = default(T);
		uint_0 &= 1073741823U;
		uint_0 <<= 2;
		if ((ulong)num == 2UL)
		{
			int num2 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			t = (T)((object)Encoding.UTF8.GetString(<Module>.byte_0, (int)uint_0, num2));
		}
		else if ((ulong)num == 3UL)
		{
			T[] array = new T[1];
			Buffer.BlockCopy(<Module>.byte_0, (int)uint_0, array, 0, sizeof(T));
			t = array[0];
		}
		else if ((ulong)num == 1UL)
		{
			int num3 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			int num4 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			Array array2 = Array.CreateInstance(typeof(T).GetElementType(), num4);
			Buffer.BlockCopy(<Module>.byte_0, (int)uint_0, array2, 0, num3 - 4);
			t = (T)((object)array2);
		}
		return t;
	}

	// Token: 0x0600001A RID: 26 RVA: 0x000206F0 File Offset: 0x0001E8F0
	internal static T smethod_25<T>(uint uint_0)
	{
		uint_0 = (uint_0 * 237208123U) ^ 1424819256U;
		uint num = uint_0 >> 30;
		T t = default(T);
		uint_0 &= 1073741823U;
		uint_0 <<= 2;
		if ((ulong)num == 3UL)
		{
			int num2 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			t = (T)((object)Encoding.UTF8.GetString(<Module>.byte_0, (int)uint_0, num2));
		}
		else if ((ulong)num == 2UL)
		{
			T[] array = new T[1];
			Buffer.BlockCopy(<Module>.byte_0, (int)uint_0, array, 0, sizeof(T));
			t = array[0];
		}
		else if ((ulong)num == 1UL)
		{
			int num3 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			int num4 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			Array array2 = Array.CreateInstance(typeof(T).GetElementType(), num4);
			Buffer.BlockCopy(<Module>.byte_0, (int)uint_0, array2, 0, num3 - 4);
			t = (T)((object)array2);
		}
		return t;
	}

	// Token: 0x0600001B RID: 27 RVA: 0x0002088C File Offset: 0x0001EA8C
	internal static T smethod_26<T>(uint uint_0)
	{
		uint_0 = (uint_0 * 1413103161U) ^ 683705021U;
		uint num = uint_0 >> 30;
		T t = default(T);
		uint_0 &= 1073741823U;
		uint_0 <<= 2;
		if ((ulong)num == 0UL)
		{
			int num2 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			t = (T)((object)Encoding.UTF8.GetString(<Module>.byte_0, (int)uint_0, num2));
		}
		else if ((ulong)num == 1UL)
		{
			T[] array = new T[1];
			Buffer.BlockCopy(<Module>.byte_0, (int)uint_0, array, 0, sizeof(T));
			t = array[0];
		}
		else if ((ulong)num == 3UL)
		{
			int num3 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			int num4 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			Array array2 = Array.CreateInstance(typeof(T).GetElementType(), num4);
			Buffer.BlockCopy(<Module>.byte_0, (int)uint_0, array2, 0, num3 - 4);
			t = (T)((object)array2);
		}
		return t;
	}

	// Token: 0x0600001C RID: 28 RVA: 0x00020A28 File Offset: 0x0001EC28
	internal static T smethod_27<T>(uint uint_0)
	{
		uint_0 = (uint_0 * 1018687147U) ^ 4045344197U;
		uint num = uint_0 >> 30;
		T t = default(T);
		uint_0 &= 1073741823U;
		uint_0 <<= 2;
		if ((ulong)num == 1UL)
		{
			int num2 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			t = (T)((object)Encoding.UTF8.GetString(<Module>.byte_0, (int)uint_0, num2));
		}
		else if ((ulong)num == 3UL)
		{
			T[] array = new T[1];
			Buffer.BlockCopy(<Module>.byte_0, (int)uint_0, array, 0, sizeof(T));
			t = array[0];
		}
		else if ((ulong)num == 0UL)
		{
			int num3 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			int num4 = (int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 8) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 16) | ((int)<Module>.byte_0[(int)((UIntPtr)(uint_0++))] << 24);
			Array array2 = Array.CreateInstance(typeof(T).GetElementType(), num4);
			Buffer.BlockCopy(<Module>.byte_0, (int)uint_0, array2, 0, num3 - 4);
			t = (T)((object)array2);
		}
		return t;
	}

	// Token: 0x04000001 RID: 1
	internal static byte[] byte_0;

	// Token: 0x04000002 RID: 2 RVA: 0x00002050 File Offset: 0x00000250
	// Note: this field is marked with 'hasfieldrva'.
	internal static <Module>.Struct4 struct4_0;

	// Token: 0x02000002 RID: 2
	[StructLayout(LayoutKind.Explicit, Size = 28608)]
	internal struct Struct4
	{
	}
}
