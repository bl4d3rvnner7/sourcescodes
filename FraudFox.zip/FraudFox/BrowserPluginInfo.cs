﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace FraudFox
{
	// Token: 0x0200001D RID: 29
	[Obfuscation(Exclude = true, ApplyToMembers = true)]
	public struct BrowserPluginInfo
	{
		// Token: 0x17000057 RID: 87
		// (get) Token: 0x060001ED RID: 493 RVA: 0x0000CEB0 File Offset: 0x0000B0B0
		// (set) Token: 0x060001EE RID: 494 RVA: 0x0000CEB8 File Offset: 0x0000B0B8
		public string Name { get; set; }

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x060001EF RID: 495 RVA: 0x0000CEC1 File Offset: 0x0000B0C1
		// (set) Token: 0x060001F0 RID: 496 RVA: 0x0000CEC9 File Offset: 0x0000B0C9
		public string Description { get; set; }

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x060001F1 RID: 497 RVA: 0x0000CED2 File Offset: 0x0000B0D2
		// (set) Token: 0x060001F2 RID: 498 RVA: 0x0000CEDA File Offset: 0x0000B0DA
		public string Filename { get; set; }

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x060001F3 RID: 499 RVA: 0x0000CEE3 File Offset: 0x0000B0E3
		// (set) Token: 0x060001F4 RID: 500 RVA: 0x0000CEEB File Offset: 0x0000B0EB
		public List<string> MimeType { get; set; }

		// Token: 0x060001F5 RID: 501 RVA: 0x0000CEF4 File Offset: 0x0000B0F4
		public override string ToString()
		{
			return BrowserPluginInfo.smethod_1(<Module>.smethod_26<string>(1468061418U), this.Name, BrowserPluginInfo.smethod_0(<Module>.smethod_26<string>(1625281455U), this.MimeType));
		}

		// Token: 0x060001F6 RID: 502 RVA: 0x0000CF20 File Offset: 0x0000B120
		public override int GetHashCode()
		{
			return BrowserPluginInfo.smethod_2(this.Name) ^ BrowserPluginInfo.smethod_2(this.Description) ^ BrowserPluginInfo.smethod_2(this.Filename) ^ BrowserPluginInfo.smethod_2(this.MimeType);
		}

		// Token: 0x060001F7 RID: 503 RVA: 0x0000CF51 File Offset: 0x0000B151
		public override bool Equals(object obj)
		{
			return obj is BrowserPluginInfo && this == (BrowserPluginInfo)obj;
		}

		// Token: 0x060001F8 RID: 504 RVA: 0x00025FC0 File Offset: 0x000241C0
		public static bool operator ==(BrowserPluginInfo x, BrowserPluginInfo y)
		{
			return BrowserPluginInfo.smethod_3(x.Name, y.Name) && BrowserPluginInfo.smethod_3(x.Description, y.Description) && BrowserPluginInfo.smethod_3(x.Filename, y.Filename);
		}

		// Token: 0x060001F9 RID: 505 RVA: 0x0000CF6E File Offset: 0x0000B16E
		public static bool operator !=(BrowserPluginInfo x, BrowserPluginInfo y)
		{
			return !(x == y);
		}

		// Token: 0x060001FA RID: 506 RVA: 0x0000CD8D File Offset: 0x0000AF8D
		static string smethod_0(string string_0, IEnumerable<string> ienumerable_0)
		{
			return string.Join(string_0, ienumerable_0);
		}

		// Token: 0x060001FB RID: 507 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_1(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x060001FC RID: 508 RVA: 0x0000CF7A File Offset: 0x0000B17A
		static int smethod_2(object object_0)
		{
			return object_0.GetHashCode();
		}

		// Token: 0x060001FD RID: 509 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_3(string string_0, string string_1)
		{
			return string_0 == string_1;
		}
	}
}
