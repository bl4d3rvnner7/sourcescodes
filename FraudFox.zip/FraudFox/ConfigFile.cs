﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using MadMilkman.Ini;

namespace FraudFox
{
	// Token: 0x02000015 RID: 21
	public class ConfigFile
	{
		// Token: 0x0600011D RID: 285 RVA: 0x00023388 File Offset: 0x00021588
		public ConfigFile(string filePath)
		{
			if (ConfigFile.smethod_0(filePath))
			{
				this.iniFile = new IniFile();
				this.iniFile.Load(filePath);
				this.iniFile.ValueMappings.Add<bool>(<Module>.smethod_25<string>(577317530U), true);
				this.iniFile.ValueMappings.Add<bool>(<Module>.smethod_25<string>(1551681872U), false);
			}
		}

		// Token: 0x0600011E RID: 286 RVA: 0x000233F0 File Offset: 0x000215F0
		public T GetValue<T>(string section, string key, [Optional] T value)
		{
			T t = value;
			if (this.iniFile.Sections.Contains(section) && this.iniFile.Sections[section].Keys.Contains(key) && ConfigFile.smethod_1(this.iniFile.Sections[section].Keys[key].Value) > 1)
			{
				this.iniFile.Sections[section].Keys[key].TryParseValue<T>(out t);
			}
			return t;
		}

		// Token: 0x0600011F RID: 287 RVA: 0x00023480 File Offset: 0x00021680
		public List<string> GetStringList(string section, string key)
		{
			string text = ConfigFile.smethod_2(this.GetValue<string>(section, key, ""), <Module>.smethod_24<string>(415060776U), <Module>.smethod_23<string>(847909907U));
			if (ConfigFile.smethod_1(text) >= 2)
			{
				return (from item in ConfigFile.smethod_3(text, new char[] { ',' })
					select ConfigFile.<>c.smethod_0(item)).ToList<string>();
			}
			return new List<string>();
		}

		// Token: 0x06000120 RID: 288 RVA: 0x0000C681 File Offset: 0x0000A881
		static bool smethod_0(string string_0)
		{
			return File.Exists(string_0);
		}

		// Token: 0x06000121 RID: 289 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_1(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06000122 RID: 290 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_2(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x06000123 RID: 291 RVA: 0x0000C693 File Offset: 0x0000A893
		static string[] smethod_3(string string_0, char[] char_0)
		{
			return string_0.Split(char_0);
		}

		// Token: 0x04000046 RID: 70
		private IniFile iniFile;
	}
}
