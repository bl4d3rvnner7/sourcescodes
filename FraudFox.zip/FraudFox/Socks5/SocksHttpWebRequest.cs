﻿using System;
using System.Collections;
using System.Collections.Specialized;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using Org.Mentalis.Network.ProxySocket;

namespace FraudFox.Socks5
{
	// Token: 0x0200004A RID: 74
	public class SocksHttpWebRequest : WebRequest
	{
		// Token: 0x060004BF RID: 1215 RVA: 0x0000DD91 File Offset: 0x0000BF91
		private SocksHttpWebRequest(Uri requestUri)
		{
			this._requestUri = requestUri;
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x00035ED4 File Offset: 0x000340D4
		public override WebResponse GetResponse()
		{
			if (SocksHttpWebRequest.smethod_0(this) == null)
			{
				throw SocksHttpWebRequest.smethod_1(<Module>.smethod_24<string>(2227447476U));
			}
			if (SocksHttpWebRequest.smethod_3(SocksHttpWebRequest.smethod_2(this)))
			{
				throw SocksHttpWebRequest.smethod_1(<Module>.smethod_25<string>(1116897757U));
			}
			if (this.RequestSubmitted)
			{
				return this._response;
			}
			this._response = this.InternalGetResponse();
			this.RequestSubmitted = true;
			return this._response;
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x060004C1 RID: 1217 RVA: 0x0000DDA0 File Offset: 0x0000BFA0
		public override Uri RequestUri
		{
			get
			{
				return this._requestUri;
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x060004C2 RID: 1218 RVA: 0x0000DDA8 File Offset: 0x0000BFA8
		// (set) Token: 0x060004C3 RID: 1219 RVA: 0x0000DDB0 File Offset: 0x0000BFB0
		public override IWebProxy Proxy { get; set; }

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x060004C4 RID: 1220 RVA: 0x0000DDB9 File Offset: 0x0000BFB9
		// (set) Token: 0x060004C5 RID: 1221 RVA: 0x0000DDD4 File Offset: 0x0000BFD4
		public override WebHeaderCollection Headers
		{
			get
			{
				if (this._requestHeaders == null)
				{
					this._requestHeaders = SocksHttpWebRequest.smethod_4();
				}
				return this._requestHeaders;
			}
			set
			{
				if (this.RequestSubmitted)
				{
					throw SocksHttpWebRequest.smethod_1(<Module>.smethod_27<string>(3630038609U));
				}
				this._requestHeaders = value;
			}
		}

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x060004C6 RID: 1222 RVA: 0x0000DDF5 File Offset: 0x0000BFF5
		// (set) Token: 0x060004C7 RID: 1223 RVA: 0x0000DDFD File Offset: 0x0000BFFD
		public bool RequestSubmitted { get; private set; }

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x060004C8 RID: 1224 RVA: 0x0000DE06 File Offset: 0x0000C006
		// (set) Token: 0x060004C9 RID: 1225 RVA: 0x0000DE1C File Offset: 0x0000C01C
		public override string Method
		{
			get
			{
				return this._method ?? <Module>.smethod_26<string>(377842604U);
			}
			set
			{
				if (!SocksHttpWebRequest.smethod_5(SocksHttpWebRequest.validHttpVerbs, value))
				{
					throw SocksHttpWebRequest.smethod_7(<Module>.smethod_27<string>(2371252898U), SocksHttpWebRequest.smethod_6(<Module>.smethod_23<string>(350518977U), value));
				}
				this._method = value;
			}
		}

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x060004CA RID: 1226 RVA: 0x0000DE52 File Offset: 0x0000C052
		// (set) Token: 0x060004CB RID: 1227 RVA: 0x0000DE5A File Offset: 0x0000C05A
		public override long ContentLength { get; set; }

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x060004CC RID: 1228 RVA: 0x0000DE63 File Offset: 0x0000C063
		// (set) Token: 0x060004CD RID: 1229 RVA: 0x0000DE6B File Offset: 0x0000C06B
		public override string ContentType { get; set; }

		// Token: 0x060004CE RID: 1230 RVA: 0x00035F40 File Offset: 0x00034140
		public override Stream GetRequestStream()
		{
			if (this.RequestSubmitted)
			{
				throw SocksHttpWebRequest.smethod_1(<Module>.smethod_27<string>(3630038609U));
			}
			if (this._requestContentBuffer != null)
			{
				if (SocksHttpWebRequest.smethod_8(this) == 0L)
				{
					this._requestContentBuffer = new byte[int.MaxValue];
				}
				else if ((long)this._requestContentBuffer.Length != SocksHttpWebRequest.smethod_8(this))
				{
					Array.Resize<byte>(ref this._requestContentBuffer, (int)SocksHttpWebRequest.smethod_8(this));
				}
			}
			else
			{
				this._requestContentBuffer = new byte[SocksHttpWebRequest.smethod_8(this)];
			}
			return SocksHttpWebRequest.smethod_9(this._requestContentBuffer);
		}

		// Token: 0x060004CF RID: 1231 RVA: 0x0000DE74 File Offset: 0x0000C074
		public new static WebRequest Create(string requestUri)
		{
			return new SocksHttpWebRequest(SocksHttpWebRequest.smethod_10(requestUri));
		}

		// Token: 0x060004D0 RID: 1232 RVA: 0x0000DE81 File Offset: 0x0000C081
		public new static WebRequest Create(Uri requestUri)
		{
			return new SocksHttpWebRequest(requestUri);
		}

		// Token: 0x060004D1 RID: 1233 RVA: 0x00035FCC File Offset: 0x000341CC
		private string BuildHttpRequestMessage()
		{
			if (this.RequestSubmitted)
			{
				throw SocksHttpWebRequest.smethod_1(<Module>.smethod_26<string>(3920272507U));
			}
			StringBuilder stringBuilder = SocksHttpWebRequest.smethod_11();
			SocksHttpWebRequest.smethod_15(stringBuilder, <Module>.smethod_23<string>(4277736894U), SocksHttpWebRequest.smethod_2(this), SocksHttpWebRequest.smethod_13(SocksHttpWebRequest.smethod_12(this)), SocksHttpWebRequest.smethod_14(SocksHttpWebRequest.smethod_12(this)));
			IEnumerator enumerator = SocksHttpWebRequest.smethod_18(SocksHttpWebRequest.smethod_17(SocksHttpWebRequest.smethod_16(this)));
			try
			{
				while (SocksHttpWebRequest.smethod_23(enumerator))
				{
					object obj = SocksHttpWebRequest.smethod_19(enumerator);
					SocksHttpWebRequest.smethod_22(stringBuilder, <Module>.smethod_25<string>(1689693584U), obj, SocksHttpWebRequest.smethod_21(SocksHttpWebRequest.smethod_16(this), SocksHttpWebRequest.smethod_20(obj)));
				}
			}
			finally
			{
				IDisposable disposable = enumerator as IDisposable;
				if (disposable != null)
				{
					SocksHttpWebRequest.smethod_24(disposable);
				}
			}
			if (!SocksHttpWebRequest.smethod_3(SocksHttpWebRequest.smethod_25(this)))
			{
				SocksHttpWebRequest.smethod_26(stringBuilder, <Module>.smethod_26<string>(3184471097U), SocksHttpWebRequest.smethod_25(this));
			}
			if (SocksHttpWebRequest.smethod_8(this) > 0L)
			{
				SocksHttpWebRequest.smethod_26(stringBuilder, <Module>.smethod_26<string>(1756007463U), SocksHttpWebRequest.smethod_8(this));
			}
			SocksHttpWebRequest.smethod_27(stringBuilder, <Module>.smethod_26<string>(162419152U));
			if (this._requestContentBuffer != null && this._requestContentBuffer.Length != 0)
			{
				MemoryStream memoryStream = SocksHttpWebRequest.smethod_28(this._requestContentBuffer, false);
				try
				{
					StreamReader streamReader = SocksHttpWebRequest.smethod_29(memoryStream);
					try
					{
						SocksHttpWebRequest.smethod_27(stringBuilder, SocksHttpWebRequest.smethod_30(streamReader));
					}
					finally
					{
						if (streamReader != null)
						{
							SocksHttpWebRequest.smethod_24(streamReader);
						}
					}
				}
				finally
				{
					if (memoryStream != null)
					{
						SocksHttpWebRequest.smethod_24(memoryStream);
					}
				}
			}
			return SocksHttpWebRequest.smethod_20(stringBuilder);
		}

		// Token: 0x060004D2 RID: 1234 RVA: 0x00036160 File Offset: 0x00034360
		private SocksHttpWebResponse InternalGetResponse()
		{
			StringBuilder stringBuilder = SocksHttpWebRequest.smethod_11();
			ProxySocket proxySocket = new ProxySocket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			try
			{
				Uri uri = SocksHttpWebRequest.smethod_31(SocksHttpWebRequest.smethod_0(this), SocksHttpWebRequest.smethod_12(this));
				IPAddress proxyIpAddress = SocksHttpWebRequest.GetProxyIpAddress(uri);
				proxySocket.ProxyEndPoint = SocksHttpWebRequest.smethod_33(proxyIpAddress, SocksHttpWebRequest.smethod_32(uri));
				proxySocket.ProxyType = ProxyTypes.Socks5;
				proxySocket.Connect(SocksHttpWebRequest.smethod_14(SocksHttpWebRequest.smethod_12(this)), 80);
				SocksHttpWebRequest.smethod_36(proxySocket, SocksHttpWebRequest.smethod_35(SocksHttpWebRequest.smethod_34(), this.RequestMessage));
				byte[] array = new byte[1024];
				for (int i = SocksHttpWebRequest.smethod_37(proxySocket, array); i > 0; i = SocksHttpWebRequest.smethod_37(proxySocket, array))
				{
					SocksHttpWebRequest.smethod_27(stringBuilder, SocksHttpWebRequest.smethod_38(SocksHttpWebRequest.smethod_34(), array, 0, i));
				}
			}
			finally
			{
				if (proxySocket != null)
				{
					SocksHttpWebRequest.smethod_24(proxySocket);
				}
			}
			return new SocksHttpWebResponse(SocksHttpWebRequest.smethod_20(stringBuilder));
		}

		// Token: 0x060004D3 RID: 1235 RVA: 0x0003623C File Offset: 0x0003443C
		private static IPAddress GetProxyIpAddress(Uri proxyUri)
		{
			IPAddress ipaddress;
			if (!SocksHttpWebRequest.smethod_39(SocksHttpWebRequest.smethod_14(proxyUri), ref ipaddress))
			{
				IPAddress ipaddress2;
				try
				{
					ipaddress2 = SocksHttpWebRequest.smethod_41(SocksHttpWebRequest.smethod_40(SocksHttpWebRequest.smethod_14(proxyUri)))[0];
				}
				catch (Exception ex)
				{
					throw SocksHttpWebRequest.smethod_42(SocksHttpWebRequest.smethod_6(<Module>.smethod_27<string>(2768211348U), SocksHttpWebRequest.smethod_14(proxyUri)), ex);
				}
				return ipaddress2;
			}
			return ipaddress;
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x060004D4 RID: 1236 RVA: 0x0000DE89 File Offset: 0x0000C089
		public string RequestMessage
		{
			get
			{
				if (SocksHttpWebRequest.smethod_3(this._requestMessage))
				{
					this._requestMessage = this.BuildHttpRequestMessage();
				}
				return this._requestMessage;
			}
		}

		// Token: 0x060004D5 RID: 1237 RVA: 0x000362A4 File Offset: 0x000344A4
		// Note: this type is marked as 'beforefieldinit'.
		static SocksHttpWebRequest()
		{
			StringCollection stringCollection = SocksHttpWebRequest.smethod_43();
			SocksHttpWebRequest.smethod_44(stringCollection, <Module>.smethod_24<string>(532934729U));
			SocksHttpWebRequest.smethod_44(stringCollection, <Module>.smethod_23<string>(3260026261U));
			SocksHttpWebRequest.smethod_44(stringCollection, <Module>.smethod_26<string>(1803889433U));
			SocksHttpWebRequest.smethod_44(stringCollection, <Module>.smethod_27<string>(2068885953U));
			SocksHttpWebRequest.smethod_44(stringCollection, <Module>.smethod_26<string>(3241929461U));
			SocksHttpWebRequest.smethod_44(stringCollection, <Module>.smethod_25<string>(4264799345U));
			SocksHttpWebRequest.smethod_44(stringCollection, <Module>.smethod_25<string>(4056006986U));
			SocksHttpWebRequest.validHttpVerbs = stringCollection;
		}

		// Token: 0x060004D6 RID: 1238 RVA: 0x0000DEAA File Offset: 0x0000C0AA
		static IWebProxy smethod_0(WebRequest webRequest_0)
		{
			return webRequest_0.Proxy;
		}

		// Token: 0x060004D7 RID: 1239 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_1(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x060004D8 RID: 1240 RVA: 0x0000DEB2 File Offset: 0x0000C0B2
		static string smethod_2(WebRequest webRequest_0)
		{
			return webRequest_0.Method;
		}

		// Token: 0x060004D9 RID: 1241 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_3(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x060004DA RID: 1242 RVA: 0x0000DEBA File Offset: 0x0000C0BA
		static WebHeaderCollection smethod_4()
		{
			return new WebHeaderCollection();
		}

		// Token: 0x060004DB RID: 1243 RVA: 0x0000DEC1 File Offset: 0x0000C0C1
		static bool smethod_5(StringCollection stringCollection_0, string string_0)
		{
			return stringCollection_0.Contains(string_0);
		}

		// Token: 0x060004DC RID: 1244 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_6(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x060004DD RID: 1245 RVA: 0x0000DECA File Offset: 0x0000C0CA
		static ArgumentOutOfRangeException smethod_7(string string_0, string string_1)
		{
			return new ArgumentOutOfRangeException(string_0, string_1);
		}

		// Token: 0x060004DE RID: 1246 RVA: 0x0000DED3 File Offset: 0x0000C0D3
		static long smethod_8(WebRequest webRequest_0)
		{
			return webRequest_0.ContentLength;
		}

		// Token: 0x060004DF RID: 1247 RVA: 0x0000C877 File Offset: 0x0000AA77
		static MemoryStream smethod_9(byte[] byte_0)
		{
			return new MemoryStream(byte_0);
		}

		// Token: 0x060004E0 RID: 1248 RVA: 0x0000DEDB File Offset: 0x0000C0DB
		static Uri smethod_10(string string_0)
		{
			return new Uri(string_0);
		}

		// Token: 0x060004E1 RID: 1249 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_11()
		{
			return new StringBuilder();
		}

		// Token: 0x060004E2 RID: 1250 RVA: 0x0000DEE3 File Offset: 0x0000C0E3
		static Uri smethod_12(WebRequest webRequest_0)
		{
			return webRequest_0.RequestUri;
		}

		// Token: 0x060004E3 RID: 1251 RVA: 0x0000DEEB File Offset: 0x0000C0EB
		static string smethod_13(Uri uri_0)
		{
			return uri_0.PathAndQuery;
		}

		// Token: 0x060004E4 RID: 1252 RVA: 0x0000DEF3 File Offset: 0x0000C0F3
		static string smethod_14(Uri uri_0)
		{
			return uri_0.Host;
		}

		// Token: 0x060004E5 RID: 1253 RVA: 0x0000DEFB File Offset: 0x0000C0FB
		static StringBuilder smethod_15(StringBuilder stringBuilder_0, string string_0, object object_0, object object_1, object object_2)
		{
			return stringBuilder_0.AppendFormat(string_0, object_0, object_1, object_2);
		}

		// Token: 0x060004E6 RID: 1254 RVA: 0x0000DF08 File Offset: 0x0000C108
		static WebHeaderCollection smethod_16(WebRequest webRequest_0)
		{
			return webRequest_0.Headers;
		}

		// Token: 0x060004E7 RID: 1255 RVA: 0x0000DF10 File Offset: 0x0000C110
		static NameObjectCollectionBase.KeysCollection smethod_17(NameObjectCollectionBase nameObjectCollectionBase_0)
		{
			return nameObjectCollectionBase_0.Keys;
		}

		// Token: 0x060004E8 RID: 1256 RVA: 0x0000DF18 File Offset: 0x0000C118
		static IEnumerator smethod_18(NameObjectCollectionBase.KeysCollection keysCollection_0)
		{
			return keysCollection_0.GetEnumerator();
		}

		// Token: 0x060004E9 RID: 1257 RVA: 0x0000D8E2 File Offset: 0x0000BAE2
		static object smethod_19(IEnumerator ienumerator_0)
		{
			return ienumerator_0.Current;
		}

		// Token: 0x060004EA RID: 1258 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_20(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x060004EB RID: 1259 RVA: 0x0000DF20 File Offset: 0x0000C120
		static string smethod_21(NameValueCollection nameValueCollection_0, string string_0)
		{
			return nameValueCollection_0[string_0];
		}

		// Token: 0x060004EC RID: 1260 RVA: 0x0000DF29 File Offset: 0x0000C129
		static StringBuilder smethod_22(StringBuilder stringBuilder_0, string string_0, object object_0, object object_1)
		{
			return stringBuilder_0.AppendFormat(string_0, object_0, object_1);
		}

		// Token: 0x060004ED RID: 1261 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_23(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060004EE RID: 1262 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_24(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060004EF RID: 1263 RVA: 0x0000DF34 File Offset: 0x0000C134
		static string smethod_25(WebRequest webRequest_0)
		{
			return webRequest_0.ContentType;
		}

		// Token: 0x060004F0 RID: 1264 RVA: 0x0000DF3C File Offset: 0x0000C13C
		static StringBuilder smethod_26(StringBuilder stringBuilder_0, string string_0, object object_0)
		{
			return stringBuilder_0.AppendFormat(string_0, object_0);
		}

		// Token: 0x060004F1 RID: 1265 RVA: 0x0000DB11 File Offset: 0x0000BD11
		static StringBuilder smethod_27(StringBuilder stringBuilder_0, string string_0)
		{
			return stringBuilder_0.Append(string_0);
		}

		// Token: 0x060004F2 RID: 1266 RVA: 0x0000DF46 File Offset: 0x0000C146
		static MemoryStream smethod_28(byte[] byte_0, bool bool_0)
		{
			return new MemoryStream(byte_0, bool_0);
		}

		// Token: 0x060004F3 RID: 1267 RVA: 0x0000DF4F File Offset: 0x0000C14F
		static StreamReader smethod_29(Stream stream_0)
		{
			return new StreamReader(stream_0);
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x0000DF57 File Offset: 0x0000C157
		static string smethod_30(TextReader textReader_0)
		{
			return textReader_0.ReadToEnd();
		}

		// Token: 0x060004F5 RID: 1269 RVA: 0x0000DF5F File Offset: 0x0000C15F
		static Uri smethod_31(IWebProxy iwebProxy_0, Uri uri_0)
		{
			return iwebProxy_0.GetProxy(uri_0);
		}

		// Token: 0x060004F6 RID: 1270 RVA: 0x0000DF68 File Offset: 0x0000C168
		static int smethod_32(Uri uri_0)
		{
			return uri_0.Port;
		}

		// Token: 0x060004F7 RID: 1271 RVA: 0x0000C369 File Offset: 0x0000A569
		static IPEndPoint smethod_33(IPAddress ipaddress_0, int int_0)
		{
			return new IPEndPoint(ipaddress_0, int_0);
		}

		// Token: 0x060004F8 RID: 1272 RVA: 0x0000C3FB File Offset: 0x0000A5FB
		static Encoding smethod_34()
		{
			return Encoding.ASCII;
		}

		// Token: 0x060004F9 RID: 1273 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_35(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x060004FA RID: 1274 RVA: 0x0000C423 File Offset: 0x0000A623
		static int smethod_36(Socket socket_0, byte[] byte_0)
		{
			return socket_0.Send(byte_0);
		}

		// Token: 0x060004FB RID: 1275 RVA: 0x0000DF70 File Offset: 0x0000C170
		static int smethod_37(Socket socket_0, byte[] byte_0)
		{
			return socket_0.Receive(byte_0);
		}

		// Token: 0x060004FC RID: 1276 RVA: 0x0000DF79 File Offset: 0x0000C179
		static string smethod_38(Encoding encoding_0, byte[] byte_0, int int_0, int int_1)
		{
			return encoding_0.GetString(byte_0, int_0, int_1);
		}

		// Token: 0x060004FD RID: 1277 RVA: 0x0000DF84 File Offset: 0x0000C184
		static bool smethod_39(string string_0, ref IPAddress ipaddress_0)
		{
			return IPAddress.TryParse(string_0, out ipaddress_0);
		}

		// Token: 0x060004FE RID: 1278 RVA: 0x0000DF8D File Offset: 0x0000C18D
		static IPHostEntry smethod_40(string string_0)
		{
			return Dns.GetHostEntry(string_0);
		}

		// Token: 0x060004FF RID: 1279 RVA: 0x0000C361 File Offset: 0x0000A561
		static IPAddress[] smethod_41(IPHostEntry iphostEntry_0)
		{
			return iphostEntry_0.AddressList;
		}

		// Token: 0x06000500 RID: 1280 RVA: 0x0000DF95 File Offset: 0x0000C195
		static InvalidOperationException smethod_42(string string_0, Exception exception_0)
		{
			return new InvalidOperationException(string_0, exception_0);
		}

		// Token: 0x06000501 RID: 1281 RVA: 0x0000DF9E File Offset: 0x0000C19E
		static StringCollection smethod_43()
		{
			return new StringCollection();
		}

		// Token: 0x06000502 RID: 1282 RVA: 0x0000DFA5 File Offset: 0x0000C1A5
		static int smethod_44(StringCollection stringCollection_0, string string_0)
		{
			return stringCollection_0.Add(string_0);
		}

		// Token: 0x040001C9 RID: 457
		private readonly Uri _requestUri;

		// Token: 0x040001CA RID: 458
		private WebHeaderCollection _requestHeaders;

		// Token: 0x040001CB RID: 459
		private string _method;

		// Token: 0x040001CC RID: 460
		private SocksHttpWebResponse _response;

		// Token: 0x040001CD RID: 461
		private string _requestMessage;

		// Token: 0x040001CE RID: 462
		private byte[] _requestContentBuffer;

		// Token: 0x040001CF RID: 463
		private static readonly StringCollection validHttpVerbs;
	}
}
