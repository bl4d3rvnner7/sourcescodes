﻿using System;

namespace FraudFox.Socks5
{
	// Token: 0x0200004D RID: 77
	public class ProxyDetails
	{
		// Token: 0x06000519 RID: 1305 RVA: 0x0000E053 File Offset: 0x0000C253
		public ProxyDetails(string fullProxyAddress, ProxyType proxyType)
		{
			this.FullProxyAddress = fullProxyAddress;
			this.ProxyType = proxyType;
		}

		// Token: 0x040001DA RID: 474
		public ProxyType ProxyType;

		// Token: 0x040001DB RID: 475
		public string FullProxyAddress;
	}
}
