﻿using System;
using System.Net;

namespace FraudFox.Socks5
{
	// Token: 0x0200004E RID: 78
	public class SocksWebClient : WebClient
	{
		// Token: 0x17000071 RID: 113
		// (get) Token: 0x0600051A RID: 1306 RVA: 0x0000E069 File Offset: 0x0000C269
		// (set) Token: 0x0600051B RID: 1307 RVA: 0x0000E071 File Offset: 0x0000C271
		public ProxyDetails ProxyDetails { get; set; }

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x0600051C RID: 1308 RVA: 0x0000E07A File Offset: 0x0000C27A
		// (set) Token: 0x0600051D RID: 1309 RVA: 0x0000E082 File Offset: 0x0000C282
		public string UserAgent { get; set; }

		// Token: 0x0600051E RID: 1310 RVA: 0x000363C4 File Offset: 0x000345C4
		protected override WebRequest GetWebRequest(Uri address)
		{
			WebRequest webRequest = null;
			if (this.ProxyDetails != null)
			{
				if (this.ProxyDetails.ProxyType == ProxyType.Proxy)
				{
					webRequest = (HttpWebRequest)SocksWebClient.smethod_0(address);
					SocksWebClient.smethod_2(webRequest, SocksWebClient.smethod_1(this.ProxyDetails.FullProxyAddress));
					if (!SocksWebClient.smethod_3(this.UserAgent))
					{
						SocksWebClient.smethod_4((HttpWebRequest)webRequest, this.UserAgent);
					}
				}
				else if (this.ProxyDetails.ProxyType != ProxyType.Socks)
				{
					if (this.ProxyDetails.ProxyType == ProxyType.None)
					{
						webRequest = (HttpWebRequest)SocksWebClient.smethod_0(address);
						if (!SocksWebClient.smethod_3(this.UserAgent))
						{
							SocksWebClient.smethod_4((HttpWebRequest)webRequest, this.UserAgent);
						}
					}
				}
				else
				{
					webRequest = SocksHttpWebRequest.Create(address);
					SocksWebClient.smethod_2(webRequest, SocksWebClient.smethod_1(this.ProxyDetails.FullProxyAddress));
				}
			}
			else
			{
				webRequest = (HttpWebRequest)SocksWebClient.smethod_0(address);
				if (!SocksWebClient.smethod_3(this.UserAgent))
				{
					SocksWebClient.smethod_4((HttpWebRequest)webRequest, this.UserAgent);
				}
			}
			return webRequest;
		}

		// Token: 0x06000520 RID: 1312 RVA: 0x0000E093 File Offset: 0x0000C293
		static WebRequest smethod_0(Uri uri_0)
		{
			return WebRequest.Create(uri_0);
		}

		// Token: 0x06000521 RID: 1313 RVA: 0x0000E09B File Offset: 0x0000C29B
		static WebProxy smethod_1(string string_0)
		{
			return new WebProxy(string_0);
		}

		// Token: 0x06000522 RID: 1314 RVA: 0x0000E0A3 File Offset: 0x0000C2A3
		static void smethod_2(WebRequest webRequest_0, IWebProxy iwebProxy_0)
		{
			webRequest_0.Proxy = iwebProxy_0;
		}

		// Token: 0x06000523 RID: 1315 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_3(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06000524 RID: 1316 RVA: 0x0000E0AC File Offset: 0x0000C2AC
		static void smethod_4(HttpWebRequest httpWebRequest_0, string string_0)
		{
			httpWebRequest_0.UserAgent = string_0;
		}
	}
}
