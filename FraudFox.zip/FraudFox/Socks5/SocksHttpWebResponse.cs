﻿using System;
using System.Collections.Specialized;
using System.IO;
using System.Net;
using System.Text;

namespace FraudFox.Socks5
{
	// Token: 0x0200004B RID: 75
	public class SocksHttpWebResponse : WebResponse
	{
		// Token: 0x06000503 RID: 1283 RVA: 0x0000DFAE File Offset: 0x0000C1AE
		public SocksHttpWebResponse(string httpResponseMessage)
		{
			this.SetHeadersAndResponseContent(httpResponseMessage);
		}

		// Token: 0x06000504 RID: 1284 RVA: 0x0000DFBD File Offset: 0x0000C1BD
		public override Stream GetResponseStream()
		{
			if (SocksHttpWebResponse.smethod_0(this.ResponseContent) != 0)
			{
				return SocksHttpWebResponse.smethod_3(SocksHttpWebResponse.smethod_2(SocksHttpWebResponse.smethod_1(), this.ResponseContent));
			}
			return Stream.Null;
		}

		// Token: 0x06000505 RID: 1285 RVA: 0x0000C600 File Offset: 0x0000A800
		public override void Close()
		{
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06000506 RID: 1286 RVA: 0x0000DFE7 File Offset: 0x0000C1E7
		public override WebHeaderCollection Headers
		{
			get
			{
				if (this._httpResponseHeaders == null)
				{
					this._httpResponseHeaders = SocksHttpWebResponse.smethod_4();
				}
				return this._httpResponseHeaders;
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06000507 RID: 1287 RVA: 0x0000E002 File Offset: 0x0000C202
		// (set) Token: 0x06000508 RID: 1288 RVA: 0x0000E010 File Offset: 0x0000C210
		public override long ContentLength
		{
			get
			{
				return (long)SocksHttpWebResponse.smethod_0(this.ResponseContent);
			}
			set
			{
				throw SocksHttpWebResponse.smethod_5();
			}
		}

		// Token: 0x06000509 RID: 1289 RVA: 0x00036334 File Offset: 0x00034534
		private void SetHeadersAndResponseContent(string responseMessage)
		{
			int num = SocksHttpWebResponse.smethod_6(responseMessage, <Module>.smethod_27<string>(1276317172U));
			string[] array = SocksHttpWebResponse.smethod_8(SocksHttpWebResponse.smethod_7(responseMessage, 0, num), new string[] { <Module>.smethod_25<string>(4057262895U) }, StringSplitOptions.RemoveEmptyEntries);
			for (int i = 1; i < array.Length; i++)
			{
				string[] array2 = SocksHttpWebResponse.smethod_9(array[i], new char[] { ':' });
				SocksHttpWebResponse.smethod_11(SocksHttpWebResponse.smethod_10(this), array2[0], array2[1]);
			}
			this.ResponseContent = SocksHttpWebResponse.smethod_12(responseMessage, num + 4);
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x0600050A RID: 1290 RVA: 0x0000E017 File Offset: 0x0000C217
		// (set) Token: 0x0600050B RID: 1291 RVA: 0x0000E028 File Offset: 0x0000C228
		private string ResponseContent
		{
			get
			{
				return this._responseContent ?? string.Empty;
			}
			set
			{
				this._responseContent = value;
			}
		}

		// Token: 0x0600050C RID: 1292 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_0(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x0600050D RID: 1293 RVA: 0x0000DB1A File Offset: 0x0000BD1A
		static Encoding smethod_1()
		{
			return Encoding.UTF8;
		}

		// Token: 0x0600050E RID: 1294 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_2(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x0600050F RID: 1295 RVA: 0x0000C877 File Offset: 0x0000AA77
		static MemoryStream smethod_3(byte[] byte_0)
		{
			return new MemoryStream(byte_0);
		}

		// Token: 0x06000510 RID: 1296 RVA: 0x0000DEBA File Offset: 0x0000C0BA
		static WebHeaderCollection smethod_4()
		{
			return new WebHeaderCollection();
		}

		// Token: 0x06000511 RID: 1297 RVA: 0x0000E031 File Offset: 0x0000C231
		static NotSupportedException smethod_5()
		{
			return new NotSupportedException();
		}

		// Token: 0x06000512 RID: 1298 RVA: 0x0000E038 File Offset: 0x0000C238
		static int smethod_6(string string_0, string string_1)
		{
			return string_0.IndexOf(string_1);
		}

		// Token: 0x06000513 RID: 1299 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_7(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x06000514 RID: 1300 RVA: 0x0000DB07 File Offset: 0x0000BD07
		static string[] smethod_8(string string_0, string[] string_1, StringSplitOptions stringSplitOptions_0)
		{
			return string_0.Split(string_1, stringSplitOptions_0);
		}

		// Token: 0x06000515 RID: 1301 RVA: 0x0000C693 File Offset: 0x0000A893
		static string[] smethod_9(string string_0, char[] char_0)
		{
			return string_0.Split(char_0);
		}

		// Token: 0x06000516 RID: 1302 RVA: 0x0000E041 File Offset: 0x0000C241
		static WebHeaderCollection smethod_10(WebResponse webResponse_0)
		{
			return webResponse_0.Headers;
		}

		// Token: 0x06000517 RID: 1303 RVA: 0x0000E049 File Offset: 0x0000C249
		static void smethod_11(NameValueCollection nameValueCollection_0, string string_0, string string_1)
		{
			nameValueCollection_0.Add(string_0, string_1);
		}

		// Token: 0x06000518 RID: 1304 RVA: 0x0000D416 File Offset: 0x0000B616
		static string smethod_12(string string_0, int int_0)
		{
			return string_0.Substring(int_0);
		}

		// Token: 0x040001D4 RID: 468
		private WebHeaderCollection _httpResponseHeaders;

		// Token: 0x040001D5 RID: 469
		private string _responseContent;
	}
}
