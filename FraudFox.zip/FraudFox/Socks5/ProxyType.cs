﻿using System;

namespace FraudFox.Socks5
{
	// Token: 0x0200004C RID: 76
	public enum ProxyType
	{
		// Token: 0x040001D7 RID: 471
		None,
		// Token: 0x040001D8 RID: 472
		Proxy,
		// Token: 0x040001D9 RID: 473
		Socks
	}
}
