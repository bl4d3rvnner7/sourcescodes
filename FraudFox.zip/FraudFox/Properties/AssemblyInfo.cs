﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.5.5753.27655")]
[assembly: AssemblyTitle("FraudFox")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: Guid("bde5dc2b-636f-4879-87c2-66e6b7aa48ac")]
[assembly: ComVisible(false)]
[assembly: AssemblyProduct("FraudFox")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[module: ConfusedBy("ConfuserEx v0.4.0")]
