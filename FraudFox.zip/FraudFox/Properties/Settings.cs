﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace FraudFox.Properties
{
	// Token: 0x02000049 RID: 73
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "10.0.0.0")]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x060004BE RID: 1214 RVA: 0x0000DD89 File Offset: 0x0000BF89
		static SettingsBase smethod_0(SettingsBase settingsBase_0)
		{
			return SettingsBase.Synchronized(settingsBase_0);
		}
	}
}
