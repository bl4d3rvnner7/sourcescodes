﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace FraudFox.Properties
{
	// Token: 0x02000049 RID: 73
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "10.0.0.0")]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x17000065 RID: 101
		// (get) Token: 0x060004BB RID: 1211 RVA: 0x0000DD64 File Offset: 0x0000BF64
		public static Settings Default
		{
			get
			{
				return Settings.defaultInstance;
			}
		}

		// Token: 0x040001C8 RID: 456
		private static Settings defaultInstance = (Settings)Settings.smethod_0(new Settings());
	}
}
