﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;

namespace FraudFox.Properties
{
	// Token: 0x02000048 RID: 72
	[CompilerGenerated]
	[DebuggerNonUserCode]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	internal class Resources
	{
		// Token: 0x060004B3 RID: 1203 RVA: 0x0000C6A8 File Offset: 0x0000A8A8
		internal Resources()
		{
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x060004B4 RID: 1204 RVA: 0x0000DCF0 File Offset: 0x0000BEF0
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (Resources.resourceMan == null)
				{
					Resources.resourceMan = Resources.smethod_2(<Module>.smethod_26<string>(4073494811U), Resources.smethod_1(Resources.smethod_0(typeof(Resources).TypeHandle)));
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x17000063 RID: 99
		// (set) Token: 0x060004B5 RID: 1205 RVA: 0x0000DD21 File Offset: 0x0000BF21
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x060004B6 RID: 1206 RVA: 0x0000DD29 File Offset: 0x0000BF29
		internal static Bitmap _1421437996_firefox_grey
		{
			get
			{
				return (Bitmap)Resources.smethod_3(Resources.ResourceManager, <Module>.smethod_23<string>(176051350U), Resources.resourceCulture);
			}
		}

		// Token: 0x060004B7 RID: 1207 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_0(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060004B8 RID: 1208 RVA: 0x0000DD49 File Offset: 0x0000BF49
		static Assembly smethod_1(Type type_0)
		{
			return type_0.Assembly;
		}

		// Token: 0x060004B9 RID: 1209 RVA: 0x0000DD51 File Offset: 0x0000BF51
		static ResourceManager smethod_2(string string_0, Assembly assembly_0)
		{
			return new ResourceManager(string_0, assembly_0);
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x0000DD5A File Offset: 0x0000BF5A
		static object smethod_3(ResourceManager resourceManager_0, string string_0, CultureInfo cultureInfo_0)
		{
			return resourceManager_0.GetObject(string_0, cultureInfo_0);
		}

		// Token: 0x040001C6 RID: 454
		private static ResourceManager resourceMan;

		// Token: 0x040001C7 RID: 455
		private static CultureInfo resourceCulture;
	}
}
