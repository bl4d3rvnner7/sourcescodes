﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace FraudFox
{
	// Token: 0x02000032 RID: 50
	public static class LogManager
	{
		// Token: 0x06000308 RID: 776 RVA: 0x00028A24 File Offset: 0x00026C24
		public static void AddEntry(string message, Exception ex = null)
		{
			string text = ((ex != null) ? LogManager.smethod_3(<Module>.smethod_23<string>(312581286U), new object[]
			{
				DateTime.Now,
				message,
				LogManager.smethod_1(ex),
				LogManager.smethod_2(ex)
			}) : LogManager.smethod_0(<Module>.smethod_26<string>(872744062U), DateTime.Now, message));
			LogManager._logList.Add(text);
			if (LogManager.smethod_4(LogManager._frmLogs))
			{
				LogManager._frmLogs.AppendText(text);
			}
		}

		// Token: 0x06000309 RID: 777 RVA: 0x0000D4A2 File Offset: 0x0000B6A2
		public static void ShowLogWindow()
		{
			if (!LogManager.smethod_4(LogManager._frmLogs))
			{
				LogManager._frmLogs.ShowForm(LogManager._logList);
			}
		}

		// Token: 0x0600030A RID: 778 RVA: 0x00028AAC File Offset: 0x00026CAC
		public static void Flush()
		{
			string text = LogManager.smethod_7(LogManager.smethod_6(LogManager.smethod_5()));
			if (LogManager.smethod_9(LogManager.smethod_8(text, <Module>.smethod_26<string>(3758400512U))))
			{
				FileInfo fileInfo = LogManager.smethod_10(LogManager.smethod_8(text, <Module>.smethod_26<string>(3758400512U)));
				if (LogManager.smethod_11(fileInfo) > 512000L)
				{
					LogManager.smethod_12(fileInfo);
				}
			}
			StreamWriter streamWriter = LogManager.smethod_13(LogManager.smethod_8(text, <Module>.smethod_26<string>(3758400512U)));
			try
			{
				IEnumerator<string> enumerator = LogManager._logList.GetEnumerator();
				try
				{
					while (LogManager.smethod_15(enumerator))
					{
						string text2 = enumerator.Current;
						LogManager.smethod_14(streamWriter, text2);
					}
				}
				finally
				{
					if (enumerator != null)
					{
						LogManager.smethod_16(enumerator);
					}
				}
			}
			finally
			{
				if (streamWriter != null)
				{
					LogManager.smethod_16(streamWriter);
				}
			}
		}

		// Token: 0x0600030C RID: 780 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_0(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x0600030D RID: 781 RVA: 0x0000D3E3 File Offset: 0x0000B5E3
		static string smethod_1(Exception exception_0)
		{
			return exception_0.Message;
		}

		// Token: 0x0600030E RID: 782 RVA: 0x0000D3EB File Offset: 0x0000B5EB
		static string smethod_2(Exception exception_0)
		{
			return exception_0.StackTrace;
		}

		// Token: 0x0600030F RID: 783 RVA: 0x0000CD33 File Offset: 0x0000AF33
		static string smethod_3(string string_0, object[] object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x06000310 RID: 784 RVA: 0x0000C82A File Offset: 0x0000AA2A
		static bool smethod_4(Control control_0)
		{
			return control_0.Visible;
		}

		// Token: 0x06000311 RID: 785 RVA: 0x0000C65F File Offset: 0x0000A85F
		static Assembly smethod_5()
		{
			return Assembly.GetExecutingAssembly();
		}

		// Token: 0x06000312 RID: 786 RVA: 0x0000C666 File Offset: 0x0000A866
		static string smethod_6(Assembly assembly_0)
		{
			return assembly_0.Location;
		}

		// Token: 0x06000313 RID: 787 RVA: 0x0000C66E File Offset: 0x0000A86E
		static string smethod_7(string string_0)
		{
			return Path.GetDirectoryName(string_0);
		}

		// Token: 0x06000314 RID: 788 RVA: 0x0000C656 File Offset: 0x0000A856
		static string smethod_8(string string_0, string string_1)
		{
			return Path.Combine(string_0, string_1);
		}

		// Token: 0x06000315 RID: 789 RVA: 0x0000C681 File Offset: 0x0000A881
		static bool smethod_9(string string_0)
		{
			return File.Exists(string_0);
		}

		// Token: 0x06000316 RID: 790 RVA: 0x0000D4D5 File Offset: 0x0000B6D5
		static FileInfo smethod_10(string string_0)
		{
			return new FileInfo(string_0);
		}

		// Token: 0x06000317 RID: 791 RVA: 0x0000D4DD File Offset: 0x0000B6DD
		static long smethod_11(FileInfo fileInfo_0)
		{
			return fileInfo_0.Length;
		}

		// Token: 0x06000318 RID: 792 RVA: 0x0000D4E5 File Offset: 0x0000B6E5
		static void smethod_12(FileSystemInfo fileSystemInfo_0)
		{
			fileSystemInfo_0.Delete();
		}

		// Token: 0x06000319 RID: 793 RVA: 0x0000D4ED File Offset: 0x0000B6ED
		static StreamWriter smethod_13(string string_0)
		{
			return File.AppendText(string_0);
		}

		// Token: 0x0600031A RID: 794 RVA: 0x0000D4F5 File Offset: 0x0000B6F5
		static void smethod_14(TextWriter textWriter_0, string string_0)
		{
			textWriter_0.WriteLine(string_0);
		}

		// Token: 0x0600031B RID: 795 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_15(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x0600031C RID: 796 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_16(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x040000C5 RID: 197
		private static ObservableCollection<string> _logList = new ObservableCollection<string>();

		// Token: 0x040000C6 RID: 198
		private static Logs _frmLogs = new Logs();

		// Token: 0x040000C7 RID: 199
		private const string LogFileName = "fraudfox.log";
	}
}
