﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using FraudFox.Socks5;
using Newtonsoft.Json;

namespace FraudFox
{
	// Token: 0x02000038 RID: 56
	public class ProcessLogin
	{
		// Token: 0x060003EB RID: 1003 RVA: 0x0000D9B5 File Offset: 0x0000BBB5
		public ProcessLogin(string username, string password)
		{
			this._username = username;
			this._password = password;
		}

		// Token: 0x060003EC RID: 1004 RVA: 0x0002E440 File Offset: 0x0002C640
		public static bool StartProxy(int timeoutSec, DataReceivedEventHandler handler)
		{
			string text = ProcessLogin.smethod_2(ProcessLogin.smethod_1(ProcessLogin.smethod_0()));
			if (ProcessLogin.smethod_3(<Module>.smethod_27<string>(398972783U)).Length < 1)
			{
				Process process = ProcessLogin.smethod_4();
				ProcessStartInfo processStartInfo = ProcessLogin.smethod_5();
				ProcessLogin.smethod_7(processStartInfo, ProcessLogin.smethod_6(text, <Module>.smethod_24<string>(2561778614U), <Module>.smethod_27<string>(305729397U)));
				ProcessLogin.smethod_9(processStartInfo, ProcessLogin.smethod_8(text, <Module>.smethod_25<string>(190582024U)));
				ProcessLogin.smethod_12(processStartInfo, ProcessLogin.smethod_11(<Module>.smethod_24<string>(299210373U), ProcessLogin.smethod_10(text, <Module>.smethod_27<string>(398972783U), <Module>.smethod_23<string>(3860227231U), <Module>.smethod_24<string>(705690184U))));
				ProcessLogin.smethod_13(processStartInfo, ProcessWindowStyle.Hidden);
				ProcessLogin.smethod_14(processStartInfo, false);
				ProcessLogin.smethod_15(processStartInfo, true);
				ProcessLogin.smethod_16(processStartInfo, true);
				ProcessLogin.smethod_17(process, processStartInfo);
				ProcessLogin.smethod_18(process, handler);
				ProcessLogin.smethod_19(process);
				ProcessLogin.smethod_20(process);
			}
			TcpClient tcpClient = ProcessLogin.smethod_21();
			int i = 0;
			while (i <= timeoutSec)
			{
				try
				{
					ProcessLogin.smethod_22(tcpClient, <Module>.smethod_24<string>(3551048861U), 9050);
					if (ProcessLogin.smethod_23(tcpClient))
					{
						ProcessLogin.smethod_24(4000);
						return true;
					}
				}
				catch (Exception)
				{
					i++;
					ProcessLogin.smethod_24(1000);
				}
			}
			return false;
		}

		// Token: 0x060003ED RID: 1005 RVA: 0x0002E584 File Offset: 0x0002C784
		public static void StopProxy()
		{
			try
			{
				Process[] array = ProcessLogin.smethod_3(<Module>.smethod_23<string>(3666945479U));
				if (array.Length != 0)
				{
					ProcessLogin.smethod_25(array[0]);
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060003EE RID: 1006 RVA: 0x0002E5C8 File Offset: 0x0002C7C8
		public bool LoginUsingTor()
		{
			int num = (int)Math.Truncate(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds);
			Dictionary<string, string> dictionary = new Dictionary<string, string>
			{
				{
					<Module>.smethod_26<string>(3440707756U),
					this._username
				},
				{
					<Module>.smethod_27<string>(4134479763U),
					this._password
				},
				{
					<Module>.smethod_23<string>(998422907U),
					Assembly.GetEntryAssembly().GetName().Version.ToString()
				},
				{
					<Module>.smethod_27<string>(3880082630U),
					Convert.ToString(num)
				}
			};
			bool flag;
			using (SocksWebClient socksWebClient = new SocksWebClient())
			{
				socksWebClient.ProxyDetails = new ProxyDetails(<Module>.smethod_27<string>(4087858070U), ProxyType.Socks);
				socksWebClient.Headers[HttpRequestHeader.ContentType] = <Module>.smethod_26<string>(1217494246U);
				string text = string.Format(<Module>.smethod_25<string>(1582531084U), <Module>.smethod_27<string>(766174787U), Uri.EscapeDataString(ProcessLogin.EncryptRj256(<Module>.smethod_25<string>(3062751048U), <Module>.smethod_27<string>(1921971524U), dictionary.ToJson())));
				string text2 = socksWebClient.DownloadString(text);
				if (text2.Length < 1)
				{
					throw new FormatException(<Module>.smethod_25<string>(4037115390U));
				}
				LoginResult loginResult;
				try
				{
					text2 = ProcessLogin.DecryptRj256(<Module>.smethod_27<string>(2248323375U), <Module>.smethod_26<string>(2703416244U), text2);
					loginResult = JsonConvert.DeserializeObject<LoginResult>(text2);
				}
				catch (FormatException)
				{
					throw new FormatException(<Module>.smethod_24<string>(3177091008U));
				}
				catch (JsonSerializationException)
				{
					throw new FormatException(<Module>.smethod_24<string>(3177091008U));
				}
				if (loginResult.Now <= 0 || Math.Abs(loginResult.Now - num) >= 60)
				{
					if (string.IsNullOrEmpty(loginResult.Message))
					{
						throw new ApplicationException(<Module>.smethod_24<string>(2948950955U));
					}
					throw new ApplicationException(loginResult.Message);
				}
				else
				{
					flag = true;
				}
			}
			return flag;
		}

		// Token: 0x060003EF RID: 1007 RVA: 0x0002E7F8 File Offset: 0x0002C9F8
		public bool LoginUsingDirect()
		{
			int num = (int)Math.Truncate(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds);
			Dictionary<string, string> dictionary = new Dictionary<string, string>
			{
				{
					<Module>.smethod_26<string>(3440707756U),
					this._username
				},
				{
					<Module>.smethod_25<string>(1025751460U),
					this._password
				},
				{
					<Module>.smethod_26<string>(3360189697U),
					Assembly.GetEntryAssembly().GetName().Version.ToString()
				},
				{
					<Module>.smethod_23<string>(1559454038U),
					Convert.ToString(num)
				}
			};
			bool flag;
			using (SocksWebClient socksWebClient = new SocksWebClient())
			{
				socksWebClient.Headers[HttpRequestHeader.ContentType] = <Module>.smethod_26<string>(1217494246U);
				string text = string.Format(<Module>.smethod_27<string>(346579550U), <Module>.smethod_24<string>(1729511522U), Uri.EscapeDataString(ProcessLogin.EncryptRj256(<Module>.smethod_27<string>(2248323375U), <Module>.smethod_24<string>(1267144017U), dictionary.ToJson())));
				string text2 = socksWebClient.DownloadString(text);
				if (text2.Length < 1)
				{
					throw new FormatException(<Module>.smethod_24<string>(3177091008U));
				}
				LoginResult loginResult;
				try
				{
					text2 = ProcessLogin.DecryptRj256(<Module>.smethod_27<string>(2248323375U), <Module>.smethod_27<string>(1921971524U), text2);
					loginResult = JsonConvert.DeserializeObject<LoginResult>(text2);
				}
				catch (FormatException)
				{
					throw new FormatException(<Module>.smethod_25<string>(4037115390U));
				}
				catch (JsonSerializationException)
				{
					throw new FormatException(<Module>.smethod_24<string>(3177091008U));
				}
				if (loginResult.Now <= 0 || Math.Abs(loginResult.Now - num) >= 60)
				{
					if (!string.IsNullOrEmpty(loginResult.Message))
					{
						throw new ApplicationException(loginResult.Message);
					}
					throw new ApplicationException(<Module>.smethod_26<string>(4294587750U));
				}
				else
				{
					flag = true;
				}
			}
			return flag;
		}

		// Token: 0x060003F0 RID: 1008 RVA: 0x0002EA10 File Offset: 0x0002CC10
		public string GetNewsUsingTor()
		{
			string text2;
			try
			{
				int num = (int)Math.Truncate(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds);
				Dictionary<string, string> dictionary = new Dictionary<string, string>
				{
					{
						<Module>.smethod_25<string>(557242740U),
						Assembly.GetEntryAssembly().GetName().Version.ToString()
					},
					{
						<Module>.smethod_27<string>(3880082630U),
						Convert.ToString(num)
					}
				};
				using (SocksWebClient socksWebClient = new SocksWebClient())
				{
					socksWebClient.ProxyDetails = new ProxyDetails(<Module>.smethod_27<string>(4087858070U), ProxyType.Socks);
					socksWebClient.Headers[HttpRequestHeader.ContentType] = <Module>.smethod_23<string>(3996860314U);
					string text = string.Format(<Module>.smethod_26<string>(742581453U), <Module>.smethod_23<string>(3054612475U), Uri.EscapeDataString(ProcessLogin.EncryptRj256(<Module>.smethod_27<string>(2248323375U), <Module>.smethod_26<string>(2703416244U), dictionary.ToJson())));
					text2 = socksWebClient.DownloadString(text);
				}
			}
			catch (WebException)
			{
				text2 = "";
			}
			return text2;
		}

		// Token: 0x060003F1 RID: 1009 RVA: 0x0002EB3C File Offset: 0x0002CD3C
		public string GetNewsUsingDirect()
		{
			string text2;
			try
			{
				int num = (int)Math.Truncate(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds);
				Dictionary<string, string> dictionary = new Dictionary<string, string>
				{
					{
						<Module>.smethod_26<string>(3360189697U),
						Assembly.GetEntryAssembly().GetName().Version.ToString()
					},
					{
						<Module>.smethod_27<string>(3880082630U),
						Convert.ToString(num)
					}
				};
				using (SocksWebClient socksWebClient = new SocksWebClient())
				{
					socksWebClient.Headers[HttpRequestHeader.ContentType] = <Module>.smethod_26<string>(1217494246U);
					string text = string.Format(<Module>.smethod_26<string>(3618661509U), <Module>.smethod_23<string>(3054612475U), Uri.EscapeDataString(ProcessLogin.EncryptRj256(<Module>.smethod_25<string>(3062751048U), <Module>.smethod_23<string>(2101671044U), dictionary.ToJson())));
					text2 = socksWebClient.DownloadString(text);
				}
			}
			catch (WebException)
			{
				for (;;)
				{
					IL_0109:
					int num2 = 878874632;
					for (;;)
					{
						switch (num2 ^ 878874634)
						{
						case 0:
							goto IL_0109;
						case 2:
							text2 = "";
							num2 = 878874635;
							continue;
						}
						goto Block_7;
					}
				}
				Block_7:;
			}
			return text2;
		}

		// Token: 0x060003F2 RID: 1010 RVA: 0x0002EC7C File Offset: 0x0002CE7C
		public static void SyncTimeUsingTor()
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string> { 
			{
				<Module>.smethod_27<string>(3926704323U),
				ProcessLogin.smethod_29(ProcessLogin.smethod_28(ProcessLogin.smethod_27(ProcessLogin.smethod_26())))
			} };
			if (!TimezoneManager.SetTimeZone(<Module>.smethod_23<string>(423924447U)))
			{
				throw ProcessLogin.smethod_30(<Module>.smethod_25<string>(170507234U));
			}
			SocksWebClient socksWebClient = new SocksWebClient();
			try
			{
				socksWebClient.ProxyDetails = new ProxyDetails(<Module>.smethod_26<string>(2012244122U), ProxyType.Socks);
				ProcessLogin.smethod_32(ProcessLogin.smethod_31(socksWebClient), HttpRequestHeader.ContentType, <Module>.smethod_23<string>(3996860314U));
				string text = ProcessLogin.smethod_34(<Module>.smethod_26<string>(2933158874U), <Module>.smethod_26<string>(2142315905U), ProcessLogin.smethod_33(ProcessLogin.EncryptRj256(<Module>.smethod_24<string>(1903793014U), <Module>.smethod_23<string>(2101671044U), dictionary.ToJson())));
				string text2 = ProcessLogin.smethod_35(socksWebClient, text);
				if (ProcessLogin.smethod_36(text2))
				{
					throw ProcessLogin.smethod_30(<Module>.smethod_26<string>(1514271634U));
				}
				TimezoneManager.SetTime(ProcessLogin.smethod_37(text2));
			}
			finally
			{
				if (socksWebClient != null)
				{
					ProcessLogin.smethod_38(socksWebClient);
				}
			}
		}

		// Token: 0x060003F3 RID: 1011 RVA: 0x0002ED8C File Offset: 0x0002CF8C
		public static void SyncTimeUsingDirect()
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string> { 
			{
				<Module>.smethod_25<string>(557242740U),
				ProcessLogin.smethod_29(ProcessLogin.smethod_28(ProcessLogin.smethod_27(ProcessLogin.smethod_26())))
			} };
			if (!TimezoneManager.SetTimeZone(<Module>.smethod_23<string>(423924447U)))
			{
				throw ProcessLogin.smethod_30(<Module>.smethod_26<string>(771310635U));
			}
			SocksWebClient socksWebClient = new SocksWebClient();
			try
			{
				ProcessLogin.smethod_32(ProcessLogin.smethod_31(socksWebClient), HttpRequestHeader.ContentType, <Module>.smethod_25<string>(1183619817U));
				string text = ProcessLogin.smethod_34(<Module>.smethod_27<string>(3703341446U), <Module>.smethod_27<string>(766174787U), ProcessLogin.smethod_33(ProcessLogin.EncryptRj256(<Module>.smethod_27<string>(2248323375U), <Module>.smethod_23<string>(2101671044U), dictionary.ToJson())));
				string text2 = ProcessLogin.smethod_35(socksWebClient, text);
				if (ProcessLogin.smethod_36(text2))
				{
					throw ProcessLogin.smethod_30(<Module>.smethod_24<string>(2243708455U));
				}
				TimezoneManager.SetTime(ProcessLogin.smethod_37(text2));
			}
			finally
			{
				if (socksWebClient != null)
				{
					ProcessLogin.smethod_38(socksWebClient);
				}
			}
		}

		// Token: 0x060003F4 RID: 1012 RVA: 0x0002EE88 File Offset: 0x0002D088
		private static string CalculateMd5Hash(string input)
		{
			HashAlgorithm hashAlgorithm = ProcessLogin.smethod_39();
			byte[] array = ProcessLogin.smethod_41(ProcessLogin.smethod_40(), input);
			byte[] array2 = ProcessLogin.smethod_42(hashAlgorithm, array);
			StringBuilder stringBuilder = ProcessLogin.smethod_43();
			for (int i = 0; i < array2.Length; i++)
			{
				stringBuilder.Append(array2[i].ToString(<Module>.smethod_25<string>(2009488885U)));
			}
			return stringBuilder.ToString();
		}

		// Token: 0x060003F5 RID: 1013 RVA: 0x0002EEE4 File Offset: 0x0002D0E4
		private static string DecryptRj256(string prmKey, string prmIv, string prmTextToDecrypt)
		{
			RijndaelManaged rijndaelManaged = ProcessLogin.smethod_44();
			ProcessLogin.smethod_45(rijndaelManaged, PaddingMode.Zeros);
			ProcessLogin.smethod_46(rijndaelManaged, CipherMode.CBC);
			ProcessLogin.smethod_47(rijndaelManaged, 256);
			ProcessLogin.smethod_48(rijndaelManaged, 256);
			byte[] array = ProcessLogin.smethod_41(ProcessLogin.smethod_40(), prmKey);
			byte[] array2 = ProcessLogin.smethod_41(ProcessLogin.smethod_40(), prmIv);
			ICryptoTransform cryptoTransform = ProcessLogin.smethod_49(rijndaelManaged, array, array2);
			byte[] array3 = ProcessLogin.smethod_50(prmTextToDecrypt);
			byte[] array4 = new byte[array3.Length];
			ProcessLogin.smethod_53(ProcessLogin.smethod_52(ProcessLogin.smethod_51(array3), cryptoTransform, CryptoStreamMode.Read), array4, 0, array4.Length);
			return ProcessLogin.smethod_54(ProcessLogin.smethod_40(), array4);
		}

		// Token: 0x060003F6 RID: 1014 RVA: 0x0002EF6C File Offset: 0x0002D16C
		private static string EncryptRj256(string prmKey, string prmIv, string prmTextToEncrypt)
		{
			RijndaelManaged rijndaelManaged = ProcessLogin.smethod_44();
			ProcessLogin.smethod_45(rijndaelManaged, PaddingMode.Zeros);
			ProcessLogin.smethod_46(rijndaelManaged, CipherMode.CBC);
			ProcessLogin.smethod_47(rijndaelManaged, 256);
			ProcessLogin.smethod_48(rijndaelManaged, 256);
			byte[] array = ProcessLogin.smethod_41(ProcessLogin.smethod_40(), prmKey);
			byte[] array2 = ProcessLogin.smethod_41(ProcessLogin.smethod_40(), prmIv);
			ICryptoTransform cryptoTransform = ProcessLogin.smethod_55(rijndaelManaged, array, array2);
			MemoryStream memoryStream = ProcessLogin.smethod_56();
			CryptoStream cryptoStream = ProcessLogin.smethod_52(memoryStream, cryptoTransform, CryptoStreamMode.Write);
			byte[] array3 = ProcessLogin.smethod_41(ProcessLogin.smethod_40(), prmTextToEncrypt);
			ProcessLogin.smethod_57(cryptoStream, array3, 0, array3.Length);
			ProcessLogin.smethod_58(cryptoStream);
			return ProcessLogin.smethod_60(ProcessLogin.smethod_59(memoryStream));
		}

		// Token: 0x060003F7 RID: 1015 RVA: 0x0000C65F File Offset: 0x0000A85F
		static Assembly smethod_0()
		{
			return Assembly.GetExecutingAssembly();
		}

		// Token: 0x060003F8 RID: 1016 RVA: 0x0000C666 File Offset: 0x0000A866
		static string smethod_1(Assembly assembly_0)
		{
			return assembly_0.Location;
		}

		// Token: 0x060003F9 RID: 1017 RVA: 0x0000C66E File Offset: 0x0000A86E
		static string smethod_2(string string_0)
		{
			return Path.GetDirectoryName(string_0);
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x0000D7DF File Offset: 0x0000B9DF
		static Process[] smethod_3(string string_0)
		{
			return Process.GetProcessesByName(string_0);
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x0000C775 File Offset: 0x0000A975
		static Process smethod_4()
		{
			return new Process();
		}

		// Token: 0x060003FC RID: 1020 RVA: 0x0000D9CB File Offset: 0x0000BBCB
		static ProcessStartInfo smethod_5()
		{
			return new ProcessStartInfo();
		}

		// Token: 0x060003FD RID: 1021 RVA: 0x0000C784 File Offset: 0x0000A984
		static string smethod_6(string string_0, string string_1, string string_2)
		{
			return Path.Combine(string_0, string_1, string_2);
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x0000C78E File Offset: 0x0000A98E
		static void smethod_7(ProcessStartInfo processStartInfo_0, string string_0)
		{
			processStartInfo_0.FileName = string_0;
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x0000C656 File Offset: 0x0000A856
		static string smethod_8(string string_0, string string_1)
		{
			return Path.Combine(string_0, string_1);
		}

		// Token: 0x06000400 RID: 1024 RVA: 0x0000C7A0 File Offset: 0x0000A9A0
		static void smethod_9(ProcessStartInfo processStartInfo_0, string string_0)
		{
			processStartInfo_0.WorkingDirectory = string_0;
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x0000C676 File Offset: 0x0000A876
		static string smethod_10(string string_0, string string_1, string string_2, string string_3)
		{
			return Path.Combine(string_0, string_1, string_2, string_3);
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_11(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x0000C797 File Offset: 0x0000A997
		static void smethod_12(ProcessStartInfo processStartInfo_0, string string_0)
		{
			processStartInfo_0.Arguments = string_0;
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x0000C7A9 File Offset: 0x0000A9A9
		static void smethod_13(ProcessStartInfo processStartInfo_0, ProcessWindowStyle processWindowStyle_0)
		{
			processStartInfo_0.WindowStyle = processWindowStyle_0;
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x0000C7B2 File Offset: 0x0000A9B2
		static void smethod_14(ProcessStartInfo processStartInfo_0, bool bool_0)
		{
			processStartInfo_0.UseShellExecute = bool_0;
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x0000C7BB File Offset: 0x0000A9BB
		static void smethod_15(ProcessStartInfo processStartInfo_0, bool bool_0)
		{
			processStartInfo_0.RedirectStandardOutput = bool_0;
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x0000C7C4 File Offset: 0x0000A9C4
		static void smethod_16(ProcessStartInfo processStartInfo_0, bool bool_0)
		{
			processStartInfo_0.CreateNoWindow = bool_0;
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x0000D9D2 File Offset: 0x0000BBD2
		static void smethod_17(Process process_0, ProcessStartInfo processStartInfo_0)
		{
			process_0.StartInfo = processStartInfo_0;
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x0000D9DB File Offset: 0x0000BBDB
		static void smethod_18(Process process_0, DataReceivedEventHandler dataReceivedEventHandler_0)
		{
			process_0.OutputDataReceived += dataReceivedEventHandler_0;
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x0000C7CD File Offset: 0x0000A9CD
		static bool smethod_19(Process process_0)
		{
			return process_0.Start();
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x0000D9E4 File Offset: 0x0000BBE4
		static void smethod_20(Process process_0)
		{
			process_0.BeginOutputReadLine();
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x0000D9EC File Offset: 0x0000BBEC
		static TcpClient smethod_21()
		{
			return new TcpClient();
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x0000D9F3 File Offset: 0x0000BBF3
		static void smethod_22(TcpClient tcpClient_0, string string_0, int int_0)
		{
			tcpClient_0.Connect(string_0, int_0);
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x0000D9FD File Offset: 0x0000BBFD
		static bool smethod_23(TcpClient tcpClient_0)
		{
			return tcpClient_0.Connected;
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x0000C7D5 File Offset: 0x0000A9D5
		static void smethod_24(int int_0)
		{
			Thread.Sleep(int_0);
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x0000DA05 File Offset: 0x0000BC05
		static void smethod_25(Process process_0)
		{
			process_0.Kill();
		}

		// Token: 0x06000411 RID: 1041 RVA: 0x0000C7F5 File Offset: 0x0000A9F5
		static Assembly smethod_26()
		{
			return Assembly.GetEntryAssembly();
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x0000C7FC File Offset: 0x0000A9FC
		static AssemblyName smethod_27(Assembly assembly_0)
		{
			return assembly_0.GetName();
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x0000C804 File Offset: 0x0000AA04
		static Version smethod_28(AssemblyName assemblyName_0)
		{
			return assemblyName_0.Version;
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_29(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_30(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x0000DA0D File Offset: 0x0000BC0D
		static WebHeaderCollection smethod_31(WebClient webClient_0)
		{
			return webClient_0.Headers;
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x0000DA15 File Offset: 0x0000BC15
		static void smethod_32(WebHeaderCollection webHeaderCollection_0, HttpRequestHeader httpRequestHeader_0, string string_0)
		{
			webHeaderCollection_0[httpRequestHeader_0] = string_0;
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x0000DA1F File Offset: 0x0000BC1F
		static string smethod_33(string string_0)
		{
			return Uri.EscapeDataString(string_0);
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_34(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x0600041A RID: 1050 RVA: 0x0000DA27 File Offset: 0x0000BC27
		static string smethod_35(WebClient webClient_0, string string_0)
		{
			return webClient_0.DownloadString(string_0);
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_36(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x0000DA30 File Offset: 0x0000BC30
		static DateTime smethod_37(string string_0)
		{
			return Convert.ToDateTime(string_0);
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_38(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x0000DA38 File Offset: 0x0000BC38
		static MD5 smethod_39()
		{
			return MD5.Create();
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x0000C3FB File Offset: 0x0000A5FB
		static Encoding smethod_40()
		{
			return Encoding.ASCII;
		}

		// Token: 0x06000420 RID: 1056 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_41(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x06000421 RID: 1057 RVA: 0x0000DA3F File Offset: 0x0000BC3F
		static byte[] smethod_42(HashAlgorithm hashAlgorithm_0, byte[] byte_0)
		{
			return hashAlgorithm_0.ComputeHash(byte_0);
		}

		// Token: 0x06000422 RID: 1058 RVA: 0x0000DA48 File Offset: 0x0000BC48
		static StringBuilder smethod_43()
		{
			return new StringBuilder();
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x0000C83A File Offset: 0x0000AA3A
		static RijndaelManaged smethod_44()
		{
			return new RijndaelManaged();
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x0000C841 File Offset: 0x0000AA41
		static void smethod_45(SymmetricAlgorithm symmetricAlgorithm_0, PaddingMode paddingMode_0)
		{
			symmetricAlgorithm_0.Padding = paddingMode_0;
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x0000C84A File Offset: 0x0000AA4A
		static void smethod_46(SymmetricAlgorithm symmetricAlgorithm_0, CipherMode cipherMode_0)
		{
			symmetricAlgorithm_0.Mode = cipherMode_0;
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x0000C853 File Offset: 0x0000AA53
		static void smethod_47(SymmetricAlgorithm symmetricAlgorithm_0, int int_0)
		{
			symmetricAlgorithm_0.KeySize = int_0;
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x0000C85C File Offset: 0x0000AA5C
		static void smethod_48(SymmetricAlgorithm symmetricAlgorithm_0, int int_0)
		{
			symmetricAlgorithm_0.BlockSize = int_0;
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x0000C865 File Offset: 0x0000AA65
		static ICryptoTransform smethod_49(SymmetricAlgorithm symmetricAlgorithm_0, byte[] byte_0, byte[] byte_1)
		{
			return symmetricAlgorithm_0.CreateDecryptor(byte_0, byte_1);
		}

		// Token: 0x06000429 RID: 1065 RVA: 0x0000C86F File Offset: 0x0000AA6F
		static byte[] smethod_50(string string_0)
		{
			return Convert.FromBase64String(string_0);
		}

		// Token: 0x0600042A RID: 1066 RVA: 0x0000C877 File Offset: 0x0000AA77
		static MemoryStream smethod_51(byte[] byte_0)
		{
			return new MemoryStream(byte_0);
		}

		// Token: 0x0600042B RID: 1067 RVA: 0x0000C87F File Offset: 0x0000AA7F
		static CryptoStream smethod_52(Stream stream_0, ICryptoTransform icryptoTransform_0, CryptoStreamMode cryptoStreamMode_0)
		{
			return new CryptoStream(stream_0, icryptoTransform_0, cryptoStreamMode_0);
		}

		// Token: 0x0600042C RID: 1068 RVA: 0x0000C889 File Offset: 0x0000AA89
		static int smethod_53(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			return stream_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x0600042D RID: 1069 RVA: 0x0000C894 File Offset: 0x0000AA94
		static string smethod_54(Encoding encoding_0, byte[] byte_0)
		{
			return encoding_0.GetString(byte_0);
		}

		// Token: 0x0600042E RID: 1070 RVA: 0x0000C89D File Offset: 0x0000AA9D
		static ICryptoTransform smethod_55(SymmetricAlgorithm symmetricAlgorithm_0, byte[] byte_0, byte[] byte_1)
		{
			return symmetricAlgorithm_0.CreateEncryptor(byte_0, byte_1);
		}

		// Token: 0x0600042F RID: 1071 RVA: 0x0000C8A7 File Offset: 0x0000AAA7
		static MemoryStream smethod_56()
		{
			return new MemoryStream();
		}

		// Token: 0x06000430 RID: 1072 RVA: 0x0000C8AE File Offset: 0x0000AAAE
		static void smethod_57(Stream stream_0, byte[] byte_0, int int_0, int int_1)
		{
			stream_0.Write(byte_0, int_0, int_1);
		}

		// Token: 0x06000431 RID: 1073 RVA: 0x0000C8B9 File Offset: 0x0000AAB9
		static void smethod_58(CryptoStream cryptoStream_0)
		{
			cryptoStream_0.FlushFinalBlock();
		}

		// Token: 0x06000432 RID: 1074 RVA: 0x0000C8C1 File Offset: 0x0000AAC1
		static byte[] smethod_59(MemoryStream memoryStream_0)
		{
			return memoryStream_0.ToArray();
		}

		// Token: 0x06000433 RID: 1075 RVA: 0x0000C8C9 File Offset: 0x0000AAC9
		static string smethod_60(byte[] byte_0)
		{
			return Convert.ToBase64String(byte_0);
		}

		// Token: 0x04000117 RID: 279
		private const string LoginServer = "krtuoy4u4b2f547u.onion";

		// Token: 0x04000118 RID: 280
		private const string LoginKey = "f2RxsiYmqHgKzBzlGgPREbjq6J4FtIy7";

		// Token: 0x04000119 RID: 281
		private const string LoginIv = "dzRrmdq25XwU3AHFq3mgfRdezftr9bOU";

		// Token: 0x0400011A RID: 282
		private readonly string _username;

		// Token: 0x0400011B RID: 283
		private readonly string _password;
	}
}
