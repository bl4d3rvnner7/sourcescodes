﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Reflection;
using System.Windows.Forms;
using FraudFox.Properties;

namespace FraudFox
{
	// Token: 0x0200002E RID: 46
	public partial class Login : Form
	{
		// Token: 0x060002CA RID: 714 RVA: 0x0000D361 File Offset: 0x0000B561
		public Login()
		{
			this.InitializeComponent();
		}

		// Token: 0x060002CB RID: 715 RVA: 0x00027B9C File Offset: 0x00025D9C
		private void btnLogin_Click(object sender, EventArgs e)
		{
			if (Login.smethod_1(Login.smethod_0(this.txtUsername)) < 1 || Login.smethod_1(Login.smethod_0(this.txtPassword)) < 1)
			{
				Login.ShowError(<Module>.smethod_27<string>(1625376119U));
				return;
			}
			this.DisableUi();
			if (Login.smethod_2(this.cbConnection) != 0)
			{
				this.UpdateStatus(<Module>.smethod_23<string>(675190163U));
				Login.smethod_3(this.bwDirectLogin);
				return;
			}
			this.UpdateStatus(<Module>.smethod_25<string>(2876690727U));
			Login.smethod_3(this.bwTorLogin);
		}

		// Token: 0x060002CC RID: 716 RVA: 0x00027C2C File Offset: 0x00025E2C
		private void bwTorLogin_DoWork(object sender, DoWorkEventArgs e)
		{
			if (ProcessLogin.StartProxy(60, new DataReceivedEventHandler(this.TorOutputHandler)))
			{
				ProcessLogin processLogin = new ProcessLogin(Login.smethod_0(this.txtUsername), Login.smethod_0(this.txtPassword));
				try
				{
					bool flag = processLogin != null;
					string text = "";
					if (!flag)
					{
						text = processLogin.GetNewsUsingTor();
						ProcessLogin.StopProxy();
					}
					this.LoginDone(flag, text);
					return;
				}
				catch (FormatException ex)
				{
					Login.ShowError(Login.smethod_4(ex));
					LogManager.AddEntry(Login.smethod_4(ex), ex);
					return;
				}
				catch (ApplicationException ex2)
				{
					Login.ShowError(Login.smethod_5(<Module>.smethod_24<string>(1575051762U), Login.smethod_4(ex2)));
					LogManager.AddEntry(Login.smethod_5(<Module>.smethod_23<string>(868471915U), Login.smethod_4(ex2)), ex2);
					return;
				}
				catch (WebException ex3)
				{
					Login.ShowError(<Module>.smethod_25<string>(182464850U));
					for (;;)
					{
						IL_00F8:
						int num = 1131852515;
						for (;;)
						{
							switch (num ^ 1131852514)
							{
							case 0:
								goto IL_00F8;
							case 1:
								LogManager.AddEntry(<Module>.smethod_25<string>(3970175185U), ex3);
								num = 1131852512;
								continue;
							}
							goto Block_9;
						}
					}
					Block_9:
					return;
				}
				catch (Exception ex4)
				{
					Login.ShowError(Login.smethod_7(<Module>.smethod_25<string>(440779872U), Login.smethod_4(ex4), Login.smethod_6(ex4)));
					for (;;)
					{
						IL_016E:
						int num2 = 1131852512;
						for (;;)
						{
							switch (num2 ^ 1131852514)
							{
							case 0:
								goto IL_016E;
							case 2:
								LogManager.AddEntry(Login.smethod_7(<Module>.smethod_26<string>(1347566029U), Login.smethod_4(ex4), Login.smethod_6(ex4)), ex4);
								num2 = 1131852515;
								continue;
							}
							goto Block_11;
						}
					}
					Block_11:
					return;
				}
				finally
				{
					this.UpdateStatus("");
					this.EnableUi();
				}
			}
			Login.ShowError(<Module>.smethod_25<string>(649572231U));
		}

		// Token: 0x060002CD RID: 717 RVA: 0x00027E50 File Offset: 0x00026050
		public void TorOutputHandler(object sender, DataReceivedEventArgs e)
		{
			if (Login.smethod_9(Login.smethod_8(e)))
			{
				return;
			}
			if (!Login.smethod_10(this.statusLabel))
			{
				string text = Login.smethod_8(e);
				if (Login.smethod_12(text, <Module>.smethod_27<string>(3174985695U)))
				{
					string text2 = text;
					text = Login.smethod_14(text2, Login.smethod_13(text2, <Module>.smethod_24<string>(1541009350U), StringComparison.Ordinal) + 2);
				}
				LogManager.AddEntry(Login.smethod_15(<Module>.smethod_25<string>(1971923838U), text), null);
				this.UpdateStatus(text);
				return;
			}
			Login.smethod_11(this, new Action(delegate
			{
				this.TorOutputHandler(sender, e);
			}));
		}

		// Token: 0x060002CE RID: 718 RVA: 0x00027F04 File Offset: 0x00026104
		private void bwDirectLogin_DoWork(object sender, DoWorkEventArgs e)
		{
			ProcessLogin processLogin = new ProcessLogin(Login.smethod_0(this.txtUsername), Login.smethod_0(this.txtPassword));
			try
			{
				bool flag = processLogin != null;
				string text = "";
				if (!flag)
				{
					text = processLogin;
				}
				this.LoginDone(flag, text);
			}
			catch (FormatException ex)
			{
				Login.ShowError(Login.smethod_4(ex));
				LogManager.AddEntry(Login.smethod_4(ex), ex);
			}
			catch (ApplicationException ex2)
			{
				Login.ShowError(Login.smethod_5(<Module>.smethod_27<string>(2365551667U), Login.smethod_4(ex2)));
				LogManager.AddEntry(Login.smethod_5(<Module>.smethod_24<string>(1575051762U), Login.smethod_4(ex2)), ex2);
			}
			catch (WebException ex3)
			{
				Login.ShowError(<Module>.smethod_27<string>(3408094160U));
				for (Exception ex4 = ex3; ex4 != null; ex4 = Login.smethod_16(ex4))
				{
					LogManager.AddEntry(<Module>.smethod_26<string>(3480685086U), ex4);
				}
			}
			catch (Exception ex5)
			{
				for (;;)
				{
					IL_0132:
					int num = -1176187668;
					for (;;)
					{
						switch (num ^ -1176187666)
						{
						case 0:
							goto IL_0132;
						case 2:
							Login.ShowError(Login.smethod_7(<Module>.smethod_26<string>(1347566029U), Login.smethod_4(ex5), Login.smethod_6(ex5)));
							LogManager.AddEntry(Login.smethod_7(<Module>.smethod_25<string>(440779872U), Login.smethod_4(ex5), Login.smethod_6(ex5)), ex5);
							num = -1176187665;
							continue;
						}
						goto Block_10;
					}
				}
				Block_10:;
			}
			finally
			{
				this.UpdateStatus("");
				this.EnableUi();
			}
		}

		// Token: 0x060002CF RID: 719 RVA: 0x000280DC File Offset: 0x000262DC
		private void LoginDone(bool result, string newsHtml)
		{
			if (this.method_0())
			{
				Login.smethod_11(this, new Action(delegate
				{
					this.LoginDone(result, newsHtml);
				}));
				return;
			}
			if (result)
			{
				ControlCenter controlCenter = new ControlCenter((int)Math.Truncate(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds));
				controlCenter.Username = this.txtUsername.Text;
				controlCenter.NewsHtml = newsHtml;
				base.Hide();
				controlCenter.Show();
				return;
			}
			Login.ShowError(<Module>.smethod_27<string>(2283401988U));
			this.UpdateStatus("");
			this.txtPassword.Text = string.Empty;
		}

		// Token: 0x060002D0 RID: 720 RVA: 0x000281AC File Offset: 0x000263AC
		private void DisableUi()
		{
			if (this.method_0())
			{
				Login.smethod_11(this, new Action(this.DisableUi));
				return;
			}
			Login.smethod_17(this.txtUsername, false);
			Login.smethod_17(this.txtPassword, false);
			Login.smethod_17(this.cbConnection, false);
			Login.smethod_17(this.btnLogin, false);
		}

		// Token: 0x060002D1 RID: 721 RVA: 0x00028208 File Offset: 0x00026408
		private void EnableUi()
		{
			if (this.method_0())
			{
				Login.smethod_11(this, new Action(this.EnableUi));
				return;
			}
			Login.smethod_17(this.txtUsername, true);
			Login.smethod_17(this.txtPassword, true);
			Login.smethod_17(this.cbConnection, true);
			Login.smethod_17(this.btnLogin, true);
		}

		// Token: 0x060002D2 RID: 722 RVA: 0x00028264 File Offset: 0x00026464
		private void UpdateStatus(string message)
		{
			if (!this.method_0())
			{
				Login.smethod_18(this.statusLabel, message);
				return;
			}
			Login.smethod_11(this, new Action(delegate
			{
				this.UpdateStatus(message);
			}));
		}

		// Token: 0x060002D3 RID: 723 RVA: 0x0000D36F File Offset: 0x0000B56F
		public static void ShowError(string message)
		{
			Login.smethod_19(message, <Module>.smethod_26<string>(407498489U), MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x060002D4 RID: 724 RVA: 0x000282B4 File Offset: 0x000264B4
		private void Login_Load(object sender, EventArgs e)
		{
			Login.smethod_18(this, Login.smethod_5(<Module>.smethod_25<string>(1882251595U), Login.smethod_22(Login.smethod_21(Login.smethod_20()))));
			this.txtPassword.Text = "Cracked By NoNh";
			this.txtPassword.Enabled = false;
			this.txtUsername.Text = "Cracked By NoNh";
			this.txtUsername.Enabled = false;
			Login.smethod_23(this.cbConnection, 0);
		}

		// Token: 0x060002D5 RID: 725 RVA: 0x0000D385 File Offset: 0x0000B585
		private void Login_FormClosed(object sender, FormClosedEventArgs e)
		{
			LogManager.Flush();
			ProcessLogin.StopProxy();
			Login.smethod_24();
		}

		// Token: 0x060002D6 RID: 726 RVA: 0x0000D396 File Offset: 0x0000B596
		private void Login_KeyDown(object sender, KeyEventArgs e)
		{
			if (Login.smethod_25(e) == Keys.Return)
			{
				Login.smethod_26(this.btnLogin);
			}
		}

		// Token: 0x060002D7 RID: 727 RVA: 0x0000D3AD File Offset: 0x0000B5AD
		private void statusLabel_DoubleClick(object sender, EventArgs e)
		{
			LogManager.ShowLogWindow();
		}

		// Token: 0x060002DA RID: 730 RVA: 0x0000D09A File Offset: 0x0000B29A
		static string smethod_0(Control control_0)
		{
			return control_0.Text;
		}

		// Token: 0x060002DB RID: 731 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_1(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x060002DC RID: 732 RVA: 0x0000D3D3 File Offset: 0x0000B5D3
		static int smethod_2(ListControl listControl_0)
		{
			return listControl_0.SelectedIndex;
		}

		// Token: 0x060002DD RID: 733 RVA: 0x0000D3DB File Offset: 0x0000B5DB
		static void smethod_3(BackgroundWorker backgroundWorker_0)
		{
			backgroundWorker_0.RunWorkerAsync();
		}

		// Token: 0x060002DE RID: 734 RVA: 0x0000D3E3 File Offset: 0x0000B5E3
		static string smethod_4(Exception exception_0)
		{
			return exception_0.Message;
		}

		// Token: 0x060002DF RID: 735 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_5(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x060002E0 RID: 736 RVA: 0x0000D3EB File Offset: 0x0000B5EB
		static string smethod_6(Exception exception_0)
		{
			return exception_0.StackTrace;
		}

		// Token: 0x060002E1 RID: 737 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_7(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x060002E2 RID: 738 RVA: 0x0000D3F3 File Offset: 0x0000B5F3
		static string smethod_8(DataReceivedEventArgs dataReceivedEventArgs_0)
		{
			return dataReceivedEventArgs_0.Data;
		}

		// Token: 0x060002E3 RID: 739 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_9(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x060002E4 RID: 740 RVA: 0x0000D3FB File Offset: 0x0000B5FB
		static bool smethod_10(Control control_0)
		{
			return control_0.InvokeRequired;
		}

		// Token: 0x060002E5 RID: 741 RVA: 0x0000D403 File Offset: 0x0000B603
		static IAsyncResult smethod_11(Control control_0, Delegate delegate_0)
		{
			return control_0.BeginInvoke(delegate_0);
		}

		// Token: 0x060002E6 RID: 742 RVA: 0x0000CD7D File Offset: 0x0000AF7D
		static bool smethod_12(string string_0, string string_1)
		{
			return string_0.Contains(string_1);
		}

		// Token: 0x060002E7 RID: 743 RVA: 0x0000D40C File Offset: 0x0000B60C
		static int smethod_13(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.IndexOf(string_1, stringComparison_0);
		}

		// Token: 0x060002E8 RID: 744 RVA: 0x0000D416 File Offset: 0x0000B616
		static string smethod_14(string string_0, int int_0)
		{
			return string_0.Substring(int_0);
		}

		// Token: 0x060002E9 RID: 745 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_15(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x060002EA RID: 746 RVA: 0x0000D428 File Offset: 0x0000B628
		static Exception smethod_16(Exception exception_0)
		{
			return exception_0.InnerException;
		}

		// Token: 0x060002EB RID: 747 RVA: 0x0000D430 File Offset: 0x0000B630
		bool method_0()
		{
			return base.InvokeRequired;
		}

		// Token: 0x060002EC RID: 748 RVA: 0x0000D165 File Offset: 0x0000B365
		static void smethod_17(Control control_0, bool bool_0)
		{
			control_0.Enabled = bool_0;
		}

		// Token: 0x060002ED RID: 749 RVA: 0x0000C816 File Offset: 0x0000AA16
		static void smethod_18(Control control_0, string string_0)
		{
			control_0.Text = string_0;
		}

		// Token: 0x060002EE RID: 750 RVA: 0x0000C81F File Offset: 0x0000AA1F
		static DialogResult smethod_19(string string_0, string string_1, MessageBoxButtons messageBoxButtons_0, MessageBoxIcon messageBoxIcon_0)
		{
			return MessageBox.Show(string_0, string_1, messageBoxButtons_0, messageBoxIcon_0);
		}

		// Token: 0x060002EF RID: 751 RVA: 0x0000C7F5 File Offset: 0x0000A9F5
		static Assembly smethod_20()
		{
			return Assembly.GetEntryAssembly();
		}

		// Token: 0x060002F0 RID: 752 RVA: 0x0000C7FC File Offset: 0x0000A9FC
		static AssemblyName smethod_21(Assembly assembly_0)
		{
			return assembly_0.GetName();
		}

		// Token: 0x060002F1 RID: 753 RVA: 0x0000C804 File Offset: 0x0000AA04
		static Version smethod_22(AssemblyName assemblyName_0)
		{
			return assemblyName_0.Version;
		}

		// Token: 0x060002F2 RID: 754 RVA: 0x0000D15C File Offset: 0x0000B35C
		static void smethod_23(ListControl listControl_0, int int_0)
		{
			listControl_0.SelectedIndex = int_0;
		}

		// Token: 0x060002F3 RID: 755 RVA: 0x0000D438 File Offset: 0x0000B638
		static void smethod_24()
		{
			Application.Exit();
		}

		// Token: 0x060002F4 RID: 756 RVA: 0x0000D43F File Offset: 0x0000B63F
		static Keys smethod_25(KeyEventArgs keyEventArgs_0)
		{
			return keyEventArgs_0.KeyCode;
		}

		// Token: 0x060002F5 RID: 757 RVA: 0x0000D447 File Offset: 0x0000B647
		static void smethod_26(Button button_0)
		{
			button_0.PerformClick();
		}

		// Token: 0x060002F6 RID: 758 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_27(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060002F7 RID: 759 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_28(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x060002F8 RID: 760 RVA: 0x0000C8E9 File Offset: 0x0000AAE9
		static ComponentResourceManager smethod_29(Type type_0)
		{
			return new ComponentResourceManager(type_0);
		}

		// Token: 0x060002F9 RID: 761 RVA: 0x0000D186 File Offset: 0x0000B386
		static Label smethod_30()
		{
			return new Label();
		}

		// Token: 0x060002FA RID: 762 RVA: 0x0000D0C7 File Offset: 0x0000B2C7
		static TextBox smethod_31()
		{
			return new TextBox();
		}

		// Token: 0x060002FB RID: 763 RVA: 0x0000C8F8 File Offset: 0x0000AAF8
		static Button smethod_32()
		{
			return new Button();
		}

		// Token: 0x060002FC RID: 764 RVA: 0x0000D44F File Offset: 0x0000B64F
		static PictureBox smethod_33()
		{
			return new PictureBox();
		}

		// Token: 0x060002FD RID: 765 RVA: 0x0000D456 File Offset: 0x0000B656
		static BackgroundWorker smethod_34()
		{
			return new BackgroundWorker();
		}

		// Token: 0x060002FE RID: 766 RVA: 0x0000D194 File Offset: 0x0000B394
		static ComboBox smethod_35()
		{
			return new ComboBox();
		}

		// Token: 0x060002FF RID: 767 RVA: 0x0000D19B File Offset: 0x0000B39B
		static void smethod_36(ISupportInitialize isupportInitialize_0)
		{
			isupportInitialize_0.BeginInit();
		}

		// Token: 0x06000300 RID: 768 RVA: 0x0000C907 File Offset: 0x0000AB07
		static void smethod_37(Control control_0)
		{
			control_0.SuspendLayout();
		}

		// Token: 0x06000301 RID: 769 RVA: 0x0000D1A3 File Offset: 0x0000B3A3
		static void smethod_38(Control control_0, bool bool_0)
		{
			control_0.AutoSize = bool_0;
		}
	}
}
