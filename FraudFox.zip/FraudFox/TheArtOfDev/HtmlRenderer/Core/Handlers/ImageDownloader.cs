﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Threading;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Handlers
{
	// Token: 0x0200009C RID: 156
	internal sealed class ImageDownloader : IDisposable
	{
		// Token: 0x06000810 RID: 2064 RVA: 0x00042260 File Offset: 0x00040460
		public void DownloadImage(Uri imageUri, string filePath, bool async, DownloadFileAsyncCallback cachedFileCallback)
		{
			ArgChecker.AssertArgNotNull(imageUri, <Module>.smethod_25<string>(8725720U));
			ArgChecker.AssertArgNotNull(cachedFileCallback, <Module>.smethod_27<string>(1463702690U));
			bool flag = true;
			bool flag2 = false;
			try
			{
				Dictionary<string, List<DownloadFileAsyncCallback>> imageDownloadCallbacks;
				ImageDownloader.smethod_0(imageDownloadCallbacks = this._imageDownloadCallbacks, ref flag2);
				if (this._imageDownloadCallbacks.ContainsKey(filePath))
				{
					flag = false;
					this._imageDownloadCallbacks[filePath].Add(cachedFileCallback);
				}
				else
				{
					this._imageDownloadCallbacks[filePath] = new List<DownloadFileAsyncCallback> { cachedFileCallback };
				}
			}
			finally
			{
				if (flag2)
				{
					Dictionary<string, List<DownloadFileAsyncCallback>> imageDownloadCallbacks;
					ImageDownloader.smethod_1(imageDownloadCallbacks);
				}
			}
			if (flag)
			{
				string text = ImageDownloader.smethod_2();
				if (async)
				{
					ImageDownloader.smethod_3(new WaitCallback(this.DownloadImageFromUrlAsync), new ImageDownloader.DownloadData(imageUri, text, filePath));
					return;
				}
				this.DownloadImageFromUrl(imageUri, text, filePath);
			}
		}

		// Token: 0x06000811 RID: 2065 RVA: 0x0000F931 File Offset: 0x0000DB31
		public void Dispose()
		{
			this.ReleaseObjects();
		}

		// Token: 0x06000812 RID: 2066 RVA: 0x00042330 File Offset: 0x00040530
		private void DownloadImageFromUrl(Uri source, string tempPath, string filePath)
		{
			try
			{
				WebClient webClient = ImageDownloader.smethod_4();
				try
				{
					this._clients.Add(webClient);
					ImageDownloader.smethod_5(webClient, source, tempPath);
					this.OnDownloadImageCompleted(webClient, source, tempPath, filePath, null, false);
				}
				finally
				{
					if (webClient != null)
					{
						ImageDownloader.smethod_6(webClient);
					}
				}
			}
			catch (Exception ex)
			{
				this.OnDownloadImageCompleted(null, source, tempPath, filePath, ex, false);
			}
		}

		// Token: 0x06000813 RID: 2067 RVA: 0x0004239C File Offset: 0x0004059C
		private void DownloadImageFromUrlAsync(object data)
		{
			ImageDownloader.DownloadData downloadData = (ImageDownloader.DownloadData)data;
			try
			{
				WebClient webClient = ImageDownloader.smethod_4();
				this._clients.Add(webClient);
				ImageDownloader.smethod_7(webClient, new AsyncCompletedEventHandler(this.OnDownloadImageAsyncCompleted));
				ImageDownloader.smethod_8(webClient, downloadData._uri, downloadData._tempPath, downloadData);
			}
			catch (Exception ex)
			{
				this.OnDownloadImageCompleted(null, downloadData._uri, downloadData._tempPath, downloadData._filePath, ex, false);
			}
		}

		// Token: 0x06000814 RID: 2068 RVA: 0x00042418 File Offset: 0x00040618
		private void OnDownloadImageAsyncCompleted(object sender, AsyncCompletedEventArgs e)
		{
			ImageDownloader.DownloadData downloadData = (ImageDownloader.DownloadData)ImageDownloader.smethod_9(e);
			try
			{
				WebClient webClient = (WebClient)sender;
				try
				{
					ImageDownloader.smethod_10(webClient, new AsyncCompletedEventHandler(this.OnDownloadImageAsyncCompleted));
					this.OnDownloadImageCompleted(webClient, downloadData._uri, downloadData._tempPath, downloadData._filePath, ImageDownloader.smethod_11(e), ImageDownloader.smethod_12(e));
				}
				finally
				{
					if (webClient != null)
					{
						ImageDownloader.smethod_6(webClient);
					}
				}
			}
			catch (Exception ex)
			{
				this.OnDownloadImageCompleted(null, downloadData._uri, downloadData._tempPath, downloadData._filePath, ex, false);
			}
		}

		// Token: 0x06000815 RID: 2069 RVA: 0x000424B8 File Offset: 0x000406B8
		private void OnDownloadImageCompleted(WebClient client, Uri source, string tempPath, string filePath, Exception error, bool cancelled)
		{
			if (!cancelled)
			{
				if (error == null)
				{
					string responseContentType = CommonUtils.GetResponseContentType(client);
					if (responseContentType == null || !ImageDownloader.smethod_13(responseContentType, <Module>.smethod_27<string>(780793169U), StringComparison.OrdinalIgnoreCase))
					{
						error = ImageDownloader.smethod_15(ImageDownloader.smethod_14(<Module>.smethod_26<string>(2031306084U), responseContentType));
					}
				}
				if (error == null)
				{
					if (ImageDownloader.smethod_16(tempPath))
					{
						try
						{
							ImageDownloader.smethod_17(tempPath, filePath);
						}
						catch (Exception ex)
						{
							error = ImageDownloader.smethod_18(<Module>.smethod_27<string>(2034256713U), ex);
						}
					}
					object obj;
					if (ImageDownloader.smethod_16(filePath))
					{
						obj = null;
						goto IL_0083;
					}
					goto IL_00BA;
					int num;
					for (;;)
					{
						IL_009D:
						switch (num ^ 1541091243)
						{
						case 0:
							goto IL_008C;
						case 2:
							goto IL_00BA;
						case 3:
							if ((obj = error) == null)
							{
								num = 1541091243;
								continue;
							}
							goto IL_0083;
						}
						goto Block_8;
					}
					IL_008C:
					obj = ImageDownloader.smethod_15(<Module>.smethod_24<string>(63959980U));
					goto IL_0083;
					Block_8:
					goto IL_00C1;
					IL_0083:
					error = obj;
					num = 1541091242;
					goto IL_009D;
					IL_00BA:
					num = 1541091240;
					goto IL_009D;
				}
			}
			IL_00C1:
			bool flag = false;
			List<DownloadFileAsyncCallback> list;
			try
			{
				Dictionary<string, List<DownloadFileAsyncCallback>> imageDownloadCallbacks;
				ImageDownloader.smethod_0(imageDownloadCallbacks = this._imageDownloadCallbacks, ref flag);
				if (this._imageDownloadCallbacks.TryGetValue(filePath, out list))
				{
					this._imageDownloadCallbacks.Remove(filePath);
				}
			}
			finally
			{
				if (flag)
				{
					Dictionary<string, List<DownloadFileAsyncCallback>> imageDownloadCallbacks;
					ImageDownloader.smethod_1(imageDownloadCallbacks);
				}
			}
			if (list != null)
			{
				foreach (DownloadFileAsyncCallback downloadFileAsyncCallback in list)
				{
					try
					{
						downloadFileAsyncCallback(source, filePath, error, cancelled);
					}
					catch
					{
					}
				}
			}
		}

		// Token: 0x06000816 RID: 2070 RVA: 0x0004263C File Offset: 0x0004083C
		private void ReleaseObjects()
		{
			this._imageDownloadCallbacks.Clear();
			while (this._clients.Count > 0)
			{
				try
				{
					WebClient webClient = this._clients[0];
					ImageDownloader.smethod_19(webClient);
					ImageDownloader.smethod_20(webClient);
					this._clients.RemoveAt(0);
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000818 RID: 2072 RVA: 0x0000DBD7 File Offset: 0x0000BDD7
		static void smethod_0(object object_0, ref bool bool_0)
		{
			Monitor.Enter(object_0, ref bool_0);
		}

		// Token: 0x06000819 RID: 2073 RVA: 0x0000DBEF File Offset: 0x0000BDEF
		static void smethod_1(object object_0)
		{
			Monitor.Exit(object_0);
		}

		// Token: 0x0600081A RID: 2074 RVA: 0x0000F957 File Offset: 0x0000DB57
		static string smethod_2()
		{
			return Path.GetTempFileName();
		}

		// Token: 0x0600081B RID: 2075 RVA: 0x0000F95E File Offset: 0x0000DB5E
		static bool smethod_3(WaitCallback waitCallback_0, object object_0)
		{
			return ThreadPool.QueueUserWorkItem(waitCallback_0, object_0);
		}

		// Token: 0x0600081C RID: 2076 RVA: 0x0000EE74 File Offset: 0x0000D074
		static WebClient smethod_4()
		{
			return new WebClient();
		}

		// Token: 0x0600081D RID: 2077 RVA: 0x0000F967 File Offset: 0x0000DB67
		static void smethod_5(WebClient webClient_0, Uri uri_0, string string_0)
		{
			webClient_0.DownloadFile(uri_0, string_0);
		}

		// Token: 0x0600081E RID: 2078 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_6(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x0600081F RID: 2079 RVA: 0x0000F971 File Offset: 0x0000DB71
		static void smethod_7(WebClient webClient_0, AsyncCompletedEventHandler asyncCompletedEventHandler_0)
		{
			webClient_0.DownloadFileCompleted += asyncCompletedEventHandler_0;
		}

		// Token: 0x06000820 RID: 2080 RVA: 0x0000F97A File Offset: 0x0000DB7A
		static void smethod_8(WebClient webClient_0, Uri uri_0, string string_0, object object_0)
		{
			webClient_0.DownloadFileAsync(uri_0, string_0, object_0);
		}

		// Token: 0x06000821 RID: 2081 RVA: 0x0000F985 File Offset: 0x0000DB85
		static object smethod_9(AsyncCompletedEventArgs asyncCompletedEventArgs_0)
		{
			return asyncCompletedEventArgs_0.UserState;
		}

		// Token: 0x06000822 RID: 2082 RVA: 0x0000F98D File Offset: 0x0000DB8D
		static void smethod_10(WebClient webClient_0, AsyncCompletedEventHandler asyncCompletedEventHandler_0)
		{
			webClient_0.DownloadFileCompleted -= asyncCompletedEventHandler_0;
		}

		// Token: 0x06000823 RID: 2083 RVA: 0x0000EE0B File Offset: 0x0000D00B
		static Exception smethod_11(AsyncCompletedEventArgs asyncCompletedEventArgs_0)
		{
			return asyncCompletedEventArgs_0.Error;
		}

		// Token: 0x06000824 RID: 2084 RVA: 0x0000EE03 File Offset: 0x0000D003
		static bool smethod_12(AsyncCompletedEventArgs asyncCompletedEventArgs_0)
		{
			return asyncCompletedEventArgs_0.Cancelled;
		}

		// Token: 0x06000825 RID: 2085 RVA: 0x0000F8C5 File Offset: 0x0000DAC5
		static bool smethod_13(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.StartsWith(string_1, stringComparison_0);
		}

		// Token: 0x06000826 RID: 2086 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_14(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x06000827 RID: 2087 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_15(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x06000828 RID: 2088 RVA: 0x0000C681 File Offset: 0x0000A881
		static bool smethod_16(string string_0)
		{
			return File.Exists(string_0);
		}

		// Token: 0x06000829 RID: 2089 RVA: 0x0000CD60 File Offset: 0x0000AF60
		static void smethod_17(string string_0, string string_1)
		{
			File.Move(string_0, string_1);
		}

		// Token: 0x0600082A RID: 2090 RVA: 0x0000F996 File Offset: 0x0000DB96
		static Exception smethod_18(string string_0, Exception exception_0)
		{
			return new Exception(string_0, exception_0);
		}

		// Token: 0x0600082B RID: 2091 RVA: 0x0000F99F File Offset: 0x0000DB9F
		static void smethod_19(WebClient webClient_0)
		{
			webClient_0.CancelAsync();
		}

		// Token: 0x0600082C RID: 2092 RVA: 0x0000EE5C File Offset: 0x0000D05C
		static void smethod_20(Component component_0)
		{
			component_0.Dispose();
		}

		// Token: 0x040002ED RID: 749
		private readonly List<WebClient> _clients = new List<WebClient>();

		// Token: 0x040002EE RID: 750
		private readonly Dictionary<string, List<DownloadFileAsyncCallback>> _imageDownloadCallbacks = new Dictionary<string, List<DownloadFileAsyncCallback>>();

		// Token: 0x0200009D RID: 157
		private sealed class DownloadData
		{
			// Token: 0x0600082D RID: 2093 RVA: 0x0000F9A7 File Offset: 0x0000DBA7
			public DownloadData(Uri uri, string tempPath, string filePath)
			{
				this._uri = uri;
				this._tempPath = tempPath;
				this._filePath = filePath;
			}

			// Token: 0x040002EF RID: 751
			public readonly Uri _uri;

			// Token: 0x040002F0 RID: 752
			public readonly string _tempPath;

			// Token: 0x040002F1 RID: 753
			public readonly string _filePath;
		}
	}
}
