﻿using System;
using System.Collections.Generic;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Handlers
{
	// Token: 0x0200009A RID: 154
	internal sealed class FontsHandler
	{
		// Token: 0x06000804 RID: 2052 RVA: 0x00042024 File Offset: 0x00040224
		public FontsHandler(RAdapter adapter)
		{
			ArgChecker.AssertArgNotNull(adapter, <Module>.smethod_26<string>(3421464142U));
			this._adapter = adapter;
		}

		// Token: 0x06000805 RID: 2053 RVA: 0x00042080 File Offset: 0x00040280
		public bool IsFontExists(string family)
		{
			bool flag;
			string text;
			if (!(flag = this._existingFontFamilies.ContainsKey(family)) && this._fontsMapping.TryGetValue(family, out text))
			{
				flag = this._existingFontFamilies.ContainsKey(text);
			}
			return flag;
		}

		// Token: 0x06000806 RID: 2054 RVA: 0x0000F8D7 File Offset: 0x0000DAD7
		public void AddFontFamily(RFontFamily fontFamily)
		{
			ArgChecker.AssertArgNotNull(fontFamily, <Module>.smethod_25<string>(2772549050U));
			this._existingFontFamilies[fontFamily.Name] = fontFamily;
		}

		// Token: 0x06000807 RID: 2055 RVA: 0x0000F8FB File Offset: 0x0000DAFB
		public void AddFontFamilyMapping(string fromFamily, string toFamily)
		{
			ArgChecker.AssertArgNotNullOrEmpty(fromFamily, <Module>.smethod_25<string>(3677315939U));
			ArgChecker.AssertArgNotNullOrEmpty(toFamily, <Module>.smethod_24<string>(612199325U));
			this._fontsMapping[fromFamily] = toFamily;
		}

		// Token: 0x06000808 RID: 2056 RVA: 0x000420BC File Offset: 0x000402BC
		public RFont GetCachedFont(string family, double size, RFontStyle style)
		{
			RFont rfont = this.TryGetFont(family, size, style);
			if (rfont == null)
			{
				string text;
				if (!this._existingFontFamilies.ContainsKey(family) && this._fontsMapping.TryGetValue(family, out text))
				{
					rfont = this.TryGetFont(text, size, style);
					if (rfont == null)
					{
						rfont = this.CreateFont(text, size, style);
						this._fontsCache[text][size][style] = rfont;
					}
				}
				if (rfont == null)
				{
					rfont = this.CreateFont(family, size, style);
				}
				this._fontsCache[family][size][style] = rfont;
			}
			return rfont;
		}

		// Token: 0x06000809 RID: 2057 RVA: 0x0004214C File Offset: 0x0004034C
		private RFont TryGetFont(string family, double size, RFontStyle style)
		{
			RFont rfont = null;
			if (this._fontsCache.ContainsKey(family))
			{
				Dictionary<double, Dictionary<RFontStyle, RFont>> dictionary = this._fontsCache[family];
				if (dictionary.ContainsKey(size))
				{
					Dictionary<RFontStyle, RFont> dictionary2 = dictionary[size];
					if (dictionary2.ContainsKey(style))
					{
						rfont = dictionary2[style];
					}
				}
				else
				{
					this._fontsCache[family][size] = new Dictionary<RFontStyle, RFont>();
				}
			}
			else
			{
				this._fontsCache[family] = new Dictionary<double, Dictionary<RFontStyle, RFont>>();
				this._fontsCache[family][size] = new Dictionary<RFontStyle, RFont>();
			}
			return rfont;
		}

		// Token: 0x0600080A RID: 2058 RVA: 0x000421DC File Offset: 0x000403DC
		private RFont CreateFont(string family, double size, RFontStyle style)
		{
			RFont rfont;
			try
			{
				RFontFamily rfontFamily;
				rfont = (this._existingFontFamilies.TryGetValue(family, out rfontFamily) ? this._adapter.CreateFont(rfontFamily, size, style) : this._adapter.CreateFont(family, size, style));
			}
			catch
			{
				RFontFamily rfontFamily;
				rfont = (this._existingFontFamilies.TryGetValue(family, out rfontFamily) ? this._adapter.CreateFont(rfontFamily, size, RFontStyle.Regular) : this._adapter.CreateFont(family, size, RFontStyle.Regular));
			}
			return rfont;
		}

		// Token: 0x0600080B RID: 2059 RVA: 0x0000F92A File Offset: 0x0000DB2A
		static StringComparer smethod_0()
		{
			return StringComparer.InvariantCultureIgnoreCase;
		}

		// Token: 0x040002E9 RID: 745
		private readonly RAdapter _adapter;

		// Token: 0x040002EA RID: 746
		private readonly Dictionary<string, string> _fontsMapping = new Dictionary<string, string>(FontsHandler.smethod_0());

		// Token: 0x040002EB RID: 747
		private readonly Dictionary<string, RFontFamily> _existingFontFamilies = new Dictionary<string, RFontFamily>(FontsHandler.smethod_0());

		// Token: 0x040002EC RID: 748
		private readonly Dictionary<string, Dictionary<double, Dictionary<RFontStyle, RFont>>> _fontsCache = new Dictionary<string, Dictionary<double, Dictionary<RFontStyle, RFont>>>(FontsHandler.smethod_0());
	}
}
