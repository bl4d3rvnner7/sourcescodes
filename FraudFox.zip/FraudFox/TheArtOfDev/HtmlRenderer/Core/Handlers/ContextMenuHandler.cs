﻿using System;
using System.Globalization;
using System.IO;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Core.Dom;
using TheArtOfDev.HtmlRenderer.Core.Entities;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Handlers
{
	// Token: 0x02000099 RID: 153
	internal sealed class ContextMenuHandler : IDisposable
	{
		// Token: 0x060007F2 RID: 2034 RVA: 0x000411DC File Offset: 0x0003F3DC
		static ContextMenuHandler()
		{
			if (ContextMenuHandler.smethod_2(ContextMenuHandler.smethod_1(ContextMenuHandler.smethod_0()), <Module>.smethod_23<string>(3044537765U), StringComparison.InvariantCultureIgnoreCase))
			{
				ContextMenuHandler._selectAll = <Module>.smethod_26<string>(2186945193U);
				ContextMenuHandler._copy = <Module>.smethod_23<string>(1691565501U);
				ContextMenuHandler._copyLink = <Module>.smethod_23<string>(2059314880U);
				ContextMenuHandler._openLink = <Module>.smethod_24<string>(4029168666U);
				ContextMenuHandler._copyImageLink = <Module>.smethod_27<string>(2599039196U);
				ContextMenuHandler._copyImage = <Module>.smethod_24<string>(194539742U);
				ContextMenuHandler._saveImage = <Module>.smethod_23<string>(2639160136U);
				ContextMenuHandler._openVideo = <Module>.smethod_25<string>(3009387943U);
				ContextMenuHandler._copyVideoUrl = <Module>.smethod_25<string>(3774959926U);
				return;
			}
			if (ContextMenuHandler.smethod_2(ContextMenuHandler.smethod_1(ContextMenuHandler.smethod_0()), <Module>.smethod_25<string>(106369707U), StringComparison.InvariantCultureIgnoreCase))
			{
				ContextMenuHandler._selectAll = <Module>.smethod_27<string>(2686511042U);
				ContextMenuHandler._copy = <Module>.smethod_26<string>(3510068493U);
				ContextMenuHandler._copyLink = <Module>.smethod_26<string>(4224300310U);
				ContextMenuHandler._openLink = <Module>.smethod_23<string>(145311485U);
				ContextMenuHandler._copyImageLink = <Module>.smethod_25<string>(871941690U);
				ContextMenuHandler._copyImage = <Module>.smethod_25<string>(1567916220U);
				ContextMenuHandler._saveImage = <Module>.smethod_23<string>(3143748892U);
				ContextMenuHandler._openVideo = <Module>.smethod_27<string>(868265015U);
				ContextMenuHandler._copyVideoUrl = <Module>.smethod_24<string>(1982034669U);
				return;
			}
			if (ContextMenuHandler.smethod_2(ContextMenuHandler.smethod_1(ContextMenuHandler.smethod_0()), <Module>.smethod_25<string>(2989313153U), StringComparison.InvariantCultureIgnoreCase))
			{
				ContextMenuHandler._selectAll = <Module>.smethod_24<string>(816453797U);
				ContextMenuHandler._copy = <Module>.smethod_24<string>(1222933608U);
				ContextMenuHandler._copyLink = <Module>.smethod_27<string>(2028035800U);
				ContextMenuHandler._openLink = <Module>.smethod_23<string>(2577577259U);
				ContextMenuHandler._copyImageLink = <Module>.smethod_24<string>(4122150846U);
				ContextMenuHandler._copyImage = <Module>.smethod_25<string>(155892370U);
				ContextMenuHandler._saveImage = <Module>.smethod_23<string>(4223042402U);
				ContextMenuHandler._openVideo = <Module>.smethod_26<string>(1692970438U);
				ContextMenuHandler._copyVideoUrl = <Module>.smethod_23<string>(4048574775U);
				return;
			}
			if (ContextMenuHandler.smethod_2(ContextMenuHandler.smethod_1(ContextMenuHandler.smethod_0()), <Module>.smethod_26<string>(283659592U), StringComparison.InvariantCultureIgnoreCase))
			{
				ContextMenuHandler._selectAll = <Module>.smethod_24<string>(1967299727U);
				ContextMenuHandler._copy = <Module>.smethod_27<string>(4038540139U);
				ContextMenuHandler._copyLink = <Module>.smethod_24<string>(924170919U);
				ContextMenuHandler._openLink = <Module>.smethod_24<string>(4053557343U);
				ContextMenuHandler._copyImageLink = <Module>.smethod_26<string>(1539748134U);
				ContextMenuHandler._copyImage = <Module>.smethod_26<string>(835092711U);
				ContextMenuHandler._saveImage = <Module>.smethod_27<string>(250639926U);
				ContextMenuHandler._openVideo = <Module>.smethod_25<string>(4291589970U);
				ContextMenuHandler._copyVideoUrl = <Module>.smethod_23<string>(3237819517U);
				return;
			}
			if (ContextMenuHandler.smethod_2(ContextMenuHandler.smethod_1(ContextMenuHandler.smethod_0()), <Module>.smethod_27<string>(3913363751U), StringComparison.InvariantCultureIgnoreCase))
			{
				ContextMenuHandler._selectAll = <Module>.smethod_27<string>(3333443204U);
				ContextMenuHandler._copy = <Module>.smethod_27<string>(2913847967U);
				ContextMenuHandler._copyLink = <Module>.smethod_25<string>(1666961546U);
				ContextMenuHandler._openLink = <Module>.smethod_27<string>(4243240277U);
				ContextMenuHandler._copyImageLink = <Module>.smethod_25<string>(2425890409U);
				ContextMenuHandler._copyImage = <Module>.smethod_26<string>(1566060511U);
				ContextMenuHandler._saveImage = <Module>.smethod_23<string>(2028368721U);
				ContextMenuHandler._openVideo = <Module>.smethod_26<string>(1613942481U);
				ContextMenuHandler._copyVideoUrl = <Module>.smethod_26<string>(195055241U);
				return;
			}
			if (ContextMenuHandler.smethod_2(ContextMenuHandler.smethod_1(ContextMenuHandler.smethod_0()), <Module>.smethod_24<string>(2507411374U), StringComparison.InvariantCultureIgnoreCase))
			{
				ContextMenuHandler._selectAll = <Module>.smethod_26<string>(2870031023U);
				ContextMenuHandler._copy = <Module>.smethod_26<string>(13103755U);
				ContextMenuHandler._copyLink = <Module>.smethod_24<string>(1748310313U);
				ContextMenuHandler._openLink = <Module>.smethod_27<string>(2419222710U);
				ContextMenuHandler._copyImageLink = <Module>.smethod_27<string>(1859762394U);
				ContextMenuHandler._copyImage = <Module>.smethod_26<string>(765641148U);
				ContextMenuHandler._saveImage = <Module>.smethod_25<string>(3797764679U);
				ContextMenuHandler._openVideo = <Module>.smethod_25<string>(198771913U);
				ContextMenuHandler._copyVideoUrl = <Module>.smethod_26<string>(2213257570U);
				return;
			}
			if (ContextMenuHandler.smethod_2(ContextMenuHandler.smethod_1(ContextMenuHandler.smethod_0()), <Module>.smethod_27<string>(3028000957U), StringComparison.InvariantCultureIgnoreCase))
			{
				ContextMenuHandler._selectAll = <Module>.smethod_23<string>(3480552112U);
				ContextMenuHandler._copy = <Module>.smethod_23<string>(4234864995U);
				ContextMenuHandler._copyLink = <Module>.smethod_26<string>(3166899237U);
				ContextMenuHandler._openLink = <Module>.smethod_23<string>(2353349348U);
				ContextMenuHandler._copyImageLink = <Module>.smethod_26<string>(329124757U);
				ContextMenuHandler._copyImage = <Module>.smethod_26<string>(3195628419U);
				ContextMenuHandler._saveImage = <Module>.smethod_26<string>(3919436630U);
				ContextMenuHandler._openVideo = <Module>.smethod_27<string>(175609906U);
				ContextMenuHandler._copyVideoUrl = <Module>.smethod_27<string>(4190847044U);
				return;
			}
			if (ContextMenuHandler.smethod_2(ContextMenuHandler.smethod_1(ContextMenuHandler.smethod_0()), <Module>.smethod_27<string>(1320312936U), StringComparison.InvariantCultureIgnoreCase))
			{
				ContextMenuHandler._selectAll = <Module>.smethod_27<string>(3771251807U);
				ContextMenuHandler._copy = <Module>.smethod_25<string>(526684388U);
				ContextMenuHandler._copyLink = <Module>.smethod_23<string>(2527816975U);
				ContextMenuHandler._openLink = <Module>.smethod_25<string>(874671653U);
				ContextMenuHandler._copyImageLink = <Module>.smethod_23<string>(3225687483U);
				ContextMenuHandler._copyImage = <Module>.smethod_27<string>(4278318890U);
				ContextMenuHandler._saveImage = <Module>.smethod_23<string>(1000377084U);
				ContextMenuHandler._openVideo = <Module>.smethod_26<string>(1671400845U);
				ContextMenuHandler._copyVideoUrl = <Module>.smethod_25<string>(2922445663U);
				return;
			}
			if (ContextMenuHandler.smethod_2(ContextMenuHandler.smethod_1(ContextMenuHandler.smethod_0()), <Module>.smethod_26<string>(2440765047U), StringComparison.InvariantCultureIgnoreCase))
			{
				ContextMenuHandler._selectAll = <Module>.smethod_23<string>(962748834U);
				ContextMenuHandler._copy = <Module>.smethod_23<string>(3013591606U);
				ContextMenuHandler._copyLink = <Module>.smethod_23<string>(1717061717U);
				ContextMenuHandler._openLink = <Module>.smethod_27<string>(2460072863U);
				ContextMenuHandler._copyImageLink = <Module>.smethod_25<string>(367414692U);
				ContextMenuHandler._copyImage = <Module>.smethod_25<string>(1063389222U);
				ContextMenuHandler._saveImage = <Module>.smethod_27<string>(2226964398U);
				ContextMenuHandler._openVideo = <Module>.smethod_23<string>(3523320864U);
				ContextMenuHandler._copyVideoUrl = <Module>.smethod_26<string>(420890964U);
				return;
			}
			if (ContextMenuHandler.smethod_2(ContextMenuHandler.smethod_1(ContextMenuHandler.smethod_0()), <Module>.smethod_25<string>(1580019266U), StringComparison.InvariantCultureIgnoreCase))
			{
				ContextMenuHandler._selectAll = <Module>.smethod_24<string>(2566351142U);
				ContextMenuHandler._copy = <Module>.smethod_23<string>(3909884368U);
				ContextMenuHandler._copyLink = <Module>.smethod_23<string>(2052323348U);
				ContextMenuHandler._openLink = <Module>.smethod_27<string>(2407679630U);
				ContextMenuHandler._copyImageLink = <Module>.smethod_25<string>(3459150497U);
				ContextMenuHandler._copyImage = <Module>.smethod_23<string>(2575726229U);
				ContextMenuHandler._saveImage = <Module>.smethod_23<string>(1646945719U);
				ContextMenuHandler._openVideo = <Module>.smethod_25<string>(4294319933U);
				ContextMenuHandler._copyVideoUrl = <Module>.smethod_27<string>(729298682U);
				return;
			}
			if (!ContextMenuHandler.smethod_2(ContextMenuHandler.smethod_1(ContextMenuHandler.smethod_0()), <Module>.smethod_23<string>(644450298U), StringComparison.InvariantCultureIgnoreCase))
			{
				ContextMenuHandler._selectAll = <Module>.smethod_24<string>(695527770U);
				ContextMenuHandler._copy = <Module>.smethod_26<string>(1096817205U);
				ContextMenuHandler._copyLink = <Module>.smethod_23<string>(1222753965U);
				ContextMenuHandler._openLink = <Module>.smethod_25<string>(884044736U);
				ContextMenuHandler._copyImageLink = <Module>.smethod_23<string>(2344816227U);
				ContextMenuHandler._copyImage = <Module>.smethod_23<string>(270018828U);
				ContextMenuHandler._saveImage = <Module>.smethod_26<string>(2050458872U);
				ContextMenuHandler._openVideo = <Module>.smethod_25<string>(1539869686U);
				ContextMenuHandler._copyVideoUrl = <Module>.smethod_23<string>(4197236745U);
				return;
			}
			ContextMenuHandler._selectAll = <Module>.smethod_27<string>(2122177932U);
			ContextMenuHandler._copy = <Module>.smethod_27<string>(2168799625U);
			ContextMenuHandler._copyLink = <Module>.smethod_26<string>(3182054292U);
			ContextMenuHandler._openLink = <Module>.smethod_23<string>(3292410862U);
			ContextMenuHandler._copyImageLink = <Module>.smethod_23<string>(1434849842U);
			ContextMenuHandler._copyImage = <Module>.smethod_25<string>(2951893536U);
			ContextMenuHandler._saveImage = <Module>.smethod_26<string>(2496551657U);
			ContextMenuHandler._openVideo = <Module>.smethod_27<string>(537040370U);
			ContextMenuHandler._copyVideoUrl = <Module>.smethod_25<string>(3021490989U);
		}

		// Token: 0x060007F3 RID: 2035 RVA: 0x0000F878 File Offset: 0x0000DA78
		public ContextMenuHandler(SelectionHandler selectionHandler, HtmlContainerInt htmlContainer)
		{
			ArgChecker.AssertArgNotNull(selectionHandler, <Module>.smethod_26<string>(3498075294U));
			ArgChecker.AssertArgNotNull(htmlContainer, <Module>.smethod_23<string>(1410895215U));
			this._selectionHandler = selectionHandler;
			this._htmlContainer = htmlContainer;
		}

		// Token: 0x060007F4 RID: 2036 RVA: 0x000419A0 File Offset: 0x0003FBA0
		public void ShowContextMenu(RControl parent, CssRect rect, CssBox link)
		{
			try
			{
				this.DisposeContextMenu();
				this._parentControl = parent;
				this._currentRect = rect;
				this._currentLink = link;
				this._contextMenu = this._htmlContainer.Adapter.GetContextMenu();
				if (rect != null)
				{
					bool flag = false;
					if (link != null)
					{
						flag = link is CssBoxFrame && ((CssBoxFrame)link).IsVideo;
						bool flag2 = !ContextMenuHandler.smethod_3(link.HrefLink);
						this._contextMenu.AddItem(flag ? ContextMenuHandler._openVideo : ContextMenuHandler._openLink, flag2, new EventHandler(this.OnOpenLinkClick));
						if (this._htmlContainer.IsSelectionEnabled)
						{
							this._contextMenu.AddItem(flag ? ContextMenuHandler._copyVideoUrl : ContextMenuHandler._copyLink, flag2, new EventHandler(this.OnCopyLinkClick));
						}
						this._contextMenu.AddDivider();
					}
					if (rect.IsImage && !flag)
					{
						this._contextMenu.AddItem(ContextMenuHandler._saveImage, rect.Image != null, new EventHandler(this.OnSaveImageClick));
						if (this._htmlContainer.IsSelectionEnabled)
						{
							this._contextMenu.AddItem(ContextMenuHandler._copyImageLink, !ContextMenuHandler.smethod_3(this._currentRect.OwnerBox.GetAttribute(<Module>.smethod_25<string>(614955292U))), new EventHandler(this.OnCopyImageLinkClick));
							this._contextMenu.AddItem(ContextMenuHandler._copyImage, rect.Image != null, new EventHandler(this.OnCopyImageClick));
						}
						this._contextMenu.AddDivider();
					}
					if (this._htmlContainer.IsSelectionEnabled)
					{
						this._contextMenu.AddItem(ContextMenuHandler._copy, rect.Selected, new EventHandler(this.OnCopyClick));
					}
				}
				if (this._htmlContainer.IsSelectionEnabled)
				{
					this._contextMenu.AddItem(ContextMenuHandler._selectAll, true, new EventHandler(this.OnSelectAllClick));
				}
				if (this._contextMenu.ItemsCount > 0)
				{
					this._contextMenu.RemoveLastDivider();
					this._contextMenu.Show(parent, parent.MouseLocation);
				}
			}
			catch (Exception ex)
			{
				this._htmlContainer.ReportError(HtmlRenderErrorType.ContextMenu, <Module>.smethod_25<string>(2444636575U), ex);
			}
		}

		// Token: 0x060007F5 RID: 2037 RVA: 0x0000F8AE File Offset: 0x0000DAAE
		public void Dispose()
		{
			this.DisposeContextMenu();
		}

		// Token: 0x060007F6 RID: 2038 RVA: 0x00041BEC File Offset: 0x0003FDEC
		private void DisposeContextMenu()
		{
			try
			{
				if (this._contextMenu != null)
				{
					this._contextMenu.Dispose();
				}
				this._contextMenu = null;
				this._parentControl = null;
				this._currentRect = null;
				this._currentLink = null;
			}
			catch
			{
			}
		}

		// Token: 0x060007F7 RID: 2039 RVA: 0x00041C40 File Offset: 0x0003FE40
		private void OnOpenLinkClick(object sender, EventArgs e)
		{
			try
			{
				this._currentLink.HtmlContainer.HandleLinkClicked(this._parentControl, this._parentControl.MouseLocation, this._currentLink);
			}
			catch (HtmlLinkClickedException)
			{
				throw;
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_0066:
					int num = 428544800;
					for (;;)
					{
						switch (num ^ 428544801)
						{
						case 0:
							goto IL_0066;
						case 1:
							this._htmlContainer.ReportError(HtmlRenderErrorType.ContextMenu, <Module>.smethod_27<string>(3800558880U), ex);
							num = 428544803;
							continue;
						}
						goto Block_5;
					}
				}
				Block_5:;
			}
			finally
			{
				this.DisposeContextMenu();
			}
		}

		// Token: 0x060007F8 RID: 2040 RVA: 0x00041CF0 File Offset: 0x0003FEF0
		private void OnCopyLinkClick(object sender, EventArgs e)
		{
			try
			{
				this._htmlContainer.Adapter.SetToClipboard(this._currentLink.HrefLink);
			}
			catch (Exception ex)
			{
				this._htmlContainer.ReportError(HtmlRenderErrorType.ContextMenu, <Module>.smethod_25<string>(3697390729U), ex);
			}
			finally
			{
				this.DisposeContextMenu();
			}
		}

		// Token: 0x060007F9 RID: 2041 RVA: 0x00041D5C File Offset: 0x0003FF5C
		private void OnSaveImageClick(object sender, EventArgs e)
		{
			try
			{
				string attribute = this._currentRect.OwnerBox.GetAttribute(<Module>.smethod_23<string>(1525630995U));
				this._htmlContainer.Adapter.SaveToFile(this._currentRect.Image, ContextMenuHandler.smethod_4(attribute) ?? <Module>.smethod_26<string>(2694494075U), ContextMenuHandler.smethod_5(attribute) ?? <Module>.smethod_24<string>(3986489877U), null);
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_009B:
					int num = -1552062502;
					for (;;)
					{
						switch (num ^ -1552062501)
						{
						case 1:
							this._htmlContainer.ReportError(HtmlRenderErrorType.ContextMenu, <Module>.smethod_25<string>(3975780541U), ex);
							num = -1552062501;
							continue;
						case 2:
							goto IL_009B;
						}
						goto Block_6;
					}
				}
				Block_6:;
			}
			finally
			{
				this.DisposeContextMenu();
			}
		}

		// Token: 0x060007FA RID: 2042 RVA: 0x00041E34 File Offset: 0x00040034
		private void OnCopyImageLinkClick(object sender, EventArgs e)
		{
			try
			{
				this._htmlContainer.Adapter.SetToClipboard(this._currentRect.OwnerBox.GetAttribute(<Module>.smethod_23<string>(1525630995U)));
			}
			catch (Exception ex)
			{
				this._htmlContainer.ReportError(HtmlRenderErrorType.ContextMenu, <Module>.smethod_27<string>(2681638248U), ex);
			}
			finally
			{
				this.DisposeContextMenu();
			}
		}

		// Token: 0x060007FB RID: 2043 RVA: 0x00041EAC File Offset: 0x000400AC
		private void OnCopyImageClick(object sender, EventArgs e)
		{
			try
			{
				this._htmlContainer.Adapter.SetToClipboard(this._currentRect.Image);
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_0057:
					int num = 298968946;
					for (;;)
					{
						switch (num ^ 298968947)
						{
						case 1:
							this._htmlContainer.ReportError(HtmlRenderErrorType.ContextMenu, <Module>.smethod_23<string>(3773044991U), ex);
							num = 298968947;
							continue;
						case 2:
							goto IL_0057;
						}
						goto Block_4;
					}
				}
				Block_4:;
			}
			finally
			{
				this.DisposeContextMenu();
			}
		}

		// Token: 0x060007FC RID: 2044 RVA: 0x00041F40 File Offset: 0x00040140
		private void OnCopyClick(object sender, EventArgs e)
		{
			try
			{
				this._selectionHandler.CopySelectedHtml();
			}
			catch (Exception ex)
			{
				this._htmlContainer.ReportError(HtmlRenderErrorType.ContextMenu, <Module>.smethod_23<string>(793421709U), ex);
			}
			finally
			{
				this.DisposeContextMenu();
			}
		}

		// Token: 0x060007FD RID: 2045 RVA: 0x00041F9C File Offset: 0x0004019C
		private void OnSelectAllClick(object sender, EventArgs e)
		{
			try
			{
				this._selectionHandler.SelectAll(this._parentControl);
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_004D:
					int num = -762816951;
					for (;;)
					{
						switch (num ^ -762816952)
						{
						case 0:
							goto IL_004D;
						case 1:
							this._htmlContainer.ReportError(HtmlRenderErrorType.ContextMenu, <Module>.smethod_24<string>(382030139U), ex);
							num = -762816950;
							continue;
						}
						goto Block_4;
					}
				}
				Block_4:;
			}
			finally
			{
				this.DisposeContextMenu();
			}
		}

		// Token: 0x060007FE RID: 2046 RVA: 0x0000F8B6 File Offset: 0x0000DAB6
		static CultureInfo smethod_0()
		{
			return CultureInfo.CurrentUICulture;
		}

		// Token: 0x060007FF RID: 2047 RVA: 0x0000F8BD File Offset: 0x0000DABD
		static string smethod_1(CultureInfo cultureInfo_0)
		{
			return cultureInfo_0.Name;
		}

		// Token: 0x06000800 RID: 2048 RVA: 0x0000F8C5 File Offset: 0x0000DAC5
		static bool smethod_2(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.StartsWith(string_1, stringComparison_0);
		}

		// Token: 0x06000801 RID: 2049 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_3(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06000802 RID: 2050 RVA: 0x0000CFF4 File Offset: 0x0000B1F4
		static string smethod_4(string string_0)
		{
			return Path.GetFileName(string_0);
		}

		// Token: 0x06000803 RID: 2051 RVA: 0x0000F8CF File Offset: 0x0000DACF
		static string smethod_5(string string_0)
		{
			return Path.GetExtension(string_0);
		}

		// Token: 0x040002DA RID: 730
		private static readonly string _selectAll;

		// Token: 0x040002DB RID: 731
		private static readonly string _copy;

		// Token: 0x040002DC RID: 732
		private static readonly string _copyLink;

		// Token: 0x040002DD RID: 733
		private static readonly string _openLink;

		// Token: 0x040002DE RID: 734
		private static readonly string _copyImageLink;

		// Token: 0x040002DF RID: 735
		private static readonly string _copyImage;

		// Token: 0x040002E0 RID: 736
		private static readonly string _saveImage;

		// Token: 0x040002E1 RID: 737
		private static readonly string _openVideo;

		// Token: 0x040002E2 RID: 738
		private static readonly string _copyVideoUrl;

		// Token: 0x040002E3 RID: 739
		private readonly SelectionHandler _selectionHandler;

		// Token: 0x040002E4 RID: 740
		private readonly HtmlContainerInt _htmlContainer;

		// Token: 0x040002E5 RID: 741
		private RContextMenu _contextMenu;

		// Token: 0x040002E6 RID: 742
		private RControl _parentControl;

		// Token: 0x040002E7 RID: 743
		private CssRect _currentRect;

		// Token: 0x040002E8 RID: 744
		private CssBox _currentLink;
	}
}
