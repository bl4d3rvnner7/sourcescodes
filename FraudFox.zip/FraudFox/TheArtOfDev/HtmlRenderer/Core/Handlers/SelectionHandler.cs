﻿using System;
using System.Collections.Generic;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Dom;
using TheArtOfDev.HtmlRenderer.Core.Entities;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Handlers
{
	// Token: 0x020000A0 RID: 160
	internal sealed class SelectionHandler : IDisposable
	{
		// Token: 0x0600085B RID: 2139 RVA: 0x00042C28 File Offset: 0x00040E28
		public SelectionHandler(CssBox root)
		{
			ArgChecker.AssertArgNotNull(root, <Module>.smethod_24<string>(2718273090U));
			this._root = root;
			this._contextMenuHandler = new ContextMenuHandler(this, root.HtmlContainer);
		}

		// Token: 0x0600085C RID: 2140 RVA: 0x0000FB33 File Offset: 0x0000DD33
		public void SelectAll(RControl control)
		{
			if (this._root.HtmlContainer.IsSelectionEnabled)
			{
				this.ClearSelection();
				this.SelectAllWords(this._root);
				control.Invalidate();
			}
		}

		// Token: 0x0600085D RID: 2141 RVA: 0x00042C90 File Offset: 0x00040E90
		public void SelectWord(RControl control, RPoint loc)
		{
			if (this._root.HtmlContainer.IsSelectionEnabled)
			{
				CssRect cssBoxWord = DomUtils.GetCssBoxWord(this._root, loc);
				if (cssBoxWord != null)
				{
					cssBoxWord.Selection = this;
					this._selectionStartPoint = loc;
					this._selectionStart = (this._selectionEnd = cssBoxWord);
					control.Invalidate();
				}
			}
		}

		// Token: 0x0600085E RID: 2142 RVA: 0x00042CE4 File Offset: 0x00040EE4
		public void HandleMouseDown(RControl parent, RPoint loc, bool isMouseInContainer)
		{
			bool flag = !isMouseInContainer;
			if (isMouseInContainer)
			{
				this._mouseDownInControl = true;
				this._isDoubleClickSelect = (DateTime.Now - this._lastMouseDown).TotalMilliseconds < 400.0;
				goto IL_0150;
			}
			goto IL_01E6;
			int num;
			for (;;)
			{
				IL_0192:
				bool flag2;
				switch (num ^ -1139352920)
				{
				case 0:
				{
					CssRect cssBoxWord;
					if (cssBoxWord != null)
					{
						num = -1139352921;
						continue;
					}
					flag2 = true;
					goto IL_0053;
				}
				case 1:
					if (this._root.HtmlContainer.IsSelectionEnabled)
					{
						num = (parent.LeftMouseButton ? (-1139352914) : (-1139352922));
						continue;
					}
					goto IL_005E;
				case 2:
					goto IL_0150;
				case 3:
					goto IL_01E6;
				case 4:
					this.ClearSelection();
					parent.Invalidate();
					num = -1139352925;
					continue;
				case 5:
					this._mouseDownOnSelectedWord = false;
					num = -1139352919;
					continue;
				case 6:
				{
					CssRect cssBoxWord2 = DomUtils.GetCssBoxWord(this._root, loc);
					num = -1139352928;
					continue;
				}
				case 7:
				{
					CssRect cssBoxWord2;
					if (cssBoxWord2.Selected)
					{
						this._mouseDownOnSelectedWord = true;
						num = -1139352917;
						continue;
					}
					goto IL_00A3;
				}
				case 8:
				{
					CssRect cssBoxWord2;
					num = ((cssBoxWord2 == null) ? (-1139352924) : (-1139352913));
					continue;
				}
				case 9:
				{
					CssRect cssBoxWord;
					CssBox linkBox;
					this._contextMenuHandler.ShowContextMenu(parent, cssBoxWord, linkBox);
					num = -1139352920;
					continue;
				}
				case 10:
					num = (this._root.HtmlContainer.IsContextMenuEnabled ? (-1139352927) : (-1139352920));
					continue;
				case 12:
					goto IL_00A3;
				case 13:
					this._lastMouseDown = DateTime.Now;
					num = -1139352915;
					continue;
				case 14:
					goto IL_005E;
				case 15:
				{
					CssRect cssBoxWord;
					flag2 = !cssBoxWord.Selected;
					goto IL_0053;
				}
				}
				break;
				IL_0053:
				flag = flag2;
				num = -1139352917;
				continue;
				IL_005E:
				if (parent.RightMouseButton)
				{
					CssRect cssBoxWord = DomUtils.GetCssBoxWord(this._root, loc);
					CssBox linkBox = DomUtils.GetLinkBox(this._root, loc);
					num = -1139352926;
					continue;
				}
				goto IL_01E6;
				IL_00A3:
				flag = true;
				num = -1139352917;
			}
			return;
			IL_0150:
			num = -1139352923;
			goto IL_0192;
			IL_01E6:
			num = (flag ? (-1139352916) : (-1139352925));
			goto IL_0192;
		}

		// Token: 0x0600085F RID: 2143 RVA: 0x00042EE0 File Offset: 0x000410E0
		public bool HandleMouseUp(RControl parent, bool leftMouseButton)
		{
			bool flag = false;
			this._mouseDownInControl = false;
			if (this._root.HtmlContainer.IsSelectionEnabled)
			{
				flag = this._inSelection;
				if (!this._inSelection && leftMouseButton && this._mouseDownOnSelectedWord)
				{
					this.ClearSelection();
					parent.Invalidate();
				}
				this._mouseDownOnSelectedWord = false;
				this._inSelection = false;
			}
			return flag || DateTime.Now - this._lastMouseDown > TimeSpan.FromSeconds(1.0);
		}

		// Token: 0x06000860 RID: 2144 RVA: 0x00042F68 File Offset: 0x00041168
		public void HandleMouseMove(RControl parent, RPoint loc)
		{
			if (this._root.HtmlContainer.IsSelectionEnabled && this._mouseDownInControl && parent.LeftMouseButton)
			{
				if (!this._mouseDownOnSelectedWord)
				{
					this.HandleSelection(parent, loc, !this._isDoubleClickSelect);
					this._inSelection = this._selectionStart != null && this._selectionEnd != null && (this._selectionStart != this._selectionEnd || this._selectionStartIndex != this._selectionEndIndex);
					return;
				}
				if ((DateTime.Now - this._lastMouseDown).TotalMilliseconds > 200.0)
				{
					this.StartDragDrop(parent);
					return;
				}
			}
			else
			{
				CssBox linkBox = DomUtils.GetLinkBox(this._root, loc);
				if (linkBox != null)
				{
					this._cursorChanged = true;
					parent.SetCursorHand();
					return;
				}
				if (this._root.HtmlContainer.IsSelectionEnabled)
				{
					CssRect cssBoxWord = DomUtils.GetCssBoxWord(this._root, loc);
					this._cursorChanged = cssBoxWord != null && !cssBoxWord.IsImage && (!cssBoxWord.Selected || (cssBoxWord.SelectedStartIndex >= 0 && cssBoxWord.Left + cssBoxWord.SelectedStartOffset > loc.X) || (cssBoxWord.SelectedEndOffset >= 0.0 && cssBoxWord.Left + cssBoxWord.SelectedEndOffset < loc.X));
					if (!this._cursorChanged)
					{
						parent.SetCursorDefault();
						return;
					}
					parent.SetCursorIBeam();
					return;
				}
				else if (this._cursorChanged)
				{
					parent.SetCursorDefault();
				}
			}
		}

		// Token: 0x06000861 RID: 2145 RVA: 0x0000FB5F File Offset: 0x0000DD5F
		public void HandleMouseLeave(RControl parent)
		{
			if (this._cursorChanged)
			{
				this._cursorChanged = false;
				parent.SetCursorDefault();
			}
		}

		// Token: 0x06000862 RID: 2146 RVA: 0x000430F0 File Offset: 0x000412F0
		public void CopySelectedHtml()
		{
			if (this._root.HtmlContainer.IsSelectionEnabled)
			{
				string text = DomUtils.GenerateHtml(this._root, HtmlGenerationStyle.Inline, true);
				string selectedPlainText = DomUtils.GetSelectedPlainText(this._root);
				if (!SelectionHandler.smethod_0(selectedPlainText))
				{
					this._root.HtmlContainer.Adapter.SetToClipboard(text, selectedPlainText);
				}
			}
		}

		// Token: 0x06000863 RID: 2147 RVA: 0x0000FB76 File Offset: 0x0000DD76
		public string GetSelectedText()
		{
			if (!this._root.HtmlContainer.IsSelectionEnabled)
			{
				return null;
			}
			return DomUtils.GetSelectedPlainText(this._root);
		}

		// Token: 0x06000864 RID: 2148 RVA: 0x0000FB97 File Offset: 0x0000DD97
		public string GetSelectedHtml()
		{
			if (!this._root.HtmlContainer.IsSelectionEnabled)
			{
				return null;
			}
			return DomUtils.GenerateHtml(this._root, HtmlGenerationStyle.Inline, true);
		}

		// Token: 0x06000865 RID: 2149 RVA: 0x0000FBBA File Offset: 0x0000DDBA
		public int GetSelectingStartIndex(CssRect word)
		{
			if (word != (this._backwardSelection ? this._selectionEnd : this._selectionStart))
			{
				return -1;
			}
			if (!this._backwardSelection)
			{
				return this._selectionStartIndex;
			}
			return this._selectionEndIndex;
		}

		// Token: 0x06000866 RID: 2150 RVA: 0x0000FBEC File Offset: 0x0000DDEC
		public int GetSelectedEndIndexOffset(CssRect word)
		{
			if (word != (this._backwardSelection ? this._selectionStart : this._selectionEnd))
			{
				return -1;
			}
			if (!this._backwardSelection)
			{
				return this._selectionEndIndex;
			}
			return this._selectionStartIndex;
		}

		// Token: 0x06000867 RID: 2151 RVA: 0x0000FC1E File Offset: 0x0000DE1E
		public double GetSelectedStartOffset(CssRect word)
		{
			if (word != (this._backwardSelection ? this._selectionEnd : this._selectionStart))
			{
				return -1.0;
			}
			if (!this._backwardSelection)
			{
				return this._selectionStartOffset;
			}
			return this._selectionEndOffset;
		}

		// Token: 0x06000868 RID: 2152 RVA: 0x0000FC58 File Offset: 0x0000DE58
		public double GetSelectedEndOffset(CssRect word)
		{
			if (word != (this._backwardSelection ? this._selectionStart : this._selectionEnd))
			{
				return -1.0;
			}
			if (!this._backwardSelection)
			{
				return this._selectionEndOffset;
			}
			return this._selectionStartOffset;
		}

		// Token: 0x06000869 RID: 2153 RVA: 0x00043148 File Offset: 0x00041348
		public void ClearSelection()
		{
			this._dragDropData = null;
			SelectionHandler.ClearSelection(this._root);
			this._selectionStartOffset = -1.0;
			this._selectionStartIndex = -1;
			this._selectionEndOffset = -1.0;
			this._selectionEndIndex = -1;
			this._selectionStartPoint = RPoint.Empty;
			this._selectionStart = null;
			this._selectionEnd = null;
		}

		// Token: 0x0600086A RID: 2154 RVA: 0x0000FC92 File Offset: 0x0000DE92
		public void Dispose()
		{
			this._contextMenuHandler.Dispose();
		}

		// Token: 0x0600086B RID: 2155 RVA: 0x000431AC File Offset: 0x000413AC
		private void HandleSelection(RControl control, RPoint loc, bool allowPartialSelect)
		{
			CssLineBox cssLineBox = DomUtils.GetCssLineBox(this._root, loc);
			if (cssLineBox != null)
			{
				CssRect cssRect = DomUtils.GetCssBoxWord(cssLineBox, loc);
				if (cssRect == null && cssLineBox.Words.Count > 0)
				{
					if (loc.Y > cssLineBox.LineBottom)
					{
						cssRect = cssLineBox.Words[cssLineBox.Words.Count - 1];
					}
					else if (loc.X >= cssLineBox.Words[0].Left)
					{
						if (loc.X > cssLineBox.Words[cssLineBox.Words.Count - 1].Right)
						{
							cssRect = cssLineBox.Words[cssLineBox.Words.Count - 1];
						}
					}
					else
					{
						cssRect = cssLineBox.Words[0];
					}
				}
				if (cssRect != null)
				{
					if (this._selectionStart == null)
					{
						this._selectionStartPoint = loc;
						this._selectionStart = cssRect;
						if (allowPartialSelect)
						{
							this.CalculateWordCharIndexAndOffset(control, cssRect, loc, true);
						}
					}
					this._selectionEnd = cssRect;
					if (allowPartialSelect)
					{
						this.CalculateWordCharIndexAndOffset(control, cssRect, loc, false);
					}
					SelectionHandler.ClearSelection(this._root);
					if (this.CheckNonEmptySelection(loc, allowPartialSelect))
					{
						this.CheckSelectionDirection();
						this.SelectWordsInRange(this._root, this._backwardSelection ? this._selectionEnd : this._selectionStart, this._backwardSelection ? this._selectionStart : this._selectionEnd);
					}
					else
					{
						this._selectionEnd = null;
					}
					this._cursorChanged = true;
					control.SetCursorIBeam();
					control.Invalidate();
				}
			}
		}

		// Token: 0x0600086C RID: 2156 RVA: 0x0004332C File Offset: 0x0004152C
		private static void ClearSelection(CssBox box)
		{
			foreach (CssRect cssRect in box.Words)
			{
				cssRect.Selection = null;
			}
			foreach (CssBox cssBox in box.Boxes)
			{
				SelectionHandler.ClearSelection(cssBox);
			}
		}

		// Token: 0x0600086D RID: 2157 RVA: 0x000433C4 File Offset: 0x000415C4
		private void StartDragDrop(RControl control)
		{
			if (this._dragDropData == null)
			{
				string text = DomUtils.GenerateHtml(this._root, HtmlGenerationStyle.Inline, true);
				string selectedPlainText = DomUtils.GetSelectedPlainText(this._root);
				this._dragDropData = control.Adapter.GetClipboardDataObject(text, selectedPlainText);
			}
			control.DoDragDropCopy(this._dragDropData);
		}

		// Token: 0x0600086E RID: 2158 RVA: 0x00043414 File Offset: 0x00041614
		public void SelectAllWords(CssBox box)
		{
			foreach (CssRect cssRect in box.Words)
			{
				cssRect.Selection = this;
			}
			foreach (CssBox cssBox in box.Boxes)
			{
				this.SelectAllWords(cssBox);
			}
		}

		// Token: 0x0600086F RID: 2159 RVA: 0x000434AC File Offset: 0x000416AC
		private bool CheckNonEmptySelection(RPoint loc, bool allowPartialSelect)
		{
			return !allowPartialSelect || ((SelectionHandler.smethod_1(this._selectionStartPoint.X - loc.X) > 1.0 || SelectionHandler.smethod_1(this._selectionStartPoint.Y - loc.Y) >= 5.0) && (this._selectionStart != this._selectionEnd || this._selectionStartIndex != this._selectionEndIndex));
		}

		// Token: 0x06000870 RID: 2160 RVA: 0x00043528 File Offset: 0x00041728
		private void SelectWordsInRange(CssBox root, CssRect selectionStart, CssRect selectionEnd)
		{
			bool flag = false;
			this.SelectWordsInRange(root, selectionStart, selectionEnd, ref flag);
		}

		// Token: 0x06000871 RID: 2161 RVA: 0x00043544 File Offset: 0x00041744
		private bool SelectWordsInRange(CssBox box, CssRect selectionStart, CssRect selectionEnd, ref bool inSelection)
		{
			foreach (CssRect cssRect in box.Words)
			{
				if (!inSelection && cssRect == selectionStart)
				{
					inSelection = true;
				}
				if (inSelection)
				{
					cssRect.Selection = this;
					if (selectionStart == selectionEnd || cssRect == selectionEnd)
					{
						return true;
					}
				}
			}
			using (List<CssBox>.Enumerator enumerator2 = box.Boxes.GetEnumerator())
			{
				while (enumerator2.MoveNext())
				{
					CssBox cssBox = enumerator2.Current;
					if (this.SelectWordsInRange(cssBox, selectionStart, selectionEnd, ref inSelection))
					{
						return true;
					}
				}
				return false;
			}
			bool flag;
			return flag;
		}

		// Token: 0x06000872 RID: 2162 RVA: 0x00043608 File Offset: 0x00041808
		private void CalculateWordCharIndexAndOffset(RControl control, CssRect word, RPoint loc, bool selectionStart)
		{
			int num;
			double num2;
			SelectionHandler.CalculateWordCharIndexAndOffset(control, word, loc, selectionStart, out num, out num2);
			if (selectionStart)
			{
				this._selectionStartIndex = num;
				this._selectionStartOffset = num2;
				return;
			}
			this._selectionEndIndex = num;
			this._selectionEndOffset = num2;
		}

		// Token: 0x06000873 RID: 2163 RVA: 0x00043644 File Offset: 0x00041844
		private static void CalculateWordCharIndexAndOffset(RControl control, CssRect word, RPoint loc, bool inclusive, out int selectionIndex, out double selectionOffset)
		{
			selectionIndex = 0;
			selectionOffset = 0.0;
			double num = loc.X - word.Left;
			if (word.Text == null)
			{
				selectionIndex = -1;
				selectionOffset = -1.0;
				return;
			}
			if (num <= word.Width - word.OwnerBox.ActualWordSpacing && loc.Y <= DomUtils.GetCssLineBoxByWord(word).LineBottom)
			{
				if (num > 0.0)
				{
					double num2 = num + (inclusive ? 0.0 : (1.5 * word.LeftGlyphPadding));
					int num3;
					double num4;
					control.MeasureString(word.Text, word.OwnerBox.ActualFont, num2, out num3, out num4);
					selectionIndex = num3;
					selectionOffset = num4;
				}
				return;
			}
			selectionIndex = SelectionHandler.smethod_2(word.Text);
			selectionOffset = word.Width;
		}

		// Token: 0x06000874 RID: 2164 RVA: 0x0004371C File Offset: 0x0004191C
		private void CheckSelectionDirection()
		{
			if (this._selectionStart == this._selectionEnd)
			{
				this._backwardSelection = this._selectionStartIndex > this._selectionEndIndex;
				return;
			}
			if (DomUtils.GetCssLineBoxByWord(this._selectionStart) != DomUtils.GetCssLineBoxByWord(this._selectionEnd))
			{
				this._backwardSelection = this._selectionStart.Top >= this._selectionEnd.Bottom;
				return;
			}
			this._backwardSelection = this._selectionStart.Left > this._selectionEnd.Left;
		}

		// Token: 0x06000875 RID: 2165 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_0(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06000876 RID: 2166 RVA: 0x0000FC9F File Offset: 0x0000DE9F
		static double smethod_1(double double_0)
		{
			return Math.Abs(double_0);
		}

		// Token: 0x06000877 RID: 2167 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_2(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x040002FC RID: 764
		private readonly CssBox _root;

		// Token: 0x040002FD RID: 765
		private readonly ContextMenuHandler _contextMenuHandler;

		// Token: 0x040002FE RID: 766
		private RPoint _selectionStartPoint;

		// Token: 0x040002FF RID: 767
		private CssRect _selectionStart;

		// Token: 0x04000300 RID: 768
		private CssRect _selectionEnd;

		// Token: 0x04000301 RID: 769
		private int _selectionStartIndex = -1;

		// Token: 0x04000302 RID: 770
		private int _selectionEndIndex = -1;

		// Token: 0x04000303 RID: 771
		private double _selectionStartOffset = -1.0;

		// Token: 0x04000304 RID: 772
		private double _selectionEndOffset = -1.0;

		// Token: 0x04000305 RID: 773
		private bool _backwardSelection;

		// Token: 0x04000306 RID: 774
		private bool _inSelection;

		// Token: 0x04000307 RID: 775
		private bool _isDoubleClickSelect;

		// Token: 0x04000308 RID: 776
		private bool _mouseDownInControl;

		// Token: 0x04000309 RID: 777
		private bool _mouseDownOnSelectedWord;

		// Token: 0x0400030A RID: 778
		private bool _cursorChanged;

		// Token: 0x0400030B RID: 779
		private DateTime _lastMouseDown;

		// Token: 0x0400030C RID: 780
		private object _dragDropData;
	}
}
