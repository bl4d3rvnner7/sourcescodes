﻿using System;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Dom;

namespace TheArtOfDev.HtmlRenderer.Core.Handlers
{
	// Token: 0x02000098 RID: 152
	internal static class BordersDrawHandler
	{
		// Token: 0x060007E1 RID: 2017 RVA: 0x00040230 File Offset: 0x0003E430
		public static void DrawBoxBorders(RGraphics g, CssBox box, RRect rect, bool isFirst, bool isLast)
		{
			if (rect.Width > 0.0 && rect.Height > 0.0)
			{
				if (!BordersDrawHandler.smethod_0(box.BorderTopStyle) && !BordersDrawHandler.smethod_1(box.BorderTopStyle, <Module>.smethod_24<string>(3284293868U)) && !BordersDrawHandler.smethod_1(box.BorderTopStyle, <Module>.smethod_25<string>(2155472341U)) && box.ActualBorderTopWidth > 0.0)
				{
					BordersDrawHandler.DrawBorder(Border.Top, box, g, rect, isFirst, isLast);
				}
				if (isFirst && !BordersDrawHandler.smethod_0(box.BorderLeftStyle) && !BordersDrawHandler.smethod_1(box.BorderLeftStyle, <Module>.smethod_27<string>(1876627641U)) && !BordersDrawHandler.smethod_1(box.BorderLeftStyle, <Module>.smethod_24<string>(2643072343U)) && box.ActualBorderLeftWidth > 0.0)
				{
					BordersDrawHandler.DrawBorder(Border.Left, box, g, rect, true, isLast);
				}
				if (!BordersDrawHandler.smethod_0(box.BorderBottomStyle) && !BordersDrawHandler.smethod_1(box.BorderBottomStyle, <Module>.smethod_24<string>(3284293868U)) && !BordersDrawHandler.smethod_1(box.BorderBottomStyle, <Module>.smethod_25<string>(2155472341U)) && box.ActualBorderBottomWidth > 0.0)
				{
					BordersDrawHandler.DrawBorder(Border.Bottom, box, g, rect, isFirst, isLast);
				}
				if (isLast && !BordersDrawHandler.smethod_0(box.BorderRightStyle) && !BordersDrawHandler.smethod_1(box.BorderRightStyle, <Module>.smethod_27<string>(1876627641U)) && !BordersDrawHandler.smethod_1(box.BorderRightStyle, <Module>.smethod_23<string>(969740366U)) && box.ActualBorderRightWidth > 0.0)
				{
					BordersDrawHandler.DrawBorder(Border.Right, box, g, rect, isFirst, true);
				}
			}
		}

		// Token: 0x060007E2 RID: 2018 RVA: 0x0000F828 File Offset: 0x0000DA28
		public static void DrawBorder(Border border, RGraphics g, CssBox box, RBrush brush, RRect rectangle)
		{
			BordersDrawHandler.SetInOutsetRectanglePoints(border, box, rectangle, true, true);
			g.DrawPolygon(brush, BordersDrawHandler._borderPts);
		}

		// Token: 0x060007E3 RID: 2019 RVA: 0x000403D0 File Offset: 0x0003E5D0
		private static void DrawBorder(Border border, CssBox box, RGraphics g, RRect rect, bool isLineStart, bool isLineEnd)
		{
			string style = BordersDrawHandler.GetStyle(border, box);
			RColor color = BordersDrawHandler.GetColor(border, box, style);
			RGraphicsPath roundedBorderPath = BordersDrawHandler.GetRoundedBorderPath(g, border, box, rect);
			if (roundedBorderPath != null)
			{
				object obj = null;
				if (box.HtmlContainer != null && !box.HtmlContainer.AvoidGeometryAntialias && box.IsRounded)
				{
					obj = g.SetAntiAliasSmoothingMode();
				}
				RPen pen = BordersDrawHandler.GetPen(g, style, color, BordersDrawHandler.GetWidth(border, box));
				RGraphicsPath rgraphicsPath = roundedBorderPath;
				try
				{
					g.DrawPath(pen, roundedBorderPath);
				}
				finally
				{
					if (rgraphicsPath != null)
					{
						BordersDrawHandler.smethod_2(rgraphicsPath);
					}
				}
				g.ReturnPreviousSmoothingMode(obj);
				return;
			}
			if (BordersDrawHandler.smethod_1(style, <Module>.smethod_27<string>(75696234U)) || BordersDrawHandler.smethod_1(style, <Module>.smethod_27<string>(215561313U)))
			{
				BordersDrawHandler.SetInOutsetRectanglePoints(border, box, rect, isLineStart, isLineEnd);
				g.DrawPolygon(g.GetSolidBrush(color), BordersDrawHandler._borderPts);
				return;
			}
			RPen pen2 = BordersDrawHandler.GetPen(g, style, color, BordersDrawHandler.GetWidth(border, box));
			switch (border)
			{
			case Border.Top:
				g.DrawLine(pen2, BordersDrawHandler.smethod_3(rect.Left), rect.Top + box.ActualBorderTopWidth / 2.0, rect.Right - 1.0, rect.Top + box.ActualBorderTopWidth / 2.0);
				return;
			case Border.Right:
				g.DrawLine(pen2, rect.Right - box.ActualBorderRightWidth / 2.0, BordersDrawHandler.smethod_3(rect.Top), rect.Right - box.ActualBorderRightWidth / 2.0, BordersDrawHandler.smethod_4(rect.Bottom));
				return;
			case Border.Bottom:
				g.DrawLine(pen2, BordersDrawHandler.smethod_3(rect.Left), rect.Bottom - box.ActualBorderBottomWidth / 2.0, rect.Right - 1.0, rect.Bottom - box.ActualBorderBottomWidth / 2.0);
				return;
			case Border.Left:
				g.DrawLine(pen2, rect.Left + box.ActualBorderLeftWidth / 2.0, BordersDrawHandler.smethod_3(rect.Top), rect.Left + box.ActualBorderLeftWidth / 2.0, BordersDrawHandler.smethod_4(rect.Bottom));
				return;
			default:
				return;
			}
		}

		// Token: 0x060007E4 RID: 2020 RVA: 0x00040628 File Offset: 0x0003E828
		private static void SetInOutsetRectanglePoints(Border border, CssBox b, RRect r, bool isLineStart, bool isLineEnd)
		{
			switch (border)
			{
			case Border.Top:
				BordersDrawHandler._borderPts[0] = new RPoint(r.Left, r.Top);
				BordersDrawHandler._borderPts[1] = new RPoint(r.Right, r.Top);
				BordersDrawHandler._borderPts[2] = new RPoint(r.Right, r.Top + b.ActualBorderTopWidth);
				BordersDrawHandler._borderPts[3] = new RPoint(r.Left, r.Top + b.ActualBorderTopWidth);
				if (isLineEnd)
				{
					RPoint[] borderPts = BordersDrawHandler._borderPts;
					int num = 2;
					borderPts[num].X = borderPts[num].X - b.ActualBorderRightWidth;
				}
				if (isLineStart)
				{
					RPoint[] borderPts2 = BordersDrawHandler._borderPts;
					int num2 = 3;
					borderPts2[num2].X = borderPts2[num2].X + b.ActualBorderLeftWidth;
					return;
				}
				break;
			case Border.Right:
				BordersDrawHandler._borderPts[0] = new RPoint(r.Right - b.ActualBorderRightWidth, r.Top + b.ActualBorderTopWidth);
				BordersDrawHandler._borderPts[1] = new RPoint(r.Right, r.Top);
				BordersDrawHandler._borderPts[2] = new RPoint(r.Right, r.Bottom);
				BordersDrawHandler._borderPts[3] = new RPoint(r.Right - b.ActualBorderRightWidth, r.Bottom - b.ActualBorderBottomWidth);
				return;
			case Border.Bottom:
				BordersDrawHandler._borderPts[0] = new RPoint(r.Left, r.Bottom - b.ActualBorderBottomWidth);
				BordersDrawHandler._borderPts[1] = new RPoint(r.Right, r.Bottom - b.ActualBorderBottomWidth);
				BordersDrawHandler._borderPts[2] = new RPoint(r.Right, r.Bottom);
				BordersDrawHandler._borderPts[3] = new RPoint(r.Left, r.Bottom);
				if (isLineStart)
				{
					RPoint[] borderPts3 = BordersDrawHandler._borderPts;
					int num3 = 0;
					borderPts3[num3].X = borderPts3[num3].X + b.ActualBorderLeftWidth;
				}
				if (isLineEnd)
				{
					RPoint[] borderPts4 = BordersDrawHandler._borderPts;
					int num4 = 1;
					borderPts4[num4].X = borderPts4[num4].X - b.ActualBorderRightWidth;
					return;
				}
				break;
			case Border.Left:
				BordersDrawHandler._borderPts[0] = new RPoint(r.Left, r.Top);
				BordersDrawHandler._borderPts[1] = new RPoint(r.Left + b.ActualBorderLeftWidth, r.Top + b.ActualBorderTopWidth);
				BordersDrawHandler._borderPts[2] = new RPoint(r.Left + b.ActualBorderLeftWidth, r.Bottom - b.ActualBorderBottomWidth);
				BordersDrawHandler._borderPts[3] = new RPoint(r.Left, r.Bottom);
				break;
			default:
				return;
			}
		}

		// Token: 0x060007E5 RID: 2021 RVA: 0x00040960 File Offset: 0x0003EB60
		private static RGraphicsPath GetRoundedBorderPath(RGraphics g, Border border, CssBox b, RRect r)
		{
			RGraphicsPath rgraphicsPath = null;
			switch (border)
			{
			case Border.Top:
				if (b.ActualCornerNw > 0.0 || b.ActualCornerNe > 0.0)
				{
					rgraphicsPath = g.GetGraphicsPath();
					rgraphicsPath.Start(r.Left + b.ActualBorderLeftWidth / 2.0, r.Top + b.ActualBorderTopWidth / 2.0 + b.ActualCornerNw);
					if (b.ActualCornerNw > 0.0)
					{
						rgraphicsPath.ArcTo(r.Left + b.ActualBorderLeftWidth / 2.0 + b.ActualCornerNw, r.Top + b.ActualBorderTopWidth / 2.0, b.ActualCornerNw, RGraphicsPath.Corner.TopLeft);
					}
					rgraphicsPath.LineTo(r.Right - b.ActualBorderRightWidth / 2.0 - b.ActualCornerNe, r.Top + b.ActualBorderTopWidth / 2.0);
					if (b.ActualCornerNe > 0.0)
					{
						rgraphicsPath.ArcTo(r.Right - b.ActualBorderRightWidth / 2.0, r.Top + b.ActualBorderTopWidth / 2.0 + b.ActualCornerNe, b.ActualCornerNe, RGraphicsPath.Corner.TopRight);
					}
				}
				break;
			case Border.Right:
				if (b.ActualCornerNe > 0.0 || b.ActualCornerSe > 0.0)
				{
					rgraphicsPath = g.GetGraphicsPath();
					bool flag = BordersDrawHandler.smethod_1(b.BorderTopStyle, <Module>.smethod_24<string>(3284293868U)) || BordersDrawHandler.smethod_1(b.BorderTopStyle, <Module>.smethod_26<string>(1903651106U));
					bool flag2 = BordersDrawHandler.smethod_1(b.BorderBottomStyle, <Module>.smethod_23<string>(436056481U)) || BordersDrawHandler.smethod_1(b.BorderBottomStyle, <Module>.smethod_24<string>(2643072343U));
					rgraphicsPath.Start(r.Right - b.ActualBorderRightWidth / 2.0 - (flag ? b.ActualCornerNe : 0.0), r.Top + b.ActualBorderTopWidth / 2.0 + (flag ? 0.0 : b.ActualCornerNe));
					if (b.ActualCornerNe > 0.0 && flag)
					{
						rgraphicsPath.ArcTo(r.Right - b.ActualBorderLeftWidth / 2.0, r.Top + b.ActualBorderTopWidth / 2.0 + b.ActualCornerNe, b.ActualCornerNe, RGraphicsPath.Corner.TopRight);
					}
					rgraphicsPath.LineTo(r.Right - b.ActualBorderRightWidth / 2.0, r.Bottom - b.ActualBorderBottomWidth / 2.0 - b.ActualCornerSe);
					if (b.ActualCornerSe > 0.0 && flag2)
					{
						rgraphicsPath.ArcTo(r.Right - b.ActualBorderRightWidth / 2.0 - b.ActualCornerSe, r.Bottom - b.ActualBorderBottomWidth / 2.0, b.ActualCornerSe, RGraphicsPath.Corner.BottomRight);
					}
				}
				break;
			case Border.Bottom:
				if (b.ActualCornerSw > 0.0 || b.ActualCornerSe > 0.0)
				{
					rgraphicsPath = g.GetGraphicsPath();
					rgraphicsPath.Start(r.Right - b.ActualBorderRightWidth / 2.0, r.Bottom - b.ActualBorderBottomWidth / 2.0 - b.ActualCornerSe);
					if (b.ActualCornerSe > 0.0)
					{
						rgraphicsPath.ArcTo(r.Right - b.ActualBorderRightWidth / 2.0 - b.ActualCornerSe, r.Bottom - b.ActualBorderBottomWidth / 2.0, b.ActualCornerSe, RGraphicsPath.Corner.BottomRight);
					}
					rgraphicsPath.LineTo(r.Left + b.ActualBorderLeftWidth / 2.0 + b.ActualCornerSw, r.Bottom - b.ActualBorderBottomWidth / 2.0);
					if (b.ActualCornerSw > 0.0)
					{
						rgraphicsPath.ArcTo(r.Left + b.ActualBorderLeftWidth / 2.0, r.Bottom - b.ActualBorderBottomWidth / 2.0 - b.ActualCornerSw, b.ActualCornerSw, RGraphicsPath.Corner.BottomLeft);
					}
				}
				break;
			case Border.Left:
				if (b.ActualCornerNw > 0.0 || b.ActualCornerSw > 0.0)
				{
					rgraphicsPath = g.GetGraphicsPath();
					bool flag3 = BordersDrawHandler.smethod_1(b.BorderTopStyle, <Module>.smethod_27<string>(1876627641U)) || BordersDrawHandler.smethod_1(b.BorderTopStyle, <Module>.smethod_26<string>(1903651106U));
					bool flag4 = BordersDrawHandler.smethod_1(b.BorderBottomStyle, <Module>.smethod_26<string>(1660243523U)) || BordersDrawHandler.smethod_1(b.BorderBottomStyle, <Module>.smethod_24<string>(2643072343U));
					rgraphicsPath.Start(r.Left + b.ActualBorderLeftWidth / 2.0 + (flag4 ? b.ActualCornerSw : 0.0), r.Bottom - b.ActualBorderBottomWidth / 2.0 - (flag4 ? 0.0 : b.ActualCornerSw));
					if (b.ActualCornerSw > 0.0 && flag4)
					{
						rgraphicsPath.ArcTo(r.Left + b.ActualBorderLeftWidth / 2.0, r.Bottom - b.ActualBorderBottomWidth / 2.0 - b.ActualCornerSw, b.ActualCornerSw, RGraphicsPath.Corner.BottomLeft);
					}
					rgraphicsPath.LineTo(r.Left + b.ActualBorderLeftWidth / 2.0, r.Top + b.ActualBorderTopWidth / 2.0 + b.ActualCornerNw);
					if (b.ActualCornerNw > 0.0 && flag3)
					{
						rgraphicsPath.ArcTo(r.Left + b.ActualBorderLeftWidth / 2.0 + b.ActualCornerNw, r.Top + b.ActualBorderTopWidth / 2.0, b.ActualCornerNw, RGraphicsPath.Corner.TopLeft);
					}
				}
				break;
			}
			return rgraphicsPath;
		}

		// Token: 0x060007E6 RID: 2022 RVA: 0x00041000 File Offset: 0x0003F200
		private static RPen GetPen(RGraphics g, string style, RColor color, double width)
		{
			RPen pen = g.GetPen(color);
			pen.Width = width;
			if (style != null)
			{
				if (!BordersDrawHandler.smethod_1(style, <Module>.smethod_27<string>(1993406560U)))
				{
					if (BordersDrawHandler.smethod_1(style, <Module>.smethod_27<string>(4090933372U)))
					{
						pen.DashStyle = RDashStyle.Dot;
					}
					else if (BordersDrawHandler.smethod_1(style, <Module>.smethod_23<string>(3780036523U)))
					{
						pen.DashStyle = RDashStyle.Dash;
					}
				}
				else
				{
					pen.DashStyle = RDashStyle.Solid;
				}
			}
			return pen;
		}

		// Token: 0x060007E7 RID: 2023 RVA: 0x00041074 File Offset: 0x0003F274
		private static RColor GetColor(Border border, CssBoxProperties box, string style)
		{
			switch (border)
			{
			case Border.Top:
				if (!BordersDrawHandler.smethod_1(style, <Module>.smethod_23<string>(2096943130U)))
				{
					return box.ActualBorderTopColor;
				}
				return BordersDrawHandler.Darken(box.ActualBorderTopColor);
			case Border.Right:
				if (!BordersDrawHandler.smethod_1(style, <Module>.smethod_24<string>(3338661108U)))
				{
					return box.ActualBorderRightColor;
				}
				return BordersDrawHandler.Darken(box.ActualBorderRightColor);
			case Border.Bottom:
				if (!BordersDrawHandler.smethod_1(style, <Module>.smethod_27<string>(215561313U)))
				{
					return box.ActualBorderBottomColor;
				}
				return BordersDrawHandler.Darken(box.ActualBorderBottomColor);
			case Border.Left:
				if (!BordersDrawHandler.smethod_1(style, <Module>.smethod_23<string>(2096943130U)))
				{
					return box.ActualBorderLeftColor;
				}
				return BordersDrawHandler.Darken(box.ActualBorderLeftColor);
			default:
				throw BordersDrawHandler.smethod_5(<Module>.smethod_23<string>(46100358U));
			}
		}

		// Token: 0x060007E8 RID: 2024 RVA: 0x0004113C File Offset: 0x0003F33C
		private static double GetWidth(Border border, CssBoxProperties box)
		{
			switch (border)
			{
			case Border.Top:
				return box.ActualBorderTopWidth;
			case Border.Right:
				return box.ActualBorderRightWidth;
			case Border.Bottom:
				return box.ActualBorderBottomWidth;
			case Border.Left:
				return box.ActualBorderLeftWidth;
			default:
				throw BordersDrawHandler.smethod_5(<Module>.smethod_25<string>(4143021981U));
			}
		}

		// Token: 0x060007E9 RID: 2025 RVA: 0x0004118C File Offset: 0x0003F38C
		private static string GetStyle(Border border, CssBoxProperties box)
		{
			switch (border)
			{
			case Border.Top:
				return box.BorderTopStyle;
			case Border.Right:
				return box.BorderRightStyle;
			case Border.Bottom:
				return box.BorderBottomStyle;
			case Border.Left:
				return box.BorderLeftStyle;
			default:
				throw BordersDrawHandler.smethod_5(<Module>.smethod_25<string>(4143021981U));
			}
		}

		// Token: 0x060007EA RID: 2026 RVA: 0x0000F841 File Offset: 0x0000DA41
		private static RColor Darken(RColor c)
		{
			return RColor.FromArgb((int)(c.R / 2), (int)(c.G / 2), (int)(c.B / 2));
		}

		// Token: 0x060007EC RID: 2028 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_0(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x060007ED RID: 2029 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_1(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x060007EE RID: 2030 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_2(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x060007EF RID: 2031 RVA: 0x0000ED7C File Offset: 0x0000CF7C
		static double smethod_3(double double_0)
		{
			return Math.Ceiling(double_0);
		}

		// Token: 0x060007F0 RID: 2032 RVA: 0x0000EE64 File Offset: 0x0000D064
		static double smethod_4(double double_0)
		{
			return Math.Floor(double_0);
		}

		// Token: 0x060007F1 RID: 2033 RVA: 0x0000F870 File Offset: 0x0000DA70
		static ArgumentOutOfRangeException smethod_5(string string_0)
		{
			return new ArgumentOutOfRangeException(string_0);
		}

		// Token: 0x040002D9 RID: 729
		private static readonly RPoint[] _borderPts = new RPoint[4];
	}
}
