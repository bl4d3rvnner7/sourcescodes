﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using TheArtOfDev.HtmlRenderer.Core.Entities;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Handlers
{
	// Token: 0x020000A1 RID: 161
	internal static class StylesheetLoadHandler
	{
		// Token: 0x06000878 RID: 2168 RVA: 0x000437A4 File Offset: 0x000419A4
		public static void LoadStylesheet(HtmlContainerInt htmlContainer, string src, Dictionary<string, string> attributes, out string stylesheet, out CssData stylesheetData)
		{
			ArgChecker.AssertArgNotNull(htmlContainer, <Module>.smethod_23<string>(1410895215U));
			stylesheet = null;
			stylesheetData = null;
			try
			{
				HtmlStylesheetLoadEventArgs htmlStylesheetLoadEventArgs = new HtmlStylesheetLoadEventArgs(src, attributes);
				htmlContainer.RaiseHtmlStylesheetLoadEvent(htmlStylesheetLoadEventArgs);
				if (!StylesheetLoadHandler.smethod_0(htmlStylesheetLoadEventArgs.SetStyleSheet))
				{
					stylesheet = htmlStylesheetLoadEventArgs.SetStyleSheet;
				}
				else if (htmlStylesheetLoadEventArgs.SetStyleSheetData == null)
				{
					if (htmlStylesheetLoadEventArgs.SetSrc != null)
					{
						stylesheet = StylesheetLoadHandler.LoadStylesheet(htmlContainer, htmlStylesheetLoadEventArgs.SetSrc);
					}
					else
					{
						stylesheet = StylesheetLoadHandler.LoadStylesheet(htmlContainer, src);
					}
				}
				else
				{
					stylesheetData = htmlStylesheetLoadEventArgs.SetStyleSheetData;
				}
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_00A8:
					int num = -714877423;
					for (;;)
					{
						switch (num ^ -714877424)
						{
						case 1:
							htmlContainer.ReportError(HtmlRenderErrorType.CssParsing, <Module>.smethod_24<string>(1905313468U), ex);
							num = -714877424;
							continue;
						case 2:
							goto IL_00A8;
						}
						goto Block_7;
					}
				}
				Block_7:;
			}
		}

		// Token: 0x06000879 RID: 2169 RVA: 0x00043874 File Offset: 0x00041A74
		private static string LoadStylesheet(HtmlContainerInt htmlContainer, string src)
		{
			Uri uri = CommonUtils.TryGetUri(src);
			if (!StylesheetLoadHandler.smethod_1(uri, null) && !StylesheetLoadHandler.smethod_3(StylesheetLoadHandler.smethod_2(uri), <Module>.smethod_23<string>(1770111473U)))
			{
				return StylesheetLoadHandler.LoadStylesheetFromUri(htmlContainer, uri);
			}
			return StylesheetLoadHandler.LoadStylesheetFromFile(htmlContainer, StylesheetLoadHandler.smethod_4(uri, null) ? StylesheetLoadHandler.smethod_5(uri) : src);
		}

		// Token: 0x0600087A RID: 2170 RVA: 0x000438C8 File Offset: 0x00041AC8
		private static string LoadStylesheetFromFile(HtmlContainerInt htmlContainer, string path)
		{
			FileInfo fileInfo = CommonUtils.TryGetFileInfo(path);
			if (fileInfo != null)
			{
				if (StylesheetLoadHandler.smethod_6(fileInfo))
				{
					StreamReader streamReader = StylesheetLoadHandler.smethod_8(StylesheetLoadHandler.smethod_7(fileInfo));
					string text;
					try
					{
						text = StylesheetLoadHandler.smethod_9(streamReader);
					}
					finally
					{
						if (streamReader != null)
						{
							StylesheetLoadHandler.smethod_10(streamReader);
						}
					}
					return text;
				}
				htmlContainer.ReportError(HtmlRenderErrorType.CssParsing, StylesheetLoadHandler.smethod_11(<Module>.smethod_27<string>(2733582108U), path), null);
			}
			else
			{
				htmlContainer.ReportError(HtmlRenderErrorType.CssParsing, StylesheetLoadHandler.smethod_11(<Module>.smethod_25<string>(1201255504U), path), null);
			}
			return string.Empty;
		}

		// Token: 0x0600087B RID: 2171 RVA: 0x00043950 File Offset: 0x00041B50
		private static string LoadStylesheetFromUri(HtmlContainerInt htmlContainer, Uri uri)
		{
			WebClient webClient = StylesheetLoadHandler.smethod_12();
			string text2;
			try
			{
				string text = StylesheetLoadHandler.smethod_13(webClient, uri);
				try
				{
					text = StylesheetLoadHandler.CorrectRelativeUrls(text, uri);
				}
				catch (Exception ex)
				{
					htmlContainer.ReportError(HtmlRenderErrorType.CssParsing, <Module>.smethod_23<string>(3820954245U), ex);
				}
				text2 = text;
			}
			finally
			{
				if (webClient != null)
				{
					StylesheetLoadHandler.smethod_10(webClient);
				}
			}
			return text2;
		}

		// Token: 0x0600087C RID: 2172 RVA: 0x000439B8 File Offset: 0x00041BB8
		private static string CorrectRelativeUrls(string stylesheet, Uri baseUri)
		{
			int num = 0;
			while (num >= 0 && num < StylesheetLoadHandler.smethod_23(stylesheet))
			{
				num = StylesheetLoadHandler.smethod_14(stylesheet, <Module>.smethod_23<string>(2868219108U), num, StringComparison.OrdinalIgnoreCase);
				if (num >= 0)
				{
					int num2 = StylesheetLoadHandler.smethod_15(stylesheet, ')', num);
					if (num2 > num + 4)
					{
						int num3 = 4 + ((StylesheetLoadHandler.smethod_16(stylesheet, num + 4) == '\'') ? 1 : 0);
						int num4 = ((StylesheetLoadHandler.smethod_16(stylesheet, num2 - 1) == '\'') ? 1 : 0);
						string text = StylesheetLoadHandler.smethod_17(stylesheet, num + num3, num2 - num - num3 - num4);
						Uri uri;
						if (StylesheetLoadHandler.smethod_18(text, UriKind.Relative, ref uri))
						{
							uri = StylesheetLoadHandler.smethod_19(baseUri, uri);
							stylesheet = StylesheetLoadHandler.smethod_20(stylesheet, num + 4, num2 - num - 4);
							stylesheet = StylesheetLoadHandler.smethod_22(stylesheet, num + 4, StylesheetLoadHandler.smethod_21(uri));
							num += StylesheetLoadHandler.smethod_23(StylesheetLoadHandler.smethod_21(uri)) + 4;
						}
						else
						{
							num = num2 + 1;
						}
					}
					else
					{
						num += 4;
					}
				}
			}
			return stylesheet;
		}

		// Token: 0x0600087D RID: 2173 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_0(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x0600087E RID: 2174 RVA: 0x0000FCA7 File Offset: 0x0000DEA7
		static bool smethod_1(Uri uri_0, Uri uri_1)
		{
			return uri_0 == uri_1;
		}

		// Token: 0x0600087F RID: 2175 RVA: 0x0000FAE8 File Offset: 0x0000DCE8
		static string smethod_2(Uri uri_0)
		{
			return uri_0.Scheme;
		}

		// Token: 0x06000880 RID: 2176 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_3(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06000881 RID: 2177 RVA: 0x0000FADF File Offset: 0x0000DCDF
		static bool smethod_4(Uri uri_0, Uri uri_1)
		{
			return uri_0 != uri_1;
		}

		// Token: 0x06000882 RID: 2178 RVA: 0x0000FAF0 File Offset: 0x0000DCF0
		static string smethod_5(Uri uri_0)
		{
			return uri_0.AbsolutePath;
		}

		// Token: 0x06000883 RID: 2179 RVA: 0x0000FAF8 File Offset: 0x0000DCF8
		static bool smethod_6(FileSystemInfo fileSystemInfo_0)
		{
			return fileSystemInfo_0.Exists;
		}

		// Token: 0x06000884 RID: 2180 RVA: 0x0000FB00 File Offset: 0x0000DD00
		static string smethod_7(FileSystemInfo fileSystemInfo_0)
		{
			return fileSystemInfo_0.FullName;
		}

		// Token: 0x06000885 RID: 2181 RVA: 0x0000CDDC File Offset: 0x0000AFDC
		static StreamReader smethod_8(string string_0)
		{
			return new StreamReader(string_0);
		}

		// Token: 0x06000886 RID: 2182 RVA: 0x0000DF57 File Offset: 0x0000C157
		static string smethod_9(TextReader textReader_0)
		{
			return textReader_0.ReadToEnd();
		}

		// Token: 0x06000887 RID: 2183 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_10(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06000888 RID: 2184 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_11(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x06000889 RID: 2185 RVA: 0x0000EE74 File Offset: 0x0000D074
		static WebClient smethod_12()
		{
			return new WebClient();
		}

		// Token: 0x0600088A RID: 2186 RVA: 0x0000FCB0 File Offset: 0x0000DEB0
		static string smethod_13(WebClient webClient_0, Uri uri_0)
		{
			return webClient_0.DownloadString(uri_0);
		}

		// Token: 0x0600088B RID: 2187 RVA: 0x0000FCB9 File Offset: 0x0000DEB9
		static int smethod_14(string string_0, string string_1, int int_0, StringComparison stringComparison_0)
		{
			return string_0.IndexOf(string_1, int_0, stringComparison_0);
		}

		// Token: 0x0600088C RID: 2188 RVA: 0x0000EE25 File Offset: 0x0000D025
		static int smethod_15(string string_0, char char_0, int int_0)
		{
			return string_0.IndexOf(char_0, int_0);
		}

		// Token: 0x0600088D RID: 2189 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_16(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x0600088E RID: 2190 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_17(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x0600088F RID: 2191 RVA: 0x0000EDF1 File Offset: 0x0000CFF1
		static bool smethod_18(string string_0, UriKind uriKind_0, ref Uri uri_0)
		{
			return Uri.TryCreate(string_0, uriKind_0, out uri_0);
		}

		// Token: 0x06000890 RID: 2192 RVA: 0x0000FCC4 File Offset: 0x0000DEC4
		static Uri smethod_19(Uri uri_0, Uri uri_1)
		{
			return new Uri(uri_0, uri_1);
		}

		// Token: 0x06000891 RID: 2193 RVA: 0x0000D926 File Offset: 0x0000BB26
		static string smethod_20(string string_0, int int_0, int int_1)
		{
			return string_0.Remove(int_0, int_1);
		}

		// Token: 0x06000892 RID: 2194 RVA: 0x0000FCCD File Offset: 0x0000DECD
		static string smethod_21(Uri uri_0)
		{
			return uri_0.AbsoluteUri;
		}

		// Token: 0x06000893 RID: 2195 RVA: 0x0000FCD5 File Offset: 0x0000DED5
		static string smethod_22(string string_0, int int_0, string string_1)
		{
			return string_0.Insert(int_0, string_1);
		}

		// Token: 0x06000894 RID: 2196 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_23(string string_0)
		{
			return string_0.Length;
		}
	}
}
