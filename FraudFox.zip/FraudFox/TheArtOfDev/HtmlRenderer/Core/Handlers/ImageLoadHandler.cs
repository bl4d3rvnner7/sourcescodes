﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Entities;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Handlers
{
	// Token: 0x0200009E RID: 158
	internal sealed class ImageLoadHandler : IDisposable
	{
		// Token: 0x0600082E RID: 2094 RVA: 0x0000F9C4 File Offset: 0x0000DBC4
		public ImageLoadHandler(HtmlContainerInt htmlContainer, ActionInt<RImage, RRect, bool> loadCompleteCallback)
		{
			ArgChecker.AssertArgNotNull(htmlContainer, <Module>.smethod_24<string>(1033414078U));
			ArgChecker.AssertArgNotNull(loadCompleteCallback, <Module>.smethod_25<string>(2961266619U));
			this._htmlContainer = htmlContainer;
			this._loadCompleteCallback = loadCompleteCallback;
		}

		// Token: 0x17000159 RID: 345
		// (get) Token: 0x0600082F RID: 2095 RVA: 0x0000F9FA File Offset: 0x0000DBFA
		public RImage Image
		{
			get
			{
				return this._image;
			}
		}

		// Token: 0x1700015A RID: 346
		// (get) Token: 0x06000830 RID: 2096 RVA: 0x0000FA02 File Offset: 0x0000DC02
		public RRect Rectangle
		{
			get
			{
				return this._imageRectangle;
			}
		}

		// Token: 0x06000831 RID: 2097 RVA: 0x000426A0 File Offset: 0x000408A0
		public void LoadImage(string src, Dictionary<string, string> attributes)
		{
			try
			{
				HtmlImageLoadEventArgs htmlImageLoadEventArgs = new HtmlImageLoadEventArgs(src, attributes, new HtmlImageLoadCallback(this.OnHtmlImageLoadEventCallback));
				this._htmlContainer.RaiseHtmlImageLoadEvent(htmlImageLoadEventArgs);
				this._asyncCallback = !this._htmlContainer.AvoidAsyncImagesLoading;
				if (!htmlImageLoadEventArgs.Handled)
				{
					if (!ImageLoadHandler.smethod_0(src))
					{
						if (!ImageLoadHandler.smethod_1(src, <Module>.smethod_27<string>(588984230U), StringComparison.CurrentCultureIgnoreCase))
						{
							this.SetImageFromPath(src);
						}
						else
						{
							this.SetFromInlineData(src);
						}
					}
					else
					{
						this.ImageLoadComplete(false);
					}
				}
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_00BE:
					int num = 430013184;
					for (;;)
					{
						switch (num ^ 430013187)
						{
						case 0:
							goto IL_00BE;
						case 2:
							this.ImageLoadComplete(false);
							num = 430013186;
							continue;
						case 3:
							this._htmlContainer.ReportError(HtmlRenderErrorType.Image, <Module>.smethod_23<string>(124646330U), ex);
							num = 430013185;
							continue;
						}
						goto Block_6;
					}
				}
				Block_6:;
			}
		}

		// Token: 0x06000832 RID: 2098 RVA: 0x0000FA0A File Offset: 0x0000DC0A
		public void Dispose()
		{
			this._disposed = true;
			this.ReleaseObjects();
		}

		// Token: 0x06000833 RID: 2099 RVA: 0x00042784 File Offset: 0x00040984
		private void OnHtmlImageLoadEventCallback(string path, object image, RRect imageRectangle)
		{
			if (!this._disposed)
			{
				this._imageRectangle = imageRectangle;
				if (image != null)
				{
					this._image = this._htmlContainer.Adapter.ConvertImage(image);
					this.ImageLoadComplete(this._asyncCallback);
					return;
				}
				if (!ImageLoadHandler.smethod_0(path))
				{
					this.SetImageFromPath(path);
					return;
				}
				this.ImageLoadComplete(this._asyncCallback);
			}
		}

		// Token: 0x06000834 RID: 2100 RVA: 0x0000FA19 File Offset: 0x0000DC19
		private void SetFromInlineData(string src)
		{
			this._image = this.GetImageFromData(src);
			if (this._image == null)
			{
				this._htmlContainer.ReportError(HtmlRenderErrorType.Image, <Module>.smethod_25<string>(3796436055U), null);
			}
			this._releaseImageObject = true;
			this.ImageLoadComplete(false);
		}

		// Token: 0x06000835 RID: 2101 RVA: 0x000427E8 File Offset: 0x000409E8
		private RImage GetImageFromData(string src)
		{
			string[] array = ImageLoadHandler.smethod_4(ImageLoadHandler.smethod_3(src, ImageLoadHandler.smethod_2(src, ':') + 1), new char[] { ',' }, 2);
			if (array.Length == 2)
			{
				int num = 0;
				int num2 = 0;
				foreach (string text in ImageLoadHandler.smethod_5(array[0], new char[] { ';' }))
				{
					string text2 = ImageLoadHandler.smethod_6(text);
					if (ImageLoadHandler.smethod_1(text2, <Module>.smethod_23<string>(2892173735U), StringComparison.InvariantCultureIgnoreCase))
					{
						num++;
					}
					if (ImageLoadHandler.smethod_7(text2, <Module>.smethod_24<string>(808326099U), StringComparison.InvariantCultureIgnoreCase))
					{
						num2++;
					}
				}
				if (num > 0)
				{
					byte[] array3 = ((num2 > 0) ? ImageLoadHandler.smethod_11(ImageLoadHandler.smethod_6(array[1])) : ImageLoadHandler.smethod_10(ImageLoadHandler.smethod_8(), ImageLoadHandler.smethod_9(ImageLoadHandler.smethod_6(array[1]))));
					return this._htmlContainer.Adapter.ImageFromStream(ImageLoadHandler.smethod_12(array3));
				}
			}
			return null;
		}

		// Token: 0x06000836 RID: 2102 RVA: 0x000428EC File Offset: 0x00040AEC
		private void SetImageFromPath(string path)
		{
			Uri uri = CommonUtils.TryGetUri(path);
			for (;;)
			{
				IL_00E5:
				int num = -443064673;
				for (;;)
				{
					string text;
					FileInfo fileInfo;
					switch (num ^ -443064674)
					{
					case 0:
						if (!ImageLoadHandler.smethod_13(uri, null))
						{
							num = -443064682;
							continue;
						}
						text = ImageLoadHandler.smethod_16(uri);
						goto IL_000D;
					case 1:
						num = ((!ImageLoadHandler.smethod_13(uri, null)) ? (-443064674) : (-443064678));
						continue;
					case 2:
						if (fileInfo != null)
						{
							this.SetImageFromFile(fileInfo);
							num = -443064681;
							continue;
						}
						goto IL_0042;
					case 3:
						goto IL_0042;
					case 4:
						num = ((!ImageLoadHandler.smethod_15(ImageLoadHandler.smethod_14(uri), <Module>.smethod_27<string>(723077769U))) ? (-443064674) : (-443064680));
						continue;
					case 6:
						goto IL_00ED;
					case 7:
						goto IL_00E5;
					case 8:
						text = path;
						goto IL_000D;
					case 9:
						return;
					}
					return;
					IL_000D:
					fileInfo = CommonUtils.TryGetFileInfo(text);
					num = -443064676;
					continue;
					IL_0042:
					this._htmlContainer.ReportError(HtmlRenderErrorType.Image, ImageLoadHandler.smethod_17(<Module>.smethod_25<string>(1201255504U), path), null);
					this.ImageLoadComplete(false);
					num = -443064677;
				}
			}
			return;
			IL_00ED:
			this.SetImageFromUrl(uri);
		}

		// Token: 0x06000837 RID: 2103 RVA: 0x000429F0 File Offset: 0x00040BF0
		private void SetImageFromFile(FileInfo source)
		{
			if (!ImageLoadHandler.smethod_18(source))
			{
				this.ImageLoadComplete(true);
				return;
			}
			if (!this._htmlContainer.AvoidAsyncImagesLoading)
			{
				ImageLoadHandler.smethod_20(delegate(object state)
				{
					this.LoadImageFromFile(ImageLoadHandler.<>c__DisplayClass2.smethod_0(source));
				});
				return;
			}
			this.LoadImageFromFile(ImageLoadHandler.smethod_19(source));
		}

		// Token: 0x06000838 RID: 2104 RVA: 0x00042A60 File Offset: 0x00040C60
		private void LoadImageFromFile(string source)
		{
			try
			{
				FileStream fileStream = ImageLoadHandler.smethod_21(source, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
				bool flag = false;
				try
				{
					ActionInt<RImage, RRect, bool> loadCompleteCallback;
					ImageLoadHandler.smethod_22(loadCompleteCallback = this._loadCompleteCallback, ref flag);
					this._imageFileStream = fileStream;
					if (!this._disposed)
					{
						this._image = this._htmlContainer.Adapter.ImageFromStream(this._imageFileStream);
					}
					this._releaseImageObject = true;
				}
				finally
				{
					if (flag)
					{
						ActionInt<RImage, RRect, bool> loadCompleteCallback;
						ImageLoadHandler.smethod_23(loadCompleteCallback);
					}
				}
				this.ImageLoadComplete(true);
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_00B4:
					int num = 656657281;
					for (;;)
					{
						switch (num ^ 656657283)
						{
						case 0:
							goto IL_00B4;
						case 2:
							this._htmlContainer.ReportError(HtmlRenderErrorType.Image, ImageLoadHandler.smethod_17(<Module>.smethod_24<string>(2488103904U), source), ex);
							num = 656657280;
							continue;
						case 3:
							this.ImageLoadComplete(true);
							num = 656657282;
							continue;
						}
						goto Block_8;
					}
				}
				Block_8:;
			}
		}

		// Token: 0x06000839 RID: 2105 RVA: 0x00042B48 File Offset: 0x00040D48
		private void SetImageFromUrl(Uri source)
		{
			FileInfo localfileName = CommonUtils.GetLocalfileName(source);
			if (ImageLoadHandler.smethod_18(localfileName) && ImageLoadHandler.smethod_24(localfileName) > 0L)
			{
				this.SetImageFromFile(localfileName);
				return;
			}
			this._htmlContainer.GetImageDownloader().DownloadImage(source, ImageLoadHandler.smethod_19(localfileName), !this._htmlContainer.AvoidAsyncImagesLoading, new DownloadFileAsyncCallback(this.OnDownloadImageCompleted));
		}

		// Token: 0x0600083A RID: 2106 RVA: 0x0000FA55 File Offset: 0x0000DC55
		private void OnDownloadImageCompleted(Uri imageUri, string filePath, Exception error, bool canceled)
		{
			if (!canceled && !this._disposed)
			{
				if (error == null)
				{
					this.LoadImageFromFile(filePath);
					return;
				}
				this._htmlContainer.ReportError(HtmlRenderErrorType.Image, ImageLoadHandler.smethod_25(<Module>.smethod_25<string>(2106022393U), imageUri), error);
				this.ImageLoadComplete(true);
			}
		}

		// Token: 0x0600083B RID: 2107 RVA: 0x0000FA94 File Offset: 0x0000DC94
		private void ImageLoadComplete(bool async = true)
		{
			if (this._disposed)
			{
				this.ReleaseObjects();
				return;
			}
			this._loadCompleteCallback(this._image, this._imageRectangle, async);
		}

		// Token: 0x0600083C RID: 2108 RVA: 0x00042BB0 File Offset: 0x00040DB0
		private void ReleaseObjects()
		{
			bool flag = false;
			try
			{
				ActionInt<RImage, RRect, bool> loadCompleteCallback;
				ImageLoadHandler.smethod_22(loadCompleteCallback = this._loadCompleteCallback, ref flag);
				if (this._releaseImageObject && this._image != null)
				{
					this._image.Dispose();
					this._image = null;
				}
				if (this._imageFileStream != null)
				{
					ImageLoadHandler.smethod_26(this._imageFileStream);
					this._imageFileStream = null;
				}
			}
			finally
			{
				if (flag)
				{
					ActionInt<RImage, RRect, bool> loadCompleteCallback;
					ImageLoadHandler.smethod_23(loadCompleteCallback);
				}
			}
		}

		// Token: 0x0600083D RID: 2109 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_0(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x0600083E RID: 2110 RVA: 0x0000F8C5 File Offset: 0x0000DAC5
		static bool smethod_1(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.StartsWith(string_1, stringComparison_0);
		}

		// Token: 0x0600083F RID: 2111 RVA: 0x0000FABD File Offset: 0x0000DCBD
		static int smethod_2(string string_0, char char_0)
		{
			return string_0.IndexOf(char_0);
		}

		// Token: 0x06000840 RID: 2112 RVA: 0x0000D416 File Offset: 0x0000B616
		static string smethod_3(string string_0, int int_0)
		{
			return string_0.Substring(int_0);
		}

		// Token: 0x06000841 RID: 2113 RVA: 0x0000FAC6 File Offset: 0x0000DCC6
		static string[] smethod_4(string string_0, char[] char_0, int int_0)
		{
			return string_0.Split(char_0, int_0);
		}

		// Token: 0x06000842 RID: 2114 RVA: 0x0000C693 File Offset: 0x0000A893
		static string[] smethod_5(string string_0, char[] char_0)
		{
			return string_0.Split(char_0);
		}

		// Token: 0x06000843 RID: 2115 RVA: 0x0000C6B8 File Offset: 0x0000A8B8
		static string smethod_6(string string_0)
		{
			return string_0.Trim();
		}

		// Token: 0x06000844 RID: 2116 RVA: 0x0000D0A2 File Offset: 0x0000B2A2
		static bool smethod_7(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.Equals(string_1, stringComparison_0);
		}

		// Token: 0x06000845 RID: 2117 RVA: 0x0000FAD0 File Offset: 0x0000DCD0
		static UTF8Encoding smethod_8()
		{
			return new UTF8Encoding();
		}

		// Token: 0x06000846 RID: 2118 RVA: 0x0000FAD7 File Offset: 0x0000DCD7
		static string smethod_9(string string_0)
		{
			return Uri.UnescapeDataString(string_0);
		}

		// Token: 0x06000847 RID: 2119 RVA: 0x0000C402 File Offset: 0x0000A602
		static byte[] smethod_10(Encoding encoding_0, string string_0)
		{
			return encoding_0.GetBytes(string_0);
		}

		// Token: 0x06000848 RID: 2120 RVA: 0x0000C86F File Offset: 0x0000AA6F
		static byte[] smethod_11(string string_0)
		{
			return Convert.FromBase64String(string_0);
		}

		// Token: 0x06000849 RID: 2121 RVA: 0x0000C877 File Offset: 0x0000AA77
		static MemoryStream smethod_12(byte[] byte_0)
		{
			return new MemoryStream(byte_0);
		}

		// Token: 0x0600084A RID: 2122 RVA: 0x0000FADF File Offset: 0x0000DCDF
		static bool smethod_13(Uri uri_0, Uri uri_1)
		{
			return uri_0 != uri_1;
		}

		// Token: 0x0600084B RID: 2123 RVA: 0x0000FAE8 File Offset: 0x0000DCE8
		static string smethod_14(Uri uri_0)
		{
			return uri_0.Scheme;
		}

		// Token: 0x0600084C RID: 2124 RVA: 0x0000CDA1 File Offset: 0x0000AFA1
		static bool smethod_15(string string_0, string string_1)
		{
			return string_0 != string_1;
		}

		// Token: 0x0600084D RID: 2125 RVA: 0x0000FAF0 File Offset: 0x0000DCF0
		static string smethod_16(Uri uri_0)
		{
			return uri_0.AbsolutePath;
		}

		// Token: 0x0600084E RID: 2126 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_17(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x0600084F RID: 2127 RVA: 0x0000FAF8 File Offset: 0x0000DCF8
		static bool smethod_18(FileSystemInfo fileSystemInfo_0)
		{
			return fileSystemInfo_0.Exists;
		}

		// Token: 0x06000850 RID: 2128 RVA: 0x0000FB00 File Offset: 0x0000DD00
		static string smethod_19(FileSystemInfo fileSystemInfo_0)
		{
			return fileSystemInfo_0.FullName;
		}

		// Token: 0x06000851 RID: 2129 RVA: 0x0000EDFB File Offset: 0x0000CFFB
		static bool smethod_20(WaitCallback waitCallback_0)
		{
			return ThreadPool.QueueUserWorkItem(waitCallback_0);
		}

		// Token: 0x06000852 RID: 2130 RVA: 0x0000FB08 File Offset: 0x0000DD08
		static FileStream smethod_21(string string_0, FileMode fileMode_0, FileAccess fileAccess_0, FileShare fileShare_0)
		{
			return File.Open(string_0, fileMode_0, fileAccess_0, fileShare_0);
		}

		// Token: 0x06000853 RID: 2131 RVA: 0x0000DBD7 File Offset: 0x0000BDD7
		static void smethod_22(object object_0, ref bool bool_0)
		{
			Monitor.Enter(object_0, ref bool_0);
		}

		// Token: 0x06000854 RID: 2132 RVA: 0x0000DBEF File Offset: 0x0000BDEF
		static void smethod_23(object object_0)
		{
			Monitor.Exit(object_0);
		}

		// Token: 0x06000855 RID: 2133 RVA: 0x0000D4DD File Offset: 0x0000B6DD
		static long smethod_24(FileInfo fileInfo_0)
		{
			return fileInfo_0.Length;
		}

		// Token: 0x06000856 RID: 2134 RVA: 0x0000EE96 File Offset: 0x0000D096
		static string smethod_25(object object_0, object object_1)
		{
			return object_0 + object_1;
		}

		// Token: 0x06000857 RID: 2135 RVA: 0x0000FB13 File Offset: 0x0000DD13
		static void smethod_26(Stream stream_0)
		{
			stream_0.Dispose();
		}

		// Token: 0x040002F2 RID: 754
		private readonly HtmlContainerInt _htmlContainer;

		// Token: 0x040002F3 RID: 755
		private readonly ActionInt<RImage, RRect, bool> _loadCompleteCallback;

		// Token: 0x040002F4 RID: 756
		private FileStream _imageFileStream;

		// Token: 0x040002F5 RID: 757
		private RImage _image;

		// Token: 0x040002F6 RID: 758
		private RRect _imageRectangle;

		// Token: 0x040002F7 RID: 759
		private bool _asyncCallback;

		// Token: 0x040002F8 RID: 760
		private bool _releaseImageObject;

		// Token: 0x040002F9 RID: 761
		private bool _disposed;
	}
}
