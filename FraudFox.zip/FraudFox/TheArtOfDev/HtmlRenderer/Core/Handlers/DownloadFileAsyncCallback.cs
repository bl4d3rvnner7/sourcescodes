﻿using System;

namespace TheArtOfDev.HtmlRenderer.Core.Handlers
{
	// Token: 0x0200009B RID: 155
	// (Invoke) Token: 0x0600080D RID: 2061
	public delegate void DownloadFileAsyncCallback(Uri imageUri, string filePath, Exception error, bool canceled);
}
