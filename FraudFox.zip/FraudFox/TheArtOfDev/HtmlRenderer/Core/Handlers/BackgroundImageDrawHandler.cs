﻿using System;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Dom;

namespace TheArtOfDev.HtmlRenderer.Core.Handlers
{
	// Token: 0x02000097 RID: 151
	internal static class BackgroundImageDrawHandler
	{
		// Token: 0x060007D9 RID: 2009 RVA: 0x0003FDA0 File Offset: 0x0003DFA0
		public static void DrawBackgroundImage(RGraphics g, CssBox box, ImageLoadHandler imageLoadHandler, RRect rectangle)
		{
			RSize rsize = new RSize((imageLoadHandler.Rectangle == RRect.Empty) ? imageLoadHandler.Image.Width : imageLoadHandler.Rectangle.Width, (imageLoadHandler.Rectangle == RRect.Empty) ? imageLoadHandler.Image.Height : imageLoadHandler.Rectangle.Height);
			RPoint location = BackgroundImageDrawHandler.GetLocation(box.BackgroundPosition, rectangle, rsize);
			RRect rrect = ((imageLoadHandler.Rectangle == RRect.Empty) ? new RRect(0.0, 0.0, rsize.Width, rsize.Height) : new RRect(imageLoadHandler.Rectangle.Left, imageLoadHandler.Rectangle.Top, rsize.Width, rsize.Height));
			RRect rrect2 = new RRect(location, rsize);
			RRect rrect3 = rectangle;
			rrect3.Intersect(g.GetClip());
			g.PushClip(rrect3);
			string backgroundRepeat;
			if ((backgroundRepeat = box.BackgroundRepeat) != null)
			{
				if (BackgroundImageDrawHandler.smethod_0(backgroundRepeat, <Module>.smethod_26<string>(599680594U)))
				{
					g.DrawImage(imageLoadHandler.Image, rrect2, rrect);
					goto IL_017D;
				}
				if (BackgroundImageDrawHandler.smethod_0(backgroundRepeat, <Module>.smethod_23<string>(1903661378U)))
				{
					BackgroundImageDrawHandler.DrawRepeatX(g, imageLoadHandler, rectangle, rrect, rrect2, rsize);
					goto IL_017D;
				}
				if (BackgroundImageDrawHandler.smethod_0(backgroundRepeat, <Module>.smethod_23<string>(220567985U)))
				{
					BackgroundImageDrawHandler.DrawRepeatY(g, imageLoadHandler, rectangle, rrect, rrect2, rsize);
					goto IL_017D;
				}
			}
			BackgroundImageDrawHandler.DrawRepeat(g, imageLoadHandler, rectangle, rrect, rrect2, rsize);
			IL_017D:
			g.PopClip();
		}

		// Token: 0x060007DA RID: 2010 RVA: 0x0003FF30 File Offset: 0x0003E130
		private static RPoint GetLocation(string backgroundPosition, RRect rectangle, RSize imgSize)
		{
			double num = rectangle.Left;
			if (BackgroundImageDrawHandler.smethod_1(backgroundPosition, <Module>.smethod_26<string>(2872447828U), StringComparison.OrdinalIgnoreCase) > -1)
			{
				num = rectangle.Left + 0.5;
			}
			else if (BackgroundImageDrawHandler.smethod_1(backgroundPosition, <Module>.smethod_25<string>(3477823948U), StringComparison.OrdinalIgnoreCase) <= -1)
			{
				if (BackgroundImageDrawHandler.smethod_1(backgroundPosition, <Module>.smethod_27<string>(1690140869U), StringComparison.OrdinalIgnoreCase) < 0)
				{
					num = rectangle.Left + (rectangle.Width - imgSize.Width) / 2.0 + 0.5;
				}
			}
			else
			{
				num = rectangle.Right - imgSize.Width;
			}
			double num2 = rectangle.Top;
			if (BackgroundImageDrawHandler.smethod_1(backgroundPosition, <Module>.smethod_25<string>(2921044324U), StringComparison.OrdinalIgnoreCase) > -1)
			{
				num2 = rectangle.Top;
			}
			else if (BackgroundImageDrawHandler.smethod_1(backgroundPosition, <Module>.smethod_27<string>(3595409369U), StringComparison.OrdinalIgnoreCase) <= -1)
			{
				if (BackgroundImageDrawHandler.smethod_1(backgroundPosition, <Module>.smethod_25<string>(1948008606U), StringComparison.OrdinalIgnoreCase) < 0)
				{
					num2 = rectangle.Top + (rectangle.Height - imgSize.Height) / 2.0 + 0.5;
				}
			}
			else
			{
				num2 = rectangle.Bottom - imgSize.Height;
			}
			return new RPoint(num, num2);
		}

		// Token: 0x060007DB RID: 2011 RVA: 0x00040068 File Offset: 0x0003E268
		private static void DrawRepeatX(RGraphics g, ImageLoadHandler imageLoadHandler, RRect rectangle, RRect srcRect, RRect destRect, RSize imgSize)
		{
			while (destRect.X > rectangle.X)
			{
				destRect.X -= imgSize.Width;
			}
			RBrush textureBrush = g.GetTextureBrush(imageLoadHandler.Image, srcRect, destRect.Location);
			try
			{
				g.DrawRectangle(textureBrush, rectangle.X, destRect.Y, rectangle.Width, srcRect.Height);
			}
			finally
			{
				if (textureBrush != null)
				{
					BackgroundImageDrawHandler.smethod_2(textureBrush);
				}
			}
		}

		// Token: 0x060007DC RID: 2012 RVA: 0x000400F4 File Offset: 0x0003E2F4
		private static void DrawRepeatY(RGraphics g, ImageLoadHandler imageLoadHandler, RRect rectangle, RRect srcRect, RRect destRect, RSize imgSize)
		{
			while (destRect.Y > rectangle.Y)
			{
				destRect.Y -= imgSize.Height;
			}
			RBrush textureBrush = g.GetTextureBrush(imageLoadHandler.Image, srcRect, destRect.Location);
			try
			{
				g.DrawRectangle(textureBrush, destRect.X, rectangle.Y, srcRect.Width, rectangle.Height);
			}
			finally
			{
				if (textureBrush != null)
				{
					BackgroundImageDrawHandler.smethod_2(textureBrush);
				}
			}
		}

		// Token: 0x060007DD RID: 2013 RVA: 0x00040180 File Offset: 0x0003E380
		private static void DrawRepeat(RGraphics g, ImageLoadHandler imageLoadHandler, RRect rectangle, RRect srcRect, RRect destRect, RSize imgSize)
		{
			while (destRect.X > rectangle.X)
			{
				destRect.X -= imgSize.Width;
			}
			while (destRect.Y > rectangle.Y)
			{
				destRect.Y -= imgSize.Height;
			}
			RBrush textureBrush = g.GetTextureBrush(imageLoadHandler.Image, srcRect, destRect.Location);
			try
			{
				g.DrawRectangle(textureBrush, rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height);
			}
			finally
			{
				if (textureBrush != null)
				{
					BackgroundImageDrawHandler.smethod_2(textureBrush);
				}
			}
		}

		// Token: 0x060007DE RID: 2014 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_0(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x060007DF RID: 2015 RVA: 0x0000D40C File Offset: 0x0000B60C
		static int smethod_1(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.IndexOf(string_1, stringComparison_0);
		}

		// Token: 0x060007E0 RID: 2016 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_2(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}
	}
}
