﻿using System;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Entities
{
	// Token: 0x0200008B RID: 139
	public struct CssBlockSelectorItem
	{
		// Token: 0x0600079D RID: 1949 RVA: 0x0000F4C0 File Offset: 0x0000D6C0
		public CssBlockSelectorItem(string @class, bool directParent)
		{
			ArgChecker.AssertArgNotNullOrEmpty(@class, <Module>.smethod_26<string>(2665764893U));
			this._class = @class;
			this._directParent = directParent;
		}

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x0600079E RID: 1950 RVA: 0x0000F4E0 File Offset: 0x0000D6E0
		public string Class
		{
			get
			{
				return this._class;
			}
		}

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x0600079F RID: 1951 RVA: 0x0000F4E8 File Offset: 0x0000D6E8
		public bool DirectParent
		{
			get
			{
				return this._directParent;
			}
		}

		// Token: 0x060007A0 RID: 1952 RVA: 0x0000F4F0 File Offset: 0x0000D6F0
		public override string ToString()
		{
			return CssBlockSelectorItem.smethod_0(this._class, this._directParent ? <Module>.smethod_24<string>(2084670584U) : string.Empty);
		}

		// Token: 0x060007A1 RID: 1953 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_0(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x040002B5 RID: 693
		private readonly string _class;

		// Token: 0x040002B6 RID: 694
		private readonly bool _directParent;
	}
}
