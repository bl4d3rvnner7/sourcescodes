﻿using System;

namespace TheArtOfDev.HtmlRenderer.Core.Entities
{
	// Token: 0x02000090 RID: 144
	public sealed class HtmlLinkClickedException : Exception
	{
		// Token: 0x060007B7 RID: 1975 RVA: 0x0000F665 File Offset: 0x0000D865
		public HtmlLinkClickedException()
		{
		}

		// Token: 0x060007B8 RID: 1976 RVA: 0x0000C1DA File Offset: 0x0000A3DA
		public HtmlLinkClickedException(string message)
			: base(message)
		{
		}

		// Token: 0x060007B9 RID: 1977 RVA: 0x0000F66D File Offset: 0x0000D86D
		public HtmlLinkClickedException(string message, Exception innerException)
			: base(message, innerException)
		{
		}
	}
}
