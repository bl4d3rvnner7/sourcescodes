﻿using System;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;

namespace TheArtOfDev.HtmlRenderer.Core.Entities
{
	// Token: 0x02000094 RID: 148
	public sealed class HtmlScrollEventArgs : EventArgs
	{
		// Token: 0x060007C4 RID: 1988 RVA: 0x0000F6FB File Offset: 0x0000D8FB
		public HtmlScrollEventArgs(RPoint location)
		{
			this._location = location;
		}

		// Token: 0x1700014D RID: 333
		// (get) Token: 0x060007C5 RID: 1989 RVA: 0x0003FD68 File Offset: 0x0003DF68
		public double X
		{
			get
			{
				return this._location.X;
			}
		}

		// Token: 0x1700014E RID: 334
		// (get) Token: 0x060007C6 RID: 1990 RVA: 0x0003FD84 File Offset: 0x0003DF84
		public double Y
		{
			get
			{
				return this._location.Y;
			}
		}

		// Token: 0x060007C7 RID: 1991 RVA: 0x0000F70A File Offset: 0x0000D90A
		public override string ToString()
		{
			return HtmlScrollEventArgs.smethod_0(<Module>.smethod_23<string>(97402231U), this._location);
		}

		// Token: 0x060007C8 RID: 1992 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_0(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x040002D0 RID: 720
		private readonly RPoint _location;
	}
}
