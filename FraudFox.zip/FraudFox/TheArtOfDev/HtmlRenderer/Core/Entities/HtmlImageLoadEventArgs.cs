﻿using System;
using System.Collections.Generic;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Entities
{
	// Token: 0x0200008E RID: 142
	public sealed class HtmlImageLoadEventArgs : EventArgs
	{
		// Token: 0x060007A6 RID: 1958 RVA: 0x0000F516 File Offset: 0x0000D716
		internal HtmlImageLoadEventArgs(string src, Dictionary<string, string> attributes, HtmlImageLoadCallback callback)
		{
			this._src = src;
			this._attributes = attributes;
			this._callback = callback;
		}

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x060007A7 RID: 1959 RVA: 0x0000F533 File Offset: 0x0000D733
		public string Src
		{
			get
			{
				return this._src;
			}
		}

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x060007A8 RID: 1960 RVA: 0x0000F53B File Offset: 0x0000D73B
		public Dictionary<string, string> Attributes
		{
			get
			{
				return this._attributes;
			}
		}

		// Token: 0x17000145 RID: 325
		// (get) Token: 0x060007A9 RID: 1961 RVA: 0x0000F543 File Offset: 0x0000D743
		// (set) Token: 0x060007AA RID: 1962 RVA: 0x0000F54B File Offset: 0x0000D74B
		public bool Handled
		{
			get
			{
				return this._handled;
			}
			set
			{
				this._handled = value;
			}
		}

		// Token: 0x060007AB RID: 1963 RVA: 0x0003FD3C File Offset: 0x0003DF3C
		public void Callback()
		{
			this._handled = true;
			this._callback(null, null, default(RRect));
		}

		// Token: 0x060007AC RID: 1964 RVA: 0x0000F554 File Offset: 0x0000D754
		public void Callback(string path)
		{
			ArgChecker.AssertArgNotNullOrEmpty(path, <Module>.smethod_25<string>(772896364U));
			this._handled = true;
			this._callback(path, null, RRect.Empty);
		}

		// Token: 0x060007AD RID: 1965 RVA: 0x0000F57F File Offset: 0x0000D77F
		public void Callback(string path, double x, double y, double width, double height)
		{
			ArgChecker.AssertArgNotNullOrEmpty(path, <Module>.smethod_25<string>(772896364U));
			this._handled = true;
			this._callback(path, null, new RRect(x, y, width, height));
		}

		// Token: 0x060007AE RID: 1966 RVA: 0x0000F5B0 File Offset: 0x0000D7B0
		public void Callback(object image)
		{
			ArgChecker.AssertArgNotNull(image, <Module>.smethod_24<string>(3710589828U));
			this._handled = true;
			this._callback(null, image, RRect.Empty);
		}

		// Token: 0x060007AF RID: 1967 RVA: 0x0000F5DB File Offset: 0x0000D7DB
		public void Callback(object image, double x, double y, double width, double height)
		{
			ArgChecker.AssertArgNotNull(image, <Module>.smethod_27<string>(780793169U));
			this._handled = true;
			this._callback(null, image, new RRect(x, y, width, height));
		}

		// Token: 0x040002BB RID: 699
		private bool _handled;

		// Token: 0x040002BC RID: 700
		private readonly string _src;

		// Token: 0x040002BD RID: 701
		private readonly Dictionary<string, string> _attributes;

		// Token: 0x040002BE RID: 702
		private readonly HtmlImageLoadCallback _callback;
	}
}
