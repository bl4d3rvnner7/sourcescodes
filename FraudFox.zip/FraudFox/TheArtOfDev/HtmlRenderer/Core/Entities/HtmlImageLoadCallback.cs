﻿using System;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;

namespace TheArtOfDev.HtmlRenderer.Core.Entities
{
	// Token: 0x0200008D RID: 141
	// (Invoke) Token: 0x060007A3 RID: 1955
	public delegate void HtmlImageLoadCallback(string path, object image, RRect imageRectangle);
}
