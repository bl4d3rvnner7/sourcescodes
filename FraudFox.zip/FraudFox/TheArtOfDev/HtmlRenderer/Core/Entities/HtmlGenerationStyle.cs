﻿using System;

namespace TheArtOfDev.HtmlRenderer.Core.Entities
{
	// Token: 0x0200008C RID: 140
	public enum HtmlGenerationStyle
	{
		// Token: 0x040002B8 RID: 696
		None,
		// Token: 0x040002B9 RID: 697
		Inline,
		// Token: 0x040002BA RID: 698
		InHeader
	}
}
