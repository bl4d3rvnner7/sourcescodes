﻿using System;

namespace TheArtOfDev.HtmlRenderer.Core.Entities
{
	// Token: 0x02000096 RID: 150
	public sealed class LinkElementData<T>
	{
		// Token: 0x060007D2 RID: 2002 RVA: 0x0000F77F File Offset: 0x0000D97F
		public LinkElementData(string id, string href, T rectangle)
		{
			this._id = id;
			this._href = href;
			this._rectangle = rectangle;
		}

		// Token: 0x17000154 RID: 340
		// (get) Token: 0x060007D3 RID: 2003 RVA: 0x0000F79C File Offset: 0x0000D99C
		public string Id
		{
			get
			{
				return this._id;
			}
		}

		// Token: 0x17000155 RID: 341
		// (get) Token: 0x060007D4 RID: 2004 RVA: 0x0000F7A4 File Offset: 0x0000D9A4
		public string Href
		{
			get
			{
				return this._href;
			}
		}

		// Token: 0x17000156 RID: 342
		// (get) Token: 0x060007D5 RID: 2005 RVA: 0x0000F7AC File Offset: 0x0000D9AC
		public T Rectangle
		{
			get
			{
				return this._rectangle;
			}
		}

		// Token: 0x17000157 RID: 343
		// (get) Token: 0x060007D6 RID: 2006 RVA: 0x0000F7B4 File Offset: 0x0000D9B4
		public bool IsAnchor
		{
			get
			{
				return LinkElementData<T>.smethod_0(this._href) > 0 && LinkElementData<T>.smethod_1(this._href, 0) == '#';
			}
		}

		// Token: 0x17000158 RID: 344
		// (get) Token: 0x060007D7 RID: 2007 RVA: 0x0000F7D6 File Offset: 0x0000D9D6
		public string AnchorId
		{
			get
			{
				if (this.IsAnchor && LinkElementData<T>.smethod_0(this._href) > 1)
				{
					return LinkElementData<T>.smethod_2(this._href, 1);
				}
				return string.Empty;
			}
		}

		// Token: 0x060007D8 RID: 2008 RVA: 0x0000F800 File Offset: 0x0000DA00
		public override string ToString()
		{
			return LinkElementData<T>.smethod_3(<Module>.smethod_24<string>(1555738709U), this._id, this._href, this._rectangle);
		}

		// Token: 0x040002D6 RID: 726
		private readonly string _id;

		// Token: 0x040002D7 RID: 727
		private readonly string _href;

		// Token: 0x040002D8 RID: 728
		private readonly T _rectangle;
	}
}
