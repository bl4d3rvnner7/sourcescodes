﻿using System;

namespace TheArtOfDev.HtmlRenderer.Core.Entities
{
	// Token: 0x02000092 RID: 146
	public sealed class HtmlRenderErrorEventArgs : EventArgs
	{
		// Token: 0x060007BE RID: 1982 RVA: 0x0000F6AA File Offset: 0x0000D8AA
		public HtmlRenderErrorEventArgs(HtmlRenderErrorType type, string message, Exception exception = null)
		{
			this._type = type;
			this._message = message;
			this._exception = exception;
		}

		// Token: 0x1700014A RID: 330
		// (get) Token: 0x060007BF RID: 1983 RVA: 0x0000F6C7 File Offset: 0x0000D8C7
		public HtmlRenderErrorType Type
		{
			get
			{
				return this._type;
			}
		}

		// Token: 0x1700014B RID: 331
		// (get) Token: 0x060007C0 RID: 1984 RVA: 0x0000F6CF File Offset: 0x0000D8CF
		public string Message
		{
			get
			{
				return this._message;
			}
		}

		// Token: 0x1700014C RID: 332
		// (get) Token: 0x060007C1 RID: 1985 RVA: 0x0000F6D7 File Offset: 0x0000D8D7
		public Exception Exception
		{
			get
			{
				return this._exception;
			}
		}

		// Token: 0x060007C2 RID: 1986 RVA: 0x0000F6DF File Offset: 0x0000D8DF
		public override string ToString()
		{
			return HtmlRenderErrorEventArgs.smethod_0(<Module>.smethod_25<string>(1886455612U), this._type);
		}

		// Token: 0x060007C3 RID: 1987 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_0(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x040002C3 RID: 707
		private readonly HtmlRenderErrorType _type;

		// Token: 0x040002C4 RID: 708
		private readonly string _message;

		// Token: 0x040002C5 RID: 709
		private readonly Exception _exception;
	}
}
