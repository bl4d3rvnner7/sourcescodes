﻿using System;

namespace TheArtOfDev.HtmlRenderer.Core.Entities
{
	// Token: 0x02000091 RID: 145
	public sealed class HtmlRefreshEventArgs : EventArgs
	{
		// Token: 0x060007BA RID: 1978 RVA: 0x0000F677 File Offset: 0x0000D877
		public HtmlRefreshEventArgs(bool layout)
		{
			this._layout = layout;
		}

		// Token: 0x17000149 RID: 329
		// (get) Token: 0x060007BB RID: 1979 RVA: 0x0000F686 File Offset: 0x0000D886
		public bool Layout
		{
			get
			{
				return this._layout;
			}
		}

		// Token: 0x060007BC RID: 1980 RVA: 0x0000F68E File Offset: 0x0000D88E
		public override string ToString()
		{
			return HtmlRefreshEventArgs.smethod_0(<Module>.smethod_26<string>(1285183229U), this._layout);
		}

		// Token: 0x060007BD RID: 1981 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_0(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x040002C2 RID: 706
		private readonly bool _layout;
	}
}
