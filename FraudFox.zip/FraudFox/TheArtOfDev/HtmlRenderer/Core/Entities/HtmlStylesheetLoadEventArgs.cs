﻿using System;
using System.Collections.Generic;

namespace TheArtOfDev.HtmlRenderer.Core.Entities
{
	// Token: 0x02000095 RID: 149
	public sealed class HtmlStylesheetLoadEventArgs : EventArgs
	{
		// Token: 0x060007C9 RID: 1993 RVA: 0x0000F726 File Offset: 0x0000D926
		internal HtmlStylesheetLoadEventArgs(string src, Dictionary<string, string> attributes)
		{
			this._src = src;
			this._attributes = attributes;
		}

		// Token: 0x1700014F RID: 335
		// (get) Token: 0x060007CA RID: 1994 RVA: 0x0000F73C File Offset: 0x0000D93C
		public string Src
		{
			get
			{
				return this._src;
			}
		}

		// Token: 0x17000150 RID: 336
		// (get) Token: 0x060007CB RID: 1995 RVA: 0x0000F744 File Offset: 0x0000D944
		public Dictionary<string, string> Attributes
		{
			get
			{
				return this._attributes;
			}
		}

		// Token: 0x17000151 RID: 337
		// (get) Token: 0x060007CC RID: 1996 RVA: 0x0000F74C File Offset: 0x0000D94C
		// (set) Token: 0x060007CD RID: 1997 RVA: 0x0000F754 File Offset: 0x0000D954
		public string SetSrc
		{
			get
			{
				return this._setSrc;
			}
			set
			{
				this._setSrc = value;
			}
		}

		// Token: 0x17000152 RID: 338
		// (get) Token: 0x060007CE RID: 1998 RVA: 0x0000F75D File Offset: 0x0000D95D
		// (set) Token: 0x060007CF RID: 1999 RVA: 0x0000F765 File Offset: 0x0000D965
		public string SetStyleSheet
		{
			get
			{
				return this._setStyleSheet;
			}
			set
			{
				this._setStyleSheet = value;
			}
		}

		// Token: 0x17000153 RID: 339
		// (get) Token: 0x060007D0 RID: 2000 RVA: 0x0000F76E File Offset: 0x0000D96E
		// (set) Token: 0x060007D1 RID: 2001 RVA: 0x0000F776 File Offset: 0x0000D976
		public CssData SetStyleSheetData
		{
			get
			{
				return this._setStyleSheetData;
			}
			set
			{
				this._setStyleSheetData = value;
			}
		}

		// Token: 0x040002D1 RID: 721
		private readonly string _src;

		// Token: 0x040002D2 RID: 722
		private readonly Dictionary<string, string> _attributes;

		// Token: 0x040002D3 RID: 723
		private string _setSrc;

		// Token: 0x040002D4 RID: 724
		private string _setStyleSheet;

		// Token: 0x040002D5 RID: 725
		private CssData _setStyleSheetData;
	}
}
