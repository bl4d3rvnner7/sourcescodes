﻿using System;

namespace TheArtOfDev.HtmlRenderer.Core.Entities
{
	// Token: 0x02000093 RID: 147
	public enum HtmlRenderErrorType
	{
		// Token: 0x040002C7 RID: 711
		General,
		// Token: 0x040002C8 RID: 712
		CssParsing,
		// Token: 0x040002C9 RID: 713
		HtmlParsing,
		// Token: 0x040002CA RID: 714
		Image,
		// Token: 0x040002CB RID: 715
		Paint,
		// Token: 0x040002CC RID: 716
		Layout,
		// Token: 0x040002CD RID: 717
		KeyboardMouse,
		// Token: 0x040002CE RID: 718
		Iframe,
		// Token: 0x040002CF RID: 719
		ContextMenu
	}
}
