﻿using System;
using System.Collections.Generic;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Entities
{
	// Token: 0x0200008A RID: 138
	public sealed class CssBlock
	{
		// Token: 0x06000789 RID: 1929 RVA: 0x0003F9DC File Offset: 0x0003DBDC
		public CssBlock(string @class, Dictionary<string, string> properties, List<CssBlockSelectorItem> selectors = null, bool hover = false)
		{
			ArgChecker.AssertArgNotNullOrEmpty(@class, <Module>.smethod_23<string>(677247487U));
			ArgChecker.AssertArgNotNull(properties, <Module>.smethod_25<string>(4023901865U));
			this._class = @class;
			this._selectors = selectors;
			this._properties = properties;
			this._hover = hover;
		}

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x0600078A RID: 1930 RVA: 0x0000F3DC File Offset: 0x0000D5DC
		public string Class
		{
			get
			{
				return this._class;
			}
		}

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x0600078B RID: 1931 RVA: 0x0000F3E4 File Offset: 0x0000D5E4
		public List<CssBlockSelectorItem> Selectors
		{
			get
			{
				return this._selectors;
			}
		}

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x0600078C RID: 1932 RVA: 0x0000F3EC File Offset: 0x0000D5EC
		public IDictionary<string, string> Properties
		{
			get
			{
				return this._properties;
			}
		}

		// Token: 0x17000140 RID: 320
		// (get) Token: 0x0600078D RID: 1933 RVA: 0x0000F3F4 File Offset: 0x0000D5F4
		public bool Hover
		{
			get
			{
				return this._hover;
			}
		}

		// Token: 0x0600078E RID: 1934 RVA: 0x0003FA2C File Offset: 0x0003DC2C
		public void Merge(CssBlock other)
		{
			ArgChecker.AssertArgNotNull(other, <Module>.smethod_25<string>(3745512053U));
			foreach (string text in other._properties.Keys)
			{
				this._properties[text] = other._properties[text];
			}
		}

		// Token: 0x0600078F RID: 1935 RVA: 0x0000F3FC File Offset: 0x0000D5FC
		public CssBlock Clone()
		{
			return new CssBlock(this._class, new Dictionary<string, string>(this._properties), (this._selectors != null) ? new List<CssBlockSelectorItem>(this._selectors) : null, false);
		}

		// Token: 0x06000790 RID: 1936 RVA: 0x0003FAA8 File Offset: 0x0003DCA8
		public bool Equals(CssBlock other)
		{
			if (CssBlock.smethod_0(null, other))
			{
				return false;
			}
			if (CssBlock.smethod_0(this, other))
			{
				goto IL_00B1;
			}
			int num;
			if (!CssBlock.smethod_1(other._class, this._class))
			{
				num = 630995952;
			}
			else
			{
				if (!CssBlock.smethod_1(other._properties.Count, this._properties.Count))
				{
					return false;
				}
				using (Dictionary<string, string>.Enumerator enumerator = this._properties.GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
					}
				}
				return this.EqualsSelector(other);
			}
			IL_0098:
			switch (num ^ 630995954)
			{
			case 0:
				IL_00B1:
				num = 630995955;
				goto IL_0098;
			case 1:
				return true;
			}
			return false;
		}

		// Token: 0x06000791 RID: 1937 RVA: 0x0003FB80 File Offset: 0x0003DD80
		public bool EqualsSelector(CssBlock other)
		{
			if (CssBlock.smethod_0(null, other))
			{
				return false;
			}
			if (CssBlock.smethod_0(this, other))
			{
				return true;
			}
			if (other.Hover != this.Hover)
			{
				return false;
			}
			if (other._selectors == null && this._selectors != null)
			{
				return false;
			}
			if (other._selectors != null && this._selectors == null)
			{
				return false;
			}
			if (other._selectors != null && this._selectors != null)
			{
				if (!CssBlock.smethod_1(other._selectors.Count, this._selectors.Count))
				{
					return false;
				}
				for (int i = 0; i < this._selectors.Count; i++)
				{
					if (!CssBlock.smethod_1(other._selectors[i].Class, this._selectors[i].Class))
					{
						return false;
					}
					if (!CssBlock.smethod_1(other._selectors[i].DirectParent, this._selectors[i].DirectParent))
					{
						return false;
					}
				}
			}
			return true;
		}

		// Token: 0x06000792 RID: 1938 RVA: 0x0000F42B File Offset: 0x0000D62B
		public override bool Equals(object obj)
		{
			return !CssBlock.smethod_0(null, obj) && (CssBlock.smethod_0(this, obj) || (!CssBlock.smethod_4(CssBlock.smethod_2(obj), CssBlock.smethod_3(typeof(CssBlock).TypeHandle)) && this.Equals((CssBlock)obj)));
		}

		// Token: 0x06000793 RID: 1939 RVA: 0x0000F468 File Offset: 0x0000D668
		public override int GetHashCode()
		{
			return (((this._class != null) ? CssBlock.smethod_5(this._class) : 0) * 397) ^ ((this._properties != null) ? CssBlock.smethod_5(this._properties) : 0);
		}

		// Token: 0x06000794 RID: 1940 RVA: 0x0003FCA4 File Offset: 0x0003DEA4
		public override string ToString()
		{
			string text = CssBlock.smethod_6(this._class, <Module>.smethod_26<string>(2675341287U));
			foreach (KeyValuePair<string, string> keyValuePair in this._properties)
			{
				text = CssBlock.smethod_6(text, CssBlock.smethod_7(<Module>.smethod_24<string>(1271710962U), keyValuePair.Key, keyValuePair.Value));
			}
			return CssBlock.smethod_6(text, <Module>.smethod_27<string>(687549783U));
		}

		// Token: 0x06000795 RID: 1941 RVA: 0x0000F49D File Offset: 0x0000D69D
		static bool smethod_0(object object_0, object object_1)
		{
			return object.ReferenceEquals(object_0, object_1);
		}

		// Token: 0x06000796 RID: 1942 RVA: 0x0000F4A6 File Offset: 0x0000D6A6
		static bool smethod_1(object object_0, object object_1)
		{
			return object.Equals(object_0, object_1);
		}

		// Token: 0x06000797 RID: 1943 RVA: 0x0000F4AF File Offset: 0x0000D6AF
		static Type smethod_2(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06000798 RID: 1944 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_3(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06000799 RID: 1945 RVA: 0x0000F4B7 File Offset: 0x0000D6B7
		static bool smethod_4(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x0600079A RID: 1946 RVA: 0x0000CF7A File Offset: 0x0000B17A
		static int smethod_5(object object_0)
		{
			return object_0.GetHashCode();
		}

		// Token: 0x0600079B RID: 1947 RVA: 0x0000D41F File Offset: 0x0000B61F
		static string smethod_6(string string_0, string string_1)
		{
			return string_0 + string_1;
		}

		// Token: 0x0600079C RID: 1948 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_7(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x040002B1 RID: 689
		private readonly string _class;

		// Token: 0x040002B2 RID: 690
		private readonly Dictionary<string, string> _properties;

		// Token: 0x040002B3 RID: 691
		private readonly List<CssBlockSelectorItem> _selectors;

		// Token: 0x040002B4 RID: 692
		private readonly bool _hover;
	}
}
