﻿using System;
using System.Collections.Generic;

namespace TheArtOfDev.HtmlRenderer.Core.Entities
{
	// Token: 0x0200008F RID: 143
	public sealed class HtmlLinkClickedEventArgs : EventArgs
	{
		// Token: 0x060007B0 RID: 1968 RVA: 0x0000F60C File Offset: 0x0000D80C
		public HtmlLinkClickedEventArgs(string link, Dictionary<string, string> attributes)
		{
			this._link = link;
			this._attributes = attributes;
		}

		// Token: 0x17000146 RID: 326
		// (get) Token: 0x060007B1 RID: 1969 RVA: 0x0000F622 File Offset: 0x0000D822
		public string Link
		{
			get
			{
				return this._link;
			}
		}

		// Token: 0x17000147 RID: 327
		// (get) Token: 0x060007B2 RID: 1970 RVA: 0x0000F62A File Offset: 0x0000D82A
		public Dictionary<string, string> Attributes
		{
			get
			{
				return this._attributes;
			}
		}

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x060007B3 RID: 1971 RVA: 0x0000F632 File Offset: 0x0000D832
		// (set) Token: 0x060007B4 RID: 1972 RVA: 0x0000F63A File Offset: 0x0000D83A
		public bool Handled
		{
			get
			{
				return this._handled;
			}
			set
			{
				this._handled = value;
			}
		}

		// Token: 0x060007B5 RID: 1973 RVA: 0x0000F643 File Offset: 0x0000D843
		public override string ToString()
		{
			return HtmlLinkClickedEventArgs.smethod_0(<Module>.smethod_26<string>(1989838652U), this._link, this._handled);
		}

		// Token: 0x060007B6 RID: 1974 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_0(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x040002BF RID: 703
		private readonly string _link;

		// Token: 0x040002C0 RID: 704
		private readonly Dictionary<string, string> _attributes;

		// Token: 0x040002C1 RID: 705
		private bool _handled;
	}
}
