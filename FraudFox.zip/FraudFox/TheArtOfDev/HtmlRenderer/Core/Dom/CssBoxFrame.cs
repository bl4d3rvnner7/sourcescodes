﻿using System;
using System.ComponentModel;
using System.Net;
using System.Threading;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Entities;
using TheArtOfDev.HtmlRenderer.Core.Handlers;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x02000079 RID: 121
	internal sealed class CssBoxFrame : CssBox
	{
		// Token: 0x06000691 RID: 1681 RVA: 0x0003A1B0 File Offset: 0x000383B0
		public CssBoxFrame(CssBox parent, HtmlTag tag)
			: base(parent, tag)
		{
			this._imageWord = new CssRectImage(this);
			base.Words.Add(this._imageWord);
			Uri uri;
			if (CssBoxFrame.smethod_25(base.GetAttribute(<Module>.smethod_25<string>(614955292U)), UriKind.Absolute, ref uri))
			{
				if (CssBoxFrame.smethod_27(CssBoxFrame.smethod_26(uri), <Module>.smethod_26<string>(1238882187U), StringComparison.InvariantCultureIgnoreCase) > -1)
				{
					this._isVideo = true;
					this.LoadYoutubeDataAsync(uri);
				}
				else if (CssBoxFrame.smethod_27(CssBoxFrame.smethod_26(uri), <Module>.smethod_24<string>(2637991136U), StringComparison.InvariantCultureIgnoreCase) > -1)
				{
					this._isVideo = true;
					this.LoadVimeoDataAsync(uri);
				}
			}
			if (!this._isVideo)
			{
				this.SetErrorBorder();
			}
		}

		// Token: 0x17000105 RID: 261
		// (get) Token: 0x06000692 RID: 1682 RVA: 0x0000ED8C File Offset: 0x0000CF8C
		public override bool IsClickable
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000106 RID: 262
		// (get) Token: 0x06000693 RID: 1683 RVA: 0x0000ED8F File Offset: 0x0000CF8F
		public override string HrefLink
		{
			get
			{
				return this._videoLinkUrl ?? base.GetAttribute(<Module>.smethod_24<string>(1947483578U));
			}
		}

		// Token: 0x17000107 RID: 263
		// (get) Token: 0x06000694 RID: 1684 RVA: 0x0000EDAB File Offset: 0x0000CFAB
		public bool IsVideo
		{
			get
			{
				return this._isVideo;
			}
		}

		// Token: 0x06000695 RID: 1685 RVA: 0x0000EDB3 File Offset: 0x0000CFB3
		public override void Dispose()
		{
			if (this._imageLoadHandler != null)
			{
				this._imageLoadHandler.Dispose();
			}
			base.Dispose();
		}

		// Token: 0x06000696 RID: 1686 RVA: 0x0003A25C File Offset: 0x0003845C
		private void LoadYoutubeDataAsync(Uri uri)
		{
			CssBoxFrame.smethod_28(delegate(object state)
			{
				try
				{
					Uri uri2 = CssBoxFrame.<>c__DisplayClass1.smethod_2(CssBoxFrame.<>c__DisplayClass1.smethod_1(<Module>.smethod_26<string>(2935484853U), CssBoxFrame.<>c__DisplayClass1.smethod_0(uri)[2]));
					WebClient webClient = CssBoxFrame.<>c__DisplayClass1.smethod_3();
					CssBoxFrame.<>c__DisplayClass1.smethod_5(webClient, CssBoxFrame.<>c__DisplayClass1.smethod_4());
					CssBoxFrame.<>c__DisplayClass1.smethod_6(webClient, new DownloadStringCompletedEventHandler(this.OnDownloadYoutubeApiCompleted));
					CssBoxFrame.<>c__DisplayClass1.smethod_7(webClient, uri2);
				}
				catch (Exception ex)
				{
					this.HtmlContainer.ReportError(HtmlRenderErrorType.Iframe, CssBoxFrame.<>c__DisplayClass1.smethod_8(<Module>.smethod_24<string>(2589213782U), uri), ex);
					for (;;)
					{
						IL_00B2:
						int num = -1432558981;
						for (;;)
						{
							switch (num ^ -1432558983)
							{
							case 0:
								goto IL_00B2;
							case 2:
								this.HtmlContainer.RequestRefresh(false);
								num = -1432558984;
								continue;
							}
							goto Block_3;
						}
					}
					Block_3:;
				}
			});
		}

		// Token: 0x06000697 RID: 1687 RVA: 0x0003A290 File Offset: 0x00038490
		private void OnDownloadYoutubeApiCompleted(object sender, DownloadStringCompletedEventArgs e)
		{
			try
			{
				if (!CssBoxFrame.smethod_29(e))
				{
					if (CssBoxFrame.smethod_30(e) != null)
					{
						this.HandleDataLoadFailure(CssBoxFrame.smethod_30(e), <Module>.smethod_23<string>(11864727U));
					}
					else
					{
						int num = CssBoxFrame.smethod_27(CssBoxFrame.smethod_31(e), <Module>.smethod_24<string>(4263910380U), StringComparison.Ordinal);
						if (num > -1)
						{
							num = CssBoxFrame.smethod_32(CssBoxFrame.smethod_31(e), <Module>.smethod_25<string>(1798111993U), num);
							if (num > -1)
							{
								num = CssBoxFrame.smethod_33(CssBoxFrame.smethod_31(e), '"', num + 4);
								if (num > -1)
								{
									int num2 = CssBoxFrame.smethod_33(CssBoxFrame.smethod_31(e), '"', num + 1);
									while (CssBoxFrame.smethod_34(CssBoxFrame.smethod_31(e), num2 - 1) == '\\')
									{
										num2 = CssBoxFrame.smethod_33(CssBoxFrame.smethod_31(e), '"', num2 + 1);
									}
									if (num2 > -1)
									{
										this._videoTitle = CssBoxFrame.smethod_36(CssBoxFrame.smethod_35(CssBoxFrame.smethod_31(e), num + 1, num2 - num - 1), <Module>.smethod_26<string>(553379552U), <Module>.smethod_25<string>(1519722181U));
									}
								}
							}
						}
						num = CssBoxFrame.smethod_27(CssBoxFrame.smethod_31(e), <Module>.smethod_24<string>(1648720889U), StringComparison.Ordinal);
						if (num > -1)
						{
							int num3 = CssBoxFrame.smethod_32(CssBoxFrame.smethod_31(e), <Module>.smethod_24<string>(2461680511U), num);
							if (num3 > -1)
							{
								if (CssBoxFrame.smethod_37(base.Width))
								{
									base.Width = <Module>.smethod_23<string>(3557659642U);
								}
								if (CssBoxFrame.smethod_37(base.Height))
								{
									base.Height = <Module>.smethod_25<string>(2702878882U);
								}
							}
							else
							{
								num3 = CssBoxFrame.smethod_32(CssBoxFrame.smethod_31(e), <Module>.smethod_24<string>(3734978505U), num);
								if (num3 > -1)
								{
									if (CssBoxFrame.smethod_37(base.Width))
									{
										base.Width = <Module>.smethod_27<string>(4102925825U);
									}
									if (CssBoxFrame.smethod_37(base.Height))
									{
										base.Height = <Module>.smethod_27<string>(3869817360U);
									}
								}
								else
								{
									num3 = CssBoxFrame.smethod_32(CssBoxFrame.smethod_31(e), <Module>.smethod_23<string>(3383192015U), num);
									if (num3 <= -1)
									{
										num3 = CssBoxFrame.smethod_32(CssBoxFrame.smethod_31(e), <Module>.smethod_25<string>(38100878U), num);
										if (CssBoxFrame.smethod_37(base.Width))
										{
											base.Width = <Module>.smethod_26<string>(821518584U);
										}
										if (CssBoxFrame.smethod_37(base.Height))
										{
											base.Height = <Module>.smethod_24<string>(76660206U);
										}
									}
									else
									{
										if (CssBoxFrame.smethod_37(base.Width))
										{
											base.Width = <Module>.smethod_24<string>(3911289130U);
										}
										if (CssBoxFrame.smethod_37(base.Height))
										{
											base.Height = <Module>.smethod_25<string>(3746840677U);
										}
									}
								}
							}
							num3 = CssBoxFrame.smethod_38(CssBoxFrame.smethod_31(e), <Module>.smethod_23<string>(940645237U), num3, StringComparison.Ordinal);
							if (num3 > -1)
							{
								int num4 = CssBoxFrame.smethod_33(CssBoxFrame.smethod_31(e), '"', num3);
								if (num4 > -1)
								{
									this._videoImageUrl = CssBoxFrame.smethod_36(CssBoxFrame.smethod_36(CssBoxFrame.smethod_35(CssBoxFrame.smethod_31(e), num3, num4 - num3), <Module>.smethod_25<string>(1658917087U), <Module>.smethod_23<string>(2473225630U)), <Module>.smethod_27<string>(3822296921U), "");
								}
							}
						}
						num = CssBoxFrame.smethod_27(CssBoxFrame.smethod_31(e), <Module>.smethod_27<string>(128538840U), StringComparison.Ordinal);
						if (num > -1)
						{
							num = CssBoxFrame.smethod_32(CssBoxFrame.smethod_31(e), <Module>.smethod_26<string>(107286767U), num);
							if (num > -1)
							{
								int num5 = CssBoxFrame.smethod_33(CssBoxFrame.smethod_31(e), '"', num);
								if (num5 > -1)
								{
									this._videoLinkUrl = CssBoxFrame.smethod_36(CssBoxFrame.smethod_36(CssBoxFrame.smethod_35(CssBoxFrame.smethod_31(e), num, num5 - num), <Module>.smethod_24<string>(145253709U), <Module>.smethod_26<string>(1981843186U)), <Module>.smethod_25<string>(3572883402U), "");
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				base.HtmlContainer.ReportError(HtmlRenderErrorType.Iframe, <Module>.smethod_23<string>(572895858U), ex);
			}
			this.HandlePostApiCall(sender);
		}

		// Token: 0x06000698 RID: 1688 RVA: 0x0003A648 File Offset: 0x00038848
		private void LoadVimeoDataAsync(Uri uri)
		{
			CssBoxFrame.smethod_28(delegate(object state)
			{
				try
				{
					Uri uri2 = CssBoxFrame.<>c__DisplayClass4.smethod_2(CssBoxFrame.<>c__DisplayClass4.smethod_1(<Module>.smethod_23<string>(253055733U), CssBoxFrame.<>c__DisplayClass4.smethod_0(uri)[2]));
					WebClient webClient = CssBoxFrame.<>c__DisplayClass4.smethod_3();
					CssBoxFrame.<>c__DisplayClass4.smethod_5(webClient, CssBoxFrame.<>c__DisplayClass4.smethod_4());
					CssBoxFrame.<>c__DisplayClass4.smethod_6(webClient, new DownloadStringCompletedEventHandler(this.OnDownloadVimeoApiCompleted));
					CssBoxFrame.<>c__DisplayClass4.smethod_7(webClient, uri2);
				}
				catch (Exception ex)
				{
					this._imageLoadingComplete = true;
					for (;;)
					{
						IL_00D7:
						int num = 36105031;
						for (;;)
						{
							switch (num ^ 36105029)
							{
							case 0:
								goto IL_00D7;
							case 1:
								this.HtmlContainer.RequestRefresh(false);
								num = 36105030;
								continue;
							case 2:
								this.SetErrorBorder();
								this.HtmlContainer.ReportError(HtmlRenderErrorType.Iframe, CssBoxFrame.<>c__DisplayClass4.smethod_8(<Module>.smethod_27<string>(932201328U), uri), ex);
								num = 36105028;
								continue;
							}
							goto Block_3;
						}
					}
					Block_3:;
				}
			});
		}

		// Token: 0x06000699 RID: 1689 RVA: 0x0003A67C File Offset: 0x0003887C
		private void OnDownloadVimeoApiCompleted(object sender, DownloadStringCompletedEventArgs e)
		{
			try
			{
				if (!CssBoxFrame.smethod_29(e))
				{
					if (CssBoxFrame.smethod_30(e) == null)
					{
						int num = CssBoxFrame.smethod_27(CssBoxFrame.smethod_31(e), <Module>.smethod_27<string>(3537693969U), StringComparison.Ordinal);
						if (num > -1)
						{
							num = CssBoxFrame.smethod_33(CssBoxFrame.smethod_31(e), '"', num + 7);
							if (num > -1)
							{
								int num2 = CssBoxFrame.smethod_33(CssBoxFrame.smethod_31(e), '"', num + 1);
								while (CssBoxFrame.smethod_34(CssBoxFrame.smethod_31(e), num2 - 1) == '\\')
								{
									num2 = CssBoxFrame.smethod_33(CssBoxFrame.smethod_31(e), '"', num2 + 1);
								}
								if (num2 > -1)
								{
									this._videoTitle = CssBoxFrame.smethod_36(CssBoxFrame.smethod_35(CssBoxFrame.smethod_31(e), num + 1, num2 - num - 1), <Module>.smethod_27<string>(693770696U), <Module>.smethod_26<string>(1981843186U));
								}
							}
						}
						num = CssBoxFrame.smethod_27(CssBoxFrame.smethod_31(e), <Module>.smethod_27<string>(3118098732U), StringComparison.Ordinal);
						if (num > -1)
						{
							if (CssBoxFrame.smethod_37(base.Width))
							{
								base.Width = <Module>.smethod_26<string>(869400554U);
							}
							if (CssBoxFrame.smethod_37(base.Height))
							{
								base.Height = <Module>.smethod_23<string>(2779392132U);
							}
						}
						else
						{
							num = CssBoxFrame.smethod_32(CssBoxFrame.smethod_31(e), <Module>.smethod_27<string>(2651881802U), num);
							if (num > -1)
							{
								if (CssBoxFrame.smethod_37(base.Width))
								{
									base.Width = <Module>.smethod_23<string>(3533705015U);
								}
								if (CssBoxFrame.smethod_37(base.Height))
								{
									base.Height = <Module>.smethod_23<string>(360799981U);
								}
							}
							else
							{
								num = CssBoxFrame.smethod_32(CssBoxFrame.smethod_31(e), <Module>.smethod_24<string>(414546514U), num);
								if (CssBoxFrame.smethod_37(base.Width))
								{
									base.Width = <Module>.smethod_25<string>(4005155699U);
								}
								if (CssBoxFrame.smethod_37(base.Height))
								{
									base.Height = <Module>.smethod_27<string>(1905934714U);
								}
							}
						}
						if (num > -1)
						{
							num = CssBoxFrame.smethod_32(CssBoxFrame.smethod_31(e), <Module>.smethod_26<string>(107286767U), num);
							if (num > -1)
							{
								int num3 = CssBoxFrame.smethod_33(CssBoxFrame.smethod_31(e), '"', num);
								if (num3 > -1)
								{
									this._videoImageUrl = CssBoxFrame.smethod_36(CssBoxFrame.smethod_36(CssBoxFrame.smethod_35(CssBoxFrame.smethod_31(e), num, num3 - num), <Module>.smethod_27<string>(693770696U), <Module>.smethod_26<string>(1981843186U)), <Module>.smethod_25<string>(3572883402U), "");
								}
							}
						}
						num = CssBoxFrame.smethod_27(CssBoxFrame.smethod_31(e), <Module>.smethod_24<string>(4072864813U), StringComparison.Ordinal);
						if (num > -1)
						{
							num = CssBoxFrame.smethod_32(CssBoxFrame.smethod_31(e), <Module>.smethod_23<string>(940645237U), num);
							if (num > -1)
							{
								int num4 = CssBoxFrame.smethod_33(CssBoxFrame.smethod_31(e), '"', num);
								if (num4 > -1)
								{
									this._videoLinkUrl = CssBoxFrame.smethod_36(CssBoxFrame.smethod_36(CssBoxFrame.smethod_35(CssBoxFrame.smethod_31(e), num, num4 - num), <Module>.smethod_26<string>(553379552U), <Module>.smethod_25<string>(1519722181U)), <Module>.smethod_24<string>(1184318668U), "");
								}
							}
						}
					}
					else
					{
						this.HandleDataLoadFailure(CssBoxFrame.smethod_30(e), <Module>.smethod_26<string>(2858873701U));
					}
				}
			}
			catch (Exception ex)
			{
				base.HtmlContainer.ReportError(HtmlRenderErrorType.Iframe, <Module>.smethod_24<string>(468405075U), ex);
			}
			this.HandlePostApiCall(sender);
		}

		// Token: 0x0600069A RID: 1690 RVA: 0x0003A9A0 File Offset: 0x00038BA0
		private void HandleDataLoadFailure(Exception ex, string source)
		{
			WebException ex2 = ex as WebException;
			for (;;)
			{
				IL_007C:
				int num = -2031899452;
				for (;;)
				{
					HttpWebResponse httpWebResponse;
					HttpWebResponse httpWebResponse2;
					switch (num ^ -2031899449)
					{
					case 0:
						goto IL_007C;
					case 1:
						httpWebResponse = null;
						goto IL_0042;
					case 3:
						if (ex2 == null)
						{
							num = -2031899450;
							continue;
						}
						httpWebResponse = CssBoxFrame.smethod_39(ex2) as HttpWebResponse;
						goto IL_0042;
					case 4:
						return;
					case 5:
						if (CssBoxFrame.smethod_40(httpWebResponse2) == HttpStatusCode.NotFound)
						{
							this._videoTitle = <Module>.smethod_23<string>(4057107896U);
							num = -2031899453;
							continue;
						}
						break;
					}
					goto Block_4;
					IL_0042:
					httpWebResponse2 = httpWebResponse;
					num = ((httpWebResponse2 == null) ? (-2031899451) : (-2031899454));
				}
			}
			Block_4:
			base.HtmlContainer.ReportError(HtmlRenderErrorType.Iframe, CssBoxFrame.smethod_41(<Module>.smethod_25<string>(1409975148U), source, <Module>.smethod_23<string>(1039856364U)), ex);
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x0003AA58 File Offset: 0x00038C58
		private void HandlePostApiCall(object sender)
		{
			try
			{
				if (this._videoImageUrl == null)
				{
					this._imageLoadingComplete = true;
					this.SetErrorBorder();
				}
				WebClient webClient = (WebClient)sender;
				CssBoxFrame.smethod_42(webClient, new DownloadStringCompletedEventHandler(this.OnDownloadYoutubeApiCompleted));
				CssBoxFrame.smethod_42(webClient, new DownloadStringCompletedEventHandler(this.OnDownloadVimeoApiCompleted));
				CssBoxFrame.smethod_43(webClient);
				base.HtmlContainer.RequestRefresh(this.IsLayoutRequired());
			}
			catch
			{
			}
		}

		// Token: 0x0600069C RID: 1692 RVA: 0x0003AAD4 File Offset: 0x00038CD4
		protected override void PaintImp(RGraphics g)
		{
			if (this._videoImageUrl != null && this._imageLoadHandler == null)
			{
				this._imageLoadHandler = new ImageLoadHandler(base.HtmlContainer, new ActionInt<RImage, RRect, bool>(this.OnLoadImageComplete));
				this._imageLoadHandler.LoadImage(this._videoImageUrl, (base.HtmlTag != null) ? base.HtmlTag.Attributes : null);
			}
			RRect firstValueOrDefault = CommonUtils.GetFirstValueOrDefault<CssLineBox, RRect>(base.Rectangles, default(RRect));
			RPoint rpoint = ((base.HtmlContainer != null) ? base.HtmlContainer.ScrollOffset : RPoint.Empty);
			firstValueOrDefault.Offset(rpoint);
			bool flag = RenderUtils.ClipGraphicsByOverflow(g, this);
			base.PaintBackground(g, firstValueOrDefault, true, true);
			BordersDrawHandler.DrawBoxBorders(g, this, firstValueOrDefault, true, true);
			CssRect cssRect = base.Words[0];
			RRect rectangle = cssRect.Rectangle;
			rectangle.Offset(rpoint);
			rectangle.Height -= base.ActualBorderTopWidth + base.ActualBorderBottomWidth + base.ActualPaddingTop + base.ActualPaddingBottom;
			rectangle.Y += base.ActualBorderTopWidth + base.ActualPaddingTop;
			rectangle.X = CssBoxFrame.smethod_44(rectangle.X);
			rectangle.Y = CssBoxFrame.smethod_44(rectangle.Y);
			RRect rrect = rectangle;
			this.DrawImage(g, rpoint, rrect);
			this.DrawTitle(g, rrect);
			this.DrawPlay(g, rrect);
			if (flag)
			{
				g.PopClip();
			}
		}

		// Token: 0x0600069D RID: 1693 RVA: 0x0003AC3C File Offset: 0x00038E3C
		private void DrawImage(RGraphics g, RPoint offset, RRect rect)
		{
			if (this._imageWord.Image != null)
			{
				if (rect.Width > 0.0 && rect.Height > 0.0)
				{
					if (this._imageWord.ImageRectangle == RRect.Empty)
					{
						g.DrawImage(this._imageWord.Image, rect);
					}
					else
					{
						g.DrawImage(this._imageWord.Image, rect, this._imageWord.ImageRectangle);
					}
					if (this._imageWord.Selected)
					{
						g.DrawRectangle(base.GetSelectionBackBrush(g, true), this._imageWord.Left + offset.X, this._imageWord.Top + offset.Y, this._imageWord.Width + 2.0, DomUtils.GetCssLineBoxByWord(this._imageWord).LineHeight);
						return;
					}
				}
			}
			else if (this._isVideo && !this._imageLoadingComplete)
			{
				RenderUtils.DrawImageLoadingIcon(g, base.HtmlContainer, rect);
				if (rect.Width > 19.0 && rect.Height > 19.0)
				{
					g.DrawRectangle(g.GetPen(RColor.LightGray), rect.X, rect.Y, rect.Width, rect.Height);
				}
			}
		}

		// Token: 0x0600069E RID: 1694 RVA: 0x0003ADA4 File Offset: 0x00038FA4
		private void DrawTitle(RGraphics g, RRect rect)
		{
			if (this._videoTitle != null && this._imageWord.Width > 40.0 && this._imageWord.Height > 40.0)
			{
				RFont font = base.HtmlContainer.Adapter.GetFont(<Module>.smethod_25<string>(1621352040U), 9.0, RFontStyle.Regular);
				g.DrawRectangle(g.GetSolidBrush(RColor.FromArgb(160, 0, 0, 0)), rect.Left, rect.Top, rect.Width, base.ActualFont.Height + 7.0);
				RRect rrect = new RRect(rect.Left + 3.0, rect.Top + 3.0, rect.Width - 6.0, rect.Height - 6.0);
				g.DrawString(this._videoTitle, font, RColor.WhiteSmoke, rrect.Location, RSize.Empty, false);
			}
		}

		// Token: 0x0600069F RID: 1695 RVA: 0x0003AEC0 File Offset: 0x000390C0
		private void DrawPlay(RGraphics g, RRect rect)
		{
			if (this._isVideo && this._imageWord.Width > 70.0 && this._imageWord.Height > 50.0)
			{
				object obj = g.SetAntiAliasSmoothingMode();
				RSize rsize = new RSize(60.0, 40.0);
				double num = rect.Left + (rect.Width - rsize.Width) / 2.0;
				double num2 = rect.Top + (rect.Height - rsize.Height) / 2.0;
				g.DrawRectangle(g.GetSolidBrush(RColor.FromArgb(160, 0, 0, 0)), num, num2, rsize.Width, rsize.Height);
				RPoint[] array = new RPoint[]
				{
					new RPoint(num + rsize.Width / 3.0 + 1.0, num2 + 3.0 * rsize.Height / 4.0),
					new RPoint(num + rsize.Width / 3.0 + 1.0, num2 + rsize.Height / 4.0),
					new RPoint(num + 2.0 * rsize.Width / 3.0 + 1.0, num2 + rsize.Height / 2.0)
				};
				g.DrawPolygon(g.GetSolidBrush(RColor.White), array);
				g.ReturnPreviousSmoothingMode(obj);
			}
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x0000EDCE File Offset: 0x0000CFCE
		internal override void MeasureWordsSize(RGraphics g)
		{
			if (!this._wordsSizeMeasured)
			{
				base.MeasureWordSpacing(g);
				this._wordsSizeMeasured = true;
			}
			CssLayoutEngine.MeasureImageSize(this._imageWord);
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x0003B098 File Offset: 0x00039298
		private void SetErrorBorder()
		{
			base.SetAllBorders(<Module>.smethod_25<string>(1897157319U), <Module>.smethod_23<string>(1794169247U), <Module>.smethod_27<string>(1294081165U));
			base.BorderRightColor = (base.BorderBottomColor = <Module>.smethod_23<string>(3283980888U));
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x0003B0E4 File Offset: 0x000392E4
		private void OnLoadImageComplete(RImage image, RRect rectangle, bool async)
		{
			this._imageWord.Image = image;
			this._imageWord.ImageRectangle = rectangle;
			this._imageLoadingComplete = true;
			this._wordsSizeMeasured = false;
			if (this._imageLoadingComplete && image == null)
			{
				this.SetErrorBorder();
			}
			if (async)
			{
				base.HtmlContainer.RequestRefresh(this.IsLayoutRequired());
			}
		}

		// Token: 0x060006A3 RID: 1699 RVA: 0x0003B13C File Offset: 0x0003933C
		private bool IsLayoutRequired()
		{
			CssLength cssLength = new CssLength(base.Width);
			CssLength cssLength2 = new CssLength(base.Height);
			return cssLength.Number <= 0.0 || cssLength.Unit != CssUnit.Pixels || cssLength2.Number <= 0.0 || cssLength2.Unit != CssUnit.Pixels;
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x0000EDF1 File Offset: 0x0000CFF1
		static bool smethod_25(string string_0, UriKind uriKind_0, ref Uri uri_0)
		{
			return Uri.TryCreate(string_0, uriKind_0, out uri_0);
		}

		// Token: 0x060006A5 RID: 1701 RVA: 0x0000DEF3 File Offset: 0x0000C0F3
		static string smethod_26(Uri uri_0)
		{
			return uri_0.Host;
		}

		// Token: 0x060006A6 RID: 1702 RVA: 0x0000D40C File Offset: 0x0000B60C
		static int smethod_27(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.IndexOf(string_1, stringComparison_0);
		}

		// Token: 0x060006A7 RID: 1703 RVA: 0x0000EDFB File Offset: 0x0000CFFB
		static bool smethod_28(WaitCallback waitCallback_0)
		{
			return ThreadPool.QueueUserWorkItem(waitCallback_0);
		}

		// Token: 0x060006A8 RID: 1704 RVA: 0x0000EE03 File Offset: 0x0000D003
		static bool smethod_29(AsyncCompletedEventArgs asyncCompletedEventArgs_0)
		{
			return asyncCompletedEventArgs_0.Cancelled;
		}

		// Token: 0x060006A9 RID: 1705 RVA: 0x0000EE0B File Offset: 0x0000D00B
		static Exception smethod_30(AsyncCompletedEventArgs asyncCompletedEventArgs_0)
		{
			return asyncCompletedEventArgs_0.Error;
		}

		// Token: 0x060006AA RID: 1706 RVA: 0x0000EE13 File Offset: 0x0000D013
		static string smethod_31(DownloadStringCompletedEventArgs downloadStringCompletedEventArgs_0)
		{
			return downloadStringCompletedEventArgs_0.Result;
		}

		// Token: 0x060006AB RID: 1707 RVA: 0x0000EE1B File Offset: 0x0000D01B
		static int smethod_32(string string_0, string string_1, int int_0)
		{
			return string_0.IndexOf(string_1, int_0);
		}

		// Token: 0x060006AC RID: 1708 RVA: 0x0000EE25 File Offset: 0x0000D025
		static int smethod_33(string string_0, char char_0, int int_0)
		{
			return string_0.IndexOf(char_0, int_0);
		}

		// Token: 0x060006AD RID: 1709 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_34(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x060006AE RID: 1710 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_35(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x060006AF RID: 1711 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_36(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x060006B0 RID: 1712 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_37(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x060006B1 RID: 1713 RVA: 0x0000EE38 File Offset: 0x0000D038
		static int smethod_38(string string_0, string string_1, int int_0, StringComparison stringComparison_0)
		{
			return string_0.LastIndexOf(string_1, int_0, stringComparison_0);
		}

		// Token: 0x060006B2 RID: 1714 RVA: 0x0000EE43 File Offset: 0x0000D043
		static WebResponse smethod_39(WebException webException_0)
		{
			return webException_0.Response;
		}

		// Token: 0x060006B3 RID: 1715 RVA: 0x0000EE4B File Offset: 0x0000D04B
		static HttpStatusCode smethod_40(HttpWebResponse httpWebResponse_0)
		{
			return httpWebResponse_0.StatusCode;
		}

		// Token: 0x060006B4 RID: 1716 RVA: 0x0000DCB0 File Offset: 0x0000BEB0
		static string smethod_41(string string_0, string string_1, string string_2)
		{
			return string_0 + string_1 + string_2;
		}

		// Token: 0x060006B5 RID: 1717 RVA: 0x0000EE53 File Offset: 0x0000D053
		static void smethod_42(WebClient webClient_0, DownloadStringCompletedEventHandler downloadStringCompletedEventHandler_0)
		{
			webClient_0.DownloadStringCompleted -= downloadStringCompletedEventHandler_0;
		}

		// Token: 0x060006B6 RID: 1718 RVA: 0x0000EE5C File Offset: 0x0000D05C
		static void smethod_43(Component component_0)
		{
			component_0.Dispose();
		}

		// Token: 0x060006B7 RID: 1719 RVA: 0x0000EE64 File Offset: 0x0000D064
		static double smethod_44(double double_0)
		{
			return Math.Floor(double_0);
		}

		// Token: 0x0400026F RID: 623
		private readonly CssRectImage _imageWord;

		// Token: 0x04000270 RID: 624
		private readonly bool _isVideo;

		// Token: 0x04000271 RID: 625
		private string _videoTitle;

		// Token: 0x04000272 RID: 626
		private string _videoImageUrl;

		// Token: 0x04000273 RID: 627
		private string _videoLinkUrl;

		// Token: 0x04000274 RID: 628
		private ImageLoadHandler _imageLoadHandler;

		// Token: 0x04000275 RID: 629
		private bool _imageLoadingComplete;
	}
}
