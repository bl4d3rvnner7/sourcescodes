﻿using System;
using System.Collections.Generic;
using System.Globalization;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Entities;
using TheArtOfDev.HtmlRenderer.Core.Handlers;
using TheArtOfDev.HtmlRenderer.Core.Parse;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x02000078 RID: 120
	internal class CssBox : CssBoxProperties, IDisposable
	{
		// Token: 0x0600063F RID: 1599 RVA: 0x00037C8C File Offset: 0x00035E8C
		public CssBox(CssBox parentBox, HtmlTag tag)
		{
			if (parentBox != null)
			{
				this._parentBox = parentBox;
				this._parentBox.Boxes.Add(this);
			}
			this._htmltag = tag;
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x06000640 RID: 1600 RVA: 0x00037CF8 File Offset: 0x00035EF8
		// (set) Token: 0x06000641 RID: 1601 RVA: 0x0000EAF2 File Offset: 0x0000CCF2
		public HtmlContainerInt HtmlContainer
		{
			get
			{
				HtmlContainerInt htmlContainerInt;
				if ((htmlContainerInt = this._htmlContainer) == null)
				{
					htmlContainerInt = (this._htmlContainer = ((this._parentBox != null) ? this._parentBox.HtmlContainer : null));
				}
				return htmlContainerInt;
			}
			set
			{
				this._htmlContainer = value;
			}
		}

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x06000642 RID: 1602 RVA: 0x0000EAFB File Offset: 0x0000CCFB
		// (set) Token: 0x06000643 RID: 1603 RVA: 0x0000EB03 File Offset: 0x0000CD03
		public CssBox ParentBox
		{
			get
			{
				return this._parentBox;
			}
			set
			{
				if (this._parentBox != null)
				{
					this._parentBox.Boxes.Remove(this);
				}
				this._parentBox = value;
				if (value != null)
				{
					this._parentBox.Boxes.Add(this);
				}
			}
		}

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x06000644 RID: 1604 RVA: 0x0000EB3A File Offset: 0x0000CD3A
		public List<CssBox> Boxes
		{
			get
			{
				return this._boxes;
			}
		}

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x06000645 RID: 1605 RVA: 0x0000EB42 File Offset: 0x0000CD42
		public bool IsBrElement
		{
			get
			{
				return this._htmltag != null && CssBox.smethod_11(this._htmltag.Name, <Module>.smethod_27<string>(3601630282U), StringComparison.InvariantCultureIgnoreCase);
			}
		}

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x06000646 RID: 1606 RVA: 0x0000EB69 File Offset: 0x0000CD69
		public bool IsInline
		{
			get
			{
				return (CssBox.smethod_12(base.Display, <Module>.smethod_23<string>(3217257509U)) || CssBox.smethod_12(base.Display, <Module>.smethod_27<string>(3881360440U))) && !this.IsBrElement;
			}
		}

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x06000647 RID: 1607 RVA: 0x0000EBA4 File Offset: 0x0000CDA4
		public bool IsBlock
		{
			get
			{
				return CssBox.smethod_12(base.Display, <Module>.smethod_27<string>(3321900124U));
			}
		}

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x06000648 RID: 1608 RVA: 0x0000EBBB File Offset: 0x0000CDBB
		public virtual bool IsClickable
		{
			get
			{
				return this.HtmlTag != null && CssBox.smethod_12(this.HtmlTag.Name, <Module>.smethod_27<string>(3461765203U)) && !this.HtmlTag.HasAttribute(<Module>.smethod_26<string>(1730530963U));
			}
		}

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x06000649 RID: 1609 RVA: 0x0000EBFB File Offset: 0x0000CDFB
		public virtual string HrefLink
		{
			get
			{
				return this.GetAttribute(<Module>.smethod_27<string>(3368521817U));
			}
		}

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x0600064A RID: 1610 RVA: 0x00037D30 File Offset: 0x00035F30
		public CssBox ContainingBlock
		{
			get
			{
				if (this.ParentBox == null)
				{
					return this;
				}
				CssBox cssBox = this.ParentBox;
				while (!cssBox.IsBlock && CssBox.smethod_13(cssBox.Display, <Module>.smethod_24<string>(1060849246U)) && CssBox.smethod_13(cssBox.Display, <Module>.smethod_24<string>(2686768490U)) && CssBox.smethod_13(cssBox.Display, <Module>.smethod_24<string>(2280288679U)) && cssBox.ParentBox != null)
				{
					cssBox = cssBox.ParentBox;
				}
				if (cssBox == null)
				{
					throw CssBox.smethod_14(<Module>.smethod_27<string>(4155319058U));
				}
				return cssBox;
			}
		}

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x0600064B RID: 1611 RVA: 0x0000EC0D File Offset: 0x0000CE0D
		public HtmlTag HtmlTag
		{
			get
			{
				return this._htmltag;
			}
		}

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x0600064C RID: 1612 RVA: 0x0000EC15 File Offset: 0x0000CE15
		public bool IsImage
		{
			get
			{
				return this.Words.Count == 1 && this.Words[0].IsImage;
			}
		}

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x0600064D RID: 1613 RVA: 0x00037DC0 File Offset: 0x00035FC0
		public bool IsSpaceOrEmpty
		{
			get
			{
				if (this.Words.Count != 0 || this.Boxes.Count != 0)
				{
					if (this.Words.Count == 1)
					{
						if (this.Words[0].IsSpaces)
						{
							return true;
						}
					}
					using (List<CssRect>.Enumerator enumerator = this.Words.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							CssRect cssRect = enumerator.Current;
							if (!cssRect.IsSpaces)
							{
								return false;
							}
						}
						return true;
					}
					bool flag;
					return flag;
				}
				return true;
			}
		}

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x0600064E RID: 1614 RVA: 0x0000EC38 File Offset: 0x0000CE38
		// (set) Token: 0x0600064F RID: 1615 RVA: 0x0000EC40 File Offset: 0x0000CE40
		public SubString Text
		{
			get
			{
				return this._text;
			}
			set
			{
				this._text = value;
				this._boxWords.Clear();
			}
		}

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x06000650 RID: 1616 RVA: 0x0000EC54 File Offset: 0x0000CE54
		internal List<CssLineBox> LineBoxes
		{
			get
			{
				return this._lineBoxes;
			}
		}

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x06000651 RID: 1617 RVA: 0x0000EC5C File Offset: 0x0000CE5C
		internal List<CssLineBox> ParentLineBoxes
		{
			get
			{
				return this._parentLineBoxes;
			}
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x06000652 RID: 1618 RVA: 0x0000EC64 File Offset: 0x0000CE64
		internal Dictionary<CssLineBox, RRect> Rectangles
		{
			get
			{
				return this._rectangles;
			}
		}

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x06000653 RID: 1619 RVA: 0x0000EC6C File Offset: 0x0000CE6C
		internal List<CssRect> Words
		{
			get
			{
				return this._boxWords;
			}
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x06000654 RID: 1620 RVA: 0x0000EC74 File Offset: 0x0000CE74
		internal CssRect FirstWord
		{
			get
			{
				return this.Words[0];
			}
		}

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x06000655 RID: 1621 RVA: 0x0000EC82 File Offset: 0x0000CE82
		// (set) Token: 0x06000656 RID: 1622 RVA: 0x0000EC8A File Offset: 0x0000CE8A
		internal CssLineBox FirstHostingLineBox
		{
			get
			{
				return this._firstHostingLineBox;
			}
			set
			{
				this._firstHostingLineBox = value;
			}
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x06000657 RID: 1623 RVA: 0x0000EC93 File Offset: 0x0000CE93
		// (set) Token: 0x06000658 RID: 1624 RVA: 0x0000EC9B File Offset: 0x0000CE9B
		internal CssLineBox LastHostingLineBox
		{
			get
			{
				return this._lastHostingLineBox;
			}
			set
			{
				this._lastHostingLineBox = value;
			}
		}

		// Token: 0x06000659 RID: 1625 RVA: 0x00037E5C File Offset: 0x0003605C
		public static CssBox CreateBox(HtmlTag tag, CssBox parent = null)
		{
			ArgChecker.AssertArgNotNull(tag, <Module>.smethod_26<string>(1851771403U));
			if (CssBox.smethod_12(tag.Name, <Module>.smethod_23<string>(355659479U)))
			{
				return new CssBoxImage(parent, tag);
			}
			if (CssBox.smethod_12(tag.Name, <Module>.smethod_24<string>(1168566368U)))
			{
				return new CssBoxFrame(parent, tag);
			}
			if (CssBox.smethod_12(tag.Name, <Module>.smethod_25<string>(2965179776U)))
			{
				return new CssBoxHr(parent, tag);
			}
			return new CssBox(parent, tag);
		}

		// Token: 0x0600065A RID: 1626 RVA: 0x00037EE0 File Offset: 0x000360E0
		public static CssBox CreateBox(CssBox parent, HtmlTag tag = null, CssBox before = null)
		{
			ArgChecker.AssertArgNotNull(parent, <Module>.smethod_25<string>(1420676855U));
			CssBox cssBox = new CssBox(parent, tag);
			cssBox.InheritStyle(null, false);
			if (before != null)
			{
				cssBox.SetBeforeBox(before);
			}
			return cssBox;
		}

		// Token: 0x0600065B RID: 1627 RVA: 0x00037F18 File Offset: 0x00036118
		public static CssBox CreateBlock()
		{
			return new CssBox(null, null)
			{
				Display = <Module>.smethod_26<string>(1300338284U)
			};
		}

		// Token: 0x0600065C RID: 1628 RVA: 0x00037F40 File Offset: 0x00036140
		public static CssBox CreateBlock(CssBox parent, HtmlTag tag = null, CssBox before = null)
		{
			ArgChecker.AssertArgNotNull(parent, <Module>.smethod_23<string>(1845471120U));
			CssBox cssBox = CssBox.CreateBox(parent, tag, before);
			cssBox.Display = <Module>.smethod_23<string>(567755356U);
			return cssBox;
		}

		// Token: 0x0600065D RID: 1629 RVA: 0x00037F78 File Offset: 0x00036178
		public void PerformLayout(RGraphics g)
		{
			try
			{
				this.PerformLayoutImp(g);
			}
			catch (Exception ex)
			{
				this.HtmlContainer.ReportError(HtmlRenderErrorType.Layout, <Module>.smethod_24<string>(938397182U), ex);
			}
		}

		// Token: 0x0600065E RID: 1630 RVA: 0x00037FB8 File Offset: 0x000361B8
		public void Paint(RGraphics g)
		{
			try
			{
				if (CssBox.smethod_13(base.Display, <Module>.smethod_27<string>(1876627641U)) && CssBox.smethod_12(base.Visibility, <Module>.smethod_25<string>(2902298158U)))
				{
					bool flag;
					if (!(flag = this.Rectangles.Count == 0))
					{
						RRect clip = g.GetClip();
						RRect clientRectangle = this.ContainingBlock.ClientRectangle;
						clientRectangle.X -= 2.0;
						clientRectangle.Width += 2.0;
						clientRectangle.Offset(new RPoint(-this.HtmlContainer.Location.X, -this.HtmlContainer.Location.Y));
						clientRectangle.Offset(this.HtmlContainer.ScrollOffset);
						clip.Intersect(clientRectangle);
						if (clip != RRect.Empty)
						{
							flag = true;
						}
					}
					if (flag)
					{
						this.PaintImp(g);
					}
				}
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_0130:
					int num = -1113843513;
					for (;;)
					{
						switch (num ^ -1113843514)
						{
						case 0:
							goto IL_0130;
						case 1:
							this.HtmlContainer.ReportError(HtmlRenderErrorType.Paint, <Module>.smethod_26<string>(2594732402U), ex);
							num = -1113843516;
							continue;
						}
						goto Block_8;
					}
				}
				Block_8:;
			}
		}

		// Token: 0x0600065F RID: 1631 RVA: 0x00038110 File Offset: 0x00036310
		public void SetBeforeBox(CssBox before)
		{
			int num = this._parentBox.Boxes.IndexOf(before);
			if (num < 0)
			{
				throw CssBox.smethod_14(<Module>.smethod_26<string>(1890076979U));
			}
			this._parentBox.Boxes.Remove(this);
			this._parentBox.Boxes.Insert(num, this);
		}

		// Token: 0x06000660 RID: 1632 RVA: 0x00038168 File Offset: 0x00036368
		public void SetAllBoxes(CssBox fromBox)
		{
			foreach (CssBox cssBox in fromBox._boxes)
			{
				cssBox._parentBox = this;
			}
			this._boxes.AddRange(fromBox._boxes);
			fromBox._boxes.Clear();
		}

		// Token: 0x06000661 RID: 1633 RVA: 0x000381D8 File Offset: 0x000363D8
		public void ParseToWords()
		{
			this._boxWords.Clear();
			int i = 0;
			bool flag2;
			bool flag = (flag2 = CssBox.smethod_12(base.WhiteSpace, <Module>.smethod_24<string>(1859073926U)) || CssBox.smethod_12(base.WhiteSpace, <Module>.smethod_25<string>(3856587710U))) || CssBox.smethod_12(base.WhiteSpace, <Module>.smethod_24<string>(3891472981U));
			while (i < this._text.Length)
			{
				while (i < this._text.Length && this._text[i] == '\r')
				{
					i++;
				}
				if (i < this._text.Length)
				{
					int num = i;
					while (num < this._text.Length && char.IsWhiteSpace(this._text[num]) && this._text[num] != '\n')
					{
						num++;
					}
					if (num > i)
					{
						if (flag2)
						{
							this._boxWords.Add(new CssRectWord(this, HtmlUtils.DecodeHtml(this._text.Substring(i, num - i)), false, false));
						}
					}
					else
					{
						num = i;
						while (num < this._text.Length && !char.IsWhiteSpace(this._text[num]) && this._text[num] != '-' && CssBox.smethod_13(base.WordBreak, <Module>.smethod_24<string>(815945118U)) && !CommonUtils.IsAsianCharecter(this._text[num]))
						{
							num++;
						}
						if (num < this._text.Length && (this._text[num] == '-' || CssBox.smethod_12(base.WordBreak, <Module>.smethod_24<string>(815945118U)) || CommonUtils.IsAsianCharecter(this._text[num])))
						{
							num++;
						}
						if (num > i)
						{
							bool flag3 = !flag2 && (i > 0 && this._boxWords.Count == 0) && char.IsWhiteSpace(this._text[i - 1]);
							bool flag4 = !flag2 && num < this._text.Length && char.IsWhiteSpace(this._text[num]);
							this._boxWords.Add(new CssRectWord(this, HtmlUtils.DecodeHtml(this._text.Substring(i, num - i)), flag3, flag4));
						}
					}
					if (num < this._text.Length && this._text[num] == '\n')
					{
						num++;
						if (flag)
						{
							this._boxWords.Add(new CssRectWord(this, <Module>.smethod_27<string>(3511083134U), false, false));
						}
					}
					i = num;
				}
			}
		}

		// Token: 0x06000662 RID: 1634 RVA: 0x00038474 File Offset: 0x00036674
		public virtual void Dispose()
		{
			if (this._imageLoadHandler != null)
			{
				this._imageLoadHandler.Dispose();
			}
			foreach (CssBox cssBox in this.Boxes)
			{
				cssBox.Dispose();
			}
		}

		// Token: 0x06000663 RID: 1635 RVA: 0x000384DC File Offset: 0x000366DC
		protected virtual void PerformLayoutImp(RGraphics g)
		{
			if (CssBox.smethod_13(base.Display, <Module>.smethod_27<string>(1876627641U)))
			{
				this.RectanglesReset();
				this.MeasureWordsSize(g);
			}
			if (!this.IsBlock && !CssBox.smethod_12(base.Display, <Module>.smethod_26<string>(595682861U)) && !CssBox.smethod_12(base.Display, <Module>.smethod_26<string>(2033722889U)) && !CssBox.smethod_12(base.Display, <Module>.smethod_23<string>(1826656995U)) && !CssBox.smethod_12(base.Display, <Module>.smethod_25<string>(4224649765U)))
			{
				CssBox previousSibling = DomUtils.GetPreviousSibling(this);
				if (previousSibling != null)
				{
					if (base.Location == RPoint.Empty)
					{
						base.Location = previousSibling.Location;
					}
					base.ActualBottom = previousSibling.ActualBottom;
				}
			}
			else
			{
				if (CssBox.smethod_13(base.Display, <Module>.smethod_23<string>(3933942142U)) && CssBox.smethod_13(base.Display, <Module>.smethod_25<string>(138474828U)))
				{
					double num = this.ContainingBlock.Size.Width - this.ContainingBlock.ActualPaddingLeft - this.ContainingBlock.ActualPaddingRight - this.ContainingBlock.ActualBorderLeftWidth - this.ContainingBlock.ActualBorderRightWidth;
					if (CssBox.smethod_13(base.Width, <Module>.smethod_24<string>(2471334246U)) && !CssBox.smethod_15(base.Width))
					{
						num = CssValueParser.ParseLength(base.Width, num, this, false);
					}
					base.Size = new RSize(num, base.Size.Height);
					base.Size = new RSize(num - base.ActualMarginLeft - base.ActualMarginRight, base.Size.Height);
				}
				if (CssBox.smethod_13(base.Display, <Module>.smethod_24<string>(2280288679U)))
				{
					CssBox previousSibling2 = DomUtils.GetPreviousSibling(this);
					double num2 = this.ContainingBlock.Location.X + this.ContainingBlock.ActualPaddingLeft + base.ActualMarginLeft + this.ContainingBlock.ActualBorderLeftWidth;
					double num3 = ((previousSibling2 != null || this.ParentBox == null) ? ((this.ParentBox == null) ? base.Location.Y : 0.0) : this.ParentBox.ClientTop) + this.MarginTopCollapse(previousSibling2) + ((previousSibling2 != null) ? (previousSibling2.ActualBottom + previousSibling2.ActualBorderBottomWidth) : 0.0);
					base.Location = new RPoint(num2, num3);
					base.ActualBottom = num3;
				}
				if (!CssBox.smethod_12(base.Display, <Module>.smethod_24<string>(2686768490U)) && !CssBox.smethod_12(base.Display, <Module>.smethod_25<string>(4274172428U)))
				{
					if (DomUtils.ContainsInlinesOnly(this))
					{
						base.ActualBottom = base.Location.Y;
						CssLayoutEngine.CreateLineBoxes(g, this);
					}
					else if (this._boxes.Count > 0)
					{
						foreach (CssBox cssBox in this.Boxes)
						{
							cssBox.PerformLayout(g);
						}
						base.ActualRight = this.CalculateActualRight();
						base.ActualBottom = this.MarginBottomCollapse();
					}
				}
				else
				{
					CssLayoutEngineTable.PerformLayout(g, this);
				}
			}
			base.ActualBottom = CssBox.smethod_16(base.ActualBottom, base.Location.Y + base.ActualHeight);
			this.CreateListItemBox(g);
			double num4 = CssBox.smethod_16(this.GetMinimumWidth() + CssBox.GetWidthMarginDeep(this), (base.Size.Width < 90999.0) ? (base.ActualRight - this.HtmlContainer.Root.Location.X) : 0.0);
			this.HtmlContainer.ActualSize = CommonUtils.Max(this.HtmlContainer.ActualSize, new RSize(num4, base.ActualBottom - this.HtmlContainer.Root.Location.Y));
		}

		// Token: 0x06000664 RID: 1636 RVA: 0x00038914 File Offset: 0x00036B14
		internal virtual void MeasureWordsSize(RGraphics g)
		{
			if (!this._wordsSizeMeasured)
			{
				if (CssBox.smethod_13(base.BackgroundImage, <Module>.smethod_25<string>(1669618794U)) && this._imageLoadHandler == null)
				{
					this._imageLoadHandler = new ImageLoadHandler(this.HtmlContainer, new ActionInt<RImage, RRect, bool>(this.OnImageLoadComplete));
					this._imageLoadHandler.LoadImage(base.BackgroundImage, (this.HtmlTag != null) ? this.HtmlTag.Attributes : null);
				}
				base.MeasureWordSpacing(g);
				if (this.Words.Count > 0)
				{
					foreach (CssRect cssRect in this.Words)
					{
						cssRect.Width = (CssBox.smethod_13(cssRect.Text, <Module>.smethod_25<string>(3918067989U)) ? g.MeasureString(cssRect.Text, base.ActualFont).Width : 0.0);
						cssRect.Height = base.ActualFont.Height;
					}
				}
				this._wordsSizeMeasured = true;
			}
		}

		// Token: 0x06000665 RID: 1637 RVA: 0x0000EAFB File Offset: 0x0000CCFB
		protected sealed override CssBoxProperties GetParent()
		{
			return this._parentBox;
		}

		// Token: 0x06000666 RID: 1638 RVA: 0x00038A44 File Offset: 0x00036C44
		private int GetIndexForList()
		{
			bool flag = !CssBox.smethod_15(this.ParentBox.GetAttribute(<Module>.smethod_24<string>(1609597270U)));
			int num;
			if (!int.TryParse(this.ParentBox.GetAttribute(<Module>.smethod_24<string>(1203117459U)), out num))
			{
				if (flag)
				{
					num = 0;
					using (List<CssBox>.Enumerator enumerator = this.ParentBox.Boxes.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							CssBox cssBox = enumerator.Current;
							if (CssBox.smethod_12(cssBox.Display, <Module>.smethod_23<string>(1322068239U)))
							{
								num++;
							}
						}
						goto IL_0093;
					}
				}
				num = 1;
			}
			IL_0093:
			using (List<CssBox>.Enumerator enumerator2 = this.ParentBox.Boxes.GetEnumerator())
			{
				while (enumerator2.MoveNext())
				{
					CssBox cssBox2 = enumerator2.Current;
					if (CssBox.smethod_17(cssBox2, this))
					{
						return num;
					}
					if (CssBox.smethod_12(cssBox2.Display, <Module>.smethod_27<string>(2902304887U)))
					{
						num += (flag ? (-1) : 1);
					}
				}
				return num;
			}
			int num2;
			return num2;
		}

		// Token: 0x06000667 RID: 1639 RVA: 0x00038B6C File Offset: 0x00036D6C
		private void CreateListItemBox(RGraphics g)
		{
			if (CssBox.smethod_12(base.Display, <Module>.smethod_23<string>(1322068239U)) && CssBox.smethod_13(base.ListStyleType, <Module>.smethod_25<string>(1669618794U)))
			{
				if (this._listItemBox == null)
				{
					this._listItemBox = new CssBox(null, null);
					this._listItemBox.InheritStyle(this, false);
					this._listItemBox.Display = <Module>.smethod_26<string>(3404728159U);
					this._listItemBox.HtmlContainer = this.HtmlContainer;
					if (CssBox.smethod_11(base.ListStyleType, <Module>.smethod_23<string>(3585006888U), StringComparison.InvariantCultureIgnoreCase))
					{
						this._listItemBox.Text = new SubString(<Module>.smethod_25<string>(78250458U));
					}
					else if (!CssBox.smethod_11(base.ListStyleType, <Module>.smethod_24<string>(566468462U), StringComparison.InvariantCultureIgnoreCase))
					{
						if (!CssBox.smethod_11(base.ListStyleType, <Module>.smethod_25<string>(704627535U), StringComparison.InvariantCultureIgnoreCase))
						{
							if (CssBox.smethod_11(base.ListStyleType, <Module>.smethod_26<string>(4210726183U), StringComparison.InvariantCultureIgnoreCase))
							{
								this._listItemBox.Text = new SubString(this.GetIndexForList().ToString(CssBox.smethod_18()) + <Module>.smethod_25<string>(1403186598U));
							}
							else if (!base.ListStyleType.Equals(<Module>.smethod_27<string>(2377923184U), StringComparison.InvariantCultureIgnoreCase))
							{
								this._listItemBox.Text = new SubString(CommonUtils.ConvertToAlphaNumber(this.GetIndexForList(), base.ListStyleType) + <Module>.smethod_24<string>(4261372568U));
							}
							else
							{
								this._listItemBox.Text = new SubString(this.GetIndexForList().ToString(<Module>.smethod_27<string>(1725219482U), CultureInfo.InvariantCulture) + <Module>.smethod_27<string>(859418173U));
							}
						}
						else
						{
							this._listItemBox.Text = new SubString(<Module>.smethod_23<string>(1214323991U));
						}
					}
					else
					{
						this._listItemBox.Text = new SubString(<Module>.smethod_25<string>(843822441U));
					}
					this._listItemBox.ParseToWords();
					this._listItemBox.PerformLayoutImp(g);
					this._listItemBox.Size = new RSize(this._listItemBox.Words[0].Width, this._listItemBox.Words[0].Height);
				}
				this._listItemBox.Words[0].Left = base.Location.X - this._listItemBox.Size.Width - 5.0;
				this._listItemBox.Words[0].Top = base.Location.Y + base.ActualPaddingTop;
			}
		}

		// Token: 0x06000668 RID: 1640 RVA: 0x00038E34 File Offset: 0x00037034
		internal CssRect FirstWordOccourence(CssBox b, CssLineBox line)
		{
			if (b.Words.Count == 0 && b.Boxes.Count == 0)
			{
				return null;
			}
			if (b.Words.Count > 0)
			{
				foreach (CssRect cssRect in b.Words)
				{
					if (line.Words.Contains(cssRect))
					{
						return cssRect;
					}
				}
				return null;
			}
			foreach (CssBox cssBox in b.Boxes)
			{
				CssRect cssRect2 = this.FirstWordOccourence(cssBox, line);
				if (cssRect2 != null)
				{
					return cssRect2;
				}
			}
			return null;
		}

		// Token: 0x06000669 RID: 1641 RVA: 0x0000ECA4 File Offset: 0x0000CEA4
		internal string GetAttribute(string attribute)
		{
			return this.GetAttribute(attribute, string.Empty);
		}

		// Token: 0x0600066A RID: 1642 RVA: 0x0000ECB2 File Offset: 0x0000CEB2
		internal string GetAttribute(string attribute, string defaultValue)
		{
			if (this.HtmlTag == null)
			{
				return defaultValue;
			}
			return this.HtmlTag.TryGetAttribute(attribute, defaultValue);
		}

		// Token: 0x0600066B RID: 1643 RVA: 0x00038F18 File Offset: 0x00037118
		internal double GetMinimumWidth()
		{
			/*
An exception occurred when decompiling this method (0600066B)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Double TheArtOfDev.HtmlRenderer.Core.Dom.CssBox::GetMinimumWidth()
 ---> System.Exception: Inconsistent stack size at IL_0034
   bei ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:Zeile 288.
   bei ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:Zeile 278.
   bei ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:Zeile 112.
   bei ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:Zeile 88.
   --- Ende der internen Ausnahmestapelüberwachung ---
   bei ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:Zeile 92.
   bei ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:Zeile 1686.
*/;
		}

		// Token: 0x0600066C RID: 1644 RVA: 0x00038F64 File Offset: 0x00037164
		private static void GetMinimumWidth_LongestWord(CssBox box, ref double maxWidth, ref CssRect maxWidthWord)
		{
			if (box.Words.Count > 0)
			{
				using (List<CssRect>.Enumerator enumerator = box.Words.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						CssRect cssRect = enumerator.Current;
						if (cssRect.Width > maxWidth)
						{
							maxWidth = cssRect.Width;
							maxWidthWord = cssRect;
						}
					}
					return;
				}
			}
			foreach (CssBox cssBox in box.Boxes)
			{
				CssBox.GetMinimumWidth_LongestWord(cssBox, ref maxWidth, ref maxWidthWord);
			}
		}

		// Token: 0x0600066D RID: 1645 RVA: 0x00039018 File Offset: 0x00037218
		private static double GetWidthMarginDeep(CssBox box)
		{
			double num = 0.0;
			if (box.Size.Width <= 90999.0)
			{
				if (box.ParentBox == null)
				{
					return num;
				}
				if (box.ParentBox.Size.Width <= 90999.0)
				{
					return num;
				}
			}
			while (box != null)
			{
				num += box.ActualMarginLeft + box.ActualMarginRight;
				box = box.ParentBox;
			}
			return num;
		}

		// Token: 0x0600066E RID: 1646 RVA: 0x0003908C File Offset: 0x0003728C
		internal double GetMaximumBottom(CssBox startBox, double currentMaxBottom)
		{
			foreach (CssLineBox cssLineBox in startBox.Rectangles.Keys)
			{
				currentMaxBottom = CssBox.smethod_16(currentMaxBottom, startBox.Rectangles[cssLineBox].Bottom);
			}
			foreach (CssBox cssBox in startBox.Boxes)
			{
				currentMaxBottom = CssBox.smethod_16(currentMaxBottom, this.GetMaximumBottom(cssBox, currentMaxBottom));
			}
			return currentMaxBottom;
		}

		// Token: 0x0600066F RID: 1647 RVA: 0x0003914C File Offset: 0x0003734C
		internal void GetMinMaxWidth(out double minWidth, out double maxWidth)
		{
			double num = 0.0;
			double num2 = 0.0;
			double num3 = 0.0;
			double num4 = 0.0;
			CssBox.GetMinMaxSumWords(this, ref num, ref num2, ref num3, ref num4);
			maxWidth = num3 + num2;
			minWidth = num3 + ((num < 90999.0) ? num : 0.0);
		}

		// Token: 0x06000670 RID: 1648 RVA: 0x000391B0 File Offset: 0x000373B0
		private static void GetMinMaxSumWords(CssBox box, ref double min, ref double maxSum, ref double paddingSum, ref double marginSum)
		{
			double? num = null;
			if (CssBox.smethod_13(box.Display, <Module>.smethod_27<string>(5988381U)) && CssBox.smethod_13(box.Display, <Module>.smethod_27<string>(3042169966U)) && CssBox.smethod_13(box.WhiteSpace, <Module>.smethod_26<string>(2087183520U)))
			{
				num = new double?(maxSum);
				maxSum = marginSum;
			}
			paddingSum += box.ActualBorderLeftWidth + box.ActualBorderRightWidth + box.ActualPaddingRight + box.ActualPaddingLeft;
			if (CssBox.smethod_12(box.Display, <Module>.smethod_26<string>(2033722889U)))
			{
				paddingSum += CssLayoutEngineTable.GetTableSpacing(box);
			}
			if (box.Words.Count > 0)
			{
				foreach (CssRect cssRect in box.Words)
				{
					maxSum += cssRect.FullWidth + (cssRect.HasSpaceBefore ? cssRect.OwnerBox.ActualWordSpacing : 0.0);
					min = CssBox.smethod_16(min, cssRect.Width);
				}
				if (box.Words.Count > 0 && !box.Words[box.Words.Count - 1].HasSpaceAfter)
				{
					maxSum -= box.Words[box.Words.Count - 1].ActualWordSpacing;
				}
			}
			else
			{
				for (int i = 0; i < box.Boxes.Count; i++)
				{
					CssBox cssBox = box.Boxes[i];
					marginSum += cssBox.ActualMarginLeft + cssBox.ActualMarginRight;
					CssBox.GetMinMaxSumWords(cssBox, ref min, ref maxSum, ref paddingSum, ref marginSum);
					marginSum -= cssBox.ActualMarginLeft + cssBox.ActualMarginRight;
				}
			}
			if (num != null)
			{
				maxSum = CssBox.smethod_16(maxSum, num.Value);
			}
		}

		// Token: 0x06000671 RID: 1649 RVA: 0x0000ECCB File Offset: 0x0000CECB
		internal bool HasJustInlineSiblings()
		{
			return this.ParentBox != null && DomUtils.ContainsInlinesOnly(this.ParentBox);
		}

		// Token: 0x06000672 RID: 1650 RVA: 0x0000ECE2 File Offset: 0x0000CEE2
		internal new void InheritStyle(CssBox box = null, bool everything = false)
		{
			base.InheritStyle(box ?? this.ParentBox, everything);
		}

		// Token: 0x06000673 RID: 1651 RVA: 0x000393AC File Offset: 0x000375AC
		protected double MarginTopCollapse(CssBoxProperties prevSibling)
		{
			double num;
			if (prevSibling != null)
			{
				num = CssBox.smethod_16(prevSibling.ActualMarginBottom, base.ActualMarginTop);
				base.CollapsedMarginTop = num;
			}
			else if (this._parentBox != null && base.ActualPaddingTop < 0.1 && base.ActualPaddingBottom < 0.1 && this._parentBox.ActualPaddingTop < 0.1 && this._parentBox.ActualPaddingBottom < 0.1)
			{
				num = CssBox.smethod_16(0.0, base.ActualMarginTop - CssBox.smethod_16(this._parentBox.ActualMarginTop, this._parentBox.CollapsedMarginTop));
			}
			else
			{
				num = base.ActualMarginTop;
			}
			if (num < 0.1 && this.HtmlTag != null && CssBox.smethod_12(this.HtmlTag.Name, <Module>.smethod_26<string>(1203829293U)))
			{
				num = base.GetEmHeight() * 1.1000000238418579;
			}
			return num;
		}

		// Token: 0x06000674 RID: 1652 RVA: 0x000394B0 File Offset: 0x000376B0
		private double CalculateActualRight()
		{
			if (base.ActualRight > 90999.0)
			{
				double num = 0.0;
				foreach (CssBox cssBox in this.Boxes)
				{
					num = CssBox.smethod_16(num, cssBox.ActualRight + cssBox.ActualMarginRight);
				}
				return num + base.ActualPaddingRight + base.ActualMarginRight + base.ActualBorderRightWidth;
			}
			return base.ActualRight;
		}

		// Token: 0x06000675 RID: 1653 RVA: 0x0003954C File Offset: 0x0003774C
		private double MarginBottomCollapse()
		{
			double num = 0.0;
			for (;;)
			{
				IL_00FA:
				int num2 = -2022335847;
				for (;;)
				{
					double num3;
					switch (num2 ^ -2022335841)
					{
					case 0:
						goto IL_00FA;
					case 1:
					{
						if (!CssBox.smethod_12(base.Height, <Module>.smethod_27<string>(1783384255U)))
						{
							num2 = -2022335844;
							continue;
						}
						double actualMarginBottom;
						num3 = CssBox.smethod_16(base.ActualMarginBottom, actualMarginBottom);
						goto IL_0078;
					}
					case 2:
					{
						double actualMarginBottom = this._boxes[this._boxes.Count - 1].ActualMarginBottom;
						num2 = -2022335842;
						continue;
					}
					case 3:
					{
						double actualMarginBottom;
						num3 = actualMarginBottom;
						goto IL_0078;
					}
					case 4:
						if (this.ParentBox.Boxes.IndexOf(this) == this.ParentBox.Boxes.Count - 1)
						{
							num2 = ((this._parentBox.ActualMarginBottom >= 0.1) ? (-2022335846) : (-2022335843));
							continue;
						}
						break;
					case 6:
						num2 = ((this.ParentBox == null) ? (-2022335846) : (-2022335845));
						continue;
					}
					goto Block_5;
					IL_0078:
					num = num3;
					num2 = -2022335846;
				}
			}
			Block_5:
			return CssBox.smethod_16(base.ActualBottom, this._boxes[this._boxes.Count - 1].ActualBottom + num + base.ActualPaddingBottom + base.ActualBorderBottomWidth);
		}

		// Token: 0x06000676 RID: 1654 RVA: 0x00039694 File Offset: 0x00037894
		internal void OffsetTop(double amount)
		{
			List<CssLineBox> list = new List<CssLineBox>();
			foreach (CssLineBox cssLineBox in this.Rectangles.Keys)
			{
				list.Add(cssLineBox);
			}
			foreach (CssLineBox cssLineBox2 in list)
			{
				RRect rrect = this.Rectangles[cssLineBox2];
				this.Rectangles[cssLineBox2] = new RRect(rrect.X, rrect.Y + amount, rrect.Width, rrect.Height);
			}
			foreach (CssRect cssRect in this.Words)
			{
				cssRect.Top += amount;
			}
			foreach (CssBox cssBox in this.Boxes)
			{
				cssBox.OffsetTop(amount);
			}
			if (this._listItemBox != null)
			{
				this._listItemBox.OffsetTop(amount);
			}
			base.Location = new RPoint(base.Location.X, base.Location.Y + amount);
		}

		// Token: 0x06000677 RID: 1655 RVA: 0x0003983C File Offset: 0x00037A3C
		protected virtual void PaintImp(RGraphics g)
		{
			if (CssBox.smethod_13(base.Display, <Module>.smethod_24<string>(3284293868U)) && (CssBox.smethod_13(base.Display, <Module>.smethod_23<string>(3933942142U)) || CssBox.smethod_13(base.EmptyCells, <Module>.smethod_27<string>(1398867631U)) || !this.IsSpaceOrEmpty))
			{
				bool flag = RenderUtils.ClipGraphicsByOverflow(g, this);
				List<RRect> list = ((this.Rectangles.Count == 0) ? new List<RRect>(new RRect[] { base.Bounds }) : new List<RRect>(this.Rectangles.Values));
				RRect[] array = list.ToArray();
				RPoint scrollOffset = this.HtmlContainer.ScrollOffset;
				for (int i = 0; i < array.Length; i++)
				{
					RRect rrect = array[i];
					rrect.Offset(scrollOffset);
					this.PaintBackground(g, rrect, i == 0, i == array.Length - 1);
					BordersDrawHandler.DrawBoxBorders(g, this, rrect, i == 0, i == array.Length - 1);
				}
				this.PaintWords(g, scrollOffset);
				for (int j = 0; j < array.Length; j++)
				{
					RRect rrect2 = array[j];
					rrect2.Offset(scrollOffset);
					this.PaintDecoration(g, rrect2, j == 0, j == array.Length - 1);
				}
				foreach (CssBox cssBox in this.Boxes)
				{
					if (CssBox.smethod_13(cssBox.Position, <Module>.smethod_24<string>(674185584U)))
					{
						cssBox.Paint(g);
					}
				}
				foreach (CssBox cssBox2 in this.Boxes)
				{
					if (CssBox.smethod_12(cssBox2.Position, <Module>.smethod_24<string>(674185584U)))
					{
						cssBox2.Paint(g);
					}
				}
				if (flag)
				{
					g.PopClip();
				}
				if (this._listItemBox != null)
				{
					this._listItemBox.Paint(g);
				}
			}
		}

		// Token: 0x06000678 RID: 1656 RVA: 0x00039A78 File Offset: 0x00037C78
		protected void PaintBackground(RGraphics g, RRect rect, bool isFirst, bool isLast)
		{
			if (rect.Width > 0.0 && rect.Height > 0.0)
			{
				RBrush rbrush = null;
				if (CssBox.smethod_13(base.BackgroundGradient, <Module>.smethod_27<string>(1876627641U)))
				{
					rbrush = g.GetLinearGradientBrush(rect, base.ActualBackgroundColor, base.ActualBackgroundGradient, base.ActualBackgroundGradientAngle);
				}
				else if (RenderUtils.IsColorVisible(base.ActualBackgroundColor))
				{
					rbrush = g.GetSolidBrush(base.ActualBackgroundColor);
				}
				if (rbrush != null)
				{
					RGraphicsPath rgraphicsPath = null;
					if (base.IsRounded)
					{
						rgraphicsPath = RenderUtils.GetRoundRect(g, rect, base.ActualCornerNw, base.ActualCornerNe, base.ActualCornerSe, base.ActualCornerSw);
					}
					object obj = null;
					if (this.HtmlContainer != null && !this.HtmlContainer.AvoidGeometryAntialias && base.IsRounded)
					{
						obj = g.SetAntiAliasSmoothingMode();
					}
					if (rgraphicsPath != null)
					{
						g.DrawPath(rbrush, rgraphicsPath);
					}
					else
					{
						g.DrawRectangle(rbrush, CssBox.smethod_19(rect.X), CssBox.smethod_19(rect.Y), rect.Width, rect.Height);
					}
					g.ReturnPreviousSmoothingMode(obj);
					if (rgraphicsPath != null)
					{
						rgraphicsPath.Dispose();
					}
					rbrush.Dispose();
				}
				if (this._imageLoadHandler != null && this._imageLoadHandler.Image != null && isFirst)
				{
					BackgroundImageDrawHandler.DrawBackgroundImage(g, this, this._imageLoadHandler, rect);
				}
			}
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x00039BCC File Offset: 0x00037DCC
		private void PaintWords(RGraphics g, RPoint offset)
		{
			if (CssBox.smethod_20(base.Width) > 0)
			{
				bool flag = CssBox.smethod_12(base.Direction, <Module>.smethod_24<string>(3519544261U));
				foreach (CssRect cssRect in this.Words)
				{
					if (!cssRect.IsLineBreak)
					{
						RPoint rpoint = new RPoint(cssRect.Left + offset.X, cssRect.Top + offset.Y);
						if (!cssRect.Selected)
						{
							g.DrawString(cssRect.Text, base.ActualFont, base.ActualColor, rpoint, new RSize(cssRect.Width, cssRect.Height), flag);
						}
						else
						{
							CssLineBox cssLineBoxByWord = DomUtils.GetCssLineBoxByWord(cssRect);
							double num;
							if (cssRect.SelectedStartOffset <= -1.0)
							{
								if (cssLineBoxByWord.Words[0] != cssRect)
								{
									if (cssRect.HasSpaceBefore)
									{
										num = -base.ActualWordSpacing;
										goto IL_00F4;
									}
								}
								num = 0.0;
							}
							else
							{
								num = cssRect.SelectedStartOffset;
							}
							IL_00F4:
							double num2 = num;
							bool flag2 = cssRect.HasSpaceAfter && !cssLineBoxByWord.IsLastSelectedWord(cssRect);
							double num3 = ((cssRect.SelectedEndOffset > -1.0) ? cssRect.SelectedEndOffset : (cssRect.Width + (flag2 ? base.ActualWordSpacing : 0.0)));
							RRect rrect = new RRect(cssRect.Left + offset.X + num2, cssRect.Top + offset.Y, num3 - num2, cssLineBoxByWord.LineHeight);
							g.DrawRectangle(this.GetSelectionBackBrush(g, false), rrect.X, rrect.Y, rrect.Width, rrect.Height);
							if (this.HtmlContainer.SelectionForeColor != RColor.Empty && (cssRect.SelectedStartOffset > 0.0 || cssRect.SelectedEndIndexOffset > -1))
							{
								g.PushClipExclude(rrect);
								g.DrawString(cssRect.Text, base.ActualFont, base.ActualColor, rpoint, new RSize(cssRect.Width, cssRect.Height), flag);
								g.PopClip();
								g.PushClip(rrect);
								g.DrawString(cssRect.Text, base.ActualFont, this.GetSelectionForeBrush(), rpoint, new RSize(cssRect.Width, cssRect.Height), flag);
								g.PopClip();
							}
							else
							{
								g.DrawString(cssRect.Text, base.ActualFont, this.GetSelectionForeBrush(), rpoint, new RSize(cssRect.Width, cssRect.Height), flag);
							}
						}
					}
				}
			}
		}

		// Token: 0x0600067A RID: 1658 RVA: 0x00039E88 File Offset: 0x00038088
		protected void PaintDecoration(RGraphics g, RRect rectangle, bool isFirst, bool isLast)
		{
			if (!CssBox.smethod_15(base.TextDecoration) && !CssBox.smethod_12(base.TextDecoration, <Module>.smethod_23<string>(436056481U)))
			{
				double num = 0.0;
				if (CssBox.smethod_12(base.TextDecoration, <Module>.smethod_27<string>(1538732710U)))
				{
					num = CssBox.smethod_21(rectangle.Top + base.ActualFont.UnderlineOffset);
				}
				else if (!CssBox.smethod_12(base.TextDecoration, <Module>.smethod_24<string>(37536587U)))
				{
					if (CssBox.smethod_12(base.TextDecoration, <Module>.smethod_25<string>(2792551125U)))
					{
						num = rectangle.Top;
					}
				}
				else
				{
					num = rectangle.Top + rectangle.Height / 2.0;
				}
				num -= base.ActualPaddingBottom - base.ActualBorderBottomWidth;
				double num2 = rectangle.X;
				if (isFirst)
				{
					num2 += base.ActualPaddingLeft + base.ActualBorderLeftWidth;
				}
				double num3 = rectangle.Right;
				if (isLast)
				{
					num3 -= base.ActualPaddingRight + base.ActualBorderRightWidth;
				}
				RPen pen = g.GetPen(base.ActualColor);
				pen.Width = 1.0;
				pen.DashStyle = RDashStyle.Solid;
				g.DrawLine(pen, num2, num, num3, num);
				return;
			}
		}

		// Token: 0x0600067B RID: 1659 RVA: 0x00039FC4 File Offset: 0x000381C4
		internal void OffsetRectangle(CssLineBox lineBox, double gap)
		{
			if (this.Rectangles.ContainsKey(lineBox))
			{
				RRect rrect = this.Rectangles[lineBox];
				this.Rectangles[lineBox] = new RRect(rrect.X, rrect.Y + gap, rrect.Width, rrect.Height);
			}
		}

		// Token: 0x0600067C RID: 1660 RVA: 0x0000ECF6 File Offset: 0x0000CEF6
		internal void RectanglesReset()
		{
			this._rectangles.Clear();
		}

		// Token: 0x0600067D RID: 1661 RVA: 0x0000ED03 File Offset: 0x0000CF03
		private void OnImageLoadComplete(RImage image, RRect rectangle, bool async)
		{
			if (image != null && async)
			{
				this.HtmlContainer.RequestRefresh(false);
			}
		}

		// Token: 0x0600067E RID: 1662 RVA: 0x0000ED17 File Offset: 0x0000CF17
		protected RColor GetSelectionForeBrush()
		{
			if (!(this.HtmlContainer.SelectionForeColor != RColor.Empty))
			{
				return base.ActualColor;
			}
			return this.HtmlContainer.SelectionForeColor;
		}

		// Token: 0x0600067F RID: 1663 RVA: 0x0003A01C File Offset: 0x0003821C
		protected RBrush GetSelectionBackBrush(RGraphics g, bool forceAlpha)
		{
			RColor selectionBackColor = this.HtmlContainer.SelectionBackColor;
			if (!(selectionBackColor != RColor.Empty))
			{
				return g.GetSolidBrush(CssUtils.DefaultSelectionBackcolor);
			}
			if (forceAlpha && selectionBackColor.A > 180)
			{
				return g.GetSolidBrush(RColor.FromArgb(180, (int)selectionBackColor.R, (int)selectionBackColor.G, (int)selectionBackColor.B));
			}
			return g.GetSolidBrush(selectionBackColor);
		}

		// Token: 0x06000680 RID: 1664 RVA: 0x0000ED42 File Offset: 0x0000CF42
		protected override RFont GetCachedFont(string fontFamily, double fsize, RFontStyle st)
		{
			return this.HtmlContainer.Adapter.GetFont(fontFamily, fsize, st);
		}

		// Token: 0x06000681 RID: 1665 RVA: 0x0000ED57 File Offset: 0x0000CF57
		protected override RColor GetActualColor(string colorStr)
		{
			return this.HtmlContainer.CssParser.ParseColor(colorStr);
		}

		// Token: 0x06000682 RID: 1666 RVA: 0x0003A08C File Offset: 0x0003828C
		public override string ToString()
		{
			string text = ((this.HtmlTag != null) ? CssBox.smethod_22(<Module>.smethod_23<string>(2492039755U), this.HtmlTag.Name) : <Module>.smethod_27<string>(559677157U));
			if (this.IsBlock)
			{
				return CssBox.smethod_23(<Module>.smethod_25<string>(3349330749U), new object[]
				{
					(this.ParentBox == null) ? <Module>.smethod_24<string>(1364693142U) : string.Empty,
					text,
					base.FontSize,
					this.Boxes.Count
				});
			}
			if (CssBox.smethod_12(base.Display, <Module>.smethod_23<string>(436056481U)))
			{
				return CssBox.smethod_24(<Module>.smethod_25<string>(127773121U), (this.ParentBox == null) ? <Module>.smethod_25<string>(336565480U) : string.Empty, text);
			}
			return CssBox.smethod_23(<Module>.smethod_23<string>(1893380374U), new object[]
			{
				(this.ParentBox == null) ? <Module>.smethod_24<string>(1364693142U) : string.Empty,
				text,
				base.Display,
				this.Text
			});
		}

		// Token: 0x06000683 RID: 1667 RVA: 0x0000D0A2 File Offset: 0x0000B2A2
		static bool smethod_11(string string_0, string string_1, StringComparison stringComparison_0)
		{
			return string_0.Equals(string_1, stringComparison_0);
		}

		// Token: 0x06000684 RID: 1668 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_12(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06000685 RID: 1669 RVA: 0x0000CDA1 File Offset: 0x0000AFA1
		static bool smethod_13(string string_0, string string_1)
		{
			return string_0 != string_1;
		}

		// Token: 0x06000686 RID: 1670 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_14(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x06000687 RID: 1671 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_15(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06000688 RID: 1672 RVA: 0x0000ED6A File Offset: 0x0000CF6A
		static double smethod_16(double double_0, double double_1)
		{
			return Math.Max(double_0, double_1);
		}

		// Token: 0x06000689 RID: 1673 RVA: 0x0000ED73 File Offset: 0x0000CF73
		static bool smethod_17(object object_0, object object_1)
		{
			return object_0.Equals(object_1);
		}

		// Token: 0x0600068A RID: 1674 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_18()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x0600068B RID: 1675 RVA: 0x0000ED7C File Offset: 0x0000CF7C
		static double smethod_19(double double_0)
		{
			return Math.Ceiling(double_0);
		}

		// Token: 0x0600068C RID: 1676 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_20(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x0600068D RID: 1677 RVA: 0x0000ED84 File Offset: 0x0000CF84
		static double smethod_21(double double_0)
		{
			return Math.Round(double_0);
		}

		// Token: 0x0600068E RID: 1678 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_22(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x0000CD33 File Offset: 0x0000AF33
		static string smethod_23(string string_0, object[] object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x06000690 RID: 1680 RVA: 0x0000C80C File Offset: 0x0000AA0C
		static string smethod_24(string string_0, object object_0, object object_1)
		{
			return string.Format(string_0, object_0, object_1);
		}

		// Token: 0x04000260 RID: 608
		private CssBox _parentBox;

		// Token: 0x04000261 RID: 609
		protected HtmlContainerInt _htmlContainer;

		// Token: 0x04000262 RID: 610
		private readonly HtmlTag _htmltag;

		// Token: 0x04000263 RID: 611
		private readonly List<CssRect> _boxWords = new List<CssRect>();

		// Token: 0x04000264 RID: 612
		private readonly List<CssBox> _boxes = new List<CssBox>();

		// Token: 0x04000265 RID: 613
		private readonly List<CssLineBox> _lineBoxes = new List<CssLineBox>();

		// Token: 0x04000266 RID: 614
		private readonly List<CssLineBox> _parentLineBoxes = new List<CssLineBox>();

		// Token: 0x04000267 RID: 615
		private readonly Dictionary<CssLineBox, RRect> _rectangles = new Dictionary<CssLineBox, RRect>();

		// Token: 0x04000268 RID: 616
		private SubString _text;

		// Token: 0x04000269 RID: 617
		internal bool _tableFixed;

		// Token: 0x0400026A RID: 618
		protected bool _wordsSizeMeasured;

		// Token: 0x0400026B RID: 619
		private CssBox _listItemBox;

		// Token: 0x0400026C RID: 620
		private CssLineBox _firstHostingLineBox;

		// Token: 0x0400026D RID: 621
		private CssLineBox _lastHostingLineBox;

		// Token: 0x0400026E RID: 622
		private ImageLoadHandler _imageLoadHandler;
	}
}
