﻿using System;
using System.Collections.Generic;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x02000085 RID: 133
	internal sealed class CssSpacingBox : CssBox
	{
		// Token: 0x06000779 RID: 1913 RVA: 0x0003F94C File Offset: 0x0003DB4C
		public CssSpacingBox(CssBox tableBox, ref CssBox extendedBox, int startRow)
			: base(tableBox, new HtmlTag(<Module>.smethod_27<string>(1876627641U), false, new Dictionary<string, string> { 
			{
				<Module>.smethod_26<string>(2541271771U),
				<Module>.smethod_23<string>(1469188620U)
			} }))
		{
			this._extendedBox = extendedBox;
			base.Display = <Module>.smethod_24<string>(3284293868U);
			this._startRow = startRow;
			this._endRow = startRow + int.Parse(extendedBox.GetAttribute(<Module>.smethod_25<string>(3626391937U), <Module>.smethod_26<string>(609256988U))) - 1;
		}

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x0600077A RID: 1914 RVA: 0x0000F2EA File Offset: 0x0000D4EA
		public CssBox ExtendedBox
		{
			get
			{
				return this._extendedBox;
			}
		}

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x0600077B RID: 1915 RVA: 0x0000F2F2 File Offset: 0x0000D4F2
		public int StartRow
		{
			get
			{
				return this._startRow;
			}
		}

		// Token: 0x17000137 RID: 311
		// (get) Token: 0x0600077C RID: 1916 RVA: 0x0000F2FA File Offset: 0x0000D4FA
		public int EndRow
		{
			get
			{
				return this._endRow;
			}
		}

		// Token: 0x0400029A RID: 666
		private readonly CssBox _extendedBox;

		// Token: 0x0400029B RID: 667
		private readonly int _startRow;

		// Token: 0x0400029C RID: 668
		private readonly int _endRow;
	}
}
