﻿using System;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Handlers;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x02000082 RID: 130
	internal abstract class CssRect
	{
		// Token: 0x0600073E RID: 1854 RVA: 0x0000F0E7 File Offset: 0x0000D2E7
		protected CssRect(CssBox owner)
		{
			this._ownerBox = owner;
		}

		// Token: 0x17000115 RID: 277
		// (get) Token: 0x0600073F RID: 1855 RVA: 0x0000F0F6 File Offset: 0x0000D2F6
		public CssBox OwnerBox
		{
			get
			{
				return this._ownerBox;
			}
		}

		// Token: 0x17000116 RID: 278
		// (get) Token: 0x06000740 RID: 1856 RVA: 0x0000F0FE File Offset: 0x0000D2FE
		// (set) Token: 0x06000741 RID: 1857 RVA: 0x0000F106 File Offset: 0x0000D306
		public RRect Rectangle
		{
			get
			{
				return this._rect;
			}
			set
			{
				this._rect = value;
			}
		}

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x06000742 RID: 1858 RVA: 0x0000F10F File Offset: 0x0000D30F
		// (set) Token: 0x06000743 RID: 1859 RVA: 0x0000F11C File Offset: 0x0000D31C
		public double Left
		{
			get
			{
				return this._rect.X;
			}
			set
			{
				this._rect.X = value;
			}
		}

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x06000744 RID: 1860 RVA: 0x0000F12A File Offset: 0x0000D32A
		// (set) Token: 0x06000745 RID: 1861 RVA: 0x0000F137 File Offset: 0x0000D337
		public double Top
		{
			get
			{
				return this._rect.Y;
			}
			set
			{
				this._rect.Y = value;
			}
		}

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x06000746 RID: 1862 RVA: 0x0000F145 File Offset: 0x0000D345
		// (set) Token: 0x06000747 RID: 1863 RVA: 0x0000F152 File Offset: 0x0000D352
		public double Width
		{
			get
			{
				return this._rect.Width;
			}
			set
			{
				this._rect.Width = value;
			}
		}

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x06000748 RID: 1864 RVA: 0x0000F160 File Offset: 0x0000D360
		public double FullWidth
		{
			get
			{
				return this._rect.Width + this.ActualWordSpacing;
			}
		}

		// Token: 0x1700011B RID: 283
		// (get) Token: 0x06000749 RID: 1865 RVA: 0x0003F748 File Offset: 0x0003D948
		public double ActualWordSpacing
		{
			get
			{
				if (this.OwnerBox == null)
				{
					return 0.0;
				}
				return (this.HasSpaceAfter ? this.OwnerBox.ActualWordSpacing : 0.0) + (this.IsImage ? this.OwnerBox.ActualWordSpacing : 0.0);
			}
		}

		// Token: 0x1700011C RID: 284
		// (get) Token: 0x0600074A RID: 1866 RVA: 0x0000F174 File Offset: 0x0000D374
		// (set) Token: 0x0600074B RID: 1867 RVA: 0x0000F181 File Offset: 0x0000D381
		public double Height
		{
			get
			{
				return this._rect.Height;
			}
			set
			{
				this._rect.Height = value;
			}
		}

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x0600074C RID: 1868 RVA: 0x0003F7A4 File Offset: 0x0003D9A4
		// (set) Token: 0x0600074D RID: 1869 RVA: 0x0000F18F File Offset: 0x0000D38F
		public double Right
		{
			get
			{
				return this.Rectangle.Right;
			}
			set
			{
				this.Width = value - this.Left;
			}
		}

		// Token: 0x1700011E RID: 286
		// (get) Token: 0x0600074E RID: 1870 RVA: 0x0003F7C0 File Offset: 0x0003D9C0
		// (set) Token: 0x0600074F RID: 1871 RVA: 0x0000F19F File Offset: 0x0000D39F
		public double Bottom
		{
			get
			{
				return this.Rectangle.Bottom;
			}
			set
			{
				this.Height = value - this.Top;
			}
		}

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x06000750 RID: 1872 RVA: 0x0000F1AF File Offset: 0x0000D3AF
		// (set) Token: 0x06000751 RID: 1873 RVA: 0x0000F1B7 File Offset: 0x0000D3B7
		public SelectionHandler Selection
		{
			get
			{
				return this._selection;
			}
			set
			{
				this._selection = value;
			}
		}

		// Token: 0x17000120 RID: 288
		// (get) Token: 0x06000752 RID: 1874 RVA: 0x0000C17A File Offset: 0x0000A37A
		public virtual bool HasSpaceBefore
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000121 RID: 289
		// (get) Token: 0x06000753 RID: 1875 RVA: 0x0000C17A File Offset: 0x0000A37A
		public virtual bool HasSpaceAfter
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x06000754 RID: 1876 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		// (set) Token: 0x06000755 RID: 1877 RVA: 0x0000C600 File Offset: 0x0000A800
		public virtual RImage Image
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		// Token: 0x17000123 RID: 291
		// (get) Token: 0x06000756 RID: 1878 RVA: 0x0000C17A File Offset: 0x0000A37A
		public virtual bool IsImage
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x06000757 RID: 1879 RVA: 0x0000ED8C File Offset: 0x0000CF8C
		public virtual bool IsSpaces
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x06000758 RID: 1880 RVA: 0x0000C17A File Offset: 0x0000A37A
		public virtual bool IsLineBreak
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000126 RID: 294
		// (get) Token: 0x06000759 RID: 1881 RVA: 0x0000F1C0 File Offset: 0x0000D3C0
		public virtual string Text
		{
			get
			{
				return null;
			}
		}

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x0600075A RID: 1882 RVA: 0x0000F1C3 File Offset: 0x0000D3C3
		public bool Selected
		{
			get
			{
				return this._selection != null;
			}
		}

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x0600075B RID: 1883 RVA: 0x0000F1D1 File Offset: 0x0000D3D1
		public int SelectedStartIndex
		{
			get
			{
				if (this._selection == null)
				{
					return -1;
				}
				return this._selection.GetSelectingStartIndex(this);
			}
		}

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x0600075C RID: 1884 RVA: 0x0000F1E9 File Offset: 0x0000D3E9
		public int SelectedEndIndexOffset
		{
			get
			{
				if (this._selection == null)
				{
					return -1;
				}
				return this._selection.GetSelectedEndIndexOffset(this);
			}
		}

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x0600075D RID: 1885 RVA: 0x0000F201 File Offset: 0x0000D401
		public double SelectedStartOffset
		{
			get
			{
				if (this._selection == null)
				{
					return -1.0;
				}
				return this._selection.GetSelectedStartOffset(this);
			}
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x0600075E RID: 1886 RVA: 0x0000F221 File Offset: 0x0000D421
		public double SelectedEndOffset
		{
			get
			{
				if (this._selection == null)
				{
					return -1.0;
				}
				return this._selection.GetSelectedEndOffset(this);
			}
		}

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x0600075F RID: 1887 RVA: 0x0000F241 File Offset: 0x0000D441
		internal double LeftGlyphPadding
		{
			get
			{
				if (this.OwnerBox == null)
				{
					return 0.0;
				}
				return this.OwnerBox.ActualFont.LeftPadding;
			}
		}

		// Token: 0x06000760 RID: 1888 RVA: 0x0003F7DC File Offset: 0x0003D9DC
		public override string ToString()
		{
			return CssRect.smethod_3(<Module>.smethod_25<string>(3228882009U), CssRect.smethod_1(CssRect.smethod_0(this.Text, ' ', '-'), <Module>.smethod_23<string>(287085070U), <Module>.smethod_24<string>(2260981209U)), CssRect.smethod_2(this.Text), (CssRect.smethod_2(this.Text) != 1) ? <Module>.smethod_25<string>(3467122241U) : string.Empty);
		}

		// Token: 0x06000761 RID: 1889 RVA: 0x0000CD69 File Offset: 0x0000AF69
		static string smethod_0(string string_0, char char_0, char char_1)
		{
			return string_0.Replace(char_0, char_1);
		}

		// Token: 0x06000762 RID: 1890 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_1(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x06000763 RID: 1891 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_2(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06000764 RID: 1892 RVA: 0x0000CD96 File Offset: 0x0000AF96
		static string smethod_3(string string_0, object object_0, object object_1, object object_2)
		{
			return string.Format(string_0, object_0, object_1, object_2);
		}

		// Token: 0x04000292 RID: 658
		private readonly CssBox _ownerBox;

		// Token: 0x04000293 RID: 659
		private RRect _rect;

		// Token: 0x04000294 RID: 660
		private SelectionHandler _selection;
	}
}
