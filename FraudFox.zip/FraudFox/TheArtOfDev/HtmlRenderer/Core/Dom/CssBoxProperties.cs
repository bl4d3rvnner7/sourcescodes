﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Parse;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x02000077 RID: 119
	internal abstract class CssBoxProperties
	{
		// Token: 0x17000084 RID: 132
		// (get) Token: 0x0600057A RID: 1402 RVA: 0x0000E31C File Offset: 0x0000C51C
		// (set) Token: 0x0600057B RID: 1403 RVA: 0x0000E324 File Offset: 0x0000C524
		public string BorderBottomWidth
		{
			get
			{
				return this._borderBottomWidth;
			}
			set
			{
				this._borderBottomWidth = value;
				this._actualBorderBottomWidth = double.NaN;
			}
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x0600057C RID: 1404 RVA: 0x0000E33C File Offset: 0x0000C53C
		// (set) Token: 0x0600057D RID: 1405 RVA: 0x0000E344 File Offset: 0x0000C544
		public string BorderLeftWidth
		{
			get
			{
				return this._borderLeftWidth;
			}
			set
			{
				this._borderLeftWidth = value;
				this._actualBorderLeftWidth = double.NaN;
			}
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x0600057E RID: 1406 RVA: 0x0000E35C File Offset: 0x0000C55C
		// (set) Token: 0x0600057F RID: 1407 RVA: 0x0000E364 File Offset: 0x0000C564
		public string BorderRightWidth
		{
			get
			{
				return this._borderRightWidth;
			}
			set
			{
				this._borderRightWidth = value;
				this._actualBorderRightWidth = double.NaN;
			}
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x06000580 RID: 1408 RVA: 0x0000E37C File Offset: 0x0000C57C
		// (set) Token: 0x06000581 RID: 1409 RVA: 0x0000E384 File Offset: 0x0000C584
		public string BorderTopWidth
		{
			get
			{
				return this._borderTopWidth;
			}
			set
			{
				this._borderTopWidth = value;
				this._actualBorderTopWidth = double.NaN;
			}
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x06000582 RID: 1410 RVA: 0x0000E39C File Offset: 0x0000C59C
		// (set) Token: 0x06000583 RID: 1411 RVA: 0x0000E3A4 File Offset: 0x0000C5A4
		public string BorderBottomStyle
		{
			get
			{
				return this._borderBottomStyle;
			}
			set
			{
				this._borderBottomStyle = value;
			}
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x06000584 RID: 1412 RVA: 0x0000E3AD File Offset: 0x0000C5AD
		// (set) Token: 0x06000585 RID: 1413 RVA: 0x0000E3B5 File Offset: 0x0000C5B5
		public string BorderLeftStyle
		{
			get
			{
				return this._borderLeftStyle;
			}
			set
			{
				this._borderLeftStyle = value;
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x06000586 RID: 1414 RVA: 0x0000E3BE File Offset: 0x0000C5BE
		// (set) Token: 0x06000587 RID: 1415 RVA: 0x0000E3C6 File Offset: 0x0000C5C6
		public string BorderRightStyle
		{
			get
			{
				return this._borderRightStyle;
			}
			set
			{
				this._borderRightStyle = value;
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06000588 RID: 1416 RVA: 0x0000E3CF File Offset: 0x0000C5CF
		// (set) Token: 0x06000589 RID: 1417 RVA: 0x0000E3D7 File Offset: 0x0000C5D7
		public string BorderTopStyle
		{
			get
			{
				return this._borderTopStyle;
			}
			set
			{
				this._borderTopStyle = value;
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x0600058A RID: 1418 RVA: 0x0000E3E0 File Offset: 0x0000C5E0
		// (set) Token: 0x0600058B RID: 1419 RVA: 0x0000E3E8 File Offset: 0x0000C5E8
		public string BorderBottomColor
		{
			get
			{
				return this._borderBottomColor;
			}
			set
			{
				this._borderBottomColor = value;
				this._actualBorderBottomColor = RColor.Empty;
			}
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x0600058C RID: 1420 RVA: 0x0000E3FC File Offset: 0x0000C5FC
		// (set) Token: 0x0600058D RID: 1421 RVA: 0x0000E404 File Offset: 0x0000C604
		public string BorderLeftColor
		{
			get
			{
				return this._borderLeftColor;
			}
			set
			{
				this._borderLeftColor = value;
				this._actualBorderLeftColor = RColor.Empty;
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x0600058E RID: 1422 RVA: 0x0000E418 File Offset: 0x0000C618
		// (set) Token: 0x0600058F RID: 1423 RVA: 0x0000E420 File Offset: 0x0000C620
		public string BorderRightColor
		{
			get
			{
				return this._borderRightColor;
			}
			set
			{
				this._borderRightColor = value;
				this._actualBorderRightColor = RColor.Empty;
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x06000590 RID: 1424 RVA: 0x0000E434 File Offset: 0x0000C634
		// (set) Token: 0x06000591 RID: 1425 RVA: 0x0000E43C File Offset: 0x0000C63C
		public string BorderTopColor
		{
			get
			{
				return this._borderTopColor;
			}
			set
			{
				this._borderTopColor = value;
				this._actualBorderTopColor = RColor.Empty;
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x06000592 RID: 1426 RVA: 0x0000E450 File Offset: 0x0000C650
		// (set) Token: 0x06000593 RID: 1427 RVA: 0x0000E458 File Offset: 0x0000C658
		public string BorderSpacing
		{
			get
			{
				return this._borderSpacing;
			}
			set
			{
				this._borderSpacing = value;
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x06000594 RID: 1428 RVA: 0x0000E461 File Offset: 0x0000C661
		// (set) Token: 0x06000595 RID: 1429 RVA: 0x0000E469 File Offset: 0x0000C669
		public string BorderCollapse
		{
			get
			{
				return this._borderCollapse;
			}
			set
			{
				this._borderCollapse = value;
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06000596 RID: 1430 RVA: 0x0000E472 File Offset: 0x0000C672
		// (set) Token: 0x06000597 RID: 1431 RVA: 0x000364C8 File Offset: 0x000346C8
		public string CornerRadius
		{
			get
			{
				return this._cornerRadius;
			}
			set
			{
				MatchCollection matchCollection = RegexParserUtils.Match(<Module>.smethod_23<string>(3085558634U), value);
				switch (CssBoxProperties.smethod_0(matchCollection))
				{
				case 1:
					this.CornerNeRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 0));
					this.CornerNwRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 0));
					this.CornerSeRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 0));
					this.CornerSwRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 0));
					break;
				case 2:
					this.CornerNeRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 0));
					this.CornerNwRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 0));
					this.CornerSeRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 1));
					this.CornerSwRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 1));
					break;
				case 3:
					this.CornerNeRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 0));
					this.CornerNwRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 1));
					this.CornerSeRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 2));
					break;
				case 4:
					this.CornerNeRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 0));
					this.CornerNwRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 1));
					this.CornerSeRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 2));
					this.CornerSwRadius = CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 3));
					break;
				}
				this._cornerRadius = value;
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06000598 RID: 1432 RVA: 0x0000E47A File Offset: 0x0000C67A
		// (set) Token: 0x06000599 RID: 1433 RVA: 0x0000E482 File Offset: 0x0000C682
		public string CornerNwRadius
		{
			get
			{
				return this._cornerNwRadius;
			}
			set
			{
				this._cornerNwRadius = value;
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x0600059A RID: 1434 RVA: 0x0000E48B File Offset: 0x0000C68B
		// (set) Token: 0x0600059B RID: 1435 RVA: 0x0000E493 File Offset: 0x0000C693
		public string CornerNeRadius
		{
			get
			{
				return this._cornerNeRadius;
			}
			set
			{
				this._cornerNeRadius = value;
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x0600059C RID: 1436 RVA: 0x0000E49C File Offset: 0x0000C69C
		// (set) Token: 0x0600059D RID: 1437 RVA: 0x0000E4A4 File Offset: 0x0000C6A4
		public string CornerSeRadius
		{
			get
			{
				return this._cornerSeRadius;
			}
			set
			{
				this._cornerSeRadius = value;
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x0600059E RID: 1438 RVA: 0x0000E4AD File Offset: 0x0000C6AD
		// (set) Token: 0x0600059F RID: 1439 RVA: 0x0000E4B5 File Offset: 0x0000C6B5
		public string CornerSwRadius
		{
			get
			{
				return this._cornerSwRadius;
			}
			set
			{
				this._cornerSwRadius = value;
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x060005A0 RID: 1440 RVA: 0x0000E4BE File Offset: 0x0000C6BE
		// (set) Token: 0x060005A1 RID: 1441 RVA: 0x0000E4C6 File Offset: 0x0000C6C6
		public string MarginBottom
		{
			get
			{
				return this._marginBottom;
			}
			set
			{
				this._marginBottom = value;
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x060005A2 RID: 1442 RVA: 0x0000E4CF File Offset: 0x0000C6CF
		// (set) Token: 0x060005A3 RID: 1443 RVA: 0x0000E4D7 File Offset: 0x0000C6D7
		public string MarginLeft
		{
			get
			{
				return this._marginLeft;
			}
			set
			{
				this._marginLeft = value;
			}
		}

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x060005A4 RID: 1444 RVA: 0x0000E4E0 File Offset: 0x0000C6E0
		// (set) Token: 0x060005A5 RID: 1445 RVA: 0x0000E4E8 File Offset: 0x0000C6E8
		public string MarginRight
		{
			get
			{
				return this._marginRight;
			}
			set
			{
				this._marginRight = value;
			}
		}

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x060005A6 RID: 1446 RVA: 0x0000E4F1 File Offset: 0x0000C6F1
		// (set) Token: 0x060005A7 RID: 1447 RVA: 0x0000E4F9 File Offset: 0x0000C6F9
		public string MarginTop
		{
			get
			{
				return this._marginTop;
			}
			set
			{
				this._marginTop = value;
			}
		}

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x060005A8 RID: 1448 RVA: 0x0000E502 File Offset: 0x0000C702
		// (set) Token: 0x060005A9 RID: 1449 RVA: 0x0000E50A File Offset: 0x0000C70A
		public string PaddingBottom
		{
			get
			{
				return this._paddingBottom;
			}
			set
			{
				this._paddingBottom = value;
				this._actualPaddingBottom = double.NaN;
			}
		}

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x060005AA RID: 1450 RVA: 0x0000E522 File Offset: 0x0000C722
		// (set) Token: 0x060005AB RID: 1451 RVA: 0x0000E52A File Offset: 0x0000C72A
		public string PaddingLeft
		{
			get
			{
				return this._paddingLeft;
			}
			set
			{
				this._paddingLeft = value;
				this._actualPaddingLeft = double.NaN;
			}
		}

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x060005AC RID: 1452 RVA: 0x0000E542 File Offset: 0x0000C742
		// (set) Token: 0x060005AD RID: 1453 RVA: 0x0000E54A File Offset: 0x0000C74A
		public string PaddingRight
		{
			get
			{
				return this._paddingRight;
			}
			set
			{
				this._paddingRight = value;
				this._actualPaddingRight = double.NaN;
			}
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x060005AE RID: 1454 RVA: 0x0000E562 File Offset: 0x0000C762
		// (set) Token: 0x060005AF RID: 1455 RVA: 0x0000E56A File Offset: 0x0000C76A
		public string PaddingTop
		{
			get
			{
				return this._paddingTop;
			}
			set
			{
				this._paddingTop = value;
				this._actualPaddingTop = double.NaN;
			}
		}

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x060005B0 RID: 1456 RVA: 0x0000E582 File Offset: 0x0000C782
		// (set) Token: 0x060005B1 RID: 1457 RVA: 0x0000E58A File Offset: 0x0000C78A
		public string Left
		{
			get
			{
				return this._left;
			}
			set
			{
				this._left = value;
			}
		}

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x060005B2 RID: 1458 RVA: 0x0000E593 File Offset: 0x0000C793
		// (set) Token: 0x060005B3 RID: 1459 RVA: 0x0000E59B File Offset: 0x0000C79B
		public string Top
		{
			get
			{
				return this._top;
			}
			set
			{
				this._top = value;
			}
		}

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x060005B4 RID: 1460 RVA: 0x0000E5A4 File Offset: 0x0000C7A4
		// (set) Token: 0x060005B5 RID: 1461 RVA: 0x0000E5AC File Offset: 0x0000C7AC
		public string Width
		{
			get
			{
				return this._width;
			}
			set
			{
				this._width = value;
			}
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x060005B6 RID: 1462 RVA: 0x0000E5B5 File Offset: 0x0000C7B5
		// (set) Token: 0x060005B7 RID: 1463 RVA: 0x0000E5BD File Offset: 0x0000C7BD
		public string MaxWidth
		{
			get
			{
				return this._maxWidth;
			}
			set
			{
				this._maxWidth = value;
			}
		}

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x060005B8 RID: 1464 RVA: 0x0000E5C6 File Offset: 0x0000C7C6
		// (set) Token: 0x060005B9 RID: 1465 RVA: 0x0000E5CE File Offset: 0x0000C7CE
		public string Height
		{
			get
			{
				return this._height;
			}
			set
			{
				this._height = value;
			}
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x060005BA RID: 1466 RVA: 0x0000E5D7 File Offset: 0x0000C7D7
		// (set) Token: 0x060005BB RID: 1467 RVA: 0x0000E5DF File Offset: 0x0000C7DF
		public string BackgroundColor
		{
			get
			{
				return this._backgroundColor;
			}
			set
			{
				this._backgroundColor = value;
			}
		}

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x060005BC RID: 1468 RVA: 0x0000E5E8 File Offset: 0x0000C7E8
		// (set) Token: 0x060005BD RID: 1469 RVA: 0x0000E5F0 File Offset: 0x0000C7F0
		public string BackgroundImage
		{
			get
			{
				return this._backgroundImage;
			}
			set
			{
				this._backgroundImage = value;
			}
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x060005BE RID: 1470 RVA: 0x0000E5F9 File Offset: 0x0000C7F9
		// (set) Token: 0x060005BF RID: 1471 RVA: 0x0000E601 File Offset: 0x0000C801
		public string BackgroundPosition
		{
			get
			{
				return this._backgroundPosition;
			}
			set
			{
				this._backgroundPosition = value;
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x060005C0 RID: 1472 RVA: 0x0000E60A File Offset: 0x0000C80A
		// (set) Token: 0x060005C1 RID: 1473 RVA: 0x0000E612 File Offset: 0x0000C812
		public string BackgroundRepeat
		{
			get
			{
				return this._backgroundRepeat;
			}
			set
			{
				this._backgroundRepeat = value;
			}
		}

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x060005C2 RID: 1474 RVA: 0x0000E61B File Offset: 0x0000C81B
		// (set) Token: 0x060005C3 RID: 1475 RVA: 0x0000E623 File Offset: 0x0000C823
		public string BackgroundGradient
		{
			get
			{
				return this._backgroundGradient;
			}
			set
			{
				this._backgroundGradient = value;
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x060005C4 RID: 1476 RVA: 0x0000E62C File Offset: 0x0000C82C
		// (set) Token: 0x060005C5 RID: 1477 RVA: 0x0000E634 File Offset: 0x0000C834
		public string BackgroundGradientAngle
		{
			get
			{
				return this._backgroundGradientAngle;
			}
			set
			{
				this._backgroundGradientAngle = value;
			}
		}

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x060005C6 RID: 1478 RVA: 0x0000E63D File Offset: 0x0000C83D
		// (set) Token: 0x060005C7 RID: 1479 RVA: 0x0000E645 File Offset: 0x0000C845
		public string Color
		{
			get
			{
				return this._color;
			}
			set
			{
				this._color = value;
				this._actualColor = RColor.Empty;
			}
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x060005C8 RID: 1480 RVA: 0x0000E659 File Offset: 0x0000C859
		// (set) Token: 0x060005C9 RID: 1481 RVA: 0x0000E661 File Offset: 0x0000C861
		public string Display
		{
			get
			{
				return this._display;
			}
			set
			{
				this._display = value;
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x060005CA RID: 1482 RVA: 0x0000E66A File Offset: 0x0000C86A
		// (set) Token: 0x060005CB RID: 1483 RVA: 0x0000E672 File Offset: 0x0000C872
		public string Direction
		{
			get
			{
				return this._direction;
			}
			set
			{
				this._direction = value;
			}
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x060005CC RID: 1484 RVA: 0x0000E67B File Offset: 0x0000C87B
		// (set) Token: 0x060005CD RID: 1485 RVA: 0x0000E683 File Offset: 0x0000C883
		public string EmptyCells
		{
			get
			{
				return this._emptyCells;
			}
			set
			{
				this._emptyCells = value;
			}
		}

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x060005CE RID: 1486 RVA: 0x0000E68C File Offset: 0x0000C88C
		// (set) Token: 0x060005CF RID: 1487 RVA: 0x0000E694 File Offset: 0x0000C894
		public string Float
		{
			get
			{
				return this._float;
			}
			set
			{
				this._float = value;
			}
		}

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x060005D0 RID: 1488 RVA: 0x0000E69D File Offset: 0x0000C89D
		// (set) Token: 0x060005D1 RID: 1489 RVA: 0x0000E6A5 File Offset: 0x0000C8A5
		public string Position
		{
			get
			{
				return this._position;
			}
			set
			{
				this._position = value;
			}
		}

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x060005D2 RID: 1490 RVA: 0x0000E6AE File Offset: 0x0000C8AE
		// (set) Token: 0x060005D3 RID: 1491 RVA: 0x0003662C File Offset: 0x0003482C
		public string LineHeight
		{
			get
			{
				return this._lineHeight;
			}
			set
			{
				this._lineHeight = CssBoxProperties.smethod_4(CssBoxProperties.smethod_3(), <Module>.smethod_27<string>(2156357799U), new object[] { CssValueParser.ParseLength(value, this.Size.Height, this, <Module>.smethod_24<string>(3230435307U)) });
			}
		}

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x060005D4 RID: 1492 RVA: 0x0000E6B6 File Offset: 0x0000C8B6
		// (set) Token: 0x060005D5 RID: 1493 RVA: 0x0000E6BE File Offset: 0x0000C8BE
		public string VerticalAlign
		{
			get
			{
				return this._verticalAlign;
			}
			set
			{
				this._verticalAlign = value;
			}
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x060005D6 RID: 1494 RVA: 0x0000E6C7 File Offset: 0x0000C8C7
		// (set) Token: 0x060005D7 RID: 1495 RVA: 0x0000E6CF File Offset: 0x0000C8CF
		public string TextIndent
		{
			get
			{
				return this._textIndent;
			}
			set
			{
				this._textIndent = this.NoEms(value);
			}
		}

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x060005D8 RID: 1496 RVA: 0x0000E6DE File Offset: 0x0000C8DE
		// (set) Token: 0x060005D9 RID: 1497 RVA: 0x0000E6E6 File Offset: 0x0000C8E6
		public string TextAlign
		{
			get
			{
				return this._textAlign;
			}
			set
			{
				this._textAlign = value;
			}
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x060005DA RID: 1498 RVA: 0x0000E6EF File Offset: 0x0000C8EF
		// (set) Token: 0x060005DB RID: 1499 RVA: 0x0000E6F7 File Offset: 0x0000C8F7
		public string TextDecoration
		{
			get
			{
				return this._textDecoration;
			}
			set
			{
				this._textDecoration = value;
			}
		}

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x060005DC RID: 1500 RVA: 0x0000E700 File Offset: 0x0000C900
		// (set) Token: 0x060005DD RID: 1501 RVA: 0x0000E708 File Offset: 0x0000C908
		public string WhiteSpace
		{
			get
			{
				return this._whiteSpace;
			}
			set
			{
				this._whiteSpace = value;
			}
		}

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x060005DE RID: 1502 RVA: 0x0000E711 File Offset: 0x0000C911
		// (set) Token: 0x060005DF RID: 1503 RVA: 0x0000E719 File Offset: 0x0000C919
		public string Visibility
		{
			get
			{
				return this._visibility;
			}
			set
			{
				this._visibility = value;
			}
		}

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x060005E0 RID: 1504 RVA: 0x0000E722 File Offset: 0x0000C922
		// (set) Token: 0x060005E1 RID: 1505 RVA: 0x0000E72A File Offset: 0x0000C92A
		public string WordSpacing
		{
			get
			{
				return this._wordSpacing;
			}
			set
			{
				this._wordSpacing = this.NoEms(value);
			}
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x060005E2 RID: 1506 RVA: 0x0000E739 File Offset: 0x0000C939
		// (set) Token: 0x060005E3 RID: 1507 RVA: 0x0000E741 File Offset: 0x0000C941
		public string WordBreak
		{
			get
			{
				return this._wordBreak;
			}
			set
			{
				this._wordBreak = value;
			}
		}

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x060005E4 RID: 1508 RVA: 0x0000E74A File Offset: 0x0000C94A
		// (set) Token: 0x060005E5 RID: 1509 RVA: 0x0000E752 File Offset: 0x0000C952
		public string FontFamily
		{
			get
			{
				return this._fontFamily;
			}
			set
			{
				this._fontFamily = value;
			}
		}

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x060005E6 RID: 1510 RVA: 0x0000E75B File Offset: 0x0000C95B
		// (set) Token: 0x060005E7 RID: 1511 RVA: 0x00036684 File Offset: 0x00034884
		public string FontSize
		{
			get
			{
				return this._fontSize;
			}
			set
			{
				string text = RegexParserUtils.Search(<Module>.smethod_24<string>(1144177691U), value);
				if (text != null)
				{
					CssLength cssLength = new CssLength(text);
					string text2;
					if (!cssLength.HasError)
					{
						if (cssLength.Unit == CssUnit.Ems && this.GetParent() != null)
						{
							text2 = CssBoxProperties.smethod_5(cssLength.ConvertEmToPoints(this.GetParent().ActualFont.Size));
						}
						else
						{
							text2 = CssBoxProperties.smethod_5(cssLength);
						}
					}
					else
					{
						text2 = <Module>.smethod_26<string>(936435312U);
					}
					this._fontSize = text2;
					return;
				}
				this._fontSize = value;
			}
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x060005E8 RID: 1512 RVA: 0x0000E763 File Offset: 0x0000C963
		// (set) Token: 0x060005E9 RID: 1513 RVA: 0x0000E76B File Offset: 0x0000C96B
		public string FontStyle
		{
			get
			{
				return this._fontStyle;
			}
			set
			{
				this._fontStyle = value;
			}
		}

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x060005EA RID: 1514 RVA: 0x0000E774 File Offset: 0x0000C974
		// (set) Token: 0x060005EB RID: 1515 RVA: 0x0000E77C File Offset: 0x0000C97C
		public string FontVariant
		{
			get
			{
				return this._fontVariant;
			}
			set
			{
				this._fontVariant = value;
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x060005EC RID: 1516 RVA: 0x0000E785 File Offset: 0x0000C985
		// (set) Token: 0x060005ED RID: 1517 RVA: 0x0000E78D File Offset: 0x0000C98D
		public string FontWeight
		{
			get
			{
				return this._fontWeight;
			}
			set
			{
				this._fontWeight = value;
			}
		}

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x060005EE RID: 1518 RVA: 0x0000E796 File Offset: 0x0000C996
		// (set) Token: 0x060005EF RID: 1519 RVA: 0x0000E79E File Offset: 0x0000C99E
		public string ListStyle
		{
			get
			{
				return this._listStyle;
			}
			set
			{
				this._listStyle = value;
			}
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x060005F0 RID: 1520 RVA: 0x0000E7A7 File Offset: 0x0000C9A7
		// (set) Token: 0x060005F1 RID: 1521 RVA: 0x0000E7AF File Offset: 0x0000C9AF
		public string Overflow
		{
			get
			{
				return this._overflow;
			}
			set
			{
				this._overflow = value;
			}
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x060005F2 RID: 1522 RVA: 0x0000E7B8 File Offset: 0x0000C9B8
		// (set) Token: 0x060005F3 RID: 1523 RVA: 0x0000E7C0 File Offset: 0x0000C9C0
		public string ListStylePosition
		{
			get
			{
				return this._listStylePosition;
			}
			set
			{
				this._listStylePosition = value;
			}
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x060005F4 RID: 1524 RVA: 0x0000E7C9 File Offset: 0x0000C9C9
		// (set) Token: 0x060005F5 RID: 1525 RVA: 0x0000E7D1 File Offset: 0x0000C9D1
		public string ListStyleImage
		{
			get
			{
				return this._listStyleImage;
			}
			set
			{
				this._listStyleImage = value;
			}
		}

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x060005F6 RID: 1526 RVA: 0x0000E7DA File Offset: 0x0000C9DA
		// (set) Token: 0x060005F7 RID: 1527 RVA: 0x0000E7E2 File Offset: 0x0000C9E2
		public string ListStyleType
		{
			get
			{
				return this._listStyleType;
			}
			set
			{
				this._listStyleType = value;
			}
		}

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x060005F8 RID: 1528 RVA: 0x0000E7EB File Offset: 0x0000C9EB
		// (set) Token: 0x060005F9 RID: 1529 RVA: 0x0000E7F3 File Offset: 0x0000C9F3
		public RPoint Location
		{
			get
			{
				return this._location;
			}
			set
			{
				this._location = value;
			}
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x060005FA RID: 1530 RVA: 0x0000E7FC File Offset: 0x0000C9FC
		// (set) Token: 0x060005FB RID: 1531 RVA: 0x0000E804 File Offset: 0x0000CA04
		public RSize Size
		{
			get
			{
				return this._size;
			}
			set
			{
				this._size = value;
			}
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x060005FC RID: 1532 RVA: 0x0000E80D File Offset: 0x0000CA0D
		public RRect Bounds
		{
			get
			{
				return new RRect(this.Location, this.Size);
			}
		}

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x060005FD RID: 1533 RVA: 0x00036708 File Offset: 0x00034908
		public double AvailableWidth
		{
			get
			{
				return this.Size.Width - this.ActualBorderLeftWidth - this.ActualPaddingLeft - this.ActualPaddingRight - this.ActualBorderRightWidth;
			}
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x060005FE RID: 1534 RVA: 0x00036740 File Offset: 0x00034940
		// (set) Token: 0x060005FF RID: 1535 RVA: 0x0003676C File Offset: 0x0003496C
		public double ActualRight
		{
			get
			{
				return this.Location.X + this.Size.Width;
			}
			set
			{
				this.Size = new RSize(value - this.Location.X, this.Size.Height);
			}
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x06000600 RID: 1536 RVA: 0x000367A4 File Offset: 0x000349A4
		// (set) Token: 0x06000601 RID: 1537 RVA: 0x000367D0 File Offset: 0x000349D0
		public double ActualBottom
		{
			get
			{
				return this.Location.Y + this.Size.Height;
			}
			set
			{
				this.Size = new RSize(this.Size.Width, value - this.Location.Y);
			}
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x06000602 RID: 1538 RVA: 0x00036808 File Offset: 0x00034A08
		public double ClientLeft
		{
			get
			{
				return this.Location.X + this.ActualBorderLeftWidth + this.ActualPaddingLeft;
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x06000603 RID: 1539 RVA: 0x00036834 File Offset: 0x00034A34
		public double ClientTop
		{
			get
			{
				return this.Location.Y + this.ActualBorderTopWidth + this.ActualPaddingTop;
			}
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x06000604 RID: 1540 RVA: 0x0000E820 File Offset: 0x0000CA20
		public double ClientRight
		{
			get
			{
				return this.ActualRight - this.ActualPaddingRight - this.ActualBorderRightWidth;
			}
		}

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x06000605 RID: 1541 RVA: 0x0000E836 File Offset: 0x0000CA36
		public double ClientBottom
		{
			get
			{
				return this.ActualBottom - this.ActualPaddingBottom - this.ActualBorderBottomWidth;
			}
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x06000606 RID: 1542 RVA: 0x0000E84C File Offset: 0x0000CA4C
		public RRect ClientRectangle
		{
			get
			{
				return RRect.FromLTRB(this.ClientLeft, this.ClientTop, this.ClientRight, this.ClientBottom);
			}
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x06000607 RID: 1543 RVA: 0x00036860 File Offset: 0x00034A60
		public double ActualHeight
		{
			get
			{
				if (double.IsNaN(this._actualHeight))
				{
					this._actualHeight = CssValueParser.ParseLength(this.Height, this.Size.Height, this, false);
				}
				return this._actualHeight;
			}
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x06000608 RID: 1544 RVA: 0x000368A4 File Offset: 0x00034AA4
		public double ActualWidth
		{
			get
			{
				if (double.IsNaN(this._actualWidth))
				{
					this._actualWidth = CssValueParser.ParseLength(this.Width, this.Size.Width, this, false);
				}
				return this._actualWidth;
			}
		}

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x06000609 RID: 1545 RVA: 0x000368E8 File Offset: 0x00034AE8
		public double ActualPaddingTop
		{
			get
			{
				if (double.IsNaN(this._actualPaddingTop))
				{
					this._actualPaddingTop = CssValueParser.ParseLength(this.PaddingTop, this.Size.Width, this, false);
				}
				return this._actualPaddingTop;
			}
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x0600060A RID: 1546 RVA: 0x0003692C File Offset: 0x00034B2C
		public double ActualPaddingLeft
		{
			get
			{
				if (double.IsNaN(this._actualPaddingLeft))
				{
					this._actualPaddingLeft = CssValueParser.ParseLength(this.PaddingLeft, this.Size.Width, this, false);
				}
				return this._actualPaddingLeft;
			}
		}

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x0600060B RID: 1547 RVA: 0x00036970 File Offset: 0x00034B70
		public double ActualPaddingBottom
		{
			get
			{
				if (double.IsNaN(this._actualPaddingBottom))
				{
					this._actualPaddingBottom = CssValueParser.ParseLength(this.PaddingBottom, this.Size.Width, this, false);
				}
				return this._actualPaddingBottom;
			}
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x0600060C RID: 1548 RVA: 0x000369B4 File Offset: 0x00034BB4
		public double ActualPaddingRight
		{
			get
			{
				if (double.IsNaN(this._actualPaddingRight))
				{
					this._actualPaddingRight = CssValueParser.ParseLength(this.PaddingRight, this.Size.Width, this, false);
				}
				return this._actualPaddingRight;
			}
		}

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x0600060D RID: 1549 RVA: 0x000369F8 File Offset: 0x00034BF8
		public double ActualMarginTop
		{
			get
			{
				if (double.IsNaN(this._actualMarginTop))
				{
					if (CssBoxProperties.smethod_6(this.MarginTop, <Module>.smethod_24<string>(2471334246U)))
					{
						this.MarginTop = <Module>.smethod_27<string>(1690140869U);
					}
					double num = CssValueParser.ParseLength(this.MarginTop, this.Size.Width, this, false);
					if (CssBoxProperties.smethod_7(this.MarginLeft, <Module>.smethod_23<string>(3608961515U)))
					{
						return num;
					}
					this._actualMarginTop = num;
				}
				return this._actualMarginTop;
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x0600060E RID: 1550 RVA: 0x0000E86B File Offset: 0x0000CA6B
		// (set) Token: 0x0600060F RID: 1551 RVA: 0x0000E88A File Offset: 0x0000CA8A
		public double CollapsedMarginTop
		{
			get
			{
				if (!double.IsNaN(this._collapsedMarginTop))
				{
					return this._collapsedMarginTop;
				}
				return 0.0;
			}
			set
			{
				this._collapsedMarginTop = value;
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x06000610 RID: 1552 RVA: 0x00036A7C File Offset: 0x00034C7C
		public double ActualMarginLeft
		{
			get
			{
				if (double.IsNaN(this._actualMarginLeft))
				{
					if (CssBoxProperties.smethod_6(this.MarginLeft, <Module>.smethod_25<string>(2087203512U)))
					{
						this.MarginLeft = <Module>.smethod_23<string>(2680181005U);
					}
					double num = CssValueParser.ParseLength(this.MarginLeft, this.Size.Width, this, false);
					if (CssBoxProperties.smethod_7(this.MarginLeft, <Module>.smethod_25<string>(1808813700U)))
					{
						return num;
					}
					this._actualMarginLeft = num;
				}
				return this._actualMarginLeft;
			}
		}

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x06000611 RID: 1553 RVA: 0x00036B00 File Offset: 0x00034D00
		public double ActualMarginBottom
		{
			get
			{
				if (double.IsNaN(this._actualMarginBottom))
				{
					if (CssBoxProperties.smethod_6(this.MarginBottom, <Module>.smethod_24<string>(2471334246U)))
					{
						this.MarginBottom = <Module>.smethod_25<string>(1948008606U);
					}
					double num = CssValueParser.ParseLength(this.MarginBottom, this.Size.Width, this, false);
					if (CssBoxProperties.smethod_7(this.MarginLeft, <Module>.smethod_26<string>(231779889U)))
					{
						return num;
					}
					this._actualMarginBottom = num;
				}
				return this._actualMarginBottom;
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x06000612 RID: 1554 RVA: 0x00036B84 File Offset: 0x00034D84
		public double ActualMarginRight
		{
			get
			{
				if (double.IsNaN(this._actualMarginRight))
				{
					if (CssBoxProperties.smethod_6(this.MarginRight, <Module>.smethod_25<string>(2087203512U)))
					{
						this.MarginRight = <Module>.smethod_27<string>(1690140869U);
					}
					double num = CssValueParser.ParseLength(this.MarginRight, this.Size.Width, this, false);
					if (CssBoxProperties.smethod_7(this.MarginLeft, <Module>.smethod_24<string>(4097253490U)))
					{
						return num;
					}
					this._actualMarginRight = num;
				}
				return this._actualMarginRight;
			}
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x06000613 RID: 1555 RVA: 0x00036C08 File Offset: 0x00034E08
		public double ActualBorderTopWidth
		{
			get
			{
				if (double.IsNaN(this._actualBorderTopWidth))
				{
					this._actualBorderTopWidth = CssValueParser.GetActualBorderWidth(this.BorderTopWidth, this);
					if (CssBoxProperties.smethod_8(this.BorderTopStyle) || CssBoxProperties.smethod_6(this.BorderTopStyle, <Module>.smethod_23<string>(436056481U)))
					{
						this._actualBorderTopWidth = 0.0;
					}
				}
				return this._actualBorderTopWidth;
			}
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x06000614 RID: 1556 RVA: 0x00036C70 File Offset: 0x00034E70
		public double ActualBorderLeftWidth
		{
			get
			{
				if (double.IsNaN(this._actualBorderLeftWidth))
				{
					this._actualBorderLeftWidth = CssValueParser.GetActualBorderWidth(this.BorderLeftWidth, this);
					if (CssBoxProperties.smethod_8(this.BorderLeftStyle) || CssBoxProperties.smethod_6(this.BorderLeftStyle, <Module>.smethod_23<string>(436056481U)))
					{
						this._actualBorderLeftWidth = 0.0;
					}
				}
				return this._actualBorderLeftWidth;
			}
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x06000615 RID: 1557 RVA: 0x00036CD8 File Offset: 0x00034ED8
		public double ActualBorderBottomWidth
		{
			get
			{
				if (double.IsNaN(this._actualBorderBottomWidth))
				{
					this._actualBorderBottomWidth = CssValueParser.GetActualBorderWidth(this.BorderBottomWidth, this);
					if (CssBoxProperties.smethod_8(this.BorderBottomStyle) || CssBoxProperties.smethod_6(this.BorderBottomStyle, <Module>.smethod_24<string>(3284293868U)))
					{
						this._actualBorderBottomWidth = 0.0;
					}
				}
				return this._actualBorderBottomWidth;
			}
		}

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x06000616 RID: 1558 RVA: 0x00036D40 File Offset: 0x00034F40
		public double ActualBorderRightWidth
		{
			get
			{
				if (double.IsNaN(this._actualBorderRightWidth))
				{
					this._actualBorderRightWidth = CssValueParser.GetActualBorderWidth(this.BorderRightWidth, this);
					if (CssBoxProperties.smethod_8(this.BorderRightStyle) || CssBoxProperties.smethod_6(this.BorderRightStyle, <Module>.smethod_27<string>(1876627641U)))
					{
						this._actualBorderRightWidth = 0.0;
					}
				}
				return this._actualBorderRightWidth;
			}
		}

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x06000617 RID: 1559 RVA: 0x0000E893 File Offset: 0x0000CA93
		public RColor ActualBorderTopColor
		{
			get
			{
				if (this._actualBorderTopColor.IsEmpty)
				{
					this._actualBorderTopColor = this.GetActualColor(this.BorderTopColor);
				}
				return this._actualBorderTopColor;
			}
		}

		// Token: 0x06000618 RID: 1560
		protected abstract RColor GetActualColor(string colorStr);

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x06000619 RID: 1561 RVA: 0x0000E8BA File Offset: 0x0000CABA
		public RColor ActualBorderLeftColor
		{
			get
			{
				if (this._actualBorderLeftColor.IsEmpty)
				{
					this._actualBorderLeftColor = this.GetActualColor(this.BorderLeftColor);
				}
				return this._actualBorderLeftColor;
			}
		}

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x0600061A RID: 1562 RVA: 0x0000E8E1 File Offset: 0x0000CAE1
		public RColor ActualBorderBottomColor
		{
			get
			{
				if (this._actualBorderBottomColor.IsEmpty)
				{
					this._actualBorderBottomColor = this.GetActualColor(this.BorderBottomColor);
				}
				return this._actualBorderBottomColor;
			}
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x0600061B RID: 1563 RVA: 0x0000E908 File Offset: 0x0000CB08
		public RColor ActualBorderRightColor
		{
			get
			{
				if (this._actualBorderRightColor.IsEmpty)
				{
					this._actualBorderRightColor = this.GetActualColor(this.BorderRightColor);
				}
				return this._actualBorderRightColor;
			}
		}

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x0600061C RID: 1564 RVA: 0x0000E92F File Offset: 0x0000CB2F
		public double ActualCornerNw
		{
			get
			{
				if (double.IsNaN(this._actualCornerNw))
				{
					this._actualCornerNw = CssValueParser.ParseLength(this.CornerNwRadius, 0.0, this, false);
				}
				return this._actualCornerNw;
			}
		}

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x0600061D RID: 1565 RVA: 0x0000E960 File Offset: 0x0000CB60
		public double ActualCornerNe
		{
			get
			{
				if (double.IsNaN(this._actualCornerNe))
				{
					this._actualCornerNe = CssValueParser.ParseLength(this.CornerNeRadius, 0.0, this, false);
				}
				return this._actualCornerNe;
			}
		}

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x0600061E RID: 1566 RVA: 0x0000E991 File Offset: 0x0000CB91
		public double ActualCornerSe
		{
			get
			{
				if (double.IsNaN(this._actualCornerSe))
				{
					this._actualCornerSe = CssValueParser.ParseLength(this.CornerSeRadius, 0.0, this, false);
				}
				return this._actualCornerSe;
			}
		}

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x0600061F RID: 1567 RVA: 0x0000E9C2 File Offset: 0x0000CBC2
		public double ActualCornerSw
		{
			get
			{
				if (double.IsNaN(this._actualCornerSw))
				{
					this._actualCornerSw = CssValueParser.ParseLength(this.CornerSwRadius, 0.0, this, false);
				}
				return this._actualCornerSw;
			}
		}

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x06000620 RID: 1568 RVA: 0x00036DA8 File Offset: 0x00034FA8
		public bool IsRounded
		{
			get
			{
				return this.ActualCornerNe > 0.0 || this.ActualCornerNw > 0.0 || this.ActualCornerSe > 0.0 || this.ActualCornerSw > 0.0;
			}
		}

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x06000621 RID: 1569 RVA: 0x0000E9F3 File Offset: 0x0000CBF3
		public double ActualWordSpacing
		{
			get
			{
				return this._actualWordSpacing;
			}
		}

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x06000622 RID: 1570 RVA: 0x0000E9FB File Offset: 0x0000CBFB
		public RColor ActualColor
		{
			get
			{
				if (this._actualColor.IsEmpty)
				{
					this._actualColor = this.GetActualColor(this.Color);
				}
				return this._actualColor;
			}
		}

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x06000623 RID: 1571 RVA: 0x0000EA22 File Offset: 0x0000CC22
		public RColor ActualBackgroundColor
		{
			get
			{
				if (this._actualBackgroundColor.IsEmpty)
				{
					this._actualBackgroundColor = this.GetActualColor(this.BackgroundColor);
				}
				return this._actualBackgroundColor;
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x06000624 RID: 1572 RVA: 0x0000EA49 File Offset: 0x0000CC49
		public RColor ActualBackgroundGradient
		{
			get
			{
				if (this._actualBackgroundGradient.IsEmpty)
				{
					this._actualBackgroundGradient = this.GetActualColor(this.BackgroundGradient);
				}
				return this._actualBackgroundGradient;
			}
		}

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x06000625 RID: 1573 RVA: 0x0000EA70 File Offset: 0x0000CC70
		public double ActualBackgroundGradientAngle
		{
			get
			{
				if (double.IsNaN(this._actualBackgroundGradientAngle))
				{
					this._actualBackgroundGradientAngle = CssValueParser.ParseNumber(this.BackgroundGradientAngle, 360.0);
				}
				return this._actualBackgroundGradientAngle;
			}
		}

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x06000626 RID: 1574 RVA: 0x0000EA9F File Offset: 0x0000CC9F
		public RFont ActualParentFont
		{
			get
			{
				if (this.GetParent() != null)
				{
					return this.GetParent().ActualFont;
				}
				return this.ActualFont;
			}
		}

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x06000627 RID: 1575 RVA: 0x00036DFC File Offset: 0x00034FFC
		public RFont ActualFont
		{
			get
			{
				if (this._actualFont == null)
				{
					if (CssBoxProperties.smethod_8(this.FontFamily))
					{
						this.FontFamily = <Module>.smethod_24<string>(1428205438U);
					}
					if (CssBoxProperties.smethod_8(this.FontSize))
					{
						this.FontSize = 11.0.ToString(CssBoxProperties.smethod_9()) + <Module>.smethod_25<string>(2435190777U);
					}
					RFontStyle rfontStyle = RFontStyle.Regular;
					if (this.FontStyle == <Module>.smethod_24<string>(3460604493U) || this.FontStyle == <Module>.smethod_26<string>(250932677U))
					{
						rfontStyle |= RFontStyle.Italic;
					}
					if (this.FontWeight != <Module>.smethod_27<string>(990815474U) && this.FontWeight != <Module>.smethod_23<string>(3571333265U) && !string.IsNullOrEmpty(this.FontWeight) && this.FontWeight != <Module>.smethod_27<string>(711085316U))
					{
						rfontStyle |= RFontStyle.Bold;
					}
					double num = 11.0;
					if (this.GetParent() != null)
					{
						num = this.GetParent().ActualFont.Size;
					}
					string fontSize;
					double num3;
					switch (fontSize = this.FontSize)
					{

						num3 = 11.0;
						goto IL_0299;

						num3 = 7.0;
						goto IL_0299;

						num3 = 8.0;
						goto IL_0299;

						num3 = 9.0;
						goto IL_0299;

						num3 = 13.0;
						goto IL_0299;

						num3 = 14.0;
						goto IL_0299;

						num3 = 15.0;
						goto IL_0299;

						num3 = num - 2.0;
						goto IL_0299;

						num3 = num + 2.0;
						goto IL_0299;
					}
					num3 = CssValueParser.ParseLength(this.FontSize, num, num, null, true, true);
					IL_0299:
					if (num3 <= 1.0)
					{
						num3 = 11.0;
					}
					this._actualFont = this.GetCachedFont(this.FontFamily, num3, rfontStyle);
				}
				return this._actualFont;
			}
		}

		// Token: 0x06000628 RID: 1576
		protected abstract RFont GetCachedFont(string fontFamily, double fsize, RFontStyle st);

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x06000629 RID: 1577 RVA: 0x000370D8 File Offset: 0x000352D8
		public double ActualLineHeight
		{
			get
			{
				if (double.IsNaN(this._actualLineHeight))
				{
					this._actualLineHeight = 0.89999997615814209 * CssValueParser.ParseLength(this.LineHeight, this.Size.Height, this, false);
				}
				return this._actualLineHeight;
			}
		}

		// Token: 0x170000EE RID: 238
		// (get) Token: 0x0600062A RID: 1578 RVA: 0x00037124 File Offset: 0x00035324
		public double ActualTextIndent
		{
			get
			{
				if (double.IsNaN(this._actualTextIndent))
				{
					this._actualTextIndent = CssValueParser.ParseLength(this.TextIndent, this.Size.Width, this, false);
				}
				return this._actualTextIndent;
			}
		}

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x0600062B RID: 1579 RVA: 0x00037168 File Offset: 0x00035368
		public double ActualBorderSpacingHorizontal
		{
			get
			{
				if (double.IsNaN(this._actualBorderSpacingHorizontal))
				{
					MatchCollection matchCollection = RegexParserUtils.Match(<Module>.smethod_24<string>(1144177691U), this.BorderSpacing);
					if (CssBoxProperties.smethod_0(matchCollection) == 0)
					{
						this._actualBorderSpacingHorizontal = 0.0;
					}
					else if (CssBoxProperties.smethod_0(matchCollection) > 0)
					{
						this._actualBorderSpacingHorizontal = CssValueParser.ParseLength(CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 0)), 1.0, this, false);
					}
				}
				return this._actualBorderSpacingHorizontal;
			}
		}

		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x0600062C RID: 1580 RVA: 0x000371E4 File Offset: 0x000353E4
		public double ActualBorderSpacingVertical
		{
			get
			{
				if (double.IsNaN(this._actualBorderSpacingVertical))
				{
					MatchCollection matchCollection = RegexParserUtils.Match(<Module>.smethod_26<string>(2537274038U), this.BorderSpacing);
					if (CssBoxProperties.smethod_0(matchCollection) == 0)
					{
						this._actualBorderSpacingVertical = 0.0;
					}
					else if (CssBoxProperties.smethod_0(matchCollection) == 1)
					{
						this._actualBorderSpacingVertical = CssValueParser.ParseLength(CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 0)), 1.0, this, false);
					}
					else
					{
						this._actualBorderSpacingVertical = CssValueParser.ParseLength(CssBoxProperties.smethod_2(CssBoxProperties.smethod_1(matchCollection, 1)), 1.0, this, false);
					}
				}
				return this._actualBorderSpacingVertical;
			}
		}

		// Token: 0x0600062D RID: 1581
		protected abstract CssBoxProperties GetParent();

		// Token: 0x0600062E RID: 1582 RVA: 0x0000EABB File Offset: 0x0000CCBB
		public double GetEmHeight()
		{
			return this.ActualFont.Height;
		}

		// Token: 0x0600062F RID: 1583 RVA: 0x00037284 File Offset: 0x00035484
		protected string NoEms(string length)
		{
			CssLength cssLength = new CssLength(length);
			if (cssLength.Unit == CssUnit.Ems)
			{
				length = CssBoxProperties.smethod_5(cssLength.ConvertEmToPixels(this.GetEmHeight()));
			}
			return length;
		}

		// Token: 0x06000630 RID: 1584 RVA: 0x000372B8 File Offset: 0x000354B8
		protected void SetAllBorders(string style = null, string width = null, string color = null)
		{
			if (style != null)
			{
				this.BorderBottomStyle = style;
				this.BorderRightStyle = style;
				this.BorderTopStyle = style;
				this.BorderLeftStyle = style;
			}
			if (width != null)
			{
				this.BorderBottomWidth = width;
				this.BorderRightWidth = width;
				this.BorderTopWidth = width;
				this.BorderLeftWidth = width;
			}
			if (color != null)
			{
				this.BorderBottomColor = color;
				this.BorderRightColor = color;
				this.BorderTopColor = color;
				this.BorderLeftColor = color;
			}
		}

		// Token: 0x06000631 RID: 1585 RVA: 0x00037340 File Offset: 0x00035540
		protected void MeasureWordSpacing(RGraphics g)
		{
			if (double.IsNaN(this.ActualWordSpacing))
			{
				this._actualWordSpacing = CssUtils.WhiteSpace(g, this);
				if (CssBoxProperties.smethod_10(this.WordSpacing, <Module>.smethod_24<string>(4151112051U)))
				{
					string text = RegexParserUtils.Search(<Module>.smethod_24<string>(1144177691U), this.WordSpacing);
					this._actualWordSpacing += CssValueParser.ParseLength(text, 1.0, this, false);
				}
			}
		}

		// Token: 0x06000632 RID: 1586 RVA: 0x000373B4 File Offset: 0x000355B4
		protected void InheritStyle(CssBox p, bool everything)
		{
			if (p != null)
			{
				this._borderSpacing = p._borderSpacing;
				this._borderCollapse = p._borderCollapse;
				this._color = p._color;
				this._emptyCells = p._emptyCells;
				this._whiteSpace = p._whiteSpace;
				this._visibility = p._visibility;
				this._textIndent = p._textIndent;
				this._textAlign = p._textAlign;
				this._verticalAlign = p._verticalAlign;
				this._fontFamily = p._fontFamily;
				this._fontSize = p._fontSize;
				this._fontStyle = p._fontStyle;
				this._fontVariant = p._fontVariant;
				this._fontWeight = p._fontWeight;
				this._listStyleImage = p._listStyleImage;
				this._listStylePosition = p._listStylePosition;
				this._listStyleType = p._listStyleType;
				this._listStyle = p._listStyle;
				this._lineHeight = p._lineHeight;
				this._wordBreak = p.WordBreak;
				this._direction = p._direction;
				if (everything)
				{
					this._backgroundColor = p._backgroundColor;
					this._backgroundGradient = p._backgroundGradient;
					this._backgroundGradientAngle = p._backgroundGradientAngle;
					this._backgroundImage = p._backgroundImage;
					this._backgroundPosition = p._backgroundPosition;
					this._backgroundRepeat = p._backgroundRepeat;
					this._borderTopWidth = p._borderTopWidth;
					this._borderRightWidth = p._borderRightWidth;
					this._borderBottomWidth = p._borderBottomWidth;
					this._borderLeftWidth = p._borderLeftWidth;
					this._borderTopColor = p._borderTopColor;
					this._borderRightColor = p._borderRightColor;
					this._borderBottomColor = p._borderBottomColor;
					this._borderLeftColor = p._borderLeftColor;
					this._borderTopStyle = p._borderTopStyle;
					this._borderRightStyle = p._borderRightStyle;
					this._borderBottomStyle = p._borderBottomStyle;
					this._borderLeftStyle = p._borderLeftStyle;
					this._bottom = p._bottom;
					this._cornerNwRadius = p._cornerNwRadius;
					this._cornerNeRadius = p._cornerNeRadius;
					this._cornerSeRadius = p._cornerSeRadius;
					this._cornerSwRadius = p._cornerSwRadius;
					this._cornerRadius = p._cornerRadius;
					this._display = p._display;
					this._float = p._float;
					this._height = p._height;
					this._marginBottom = p._marginBottom;
					this._marginLeft = p._marginLeft;
					this._marginRight = p._marginRight;
					this._marginTop = p._marginTop;
					this._left = p._left;
					this._lineHeight = p._lineHeight;
					this._overflow = p._overflow;
					this._paddingLeft = p._paddingLeft;
					this._paddingBottom = p._paddingBottom;
					this._paddingRight = p._paddingRight;
					this._paddingTop = p._paddingTop;
					this._right = p._right;
					this._textDecoration = p._textDecoration;
					this._top = p._top;
					this._position = p._position;
					this._width = p._width;
					this._maxWidth = p._maxWidth;
					this._wordSpacing = p._wordSpacing;
				}
			}
		}

		// Token: 0x06000634 RID: 1588 RVA: 0x0000EAC8 File Offset: 0x0000CCC8
		static int smethod_0(MatchCollection matchCollection_0)
		{
			return matchCollection_0.Count;
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x0000EAD0 File Offset: 0x0000CCD0
		static Match smethod_1(MatchCollection matchCollection_0, int int_0)
		{
			return matchCollection_0[int_0];
		}

		// Token: 0x06000636 RID: 1590 RVA: 0x0000EAD9 File Offset: 0x0000CCD9
		static string smethod_2(Capture capture_0)
		{
			return capture_0.Value;
		}

		// Token: 0x06000637 RID: 1591 RVA: 0x0000EAE1 File Offset: 0x0000CCE1
		static NumberFormatInfo smethod_3()
		{
			return NumberFormatInfo.InvariantInfo;
		}

		// Token: 0x06000638 RID: 1592 RVA: 0x0000EAE8 File Offset: 0x0000CCE8
		static string smethod_4(IFormatProvider iformatProvider_0, string string_0, object[] object_0)
		{
			return string.Format(iformatProvider_0, string_0, object_0);
		}

		// Token: 0x06000639 RID: 1593 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_5(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x0600063A RID: 1594 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_6(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x0600063B RID: 1595 RVA: 0x0000D9AC File Offset: 0x0000BBAC
		static bool smethod_7(string string_0, string string_1)
		{
			return string_0.EndsWith(string_1);
		}

		// Token: 0x0600063C RID: 1596 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_8(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x0600063D RID: 1597 RVA: 0x0000CDAA File Offset: 0x0000AFAA
		static CultureInfo smethod_9()
		{
			return CultureInfo.InvariantCulture;
		}

		// Token: 0x0600063E RID: 1598 RVA: 0x0000CDA1 File Offset: 0x0000AFA1
		static bool smethod_10(string string_0, string string_1)
		{
			return string_0 != string_1;
		}

		// Token: 0x040001FC RID: 508
		private string _backgroundColor = <Module>.smethod_24<string>(1766091746U);

		// Token: 0x040001FD RID: 509
		private string _backgroundGradient = <Module>.smethod_23<string>(436056481U);

		// Token: 0x040001FE RID: 510
		private string _backgroundGradientAngle = <Module>.smethod_26<string>(519071709U);

		// Token: 0x040001FF RID: 511
		private string _backgroundImage = <Module>.smethod_24<string>(3284293868U);

		// Token: 0x04000200 RID: 512
		private string _backgroundPosition = <Module>.smethod_26<string>(1947535343U);

		// Token: 0x04000201 RID: 513
		private string _backgroundRepeat = <Module>.smethod_23<string>(3198443384U);

		// Token: 0x04000202 RID: 514
		private string _borderTopWidth = <Module>.smethod_25<string>(1182436623U);

		// Token: 0x04000203 RID: 515
		private string _borderRightWidth = <Module>.smethod_25<string>(1182436623U);

		// Token: 0x04000204 RID: 516
		private string _borderBottomWidth = <Module>.smethod_27<string>(2389466264U);

		// Token: 0x04000205 RID: 517
		private string _borderLeftWidth = <Module>.smethod_24<string>(1374346877U);

		// Token: 0x04000206 RID: 518
		private string _borderTopColor = <Module>.smethod_24<string>(2226430118U);

		// Token: 0x04000207 RID: 519
		private string _borderRightColor = <Module>.smethod_24<string>(2226430118U);

		// Token: 0x04000208 RID: 520
		private string _borderBottomColor = <Module>.smethod_25<string>(1927933816U);

		// Token: 0x04000209 RID: 521
		private string _borderLeftColor = <Module>.smethod_27<string>(472205311U);

		// Token: 0x0400020A RID: 522
		private string _borderTopStyle = <Module>.smethod_23<string>(436056481U);

		// Token: 0x0400020B RID: 523
		private string _borderRightStyle = <Module>.smethod_25<string>(1669618794U);

		// Token: 0x0400020C RID: 524
		private string _borderBottomStyle = <Module>.smethod_25<string>(1669618794U);

		// Token: 0x0400020D RID: 525
		private string _borderLeftStyle = <Module>.smethod_23<string>(436056481U);

		// Token: 0x0400020E RID: 526
		private string _borderSpacing = <Module>.smethod_24<string>(1658374624U);

		// Token: 0x0400020F RID: 527
		private string _borderCollapse = <Module>.smethod_23<string>(2462944626U);

		// Token: 0x04000210 RID: 528
		private string _bottom;

		// Token: 0x04000211 RID: 529
		private string _color = <Module>.smethod_23<string>(1901913495U);

		// Token: 0x04000212 RID: 530
		private string _cornerNwRadius = <Module>.smethod_27<string>(1690140869U);

		// Token: 0x04000213 RID: 531
		private string _cornerNeRadius = <Module>.smethod_23<string>(2680181005U);

		// Token: 0x04000214 RID: 532
		private string _cornerSeRadius = <Module>.smethod_24<string>(1658374624U);

		// Token: 0x04000215 RID: 533
		private string _cornerSwRadius = <Module>.smethod_24<string>(1658374624U);

		// Token: 0x04000216 RID: 534
		private string _cornerRadius = <Module>.smethod_26<string>(222203495U);

		// Token: 0x04000217 RID: 535
		private string _emptyCells = <Module>.smethod_24<string>(3039389740U);

		// Token: 0x04000218 RID: 536
		private string _direction = <Module>.smethod_25<string>(2484713440U);

		// Token: 0x04000219 RID: 537
		private string _display = <Module>.smethod_24<string>(370341688U);

		// Token: 0x0400021A RID: 538
		private string _fontFamily;

		// Token: 0x0400021B RID: 539
		private string _fontSize = <Module>.smethod_23<string>(2854648632U);

		// Token: 0x0400021C RID: 540
		private string _fontStyle = <Module>.smethod_25<string>(2991970401U);

		// Token: 0x0400021D RID: 541
		private string _fontVariant = <Module>.smethod_26<string>(965164494U);

		// Token: 0x0400021E RID: 542
		private string _fontWeight = <Module>.smethod_23<string>(959459362U);

		// Token: 0x0400021F RID: 543
		private string _float = <Module>.smethod_26<string>(1660243523U);

		// Token: 0x04000220 RID: 544
		private string _height = <Module>.smethod_23<string>(1558118743U);

		// Token: 0x04000221 RID: 545
		private string _marginBottom = <Module>.smethod_25<string>(1948008606U);

		// Token: 0x04000222 RID: 546
		private string _marginLeft = <Module>.smethod_24<string>(1658374624U);

		// Token: 0x04000223 RID: 547
		private string _marginRight = <Module>.smethod_27<string>(1690140869U);

		// Token: 0x04000224 RID: 548
		private string _marginTop = <Module>.smethod_24<string>(1658374624U);

		// Token: 0x04000225 RID: 549
		private string _left = <Module>.smethod_26<string>(3088707157U);

		// Token: 0x04000226 RID: 550
		private string _lineHeight = <Module>.smethod_24<string>(4151112051U);

		// Token: 0x04000227 RID: 551
		private string _listStyleType = <Module>.smethod_25<string>(2136726175U);

		// Token: 0x04000228 RID: 552
		private string _listStyleImage = string.Empty;

		// Token: 0x04000229 RID: 553
		private string _listStylePosition = <Module>.smethod_23<string>(412101854U);

		// Token: 0x0400022A RID: 554
		private string _listStyle = string.Empty;

		// Token: 0x0400022B RID: 555
		private string _overflow = <Module>.smethod_23<string>(1864285245U);

		// Token: 0x0400022C RID: 556
		private string _paddingLeft = <Module>.smethod_24<string>(1658374624U);

		// Token: 0x0400022D RID: 557
		private string _paddingBottom = <Module>.smethod_23<string>(2680181005U);

		// Token: 0x0400022E RID: 558
		private string _paddingRight = <Module>.smethod_26<string>(222203495U);

		// Token: 0x0400022F RID: 559
		private string _paddingTop = <Module>.smethod_26<string>(222203495U);

		// Token: 0x04000230 RID: 560
		private string _right;

		// Token: 0x04000231 RID: 561
		private string _textAlign = string.Empty;

		// Token: 0x04000232 RID: 562
		private string _textDecoration = string.Empty;

		// Token: 0x04000233 RID: 563
		private string _textIndent = <Module>.smethod_26<string>(222203495U);

		// Token: 0x04000234 RID: 564
		private string _top = <Module>.smethod_23<string>(1558118743U);

		// Token: 0x04000235 RID: 565
		private string _position = <Module>.smethod_25<string>(2693505799U);

		// Token: 0x04000236 RID: 566
		private string _verticalAlign = <Module>.smethod_23<string>(935504735U);

		// Token: 0x04000237 RID: 567
		private string _width = <Module>.smethod_26<string>(3088707157U);

		// Token: 0x04000238 RID: 568
		private string _maxWidth = <Module>.smethod_25<string>(1669618794U);

		// Token: 0x04000239 RID: 569
		private string _wordSpacing = <Module>.smethod_27<string>(990815474U);

		// Token: 0x0400023A RID: 570
		private string _wordBreak = <Module>.smethod_23<string>(959459362U);

		// Token: 0x0400023B RID: 571
		private string _whiteSpace = <Module>.smethod_23<string>(959459362U);

		// Token: 0x0400023C RID: 572
		private string _visibility = <Module>.smethod_27<string>(3927982133U);

		// Token: 0x0400023D RID: 573
		private RPoint _location;

		// Token: 0x0400023E RID: 574
		private RSize _size;

		// Token: 0x0400023F RID: 575
		private double _actualCornerNw = double.NaN;

		// Token: 0x04000240 RID: 576
		private double _actualCornerNe = double.NaN;

		// Token: 0x04000241 RID: 577
		private double _actualCornerSw = double.NaN;

		// Token: 0x04000242 RID: 578
		private double _actualCornerSe = double.NaN;

		// Token: 0x04000243 RID: 579
		private RColor _actualColor = RColor.Empty;

		// Token: 0x04000244 RID: 580
		private double _actualBackgroundGradientAngle = double.NaN;

		// Token: 0x04000245 RID: 581
		private double _actualHeight = double.NaN;

		// Token: 0x04000246 RID: 582
		private double _actualWidth = double.NaN;

		// Token: 0x04000247 RID: 583
		private double _actualPaddingTop = double.NaN;

		// Token: 0x04000248 RID: 584
		private double _actualPaddingBottom = double.NaN;

		// Token: 0x04000249 RID: 585
		private double _actualPaddingRight = double.NaN;

		// Token: 0x0400024A RID: 586
		private double _actualPaddingLeft = double.NaN;

		// Token: 0x0400024B RID: 587
		private double _actualMarginTop = double.NaN;

		// Token: 0x0400024C RID: 588
		private double _collapsedMarginTop = double.NaN;

		// Token: 0x0400024D RID: 589
		private double _actualMarginBottom = double.NaN;

		// Token: 0x0400024E RID: 590
		private double _actualMarginRight = double.NaN;

		// Token: 0x0400024F RID: 591
		private double _actualMarginLeft = double.NaN;

		// Token: 0x04000250 RID: 592
		private double _actualBorderTopWidth = double.NaN;

		// Token: 0x04000251 RID: 593
		private double _actualBorderLeftWidth = double.NaN;

		// Token: 0x04000252 RID: 594
		private double _actualBorderBottomWidth = double.NaN;

		// Token: 0x04000253 RID: 595
		private double _actualBorderRightWidth = double.NaN;

		// Token: 0x04000254 RID: 596
		private double _actualLineHeight = double.NaN;

		// Token: 0x04000255 RID: 597
		private double _actualWordSpacing = double.NaN;

		// Token: 0x04000256 RID: 598
		private double _actualTextIndent = double.NaN;

		// Token: 0x04000257 RID: 599
		private double _actualBorderSpacingHorizontal = double.NaN;

		// Token: 0x04000258 RID: 600
		private double _actualBorderSpacingVertical = double.NaN;

		// Token: 0x04000259 RID: 601
		private RColor _actualBackgroundGradient = RColor.Empty;

		// Token: 0x0400025A RID: 602
		private RColor _actualBorderTopColor = RColor.Empty;

		// Token: 0x0400025B RID: 603
		private RColor _actualBorderLeftColor = RColor.Empty;

		// Token: 0x0400025C RID: 604
		private RColor _actualBorderBottomColor = RColor.Empty;

		// Token: 0x0400025D RID: 605
		private RColor _actualBorderRightColor = RColor.Empty;

		// Token: 0x0400025E RID: 606
		private RColor _actualBackgroundColor = RColor.Empty;

		// Token: 0x0400025F RID: 607
		private RFont _actualFont;
	}
}
