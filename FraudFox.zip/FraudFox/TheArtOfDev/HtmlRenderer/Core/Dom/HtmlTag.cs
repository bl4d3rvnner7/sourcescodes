﻿using System;
using System.Collections.Generic;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x02000088 RID: 136
	internal sealed class HtmlTag
	{
		// Token: 0x06000780 RID: 1920 RVA: 0x0000F328 File Offset: 0x0000D528
		public HtmlTag(string name, bool isSingle, Dictionary<string, string> attributes = null)
		{
			ArgChecker.AssertArgNotNullOrEmpty(name, <Module>.smethod_26<string>(3601180475U));
			this._name = name;
			this._isSingle = isSingle;
			this._attributes = attributes;
		}

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x06000781 RID: 1921 RVA: 0x0000F355 File Offset: 0x0000D555
		public string Name
		{
			get
			{
				return this._name;
			}
		}

		// Token: 0x1700013B RID: 315
		// (get) Token: 0x06000782 RID: 1922 RVA: 0x0000F35D File Offset: 0x0000D55D
		public Dictionary<string, string> Attributes
		{
			get
			{
				return this._attributes;
			}
		}

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x06000783 RID: 1923 RVA: 0x0000F365 File Offset: 0x0000D565
		public bool IsSingle
		{
			get
			{
				return this._isSingle;
			}
		}

		// Token: 0x06000784 RID: 1924 RVA: 0x0000F36D File Offset: 0x0000D56D
		public bool HasAttributes()
		{
			return this._attributes != null && this._attributes.Count > 0;
		}

		// Token: 0x06000785 RID: 1925 RVA: 0x0000F387 File Offset: 0x0000D587
		public bool HasAttribute(string attribute)
		{
			return this._attributes != null && this._attributes.ContainsKey(attribute);
		}

		// Token: 0x06000786 RID: 1926 RVA: 0x0000F39F File Offset: 0x0000D59F
		public string TryGetAttribute(string attribute, string defaultValue = null)
		{
			if (this._attributes != null && this._attributes.ContainsKey(attribute))
			{
				return this._attributes[attribute];
			}
			return defaultValue;
		}

		// Token: 0x06000787 RID: 1927 RVA: 0x0000F3C5 File Offset: 0x0000D5C5
		public override string ToString()
		{
			return HtmlTag.smethod_0(<Module>.smethod_25<string>(3558123108U), this._name);
		}

		// Token: 0x06000788 RID: 1928 RVA: 0x0000CD57 File Offset: 0x0000AF57
		static string smethod_0(string string_0, object object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x040002A9 RID: 681
		private readonly string _name;

		// Token: 0x040002AA RID: 682
		private readonly bool _isSingle;

		// Token: 0x040002AB RID: 683
		private readonly Dictionary<string, string> _attributes;
	}
}
