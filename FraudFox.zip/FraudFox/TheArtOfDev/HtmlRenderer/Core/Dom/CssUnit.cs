﻿using System;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x02000086 RID: 134
	internal enum CssUnit
	{
		// Token: 0x0400029E RID: 670
		None,
		// Token: 0x0400029F RID: 671
		Ems,
		// Token: 0x040002A0 RID: 672
		Pixels,
		// Token: 0x040002A1 RID: 673
		Ex,
		// Token: 0x040002A2 RID: 674
		Inches,
		// Token: 0x040002A3 RID: 675
		Centimeters,
		// Token: 0x040002A4 RID: 676
		Milimeters,
		// Token: 0x040002A5 RID: 677
		Points,
		// Token: 0x040002A6 RID: 678
		Picas
	}
}
