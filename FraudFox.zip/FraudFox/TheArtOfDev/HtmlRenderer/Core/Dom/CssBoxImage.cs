﻿using System;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Handlers;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x0200007D RID: 125
	internal sealed class CssBoxImage : CssBox
	{
		// Token: 0x060006D4 RID: 1748 RVA: 0x0000EEB9 File Offset: 0x0000D0B9
		public CssBoxImage(CssBox parent, HtmlTag tag)
			: base(parent, tag)
		{
			this._imageWord = new CssRectImage(this);
			base.Words.Add(this._imageWord);
		}

		// Token: 0x17000108 RID: 264
		// (get) Token: 0x060006D5 RID: 1749 RVA: 0x0000EEE0 File Offset: 0x0000D0E0
		public RImage Image
		{
			get
			{
				return this._imageWord.Image;
			}
		}

		// Token: 0x060006D6 RID: 1750 RVA: 0x0003B72C File Offset: 0x0003992C
		protected override void PaintImp(RGraphics g)
		{
			if (this._imageLoadHandler == null)
			{
				this._imageLoadHandler = new ImageLoadHandler(base.HtmlContainer, new ActionInt<RImage, RRect, bool>(this.OnLoadImageComplete));
				this._imageLoadHandler.LoadImage(base.GetAttribute(<Module>.smethod_25<string>(614955292U)), (base.HtmlTag != null) ? base.HtmlTag.Attributes : null);
			}
			RRect firstValueOrDefault = CommonUtils.GetFirstValueOrDefault<CssLineBox, RRect>(base.Rectangles, default(RRect));
			RPoint scrollOffset = base.HtmlContainer.ScrollOffset;
			firstValueOrDefault.Offset(scrollOffset);
			bool flag = RenderUtils.ClipGraphicsByOverflow(g, this);
			base.PaintBackground(g, firstValueOrDefault, true, true);
			BordersDrawHandler.DrawBoxBorders(g, this, firstValueOrDefault, true, true);
			RRect rectangle = this._imageWord.Rectangle;
			rectangle.Offset(scrollOffset);
			rectangle.Height -= base.ActualBorderTopWidth + base.ActualBorderBottomWidth + base.ActualPaddingTop + base.ActualPaddingBottom;
			rectangle.Y += base.ActualBorderTopWidth + base.ActualPaddingTop;
			rectangle.X = CssBoxImage.smethod_25(rectangle.X);
			rectangle.Y = CssBoxImage.smethod_25(rectangle.Y);
			if (this._imageWord.Image != null)
			{
				if (rectangle.Width > 0.0 && rectangle.Height > 0.0)
				{
					if (this._imageWord.ImageRectangle == RRect.Empty)
					{
						g.DrawImage(this._imageWord.Image, rectangle);
					}
					else
					{
						g.DrawImage(this._imageWord.Image, rectangle, this._imageWord.ImageRectangle);
					}
					if (this._imageWord.Selected)
					{
						g.DrawRectangle(base.GetSelectionBackBrush(g, true), this._imageWord.Left + scrollOffset.X, this._imageWord.Top + scrollOffset.Y, this._imageWord.Width + 2.0, DomUtils.GetCssLineBoxByWord(this._imageWord).LineHeight);
					}
				}
			}
			else if (!this._imageLoadingComplete)
			{
				RenderUtils.DrawImageLoadingIcon(g, base.HtmlContainer, rectangle);
				if (rectangle.Width > 19.0 && rectangle.Height > 19.0)
				{
					g.DrawRectangle(g.GetPen(RColor.LightGray), rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height);
				}
			}
			else if (this._imageLoadingComplete && rectangle.Width > 19.0 && rectangle.Height > 19.0)
			{
				RenderUtils.DrawImageErrorIcon(g, base.HtmlContainer, rectangle);
			}
			if (flag)
			{
				g.PopClip();
			}
		}

		// Token: 0x060006D7 RID: 1751 RVA: 0x0003B9F4 File Offset: 0x00039BF4
		internal override void MeasureWordsSize(RGraphics g)
		{
			if (!this._wordsSizeMeasured)
			{
				if (this._imageLoadHandler == null && (base.HtmlContainer.AvoidAsyncImagesLoading || base.HtmlContainer.AvoidImagesLateLoading))
				{
					this._imageLoadHandler = new ImageLoadHandler(base.HtmlContainer, new ActionInt<RImage, RRect, bool>(this.OnLoadImageComplete));
					this._imageLoadHandler.LoadImage(base.GetAttribute(<Module>.smethod_23<string>(1525630995U)), (base.HtmlTag != null) ? base.HtmlTag.Attributes : null);
				}
				base.MeasureWordSpacing(g);
				this._wordsSizeMeasured = true;
			}
			CssLayoutEngine.MeasureImageSize(this._imageWord);
		}

		// Token: 0x060006D8 RID: 1752 RVA: 0x0000EEED File Offset: 0x0000D0ED
		public override void Dispose()
		{
			if (this._imageLoadHandler != null)
			{
				this._imageLoadHandler.Dispose();
			}
			base.Dispose();
		}

		// Token: 0x060006D9 RID: 1753 RVA: 0x0003BA94 File Offset: 0x00039C94
		private void SetErrorBorder()
		{
			base.SetAllBorders(<Module>.smethod_26<string>(2202100248U), <Module>.smethod_24<string>(4004271310U), <Module>.smethod_27<string>(1294081165U));
			base.BorderRightColor = (base.BorderBottomColor = <Module>.smethod_24<string>(1741703069U));
		}

		// Token: 0x060006DA RID: 1754 RVA: 0x0003BAE0 File Offset: 0x00039CE0
		private void OnLoadImageComplete(RImage image, RRect rectangle, bool async)
		{
			this._imageWord.Image = image;
			this._imageWord.ImageRectangle = rectangle;
			this._imageLoadingComplete = true;
			this._wordsSizeMeasured = false;
			if (this._imageLoadingComplete && image == null)
			{
				this.SetErrorBorder();
			}
			if (!base.HtmlContainer.AvoidImagesLateLoading || async)
			{
				CssLength cssLength = new CssLength(base.Width);
				CssLength cssLength2 = new CssLength(base.Height);
				bool flag = cssLength.Number <= 0.0 || cssLength.Unit != CssUnit.Pixels || cssLength2.Number <= 0.0 || cssLength2.Unit != CssUnit.Pixels;
				base.HtmlContainer.RequestRefresh(flag);
			}
		}

		// Token: 0x060006DB RID: 1755 RVA: 0x0000EE64 File Offset: 0x0000D064
		static double smethod_25(double double_0)
		{
			return Math.Floor(double_0);
		}

		// Token: 0x0400027A RID: 634
		private readonly CssRectImage _imageWord;

		// Token: 0x0400027B RID: 635
		private ImageLoadHandler _imageLoadHandler;

		// Token: 0x0400027C RID: 636
		private bool _imageLoadingComplete;
	}
}
