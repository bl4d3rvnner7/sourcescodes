﻿using System;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x02000084 RID: 132
	internal sealed class CssRectWord : CssRect
	{
		// Token: 0x0600076C RID: 1900 RVA: 0x0000F29C File Offset: 0x0000D49C
		public CssRectWord(CssBox owner, string text, bool hasSpaceBefore, bool hasSpaceAfter)
			: base(owner)
		{
			this._text = text;
			this._hasSpaceBefore = hasSpaceBefore;
			this._hasSpaceAfter = hasSpaceAfter;
		}

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x0600076D RID: 1901 RVA: 0x0000F2BB File Offset: 0x0000D4BB
		public override bool HasSpaceBefore
		{
			get
			{
				return this._hasSpaceBefore;
			}
		}

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x0600076E RID: 1902 RVA: 0x0000F2C3 File Offset: 0x0000D4C3
		public override bool HasSpaceAfter
		{
			get
			{
				return this._hasSpaceAfter;
			}
		}

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x0600076F RID: 1903 RVA: 0x0003F850 File Offset: 0x0003DA50
		public override bool IsSpaces
		{
			get
			{
				string text = this.Text;
				int num = 0;
				for (;;)
				{
					IL_0069:
					int num2 = ((num >= CssRectWord.smethod_5(text)) ? 1308336159 : 1308336155);
					for (;;)
					{
						switch (num2 ^ 1308336158)
						{
						case 0:
							goto IL_0069;
						case 2:
						{
							char c;
							if (!char.IsWhiteSpace(c))
							{
								goto Block_1;
							}
							goto IL_0021;
						}
						case 3:
							num2 = 1308336155;
							continue;
						case 4:
							goto IL_0021;
						case 5:
						{
							char c = CssRectWord.smethod_4(text, num);
							num2 = 1308336156;
							continue;
						}
						}
						return true;
						IL_0021:
						num++;
						num2 = 1308336158;
					}
				}
				Block_1:
				return false;
			}
		}

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x06000770 RID: 1904 RVA: 0x0000F2CB File Offset: 0x0000D4CB
		public override bool IsLineBreak
		{
			get
			{
				return CssRectWord.smethod_6(this.Text, <Module>.smethod_23<string>(287085070U));
			}
		}

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x06000771 RID: 1905 RVA: 0x0000F2E2 File Offset: 0x0000D4E2
		public override string Text
		{
			get
			{
				return this._text;
			}
		}

		// Token: 0x06000772 RID: 1906 RVA: 0x0003F8D8 File Offset: 0x0003DAD8
		public override string ToString()
		{
			return CssRectWord.smethod_9(<Module>.smethod_26<string>(695444534U), CssRectWord.smethod_8(CssRectWord.smethod_7(this.Text, ' ', '-'), <Module>.smethod_23<string>(287085070U), <Module>.smethod_24<string>(2260981209U)), CssRectWord.smethod_5(this.Text), (CssRectWord.smethod_5(this.Text) != 1) ? <Module>.smethod_25<string>(3467122241U) : string.Empty);
		}

		// Token: 0x06000773 RID: 1907 RVA: 0x0000EE2F File Offset: 0x0000D02F
		static char smethod_4(string string_0, int int_0)
		{
			return string_0[int_0];
		}

		// Token: 0x06000774 RID: 1908 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_5(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06000775 RID: 1909 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_6(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06000776 RID: 1910 RVA: 0x0000CD69 File Offset: 0x0000AF69
		static string smethod_7(string string_0, char char_0, char char_1)
		{
			return string_0.Replace(char_0, char_1);
		}

		// Token: 0x06000777 RID: 1911 RVA: 0x0000C689 File Offset: 0x0000A889
		static string smethod_8(string string_0, string string_1, string string_2)
		{
			return string_0.Replace(string_1, string_2);
		}

		// Token: 0x06000778 RID: 1912 RVA: 0x0000CD96 File Offset: 0x0000AF96
		static string smethod_9(string string_0, object object_0, object object_1, object object_2)
		{
			return string.Format(string_0, object_0, object_1, object_2);
		}

		// Token: 0x04000297 RID: 663
		private readonly string _text;

		// Token: 0x04000298 RID: 664
		private readonly bool _hasSpaceBefore;

		// Token: 0x04000299 RID: 665
		private readonly bool _hasSpaceAfter;
	}
}
