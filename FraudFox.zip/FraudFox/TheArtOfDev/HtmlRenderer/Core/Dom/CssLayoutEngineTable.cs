﻿using System;
using System.Collections.Generic;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Entities;
using TheArtOfDev.HtmlRenderer.Core.Parse;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x0200007F RID: 127
	internal sealed class CssLayoutEngineTable
	{
		// Token: 0x060006F3 RID: 1779 RVA: 0x0000EF11 File Offset: 0x0000D111
		private CssLayoutEngineTable(CssBox tableBox)
		{
			this._tableBox = tableBox;
		}

		// Token: 0x060006F4 RID: 1780 RVA: 0x0003D26C File Offset: 0x0003B46C
		public static double GetTableSpacing(CssBox tableBox)
		{
			int num = 0;
			int num2 = 0;
			foreach (CssBox cssBox in tableBox.Boxes)
			{
				if (!CssLayoutEngineTable.smethod_0(cssBox.Display, <Module>.smethod_24<string>(542079785U)))
				{
					if (CssLayoutEngineTable.smethod_0(cssBox.Display, <Module>.smethod_25<string>(465058679U)))
					{
						using (List<CssBox>.Enumerator enumerator2 = tableBox.Boxes.GetEnumerator())
						{
							while (enumerator2.MoveNext())
							{
								CssBox cssBox2 = enumerator2.Current;
								num++;
								if (CssLayoutEngineTable.smethod_0(cssBox2.Display, <Module>.smethod_26<string>(2483813407U)))
								{
									num2 = CssLayoutEngineTable.smethod_1(num2, cssBox2.Boxes.Count);
								}
							}
							goto IL_00E8;
						}
					}
					if (CssLayoutEngineTable.smethod_0(cssBox.Display, <Module>.smethod_24<string>(2574478840U)))
					{
						num++;
						num2 = CssLayoutEngineTable.smethod_1(num2, cssBox.Boxes.Count);
					}
				}
				else
				{
					num2 += CssLayoutEngineTable.GetSpan(cssBox);
				}
				IL_00E8:
				if (num > 30)
				{
					break;
				}
			}
			return (double)(num2 + 1) * CssLayoutEngineTable.GetHorizontalSpacing(tableBox);
		}

		// Token: 0x060006F5 RID: 1781 RVA: 0x0003D3AC File Offset: 0x0003B5AC
		public static void PerformLayout(RGraphics g, CssBox tableBox)
		{
			ArgChecker.AssertArgNotNull(g, <Module>.smethod_25<string>(2503459606U));
			ArgChecker.AssertArgNotNull(tableBox, <Module>.smethod_25<string>(952240850U));
			try
			{
				CssLayoutEngineTable cssLayoutEngineTable = new CssLayoutEngineTable(tableBox);
				cssLayoutEngineTable.Layout(g);
			}
			catch (Exception ex)
			{
				for (;;)
				{
					IL_006A:
					int num = 1247111610;
					for (;;)
					{
						switch (num ^ 1247111608)
						{
						case 0:
							goto IL_006A;
						case 2:
							tableBox.HtmlContainer.ReportError(HtmlRenderErrorType.Layout, <Module>.smethod_24<string>(2628337401U), ex);
							num = 1247111609;
							continue;
						}
						goto Block_4;
					}
				}
				Block_4:;
			}
		}

		// Token: 0x060006F6 RID: 1782 RVA: 0x0003D43C File Offset: 0x0003B63C
		private void Layout(RGraphics g)
		{
			CssLayoutEngineTable.MeasureWords(this._tableBox, g);
			this.AssignBoxKinds();
			this.InsertEmptyBoxes();
			double num = this.CalculateCountAndWidth();
			this.DetermineMissingColumnWidths(num);
			this.EnforceMinimumSize();
			this.EnforceMaximumSize();
			this._tableBox.PaddingLeft = (this._tableBox.PaddingTop = (this._tableBox.PaddingRight = (this._tableBox.PaddingBottom = <Module>.smethod_26<string>(222203495U))));
			this.LayoutCells(g);
		}

		// Token: 0x060006F7 RID: 1783 RVA: 0x0003D4C4 File Offset: 0x0003B6C4
		private void AssignBoxKinds()
		{
			foreach (CssBox cssBox in this._tableBox.Boxes)
			{
				string display;
				if ((display = cssBox.Display) != null)
				{
					if (<PrivateImplementationDetails>{6C443CB5-C2FB-4195-951F-C3363AAEEE4E}.$$method0x6000130-1 == null)
					{
						<PrivateImplementationDetails>{6C443CB5-C2FB-4195-951F-C3363AAEEE4E}.$$method0x6000130-1 = new Dictionary<string, int>(7)
						{
							{
								<Module>.smethod_26<string>(1788734378U),
								0
							},
							{
								<Module>.smethod_25<string>(1230630662U),
								1
							},
							{
								<Module>.smethod_25<string>(465058679U),
								2
							},
							{
								<Module>.smethod_26<string>(3950582617U),
								3
							},
							{
								<Module>.smethod_24<string>(3495155584U),
								4
							},
							{
								<Module>.smethod_23<string>(1511957372U),
								5
							},
							{
								<Module>.smethod_25<string>(3596944064U),
								6
							}
						};
					}
					int num;
					if (<PrivateImplementationDetails>{6C443CB5-C2FB-4195-951F-C3363AAEEE4E}.$$method0x6000130-1.TryGetValue(display, out num))
					{
						switch (num)
						{
						case 0:
							this._caption = cssBox;
							continue;
						case 1:
							this._bodyrows.Add(cssBox);
							continue;
						case 2:
						{
							using (List<CssBox>.Enumerator enumerator2 = cssBox.Boxes.GetEnumerator())
							{
								while (enumerator2.MoveNext())
								{
									CssBox cssBox2 = enumerator2.Current;
									if (CssLayoutEngineTable.smethod_0(cssBox2.Display, <Module>.smethod_27<string>(3216664285U)))
									{
										this._bodyrows.Add(cssBox2);
									}
								}
								continue;
							}
							break;
						}
						case 3:
							break;
						case 4:
							if (this._footerBox != null)
							{
								this._bodyrows.Add(cssBox);
								continue;
							}
							this._footerBox = cssBox;
							continue;
						case 5:
						{
							for (int i = 0; i < CssLayoutEngineTable.GetSpan(cssBox); i++)
							{
								this._columns.Add(cssBox);
							}
							continue;
						}
						case 6:
							if (cssBox.Boxes.Count == 0)
							{
								int span = CssLayoutEngineTable.GetSpan(cssBox);
								for (int j = 0; j < span; j++)
								{
									this._columns.Add(cssBox);
								}
								continue;
							}
							foreach (CssBox cssBox3 in cssBox.Boxes)
							{
								int span2 = CssLayoutEngineTable.GetSpan(cssBox3);
								for (int k = 0; k < span2; k++)
								{
									this._columns.Add(cssBox3);
								}
							}
							continue;
						default:
							continue;
						}
						if (this._headerBox != null)
						{
							this._bodyrows.Add(cssBox);
						}
						else
						{
							this._headerBox = cssBox;
						}
					}
				}
			}
			if (this._headerBox != null)
			{
				this._allRows.AddRange(this._headerBox.Boxes);
			}
			this._allRows.AddRange(this._bodyrows);
			if (this._footerBox != null)
			{
				this._allRows.AddRange(this._footerBox.Boxes);
			}
		}

		// Token: 0x060006F8 RID: 1784 RVA: 0x0003D7F4 File Offset: 0x0003B9F4
		private void InsertEmptyBoxes()
		{
			if (!this._tableBox._tableFixed)
			{
				int num = 0;
				List<CssBox> bodyrows = this._bodyrows;
				foreach (CssBox cssBox in bodyrows)
				{
					for (int i = 0; i < cssBox.Boxes.Count; i++)
					{
						CssBox cssBox2 = cssBox.Boxes[i];
						int rowSpan = CssLayoutEngineTable.GetRowSpan(cssBox2);
						int num2 = CssLayoutEngineTable.GetCellRealColumnIndex(cssBox, cssBox2);
						for (int j = num + 1; j < num + rowSpan; j++)
						{
							if (bodyrows.Count > j)
							{
								int num3 = 0;
								for (int k = 0; k < bodyrows[j].Boxes.Count; k++)
								{
									if (num3 == num2)
									{
										bodyrows[j].Boxes.Insert(num3, new CssSpacingBox(this._tableBox, ref cssBox2, num));
										break;
									}
									num3++;
									num2 -= CssLayoutEngineTable.GetColSpan(bodyrows[j].Boxes[k]) - 1;
								}
							}
						}
					}
					num++;
				}
				this._tableBox._tableFixed = true;
			}
		}

		// Token: 0x060006F9 RID: 1785 RVA: 0x0003D948 File Offset: 0x0003BB48
		private double CalculateCountAndWidth()
		{
			if (this._columns.Count > 0)
			{
				this._columnCount = this._columns.Count;
			}
			else
			{
				foreach (CssBox cssBox in this._allRows)
				{
					this._columnCount = CssLayoutEngineTable.smethod_1(this._columnCount, cssBox.Boxes.Count);
				}
			}
			this._columnWidths = new double[this._columnCount];
			for (int i = 0; i < this._columnWidths.Length; i++)
			{
				this._columnWidths[i] = double.NaN;
			}
			double availableCellWidth = this.GetAvailableCellWidth();
			if (this._columns.Count > 0)
			{
				for (int j = 0; j < this._columns.Count; j++)
				{
					CssLength cssLength = new CssLength(this._columns[j].Width);
					if (cssLength.Number > 0.0)
					{
						if (cssLength.IsPercentage)
						{
							this._columnWidths[j] = CssValueParser.ParseNumber(this._columns[j].Width, availableCellWidth);
						}
						else
						{
							if (cssLength.Unit != CssUnit.Pixels)
							{
								if (cssLength.Unit != CssUnit.None)
								{
									goto IL_013E;
								}
							}
							this._columnWidths[j] = cssLength.Number;
						}
					}
					IL_013E:;
				}
			}
			else
			{
				foreach (CssBox cssBox2 in this._allRows)
				{
					for (int k = 0; k < this._columnCount; k++)
					{
						if ((k < 20 || double.IsNaN(this._columnWidths[k])) && k < cssBox2.Boxes.Count && CssLayoutEngineTable.smethod_0(cssBox2.Boxes[k].Display, <Module>.smethod_23<string>(3933942142U)))
						{
							double num = CssValueParser.ParseLength(cssBox2.Boxes[k].Width, availableCellWidth, cssBox2.Boxes[k], false);
							if (num > 0.0)
							{
								int colSpan = CssLayoutEngineTable.GetColSpan(cssBox2.Boxes[k]);
								num /= (double)CssLayoutEngineTable.smethod_2(colSpan);
								for (int l = k; l < k + colSpan; l++)
								{
									this._columnWidths[l] = (double.IsNaN(this._columnWidths[l]) ? num : CssLayoutEngineTable.smethod_3(this._columnWidths[l], num));
								}
							}
						}
					}
				}
			}
			return availableCellWidth;
		}

		// Token: 0x060006FA RID: 1786 RVA: 0x0003DC28 File Offset: 0x0003BE28
		private void DetermineMissingColumnWidths(double availCellSpace)
		{
			double num = 0.0;
			if (!this._widthSpecified)
			{
				double[] array;
				double[] array2;
				this.GetColumnsMinMaxWidthByContent(true, out array, out array2);
				for (int i = 0; i < this._columnWidths.Length; i++)
				{
					if (double.IsNaN(this._columnWidths[i]))
					{
						this._columnWidths[i] = array[i];
					}
					num += this._columnWidths[i];
				}
				for (int j = 0; j < this._columnWidths.Length; j++)
				{
					if (array2[j] > this._columnWidths[j])
					{
						double num2 = this._columnWidths[j];
						this._columnWidths[j] = CssLayoutEngineTable.smethod_4(this._columnWidths[j] + (availCellSpace - num) / (double)CssLayoutEngineTable.smethod_2(this._columnWidths.Length - j), array2[j]);
						num = num + this._columnWidths[j] - num2;
					}
				}
			}
			else
			{
				int num3 = 0;
				foreach (double num4 in this._columnWidths)
				{
					if (double.IsNaN(num4))
					{
						num3++;
					}
					else
					{
						num += num4;
					}
				}
				int num5 = num3;
				double[] array3 = null;
				if (num3 < this._columnWidths.Length)
				{
					array3 = new double[this._columnWidths.Length];
					for (int l = 0; l < this._columnWidths.Length; l++)
					{
						array3[l] = this._columnWidths[l];
					}
				}
				if (num3 > 0)
				{
					double[] array4;
					double[] array5;
					this.GetColumnsMinMaxWidthByContent(true, out array4, out array5);
					int num6;
					do
					{
						num6 = num3;
						for (int m = 0; m < this._columnWidths.Length; m++)
						{
							double num7 = (availCellSpace - num) / (double)num3;
							if (double.IsNaN(this._columnWidths[m]) && num7 > array5[m])
							{
								this._columnWidths[m] = array5[m];
								num3--;
								num += array5[m];
							}
						}
					}
					while (num6 != num3);
					if (num3 > 0)
					{
						double num8 = (availCellSpace - num) / (double)num3;
						for (int n = 0; n < this._columnWidths.Length; n++)
						{
							if (double.IsNaN(this._columnWidths[n]))
							{
								this._columnWidths[n] = num8;
							}
						}
					}
				}
				if (num3 == 0 && num < availCellSpace)
				{
					if (num5 <= 0)
					{
						for (int num9 = 0; num9 < this._columnWidths.Length; num9++)
						{
							this._columnWidths[num9] += (availCellSpace - num) * (this._columnWidths[num9] / num);
						}
						return;
					}
					double num10 = (availCellSpace - num) / (double)num5;
					for (int num11 = 0; num11 < this._columnWidths.Length; num11++)
					{
						if (array3 == null || double.IsNaN(array3[num11]))
						{
							this._columnWidths[num11] += num10;
						}
					}
					return;
				}
			}
		}

		// Token: 0x060006FB RID: 1787 RVA: 0x0003DEC0 File Offset: 0x0003C0C0
		private void EnforceMaximumSize()
		{
			int num = 0;
			double num2 = this.GetWidthSum();
			while (num2 > this.GetAvailableTableWidth())
			{
				if (!this.CanReduceWidth())
				{
					break;
				}
				while (!this.CanReduceWidth(num))
				{
					num++;
				}
				this._columnWidths[num] -= 1.0;
				num++;
				if (num >= this._columnWidths.Length)
				{
					num = 0;
				}
			}
			double maxTableWidth = this.GetMaxTableWidth();
			if (maxTableWidth < 90999.0)
			{
				num2 = this.GetWidthSum();
				if (maxTableWidth < num2)
				{
					double[] array;
					double[] array2;
					this.GetColumnsMinMaxWidthByContent(false, out array, out array2);
					for (int i = 0; i < this._columnWidths.Length; i++)
					{
						this._columnWidths[i] = array[i];
					}
					num2 = this.GetWidthSum();
					if (maxTableWidth >= num2)
					{
						int num3 = 0;
						while (num3 < 15 && maxTableWidth > num2 + 0.1)
						{
							int num4 = 0;
							for (int j = 0; j < this._columnWidths.Length; j++)
							{
								if (this._columnWidths[j] + 1.0 < array2[j])
								{
									num4++;
								}
							}
							if (num4 == 0)
							{
								num4 = this._columnWidths.Length;
							}
							bool flag = false;
							double num5 = (maxTableWidth - num2) / (double)num4;
							for (int k = 0; k < this._columnWidths.Length; k++)
							{
								if (this._columnWidths[k] + 0.1 < array2[k])
								{
									num5 = CssLayoutEngineTable.smethod_4(num5, array2[k] - this._columnWidths[k]);
									flag = true;
								}
							}
							for (int l = 0; l < this._columnWidths.Length; l++)
							{
								if (!flag || this._columnWidths[l] + 1.0 < array2[l])
								{
									this._columnWidths[l] += num5;
								}
							}
							num2 = this.GetWidthSum();
							num3++;
						}
					}
					else
					{
						for (int m = 0; m < 15; m++)
						{
							if (maxTableWidth >= num2 - 0.1)
							{
								return;
							}
							int num6 = 0;
							double num7 = 0.0;
							double num8 = 0.0;
							for (int n = 0; n < this._columnWidths.Length; n++)
							{
								if (this._columnWidths[n] > num7 + 0.1)
								{
									num8 = num7;
									num7 = this._columnWidths[n];
									num6 = 1;
								}
								else if (this._columnWidths[n] > num7 - 0.1)
								{
									num6++;
								}
							}
							double num9 = ((num8 > 0.0) ? (num7 - num8) : ((num2 - maxTableWidth) / (double)this._columnWidths.Length));
							if (num9 * (double)num6 > num2 - maxTableWidth)
							{
								num9 = (num2 - maxTableWidth) / (double)num6;
							}
							for (int num10 = 0; num10 < this._columnWidths.Length; num10++)
							{
								if (this._columnWidths[num10] > num7 - 0.1)
								{
									this._columnWidths[num10] -= num9;
								}
							}
							num2 = this.GetWidthSum();
						}
					}
				}
			}
		}

		// Token: 0x060006FC RID: 1788 RVA: 0x0003E1C4 File Offset: 0x0003C3C4
		private void EnforceMinimumSize()
		{
			foreach (CssBox cssBox in this._allRows)
			{
				foreach (CssBox cssBox2 in cssBox.Boxes)
				{
					int colSpan = CssLayoutEngineTable.GetColSpan(cssBox2);
					int cellRealColumnIndex = CssLayoutEngineTable.GetCellRealColumnIndex(cssBox, cssBox2);
					int num = cellRealColumnIndex + colSpan - 1;
					if (this._columnWidths.Length > cellRealColumnIndex && this._columnWidths[cellRealColumnIndex] < this.GetColumnMinWidths()[cellRealColumnIndex])
					{
						double num2 = this.GetColumnMinWidths()[cellRealColumnIndex] - this._columnWidths[cellRealColumnIndex];
						this._columnWidths[num] = this.GetColumnMinWidths()[num];
						if (cellRealColumnIndex < this._columnWidths.Length - 1)
						{
							this._columnWidths[cellRealColumnIndex + 1] -= num2;
						}
					}
				}
			}
		}

		// Token: 0x060006FD RID: 1789 RVA: 0x0003E2E0 File Offset: 0x0003C4E0
		private void LayoutCells(RGraphics g)
		{
			double num = CssLayoutEngineTable.smethod_3(this._tableBox.ClientLeft + this.GetHorizontalSpacing(), 0.0);
			double num4;
			double num6;
			double num8;
			for (;;)
			{
				IL_045B:
				int num2 = -1614680938;
				for (;;)
				{
					double num3;
					int num5;
					CssBox cssBox;
					double num7;
					CssBox cssBox2;
					int num10;
					int num11;
					double num12;
					switch (num2 ^ -1614680941)
					{
					case 0:
					{
						double widthSum;
						num3 = num + (this.GetAvailableTableWidth() - widthSum) / 2.0;
						break;
					}
					case 1:
						num4 = 0.0;
						num2 = -1614680935;
						continue;
					case 2:
					{
						CssSpacingBox cssSpacingBox;
						if (cssSpacingBox.EndRow == num5)
						{
							num4 = CssLayoutEngineTable.smethod_3(num4, cssSpacingBox.ExtendedBox.ActualBottom);
							num2 = -1614680932;
							continue;
						}
						goto IL_00E9;
					}
					case 3:
					{
						CssSpacingBox cssSpacingBox;
						num2 = ((cssSpacingBox != null) ? (-1614680943) : (-1614680937));
						continue;
					}
					case 4:
					{
						int rowSpan;
						if (rowSpan == 1)
						{
							num4 = CssLayoutEngineTable.smethod_3(num4, cssBox.ActualBottom);
							num2 = -1614680955;
							continue;
						}
						goto IL_00E9;
					}
					case 5:
						num6 = CssLayoutEngineTable.smethod_3(this._tableBox.ClientTop + this.GetVerticalSpacing(), 0.0);
						num7 = num6;
						num8 = num;
						num2 = -1614680942;
						continue;
					case 6:
					{
						int num9;
						cssBox = cssBox2.Boxes[num9];
						num2 = ((num10 >= this._columnWidths.Length) ? (-1614680934) : (-1614680960));
						continue;
					}
					case 7:
						num11 = 0;
						num2 = -1614680957;
						continue;
					case 8:
						goto IL_045B;
					case 9:
						goto IL_024E;
					case 10:
						num5 = 0;
						num2 = ((!CssLayoutEngineTable.smethod_0(this._tableBox.TextAlign, <Module>.smethod_24<string>(434362663U))) ? (-1614680929) : (-1614680956));
						continue;
					case 11:
					{
						CssSpacingBox cssSpacingBox = cssBox as CssSpacingBox;
						num2 = -1614680944;
						continue;
					}
					case 12:
						num2 = (CssLayoutEngineTable.smethod_0(this._tableBox.TextAlign, <Module>.smethod_24<string>(840842474U)) ? (-1614680956) : (-1614680940));
						continue;
					case 13:
					{
						int cellRealColumnIndex;
						double cellWidth = this.GetCellWidth(cellRealColumnIndex, cssBox);
						num2 = -1614680950;
						continue;
					}
					case 14:
						num2 = -1614680949;
						continue;
					case 15:
						num2 = -1614680955;
						continue;
					case 16:
						goto IL_019A;
					case 17:
					{
						num10++;
						num12 = cssBox.ActualRight + this.GetHorizontalSpacing();
						int num9;
						num9++;
						num2 = -1614680949;
						continue;
					}
					case 18:
						goto IL_0155;
					case 19:
					{
						int rowSpan = CssLayoutEngineTable.GetRowSpan(cssBox);
						int cellRealColumnIndex = CssLayoutEngineTable.GetCellRealColumnIndex(cssBox2, cssBox);
						num2 = -1614680930;
						continue;
					}
					case 20:
					{
						double cellWidth;
						cssBox.Size = new RSize(cellWidth, 0.0);
						cssBox.PerformLayout(g);
						num2 = -1614680936;
						continue;
					}
					case 21:
					{
						int num9 = 0;
						num2 = -1614680931;
						continue;
					}
					case 22:
						goto IL_00E9;
					case 23:
					{
						double widthSum = this.GetWidthSum();
						if (!CssLayoutEngineTable.smethod_0(this._tableBox.TextAlign, <Module>.smethod_26<string>(2646612105U)))
						{
							num2 = -1614680941;
							continue;
						}
						num3 = this.GetAvailableTableWidth() - widthSum;
						break;
					}
					case 24:
					{
						int num9;
						num2 = ((num9 >= cssBox2.Boxes.Count) ? (-1614680934) : (-1614680939));
						continue;
					}
					case 25:
						cssBox.Location = new RPoint(num12, num7);
						num2 = -1614680953;
						continue;
					default:
						goto IL_024E;
					}
					num = num3;
					this._tableBox.Location = new RPoint(num - this._tableBox.ActualBorderLeftWidth - this._tableBox.ActualPaddingLeft - this.GetHorizontalSpacing(), this._tableBox.Location.Y);
					num2 = -1614680940;
					continue;
					IL_00E9:
					num8 = CssLayoutEngineTable.smethod_3(num8, cssBox.ActualRight);
					num2 = -1614680958;
					continue;
					IL_0155:
					cssBox2 = this._allRows[num11];
					num12 = num;
					num10 = 0;
					num2 = -1614680954;
					continue;
					IL_019A:
					if (num11 >= this._allRows.Count)
					{
						goto Block_3;
					}
					goto IL_0155;
					IL_024E:
					foreach (CssBox cssBox3 in cssBox2.Boxes)
					{
						CssSpacingBox cssSpacingBox2 = cssBox3 as CssSpacingBox;
						if (cssSpacingBox2 == null && CssLayoutEngineTable.GetRowSpan(cssBox3) == 1)
						{
							cssBox3.ActualBottom = num4;
							CssLayoutEngine.ApplyCellVerticalAlignment(g, cssBox3);
						}
						else if (cssSpacingBox2 != null && cssSpacingBox2.EndRow == num5)
						{
							cssSpacingBox2.ExtendedBox.ActualBottom = num4;
							CssLayoutEngine.ApplyCellVerticalAlignment(g, cssSpacingBox2.ExtendedBox);
						}
					}
					num7 = num4 + this.GetVerticalSpacing();
					num5++;
					num11++;
					goto IL_019A;
				}
			}
			Block_3:
			num8 = CssLayoutEngineTable.smethod_3(num8, this._tableBox.Location.X + this._tableBox.ActualWidth);
			this._tableBox.ActualRight = num8 + this.GetHorizontalSpacing() + this._tableBox.ActualBorderRightWidth;
			this._tableBox.ActualBottom = CssLayoutEngineTable.smethod_3(num4, num6) + this.GetVerticalSpacing() + this._tableBox.ActualBorderBottomWidth;
		}

		// Token: 0x060006FE RID: 1790 RVA: 0x0003E7CC File Offset: 0x0003C9CC
		private double GetSpannedMinWidth(CssBox row, CssBox cell, int realcolindex, int colspan)
		{
			double num = 0.0;
			int num2 = realcolindex;
			for (;;)
			{
				if (num2 >= row.Boxes.Count)
				{
					if (num2 >= realcolindex + colspan - 1)
					{
						break;
					}
				}
				if (num2 < this.GetColumnMinWidths().Length)
				{
					num += this.GetColumnMinWidths()[num2];
				}
				num2++;
			}
			return num;
		}

		// Token: 0x060006FF RID: 1791 RVA: 0x0003E81C File Offset: 0x0003CA1C
		private static int GetCellRealColumnIndex(CssBox row, CssBox cell)
		{
			int num = 0;
			foreach (CssBox cssBox in row.Boxes)
			{
				if (CssLayoutEngineTable.smethod_5(cssBox, cell))
				{
					break;
				}
				num += CssLayoutEngineTable.GetColSpan(cssBox);
			}
			return num;
		}

		// Token: 0x06000700 RID: 1792 RVA: 0x0003E880 File Offset: 0x0003CA80
		private double GetCellWidth(int column, CssBox b)
		{
			double num = (double)CssLayoutEngineTable.smethod_2(CssLayoutEngineTable.GetColSpan(b));
			double num2 = 0.0;
			int num3 = column;
			while ((double)num3 < (double)column + num && column < this._columnWidths.Length && this._columnWidths.Length > num3)
			{
				num2 += this._columnWidths[num3];
				num3++;
			}
			return num2 + (num - 1.0) * this.GetHorizontalSpacing();
		}

		// Token: 0x06000701 RID: 1793 RVA: 0x0003E8EC File Offset: 0x0003CAEC
		private static int GetColSpan(CssBox b)
		{
			string attribute = b.GetAttribute(<Module>.smethod_26<string>(2541271771U), <Module>.smethod_24<string>(2505885337U));
			int num;
			if (!int.TryParse(attribute, out num))
			{
				return 1;
			}
			return num;
		}

		// Token: 0x06000702 RID: 1794 RVA: 0x0003E924 File Offset: 0x0003CB24
		private static int GetRowSpan(CssBox b)
		{
			string attribute = b.GetAttribute(<Module>.smethod_23<string>(2591250882U), <Module>.smethod_24<string>(2505885337U));
			int num;
			if (!int.TryParse(attribute, out num))
			{
				return 1;
			}
			return num;
		}

		// Token: 0x06000703 RID: 1795 RVA: 0x0003E95C File Offset: 0x0003CB5C
		private static void MeasureWords(CssBox box, RGraphics g)
		{
			if (box != null)
			{
				foreach (CssBox cssBox in box.Boxes)
				{
					cssBox.MeasureWordsSize(g);
					CssLayoutEngineTable.MeasureWords(cssBox, g);
				}
			}
		}

		// Token: 0x06000704 RID: 1796 RVA: 0x0003E9BC File Offset: 0x0003CBBC
		private bool CanReduceWidth()
		{
			for (int i = 0; i < this._columnWidths.Length; i++)
			{
				if (this.CanReduceWidth(i))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000705 RID: 1797 RVA: 0x0000EF41 File Offset: 0x0000D141
		private bool CanReduceWidth(int columnIndex)
		{
			return this._columnWidths.Length < columnIndex && this.GetColumnMinWidths().Length < columnIndex && this._columnWidths[columnIndex] > this.GetColumnMinWidths()[columnIndex];
		}

		// Token: 0x06000706 RID: 1798 RVA: 0x0003E9E8 File Offset: 0x0003CBE8
		private double GetAvailableTableWidth()
		{
			CssLength cssLength = new CssLength(this._tableBox.Width);
			if (cssLength.Number > 0.0)
			{
				this._widthSpecified = true;
				return CssValueParser.ParseLength(this._tableBox.Width, this._tableBox.ParentBox.AvailableWidth, this._tableBox, false);
			}
			return this._tableBox.ParentBox.AvailableWidth;
		}

		// Token: 0x06000707 RID: 1799 RVA: 0x0003EA58 File Offset: 0x0003CC58
		private double GetMaxTableWidth()
		{
			CssLength cssLength = new CssLength(this._tableBox.MaxWidth);
			if (cssLength.Number > 0.0)
			{
				this._widthSpecified = true;
				return CssValueParser.ParseLength(this._tableBox.MaxWidth, this._tableBox.ParentBox.AvailableWidth, this._tableBox, false);
			}
			return 9999.0;
		}

		// Token: 0x06000708 RID: 1800 RVA: 0x0003EAC0 File Offset: 0x0003CCC0
		private void GetColumnsMinMaxWidthByContent(bool onlyNans, out double[] minFullWidths, out double[] maxFullWidths)
		{
			maxFullWidths = new double[this._columnWidths.Length];
			minFullWidths = new double[this._columnWidths.Length];
			foreach (CssBox cssBox in this._allRows)
			{
				for (int i = 0; i < cssBox.Boxes.Count; i++)
				{
					int num = CssLayoutEngineTable.GetCellRealColumnIndex(cssBox, cssBox.Boxes[i]);
					num = ((this._columnWidths.Length > num) ? num : (this._columnWidths.Length - 1));
					if ((!onlyNans || double.IsNaN(this._columnWidths[num])) && i < cssBox.Boxes.Count)
					{
						double num2;
						double num3;
						cssBox.Boxes[i].GetMinMaxWidth(out num2, out num3);
						int colSpan = CssLayoutEngineTable.GetColSpan(cssBox.Boxes[i]);
						num2 /= (double)colSpan;
						num3 /= (double)colSpan;
						for (int j = 0; j < colSpan; j++)
						{
							minFullWidths[num + j] = CssLayoutEngineTable.smethod_3(minFullWidths[num + j], num2);
							maxFullWidths[num + j] = CssLayoutEngineTable.smethod_3(maxFullWidths[num + j], num3);
						}
					}
				}
			}
		}

		// Token: 0x06000709 RID: 1801 RVA: 0x0000EF6D File Offset: 0x0000D16D
		private double GetAvailableCellWidth()
		{
			return this.GetAvailableTableWidth() - this.GetHorizontalSpacing() * (double)(this._columnCount + 1) - this._tableBox.ActualBorderLeftWidth - this._tableBox.ActualBorderRightWidth;
		}

		// Token: 0x0600070A RID: 1802 RVA: 0x0003EC10 File Offset: 0x0003CE10
		private double GetWidthSum()
		{
			double num = 0.0;
			foreach (double num2 in this._columnWidths)
			{
				if (double.IsNaN(num2))
				{
					throw CssLayoutEngineTable.smethod_6(<Module>.smethod_27<string>(3210892745U));
				}
				num += num2;
			}
			num += this.GetHorizontalSpacing() * (double)(this._columnWidths.Length + 1);
			return num + (this._tableBox.ActualBorderLeftWidth + this._tableBox.ActualBorderRightWidth);
		}

		// Token: 0x0600070B RID: 1803 RVA: 0x0003EC90 File Offset: 0x0003CE90
		private static int GetSpan(CssBox b)
		{
			double num = CssValueParser.ParseNumber(b.GetAttribute(<Module>.smethod_25<string>(305788983U)), 1.0);
			return CssLayoutEngineTable.smethod_1(1, CssLayoutEngineTable.smethod_7(num));
		}

		// Token: 0x0600070C RID: 1804 RVA: 0x0003ECC8 File Offset: 0x0003CEC8
		private double[] GetColumnMinWidths()
		{
			if (this._columnMinWidths == null)
			{
				this._columnMinWidths = new double[this._columnWidths.Length];
				foreach (CssBox cssBox in this._allRows)
				{
					foreach (CssBox cssBox2 in cssBox.Boxes)
					{
						int colSpan = CssLayoutEngineTable.GetColSpan(cssBox2);
						int cellRealColumnIndex = CssLayoutEngineTable.GetCellRealColumnIndex(cssBox, cssBox2);
						int num = CssLayoutEngineTable.smethod_8(cellRealColumnIndex + colSpan, this._columnMinWidths.Length) - 1;
						double num2 = this.GetSpannedMinWidth(cssBox, cssBox2, cellRealColumnIndex, colSpan) + (double)(colSpan - 1) * this.GetHorizontalSpacing();
						this._columnMinWidths[num] = CssLayoutEngineTable.smethod_3(this._columnMinWidths[num], cssBox2.GetMinimumWidth() - num2);
					}
				}
			}
			return this._columnMinWidths;
		}

		// Token: 0x0600070D RID: 1805 RVA: 0x0000EF9E File Offset: 0x0000D19E
		private double GetHorizontalSpacing()
		{
			if (!CssLayoutEngineTable.smethod_0(this._tableBox.BorderCollapse, <Module>.smethod_26<string>(637986170U)))
			{
				return this._tableBox.ActualBorderSpacingHorizontal;
			}
			return -1.0;
		}

		// Token: 0x0600070E RID: 1806 RVA: 0x0000EFD1 File Offset: 0x0000D1D1
		private static double GetHorizontalSpacing(CssBox box)
		{
			if (!CssLayoutEngineTable.smethod_0(box.BorderCollapse, <Module>.smethod_26<string>(637986170U)))
			{
				return box.ActualBorderSpacingHorizontal;
			}
			return -1.0;
		}

		// Token: 0x0600070F RID: 1807 RVA: 0x0000EFFA File Offset: 0x0000D1FA
		private double GetVerticalSpacing()
		{
			if (!CssLayoutEngineTable.smethod_0(this._tableBox.BorderCollapse, <Module>.smethod_26<string>(637986170U)))
			{
				return this._tableBox.ActualBorderSpacingVertical;
			}
			return -1.0;
		}

		// Token: 0x06000710 RID: 1808 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_0(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06000711 RID: 1809 RVA: 0x0000F02D File Offset: 0x0000D22D
		static int smethod_1(int int_0, int int_1)
		{
			return Math.Max(int_0, int_1);
		}

		// Token: 0x06000712 RID: 1810 RVA: 0x0000F036 File Offset: 0x0000D236
		static float smethod_2(int int_0)
		{
			return Convert.ToSingle(int_0);
		}

		// Token: 0x06000713 RID: 1811 RVA: 0x0000ED6A File Offset: 0x0000CF6A
		static double smethod_3(double double_0, double double_1)
		{
			return Math.Max(double_0, double_1);
		}

		// Token: 0x06000714 RID: 1812 RVA: 0x0000EF08 File Offset: 0x0000D108
		static double smethod_4(double double_0, double double_1)
		{
			return Math.Min(double_0, double_1);
		}

		// Token: 0x06000715 RID: 1813 RVA: 0x0000ED73 File Offset: 0x0000CF73
		static bool smethod_5(object object_0, object object_1)
		{
			return object_0.Equals(object_1);
		}

		// Token: 0x06000716 RID: 1814 RVA: 0x0000C7DD File Offset: 0x0000A9DD
		static Exception smethod_6(string string_0)
		{
			return new Exception(string_0);
		}

		// Token: 0x06000717 RID: 1815 RVA: 0x0000F03E File Offset: 0x0000D23E
		static int smethod_7(double double_0)
		{
			return Convert.ToInt32(double_0);
		}

		// Token: 0x06000718 RID: 1816 RVA: 0x0000F046 File Offset: 0x0000D246
		static int smethod_8(int int_0, int int_1)
		{
			return Math.Min(int_0, int_1);
		}

		// Token: 0x0400027D RID: 637
		private readonly CssBox _tableBox;

		// Token: 0x0400027E RID: 638
		private CssBox _caption;

		// Token: 0x0400027F RID: 639
		private CssBox _headerBox;

		// Token: 0x04000280 RID: 640
		private CssBox _footerBox;

		// Token: 0x04000281 RID: 641
		private readonly List<CssBox> _bodyrows = new List<CssBox>();

		// Token: 0x04000282 RID: 642
		private readonly List<CssBox> _columns = new List<CssBox>();

		// Token: 0x04000283 RID: 643
		private readonly List<CssBox> _allRows = new List<CssBox>();

		// Token: 0x04000284 RID: 644
		private int _columnCount;

		// Token: 0x04000285 RID: 645
		private bool _widthSpecified;

		// Token: 0x04000286 RID: 646
		private double[] _columnWidths;

		// Token: 0x04000287 RID: 647
		private double[] _columnMinWidths;
	}
}
