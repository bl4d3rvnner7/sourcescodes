﻿using System;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x02000083 RID: 131
	internal sealed class CssRectImage : CssRect
	{
		// Token: 0x06000765 RID: 1893 RVA: 0x0000F265 File Offset: 0x0000D465
		public CssRectImage(CssBox owner)
			: base(owner)
		{
		}

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x06000766 RID: 1894 RVA: 0x0000F26E File Offset: 0x0000D46E
		// (set) Token: 0x06000767 RID: 1895 RVA: 0x0000F276 File Offset: 0x0000D476
		public override RImage Image
		{
			get
			{
				return this._image;
			}
			set
			{
				this._image = value;
			}
		}

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x06000768 RID: 1896 RVA: 0x0000ED8C File Offset: 0x0000CF8C
		public override bool IsImage
		{
			get
			{
				return true;
			}
		}

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x06000769 RID: 1897 RVA: 0x0000F27F File Offset: 0x0000D47F
		// (set) Token: 0x0600076A RID: 1898 RVA: 0x0000F287 File Offset: 0x0000D487
		public RRect ImageRectangle
		{
			get
			{
				return this._imageRectangle;
			}
			set
			{
				this._imageRectangle = value;
			}
		}

		// Token: 0x0600076B RID: 1899 RVA: 0x0000F290 File Offset: 0x0000D490
		public override string ToString()
		{
			return <Module>.smethod_25<string>(3327927335U);
		}

		// Token: 0x04000295 RID: 661
		private RImage _image;

		// Token: 0x04000296 RID: 662
		private RRect _imageRectangle;
	}
}
