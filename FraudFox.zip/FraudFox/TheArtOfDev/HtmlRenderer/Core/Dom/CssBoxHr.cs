﻿using System;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Handlers;
using TheArtOfDev.HtmlRenderer.Core.Parse;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x0200007C RID: 124
	internal sealed class CssBoxHr : CssBox
	{
		// Token: 0x060006CE RID: 1742 RVA: 0x0000EE9F File Offset: 0x0000D09F
		public CssBoxHr(CssBox parent, HtmlTag tag)
			: base(parent, tag)
		{
			base.Display = <Module>.smethod_26<string>(1300338284U);
		}

		// Token: 0x060006CF RID: 1743 RVA: 0x0003B374 File Offset: 0x00039574
		protected override void PerformLayoutImp(RGraphics g)
		{
			if (CssBoxHr.smethod_25(base.Display, <Module>.smethod_27<string>(1876627641U)))
			{
				return;
			}
			base.RectanglesReset();
			CssBox previousSibling = DomUtils.GetPreviousSibling(this);
			double num = base.ContainingBlock.Location.X + base.ContainingBlock.ActualPaddingLeft + base.ActualMarginLeft + base.ContainingBlock.ActualBorderLeftWidth;
			double num2 = ((previousSibling != null || base.ParentBox == null) ? ((base.ParentBox == null) ? base.Location.Y : 0.0) : base.ParentBox.ClientTop) + base.MarginTopCollapse(previousSibling) + ((previousSibling != null) ? (previousSibling.ActualBottom + previousSibling.ActualBorderBottomWidth) : 0.0);
			base.Location = new RPoint(num, num2);
			base.ActualBottom = num2;
			double minimumWidth = base.GetMinimumWidth();
			double num3 = base.ContainingBlock.Size.Width - base.ContainingBlock.ActualPaddingLeft - base.ContainingBlock.ActualPaddingRight - base.ContainingBlock.ActualBorderLeftWidth - base.ContainingBlock.ActualBorderRightWidth - base.ActualMarginLeft - base.ActualMarginRight - base.ActualBorderLeftWidth - base.ActualBorderRightWidth;
			if (CssBoxHr.smethod_26(base.Width, <Module>.smethod_24<string>(2471334246U)) && !CssBoxHr.smethod_27(base.Width))
			{
				num3 = CssValueParser.ParseLength(base.Width, num3, this, false);
			}
			if (num3 < minimumWidth || num3 >= 9999.0)
			{
				num3 = minimumWidth;
			}
			double num4 = base.ActualHeight;
			if (num4 < 1.0)
			{
				num4 = base.Size.Height + base.ActualBorderTopWidth + base.ActualBorderBottomWidth;
			}
			if (num4 < 1.0)
			{
				num4 = 2.0;
			}
			if (num4 <= 2.0 && base.ActualBorderTopWidth < 1.0 && base.ActualBorderBottomWidth < 1.0)
			{
				base.BorderTopStyle = (base.BorderBottomStyle = <Module>.smethod_26<string>(2202100248U));
				base.BorderTopWidth = <Module>.smethod_25<string>(1111510546U);
				base.BorderBottomWidth = <Module>.smethod_23<string>(2690462009U);
			}
			base.Size = new RSize(num3, num4);
			base.ActualBottom = base.Location.Y + base.ActualPaddingTop + base.ActualPaddingBottom + num4;
		}

		// Token: 0x060006D0 RID: 1744 RVA: 0x0003B5F0 File Offset: 0x000397F0
		protected override void PaintImp(RGraphics g)
		{
			RPoint rpoint = ((base.HtmlContainer == null) ? RPoint.Empty : base.HtmlContainer.ScrollOffset);
			RRect rrect = new RRect(base.Bounds.X + rpoint.X, base.Bounds.Y + rpoint.Y, base.Bounds.Width, base.Bounds.Height);
			if (rrect.Height > 2.0 && RenderUtils.IsColorVisible(base.ActualBackgroundColor))
			{
				g.DrawRectangle(g.GetSolidBrush(base.ActualBackgroundColor), rrect.X, rrect.Y, rrect.Width, rrect.Height);
			}
			RBrush solidBrush = g.GetSolidBrush(base.ActualBorderTopColor);
			BordersDrawHandler.DrawBorder(Border.Top, g, this, solidBrush, rrect);
			if (rrect.Height > 1.0)
			{
				RBrush solidBrush2 = g.GetSolidBrush(base.ActualBorderLeftColor);
				BordersDrawHandler.DrawBorder(Border.Left, g, this, solidBrush2, rrect);
				RBrush solidBrush3 = g.GetSolidBrush(base.ActualBorderRightColor);
				BordersDrawHandler.DrawBorder(Border.Right, g, this, solidBrush3, rrect);
				RBrush solidBrush4 = g.GetSolidBrush(base.ActualBorderBottomColor);
				BordersDrawHandler.DrawBorder(Border.Bottom, g, this, solidBrush4, rrect);
			}
		}

		// Token: 0x060006D1 RID: 1745 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_25(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x060006D2 RID: 1746 RVA: 0x0000CDA1 File Offset: 0x0000AFA1
		static bool smethod_26(string string_0, string string_1)
		{
			return string_0 != string_1;
		}

		// Token: 0x060006D3 RID: 1747 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_27(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}
	}
}
