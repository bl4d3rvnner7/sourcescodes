﻿using System;
using System.Collections.Generic;
using System.Globalization;
using TheArtOfDev.HtmlRenderer.Core.Parse;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x02000080 RID: 128
	internal sealed class CssLength
	{
		// Token: 0x06000719 RID: 1817 RVA: 0x0003EDE0 File Offset: 0x0003CFE0
		public CssLength(string length)
		{
			this._length = length;
			this._number = 0.0;
			this._unit = CssUnit.None;
			this._isPercentage = false;
			if (CssLength.smethod_0(length) || CssLength.smethod_1(length, <Module>.smethod_27<string>(1690140869U)))
			{
				return;
			}
			if (CssLength.smethod_2(length, <Module>.smethod_23<string>(3608961515U)))
			{
				this._number = CssValueParser.ParseNumber(length, 1.0);
				this._isPercentage = true;
				return;
			}
			if (CssLength.smethod_3(length) >= 3)
			{
				string text = CssLength.smethod_4(length, CssLength.smethod_3(length) - 2, 2);
				string text2 = CssLength.smethod_4(length, 0, CssLength.smethod_3(length) - 2);
				string text3;
				if ((text3 = text) != null)
				{
					if (<PrivateImplementationDetails>{6C443CB5-C2FB-4195-951F-C3363AAEEE4E}.$$method0x6000149-1 == null)
					{
						<PrivateImplementationDetails>{6C443CB5-C2FB-4195-951F-C3363AAEEE4E}.$$method0x6000149-1 = new Dictionary<string, int>(8)
						{
							{
								<Module>.smethod_26<string>(926858918U),
								0
							},
							{
								<Module>.smethod_26<string>(2790258015U),
								1
							},
							{
								<Module>.smethod_26<string>(2799834409U),
								2
							},
							{
								<Module>.smethod_25<string>(792971154U),
								3
							},
							{
								<Module>.smethod_25<string>(1767335496U),
								4
							},
							{
								<Module>.smethod_23<string>(2379155005U),
								5
							},
							{
								<Module>.smethod_27<string>(1363789018U),
								6
							},
							{
								<Module>.smethod_24<string>(3602872706U),
								7
							}
						};
					}
					int num;
					if (<PrivateImplementationDetails>{6C443CB5-C2FB-4195-951F-C3363AAEEE4E}.$$method0x6000149-1.TryGetValue(text3, out num))
					{
						switch (num)
						{
						case 0:
							this._unit = CssUnit.Ems;
							this._isRelative = true;
							break;
						case 1:
							this._unit = CssUnit.Ex;
							this._isRelative = true;
							break;
						case 2:
							this._unit = CssUnit.Pixels;
							this._isRelative = true;
							break;
						case 3:
							this._unit = CssUnit.Milimeters;
							break;
						case 4:
							this._unit = CssUnit.Centimeters;
							break;
						case 5:
							this._unit = CssUnit.Inches;
							break;
						case 6:
							this._unit = CssUnit.Points;
							break;
						case 7:
							this._unit = CssUnit.Picas;
							break;
						default:
							goto IL_0202;
						}
						if (!double.TryParse(text2, NumberStyles.Number, CssLength.smethod_5(), out this._number))
						{
							this._hasError = true;
						}
						return;
					}
				}
				IL_0202:
				this._hasError = true;
				return;
			}
			double.TryParse(length, out this._number);
			this._hasError = true;
		}

		// Token: 0x17000109 RID: 265
		// (get) Token: 0x0600071A RID: 1818 RVA: 0x0000F04F File Offset: 0x0000D24F
		public double Number
		{
			get
			{
				return this._number;
			}
		}

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x0600071B RID: 1819 RVA: 0x0000F057 File Offset: 0x0000D257
		public bool HasError
		{
			get
			{
				return this._hasError;
			}
		}

		// Token: 0x1700010B RID: 267
		// (get) Token: 0x0600071C RID: 1820 RVA: 0x0000F05F File Offset: 0x0000D25F
		public bool IsPercentage
		{
			get
			{
				return this._isPercentage;
			}
		}

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x0600071D RID: 1821 RVA: 0x0000F067 File Offset: 0x0000D267
		public bool IsRelative
		{
			get
			{
				return this._isRelative;
			}
		}

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x0600071E RID: 1822 RVA: 0x0000F06F File Offset: 0x0000D26F
		public CssUnit Unit
		{
			get
			{
				return this._unit;
			}
		}

		// Token: 0x1700010E RID: 270
		// (get) Token: 0x0600071F RID: 1823 RVA: 0x0000F077 File Offset: 0x0000D277
		public string Length
		{
			get
			{
				return this._length;
			}
		}

		// Token: 0x06000720 RID: 1824 RVA: 0x0003F00C File Offset: 0x0003D20C
		public CssLength ConvertEmToPoints(double emSize)
		{
			if (this.HasError)
			{
				throw CssLength.smethod_6(<Module>.smethod_24<string>(2789913084U));
			}
			if (this.Unit != CssUnit.Ems)
			{
				throw CssLength.smethod_6(<Module>.smethod_27<string>(1206159946U));
			}
			return new CssLength(string.Format(<Module>.smethod_24<string>(174723593U), CssLength.smethod_7(this.Number * emSize).ToString(<Module>.smethod_25<string>(2602504932U), CssLength.smethod_5())));
		}

		// Token: 0x06000721 RID: 1825 RVA: 0x0003F084 File Offset: 0x0003D284
		public CssLength ConvertEmToPixels(double pixelFactor)
		{
			if (this.HasError)
			{
				throw CssLength.smethod_6(<Module>.smethod_24<string>(2789913084U));
			}
			if (this.Unit == CssUnit.Ems)
			{
				return new CssLength(string.Format(<Module>.smethod_27<string>(2156357799U), CssLength.smethod_7(this.Number * pixelFactor).ToString(<Module>.smethod_27<string>(1066294867U), CssLength.smethod_5())));
			}
			throw CssLength.smethod_6(<Module>.smethod_27<string>(1206159946U));
		}

		// Token: 0x06000722 RID: 1826 RVA: 0x0003F0FC File Offset: 0x0003D2FC
		public override string ToString()
		{
			if (this.HasError)
			{
				return string.Empty;
			}
			if (this.IsPercentage)
			{
				return CssLength.smethod_8(CssLength.smethod_5(), <Module>.smethod_26<string>(4266603619U), new object[] { this.Number });
			}
			string text = string.Empty;
			switch (this.Unit)
			{
			case CssUnit.Ems:
				text = <Module>.smethod_24<string>(3230435307U);
				break;
			case CssUnit.Pixels:
				text = <Module>.smethod_26<string>(2799834409U);
				break;
			case CssUnit.Ex:
				text = <Module>.smethod_23<string>(3732127269U);
				break;
			case CssUnit.Inches:
				text = <Module>.smethod_24<string>(1163993840U);
				break;
			case CssUnit.Centimeters:
				text = <Module>.smethod_25<string>(1767335496U);
				break;
			case CssUnit.Milimeters:
				text = <Module>.smethod_27<string>(2091972113U);
				break;
			case CssUnit.Points:
				text = <Module>.smethod_23<string>(2312431626U);
				break;
			case CssUnit.Picas:
				text = <Module>.smethod_25<string>(1488945684U);
				break;
			}
			return CssLength.smethod_8(CssLength.smethod_5(), <Module>.smethod_26<string>(4276180013U), new object[] { this.Number, text });
		}

		// Token: 0x06000723 RID: 1827 RVA: 0x0000CD11 File Offset: 0x0000AF11
		static bool smethod_0(string string_0)
		{
			return string.IsNullOrEmpty(string_0);
		}

		// Token: 0x06000724 RID: 1828 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_1(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x06000725 RID: 1829 RVA: 0x0000D9AC File Offset: 0x0000BBAC
		static bool smethod_2(string string_0, string string_1)
		{
			return string_0.EndsWith(string_1);
		}

		// Token: 0x06000726 RID: 1830 RVA: 0x0000C3E6 File Offset: 0x0000A5E6
		static int smethod_3(string string_0)
		{
			return string_0.Length;
		}

		// Token: 0x06000727 RID: 1831 RVA: 0x0000CD73 File Offset: 0x0000AF73
		static string smethod_4(string string_0, int int_0, int int_1)
		{
			return string_0.Substring(int_0, int_1);
		}

		// Token: 0x06000728 RID: 1832 RVA: 0x0000EAE1 File Offset: 0x0000CCE1
		static NumberFormatInfo smethod_5()
		{
			return NumberFormatInfo.InvariantInfo;
		}

		// Token: 0x06000729 RID: 1833 RVA: 0x0000D015 File Offset: 0x0000B215
		static InvalidOperationException smethod_6(string string_0)
		{
			return new InvalidOperationException(string_0);
		}

		// Token: 0x0600072A RID: 1834 RVA: 0x0000F07F File Offset: 0x0000D27F
		static float smethod_7(double double_0)
		{
			return Convert.ToSingle(double_0);
		}

		// Token: 0x0600072B RID: 1835 RVA: 0x0000EAE8 File Offset: 0x0000CCE8
		static string smethod_8(IFormatProvider iformatProvider_0, string string_0, object[] object_0)
		{
			return string.Format(iformatProvider_0, string_0, object_0);
		}

		// Token: 0x04000288 RID: 648
		private readonly double _number;

		// Token: 0x04000289 RID: 649
		private readonly bool _isRelative;

		// Token: 0x0400028A RID: 650
		private readonly CssUnit _unit;

		// Token: 0x0400028B RID: 651
		private readonly string _length;

		// Token: 0x0400028C RID: 652
		private readonly bool _isPercentage;

		// Token: 0x0400028D RID: 653
		private readonly bool _hasError;
	}
}
