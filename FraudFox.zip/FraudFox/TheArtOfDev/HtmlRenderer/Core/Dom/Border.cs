﻿using System;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x02000089 RID: 137
	internal enum Border
	{
		// Token: 0x040002AD RID: 685
		Top,
		// Token: 0x040002AE RID: 686
		Right,
		// Token: 0x040002AF RID: 687
		Bottom,
		// Token: 0x040002B0 RID: 688
		Left
	}
}
