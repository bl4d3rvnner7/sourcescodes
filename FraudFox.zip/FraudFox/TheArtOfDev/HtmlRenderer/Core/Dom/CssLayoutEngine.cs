﻿using System;
using System.Collections;
using System.Collections.Generic;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x0200007E RID: 126
	internal static class CssLayoutEngine
	{
		// Token: 0x060006DC RID: 1756 RVA: 0x0003BB98 File Offset: 0x00039D98
		public static void MeasureImageSize(CssRectImage imageWord)
		{
			ArgChecker.AssertArgNotNull(imageWord, <Module>.smethod_24<string>(2466761718U));
			ArgChecker.AssertArgNotNull(imageWord.OwnerBox, <Module>.smethod_24<string>(4092680962U));
			CssLength cssLength = new CssLength(imageWord.OwnerBox.Width);
			CssLength cssLength2 = new CssLength(imageWord.OwnerBox.Height);
			bool flag = cssLength.Number > 0.0 && cssLength.Unit == CssUnit.Pixels;
			bool flag2 = cssLength2.Number > 0.0 && cssLength2.Unit == CssUnit.Pixels;
			bool flag3 = false;
			if (flag)
			{
				imageWord.Width = cssLength.Number;
			}
			else if (cssLength.Number > 0.0 && cssLength.IsPercentage)
			{
				imageWord.Width = cssLength.Number * imageWord.OwnerBox.ContainingBlock.Size.Width;
				flag3 = true;
			}
			else if (imageWord.Image == null)
			{
				imageWord.Width = (flag2 ? (cssLength2.Number / 1.1399999856948853) : 20.0);
			}
			else
			{
				imageWord.Width = ((imageWord.ImageRectangle == RRect.Empty) ? imageWord.Image.Width : imageWord.ImageRectangle.Width);
			}
			CssLength cssLength3 = new CssLength(imageWord.OwnerBox.MaxWidth);
			if (cssLength3.Number > 0.0)
			{
				double num = -1.0;
				if (cssLength3.Unit != CssUnit.Pixels)
				{
					if (cssLength3.IsPercentage)
					{
						num = cssLength3.Number * imageWord.OwnerBox.ContainingBlock.Size.Width;
					}
				}
				else
				{
					num = cssLength3.Number;
				}
				if (num > -1.0 && imageWord.Width > num)
				{
					imageWord.Width = num;
					flag3 = !flag2;
				}
			}
			if (flag2)
			{
				imageWord.Height = cssLength2.Number;
			}
			else if (imageWord.Image == null)
			{
				imageWord.Height = ((imageWord.Width > 0.0) ? (imageWord.Width * 1.1399999856948853) : 22.799999237060547);
			}
			else
			{
				imageWord.Height = ((imageWord.ImageRectangle == RRect.Empty) ? imageWord.Image.Height : imageWord.ImageRectangle.Height);
			}
			if (imageWord.Image != null)
			{
				if ((!flag || flag2) && !flag3)
				{
					if (flag2 && !flag)
					{
						double num2 = imageWord.Height / imageWord.Image.Height;
						imageWord.Width = imageWord.Image.Width * num2;
					}
				}
				else
				{
					double num3 = imageWord.Width / imageWord.Image.Width;
					imageWord.Height = imageWord.Image.Height * num3;
				}
			}
			imageWord.Height += imageWord.OwnerBox.ActualBorderBottomWidth + imageWord.OwnerBox.ActualBorderTopWidth + imageWord.OwnerBox.ActualPaddingTop + imageWord.OwnerBox.ActualPaddingBottom;
		}

		// Token: 0x060006DD RID: 1757 RVA: 0x0003BEA4 File Offset: 0x0003A0A4
		public static void CreateLineBoxes(RGraphics g, CssBox blockBox)
		{
			ArgChecker.AssertArgNotNull(g, <Module>.smethod_26<string>(1179842895U));
			ArgChecker.AssertArgNotNull(blockBox, <Module>.smethod_25<string>(2364264700U));
			blockBox.LineBoxes.Clear();
			double num = blockBox.ActualRight - blockBox.ActualPaddingRight - blockBox.ActualBorderRightWidth;
			double num2 = blockBox.Location.X + blockBox.ActualPaddingLeft - 0.0 + blockBox.ActualBorderLeftWidth;
			double num3 = blockBox.Location.Y + blockBox.ActualPaddingTop - 0.0 + blockBox.ActualBorderTopWidth;
			double num4 = num2 + blockBox.ActualTextIndent;
			double num5 = num3;
			double num6 = num2;
			double num7 = num3;
			CssLineBox cssLineBox = new CssLineBox(blockBox);
			CssLayoutEngine.FlowBox(g, blockBox, blockBox, num, 0.0, num2, ref cssLineBox, ref num4, ref num5, ref num6, ref num7);
			if (blockBox.ActualRight >= 90999.0)
			{
				blockBox.ActualRight = num6 + blockBox.ActualPaddingRight + blockBox.ActualBorderRightWidth;
			}
			foreach (CssLineBox cssLineBox2 in blockBox.LineBoxes)
			{
				CssLayoutEngine.ApplyHorizontalAlignment(g, cssLineBox2);
				CssLayoutEngine.ApplyRightToLeft(blockBox, cssLineBox2);
				CssLayoutEngine.BubbleRectangles(blockBox, cssLineBox2);
				CssLayoutEngine.ApplyVerticalAlignment(g, cssLineBox2);
				cssLineBox2.AssignRectanglesToBoxes();
			}
			blockBox.ActualBottom = num7 + blockBox.ActualPaddingBottom + blockBox.ActualBorderBottomWidth;
			if (blockBox.Height != null && CssLayoutEngine.smethod_0(blockBox.Height, <Module>.smethod_26<string>(3088707157U)) && CssLayoutEngine.smethod_1(blockBox.Overflow, <Module>.smethod_27<string>(4015004606U)) && blockBox.ActualBottom - blockBox.Location.Y > blockBox.ActualHeight)
			{
				blockBox.ActualBottom = blockBox.Location.Y + blockBox.ActualHeight;
			}
		}

		// Token: 0x060006DE RID: 1758 RVA: 0x0003C090 File Offset: 0x0003A290
		public static void ApplyCellVerticalAlignment(RGraphics g, CssBox cell)
		{
			ArgChecker.AssertArgNotNull(g, <Module>.smethod_24<string>(610673288U));
			ArgChecker.AssertArgNotNull(cell, <Module>.smethod_24<string>(3740059712U));
			if (!CssLayoutEngine.smethod_1(cell.VerticalAlign, <Module>.smethod_23<string>(601990987U)) && !CssLayoutEngine.smethod_1(cell.VerticalAlign, <Module>.smethod_24<string>(3269558926U)))
			{
				double clientBottom = cell.ClientBottom;
				double maximumBottom = cell.GetMaximumBottom(cell, 0.0);
				double num = 0.0;
				if (CssLayoutEngine.smethod_1(cell.VerticalAlign, <Module>.smethod_23<string>(1724053249U)))
				{
					num = clientBottom - maximumBottom;
				}
				else if (CssLayoutEngine.smethod_1(cell.VerticalAlign, <Module>.smethod_23<string>(2478366132U)))
				{
					num = (clientBottom - maximumBottom) / 2.0;
				}
				foreach (CssBox cssBox in cell.Boxes)
				{
					cssBox.OffsetTop(num);
				}
				return;
			}
		}

		// Token: 0x060006DF RID: 1759 RVA: 0x0003C1A0 File Offset: 0x0003A3A0
		private static void FlowBox(RGraphics g, CssBox blockbox, CssBox box, double limitRight, double linespacing, double startx, ref CssLineBox line, ref double curx, ref double cury, ref double maxRight, ref double maxbottom)
		{
			double num = curx;
			double num2 = cury;
			box.FirstHostingLineBox = line;
			double num3 = curx;
			double num4 = maxRight;
			double num5 = maxbottom;
			foreach (CssBox cssBox in box.Boxes)
			{
				double num6 = (CssLayoutEngine.smethod_0(cssBox.Position, <Module>.smethod_26<string>(1372951703U)) ? (cssBox.ActualMarginLeft + cssBox.ActualBorderLeftWidth + cssBox.ActualPaddingLeft) : 0.0);
				double num7 = (CssLayoutEngine.smethod_0(cssBox.Position, <Module>.smethod_24<string>(674185584U)) ? (cssBox.ActualMarginRight + cssBox.ActualBorderRightWidth + cssBox.ActualPaddingRight) : 0.0);
				cssBox.RectanglesReset();
				cssBox.MeasureWordsSize(g);
				curx += num6;
				if (cssBox.Words.Count > 0)
				{
					bool flag = false;
					if (CssLayoutEngine.smethod_1(cssBox.WhiteSpace, <Module>.smethod_27<string>(2004949640U)) && curx > startx)
					{
						double num8 = curx;
						foreach (CssRect cssRect in cssBox.Words)
						{
							num8 += cssRect.FullWidth;
						}
						if (num8 > limitRight)
						{
							flag = true;
						}
					}
					if (DomUtils.IsBoxHasWhitespace(cssBox))
					{
						curx += box.ActualWordSpacing;
					}
					using (List<CssRect>.Enumerator enumerator3 = cssBox.Words.GetEnumerator())
					{
						while (enumerator3.MoveNext())
						{
							CssRect cssRect2 = enumerator3.Current;
							if (maxbottom - cury < box.ActualLineHeight)
							{
								maxbottom += box.ActualLineHeight - (maxbottom - cury);
							}
							if ((CssLayoutEngine.smethod_0(cssBox.WhiteSpace, <Module>.smethod_27<string>(2004949640U)) && CssLayoutEngine.smethod_0(cssBox.WhiteSpace, <Module>.smethod_23<string>(3877499767U)) && curx + cssRect2.Width + num7 > limitRight && (CssLayoutEngine.smethod_0(cssBox.WhiteSpace, <Module>.smethod_26<string>(1909229767U)) || !cssRect2.IsSpaces)) || cssRect2.IsLineBreak || flag)
							{
								flag = false;
								curx = startx;
								if (cssBox == box.Boxes[0])
								{
									if (!cssRect2.IsLineBreak && (cssRect2 == cssBox.Words[0] || (box.ParentBox != null && box.ParentBox.IsBlock)))
									{
										curx += box.ActualMarginLeft + box.ActualBorderLeftWidth + box.ActualPaddingLeft;
									}
								}
								cury = maxbottom + linespacing;
								line = new CssLineBox(blockbox);
								if (cssRect2.IsImage || CssLayoutEngine.smethod_2(cssRect2, cssBox.FirstWord))
								{
									curx += num6;
								}
							}
							line.ReportExistanceOf(cssRect2);
							cssRect2.Left = curx;
							cssRect2.Top = cury;
							curx = cssRect2.Left + cssRect2.FullWidth;
							maxRight = CssLayoutEngine.smethod_3(maxRight, cssRect2.Right);
							maxbottom = CssLayoutEngine.smethod_3(maxbottom, cssRect2.Bottom);
							if (CssLayoutEngine.smethod_1(cssBox.Position, <Module>.smethod_27<string>(1305624245U)))
							{
								cssRect2.Left += box.ActualMarginLeft;
								cssRect2.Top += box.ActualMarginTop;
							}
						}
						goto IL_036E;
					}
					goto IL_0356;
				}
				goto IL_0356;
				IL_036E:
				curx += num7;
				continue;
				IL_0356:
				CssLayoutEngine.FlowBox(g, blockbox, cssBox, limitRight, linespacing, startx, ref line, ref curx, ref cury, ref maxRight, ref maxbottom);
				goto IL_036E;
			}
			if (maxbottom - num2 < box.ActualHeight)
			{
				maxbottom += box.ActualHeight - (maxbottom - num2);
			}
			if (box.IsInline && 0.0 <= curx - num && curx - num < box.ActualWidth)
			{
				curx += box.ActualWidth - (curx - num);
				line.Rectangles.Add(box, new RRect(num, num2, box.ActualWidth, box.ActualHeight));
			}
			if (box.Text != null && box.Text.IsWhitespace() && !box.IsImage && box.IsInline && box.Boxes.Count == 0 && box.Words.Count == 0)
			{
				curx += box.ActualWordSpacing;
			}
			if (CssLayoutEngine.smethod_1(box.Position, <Module>.smethod_26<string>(1372951703U)))
			{
				curx = num3;
				maxRight = num4;
				maxbottom = num5;
				CssLayoutEngine.AdjustAbsolutePosition(box, 0.0, 0.0);
			}
			box.LastHostingLineBox = line;
		}

		// Token: 0x060006E0 RID: 1760 RVA: 0x0003C694 File Offset: 0x0003A894
		private static void AdjustAbsolutePosition(CssBox box, double left, double top)
		{
			left += box.ActualMarginLeft;
			top += box.ActualMarginTop;
			if (box.Words.Count > 0)
			{
				using (List<CssRect>.Enumerator enumerator = box.Words.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						CssRect cssRect = enumerator.Current;
						cssRect.Left += left;
						cssRect.Top += top;
					}
					return;
				}
			}
			foreach (CssBox cssBox in box.Boxes)
			{
				CssLayoutEngine.AdjustAbsolutePosition(cssBox, left, top);
			}
		}

		// Token: 0x060006E1 RID: 1761 RVA: 0x0003C764 File Offset: 0x0003A964
		private static void BubbleRectangles(CssBox box, CssLineBox line)
		{
			if (box.Words.Count > 0)
			{
				double num = 3.4028234663852886E+38;
				double num2 = 3.4028234663852886E+38;
				double num3 = -3.4028234663852886E+38;
				double num4 = -3.4028234663852886E+38;
				List<CssRect> list = line.WordsOf(box);
				if (list.Count > 0)
				{
					foreach (CssRect cssRect in list)
					{
						double num5 = cssRect.Left;
						if (box == box.ParentBox.Boxes[0] && cssRect == box.Words[0] && cssRect == line.Words[0] && line != line.OwnerBox.LineBoxes[0] && !cssRect.IsLineBreak)
						{
							num5 -= box.ParentBox.ActualMarginLeft + box.ParentBox.ActualBorderLeftWidth + box.ParentBox.ActualPaddingLeft;
						}
						num = CssLayoutEngine.smethod_4(num, num5);
						num3 = CssLayoutEngine.smethod_3(num3, cssRect.Right);
						num2 = CssLayoutEngine.smethod_4(num2, cssRect.Top);
						num4 = CssLayoutEngine.smethod_3(num4, cssRect.Bottom);
					}
					line.UpdateRectangle(box, num, num2, num3, num4);
					return;
				}
			}
			else
			{
				foreach (CssBox cssBox in box.Boxes)
				{
					CssLayoutEngine.BubbleRectangles(cssBox, line);
				}
			}
		}

		// Token: 0x060006E2 RID: 1762 RVA: 0x0003C90C File Offset: 0x0003AB0C
		private static void ApplyHorizontalAlignment(RGraphics g, CssLineBox lineBox)
		{
			string textAlign;
			if ((textAlign = lineBox.OwnerBox.TextAlign) != null)
			{
				if (CssLayoutEngine.smethod_1(textAlign, <Module>.smethod_27<string>(3315679211U)))
				{
					CssLayoutEngine.ApplyRightAlignment(g, lineBox);
					return;
				}
				if (CssLayoutEngine.smethod_1(textAlign, <Module>.smethod_25<string>(3269031589U)))
				{
					CssLayoutEngine.ApplyCenterAlignment(g, lineBox);
					return;
				}
				if (CssLayoutEngine.smethod_1(textAlign, <Module>.smethod_27<string>(40617621U)))
				{
					CssLayoutEngine.ApplyJustifyAlignment(g, lineBox);
					return;
				}
			}
			CssLayoutEngine.ApplyLeftAlignment(g, lineBox);
		}

		// Token: 0x060006E3 RID: 1763 RVA: 0x0003C980 File Offset: 0x0003AB80
		private static void ApplyRightToLeft(CssBox blockBox, CssLineBox lineBox)
		{
			if (CssLayoutEngine.smethod_1(blockBox.Direction, <Module>.smethod_23<string>(1544445120U)))
			{
				CssLayoutEngine.ApplyRightToLeftOnLine(lineBox);
				return;
			}
			foreach (CssBox cssBox in lineBox.RelatedBoxes)
			{
				if (CssLayoutEngine.smethod_1(cssBox.Direction, <Module>.smethod_27<string>(1631976096U)))
				{
					CssLayoutEngine.ApplyRightToLeftOnSingleBox(lineBox, cssBox);
				}
			}
		}

		// Token: 0x060006E4 RID: 1764 RVA: 0x0003CA0C File Offset: 0x0003AC0C
		private static void ApplyRightToLeftOnLine(CssLineBox line)
		{
			if (line.Words.Count > 0)
			{
				double left = line.Words[0].Left;
				double right = line.Words[line.Words.Count - 1].Right;
				foreach (CssRect cssRect in line.Words)
				{
					double num = cssRect.Left - left;
					double num2 = right - num;
					cssRect.Left = num2 - cssRect.Width;
				}
			}
		}

		// Token: 0x060006E5 RID: 1765 RVA: 0x0003CAB8 File Offset: 0x0003ACB8
		private static void ApplyRightToLeftOnSingleBox(CssLineBox lineBox, CssBox box)
		{
			int num = -1;
			int num2 = -1;
			for (int i = 0; i < lineBox.Words.Count; i++)
			{
				if (lineBox.Words[i].OwnerBox == box)
				{
					if (num < 0)
					{
						num = i;
					}
					num2 = i;
				}
			}
			if (num > -1 && num2 > num)
			{
				double left = lineBox.Words[num].Left;
				double right = lineBox.Words[num2].Right;
				for (int j = num; j <= num2; j++)
				{
					double num3 = lineBox.Words[j].Left - left;
					double num4 = right - num3;
					lineBox.Words[j].Left = num4 - lineBox.Words[j].Width;
				}
			}
		}

		// Token: 0x060006E6 RID: 1766 RVA: 0x0003CB7C File Offset: 0x0003AD7C
		private static void ApplyVerticalAlignment(RGraphics g, CssLineBox lineBox)
		{
			double num = -3.4028234663852886E+38;
			foreach (CssBox cssBox in lineBox.Rectangles.Keys)
			{
				num = CssLayoutEngine.smethod_3(num, lineBox.Rectangles[cssBox].Top);
			}
			List<CssBox> list = new List<CssBox>(lineBox.Rectangles.Keys);
			foreach (CssBox cssBox2 in list)
			{
				string verticalAlign;
				switch (verticalAlign = cssBox2.VerticalAlign)
				{

					lineBox.SetBaseLine(g, cssBox2, num + lineBox.Rectangles[cssBox2].Height * 0.5);
					continue;

					lineBox.SetBaseLine(g, cssBox2, num - lineBox.Rectangles[cssBox2].Height * 0.20000000298023224);
					continue;

					continue;
				}
				lineBox.SetBaseLine(g, cssBox2, num);
			}
		}

		// Token: 0x060006E7 RID: 1767 RVA: 0x0003CD98 File Offset: 0x0003AF98
		private static void ApplyJustifyAlignment(RGraphics g, CssLineBox lineBox)
		{
			if (CssLayoutEngine.smethod_2(lineBox, lineBox.OwnerBox.LineBoxes[lineBox.OwnerBox.LineBoxes.Count - 1]))
			{
				return;
			}
			double num = (CssLayoutEngine.smethod_2(lineBox, lineBox.OwnerBox.LineBoxes[0]) ? lineBox.OwnerBox.ActualTextIndent : 0.0);
			double num2 = 0.0;
			double num3 = 0.0;
			double num4 = lineBox.OwnerBox.ClientRectangle.Width - num;
			foreach (CssRect cssRect in lineBox.Words)
			{
				num2 += cssRect.Width;
				num3 += 1.0;
			}
			if (num3 <= 0.0)
			{
				return;
			}
			double num5 = (num4 - num2) / num3;
			double num6 = lineBox.OwnerBox.ClientLeft + num;
			foreach (CssRect cssRect2 in lineBox.Words)
			{
				cssRect2.Left = num6;
				num6 = cssRect2.Right + num5;
				if (cssRect2 == lineBox.Words[lineBox.Words.Count - 1])
				{
					cssRect2.Left = lineBox.OwnerBox.ClientRight - cssRect2.Width;
				}
			}
		}

		// Token: 0x060006E8 RID: 1768 RVA: 0x0003CF30 File Offset: 0x0003B130
		private static void ApplyCenterAlignment(RGraphics g, CssLineBox line)
		{
			if (line.Words.Count == 0)
			{
				return;
			}
			CssRect cssRect = line.Words[line.Words.Count - 1];
			double num = line.OwnerBox.ActualRight - line.OwnerBox.ActualPaddingRight - line.OwnerBox.ActualBorderRightWidth;
			double num2 = num - cssRect.Right - cssRect.OwnerBox.ActualBorderRightWidth - cssRect.OwnerBox.ActualPaddingRight;
			num2 /= 2.0;
			if (num2 > 0.0)
			{
				foreach (CssRect cssRect2 in line.Words)
				{
					cssRect2.Left += num2;
				}
				if (line.Rectangles.Count > 0)
				{
					foreach (CssBox cssBox in CssLayoutEngine.ToList<CssBox>(line.Rectangles.Keys))
					{
						RRect rrect = line.Rectangles[cssBox];
						line.Rectangles[cssBox] = new RRect(rrect.X + num2, rrect.Y, rrect.Width, rrect.Height);
					}
				}
			}
		}

		// Token: 0x060006E9 RID: 1769 RVA: 0x0003D0AC File Offset: 0x0003B2AC
		private static void ApplyRightAlignment(RGraphics g, CssLineBox line)
		{
			if (line.Words.Count == 0)
			{
				return;
			}
			CssRect cssRect = line.Words[line.Words.Count - 1];
			double num = line.OwnerBox.ActualRight - line.OwnerBox.ActualPaddingRight - line.OwnerBox.ActualBorderRightWidth;
			double num2 = num - cssRect.Right - cssRect.OwnerBox.ActualBorderRightWidth - cssRect.OwnerBox.ActualPaddingRight;
			if (num2 > 0.0)
			{
				foreach (CssRect cssRect2 in line.Words)
				{
					cssRect2.Left += num2;
				}
				if (line.Rectangles.Count > 0)
				{
					foreach (CssBox cssBox in CssLayoutEngine.ToList<CssBox>(line.Rectangles.Keys))
					{
						RRect rrect = line.Rectangles[cssBox];
						line.Rectangles[cssBox] = new RRect(rrect.X + num2, rrect.Y, rrect.Width, rrect.Height);
					}
				}
			}
		}

		// Token: 0x060006EA RID: 1770 RVA: 0x0000C600 File Offset: 0x0000A800
		private static void ApplyLeftAlignment(RGraphics g, CssLineBox line)
		{
		}

		// Token: 0x060006EB RID: 1771 RVA: 0x0003D21C File Offset: 0x0003B41C
		private static List<T> ToList<T>(IEnumerable<T> collection)
		{
			List<T> list = new List<T>();
			IEnumerator<T> enumerator = collection.GetEnumerator();
			try
			{
				while (CssLayoutEngine.smethod_5(enumerator))
				{
					T t = enumerator.Current;
					list.Add(t);
				}
			}
			finally
			{
				if (enumerator != null)
				{
					CssLayoutEngine.smethod_6(enumerator);
				}
			}
			return list;
		}

		// Token: 0x060006EC RID: 1772 RVA: 0x0000CDA1 File Offset: 0x0000AFA1
		static bool smethod_0(string string_0, string string_1)
		{
			return string_0 != string_1;
		}

		// Token: 0x060006ED RID: 1773 RVA: 0x0000CD45 File Offset: 0x0000AF45
		static bool smethod_1(string string_0, string string_1)
		{
			return string_0 == string_1;
		}

		// Token: 0x060006EE RID: 1774 RVA: 0x0000ED73 File Offset: 0x0000CF73
		static bool smethod_2(object object_0, object object_1)
		{
			return object_0.Equals(object_1);
		}

		// Token: 0x060006EF RID: 1775 RVA: 0x0000ED6A File Offset: 0x0000CF6A
		static double smethod_3(double double_0, double double_1)
		{
			return Math.Max(double_0, double_1);
		}

		// Token: 0x060006F0 RID: 1776 RVA: 0x0000EF08 File Offset: 0x0000D108
		static double smethod_4(double double_0, double double_1)
		{
			return Math.Min(double_0, double_1);
		}

		// Token: 0x060006F1 RID: 1777 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_5(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x060006F2 RID: 1778 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_6(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}
	}
}
