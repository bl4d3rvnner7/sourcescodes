﻿using System;
using TheArtOfDev.HtmlRenderer.Core.Entities;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x02000087 RID: 135
	internal sealed class HoverBoxBlock
	{
		// Token: 0x0600077D RID: 1917 RVA: 0x0000F302 File Offset: 0x0000D502
		public HoverBoxBlock(CssBox cssBox, CssBlock cssBlock)
		{
			this._cssBox = cssBox;
			this._cssBlock = cssBlock;
		}

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x0600077E RID: 1918 RVA: 0x0000F318 File Offset: 0x0000D518
		public CssBox CssBox
		{
			get
			{
				return this._cssBox;
			}
		}

		// Token: 0x17000139 RID: 313
		// (get) Token: 0x0600077F RID: 1919 RVA: 0x0000F320 File Offset: 0x0000D520
		public CssBlock CssBlock
		{
			get
			{
				return this._cssBlock;
			}
		}

		// Token: 0x040002A7 RID: 679
		private readonly CssBox _cssBox;

		// Token: 0x040002A8 RID: 680
		private readonly CssBlock _cssBlock;
	}
}
