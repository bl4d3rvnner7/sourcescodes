﻿using System;
using System.Collections.Generic;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;

namespace TheArtOfDev.HtmlRenderer.Core.Dom
{
	// Token: 0x02000081 RID: 129
	internal sealed class CssLineBox
	{
		// Token: 0x0600072C RID: 1836 RVA: 0x0003F21C File Offset: 0x0003D41C
		public CssLineBox(CssBox ownerBox)
		{
			this._rects = new Dictionary<CssBox, RRect>();
			this._relatedBoxes = new List<CssBox>();
			this._words = new List<CssRect>();
			this._ownerBox = ownerBox;
			this._ownerBox.LineBoxes.Add(this);
		}

		// Token: 0x1700010F RID: 271
		// (get) Token: 0x0600072D RID: 1837 RVA: 0x0000F087 File Offset: 0x0000D287
		public List<CssBox> RelatedBoxes
		{
			get
			{
				return this._relatedBoxes;
			}
		}

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x0600072E RID: 1838 RVA: 0x0000F08F File Offset: 0x0000D28F
		public List<CssRect> Words
		{
			get
			{
				return this._words;
			}
		}

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x0600072F RID: 1839 RVA: 0x0000F097 File Offset: 0x0000D297
		public CssBox OwnerBox
		{
			get
			{
				return this._ownerBox;
			}
		}

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x06000730 RID: 1840 RVA: 0x0000F09F File Offset: 0x0000D29F
		public Dictionary<CssBox, RRect> Rectangles
		{
			get
			{
				return this._rects;
			}
		}

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x06000731 RID: 1841 RVA: 0x0003F268 File Offset: 0x0003D468
		public double LineHeight
		{
			get
			{
				double num = 0.0;
				foreach (KeyValuePair<CssBox, RRect> keyValuePair in this._rects)
				{
					num = CssLineBox.smethod_0(num, keyValuePair.Value.Height);
				}
				return num;
			}
		}

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x06000732 RID: 1842 RVA: 0x0003F2D8 File Offset: 0x0003D4D8
		public double LineBottom
		{
			get
			{
				double num = 0.0;
				foreach (KeyValuePair<CssBox, RRect> keyValuePair in this._rects)
				{
					num = CssLineBox.smethod_0(num, keyValuePair.Value.Bottom);
				}
				return num;
			}
		}

		// Token: 0x06000733 RID: 1843 RVA: 0x0000F0A7 File Offset: 0x0000D2A7
		internal void ReportExistanceOf(CssRect word)
		{
			if (!this.Words.Contains(word))
			{
				this.Words.Add(word);
			}
			if (!this.RelatedBoxes.Contains(word.OwnerBox))
			{
				this.RelatedBoxes.Add(word.OwnerBox);
			}
		}

		// Token: 0x06000734 RID: 1844 RVA: 0x0003F348 File Offset: 0x0003D548
		internal List<CssRect> WordsOf(CssBox box)
		{
			List<CssRect> list = new List<CssRect>();
			foreach (CssRect cssRect in this.Words)
			{
				if (CssLineBox.smethod_1(cssRect.OwnerBox, box))
				{
					list.Add(cssRect);
				}
			}
			return list;
		}

		// Token: 0x06000735 RID: 1845 RVA: 0x0003F3B4 File Offset: 0x0003D5B4
		internal void UpdateRectangle(CssBox box, double x, double y, double r, double b)
		{
			double num = box.ActualBorderLeftWidth + box.ActualPaddingLeft;
			double num2 = box.ActualBorderRightWidth + box.ActualPaddingRight;
			double num3 = box.ActualBorderTopWidth + box.ActualPaddingTop;
			double num4 = box.ActualBorderBottomWidth + box.ActualPaddingTop;
			if ((box.FirstHostingLineBox != null && CssLineBox.smethod_1(box.FirstHostingLineBox, this)) || box.IsImage)
			{
				x -= num;
			}
			if ((box.LastHostingLineBox != null && CssLineBox.smethod_1(box.LastHostingLineBox, this)) || box.IsImage)
			{
				r += num2;
			}
			if (!box.IsImage)
			{
				y -= num3;
				b += num4;
			}
			if (!this.Rectangles.ContainsKey(box))
			{
				this.Rectangles.Add(box, RRect.FromLTRB(x, y, r, b));
			}
			else
			{
				RRect rrect = this.Rectangles[box];
				this.Rectangles[box] = RRect.FromLTRB(CssLineBox.smethod_2(rrect.X, x), CssLineBox.smethod_2(rrect.Y, y), CssLineBox.smethod_0(rrect.Right, r), CssLineBox.smethod_0(rrect.Bottom, b));
			}
			if (box.ParentBox != null && box.ParentBox.IsInline)
			{
				this.UpdateRectangle(box.ParentBox, x, y, r, b);
			}
		}

		// Token: 0x06000736 RID: 1846 RVA: 0x0003F4F8 File Offset: 0x0003D6F8
		internal void AssignRectanglesToBoxes()
		{
			foreach (CssBox cssBox in this.Rectangles.Keys)
			{
				cssBox.Rectangles.Add(this, this.Rectangles[cssBox]);
			}
		}

		// Token: 0x06000737 RID: 1847 RVA: 0x0003F564 File Offset: 0x0003D764
		internal void SetBaseLine(RGraphics g, CssBox b, double baseline)
		{
			List<CssRect> list = this.WordsOf(b);
			if (!this.Rectangles.ContainsKey(b))
			{
				return;
			}
			RRect rrect = this.Rectangles[b];
			double num = 0.0;
			if (list.Count > 0)
			{
				num = list[0].Top - rrect.Top;
			}
			else
			{
				CssRect cssRect = b.FirstWordOccourence(b, this);
				if (cssRect != null)
				{
					num = cssRect.Top - rrect.Top;
				}
			}
			if (b.ParentBox != null && b.ParentBox.Rectangles.ContainsKey(this) && rrect.Height < b.ParentBox.Rectangles[this].Height)
			{
				double num2 = baseline - num;
				RRect rrect2 = new RRect(rrect.X, num2, rrect.Width, rrect.Height);
				this.Rectangles[b] = rrect2;
				b.OffsetRectangle(this, num);
			}
			foreach (CssRect cssRect2 in list)
			{
				if (!cssRect2.IsImage)
				{
					cssRect2.Top = baseline;
				}
			}
		}

		// Token: 0x06000738 RID: 1848 RVA: 0x0003F6A4 File Offset: 0x0003D8A4
		public bool IsLastSelectedWord(CssRect word)
		{
			for (int i = 0; i < this._words.Count - 1; i++)
			{
				if (this._words[i] == word)
				{
					return !this._words[i + 1].Selected;
				}
			}
			return true;
		}

		// Token: 0x06000739 RID: 1849 RVA: 0x0003F6F4 File Offset: 0x0003D8F4
		public override string ToString()
		{
			string[] array = new string[this.Words.Count];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = this.Words[i].Text;
			}
			return CssLineBox.smethod_3(<Module>.smethod_25<string>(482330791U), array);
		}

		// Token: 0x0600073A RID: 1850 RVA: 0x0000ED6A File Offset: 0x0000CF6A
		static double smethod_0(double double_0, double double_1)
		{
			return Math.Max(double_0, double_1);
		}

		// Token: 0x0600073B RID: 1851 RVA: 0x0000ED73 File Offset: 0x0000CF73
		static bool smethod_1(object object_0, object object_1)
		{
			return object_0.Equals(object_1);
		}

		// Token: 0x0600073C RID: 1852 RVA: 0x0000EF08 File Offset: 0x0000D108
		static double smethod_2(double double_0, double double_1)
		{
			return Math.Min(double_0, double_1);
		}

		// Token: 0x0600073D RID: 1853 RVA: 0x0000DAF6 File Offset: 0x0000BCF6
		static string smethod_3(string string_0, string[] string_1)
		{
			return string.Join(string_0, string_1);
		}

		// Token: 0x0400028E RID: 654
		private readonly List<CssRect> _words;

		// Token: 0x0400028F RID: 655
		private readonly CssBox _ownerBox;

		// Token: 0x04000290 RID: 656
		private readonly Dictionary<CssBox, RRect> _rects;

		// Token: 0x04000291 RID: 657
		private readonly List<CssBox> _relatedBoxes;
	}
}
