﻿using System;
using System.Collections;
using System.Collections.Generic;
using TheArtOfDev.HtmlRenderer.Adapters;
using TheArtOfDev.HtmlRenderer.Core.Entities;
using TheArtOfDev.HtmlRenderer.Core.Parse;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Core
{
	// Token: 0x020000B6 RID: 182
	public sealed class CssData
	{
		// Token: 0x06000A36 RID: 2614 RVA: 0x00010265 File Offset: 0x0000E465
		internal CssData()
		{
			this._mediaBlocks.Add(<Module>.smethod_25<string>(554803637U), new Dictionary<string, List<CssBlock>>(CssData.smethod_0()));
		}

		// Token: 0x06000A37 RID: 2615 RVA: 0x0004F0F4 File Offset: 0x0004D2F4
		public static CssData Parse(RAdapter adapter, string stylesheet, bool combineWithDefault = true)
		{
			CssParser cssParser = new CssParser(adapter);
			return cssParser.ParseStyleSheet(stylesheet, combineWithDefault);
		}

		// Token: 0x1700016D RID: 365
		// (get) Token: 0x06000A38 RID: 2616 RVA: 0x0001029C File Offset: 0x0000E49C
		internal IDictionary<string, Dictionary<string, List<CssBlock>>> MediaBlocks
		{
			get
			{
				return this._mediaBlocks;
			}
		}

		// Token: 0x06000A39 RID: 2617 RVA: 0x0004F110 File Offset: 0x0004D310
		public bool ContainsCssBlock(string className, string media = "all")
		{
			Dictionary<string, List<CssBlock>> dictionary;
			return this._mediaBlocks.TryGetValue(media, out dictionary) && dictionary.ContainsKey(className);
		}

		// Token: 0x06000A3A RID: 2618 RVA: 0x0004F138 File Offset: 0x0004D338
		public IEnumerable<CssBlock> GetCssBlock(string className, string media = "all")
		{
			List<CssBlock> list = null;
			Dictionary<string, List<CssBlock>> dictionary;
			if (this._mediaBlocks.TryGetValue(media, out dictionary))
			{
				dictionary.TryGetValue(className, out list);
			}
			return list ?? CssData._emptyArray;
		}

		// Token: 0x06000A3B RID: 2619 RVA: 0x0004F16C File Offset: 0x0004D36C
		public void AddCssBlock(string media, CssBlock cssBlock)
		{
			Dictionary<string, List<CssBlock>> dictionary;
			if (!this._mediaBlocks.TryGetValue(media, out dictionary))
			{
				dictionary = new Dictionary<string, List<CssBlock>>(CssData.smethod_0());
				this._mediaBlocks.Add(media, dictionary);
			}
			if (dictionary.ContainsKey(cssBlock.Class))
			{
				bool flag = false;
				List<CssBlock> list = dictionary[cssBlock.Class];
				foreach (CssBlock cssBlock2 in list)
				{
					if (cssBlock2.EqualsSelector(cssBlock))
					{
						flag = true;
						cssBlock2.Merge(cssBlock);
						break;
					}
				}
				if (!flag)
				{
					if (cssBlock.Selectors == null)
					{
						list.Insert(0, cssBlock);
						return;
					}
					list.Add(cssBlock);
				}
				return;
			}
			List<CssBlock> list2 = new List<CssBlock>();
			list2.Add(cssBlock);
			dictionary[cssBlock.Class] = list2;
		}

		// Token: 0x06000A3C RID: 2620 RVA: 0x0004F248 File Offset: 0x0004D448
		public void Combine(CssData other)
		{
			ArgChecker.AssertArgNotNull(other, <Module>.smethod_25<string>(3745512053U));
			IEnumerator<KeyValuePair<string, Dictionary<string, List<CssBlock>>>> enumerator = other.MediaBlocks.GetEnumerator();
			try
			{
				while (CssData.smethod_1(enumerator))
				{
					KeyValuePair<string, Dictionary<string, List<CssBlock>>> keyValuePair = enumerator.Current;
					foreach (KeyValuePair<string, List<CssBlock>> keyValuePair2 in keyValuePair.Value)
					{
						foreach (CssBlock cssBlock in keyValuePair2.Value)
						{
							this.AddCssBlock(keyValuePair.Key, cssBlock);
						}
					}
				}
			}
			finally
			{
				if (enumerator != null)
				{
					CssData.smethod_2(enumerator);
				}
			}
		}

		// Token: 0x06000A3D RID: 2621 RVA: 0x0004F330 File Offset: 0x0004D530
		public CssData Clone()
		{
			CssData cssData = new CssData();
			foreach (KeyValuePair<string, Dictionary<string, List<CssBlock>>> keyValuePair in this._mediaBlocks)
			{
				Dictionary<string, List<CssBlock>> dictionary = new Dictionary<string, List<CssBlock>>(CssData.smethod_0());
				foreach (KeyValuePair<string, List<CssBlock>> keyValuePair2 in keyValuePair.Value)
				{
					List<CssBlock> list = new List<CssBlock>();
					foreach (CssBlock cssBlock in keyValuePair2.Value)
					{
						list.Add(cssBlock.Clone());
					}
					dictionary[keyValuePair2.Key] = list;
				}
				cssData._mediaBlocks[keyValuePair.Key] = dictionary;
			}
			return cssData;
		}

		// Token: 0x06000A3F RID: 2623 RVA: 0x0000F92A File Offset: 0x0000DB2A
		static StringComparer smethod_0()
		{
			return StringComparer.InvariantCultureIgnoreCase;
		}

		// Token: 0x06000A40 RID: 2624 RVA: 0x0000CE13 File Offset: 0x0000B013
		static bool smethod_1(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06000A41 RID: 2625 RVA: 0x0000C8D9 File Offset: 0x0000AAD9
		static void smethod_2(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x040003DA RID: 986
		private static readonly List<CssBlock> _emptyArray = new List<CssBlock>();

		// Token: 0x040003DB RID: 987
		private readonly Dictionary<string, Dictionary<string, List<CssBlock>>> _mediaBlocks = new Dictionary<string, Dictionary<string, List<CssBlock>>>(CssData.smethod_0());
	}
}
