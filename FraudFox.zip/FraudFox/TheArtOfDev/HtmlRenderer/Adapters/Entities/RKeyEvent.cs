﻿using System;

namespace TheArtOfDev.HtmlRenderer.Adapters.Entities
{
	// Token: 0x020000BA RID: 186
	public sealed class RKeyEvent
	{
		// Token: 0x06000A5D RID: 2653 RVA: 0x0001041E File Offset: 0x0000E61E
		public RKeyEvent(bool control, bool aKeyCode, bool cKeyCode)
		{
			this._control = control;
			this._aKeyCode = aKeyCode;
			this._cKeyCode = cKeyCode;
		}

		// Token: 0x17000178 RID: 376
		// (get) Token: 0x06000A5E RID: 2654 RVA: 0x0001043B File Offset: 0x0000E63B
		public bool Control
		{
			get
			{
				return this._control;
			}
		}

		// Token: 0x17000179 RID: 377
		// (get) Token: 0x06000A5F RID: 2655 RVA: 0x00010443 File Offset: 0x0000E643
		public bool AKeyCode
		{
			get
			{
				return this._aKeyCode;
			}
		}

		// Token: 0x1700017A RID: 378
		// (get) Token: 0x06000A60 RID: 2656 RVA: 0x0001044B File Offset: 0x0000E64B
		public bool CKeyCode
		{
			get
			{
				return this._cKeyCode;
			}
		}

		// Token: 0x040003EB RID: 1003
		private readonly bool _control;

		// Token: 0x040003EC RID: 1004
		private readonly bool _aKeyCode;

		// Token: 0x040003ED RID: 1005
		private readonly bool _cKeyCode;
	}
}
