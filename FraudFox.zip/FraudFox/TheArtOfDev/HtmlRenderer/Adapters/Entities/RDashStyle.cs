﻿using System;

namespace TheArtOfDev.HtmlRenderer.Adapters.Entities
{
	// Token: 0x020000B8 RID: 184
	public enum RDashStyle
	{
		// Token: 0x040003DF RID: 991
		Solid,
		// Token: 0x040003E0 RID: 992
		Dash,
		// Token: 0x040003E1 RID: 993
		Dot,
		// Token: 0x040003E2 RID: 994
		DashDot,
		// Token: 0x040003E3 RID: 995
		DashDotDot,
		// Token: 0x040003E4 RID: 996
		Custom
	}
}
