﻿using System;

namespace TheArtOfDev.HtmlRenderer.Adapters.Entities
{
	// Token: 0x020000BB RID: 187
	public sealed class RMouseEvent
	{
		// Token: 0x06000A61 RID: 2657 RVA: 0x00010453 File Offset: 0x0000E653
		public RMouseEvent(bool leftButton)
		{
			this._leftButton = leftButton;
		}

		// Token: 0x1700017B RID: 379
		// (get) Token: 0x06000A62 RID: 2658 RVA: 0x00010462 File Offset: 0x0000E662
		public bool LeftButton
		{
			get
			{
				return this._leftButton;
			}
		}

		// Token: 0x040003EE RID: 1006
		private readonly bool _leftButton;
	}
}
