﻿using System;

namespace TheArtOfDev.HtmlRenderer.Adapters.Entities
{
	// Token: 0x020000B9 RID: 185
	[Flags]
	public enum RFontStyle
	{
		// Token: 0x040003E6 RID: 998
		Regular = 0,
		// Token: 0x040003E7 RID: 999
		Bold = 1,
		// Token: 0x040003E8 RID: 1000
		Italic = 2,
		// Token: 0x040003E9 RID: 1001
		Underline = 4,
		// Token: 0x040003EA RID: 1002
		Strikeout = 8
	}
}
