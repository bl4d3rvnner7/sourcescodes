﻿using System;

namespace TheArtOfDev.HtmlRenderer.Adapters.Entities
{
	// Token: 0x020000BC RID: 188
	public struct RPoint
	{
		// Token: 0x06000A64 RID: 2660 RVA: 0x00010477 File Offset: 0x0000E677
		public RPoint(double x, double y)
		{
			this._x = x;
			this._y = y;
		}

		// Token: 0x1700017C RID: 380
		// (get) Token: 0x06000A65 RID: 2661 RVA: 0x0004F590 File Offset: 0x0004D790
		public bool IsEmpty
		{
			get
			{
				return RPoint.smethod_0(this._x - 0.0) < 0.001 && RPoint.smethod_0(this._y - 0.0) < 0.001;
			}
		}

		// Token: 0x1700017D RID: 381
		// (get) Token: 0x06000A66 RID: 2662 RVA: 0x00010487 File Offset: 0x0000E687
		// (set) Token: 0x06000A67 RID: 2663 RVA: 0x0001048F File Offset: 0x0000E68F
		public double X
		{
			get
			{
				return this._x;
			}
			set
			{
				this._x = value;
			}
		}

		// Token: 0x1700017E RID: 382
		// (get) Token: 0x06000A68 RID: 2664 RVA: 0x00010498 File Offset: 0x0000E698
		// (set) Token: 0x06000A69 RID: 2665 RVA: 0x000104A0 File Offset: 0x0000E6A0
		public double Y
		{
			get
			{
				return this._y;
			}
			set
			{
				this._y = value;
			}
		}

		// Token: 0x06000A6A RID: 2666 RVA: 0x000104A9 File Offset: 0x0000E6A9
		public static RPoint operator +(RPoint pt, RSize sz)
		{
			return RPoint.Add(pt, sz);
		}

		// Token: 0x06000A6B RID: 2667 RVA: 0x000104B2 File Offset: 0x0000E6B2
		public static RPoint operator -(RPoint pt, RSize sz)
		{
			return RPoint.Subtract(pt, sz);
		}

		// Token: 0x06000A6C RID: 2668 RVA: 0x000104BB File Offset: 0x0000E6BB
		public static bool operator ==(RPoint left, RPoint right)
		{
			return left.X == right.X && left.Y == right.Y;
		}

		// Token: 0x06000A6D RID: 2669 RVA: 0x000104DF File Offset: 0x0000E6DF
		public static bool operator !=(RPoint left, RPoint right)
		{
			return !(left == right);
		}

		// Token: 0x06000A6E RID: 2670 RVA: 0x000104EB File Offset: 0x0000E6EB
		public static RPoint Add(RPoint pt, RSize sz)
		{
			return new RPoint(pt.X + sz.Width, pt.Y + sz.Height);
		}

		// Token: 0x06000A6F RID: 2671 RVA: 0x00010510 File Offset: 0x0000E710
		public static RPoint Subtract(RPoint pt, RSize sz)
		{
			return new RPoint(pt.X - sz.Width, pt.Y - sz.Height);
		}

		// Token: 0x06000A70 RID: 2672 RVA: 0x0004F5E0 File Offset: 0x0004D7E0
		public override bool Equals(object obj)
		{
			if (!(obj is RPoint))
			{
				return false;
			}
			RPoint rpoint = (RPoint)obj;
			return rpoint.X == this.X && rpoint.Y == this.Y && RPoint.smethod_2(RPoint.smethod_1(rpoint), RPoint.smethod_1(this));
		}

		// Token: 0x06000A71 RID: 2673 RVA: 0x00010535 File Offset: 0x0000E735
		public override int GetHashCode()
		{
			return this.method_0();
		}

		// Token: 0x06000A72 RID: 2674 RVA: 0x0004F640 File Offset: 0x0004D840
		public override string ToString()
		{
			return RPoint.smethod_3(<Module>.smethod_23<string>(3865677174U), new object[] { this._x, this._y });
		}

		// Token: 0x06000A73 RID: 2675 RVA: 0x0000FC9F File Offset: 0x0000DE9F
		static double smethod_0(double double_0)
		{
			return Math.Abs(double_0);
		}

		// Token: 0x06000A74 RID: 2676 RVA: 0x0001040D File Offset: 0x0000E60D
		static Type smethod_1(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06000A75 RID: 2677 RVA: 0x00010547 File Offset: 0x0000E747
		static bool smethod_2(Type type_0, Type type_1)
		{
			return type_0.Equals(type_1);
		}

		// Token: 0x06000A76 RID: 2678 RVA: 0x00010550 File Offset: 0x0000E750
		int method_0()
		{
			return base.GetHashCode();
		}

		// Token: 0x06000A77 RID: 2679 RVA: 0x0000CD33 File Offset: 0x0000AF33
		static string smethod_3(string string_0, object[] object_0)
		{
			return string.Format(string_0, object_0);
		}

		// Token: 0x040003EF RID: 1007
		public static readonly RPoint Empty = default(RPoint);

		// Token: 0x040003F0 RID: 1008
		private double _x;

		// Token: 0x040003F1 RID: 1009
		private double _y;
	}
}
