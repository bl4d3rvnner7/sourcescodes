﻿using System;
using System.Reflection;
using System.Text;

namespace TheArtOfDev.HtmlRenderer.Adapters.Entities
{
	// Token: 0x020000B7 RID: 183
	public struct RColor
	{
		// Token: 0x06000A42 RID: 2626 RVA: 0x000102B0 File Offset: 0x0000E4B0
		private RColor(long value)
		{
			this._value = value;
		}

		// Token: 0x1700016E RID: 366
		// (get) Token: 0x06000A43 RID: 2627 RVA: 0x000102B9 File Offset: 0x0000E4B9
		public static RColor Transparent
		{
			get
			{
				return new RColor(0L);
			}
		}

		// Token: 0x1700016F RID: 367
		// (get) Token: 0x06000A44 RID: 2628 RVA: 0x000102C9 File Offset: 0x0000E4C9
		public static RColor Black
		{
			get
			{
				return RColor.FromArgb(0, 0, 0);
			}
		}

		// Token: 0x17000170 RID: 368
		// (get) Token: 0x06000A45 RID: 2629 RVA: 0x000102D3 File Offset: 0x0000E4D3
		public static RColor White
		{
			get
			{
				return RColor.FromArgb(255, 255, 255);
			}
		}

		// Token: 0x17000171 RID: 369
		// (get) Token: 0x06000A46 RID: 2630 RVA: 0x000102E9 File Offset: 0x0000E4E9
		public static RColor WhiteSmoke
		{
			get
			{
				return RColor.FromArgb(245, 245, 245);
			}
		}

		// Token: 0x17000172 RID: 370
		// (get) Token: 0x06000A47 RID: 2631 RVA: 0x000102FF File Offset: 0x0000E4FF
		public static RColor LightGray
		{
			get
			{
				return RColor.FromArgb(211, 211, 211);
			}
		}

		// Token: 0x17000173 RID: 371
		// (get) Token: 0x06000A48 RID: 2632 RVA: 0x00010315 File Offset: 0x0000E515
		public byte R
		{
			get
			{
				return (byte)((this._value >> 16) & 255L);
			}
		}

		// Token: 0x17000174 RID: 372
		// (get) Token: 0x06000A49 RID: 2633 RVA: 0x0001032B File Offset: 0x0000E52B
		public byte G
		{
			get
			{
				return (byte)((this._value >> 8) & 255L);
			}
		}

		// Token: 0x17000175 RID: 373
		// (get) Token: 0x06000A4A RID: 2634 RVA: 0x00010340 File Offset: 0x0000E540
		public byte B
		{
			get
			{
				return (byte)(this._value & 255L);
			}
		}

		// Token: 0x17000176 RID: 374
		// (get) Token: 0x06000A4B RID: 2635 RVA: 0x00010353 File Offset: 0x0000E553
		public byte A
		{
			get
			{
				return (byte)((this._value >> 24) & 255L);
			}
		}

		// Token: 0x17000177 RID: 375
		// (get) Token: 0x06000A4C RID: 2636 RVA: 0x00010369 File Offset: 0x0000E569
		public bool IsEmpty
		{
			get
			{
				return this._value == 0L;
			}
		}

		// Token: 0x06000A4D RID: 2637 RVA: 0x0001037C File Offset: 0x0000E57C
		public static bool operator ==(RColor left, RColor right)
		{
			return left._value == right._value;
		}

		// Token: 0x06000A4E RID: 2638 RVA: 0x0001038E File Offset: 0x0000E58E
		public static bool operator !=(RColor left, RColor right)
		{
			return !(left == right);
		}

		// Token: 0x06000A4F RID: 2639 RVA: 0x0001039A File Offset: 0x0000E59A
		public static RColor FromArgb(int alpha, int red, int green, int blue)
		{
			RColor.CheckByte(alpha);
			RColor.CheckByte(red);
			RColor.CheckByte(green);
			RColor.CheckByte(blue);
			return new RColor((long)((ulong)((red << 16) | (green << 8) | blue | (alpha << 24)) & 4294967295UL));
		}

		// Token: 0x06000A50 RID: 2640 RVA: 0x000103D3 File Offset: 0x0000E5D3
		public static RColor FromArgb(int red, int green, int blue)
		{
			return RColor.FromArgb(255, red, green, blue);
		}

		// Token: 0x06000A51 RID: 2641 RVA: 0x0004F44C File Offset: 0x0004D64C
		public override bool Equals(object obj)
		{
			if (obj is RColor)
			{
				RColor rcolor = (RColor)obj;
				return this._value == rcolor._value;
			}
			return false;
		}

		// Token: 0x06000A52 RID: 2642 RVA: 0x0004F47C File Offset: 0x0004D67C
		public override int GetHashCode()
		{
			return this._value.GetHashCode();
		}

		// Token: 0x06000A53 RID: 2643 RVA: 0x0004F498 File Offset: 0x0004D698
		public override string ToString()
		{
			StringBuilder stringBuilder = RColor.smethod_0(32);
			RColor.smethod_3(stringBuilder, RColor.smethod_2(RColor.smethod_1(this)));
			RColor.smethod_3(stringBuilder, <Module>.smethod_27<string>(2560814972U));
			if (this._value != 0L)
			{
				RColor.smethod_3(stringBuilder, <Module>.smethod_25<string>(906849489U));
				RColor.smethod_4(stringBuilder, this.A);
				RColor.smethod_3(stringBuilder, <Module>.smethod_26<string>(4123702760U));
				RColor.smethod_4(stringBuilder, this.R);
				RColor.smethod_3(stringBuilder, <Module>.smethod_25<string>(628459677U));
				RColor.smethod_4(stringBuilder, this.G);
				RColor.smethod_3(stringBuilder, <Module>.smethod_27<string>(2187841428U));
				RColor.smethod_4(stringBuilder, this.B);
			}
			else
			{
				RColor.smethod_3(stringBuilder, <Module>.smethod_25<string>(1463629113U));
			}
			RColor.smethod_3(stringBuilder, <Module>.smethod_26<string>(552543675U));
			return RColor.smethod_5(stringBuilder);
		}

		// Token: 0x06000A54 RID: 2644 RVA: 0x000103E2 File Offset: 0x0000E5E2
		private static void CheckByte(int value)
		{
			if (value < 0 || value > 255)
			{
				throw RColor.smethod_6(<Module>.smethod_24<string>(3596265462U));
			}
		}

		// Token: 0x06000A56 RID: 2646 RVA: 0x0000FD8A File Offset: 0x0000DF8A
		static StringBuilder smethod_0(int int_0)
		{
			return new StringBuilder(int_0);
		}

		// Token: 0x06000A57 RID: 2647 RVA: 0x0001040D File Offset: 0x0000E60D
		static Type smethod_1(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06000A58 RID: 2648 RVA: 0x0000FF2A File Offset: 0x0000E12A
		static string smethod_2(MemberInfo memberInfo_0)
		{
			return memberInfo_0.Name;
		}

		// Token: 0x06000A59 RID: 2649 RVA: 0x0000DB11 File Offset: 0x0000BD11
		static StringBuilder smethod_3(StringBuilder stringBuilder_0, string string_0)
		{
			return stringBuilder_0.Append(string_0);
		}

		// Token: 0x06000A5A RID: 2650 RVA: 0x00010415 File Offset: 0x0000E615
		static StringBuilder smethod_4(StringBuilder stringBuilder_0, byte byte_0)
		{
			return stringBuilder_0.Append(byte_0);
		}

		// Token: 0x06000A5B RID: 2651 RVA: 0x0000D833 File Offset: 0x0000BA33
		static string smethod_5(object object_0)
		{
			return object_0.ToString();
		}

		// Token: 0x06000A5C RID: 2652 RVA: 0x0000C351 File Offset: 0x0000A551
		static ArgumentException smethod_6(string string_0)
		{
			return new ArgumentException(string_0);
		}

		// Token: 0x040003DC RID: 988
		public static readonly RColor Empty = default(RColor);

		// Token: 0x040003DD RID: 989
		private readonly long _value;
	}
}
