﻿using System;

namespace TheArtOfDev.HtmlRenderer.Adapters.Entities
{
	// Token: 0x020000BD RID: 189
	public struct RRect
	{
		// Token: 0x06000A78 RID: 2680 RVA: 0x00010558 File Offset: 0x0000E758
		public RRect(double x, double y, double width, double height)
		{
			this._x = x;
			this._y = y;
			this._width = width;
			this._height = height;
		}

		// Token: 0x06000A79 RID: 2681 RVA: 0x00010577 File Offset: 0x0000E777
		public RRect(RPoint location, RSize size)
		{
			this._x = location.X;
			this._y = location.Y;
			this._width = size.Width;
			this._height = size.Height;
		}

		// Token: 0x1700017F RID: 383
		// (get) Token: 0x06000A7A RID: 2682 RVA: 0x000105AD File Offset: 0x0000E7AD
		// (set) Token: 0x06000A7B RID: 2683 RVA: 0x000105C0 File Offset: 0x0000E7C0
		public RPoint Location
		{
			get
			{
				return new RPoint(this.X, this.Y);
			}
			set
			{
				this.X = value.X;
				this.Y = value.Y;
			}
		}

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x06000A7C RID: 2684 RVA: 0x000105DC File Offset: 0x0000E7DC
		// (set) Token: 0x06000A7D RID: 2685 RVA: 0x000105EF File Offset: 0x0000E7EF
		public RSize Size
		{
			get
			{
				return new RSize(this.Width, this.Height);
			}
			set
			{
				this.Width = value.Width;
				this.Height = value.Height;
			}
		}

		// Token: 0x17000181 RID: 385
		// (get) Token: 0x06000A7E RID: 2686 RVA: 0x0001060B File Offset: 0x0000E80B
		// (set) Token: 0x06000A7F RID: 2687 RVA: 0x00010613 File Offset: 0x0000E813
		public double X
		{
			get
			{
				return this._x;
			}
			set
			{
				this._x = value;
			}
		}

		// Token: 0x17000182 RID: 386
		// (get) Token: 0x06000A80 RID: 2688 RVA: 0x0001061C File Offset: 0x0000E81C
		// (set) Token: 0x06000A81 RID: 2689 RVA: 0x00010624 File Offset: 0x0000E824
		public double Y
		{
			get
			{
				return this._y;
			}
			set
			{
				this._y = value;
			}
		}

		// Token: 0x17000183 RID: 387
		// (get) Token: 0x06000A82 RID: 2690 RVA: 0x0001062D File Offset: 0x0000E82D
		// (set) Token: 0x06000A83 RID: 2691 RVA: 0x00010635 File Offset: 0x0000E835
		public double Width
		{
			get
			{
				return this._width;
			}
			set
			{
				this._width = value;
			}
		}

		// Token: 0x17000184 RID: 388
		// (get) Token: 0x06000A84 RID: 2692 RVA: 0x0001063E File Offset: 0x0000E83E
		// (set) Token: 0x06000A85 RID: 2693 RVA: 0x00010646 File Offset: 0x0000E846
		public double Height
		{
			get
			{
				return this._height;
			}
			set
			{
				this._height = value;
			}
		}

		// Token: 0x17000185 RID: 389
		// (get) Token: 0x06000A86 RID: 2694 RVA: 0x0001064F File Offset: 0x0000E84F
		public double Left
		{
			get
			{
				return this.X;
			}
		}

		// Token: 0x17000186 RID: 390
		// (get) Token: 0x06000A87 RID: 2695 RVA: 0x00010657 File Offset: 0x0000E857
		public double Top
		{
			get
			{
				return this.Y;
			}
		}

		// Token: 0x17000187 RID: 391
		// (get) Token: 0x06000A88 RID: 2696 RVA: 0x0001065F File Offset: 0x0000E85F
		public double Right
		{
			get
			{
				return this.X + this.Width;
			}
		}

		// Token: 0x17000188 RID: 392
		// (get) Token: 0x06000A89 RID: 2697 RVA: 0x0001066E File Offset: 0x0000E86E
		public double Bottom
		{
			get
			{
				return this.Y + this.Height;
			}
		}

		// Token: 0x17000189 RID: 393
		// (get) Token: 0x06000A8A RID: 2698 RVA: 0x0001067D File Offset: 0x0000E87D
		public bool IsEmpty
		{
			get
			{
				return this.Width <= 0.0 || this.Height <= 0.0;
			}
		}

		// Token: 0x06000A8B RID: 2699 RVA: 0x0004F680 File Offset: 0x0004D880
		public static bool operator ==(RRect left, RRect right)
		{
			return RRect.smethod_0(left.X - right.X) < 0.001 && RRect.smethod_0(left.Y - right.Y) < 0.001 && RRect.smethod_0(left.Width - right.Width) < 0.001 && RRect.smethod_0(left.Height - right.Height) < 0.001;
		}

		// Token: 0x06000A8C RID: 2700 RVA: 0x000106A6 File Offset: 0x0000E8A6
		public static bool operator !=(RRect left, RRect right)
		{
			return !(left == right);
		}

		// Token: 0x06000A8D RID: 2701 RVA: 0x000106B2 File Offset: 0x0000E8B2
		public static RRect FromLTRB(double left, double top, double right, double bottom)
		{
			return new RRect(left, top, right - left, bottom - top);
		}

		// Token: 0x06000A8E RID: 2702 RVA: 0x0004F70C File Offset: 0x0004D90C
		public override bool Equals(object obj)
		{
			if (obj is RRect)
			{
				RRect rrect = (RRect)obj;
				return RRect.smethod_0(rrect.X - this.X) < 0.001 && RRect.smethod_0(rrect.Y - this.Y) < 0.001 && RRect.smethod_0(rrect.Width - this.Width) < 0.001 && RRect.smethod_0(rrect.Height - this.Height) < 0.001;
			}
			return false;
		}

		// Token: 0x06000A8F RID: 2703 RVA: 0x000106C1 File Offset: 0x0000E8C1
		public bool Contains(double x, double y)
		{
			return this.X <= x && x < this.X + this.Width && this.Y <= y && y < this.Y + this.Height;
		}

		// Token: 0x06000A90 RID: 2704 RVA: 0x000106F7 File Offset: 0x0000E8F7
		public bool Contains(RPoint pt)
		{
			return this.Contains(pt.X, pt.Y);
		}

		// Token: 0x06000A91 RID: 2705 RVA: 0x0004F7A8 File Offset: 0x0004D9A8
		public bool Contains(RRect rect)
		{
			return this.X <= rect.X && rect.X + rect.Width <= this.X + this.Width && this.Y <= rect.Y && rect.Y + rect.Height <= this.Y + this.Height;
		}

		// Token: 0x06000A92 RID: 2706 RVA: 0x0004F814 File Offset: 0x0004DA14
		public void Inflate(double x, double y)
		{
			this.X -= x;
			this.Y -= y;
			this.Width += 2.0 * x;
			this.Height += 2.0 * y;
		}

		// Token: 0x06000A93 RID: 2707 RVA: 0x0001070D File Offset: 0x0000E90D
		public void Inflate(RSize size)
		{
			this.Inflate(size.Width, size.Height);
		}

		// Token: 0x06000A94 RID: 2708 RVA: 0x0004F870 File Offset: 0x0004DA70
		public static RRect Inflate(RRect rect, double x, double y)
		{
			RRect rrect = rect;
			rrect.Inflate(x, y);
			return rrect;
		}

		// Token: 0x06000A95 RID: 2709 RVA: 0x0004F88C File Offset: 0x0004DA8C
		public void Intersect(RRect rect)
		{
			RRect rrect = RRect.Intersect(rect, this);
			this.X = rrect.X;
			this.Y = rrect.Y;
			this.Width = rrect.Width;
			this.Height = rrect.Height;
		}

		// Token: 0x06000A96 RID: 2710 RVA: 0x0004F8DC File Offset: 0x0004DADC
		public static RRect Intersect(RRect a, RRect b)
		{
			double num = RRect.smethod_1(a.X, b.X);
			double num2 = RRect.smethod_2(a.X + a.Width, b.X + b.Width);
			double num3 = RRect.smethod_1(a.Y, b.Y);
			double num4 = RRect.smethod_2(a.Y + a.Height, b.Y + b.Height);
			if (num2 >= num && num4 >= num3)
			{
				return new RRect(num, num3, num2 - num, num4 - num3);
			}
			return RRect.Empty;
		}

		// Token: 0x06000A97 RID: 2711 RVA: 0x0004F974 File Offset: 0x0004DB74
		public bool IntersectsWith(RRect rect)
		{
			return rect.X < this.X + this.Width && this.X < rect.X + rect.Width && rect.Y < this.Y + this.Height && this.Y < rect.Y + rect.Height;
		}

		// Token: 0x06000A98 RID: 2712 RVA: 0x0004F9E0 File Offset: 0x0004DBE0
		public static RRect Union(RRect a, RRect b)
		{
			double num = RRect.smethod_2(a.X, b.X);
			double num2 = RRect.smethod_1(a.X + a.Width, b.X + b.Width);
			double num3 = RRect.smethod_2(a.Y, b.Y);
			double num4 = RRect.smethod_1(a.Y + a.Height, b.Y + b.Height);
			return new RRect(num, num3, num2 - num, num4 - num3);
		}

		// Token: 0x06000A99 RID: 2713 RVA: 0x00010723 File Offset: 0x0000E923
		public void Offset(RPoint pos)
		{
			this.Offset(pos.X, pos.Y);
		}

		// Token: 0x06000A9A RID: 2714 RVA: 0x00010739 File Offset: 0x0000E939
		public void Offset(double x, double y)
		{
			this.X += x;
			this.Y += y;
		}

		// Token: 0x06000A9B RID: 2715 RVA: 0x0004FA6C File Offset: 0x0004DC6C
		public override int GetHashCode()
		{
			return (int)((uint)this.X ^ (((uint)this.Y << 13) | ((uint)this.Y >> 19)) ^ (((uint)this.Width << 26) | ((uint)this.Width >> 6)) ^ (((uint)this.Height << 7) | ((uint)this.Height >> 25)));
		}

		// Token: 0x06000A9C RID: 2716 RVA: 0x0004FAC0 File Offset: 0x0004DCC0
		public override string ToString()
		{
			return RRect.smethod_3(new object[]
			{
				<Module>.smethod_25<string>(2507590908U),
				this.X,
				<Module>.smethod_27<string>(1488516033U),
				this.Y,
				<Module>.smethod_23<string>(1640366775U),
				this.Width,
				<Module>.smethod_23<string>(2201397906U),
				this.Height,
				<Module>.smethod_27<string>(2168350252U)
			});
		}

		// Token: 0x06000A9E RID: 2718 RVA: 0x0000FC9F File Offset: 0x0000DE9F
		static double smethod_0(double double_0)
		{
			return Math.Abs(double_0);
		}

		// Token: 0x06000A9F RID: 2719 RVA: 0x0000ED6A File Offset: 0x0000CF6A
		static double smethod_1(double double_0, double double_1)
		{
			return Math.Max(double_0, double_1);
		}

		// Token: 0x06000AA0 RID: 2720 RVA: 0x0000EF08 File Offset: 0x0000D108
		static double smethod_2(double double_0, double double_1)
		{
			return Math.Min(double_0, double_1);
		}

		// Token: 0x06000AA1 RID: 2721 RVA: 0x00010764 File Offset: 0x0000E964
		static string smethod_3(object[] object_0)
		{
			return string.Concat(object_0);
		}

		// Token: 0x040003F2 RID: 1010
		public static readonly RRect Empty = default(RRect);

		// Token: 0x040003F3 RID: 1011
		private double _height;

		// Token: 0x040003F4 RID: 1012
		private double _width;

		// Token: 0x040003F5 RID: 1013
		private double _x;

		// Token: 0x040003F6 RID: 1014
		private double _y;
	}
}
