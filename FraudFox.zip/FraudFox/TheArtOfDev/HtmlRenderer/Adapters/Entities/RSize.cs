﻿using System;

namespace TheArtOfDev.HtmlRenderer.Adapters.Entities
{
	// Token: 0x020000BE RID: 190
	public struct RSize
	{
		// Token: 0x06000AA2 RID: 2722 RVA: 0x0001076C File Offset: 0x0000E96C
		public RSize(RSize size)
		{
			this._width = size._width;
			this._height = size._height;
		}

		// Token: 0x06000AA3 RID: 2723 RVA: 0x00010788 File Offset: 0x0000E988
		public RSize(RPoint pt)
		{
			this._width = pt.X;
			this._height = pt.Y;
		}

		// Token: 0x06000AA4 RID: 2724 RVA: 0x000107A4 File Offset: 0x0000E9A4
		public RSize(double width, double height)
		{
			this._width = width;
			this._height = height;
		}

		// Token: 0x1700018A RID: 394
		// (get) Token: 0x06000AA5 RID: 2725 RVA: 0x000107B4 File Offset: 0x0000E9B4
		public bool IsEmpty
		{
			get
			{
				return RSize.smethod_0(this._width) < 0.0001 && RSize.smethod_0(this._height) < 0.0001;
			}
		}

		// Token: 0x1700018B RID: 395
		// (get) Token: 0x06000AA6 RID: 2726 RVA: 0x000107E4 File Offset: 0x0000E9E4
		// (set) Token: 0x06000AA7 RID: 2727 RVA: 0x000107EC File Offset: 0x0000E9EC
		public double Width
		{
			get
			{
				return this._width;
			}
			set
			{
				this._width = value;
			}
		}

		// Token: 0x1700018C RID: 396
		// (get) Token: 0x06000AA8 RID: 2728 RVA: 0x000107F5 File Offset: 0x0000E9F5
		// (set) Token: 0x06000AA9 RID: 2729 RVA: 0x000107FD File Offset: 0x0000E9FD
		public double Height
		{
			get
			{
				return this._height;
			}
			set
			{
				this._height = value;
			}
		}

		// Token: 0x06000AAA RID: 2730 RVA: 0x00010806 File Offset: 0x0000EA06
		public static explicit operator RPoint(RSize size)
		{
			return new RPoint(size.Width, size.Height);
		}

		// Token: 0x06000AAB RID: 2731 RVA: 0x0001081B File Offset: 0x0000EA1B
		public static RSize operator +(RSize sz1, RSize sz2)
		{
			return RSize.Add(sz1, sz2);
		}

		// Token: 0x06000AAC RID: 2732 RVA: 0x00010824 File Offset: 0x0000EA24
		public static RSize operator -(RSize sz1, RSize sz2)
		{
			return RSize.Subtract(sz1, sz2);
		}

		// Token: 0x06000AAD RID: 2733 RVA: 0x0004FB54 File Offset: 0x0004DD54
		public static bool operator ==(RSize sz1, RSize sz2)
		{
			return RSize.smethod_0(sz1.Width - sz2.Width) < 0.001 && RSize.smethod_0(sz1.Height - sz2.Height) < 0.001;
		}

		// Token: 0x06000AAE RID: 2734 RVA: 0x0001082D File Offset: 0x0000EA2D
		public static bool operator !=(RSize sz1, RSize sz2)
		{
			return !(sz1 == sz2);
		}

		// Token: 0x06000AAF RID: 2735 RVA: 0x00010839 File Offset: 0x0000EA39
		public static RSize Add(RSize sz1, RSize sz2)
		{
			return new RSize(sz1.Width + sz2.Width, sz1.Height + sz2.Height);
		}

		// Token: 0x06000AB0 RID: 2736 RVA: 0x0001085E File Offset: 0x0000EA5E
		public static RSize Subtract(RSize sz1, RSize sz2)
		{
			return new RSize(sz1.Width - sz2.Width, sz1.Height - sz2.Height);
		}

		// Token: 0x06000AB1 RID: 2737 RVA: 0x0004FBA4 File Offset: 0x0004DDA4
		public override bool Equals(object obj)
		{
			if (obj is RSize)
			{
				RSize rsize = (RSize)obj;
				return RSize.smethod_0(rsize.Width - this.Width) < 0.001 && RSize.smethod_0(rsize.Height - this.Height) < 0.001 && RSize.smethod_2(RSize.smethod_1(rsize), RSize.smethod_1(this));
			}
			return false;
		}

		// Token: 0x06000AB2 RID: 2738 RVA: 0x00010883 File Offset: 0x0000EA83
		public override int GetHashCode()
		{
			return this.method_0();
		}

		// Token: 0x06000AB3 RID: 2739 RVA: 0x00010895 File Offset: 0x0000EA95
		public RPoint ToPointF()
		{
			return (RPoint)this;
		}

		// Token: 0x06000AB4 RID: 2740 RVA: 0x0004FC20 File Offset: 0x0004DE20
		public override string ToString()
		{
			return RSize.smethod_3(new object[]
			{
				<Module>.smethod_23<string>(518304513U),
				this._width,
				<Module>.smethod_26<string>(4181161124U),
				this._height,
				<Module>.smethod_23<string>(1901810348U)
			});
		}

		// Token: 0x06000AB6 RID: 2742 RVA: 0x0000FC9F File Offset: 0x0000DE9F
		static double smethod_0(double double_0)
		{
			return Math.Abs(double_0);
		}

		// Token: 0x06000AB7 RID: 2743 RVA: 0x0001040D File Offset: 0x0000E60D
		static Type smethod_1(object object_0)
		{
			return object_0.GetType();
		}

		// Token: 0x06000AB8 RID: 2744 RVA: 0x000108AF File Offset: 0x0000EAAF
		static bool smethod_2(Type type_0, Type type_1)
		{
			return type_0 == type_1;
		}

		// Token: 0x06000AB9 RID: 2745 RVA: 0x00010550 File Offset: 0x0000E750
		int method_0()
		{
			return base.GetHashCode();
		}

		// Token: 0x06000ABA RID: 2746 RVA: 0x00010764 File Offset: 0x0000E964
		static string smethod_3(object[] object_0)
		{
			return string.Concat(object_0);
		}

		// Token: 0x040003F7 RID: 1015
		public static readonly RSize Empty = default(RSize);

		// Token: 0x040003F8 RID: 1016
		private double _height;

		// Token: 0x040003F9 RID: 1017
		private double _width;
	}
}
