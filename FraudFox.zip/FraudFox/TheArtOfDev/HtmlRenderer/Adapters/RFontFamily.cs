﻿using System;

namespace TheArtOfDev.HtmlRenderer.Adapters
{
	// Token: 0x020000C4 RID: 196
	public abstract class RFontFamily
	{
		// Token: 0x17000197 RID: 407
		// (get) Token: 0x06000AFD RID: 2813
		public abstract string Name { get; }
	}
}
