﻿using System;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Adapters
{
	// Token: 0x020000C2 RID: 194
	public abstract class RControl
	{
		// Token: 0x06000AEC RID: 2796 RVA: 0x000109BD File Offset: 0x0000EBBD
		protected RControl(RAdapter adapter)
		{
			ArgChecker.AssertArgNotNull(adapter, <Module>.smethod_24<string>(1626870024U));
			this._adapter = adapter;
		}

		// Token: 0x1700018F RID: 399
		// (get) Token: 0x06000AED RID: 2797 RVA: 0x000109DC File Offset: 0x0000EBDC
		public RAdapter Adapter
		{
			get
			{
				return this._adapter;
			}
		}

		// Token: 0x17000190 RID: 400
		// (get) Token: 0x06000AEE RID: 2798
		public abstract bool LeftMouseButton { get; }

		// Token: 0x17000191 RID: 401
		// (get) Token: 0x06000AEF RID: 2799
		public abstract bool RightMouseButton { get; }

		// Token: 0x17000192 RID: 402
		// (get) Token: 0x06000AF0 RID: 2800
		public abstract RPoint MouseLocation { get; }

		// Token: 0x06000AF1 RID: 2801
		public abstract void SetCursorDefault();

		// Token: 0x06000AF2 RID: 2802
		public abstract void SetCursorHand();

		// Token: 0x06000AF3 RID: 2803
		public abstract void SetCursorIBeam();

		// Token: 0x06000AF4 RID: 2804
		public abstract void DoDragDropCopy(object dragDropData);

		// Token: 0x06000AF5 RID: 2805
		public abstract void MeasureString(string str, RFont font, double maxWidth, out int charFit, out double charFitWidth);

		// Token: 0x06000AF6 RID: 2806
		public abstract void Invalidate();

		// Token: 0x04000400 RID: 1024
		private readonly RAdapter _adapter;
	}
}
