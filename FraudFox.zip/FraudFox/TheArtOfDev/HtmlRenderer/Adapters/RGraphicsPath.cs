﻿using System;

namespace TheArtOfDev.HtmlRenderer.Adapters
{
	// Token: 0x020000C6 RID: 198
	public abstract class RGraphicsPath : IDisposable
	{
		// Token: 0x06000B17 RID: 2839
		public abstract void Start(double x, double y);

		// Token: 0x06000B18 RID: 2840
		public abstract void LineTo(double x, double y);

		// Token: 0x06000B19 RID: 2841
		public abstract void ArcTo(double x, double y, double size, RGraphicsPath.Corner corner);

		// Token: 0x06000B1A RID: 2842
		public abstract void Dispose();

		// Token: 0x020000C7 RID: 199
		public enum Corner
		{
			// Token: 0x04000404 RID: 1028
			TopLeft,
			// Token: 0x04000405 RID: 1029
			TopRight,
			// Token: 0x04000406 RID: 1030
			BottomLeft,
			// Token: 0x04000407 RID: 1031
			BottomRight
		}
	}
}
