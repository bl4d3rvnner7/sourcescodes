﻿using System;
using System.Collections.Generic;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Adapters
{
	// Token: 0x020000C5 RID: 197
	public abstract class RGraphics : IDisposable
	{
		// Token: 0x06000AFF RID: 2815 RVA: 0x000109E4 File Offset: 0x0000EBE4
		protected RGraphics(RAdapter adapter, RRect initialClip)
		{
			ArgChecker.AssertArgNotNull(adapter, <Module>.smethod_24<string>(3511416563U));
			this._adapter = adapter;
			this._clipStack.Push(initialClip);
		}

		// Token: 0x06000B00 RID: 2816 RVA: 0x00010A1A File Offset: 0x0000EC1A
		public RPen GetPen(RColor color)
		{
			return this._adapter.GetPen(color);
		}

		// Token: 0x06000B01 RID: 2817 RVA: 0x00010A28 File Offset: 0x0000EC28
		public RBrush GetSolidBrush(RColor color)
		{
			return this._adapter.GetSolidBrush(color);
		}

		// Token: 0x06000B02 RID: 2818 RVA: 0x00010A36 File Offset: 0x0000EC36
		public RBrush GetLinearGradientBrush(RRect rect, RColor color1, RColor color2, double angle)
		{
			return this._adapter.GetLinearGradientBrush(rect, color1, color2, angle);
		}

		// Token: 0x06000B03 RID: 2819 RVA: 0x00010A48 File Offset: 0x0000EC48
		public RRect GetClip()
		{
			return this._clipStack.Peek();
		}

		// Token: 0x06000B04 RID: 2820
		public abstract void PopClip();

		// Token: 0x06000B05 RID: 2821
		public abstract void PushClip(RRect rect);

		// Token: 0x06000B06 RID: 2822
		public abstract void PushClipExclude(RRect rect);

		// Token: 0x06000B07 RID: 2823
		public abstract object SetAntiAliasSmoothingMode();

		// Token: 0x06000B08 RID: 2824
		public abstract void ReturnPreviousSmoothingMode(object prevMode);

		// Token: 0x06000B09 RID: 2825
		public abstract RBrush GetTextureBrush(RImage image, RRect dstRect, RPoint translateTransformLocation);

		// Token: 0x06000B0A RID: 2826
		public abstract RGraphicsPath GetGraphicsPath();

		// Token: 0x06000B0B RID: 2827
		public abstract RSize MeasureString(string str, RFont font);

		// Token: 0x06000B0C RID: 2828
		public abstract void MeasureString(string str, RFont font, double maxWidth, out int charFit, out double charFitWidth);

		// Token: 0x06000B0D RID: 2829
		public abstract void DrawString(string str, RFont font, RColor color, RPoint point, RSize size, bool rtl);

		// Token: 0x06000B0E RID: 2830
		public abstract void DrawLine(RPen pen, double x1, double y1, double x2, double y2);

		// Token: 0x06000B0F RID: 2831
		public abstract void DrawRectangle(RPen pen, double x, double y, double width, double height);

		// Token: 0x06000B10 RID: 2832
		public abstract void DrawRectangle(RBrush brush, double x, double y, double width, double height);

		// Token: 0x06000B11 RID: 2833
		public abstract void DrawImage(RImage image, RRect destRect, RRect srcRect);

		// Token: 0x06000B12 RID: 2834
		public abstract void DrawImage(RImage image, RRect destRect);

		// Token: 0x06000B13 RID: 2835
		public abstract void DrawPath(RPen pen, RGraphicsPath path);

		// Token: 0x06000B14 RID: 2836
		public abstract void DrawPath(RBrush brush, RGraphicsPath path);

		// Token: 0x06000B15 RID: 2837
		public abstract void DrawPolygon(RBrush brush, RPoint[] points);

		// Token: 0x06000B16 RID: 2838
		public abstract void Dispose();

		// Token: 0x04000401 RID: 1025
		protected readonly RAdapter _adapter;

		// Token: 0x04000402 RID: 1026
		protected readonly Stack<RRect> _clipStack = new Stack<RRect>();
	}
}
