﻿using System;

namespace TheArtOfDev.HtmlRenderer.Adapters
{
	// Token: 0x020000C0 RID: 192
	public abstract class RBrush : IDisposable
	{
		// Token: 0x06000AE3 RID: 2787
		public abstract void Dispose();
	}
}
