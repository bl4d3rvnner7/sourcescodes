﻿using System;

namespace TheArtOfDev.HtmlRenderer.Adapters
{
	// Token: 0x020000C3 RID: 195
	public abstract class RFont
	{
		// Token: 0x17000193 RID: 403
		// (get) Token: 0x06000AF7 RID: 2807
		public abstract double Size { get; }

		// Token: 0x17000194 RID: 404
		// (get) Token: 0x06000AF8 RID: 2808
		public abstract double Height { get; }

		// Token: 0x17000195 RID: 405
		// (get) Token: 0x06000AF9 RID: 2809
		public abstract double UnderlineOffset { get; }

		// Token: 0x17000196 RID: 406
		// (get) Token: 0x06000AFA RID: 2810
		public abstract double LeftPadding { get; }

		// Token: 0x06000AFB RID: 2811
		public abstract double GetWhitespaceWidth(RGraphics graphics);
	}
}
