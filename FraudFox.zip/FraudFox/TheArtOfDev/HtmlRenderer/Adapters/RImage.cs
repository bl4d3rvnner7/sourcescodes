﻿using System;

namespace TheArtOfDev.HtmlRenderer.Adapters
{
	// Token: 0x020000C8 RID: 200
	public abstract class RImage : IDisposable
	{
		// Token: 0x17000198 RID: 408
		// (get) Token: 0x06000B1C RID: 2844
		public abstract double Width { get; }

		// Token: 0x17000199 RID: 409
		// (get) Token: 0x06000B1D RID: 2845
		public abstract double Height { get; }

		// Token: 0x06000B1E RID: 2846
		public abstract void Dispose();
	}
}
