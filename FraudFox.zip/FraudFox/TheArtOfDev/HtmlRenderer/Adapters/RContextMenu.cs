﻿using System;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;

namespace TheArtOfDev.HtmlRenderer.Adapters
{
	// Token: 0x020000C1 RID: 193
	public abstract class RContextMenu : IDisposable
	{
		// Token: 0x1700018E RID: 398
		// (get) Token: 0x06000AE5 RID: 2789
		public abstract int ItemsCount { get; }

		// Token: 0x06000AE6 RID: 2790
		public abstract void AddDivider();

		// Token: 0x06000AE7 RID: 2791
		public abstract void AddItem(string text, bool enabled, EventHandler onClick);

		// Token: 0x06000AE8 RID: 2792
		public abstract void RemoveLastDivider();

		// Token: 0x06000AE9 RID: 2793
		public abstract void Show(RControl parent, RPoint location);

		// Token: 0x06000AEA RID: 2794
		public abstract void Dispose();
	}
}
