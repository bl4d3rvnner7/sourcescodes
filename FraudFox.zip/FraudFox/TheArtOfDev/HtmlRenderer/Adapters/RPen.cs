﻿using System;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;

namespace TheArtOfDev.HtmlRenderer.Adapters
{
	// Token: 0x020000C9 RID: 201
	public abstract class RPen
	{
		// Token: 0x1700019A RID: 410
		// (get) Token: 0x06000B20 RID: 2848
		// (set) Token: 0x06000B21 RID: 2849
		public abstract double Width { get; set; }

		// Token: 0x1700019B RID: 411
		// (set) Token: 0x06000B22 RID: 2850
		public abstract RDashStyle DashStyle { set; }
	}
}
