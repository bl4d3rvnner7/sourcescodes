﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using TheArtOfDev.HtmlRenderer.Adapters.Entities;
using TheArtOfDev.HtmlRenderer.Core;
using TheArtOfDev.HtmlRenderer.Core.Handlers;
using TheArtOfDev.HtmlRenderer.Core.Utils;

namespace TheArtOfDev.HtmlRenderer.Adapters
{
	// Token: 0x020000BF RID: 191
	public abstract class RAdapter
	{
		// Token: 0x06000ABB RID: 2747 RVA: 0x000108B8 File Offset: 0x0000EAB8
		protected RAdapter()
		{
			this._fontsHandler = new FontsHandler(this);
		}

		// Token: 0x1700018D RID: 397
		// (get) Token: 0x06000ABC RID: 2748 RVA: 0x0004FC80 File Offset: 0x0004DE80
		public CssData DefaultCssData
		{
			get
			{
				CssData cssData;
				if ((cssData = this._defaultCssData) == null)
				{
					cssData = (this._defaultCssData = CssData.Parse(this, <Module>.smethod_24<string>(2376826029U), false));
				}
				return cssData;
			}
		}

		// Token: 0x06000ABD RID: 2749 RVA: 0x000108E2 File Offset: 0x0000EAE2
		public RColor GetColor(string colorName)
		{
			ArgChecker.AssertArgNotNullOrEmpty(colorName, <Module>.smethod_26<string>(1953859055U));
			return this.GetColorInt(colorName);
		}

		// Token: 0x06000ABE RID: 2750 RVA: 0x0004FCB4 File Offset: 0x0004DEB4
		public RPen GetPen(RColor color)
		{
			RPen rpen;
			if (!this._penCache.TryGetValue(color, out rpen))
			{
				rpen = (this._penCache[color] = this.CreatePen(color));
			}
			return rpen;
		}

		// Token: 0x06000ABF RID: 2751 RVA: 0x0004FCE8 File Offset: 0x0004DEE8
		public RBrush GetSolidBrush(RColor color)
		{
			RBrush rbrush;
			if (!this._brushesCache.TryGetValue(color, out rbrush))
			{
				rbrush = (this._brushesCache[color] = this.CreateSolidBrush(color));
			}
			return rbrush;
		}

		// Token: 0x06000AC0 RID: 2752 RVA: 0x000108FB File Offset: 0x0000EAFB
		public RBrush GetLinearGradientBrush(RRect rect, RColor color1, RColor color2, double angle)
		{
			return this.CreateLinearGradientBrush(rect, color1, color2, angle);
		}

		// Token: 0x06000AC1 RID: 2753 RVA: 0x00010908 File Offset: 0x0000EB08
		public RImage ConvertImage(object image)
		{
			return this.ConvertImageInt(image);
		}

		// Token: 0x06000AC2 RID: 2754 RVA: 0x00010911 File Offset: 0x0000EB11
		public RImage ImageFromStream(Stream memoryStream)
		{
			return this.ImageFromStreamInt(memoryStream);
		}

		// Token: 0x06000AC3 RID: 2755 RVA: 0x0001091A File Offset: 0x0000EB1A
		public bool IsFontExists(string font)
		{
			return this._fontsHandler.IsFontExists(font);
		}

		// Token: 0x06000AC4 RID: 2756 RVA: 0x00010928 File Offset: 0x0000EB28
		public void AddFontFamily(RFontFamily fontFamily)
		{
			this._fontsHandler.AddFontFamily(fontFamily);
		}

		// Token: 0x06000AC5 RID: 2757 RVA: 0x00010936 File Offset: 0x0000EB36
		public void AddFontFamilyMapping(string fromFamily, string toFamily)
		{
			this._fontsHandler.AddFontFamilyMapping(fromFamily, toFamily);
		}

		// Token: 0x06000AC6 RID: 2758 RVA: 0x00010945 File Offset: 0x0000EB45
		public RFont GetFont(string family, double size, RFontStyle style)
		{
			return this._fontsHandler.GetCachedFont(family, size, style);
		}

		// Token: 0x06000AC7 RID: 2759 RVA: 0x0004FD1C File Offset: 0x0004DF1C
		public RImage GetLoadingImage()
		{
			if (this._loadImage == null)
			{
				Stream stream = RAdapter.smethod_2(RAdapter.smethod_1(RAdapter.smethod_0(typeof(HtmlRendererUtils).TypeHandle)), <Module>.smethod_26<string>(3391899083U));
				if (stream != null)
				{
					this._loadImage = this.ImageFromStream(stream);
				}
			}
			return this._loadImage;
		}

		// Token: 0x06000AC8 RID: 2760 RVA: 0x0004FD68 File Offset: 0x0004DF68
		public RImage GetLoadingFailedImage()
		{
			if (this._errorImage == null)
			{
				Stream stream = RAdapter.smethod_2(RAdapter.smethod_1(RAdapter.smethod_0(typeof(HtmlRendererUtils).TypeHandle)), <Module>.smethod_23<string>(189931267U));
				if (stream != null)
				{
					this._errorImage = this.ImageFromStream(stream);
				}
			}
			return this._errorImage;
		}

		// Token: 0x06000AC9 RID: 2761 RVA: 0x00010955 File Offset: 0x0000EB55
		public object GetClipboardDataObject(string html, string plainText)
		{
			return this.GetClipboardDataObjectInt(html, plainText);
		}

		// Token: 0x06000ACA RID: 2762 RVA: 0x0001095F File Offset: 0x0000EB5F
		public void SetToClipboard(string text)
		{
			this.SetToClipboardInt(text);
		}

		// Token: 0x06000ACB RID: 2763 RVA: 0x00010968 File Offset: 0x0000EB68
		public void SetToClipboard(string html, string plainText)
		{
			this.SetToClipboardInt(html, plainText);
		}

		// Token: 0x06000ACC RID: 2764 RVA: 0x00010972 File Offset: 0x0000EB72
		public void SetToClipboard(RImage image)
		{
			this.SetToClipboardInt(image);
		}

		// Token: 0x06000ACD RID: 2765 RVA: 0x0001097B File Offset: 0x0000EB7B
		public RContextMenu GetContextMenu()
		{
			return this.CreateContextMenuInt();
		}

		// Token: 0x06000ACE RID: 2766 RVA: 0x00010983 File Offset: 0x0000EB83
		public void SaveToFile(RImage image, string name, string extension, RControl control = null)
		{
			this.SaveToFileInt(image, name, extension, control);
		}

		// Token: 0x06000ACF RID: 2767 RVA: 0x00010990 File Offset: 0x0000EB90
		internal RFont CreateFont(string family, double size, RFontStyle style)
		{
			return this.CreateFontInt(family, size, style);
		}

		// Token: 0x06000AD0 RID: 2768 RVA: 0x0001099B File Offset: 0x0000EB9B
		internal RFont CreateFont(RFontFamily family, double size, RFontStyle style)
		{
			return this.CreateFontInt(family, size, style);
		}

		// Token: 0x06000AD1 RID: 2769
		protected abstract RColor GetColorInt(string colorName);

		// Token: 0x06000AD2 RID: 2770
		protected abstract RPen CreatePen(RColor color);

		// Token: 0x06000AD3 RID: 2771
		protected abstract RBrush CreateSolidBrush(RColor color);

		// Token: 0x06000AD4 RID: 2772
		protected abstract RBrush CreateLinearGradientBrush(RRect rect, RColor color1, RColor color2, double angle);

		// Token: 0x06000AD5 RID: 2773
		protected abstract RImage ConvertImageInt(object image);

		// Token: 0x06000AD6 RID: 2774
		protected abstract RImage ImageFromStreamInt(Stream memoryStream);

		// Token: 0x06000AD7 RID: 2775
		protected abstract RFont CreateFontInt(string family, double size, RFontStyle style);

		// Token: 0x06000AD8 RID: 2776
		protected abstract RFont CreateFontInt(RFontFamily family, double size, RFontStyle style);

		// Token: 0x06000AD9 RID: 2777 RVA: 0x000109A6 File Offset: 0x0000EBA6
		protected virtual object GetClipboardDataObjectInt(string html, string plainText)
		{
			throw RAdapter.smethod_3();
		}

		// Token: 0x06000ADA RID: 2778 RVA: 0x000109A6 File Offset: 0x0000EBA6
		protected virtual void SetToClipboardInt(string text)
		{
			throw RAdapter.smethod_3();
		}

		// Token: 0x06000ADB RID: 2779 RVA: 0x000109A6 File Offset: 0x0000EBA6
		protected virtual void SetToClipboardInt(string html, string plainText)
		{
			throw RAdapter.smethod_3();
		}

		// Token: 0x06000ADC RID: 2780 RVA: 0x000109A6 File Offset: 0x0000EBA6
		protected virtual void SetToClipboardInt(RImage image)
		{
			throw RAdapter.smethod_3();
		}

		// Token: 0x06000ADD RID: 2781 RVA: 0x000109A6 File Offset: 0x0000EBA6
		protected virtual RContextMenu CreateContextMenuInt()
		{
			throw RAdapter.smethod_3();
		}

		// Token: 0x06000ADE RID: 2782 RVA: 0x000109A6 File Offset: 0x0000EBA6
		protected virtual void SaveToFileInt(RImage image, string name, string extension, RControl control = null)
		{
			throw RAdapter.smethod_3();
		}

		// Token: 0x06000ADF RID: 2783 RVA: 0x0000C8E1 File Offset: 0x0000AAE1
		static Type smethod_0(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06000AE0 RID: 2784 RVA: 0x0000DD49 File Offset: 0x0000BF49
		static Assembly smethod_1(Type type_0)
		{
			return type_0.Assembly;
		}

		// Token: 0x06000AE1 RID: 2785 RVA: 0x000109AD File Offset: 0x0000EBAD
		static Stream smethod_2(Assembly assembly_0, string string_0)
		{
			return assembly_0.GetManifestResourceStream(string_0);
		}

		// Token: 0x06000AE2 RID: 2786 RVA: 0x000109B6 File Offset: 0x0000EBB6
		static NotImplementedException smethod_3()
		{
			return new NotImplementedException();
		}

		// Token: 0x040003FA RID: 1018
		private readonly Dictionary<RColor, RBrush> _brushesCache = new Dictionary<RColor, RBrush>();

		// Token: 0x040003FB RID: 1019
		private readonly Dictionary<RColor, RPen> _penCache = new Dictionary<RColor, RPen>();

		// Token: 0x040003FC RID: 1020
		private readonly FontsHandler _fontsHandler;

		// Token: 0x040003FD RID: 1021
		private CssData _defaultCssData;

		// Token: 0x040003FE RID: 1022
		private RImage _loadImage;

		// Token: 0x040003FF RID: 1023
		private RImage _errorImage;
	}
}
