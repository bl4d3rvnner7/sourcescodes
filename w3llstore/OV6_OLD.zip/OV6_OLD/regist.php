<?php

require_once "gogo/conf.php";

?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>W3LL OV6 REGISTER CODE
    </title>
    <style>body{
      background:#000 fixed;
      background-position:95% 95%;
      background-repeat:no-repeat}
    </style>
  </head>
  <body>
    <html>
      <head>
        <meta content="text/html; charset=ISO-8859-1"http-equiv="content-type">
        <meta content="width=device-width,initial-scale=1"name="viewport">
        <link href="https://w3ll.shop/images/logonew.png"rel="icon"type="image/x-icon">
      </head>
      <body bgcolor="#FFFFFF"onload="writetext(),pageScroll()">
        <div id="nothing"style="font-family:Courier">
          <h2>
            <font color="#00ff00"face="Courier"new=""size="4">
            </font>
          </h2>
          <font color="#00ff00"face="Courier"new=""size="3">
            <center>
            </center>
            <br>
            <br>
          </font>
          <font color="#00ff00"face="Courier"new=""size="3">
            <center>
            </center>
            </div>
          </body>
        <style>.btn,.btn10,.btn2,.btn3,.btn4,.btn5,.btn6,.btn7{
          padding:15px 100px;
          margin:10px 4px;
          color:#fff;
          font-family:sans-serif;
          text-transform:uppercase;
          text-align:center;
          position:relative;
          text-decoration:none;
          display:inline-block}
          .btn::before{
            content:'';
            position:absolute;
            bottom:50%;
            left:0;
            width:100%;
            height:1px;
            background:#6098ff;
            display:block;
            -webkit-transform-origin:left top;
            -ms-transform-origin:left top;
            transform-origin:left top;
            -webkit-transform:scale(0,1);
            -ms-transform:scale(0,1);
            transform:scale(0,1);
            -webkit-transition:transform .4s cubic-bezier(1,0,0,1);
            transition:transform .4s cubic-bezier(1,0,0,1)}
          .btn:hover::before{
            -webkit-transform-origin:right top;
            -ms-transform-origin:right top;
            transform-origin:right top;
            -webkit-transform:scale(1,1);
            -ms-transform:scale(1,1);
            transform:scale(1,1)}
          .bar-anchor{
            padding:20px 10px;
            margin:10px 4px;
            color:#fff;
            font-family:sans-serif;
            text-transform:uppercase;
            text-align:center;
            position:relative;
            text-decoration:none;
            display:inline-block;
            overflow:hidden}
          .bar-anchor span{
            width:100%;
            position:relative;
            padding:10px 70px;
            -moz-transition:all .65s cubic-bezier(.77,0,.175,1);
            -o-transition:all .65s cubic-bezier(.77,0,.175,1);
            -webkit-transition:all .65s cubic-bezier(.77,0,.175,1);
            transition:all .65s cubic-bezier(.77,0,.175,1)}
          .transition-bar{
            position:absolute;
            top:0;
            left:0;
            width:0;
            height:100%;
            background:#80ffd3;
            z-index:-1}
          .bar-anchor:hover span{
            color:#80ffd3!important}
          .bar-anchor:hover .transition-bar{
            width:120%;
            left:110%;
            -moz-transition:all .65s cubic-bezier(.77,0,.175,1);
            -o-transition:all .65s cubic-bezier(.77,0,.175,1);
            -webkit-transition:all .65s cubic-bezier(.77,0,.175,1);
            transition:all .65s cubic-bezier(.77,0,.175,1)}
          h1{
            font-weight:700;
            color:#ff3c41;
            font-size:32px;
            font-family:Courier}
        </style>
        </html>
      <script>function pageScroll(){
          window.scrollBy(0,5e3),scrolldelay=setTimeout("pageScroll()",200)}
        function writetext(){
          text1=text2+"<font color='#FFFFFF'>"+text[count]+"</font>",text2+=text[count],document.all.nothing.innerHTML=text1,count<text.length-1?(count++,setTimeout("writetext()",1)):(count=0,10!=count2&&(count2++,text2+="",text=eval("msg["+count2+'].split("")'),setTimeout("writetext()",1)))}
        msg=new Array,msg[0]="<br><br><br><br><br><br><br><br><br><br><br><br><center><h2><font face='Courier' color='#00FF00' new size='4'><center>⚡<?php $dom = base64_encode($domen[0]); $dom = str_replace('=', '', $dom); echo $dom; ?>⚡</center></font></h2><font face='Courier' color='#FF3C41' new size='3'>Register code above on store!</font></center>",text1="",text2="",count=0,count2=0,text=msg[0].split("")
        </script>
    </body>
</html>