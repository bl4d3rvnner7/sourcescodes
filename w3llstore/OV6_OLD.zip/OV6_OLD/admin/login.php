<?php

error_reporting(E_ALL);
session_start();
require "../gogo/conf.php";
if (isset($_SESSION["login"])) {
    header("Location: index.php");
    die;
}
function clear($param)
{
    if (!preg_match("/^[A-Za-z0-9]+\$/", $param)) {
        header("HTTP/1.1 500 Internal Server Error");
        die;
    }
    return $param;
}
if (isset($_POST["submit"])) {
    $_SESSION["login"] = "motherfucker";
    header("Location: index.php");
    die;
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Login Panel
    </title>
    <meta charset="utf-8">
    <meta content="width=device-width,initial-scale=1"name="viewport">
    <link href="style.css"rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js">
    </script>
    <style type="text/css">.row{
      height:100vh}
    </style>
  </head>
  <body>
    <?php 
if (isset($_GET["invalid"])) {
echo "<div class=\"alert alert-danger\" role=\"alert\">\n                    <i class=\"mdi mdi-alert-circle\"></i>\n                    YOUR TOKEN IS NOT VALID!.\n                  </div>";
}
?>
    <div class="container-fluid">
      <div class="align-items-center d-flex row">
        <div class="col-lg-4 col-md-4 col-xs-12 mx-auto">
          <div class="card">
            <div class="card-header text-center">Login to Panel
            </div>
            <div class="card-body">
              <form method="post">
                <div class="form-group">
                  <input autocomplete="off"class="form-control"id="key"name="key"placeholder="Private Key"required spellcheck="false"type="password">
                </div>
                <button class="btn btn-block btn-secondary"name="submit"type="submit">Submit
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

