<?php

error_reporting(E_ALL);
session_start();
if (!isset($_SESSION["login"])) {
    header("Location: login.php");
    die;
}
unset($_SESSION["login"]);
session_destroy();
header("Location: login.php");
