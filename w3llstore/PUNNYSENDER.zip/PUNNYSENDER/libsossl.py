from __future__ import print_function
from mailers import Mailer
from config import Config
from concurrent.futures import ThreadPoolExecutor
import requests
import random
import sys
import time
import socket
import readchar
import fileinput
import os
from requests.structures import CaseInsensitiveDict
from multi import *
from multiprocessing import freeze_support
from colorama import Fore
from logo import logo, clearConsole


def main():
    config = Config()
    
    #token = Check_token(config.config['sender']['token'])
    token = {
        "username": "scarlettaowner",
        "expire": 9999,
        "news": "W3LL Punnysender reversed by @scarlettaowner (TG)",
        "reason": "Working",
        "status": True
    }
    
    if token['status']:
        print(Fore.GREEN + 'Username: ' + Fore.WHITE + token['username'])
        print(Fore.GREEN + 'Duration: ' + Fore.WHITE + str(token['expire']) + ' day left')
        print()
        print('[' + Fore.GREEN + 'NEWS' + Fore.WHITE + ']')
        print(token['news'])
        print()
    else:
        print(Fore.WHITE + '[' + Fore.RED + '!' + Fore.WHITE + '] ' + token['reason'] + '')
        print()
        print(Fore.WHITE + '[' + Fore.RED + '!' + Fore.WHITE + '] Press any key to exit!')
        k = readchar.readchar()
        sys.exit(0)
    
    if config.config['sender']['smtp_list_format'] == 'file':
        smtps = config.get_smtp_file()
    else:
        smtps = config.get_smtp()
    
    smtp_count = 0
    connect_count = 0
    mail = []
    connect = []
    delete_count = []
    
    print('Preparing your SMTPs. Get ' + Fore.GREEN + str(len(smtps)) + Fore.WHITE + ' of SMTP on your Config..')
    print()
    
    if config.get('smtp_timeout') == 'default':
        timeout = socket._GLOBAL_DEFAULT_TIMEOUT
    else:
        timeout = int(config.get('smtp_timeout'))
    
    for smtp in smtps:
        try:
            if len(smtp) == 4:
                if not smtp[1].isdigit():
                    print('[' + Fore.YELLOW + '!' + Fore.WHITE + '] ' + smtp[0] + ' | ' + smtp[2] + ' [' + Fore.RED + 'BADP' + Fore.WHITE + ']')
                    continue
                
                if smtp[1] == '465':
                    mail.append(Mailer(
                        host=smtp[0],
                        port=int(smtp[1]),
                        use_tls=True,
                        usr=smtp[2],
                        pwd=smtp[3],
                        use_ssl=True,
                        timeout=timeout
                    ))
                else:
                    mail.append(Mailer(
                        host=smtp[0],
                        port=int(smtp[1]),
                        use_tls=True,
                        usr=smtp[2],
                        pwd=smtp[3],
                        use_ssl=False,
                        timeout=timeout
                    ))
                
                connect.append(mail[connect_count].connect(config.get('debug_smtp')))
                
                if connect[connect_count] == 'OK':
                    print('[' + Fore.GREEN + '+' + Fore.WHITE + '] ' + smtp[0] + ' | ' + smtp[2])
                    connect_count += 1
                else:
                    errmsg = error_code(connect[connect_count])
                    print('[' + Fore.RED + '-' + Fore.WHITE + '] ' + smtp[0] + ' | ' + smtp[2] + ' [' + Fore.RED + errmsg + Fore.WHITE + ']')
                    del mail[-1]
                    del connect[-1]
                    delete_count.append(smtp_count)
                    
                    if config.config['sender']['smtp_list_format'] == 'file':
                        bad_words = [
                            smtp[0] + '|' + smtp[1] + '|' + smtp[2] + '|' + smtp[3],
                            smtp[0] + ':' + smtp[1] + ' ' + smtp[2] + ' ' + smtp[3],
                            smtp[0] + ',' + smtp[1] + ',' + smtp[2] + ',' + smtp[3]
                        ]
                        for stat in bad_words:
                            for line in fileinput.input(config.config['settings']['smtp_list'], inplace=True):
                                if stat in line:
                                    continue
                                print(line, end='')
                    else:
                        delete = dict(config.config.items('smtp'))
                        for i in delete:
                            smtp_str = config.config['smtp'][str(i)]
                            if (smtp_str == smtp[0] + '|' + smtp[1] + '|' + smtp[2] + '|' + smtp[3] or
                                smtp_str == smtp[0] + ':' + smtp[1] + ' ' + smtp[2] + ' ' + smtp[3] or
                                smtp_str == smtp[0] + ',' + smtp[1] + ',' + smtp[2] + ',' + smtp[3]):
                                config.config.remove_option('smtp', str(i))
                                with open('config.ini', 'w') as f:
                                    config.config.write(f)
                                break
                smtp_count += 1
            else:
                print('[' + Fore.RED + '-' + Fore.WHITE + '] ' + smtp[0] + ' | ' + smtp[2] + ' [' + Fore.RED + 'BADF' + Fore.WHITE + ']')
        except (IndexError, ValueError):
            print('[' + Fore.YELLOW + '!' + Fore.WHITE + '] ' + smtp[0] + ' | ' + smtp[2] + ' [' + Fore.RED + 'BADF' + Fore.WHITE + ']')
            continue
    
    print()
    print('Total SMTPs active count: ' + Fore.GREEN + str(connect_count) + Fore.WHITE + ' [Default thread: ' + str(connect_count) + ']')
    print()
    
    if connect_count > 0:
        notice('Starting Sender')
    else:
        notice('Quitting Sender')
        print()
        print(Fore.WHITE + '[' + Fore.RED + '!' + Fore.WHITE + '] Press any key to #exit!')
        k = readchar.readchar()
        sys.exit(0)
    
    clearConsole()
    smtp_count = 0
    fromnames = config.get_fromname()
    frommails = config.get_frommail()
    redirect_count = 0
    lines = 1
    test_email = 0
    saved_count = 0
    total_lines = len(config.get_email())
    code = ''
    
    if config.config['session']['email'] != '0' and int(config.config['session']['email']) < total_lines:
        print('[' + Fore.YELLOW + '+' + Fore.WHITE + '] We Found A Session! Last sended email is on line ' + config.config['session']['email'])
        con = input('[' + Fore.YELLOW + '+' + Fore.WHITE + '] Do you want to continue session ? [y/n] ')
        if con == 'Y' or con == 'y':
            saved_count = int(config.config['session']['email'])
        else:
            config.config.set('session', 'email', '0')
            with open('config.ini', 'w') as f:
                config.config.write(f)
    
    if config.get('thread') == 'default' or config.get('thread') == 'DEFAULT' or int(config.get('thread')) < connect_count:
        thread = connect_count
    else:
        thread = int(config.get('thread'))
    clearConsole()
    logo()

    with ThreadPoolExecutor(max_workers=thread) as executor:
        a = 0
        for email in config.get_email():
            if saved_count != 0 and lines <= saved_count:
                lines += 1
                continue
            
            if config.get('redirect') == '9' and redirect_count == 0:
                url = f'https://w3ll.store/api/generate_redirect?username={config.get("username")}&password={config.get("password")}&id={config.get("ids")}'
                headers = CaseInsensitiveDict()
                headers['Content-Type'] = 'application/json'
                resp = requests.get(url, headers=headers)
                
                if resp.content.decode('utf-8') == '':
                    print(Fore.WHITE + '[' + Fore.RED + '!' + Fore.WHITE + '] Invalid redirect type 9 Settings!')
                    print()
                    print(Fore.WHITE + '[' + Fore.RED + '!' + Fore.WHITE + '] Press any key to exit!')
                    k = readchar.readchar()
                    sys.exit(0)
                
                resp = resp.json()
                code = resp['code']
            
            if smtp_count == len(mail):
                smtp_count = 0
            
            if a == thread:
                a = 0
                time.sleep(int(config.get('sleeptime')))
            
            fromname = random.choice(fromnames)
            frommail = random.choice(frommails)
            
            try:
                if config.get('email_test') == '1' and test_email == int(config.get('test_every')):
                    test_email = 0
                    executor.submit(
                        send, mail, smtp_count, code, lines, total_lines, config,
                        smtps[smtp_count][0], smtps[smtp_count][2], smtps[smtp_count][3], smtps[smtp_count][1],
                        config.get('email_destination'), fromname, frommail
                    )
                
                executor.submit(
                    send, mail, smtp_count, code, lines, total_lines, config,
                    smtps[smtp_count][0], smtps[smtp_count][2], smtps[smtp_count][3], smtps[smtp_count][1],
                    email, fromname, frommail
                )
            except IndexError:
                pass
            
            smtp_count += 1
            lines += 1
            a += 1
            test_email += 1
            redirect_count += 1
            
            if redirect_count == 100:
                redirect_count = 0


if __name__ == '__main__':
    clearConsole()
    freeze_support()
    try:
        main()
        print()
        print(Fore.WHITE + '[' + Fore.RED + '!' + Fore.WHITE + '] Press any key to exit!')
        k = readchar.readchar()
        sys.exit(0)
    except KeyboardInterrupt:
        print(Fore.WHITE + '[' + Fore.RED + '!' + Fore.WHITE + '] Closing sender...')
        sys.stdout.flush()
        print()
        print(Fore.WHITE + '[' + Fore.RED + '!' + Fore.WHITE + '] Press any key to exit!')
        k = readchar.readchar()
        time.sleep(2)
        sys.exit(0)