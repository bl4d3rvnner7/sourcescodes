import configparser
import os
import time
import sys
import random
from colorama import Fore


class Config:
    def __init__(self, config_file='config.ini'):
        try:
            self.config = configparser.ConfigParser()
            self.config.read(config_file)
        except configparser.DuplicateOptionError:
            print('[' + Fore.WHITE + '[' + Fore.RED + '!' + Fore.WHITE + '] Duplicated smtp number in config.ini')
            try:
                sys.exit(0)
            except SystemExit:
                os._exit(0)
        
        substring = ','
        content_list = []
        
        if substring in self.config['settings']['letter']:
            content_list = self.config['settings']['letter'].split(substring)
            lette = random.choice(content_list)
        else:
            lette = self.config['settings']['letter']
        
        if os.path.isfile(self.config['settings']['maillist']) is False:
            def mailist():
                logo = f"""
┌────────────────────────────────────────────────────────────────────┐
│                                                                   │
│                          ▒█▀▀█ ▒█░▒█ ▒█▄░▒█ ▒█▄░▒█ ▒█░░▒█           │
│                    {Fore.GREEN}▒█▄▄█ ▒█░▒█ ▒█▒█▒█ ▒█▒█▒█ ▒█▄▄▄█{Fore.WHITE}                      │
│                          ▒█░░░ ░▀▄▄▀ ▒█░░▀█ ▒█░░▀█ ░░▒█               │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│                                                                   │
│                            {Fore.YELLOW}HOW TO USE PUNNY SENDER{Fore.WHITE}                           │
│                                                                   │
│                   {Fore.GREEN}files/attachment{Fore.WHITE} : FOR ATTACHMENT FILE                   │
│                   {Fore.GREEN}files/mail_list{Fore.WHITE}  : FOR EMAIL LEADS                       │
│                   {Fore.GREEN}files/letter{Fore.WHITE}     : FOR LETTER                           │
│                   {Fore.GREEN}files/image{Fore.WHITE}     : FOR LOCAL IMAGE LOGO                 │
│                   {Fore.GREEN}config.ini{Fore.WHITE}       : FOR SET ALL CONFIGURATION           │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│                                                                   │
│                         {Fore.YELLOW}CONTACT SUPPORT PUNNY SENDER{Fore.WHITE}                           │
│                                                                   │
│                           {Fore.GREEN}TELEGRAM{Fore.WHITE} : t.me/W3LLSTORE                          │
│                           {Fore.GREEN}WEBSITE{Fore.WHITE}  : W3LL.SHOP                               │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│             {Fore.RED}MAILIST IS NOT FOUND, PLEASE CHECK YOUR MAILIST NAME!{Fore.WHITE}            │
└────────────────────────────────────────────────────────────────────┘"""
                for line in logo.split('\n'):
                    print(line)
                    time.sleep(0.15)
            mailist()
            self.exit()
        
        if os.path.isfile(lette) is False:
            def letter():
                logo = f"""
┌────────────────────────────────────────────────────────────────────┐
│                                                                   │
│                          ▒█▀▀█ ▒█░▒█ ▒█▄░▒█ ▒█▄░▒█ ▒█░░▒█           │
│                    {Fore.GREEN}▒█▄▄█ ▒█░▒█ ▒█▒█▒█ ▒█▒█▒█ ▒█▄▄▄█{Fore.WHITE}                      │
│                          ▒█░░░ ░▀▄▄▀ ▒█░░▀█ ▒█░░▀█ ░░▒█               │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│                                                                   │
│                            {Fore.YELLOW}HOW TO USE PUNNY SENDER{Fore.WHITE}                           │
│                                                                   │
│                   {Fore.GREEN}files/attachment{Fore.WHITE} : FOR ATTACHMENT FILE                   │
│                   {Fore.GREEN}files/mail_list{Fore.WHITE}  : FOR EMAIL LEADS                       │
│                   {Fore.GREEN}files/letter{Fore.WHITE}     : FOR LETTER                           │
│                   {Fore.GREEN}files/image{Fore.WHITE}     : FOR LOCAL IMAGE LOGO                 │
│                   {Fore.GREEN}config.ini{Fore.WHITE}       : FOR SET ALL CONFIGURATION           │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│                                                                   │
│                         {Fore.YELLOW}CONTACT SUPPORT PUNNY SENDER{Fore.WHITE}                           │
│                                                                   │
│                           {Fore.GREEN}TELEGRAM{Fore.WHITE} : t.me/W3LLSTORE                          │
│                           {Fore.GREEN}WEBSITE{Fore.WHITE}  : W3LL.SHOP                               │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│              {Fore.RED}LETTER IS NOT FOUND, PLEASE CHECK YOUR LETTER NAME!{Fore.WHITE}             │
└────────────────────────────────────────────────────────────────────┘"""
                for line in logo.split('\n'):
                    print(line)
                    time.sleep(0.15)
            letter()
            self.exit()
        
        if self.config['users']['subject'] == '':
            def subject():
                logo = f"""
┌────────────────────────────────────────────────────────────────────┐
│                                                                   │
│                          ▒█▀▀█ ▒█░▒█ ▒█▄░▒█ ▒█▄░▒█ ▒█░░▒█           │
│                    {Fore.GREEN}▒█▄▄█ ▒█░▒█ ▒█▒█▒█ ▒█▒█▒█ ▒█▄▄▄█{Fore.WHITE}                      │
│                          ▒█░░░ ░▀▄▄▀ ▒█░░▀█ ▒█░░▀█ ░░▒█               │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│                                                                   │
│                            {Fore.YELLOW}HOW TO USE PUNNY SENDER{Fore.WHITE}                           │
│                                                                   │
│                   {Fore.GREEN}files/attachment{Fore.WHITE} : FOR ATTACHMENT FILE                   │
│                   {Fore.GREEN}files/mail_list{Fore.WHITE}  : FOR EMAIL LEADS                       │
│                   {Fore.GREEN}files/letter{Fore.WHITE}     : FOR LETTER                           │
│                   {Fore.GREEN}files/image{Fore.WHITE}     : FOR LOCAL IMAGE LOGO                 │
│                   {Fore.GREEN}config.ini{Fore.WHITE}       : FOR SET ALL CONFIGURATION           │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│                                                                   │
│                         {Fore.YELLOW}CONTACT SUPPORT PUNNY SENDER{Fore.WHITE}                           │
│                                                                   │
│                           {Fore.GREEN}TELEGRAM{Fore.WHITE} : t.me/W3LLSTORE                          │
│                           {Fore.GREEN}WEBSITE{Fore.WHITE}  : W3LL.SHOP                               │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│             {Fore.RED}SUBJECT CAN NOT BE EMPTY, PLEASE CHECK YOUR SUBJECT!{Fore.WHITE}             │
└────────────────────────────────────────────────────────────────────┘"""
                for line in logo.split('\n'):
                    print(line)
                    time.sleep(0.15)
            subject()
            self.exit()
        
        if os.path.isfile(self.config['settings']['attachment']) is False:
            def attachment():
                logo = f"""
┌────────────────────────────────────────────────────────────────────┐
│                                                                   │
│                          ▒█▀▀█ ▒█░▒█ ▒█▄░▒█ ▒█▄░▒█ ▒█░░▒█           │
│                    {Fore.GREEN}▒█▄▄█ ▒█░▒█ ▒█▒█▒█ ▒█▒█▒█ ▒█▄▄▄█{Fore.WHITE}                      │
│                          ▒█░░░ ░▀▄▄▀ ▒█░░▀█ ▒█░░▀█ ░░▒█               │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│                                                                   │
│                            {Fore.YELLOW}HOW TO USE PUNNY SENDER{Fore.WHITE}                           │
│                                                                   │
│                   {Fore.GREEN}files/attachment{Fore.WHITE} : FOR ATTACHMENT FILE                   │
│                   {Fore.GREEN}files/mail_list{Fore.WHITE}  : FOR EMAIL LEADS                       │
│                   {Fore.GREEN}files/letter{Fore.WHITE}     : FOR LETTER                           │
│                   {Fore.GREEN}files/image{Fore.WHITE}     : FOR LOCAL IMAGE LOGO                 │
│                   {Fore.GREEN}config.ini{Fore.WHITE}       : FOR SET ALL CONFIGURATION           │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│                                                                   │
│                         {Fore.YELLOW}CONTACT SUPPORT PUNNY SENDER{Fore.WHITE}                           │
│                                                                   │
│                           {Fore.GREEN}TELEGRAM{Fore.WHITE} : t.me/W3LLSTORE                          │
│                           {Fore.GREEN}WEBSITE{Fore.WHITE}  : W3LL.SHOP                               │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│          {Fore.RED}ATTACHMENT IS NOT FOUND PLEASE CHECK YOUR ATTACHMENT NAME!{Fore.WHITE}          │
└────────────────────────────────────────────────────────────────────┘"""
                for line in logo.split('\n'):
                    print(line)
                    time.sleep(0.15)
            attachment()
            self.exit()
        
        if os.path.isfile(self.config['settings']['smtp_list']) is False:
            def attachment():
                logo = f"""
┌────────────────────────────────────────────────────────────────────┐
│                                                                   │
│                          ▒█▀▀█ ▒█░▒█ ▒█▄░▒█ ▒█▄░▒█ ▒█░░▒█           │
│                    {Fore.GREEN}▒█▄▄█ ▒█░▒█ ▒█▒█▒█ ▒█▒█▒█ ▒█▄▄▄█{Fore.WHITE}                      │
│                          ▒█░░░ ░▀▄▄▀ ▒█░░▀█ ▒█░░▀█ ░░▒█               │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│                                                                   │
│                            {Fore.YELLOW}HOW TO USE PUNNY SENDER{Fore.WHITE}                           │
│                                                                   │
│                   {Fore.GREEN}files/attachment{Fore.WHITE} : FOR ATTACHMENT FILE                   │
│                   {Fore.GREEN}files/mail_list{Fore.WHITE}  : FOR EMAIL LEADS                       │
│                   {Fore.GREEN}files/letter{Fore.WHITE}     : FOR LETTER                           │
│                   {Fore.GREEN}files/image{Fore.WHITE}     : FOR LOCAL IMAGE LOGO                 │
│                   {Fore.GREEN}config.ini{Fore.WHITE}       : FOR SET ALL CONFIGURATION           │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│                                                                   │
│                         {Fore.YELLOW}CONTACT SUPPORT PUNNY SENDER{Fore.WHITE}                           │
│                                                                   │
│                           {Fore.GREEN}TELEGRAM{Fore.WHITE} : t.me/W3LLSTORE                          │
│                           {Fore.GREEN}WEBSITE{Fore.WHITE}  : W3LL.SHOP                               │
│                                                                   │
├────────────────────────────────────────────────────────────────────┤
│           {Fore.RED}SMTPS IS NOT FOUND PLEASE CHECK YOUR ATTACHMENT NAME!{Fore.WHITE}            │
└────────────────────────────────────────────────────────────────────┘"""
                for line in logo.split('\n'):
                    print(line)
                    time.sleep(0.15)
            attachment()
            self.exit()
    
    def exit(self):
        time.sleep(3)
        sys.exit()
    
    def get_custom_header(self):
        header = list(self.config.items('custom_headers'))
        headers = []
        for stats in header:
            commas = stats[1].split(',')
            headers.append(stats)
        return headers
    
    def get_smtp(self):
        smtp = list(self.config.items('smtp'))
        smtps = []
        for stats in smtp:
            if ',' in stats[1]:
                commas = stats[1].split(',')
                smtps.append(commas)
            elif '|' in stats[1]:
                commas = stats[1].split('|')
                smtps.append(commas)
            elif ':' in stats[1]:
                commas = stats[1].split(':')
                ex = commas[1].split(' ')
                del commas[1]
                for i in ex:
                    commas.append(ex[ex.index(i)])
                smtps.append(commas)
        return smtps
    
    def get_smtp_file(self):
        smtp_file = open(self.config['settings']['smtp_list'], 'r')
        content = smtp_file.read()
        if '\n' in content:
            smtp = content.split('\n')
        else:
            smtp = []
            smtp.append(content)
        smtp_file.close()
        
        smtps = []
        for stats in smtp:
            if ',' in stats:
                commas = stats.split(',')
                smtps.append(commas)
            elif '|' in stats:
                commas = stats.split('|')
                smtps.append(commas)
            elif ':' in stats:
                commas = stats.split(':')
                ex = commas[1].split(' ')
                del commas[1]
                for i in ex:
                    commas.append(ex[ex.index(i)])
                smtps.append(commas)
        return smtps
    
    def get_url(self):
        substring = ','
        content_list = []
        if substring in self.config['users']['scampage']:
            content_list = self.config['users']['scampage'].split(substring)
        else:
            content_list.append(self.config['users']['scampage'])
        return content_list
    
    def get_subject(self):
        substring = ',,'
        content_list = []
        if substring in self.config['users']['subject']:
            content_list = self.config['users']['subject'].split(substring)
        else:
            content_list.append(self.config['users']['subject'])
        return content_list
    
    def get_frommail(self):
        substring = ','
        content_list = []
        if substring in self.config['users']['frommail']:
            content_list = self.config['users']['frommail'].split(substring)
        else:
            content_list.append(self.config['users']['frommail'])
        return content_list
    
    def get_fromname(self):
        substring = ','
        content_list = []
        if substring in self.config['users']['fromname']:
            content_list = self.config['users']['fromname'].split(substring)
        else:
            content_list.append(self.config['users']['fromname'])
        return content_list
    
    def get_encoding(self):
        substring = ','
        content_list = []
        if substring in self.config['users']['encoding']:
            content_list = self.config['users']['encoding'].split(substring)
        else:
            content_list.append(self.config['users']['encoding'])
        return content_list
    
    def get(self, variables):
        return self.config['users'][variables]
    
    def get_settings(self, variables):
        return self.config['settings'][variables]
    
    def get_letter(self):
        substring = ','
        content_list = []
        if substring in self.config['settings']['letter']:
            content_list = self.config['settings']['letter'].split(substring)
            lette = random.choice(content_list)
            with open(lette) as f:
                lines = f.read()
        else:
            with open(self.config['settings']['letter']) as f:
                lines = f.read()
        return lines
    
    def get_attachment(self):
        if '.pdf' in self.config['settings']['attachment']:
            with open(self.config['settings']['attachment'], encoding='ISO8859-1') as f:
                lines = f.read()
        else:
            with open(self.config['settings']['attachment']) as f:
                lines = f.read()
        return lines
    
    def get_email(self):
        mail_file = open(self.config['settings']['maillist'], 'r')
        content = mail_file.read()
        content_list = content.split('\n')
        mail_file.close()
        return content_list