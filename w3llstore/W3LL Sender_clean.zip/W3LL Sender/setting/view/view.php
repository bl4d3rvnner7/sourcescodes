<?php
include "config.php";
date_default_timezone_set($W3LL_setup["timezone"]);
class W3ll_color
{
    public function Blue($str)
    {
        return "\033[0;34m" . $str . "\033[0m";
    }
    public function cyan($str)
    {
        return "\e[0;37m" . $str . "\033[0m";
    }
    public function bggreenblack($str)
    {
        return "\e[5;30;42m" . $str . "\033[0m";
    }
    public function purple($str)
    {
        return "\e[0;35m" . $str . "\033[0m";
    }
    public function white($str)
    {
        return "\033[0m" . $str . "\033[0m";
    }
    public function Bluee($str)
    {
        return "\033[36m" . $str . "\033[0m";
    }
    public function Red($str)
    {
        return "\033[0;31m" . $str . "\033[0m";
    }
    public function Redd($str)
    {
        return "\033[31m" . $str . "\033[0m";
    }
    public function Yellow($str)
    {
        return "\033[1;33m" . $str . "\033[0m";
    }
    public function Green($str)
    {
        return "\033[92m" . $str . "\033[0m";
    }
    public function Greenn($str)
    {
        return "\033[0;32m" . $str . "\033[0m";
    }
    public function Bold($str)
    {
        return "\033[1m" . $str . "\033[0m";
    }
    public function blockred($str)
    {
        return "\033[1;37;41m" . $str . "\033[0m";
    }
    public function lightgreen($str)
    {
        return "\033[1;32m" . $str . "\033[0m";
    }
    public function bggreen($str)
    {
        return "\e[42m" . $str . "\033[0m";
    }
}
class Banner extends W3ll_color
{
    protected $color;
    public function __construct()
    {
        $this->color = new W3ll_color();
    }
    public function warna_euy()
    {
        $arr = [
            "Blue",
            "Red",
            "Yellow",
            "Green",
            "Bold",
            "Bluee",
            "Redd",
            "Greenn",
            "purple",
            "cyan",
        ];
        $warna = $arr[array_rand($arr)];
        return $warna;
    }
    public function skuy()
{
    $warna = self::warna_euy();
    $logo1 = [];
    $logo1[1] = "";
    $logo1[2] = "";
    $logo1[3] = "";
    $logo1[4] = "";
    $logo1[5] = "";
    
    $logo1[1] .= $this->color->Red("      ┌────────────────────────────────────────────────────────────────────────────────────────────────┐" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │") . $this->color->White("                           ▄         ▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄            ▄                             ") . $this->color->Red("│" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │") . $this->color->White("                          ▐") . $this->color->Red("░") . $this->color->White("▌       ▐") . $this->color->Red("░") . $this->color->White("▌▐") . $this->color->Red("░░░░░░░░░░░") . $this->color->White("▌▐") . $this->color->Red("░") . $this->color->White("▌          ▐") . $this->color->Red("░") . $this->color->White("▌                            ") . $this->color->Red("│" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │") . $this->color->White("                          ▐") . $this->color->Red("░") . $this->color->White("▌       ▐") . $this->color->Red("░") . $this->color->White("▌ ▀▀▀▀▀▀▀▀▀█") . $this->color->Red("░") . $this->color->White("▌▐") . $this->color->Red("░") . $this->color->White("▌          ▐") . $this->color->Red("░") . $this->color->White("▌                            ") . $this->color->Red("│" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │") . $this->color->White("                          ▐") . $this->color->Red("░") . $this->color->White("▌       ▐") . $this->color->Red("░") . $this->color->White("▌          ▐") . $this->color->Red("░") . $this->color->White("▌▐") . $this->color->Red("░") . $this->color->White("▌          ▐") . $this->color->Red("░") . $this->color->White("▌                            ") . $this->color->Red("│" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │") . $this->color->White("                          ▐") . $this->color->Red("░") . $this->color->White("▌   ▄   ▐") . $this->color->Red("░") . $this->color->White("▌ ▄▄▄▄▄▄▄▄▄█") . $this->color->Red("░") . $this->color->White("▌▐") . $this->color->Red("░") . $this->color->White("▌          ▐") . $this->color->Red("░") . $this->color->White("▌                            ") . $this->color->Red("│" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │") . $this->color->White("                          ▐") . $this->color->Red("░") . $this->color->White("▌  ▐") . $this->color->Red("░") . $this->color->White("▌  ▐") . $this->color->Red("░") . $this->color->White("▌▐") . $this->color->Red("░░░░░░░░░░░") . $this->color->White("▌▐") . $this->color->Red("░") . $this->color->White("▌          ▐") . $this->color->Red("░") . $this->color->White("▌                            ") . $this->color->Red("│" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │") . $this->color->White("                          ▐") . $this->color->Red("░") . $this->color->White("▌ ▐") . $this->color->Red("░") . $this->color->White("▌") . $this->color->Red("░") . $this->color->White("▌ ▐") . $this->color->Red("░") . $this->color->White("▌ ▀▀▀▀▀▀▀▀▀█") . $this->color->Red("░") . $this->color->White("▌▐") . $this->color->Red("░") . $this->color->White("▌          ▐") . $this->color->Red("░") . $this->color->White("▌                            ") . $this->color->Red("│" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │") . $this->color->White("                          ▐") . $this->color->Red("░") . $this->color->White("▌▐") . $this->color->Red("░") . $this->color->White("▌ ▐") . $this->color->Red("░") . $this->color->White("▌▐") . $this->color->Red("░") . $this->color->White("▌          ▐") . $this->color->Red("░") . $this->color->White("▌▐") . $this->color->Red("░") . $this->color->White("▌          ▐") . $this->color->Red("░") . $this->color->White("▌                                 ") . $this->color->Red("│" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │") . $this->color->White("                          ▐") . $this->color->Red("░") . $this->color->White("▌") . $this->color->Red("░") . $this->color->White("▌   ▐") . $this->color->Red("░") . $this->color->White("▐") . $this->color->Red("░") . $this->color->White("▌ ▄▄▄▄▄▄▄▄▄█") . $this->color->Red("░") . $this->color->White("▌▐") . $this->color->Red("░") . $this->color->White("█▄▄▄▄▄▄▄▄▄ ▐") . $this->color->Red("░") . $this->color->White("█▄▄▄▄▄▄▄▄▄ ") . $this->color->Red("                │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │") . $this->color->White("                          ▐") . $this->color->Red("░░") . $this->color->White("▌     ▐") . $this->color->Red("░░") . $this->color->White("▌▐") . $this->color->Red("░░░░░░░░░░░") . $this->color->White("▌▐") . $this->color->Red("░░░░░░░░░░░") . $this->color->White("▌▐") . $this->color->Red("░░░░░░░░░░░") . $this->color->White("▌") . $this->color->Red("           │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │") . $this->color->White("                           ▀▀       ▀▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀▀▀▀▀▀▀▀▀▀▀                               ") . $this->color->Red("│" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                                                                                                                                                │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      ├────────────────────────────────────────────────────────────────────────────────────────────────┤" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                                                                                                │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                                    ") . $this->color->Bluee("HOW TO USE W3LL SENDER") . $this->color->Red("                                    │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                                                                                                │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                         ") . $this->color->Yellow("settings.php") . $this->color->white("  : ") . $this->color->Green("FOR SET SMTPS AND LINK") . $this->color->Red("                                        │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                          ") . $this->color->Yellow("config.php") . $this->color->white("    : ") . $this->color->Green("FOR SET SUBJECT,") . $this->color->Red("                                              │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                                        ") . $this->color->Green("FROM NAME, FROM MAIL, ETC") . $this->color->Red("                                     │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                               ") . $this->color->Yellow("W3LL_MAILIST") . $this->color->white("  : ") . $this->color->Green("FOR EMAIL LEADS") . $this->color->Red("                                           │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                     ") . $this->color->Yellow("W3LL_LETTER") . $this->color->white("         : ") . $this->color->Green("FOR LETTER") . $this->color->Red("                                                  │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                               ") . $this->color->Yellow("ATTACHMENT") . $this->color->white("         : ") . $this->color->Green("FOR ATTACHMENT FILE") . $this->color->Red("                                          │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                              ") . $this->color->Yellow("IMAGE") . $this->color->white("     : ") . $this->color->Green("FOR LOCAL IMAGE LOGO") . $this->color->Red("                                          │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                                                                                                │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      ├────────────────────────────────────────────────────────────────────────────────────────────────┤" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                                                                                                │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                            ") . $this->color->Bluee("CONTACT SUPPORT W3LL SENDER") . $this->color->Red("                                      │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                                                                                                │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                             ") . $this->color->Yellow("OFFICIAL WEBSITE  ") . $this->color->White(": ") . $this->color->Green("W3LL.STORE") . $this->color->Red("                                             │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                           ") . $this->color->Yellow("TELEGRAM          ") . $this->color->White(": ") . $this->color->Green("t.me/W3LLSTORE") . $this->color->Red("                                         │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                           ") . $this->color->Yellow("ICQ                 ") . $this->color->White(": ") . $this->color->Green("@W3LLSTORE_OFFICIAL") . $this->color->Red("                                    │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                                                                                                │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      │                                                                                                │" . PHP_EOL);
    $logo1[1] .= $this->color->Red("      └────────────────────────────────────────────────────────────────────────────────────────────────┘" . PHP_EOL);
    
    print_r($logo1[1]);
}
    public function start()
    {
        echo "\033[31m      ├──────────┬──────────┬───────────┬───────────────┬───────────────┬────────────┤\e[0m" .
            PHP_EOL;
        echo "\033[31m      │ \033[0m  TIME\033[31m   │   \033[0mFROM \033[31m  │    \033[0mTO \033[31m    │\033[31m    \033[0mSUBJECT \033[31m   │\033[31m   \033[0mFROM NAME \033[31m  │\033[31m   \033[0mSTATUS \033[31m  │" .
            PHP_EOL;
        echo "\033[31m      ├──────────┼──────────┼───────────┼───────────────┼───────────────┼────────────┤" .
            PHP_EOL;
    }
    public function notmatch()
    {
        echo PHP_EOL .
            "      " .
            $this->color->blockred("Error: Token not match.") .
            PHP_EOL .
            PHP_EOL;
    }
    public function login()
    {
        echo "      login success...";
        sleep(3);
        system("clear");
    }
    public function failedlogin()
    {
        echo "      " .
            $this->color->blockred("Error. Invalid Account!") .
            PHP_EOL .
            PHP_EOL;
    }
    public function errorcase1()
    {
        echo "\033[0;31m      ├──────────┴──────────┴───────────┴───────────────┴───────────────┴────────────┤" .
            PHP_EOL;
        echo "\033[0;31m      │ \e[0m     [ " .
            $this->color->Red(
                "PLEASE CHECK UR SMTP ON https://www.gmass.co/smtp-test [CASE1] ",
            ) .
            "]" .
            $this->color->Red("      │") .
            "\e[0m" .
            PHP_EOL;
        echo "\033[0;31m      ├──────────┬──────────┬───────────┬───────────────┬───────────────┬────────────┤" .
            PHP_EOL;
    }
    public function errorcase2()
    {
        echo "\033[0;31m      ├──────────┴──────────┴───────────┴───────────────┴───────────────┴────────────┤" .
            PHP_EOL;
        echo "\033[0;31m      │ \e[0m     [ " .
            $this->color->Red(
                "PLEASE CHECK UR SMTP ON https://www.gmass.co/smtp-test [CASE2] ",
            ) .
            "]" .
            $this->color->Red("      │") .
            "\e[0m" .
            PHP_EOL;
        echo "\033[0;31m      ├──────────┬──────────┬───────────┬───────────────┬───────────────┬────────────┤" .
            PHP_EOL;
    }
    public function errorletter()
    {
        echo "\033[0;31m      ├──────────────────────────────────────────────────────────────────────────────┤" .
            PHP_EOL;
        echo "\033[0;31m      │ \e[0m             [ " .
            $this->color->yellow(
                "LETTER NOT FOUND - PLEASE CHECK YOUR LETTER NAME ! ",
            ) .
            "]" .
            $this->color->Red("            │") .
            "\e[0m" .
            PHP_EOL;
        echo "\033[0;31m      └──────────────────────────────────────────────────────────────────────────────┘" .
            PHP_EOL;
    }
    public function errorattachment()
    {
        echo "\033[0;31m      ├──────────────────────────────────────────────────────────────────────────────┤" .
            PHP_EOL;
        echo "\033[0;31m      │ \e[0m       [ " .
            $this->color->yellow(
                "ATTACHMENT NOT FOUND - PLEASE CHECK YOUR ATTACHMENT NAME ! ",
            ) .
            "]" .
            $this->color->Red("        │") .
            "\e[0m" .
            PHP_EOL;
        echo "\033[0;31m      └──────────────────────────────────────────────────────────────────────────────┘" .
            PHP_EOL;
    }
    public function mailist()
    {
        echo "\033[0;31m      ├──────────────────────────────────────────────────────────────────────────────┤" .
            PHP_EOL;
        echo "\033[0;31m      │ \e[0m          [ " .
            $this->color->yellow(
                "MAILIST NOT FOUND - PLEASE CHECK YOUR MAILIST NAME ! ",
            ) .
            "]" .
            $this->color->Red("           │") .
            "\e[0m" .
            PHP_EOL;
        echo "\033[0;31m      └──────────────────────────────────────────────────────────────────────────────┘" .
            PHP_EOL;
    }
    public function done()
    {
        echo "\033[0;31m      └──────────┴──────────┴───────────┴───────────────┴───────────────┴────────────┘\e[0m" .
            PHP_EOL;
    }
    public function k1()
    {
        echo "\033[31m      │ \e[1;36m";
    }
    public function k3($num)
    {
        echo $num + 1;
    }
    public function k4()
    {
        echo $this->color->red(
            "      ├──────────┴──────────┴───────────┴───────────────┴───────────────┴────────────┤",
        ) . PHP_EOL;
        echo $this->color->red("      │") .
            $this->color->Green(
                "                                       TEST SENT!",
            ) .
            $this->color->red("                                │") .
            PHP_EOL;
        echo $this->color->red(
            "      ├──────────┬──────────┬───────────┬───────────────┬───────────────┬────────────┤",
        ) . PHP_EOL;
    }
    public function delay($rat, $W3LL_setup) {}
    public function pleasewait()
    {
        $iloop = "0";
        while (true) {
            $warn = "      Please Wait...\r";
            if (strlen($warn) === $iloop + 1) {
                $iloop = "0";
                break;
            }
            $warn = str_split($warn);
            $iloop++;
            $warn[$iloop] = strtoupper($warn[$iloop]);
            echo implode($warn);
            usleep(170000);
        }
    }
    public function update()
    {
        $iloop = "0";
        while (true) {
            $warn = "Checking updates...\r";
            if (strlen($warn) === $iloop + 1) {
                $iloop = "0";
                break;
            }
            $warn = str_split($warn);
            $iloop++;
            $warn[$iloop] = strtoupper($warn[$iloop]);
            echo implode($warn);
            usleep(170000);
        }
    }
} ?>
