"""
mailer module

Simple front end to the smtplib and email modules,
to simplify sending email.

A lot of this code was taken from the online examples in the
email module documentation:
http://docs.python.org/library/email-examples.html

Released under MIT license.

Version 0.5 is based on a patch by Douglas Mayle

Sample code:

    import mailer

    message = mailer.Message()
    message.From = "me@example.com"
    message.To = "you@example.com"
    message.RTo = "you@example.com"
    message.Subject = "My Vacation"
    message.Body = open("letter.txt", "rb").read()
    message.attach("picture.jpg")

    sender = mailer.Mailer('mail.example.com')
    sender.send(message)

"""

from __future__ import with_statement

import logging
from logging import exception

from smtplib import SMTPException, SMTP_SSL, SMTP
import socket
import threading
import queue
import uuid
import sys
import ssl
import random

if sys.version_info[0] >= 3:
    unicode = str
    basestring = str

from formatflowed import convertToWrapped
import email
from email import encoders
from email.header import make_header
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.charset import Charset
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import mimetypes
import time
from os import path

__version__ = '0.8.1'
__author__ = 'Ryan Ginstrom'
__license__ = 'MIT'
__description__ = 'A module to send email simply in Python'


class Mailer(object):
    """
    Represents an SMTP connection.

    Use login() to log in with a username and password.
    """

    def __init__(self, host='localhost', port=0, use_tls=False, usr=None, pwd=None, use_ssl=False, use_plain_auth=False, timeout=socket._GLOBAL_DEFAULT_TIMEOUT):
        self.host = host
        self.port = port
        self.use_tls = use_tls
        self.use_ssl = use_ssl
        self.use_plain_auth = use_plain_auth
        self._usr = usr
        self._pwd = pwd
        self.timeout = timeout
        self.server = None

    def connect(self, debug=0):
        try:
            if self.use_ssl:
                try:
                    self.server = SMTP_SSL(self.host, self.port, timeout=self.timeout)
                    self.server.set_debuglevel(int(debug))
                    if self.use_plain_auth is True:
                        self.server.esmtp_features['auth'] = 'LOGIN PLAIN'
                    if self._usr:
                        self.server.login(self._usr, self._pwd)
                    errs = 'OK'
                except Exception as err:
                    errs = str(type(err))
            else:
                self.server = SMTP(self.host, self.port, timeout=self.timeout)
                self.server.set_debuglevel(int(debug))
                if self.use_tls is True:
                    self.server.ehlo()
                    self.server.starttls()
                    self.server.ehlo()
                if self.use_plain_auth is True:
                    self.server.esmtp_features['auth'] = 'LOGIN PLAIN'
                if self._usr:
                    self.server.login(self._usr, self._pwd)
                errs = 'OK'
        except Exception as err:
            errs = str(type(err))
        return errs

    def login(self, usr, pwd):
        self._usr = usr
        self._pwd = pwd

    def send_test(self, msg, debug=0):
        try:
            self.server.set_debuglevel(int(debug))
            if isinstance(msg, Message):
                msg = [msg]
            for m in msg:
                self._send(self.server, m)
            err = 'OK'
            return err
        except Exception as err:
            raise

    def send(self, msg, debug=False):
        """
        Send one message or a sequence of messages.

        Every time you call send, the mailer creates a new
        connection, so if you have several emails to send, pass
        them as a list:
        mailer.send([msg1, msg2, msg3])
        """
        if self.use_ssl:
            server = SMTP_SSL(self.host, self.port, timeout=self.timeout)
        else:
            server = SMTP(self.host, self.port, timeout=self.timeout)
        server.set_debuglevel(1)
        if self._usr and self._pwd:
            if self.use_tls is True:
                server.ehlo()
                server.starttls()
                server.ehlo()
            if self.use_plain_auth is True:
                server.esmtp_features['auth'] = 'LOGIN PLAIN'
            server.login(self._usr, self._pwd)
        if isinstance(msg, Message):
            msg = [msg]
        for m in msg:
            self._send(server, m)
        server.quit()

    def is_connected(self):
        try:
            status = self.server.noop()[0]
        except:
            status = -1
        return True if status == 250 else False

    def _send(self, server, msg):
        """
        Sends a single message using the server
        we created in send()
        """
        me = msg.From
        if isinstance(msg.To, basestring):
            to = [msg.To]
        else:
            to = list(msg.To)
        cc = []
        if msg.CC:
            if isinstance(msg.CC, basestring):
                cc = [msg.CC]
            else:
                cc = list(msg.CC)
        bcc = []
        if msg.BCC:
            if isinstance(msg.BCC, basestring):
                bcc = [msg.BCC]
            else:
                bcc = list(msg.BCC)
        rto = []
        if msg.RTo:
            if isinstance(msg.RTo, basestring):
                rto = [msg.RTo]
            else:
                rto = list(msg.RTo)
        you = to + cc + bcc
        server.sendmail(me, you, msg.as_string())


class Message(object):
    """
    Represents an email message.

    Set the To, From, Reply-To, Subject, and Body attributes as plain-text strings.
    Optionally, set the Html attribute to send an HTML email, or use the
    attach() method to attach files.

    Use the charset property to send messages using other than us-ascii

    If you specify an attachments argument, it should be a list of
    attachment filenames: ["file1.txt", "file2.txt"]

    `To` should be a string for a single address, and a sequence
    of strings for multiple recipients (castable to list)

    Send using the Mailer class.
    """

    def __init__(self, **kwargs):
        """
        Parameters and default values (parameter names are case insensitive):
            To=None, From=None, RTo=None, CC=None, BCC=None, Subject=None, Body=None, Html=None,
            Date=None, Attachments=None, Charset=None, Headers=None
        """
        params = {}
        for i in kwargs:
            params[i.lower()] = kwargs[i]
        self.attachments = []
        attachments = params.get('attachments', None)
        if attachments:
            for attachment in attachments:
                if isinstance(attachment, basestring):
                    self.attachments.append((attachment, None, None, None, None))
                else:
                    try:
                        length = len(attachment)
                    except TypeError:
                        length = None
                    if length is None or length <= 4:
                        self.attachments.append((attachment, None, None, None, None))
                    else:
                        self.attachments.append(tuple(attachment) + (None, None, None, None)[:4 - len(attachment)])
        self.To = params.get('to', None)
        self.RTo = params.get('rto', None)
        self.CC = params.get('cc', None)
        self.BCC = params.get('bcc', None)
        self.From = params.get('from', None)
        self.Subject = params.get('subject', '')
        self.Body = params.get('body', None)
        self.Html = params.get('html', None)
        self.config = params.get('config', None)
        self.Date = params.get('date', None)
        self.charset = params.get('charset', None)
        self.Headers = params.get('headers', {})
        if isinstance(self.Body, unicode):
            self.Body = self.Body.encode(self.charset)
        self.message_id = self.make_key()

    def decode_punnycode(self, string):
        list = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '[', ']', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', ':', ',', '.', '#']
        replaces = ['ａ', 'ᖯ', 'ｃ', 'ｄ', 'ｅ', 'ｆ', 'ｇ', 'ｈ', 'ｉ', 'ｊ', 'ｋ', 'ｌ', 'ｍ', 'ｎ', 'ｏ', 'ｐ', 'ｑ', 'ｒ', 'ｓ', 'ｔ', 'ｕ', 'ｖ', 'ｗ', 'ｘ', 'ｙ', 'ｚ', '［', '］', 'Ａ', 'Ｂ', 'Ｃ', 'Ｄ', 'Ｅ', 'Ｆ', 'Ｇ', 'Ｈ', 'Ｉ', 'Ｊ', 'Ｋ', 'Ｌ', 'Ｍ', 'Ｎ', 'Ｏ', 'Ｐ', 'Ｑ', 'Ｒ', 'Ｓ', 'Ｔ', 'Ｕ', 'Ｖ', 'Ｗ', 'Ｘ', 'Ｙ', 'Ｚ', '１', '２', '３', '４', '５', '６', '７', '８', '９', '０', '：', '，', '．', '＃']
        for ele in replaces:
            count = replaces.index(ele)
            string = string.replace(ele, list[count])
        return string

    def make_key(self):
        return str(uuid.uuid4())

    def header(self, msg, name, value):
        if value is None:
            return
        if isinstance(value, list):
            value = ', '.join(value)
        if isinstance(value, unicode):
            value = value.encode(self.charset)
        msg[name] = make_header([(value, self.charset)])

    def as_string(self):
        if self.attachments:
            return self._multipart()
        elif self.Html:
            return self._with_html()
        else:
            return self._plaintext()

    def _plaintext(self):
        msg = MIMEText(self.Body, 'plain', self.charset)
        self._set_info(msg)
        return msg.as_string()

    def _with_html(self):
        outer = MIMEMultipart('alternative')
        part1 = MIMEText(self.Body, 'plain', self.charset)
        cs = Charset(self.charset)
        enco = random.choice(self.config.get_encoding())
        if enco == 'base64':
            cs.body_encoding = 2
        elif enco == 'quoted-printable':
            cs.body_encoding = 1
        if enco == '8bit':
            part2 = MIMEText(self.Html, 'html')
            part2.set_charset(self.charset)
        else:
            part2 = MIMEText(self.Html, 'html', _charset=cs)
        outer.attach(part1)
        outer.attach(part2)
        self._set_info(outer)
        return outer.as_string()

    def _set_info(self, msg):
        # Set headers like From, To, Subject, etc.
        self.header(msg, 'From', self.From)
        self.header(msg, 'To', self.To)
        self.header(msg, 'Cc', self.CC)
        self.header(msg, 'Reply-To', self.RTo)
        self.header(msg, 'Subject', self.Subject)
        self.header(msg, 'Date', self.Date)
        self.header(msg, 'Message-ID', self.message_id)
        for name, value in self.Headers.items():
            self.header(msg, name, value)

    def _multipart(self):
        msg = MIMEMultipart('related')
        outer = MIMEMultipart('alternative')
        if self.Html:
            part1 = MIMEText(self.Body, 'plain', self.charset)
            part1.add_header('Content-Disposition', 'inline')
            cs = Charset(self.charset)
            enco = random.choice(self.config.get_encoding())
            if enco == 'base64':
                cs.body_encoding = 2
            elif enco == 'quoted-printable':
                cs.body_encoding = 1
            if enco == '8bit':
                part2 = MIMEText(self.Html, 'html')
                part2.set_charset(self.charset)
            else:
                part2 = MIMEText(self.Html, 'html', _charset=cs)
            part2.add_header('Content-Disposition', 'inline')
            outer.attach(part1)
            outer.attach(part2)
            msg.attach(outer)
        else:
            msg.attach(MIMEText(self.Body, 'plain', self.charset))
        self._set_info(msg)
        if self.config.get('subject_encode_type') == 'punnycode' and self.config.get('subject_encrypt') == '1':
            subs = self.decode_punnycode(self.Subject)
            msg.preamble = subs
        else:
            msg.preamble = self.Subject
        for filename, cid, mimetype, content, charset in self.attachments:
            self._add_attachment(msg, filename, cid, mimetype, content, charset)
        return msg.as_string()

    def _add_attachment(self, outer, filename, cid, mimetype, content, charset):
        """
        If mimetype is None, it will try to guess the mimetype
        """
        if mimetype:
            ctype = mimetype
            encoding = None
        else:
            ctype, encoding = mimetypes.guess_type(filename)
        if ctype is None or encoding is not None:
            ctype = 'application/octet-stream'
        maintype, subtype = ctype.split('/', 1)
        if content:
            pass
        else:
            with open(filename, 'rb') as fp:
                content = fp.read()
        if maintype == 'text':
            msg = MIMEText(content, _subtype=subtype, _charset=charset)
        elif maintype == 'image':
            msg = MIMEImage(content, _subtype=subtype)
        elif maintype == 'audio':
            msg = MIMEAudio(content, _subtype=subtype)
        else:
            msg = MIMEBase(maintype, subtype)
            msg.set_payload(content)
            encoders.encode_base64(msg)
        if cid:
            msg.add_header('Content-ID', '<%s>' % cid)
            msg.add_header('Content-Disposition', 'inline')
        else:
            msg.add_header('Content-Disposition', 'attachment', filename=path.basename(filename))
        outer.attach(msg)

    def attach(self, filename, cid=None, mimetype=None, content=None, charset=None):
        """
        Attach a file to the email. Specify the name of the file;
        Message will figure out the MIME type and load the file.

        Specify mimetype to set the MIME type manually. The content
        argument take the contents of the file if they are already loaded
        in memory.
        """
        self.attachments.append((filename, cid, mimetype, content, charset))


class Manager(threading.Thread):
    """
    Manages the sending of email in the background.

    You can supply it with an instance of class Mailer or pass in the same
    parameters that you would have used to create an instance of Mailer.

    If a message was succesfully sent, self.results[msg.message_id] returns a 3
    element tuple (True/False, err_code, err_message).
    """

    def __init__(self, mailer=None, callback=None, **kwargs):
        threading.Thread.__init__(self)
        self.queue = queue.Queue()
        self.mailer = mailer
        self.abort = False
        self.callback = callback
        self._results = {}
        self._result_lock = threading.RLock()
        if self.mailer is None:
            self.mailer = Mailer(
                kwargs.get('host', 'localhost'),
                kwargs.get('port', 25),
                kwargs.get('use_tls', False),
                kwargs.get('usr', None),
                kwargs.get('pwd', None)
            )

    def __getattr__(self, name):
        if name == 'results':
            with self._result_lock:
                return self._results

    def run(self):
        while self.abort is False:
            msg = self.queue.get(block=True)
            if msg is None:
                break
            if isinstance(msg, Message):
                msg = [msg]
            for m in msg:
                try:
                    self.results[m.message_id] = (False, -1, '')
                    self.mailer.send(m)
                    self.results[m.message_id] = (True, 0, '')
                except Exception as e:
                    args = e.args
                    if len(args) < 2:
                        args = (-1, args[0])
                    self.results[m.message_id] = (False, args[0], args[1])
                try:
                    if self.callback:
                        self.callback(m.message_id)
                except Exception:
                    pass
            self.queue.task_done()

    def send(self, msg):
        self.queue.put(msg)