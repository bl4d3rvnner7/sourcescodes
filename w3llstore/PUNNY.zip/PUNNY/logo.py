import time
import os
from colorama import Fore

def logo():
    logo = '\n┌──────────────────────────────────────────────────────────────────────────────┐\n│\t\t\t\t\t\t                               │\n│\t\t\t ▒█▀▀█ ▒█░▒█ ▒█▄░▒█ ▒█▄░▒█ ▒█░░▒█\t\t       │\n│\t\t\t {}▒█▄▄█ ▒█░▒█ ▒█▒█▒█ ▒█▒█▒█ ▒█▄▄▄█{}                      │\n│\t\t\t ▒█░░░ ░▀▄▄▀ ▒█░░▀█ ▒█░░▀█ ░░▒█\t\t               │\n│                                                                              │\n├──────────────────────────────────────────────────────────────────────────────┤\n│                                                                              │\n│                            {}HOW TO USE PUNNY SENDER{}                           │\n│                                                                              │\n│\t\t       {}files/attachment{} : FOR ATTACHMENT FILE\t\t       │\n│\t\t       {}files/mail_list{}  : FOR EMAIL LEADS\t\t       │\t\t   \t\n│\t\t       {}files/letter{}     : FOR LETTER\t\t               │\n│\t\t       {}files/image{} \t: FOR LOCAL IMAGE LOGO                 │\n│             \t       {}config.ini{}       : FOR SET ALL CONFIIGURATION           │\n│                                                                              │\n├──────────────────────────────────────────────────────────────────────────────┤\n│                                                                              │\n│                         {}CONTACT SUPPORT PUNNY SENDER{}\t\t               │\n│                                                                              │\n│                           {}TELEGRAM{} : t.me/W3LLSTORE                          │\t\n│                           {}WEBSITE{}  : W3LL.SHOP                               │\n│                                                                              │\n├────────────┬────────────┬────────────┬────────────┬────────────┬─────────────┤\n│    TIME    │    FROM    │     TO     │  SUBJECTS  │  FROMNAME  │    CODE!    │\n├────────────┼────────────┼────────────┼────────────┼────────────┼─────────────┤'.format(Fore.GREEN, Fore.WHITE, Fore.YELLOW, Fore.WHITE, Fore.GREEN, Fore.WHITE, Fore.GREEN, Fore.WHITE, Fore.GREEN, Fore.WHITE, Fore.GREEN, Fore.WHITE, Fore.GREEN, Fore.WHITE, Fore.YELLOW, Fore.WHITE, Fore.GREEN, Fore.WHITE, Fore.GREEN, Fore.WHITE)
    for line in logo.split('\n'):
        print(line)
        time.sleep(0.15)


def end():
    endlogo = '├────────────┴────────────┴────────────┴────────────┴────────────┴─────────────┤    \n{}│               {}█▀ █▀▀ █▄░█ █▀▄ █ █▄░█ █▀▀   █▀▀ █ █▄░█ █ █▀ █░█               │\n{}│               {}▄█ ██▄ █░▀█ █▄▀ █ █░▀█ █▄█   █▀░ █ █░▀█ █ ▄█ █▀█               {}│\n└──────────────────────────────────────────────────────────────────────────────┘'.format(Fore.WHITE, Fore.WHITE, Fore.WHITE, Fore.GREEN, Fore.WHITE)
    for line in endlogo.split('\n'):
        print(line)
        time.sleep(0.15)


def clearConsole():
    command = 'clear'
    if os.name in ('nt', 'dos'):
        command = 'cls'
    os.system(command)