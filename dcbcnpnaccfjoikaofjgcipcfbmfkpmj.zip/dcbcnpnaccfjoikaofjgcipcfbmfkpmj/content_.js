(function() {
    chrome.runtime.onMessage.addListener((async (e, t, n) => {
        var m;
        "ASK_CHATGPT" === e.type && (document.activeElement && (document.activeElement.isContentEditable || "TEXTAREA" === document.activeElement.nodeName.toUpperCase() || "INPUT" === document.activeElement.nodeName.toUpperCase()) ? (originalActiveElement = document.activeElement, m = document.getSelection().toString().trim() || document.activeElement.textContent.trim()) : m = document.getSelection().toString().trim(), setTimeout((() => {
            chrome.runtime.sendMessage({
                action: "ASK_CHATGPT_SIDEPANEL",
                ask: m
            })
        }), 1e3))
    }))
})();