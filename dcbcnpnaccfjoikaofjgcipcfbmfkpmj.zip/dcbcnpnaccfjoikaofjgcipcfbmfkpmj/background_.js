(function() {
    chrome.sidePanel.setPanelBehavior({
        openPanelOnActionClick: !0
    }), chrome.contextMenus.create({
        id: "ask-chatgpt",
        title: "Ask ChatGPT",
        contexts: ["all"]
    }), chrome.contextMenus.onClicked.addListener(((e, n) => {
        "ask-chatgpt" === e.menuItemId && chrome.sidePanel.open({
            windowId: n.windowId
        }, (function() {
            chrome.tabs.sendMessage(n.id, {
                type: "ASK_CHATGPT"
            })
        }))
    })), chrome.tabs.onUpdated.addListener(((e, n, t) => {}))
})();