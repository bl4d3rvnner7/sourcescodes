Please download XAMPP version 7.3.13
https://sourceforge.net/projects/xampp/files/XAMPP%20Windows/7.3.13/xampp-portable-windows-x64-7.3.13-0-VC15-installer.exe/download

- Download and Install XAMPP
- Add xampp folder to path
- Open Xampp Control Panel
- Start Apache 


Guide to use Validator:
Click _start

P/S: RECHECK means that HTTP Status 429 – Too Many Requests occurs when the server limits the number of requests you can send within a specific timeframe, because this validator not use proxy. You can recheck it later or mark it as DEAD.