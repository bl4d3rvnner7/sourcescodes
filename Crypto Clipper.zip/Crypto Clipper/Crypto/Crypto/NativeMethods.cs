﻿using System;
using System.Runtime.InteropServices;

namespace Crypto.Crypto
{
	internal sealed class NativeMethods
	{
		[DllImport("user32.dll", SetLastError = true)]
		public static extern bool AddClipboardFormatListener(IntPtr hwnd);

		[DllImport("user32.dll", SetLastError = true)]
		public static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);

		public const int WM_CLIPBOARDUPDATE = 797;

		public static IntPtr HWND_MESSAGE = new IntPtr(-3);
	}
}
