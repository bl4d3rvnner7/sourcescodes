<?php


$smtp_host = 'smtp.sendgrid.net';
$smtp_port = '587';
$smtp_user = 'apikey';
$smtp_pass = '';
$smtp_from = '';
$smtp_name = '';
$smtp_cert = false; // ssl, tls
$smtp_auth = true;
$smtp_test = '';
$smtp_debg = true; 
$smtp_char = 'UTF-8'; 
