<?php
/**
 * Bec Mailer by [bectools.pw]
 * @version : 1.0
**/

/*

DEBUGGING

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
*/


$password = "bectools"; // Change me please :/

require_once __DIR__ . "/config.php";

session_start();
error_reporting(0);
set_time_limit(0);
ini_set("memory_limit",-1);

$leaf['version']="1.0";
$leaf['website']="bectools.pw";


$sessioncode = md5(__FILE__);
if (!empty($password) && (!isset($_SESSION[$sessioncode]) || $_SESSION[$sessioncode] !== $password)) {
    if (isset($_REQUEST['pass']) && $_REQUEST['pass'] === $password) {
        $_SESSION[$sessioncode] = $password;
    } else {
        echo "<pre align=center><form method=post>
                Password: <input type='password' name='pass'>
                <input type='submit' value='>>'>
              </form></pre>";
        exit;
    }
}

//session_write_close();


function leafClear($text,$email){
	$e = explode('@', $email);
	$emailuser=$e[0];
	$emaildomain=$e[1];
    $text = str_replace("[-time-]", date("m/d/Y h:i:s a", time()), $text);
    $text = str_replace("[-email-]", $email, $text);
    $text = str_replace("[-emailuser-]", $emailuser, $text);
    $text = str_replace("[-emaildomain-]", $emaildomain, $text);
    $text = str_replace("[-randomletters-]", randString('abcdefghijklmnopqrstuvwxyz'), $text);
    $text = str_replace("[-randomstring-]", randString('abcdefghijklmnopqrstuvwxyz0123456789'), $text);
    $text = str_replace("[-randomnumber-]", randString('0123456789'), $text);
    $text = str_replace("[-randommd5-]", md5(randString('abcdefghijklmnopqrstuvwxyz0123456789')), $text);
    return $text;
}
function leafTrim($string){
	$string=urldecode($string);
    return stripslashes(trim($string));
}
function randString($consonants) {
    $length=rand(12,25);
    $password = '';
    for ($i = 0; $i < $length; $i++) {
            $password .= $consonants[(rand() % strlen($consonants))];
    }
    return $password;
}
function leafMailCheck($email){
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) return true;
    else return false;
}
# Bulit-in BlackList Checker
if(isset($_GET['check_ip'])){
    if (isset($_GET['host'])){
        $_GET['host']=explode(",", $_GET['host']);
        foreach ($_GET['host'] as $host) {
            if (checkdnsrr($_GET['check_ip'] . "." .  $host . ".", "A")) $check= "<font color='red'> Listed</font>";
            else $check= "<font color='#10ff10'> Clean</font>";
            print 'document.getElementById("'. $host.'").innerHTML = "'.$check.'";';
        }

        exit;
    }
    $dnsbl_lookup = [
        "all.s5h.net",
        "b.barracudacentral.org",
        "bl.spamcop.net",
        "blacklist.woody.ch",
        "bogons.cymru.com",
        "cbl.abuseat.org",
        "cdl.anti-spam.org.cn",
        "combined.abuse.ch",
        "db.wpbl.info",
        "dnsbl-1.uceprotect.net",
        "dnsbl-2.uceprotect.net",
        "dnsbl-3.uceprotect.net",
        "dnsbl.anticaptcha.net",
        "dnsbl.dronebl.org",
        "dnsbl.inps.de",
        "dnsbl.sorbs.net",
        "drone.abuse.ch",
        "duinv.aupads.org",
        "dul.dnsbl.sorbs.net",
        "dyna.spamrats.com",
        "dynip.rothen.com",
        "http.dnsbl.sorbs.net",
        "ips.backscatterer.org",
        "ix.dnsbl.manitu.net",
        "korea.services.net",
        "misc.dnsbl.sorbs.net",
        "noptr.spamrats.com",
        "orvedb.aupads.org",
        "pbl.spamhaus.org",
        "proxy.bl.gweep.ca",
        "psbl.surriel.com",
        "relays.bl.gweep.ca",
        "relays.nether.net",
        "sbl.spamhaus.org",
        "short.rbl.jp",
        "singular.ttk.pte.hu",
        "smtp.dnsbl.sorbs.net",
        "socks.dnsbl.sorbs.net",
        "spam.abuse.ch",
        "spam.dnsbl.anonmails.de",
        "spam.dnsbl.sorbs.net",
        "spam.spamrats.com",
        "spambot.bls.digibase.ca",
        "spamrbl.imp.ch",
        "spamsources.fabel.dk",
        "ubl.lashback.com",
        "ubl.unsubscore.com",
        "virus.rbl.jp",
        "web.dnsbl.sorbs.net",
        "wormrbl.imp.ch",
        "xbl.spamhaus.org",
        "z.mailspike.net",
        "zen.spamhaus.org",
        "zombie.dnsbl.sorbs.net",
    ];
    $reverse_ip = implode(".", array_reverse(explode(".", $_GET['check_ip'])));
    $dnsT = count($dnsbl_lookup);
    leafheader();
    print '<div class="container col-lg-6"><h3><font color="#20ff20"><span class="glyphicon glyphicon-tower"></span></font> PHPMailer <small>Blacklist Checker</small></h3>';
    Print "Checking <b>".$_GET['check_ip']."</b> in <b>$dnsT</b>  anti-spam databases:<br>";
    $dnsN="";
    print '<table >';
    for ($i=0; $i < $dnsT; $i=$i+10) {
        $host="";
        $hosts="";
        for($j=$i; $j<$i+10;$j++){
            $host=$dnsbl_lookup[$j];
            if(!empty($host)){
                print "<tr> <td>$host</td> <td id='$host'>Checking ..</td></tr>";
                $hosts .="$host,";
            }
        }
        $dnsN.="<script src='?check_ip=$reverse_ip&host=".$hosts."' type='text/javascript'></script>";
    }

    print '</table></div>';
    print $dnsN;
    exit;
}
if(isset($_GET['emailfilter'])){

    if(!empty($_FILES['fileToUpload']['tmp_name'])){
        $_POST['emailList']= file_get_contents($_FILES["fileToUpload"]["tmp_name"]);
    }
    $_POST['emailList']=strtolower($_POST['emailList']);
   if($_GET['emailfilter']=="ifram"){
        if ($_POST['resulttype'] == "download"){
            header("Content-Description: File Transfer");
            header("Content-Type: application/octet-stream");
            header("Content-Disposition: attachment; filename=emails".time().".txt");
        }
        else {
            header("Content-Type: text/plain");
        }
    if($_POST['submit']=="extract"){
        $pattern = '/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}/';
        preg_match_all($pattern, $_POST['emailList'], $matches);
        foreach ($matches[0] as $email) {
            print $email."\n";
        }
    }
    elseif ($_POST['submit']=="filter") {
        $emails=explode("\n", $_POST['emailList']);
        $keywords=explode("\n", strtolower($_POST['keywords']));
        foreach ($emails as $email) {
            foreach ($keywords as $keyword ) {
                if(strstr($email, $keyword) ){
                    print $email."\n";
                     break;
                }

            }
        }

    }
    exit;
   }
   leafheader();
   print '<body style="background-color:black;color:white"><div class="container col-lg-12"><h3><font color="#20ff20"><span class="glyphicon glyphicon-tower"></span></font> PHPMailer <small style="color:#bcff5b";>Email Filter</small></h3>';
   print '
    <form action="?emailfilter=ifram" method="POST" target="my-iframe" enctype="multipart/form-data" onsubmit=\'\'>
        <label for="emailList">Text </label><input type="file" name="fileToUpload" id="fileToUpload">
        or

        <textarea name="emailList" id="emailList" class="form-control" rows="7" id="textArea"></textarea>
      <div class="col-lg-12">
        <div class="radio">
          <label>
            <input type="radio" name="resulttype" id="resulttype" value="here" checked="">
            Show Result in this page
          </label>
        </div>
        <div class="radio">
          <label>
            <input type="radio" name="resulttype" id="resulttype" value="download">
            Download Result (for big numbers)
          </label>
        </div>
      </div>
      <legend><h4 style="color: #70ff70;">Extract Emails</h4></legend>
            Detecting every email (100%) and order them line by line <br><br>
        <button type="submit" name="submit" value="extract" class="btn btn-default btn-sm">Start</button>
            <legend><h4 style="color: #70ff70;">Filter Emails</h4></legend>
        <label >Keywords <small> ex: gmail.com or .co.uk</small> </label><textarea name="keywords" id="keywords" class="form-control" rows="4" id="textArea">gmail.com
hotmail.com
yahoo.com
.co.uk</textarea><br>

            <button type="submit" name="submit" value="filter" class="btn btn-default btn-sm">Start</button>
    </form>
    <label >Result </label>
    <iframe style="border:none;width:100%;" name="my-iframe"  src="?emailfilter=ifram" ></iframe>
   ';
   exit;

}
$html="checked";
$utf8="selected";
$bit8="selected";
$plain="selected";
$user = $smtp_from ?? ''; // Fallback to empty string if not in config
$subject = '';
$messageLetter = '';
$emailList = '';
$iso = '';
$bit7 = '';
$binary = '';
$base64 = '';
$quotedprintable = '';

if(isset($_POST['action']) && ($_POST['action']=="send" || $_POST['action']=="score")){

    $senderEmail=leafTrim($_POST['senderEmail']);
    $senderName=leafTrim($_POST['senderName']);
    $replyTo=leafTrim($_POST['replyTo']);
    $subject=leafTrim($_POST['subject']);
    $emailList=leafTrim($_POST['emailList']);
    $messageType=leafTrim($_POST['messageType']);
    $messageLetter=leafTrim($_POST['messageLetter']);
    $encoding = $_POST['encode'];
    $charset = $_POST['charset'];
    $html="";
    $utf8="";
    $bit8="";

    if($messageType==2) $plain="checked";
    else $html="checked";

    if($charset=="ISO-8859-1") $iso="selected";
    else $utf8="selected";

    if($encoding=="7bit") $bit7="selected";
    elseif($encoding=="binary") $binary="selected";
    elseif($encoding=="base64") $base64="selected";
    elseif($encoding=="quoted-printable") $quotedprintable="selected";
    else $bit8="selected";



}
if($_POST['action']=="view"){
	$viewMessage=leafTrim($_POST['messageLetter']);
	$viewMessage=leafClear($viewMessage,"user@domain.com");
	if ($_POST['messageType']==2){
		print "<pre>".htmlspecialchars($viewMessage)."</pre>";
	}
	else {
		print $viewMessage;
	}
	exit;
}



if(!isset($_POST['senderEmail'])){
    $senderEmail="support@".str_replace("www.", "", $_SERVER['HTTP_HOST']);
    if (!leafMailCheck($senderEmail)) $senderEmail="";
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'vendor/autoload.php';
require 'config.php';

function leafheader(){
print '
<head>
    <title>'.str_replace("www.", "", $_SERVER['HTTP_HOST']).' - PHPMailer</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <link href="https://maxcdn.bootstrapcdn.com/bootswatch/3.4.1/cyborg/bootstrap.min.css" rel="stylesheet" >
    <style>.form-control {background-color:black};</style>
</head>';
}
leafheader();
print '<body style="color: #fff;background-color: #000;">';
print '<script>
    var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");



}
    </script>';
print '<div class="container col-lg-12">
        <h3><font color="#20ff20"><span class="glyphicon glyphicon-grain"></span></font> Bec Mailer  <small>'.$leaf['version'].'</small></h3>
        <form name="form" id="form" method="POST" enctype="multipart/form-data" action="">
                    <input type="hidden" name="action" value="score">

            <div class="row">
                <div class="form-group col-lg-6 "><label for="senderEmail">From Address</label><input type="text" class="form-control  input-sm " id="senderEmail" name="senderEmail" value="'.$smtp_from.'"></div>
                <div class="form-group col-lg-6 "><label for="senderName">Sender Name</label><input type="text" class="form-control  input-sm " id="senderName" name="senderName" value="'.$smtp_name.'"></div>
            </div>
            <div class="row">
                <span class="form-group col-lg-6  "><label for="attachment">Attachment <small>(Multiple Available)</small></label><input type="file" name="attachment[]" id="attachment[]" multiple/></span>

                <div class="form-group col-lg-6"><label for="replyTo">Reply-to Address</label><input type="text" class="form-control  input-sm " id="replyTo" name="replyTo" value="'.$user.'" /></div>
            </div>
            <div class="row">
                <div class="form-group col-lg-12 "><label for="subject">Subject</label><input type="text" class="form-control  input-sm " id="subject" name="subject" value="'.$subject.'" /></div>
            </div>
            <div class="row">
                <div class="form-group col-lg-6"><label for="messageLetter">Message Letter <button type="submit" class="btn btn-default btn-xs" form="form" name="action" value="view" formtarget="_blank">Preview </button></label><textarea name="messageLetter" id="messageLetter" class="form-control" rows="10" id="textArea">'.$messageLetter.'</textarea></div>
                <div class="form-group col-lg-6 "><label for="emailList">Email List <a href="?emailfilter=on" target="_blank" class="btn btn-default btn-xs">Filter/Extract</a></label><textarea name="emailList" id="emailList" class="form-control" rows="10" id="textArea">'.$emailList.'</textarea></div>
            </div>
            <div class="row">
                <div class="form-group col-lg-6 ">
                    <label for="messageType">Message Type</label>
                    HTML <input type="radio" name="messageType" id="messageType" value="1" '.$html.'>
                    Plain<input type="radio" name="messageType" id="messageType" value="2" '.$plain.'>
                </div>
                <div class="form-group col-lg-3 ">
                    <label for="charset">Character set</label>
                    <select class="form-control input-sm" id="charset" name="charset">
                        <option '.$utf8.'>UTF-8</option>
                        <option '.$iso.'>ISO-8859-1</option>
                    </select>
                </div>
                <div class="form-group col-lg-3 ">
                    <label for="encoding">Message encoding</label>
                    <select class="form-control input-sm" id="encode" name="encode">
                        <option '.$bit8.'>8bit</option>
                        <option '.$bit7.'>7bit</option>
                        <option '.$binary.'>binary</option>
                        <option '.$base64.'>base64</option>
                        <option '.$quotedprintable.'>quoted-printable</option>

                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-danger btn-sm" form="form" name="" value="send">TEST SMTP</button>
              <button type="submit" class="btn btn-success btn-sm" form="form" name="" value="send">SAVE SMTP</button>
              <button type="submit" class="btn btn-primary btn-sm" form="form" name="action" value="send">START SEND</button>
 or <a href="#" onclick="document.getElementById(\'form\').submit(); return false;">check SpamAssassin Score</a>

        </form>
    </div>


      </div>';
if($_POST['action']=="send"){
    print '    <div class="col-lg-12">';
    $maillist=explode("\r\n", $emailList);
    $n=count($maillist);
    $x =1;
    foreach ($maillist as $email ) {
        print '<div class="col-lg-1">['.$x.'/'.$n.']</div><div class="col-lg-4">'.$email.'</div>';
        if(!leafMailCheck($email)) {
            print '<div class="col-lg-6"><span class="label label-default">Incorrect Email</span></div>';
            print "<br>\r\n        </div>";
        }
        else {

            require 'config.php';

            // Create an instance; passing `true` enables exceptions
            $mail = new PHPMailer(true);
            $mail->SMTPDebug  = false;
            $mail->isSMTP(); // Send using SMTP
            $mail->Host       = $smtp_host;
            $mail->SMTPAuth   = true;
            $mail->Username   = $smtp_user;
            $mail->Password   = $smtp_pass;
            $mail->SMTPSecure = $smtp_cert;
            $mail->Port       = $smtp_port;
            $mail->setFrom(leafClear($senderEmail,$email),leafClear($senderName,$email));
            $mail->addReplyTo(leafClear($replyTo,$email));
            $mail->addAddress($email);
            $mail->Subject = leafClear($subject,$email);
            $mail->Body =  leafClear($messageLetter,$email);
            if($messageType==1){
                $mail->IsHTML(true);
                $mail->AltBody =strip_tags(leafClear($messageLetter,$email));
            }
            else $mail->IsHTML(false);
            $mail->CharSet = $charset;
            $mail->Encoding = $encoding;
            for($i=0; $i<count($_FILES['attachment']['name']); $i++) {
                if ($_FILES['attachment']['tmp_name'][$i] != ""){
                    $mail->AddAttachment($_FILES['attachment']['tmp_name'][$i],$_FILES['attachment']['name'][$i]);
                }

            }

            if (!$mail->send()) {
                echo '<div class="col-lg-6"><span class="label label-default">'.htmlspecialchars($mail->ErrorInfo).'</span></div>';
            }
            else {
                echo '<div class="col-lg-6"><span class="label label-success">Ok</span></div>';
            }
            print "<br>\r\n";
        }
        $x++;
        for($k = 0; $k < 40000; $k++) {echo ' ';}
    }

}
elseif($_POST['action']=="score"){
    $mail = new PHPMailer;
    $mail->SMTPDebug  = false;
    $mail->isSMTP(); // Send using SMTP
    $mail->Host       = $host;
    $mail->SMTPAuth   = $auth;
    $mail->Username   = $user;
    $mail->Password   = $pass;
    $mail->SMTPSecure = $auth;
    $mail->Port       = $port;
    $mail->setFrom(leafClear($senderEmail,$email),leafClear($senderName,$email));
    $mail->addReplyTo(leafClear($replyTo,$email));
    $mail->addAddress("username@domain.com");
    $mail->Subject = leafClear($subject,$email);
    $mail->Body =  leafClear($messageLetter,$email);
    if($messageType==1){
        $mail->IsHTML(true);
        $mail->AltBody =strip_tags(leafClear($messageLetter,$email));
    }
    else $mail->IsHTML(false);
    $mail->SMTPDebug  = false;
    $mail->isSMTP(); // Send using SMTP
    $mail->Host       = $host;
    $mail->SMTPAuth   = $auth;
    $mail->Username   = $user;
    $mail->Password   = $pass;
    $mail->SMTPSecure = $auth;
    $mail->Port       = $port;
    $mail->CharSet = $charset;
    $mail->Encoding = $encoding;
    $mail->preSend();
    $messageHeaders=$mail->getSentMIMEMessage();
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, 'http://spamcheck.postmarkapp.com/filter');
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array('email' => $messageHeaders,'options'=>'long')));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    $response = curl_exec($ch);
    $response = json_decode($response);
    print '    <div class="col-lg-12">';
    if ($response->success == TRUE ){
        $score = $response->score;
        if ($score > 5 ) $class="danger";
        else $class="success";
            print '<div class="text-'.$class.'">Your SpamAssassin score is '.$score.'  </div>
<div>Full Report : <pre>'.$response->report.'</pre></div>';
print '    </div>';
    }
}
print '</body>';
?>
