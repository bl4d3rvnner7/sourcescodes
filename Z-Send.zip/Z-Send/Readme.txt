
╔══════════════════════════════════════════════════════════════════╗
║                        ZERODAYS SENDER                           ║
║              INBOX GUARANTEE, POWERFULL, SUPERFAST SENDING       ║
║                      CREATED BY ZERODAYS TEAM                    ║
╚══════════════════════════════════════════════════════════════════╝

📖 DESCRIPTION:
ZERODAYS SENDER (ZESSEN) is a high-performance, multi-threaded bulk email sender designed for professional email marketing and outreach. It features a robust SMTP engine, advanced personalization, and a user-friendly console interface.

🔑 FEATURES:
• License System: Integrated token validation for access control.
• Bulk Email Sending: Send emails to thousands of recipients quickly.
• Multi-Threading: Send multiple emails concurrently for maximum speed.
• SMTP Validation: Automatically tests and filters working SMTP servers.
• Advanced Personalization: Use variables like {email}, {username}, {current_date} in your HTML content and subjects.
• Dynamic Content: Load multiple subjects and from names from files for variety.
• HTML Email Support: Send rich, formatted HTML emails.
• File Attachments: Attach files to your campaigns.
• Custom Headers: Set custom "From" email and "Reply-To" addresses.
• Proxy Support: Route traffic through SOCKS4, SOCKS5, or HTTP proxies to protect your IP.
• Detailed Logging: Tracks all sent, failed, valid, and invalid emails in real-time and saves logs to files.
• Real-Time Console Output: Beautiful, color-coded status updates using the Rich library.
• Send Types: Support for TO, CC, and BCC fields.

⚙️ PREREQUISITES:
• Python 3.7 or higher

📦 INSTALLATION:
1.  Ensure you have Python installed.
2.  Install the required libraries using pip:
    pip install requests rich pysocks or pip install -r requirements.txt

3.  Save the script as `zessen.py`.

🗂 FILE STRUCTURE:

• zessen.py - The main script.
• your-list.txt - Your list of target email addresses (one per line).
• smtp-list.txt - Your list of SMTP credentials (format: host|port|user|pass).
• your-letter.html - Your HTML email template.
• subjects.txt - (Optional) A list of subjects, one per line.
• fromnames.txt - (Optional) A list of from names, one per line.
• proxy-list.txt - (Optional) Your list of proxies (format: ip:port).

🚀 USAGE:
1.  Prepare your files:
    • `your-list.txt`: List of recipient emails.
    • `smtp-list.txt`: List of your SMTP accounts.
    • `your-letter.html`: Your HTML email template.

2.  Run the script:
    python zessen.py

3.  Follow the interactive prompts:
    • Enter your license token.
    • Enter the path to your email list (e.g., your-list.txt).
    • Enter the path to your SMTP list (e.g., smtp-list.txt).
    • Enter the subject (e.g., "Your Order") or path to a subjects file.
    • Enter the from name (e.g., "Support") or path to a fromnames file.
    • Enter the HTML file name (e.g., your-letter.html).
    • Specify an attachment (or type 'none').
    • Set a custom "From" email (or type 'none').
    • Choose send type (TO, CC, BCC).
    • Set a "Reply-To" address (or leave empty).
    • Configure proxies if needed.
    • Set the number of threads (e.g., 10-50).

4.  The script will run, displaying a live feed of sent emails and errors. Results will be saved automatically.

📝 TEMPLATE VARIABLES:
Use these variables in your `your-letter.html` file or subject line for personalization:
• {email} - The recipient's full email address.
• {username} - The part of the email before the @.
• {current_date} - The current date in the format 'Mon DD, YYYY HH:MM:SS'.

📊 OUTPUT FILES:
After running, the script generates several files:
• email_sender.log - A detailed log of all events and errors.
• valid_smtp.txt - The list of SMTP servers that successfully authenticated.
• invalid_smtp.txt - The list of SMTP servers that failed.
• smtp-list.txt - Gets overwritten with only the working SMTPs for the next run.
• sent_emails.txt - A list of all successfully sent emails.
• failed_emails.txt - A list of all emails that failed to send.
