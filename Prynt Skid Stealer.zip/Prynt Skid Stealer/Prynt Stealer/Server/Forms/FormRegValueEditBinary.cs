﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Server.Helper;
using Server.Helper.HexEditor;

namespace Server.Forms
{
	// Token: 0x02000081 RID: 129
	public partial class FormRegValueEditBinary : Form
	{
		// Token: 0x060003E7 RID: 999 RVA: 0x00004048 File Offset: 0x00002248
		public FormRegValueEditBinary(RegistrySeeker.RegValueData value)
		{
			this._value = value;
			this.InitializeComponent();
			this.valueNameTxtBox.Text = RegValueHelper.GetName(value.Name);
			this.hexEditor.HexTable = value.Data;
		}

		// Token: 0x060003E8 RID: 1000 RVA: 0x000212BC File Offset: 0x0001F4BC
		private void okButton_Click(object sender, EventArgs e)
		{
			byte[] hexTable = this.hexEditor.HexTable;
			if (hexTable != null)
			{
				try
				{
					this._value.Data = hexTable;
					base.DialogResult = DialogResult.OK;
					base.Tag = this._value;
				}
				catch
				{
					this.ShowWarning("The binary value was invalid and could not be converted correctly.", "Warning");
					base.DialogResult = DialogResult.None;
				}
			}
			base.Close();
		}

		// Token: 0x060003E9 RID: 1001 RVA: 0x00004084 File Offset: 0x00002284
		private void ShowWarning(string msg, string caption)
		{
			MessageBox.Show(msg, caption, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}

		// Token: 0x040002A0 RID: 672
		private readonly RegistrySeeker.RegValueData _value;

		// Token: 0x040002A1 RID: 673
		private const string INVALID_BINARY_ERROR = "The binary value was invalid and could not be converted correctly.";
	}
}
