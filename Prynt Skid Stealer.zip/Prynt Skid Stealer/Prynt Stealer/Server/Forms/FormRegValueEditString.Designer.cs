﻿namespace Server.Forms
{
	// Token: 0x02000086 RID: 134
	public partial class FormRegValueEditString : global::System.Windows.Forms.Form
	{
		// Token: 0x06000405 RID: 1029 RVA: 0x00004199 File Offset: 0x00002399
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x000222FC File Offset: 0x000204FC
		private void InitializeComponent()
		{
			this.cancelButton = new global::System.Windows.Forms.Button();
			this.okButton = new global::System.Windows.Forms.Button();
			this.label2 = new global::System.Windows.Forms.Label();
			this.valueNameTxtBox = new global::System.Windows.Forms.TextBox();
			this.valueDataTxtBox = new global::System.Windows.Forms.TextBox();
			this.label1 = new global::System.Windows.Forms.Label();
			base.SuspendLayout();
			this.cancelButton.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.cancelButton.DialogResult = global::System.Windows.Forms.DialogResult.Cancel;
			this.cancelButton.Location = new global::System.Drawing.Point(280, 126);
			this.cancelButton.Name = "cancelButton";
			this.cancelButton.Size = new global::System.Drawing.Size(75, 25);
			this.cancelButton.TabIndex = 7;
			this.cancelButton.Text = "Cancel";
			this.cancelButton.UseVisualStyleBackColor = true;
			this.okButton.DialogResult = global::System.Windows.Forms.DialogResult.OK;
			this.okButton.Location = new global::System.Drawing.Point(199, 126);
			this.okButton.Name = "okButton";
			this.okButton.Size = new global::System.Drawing.Size(75, 25);
			this.okButton.TabIndex = 6;
			this.okButton.Text = "OK";
			this.okButton.UseVisualStyleBackColor = true;
			this.okButton.Click += new global::System.EventHandler(this.okButton_Click);
			this.label2.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.label2.AutoSize = true;
			this.label2.Location = new global::System.Drawing.Point(9, 69);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(61, 13);
			this.label2.TabIndex = 8;
			this.label2.Text = "Value data:";
			this.label2.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.valueNameTxtBox.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.valueNameTxtBox.Location = new global::System.Drawing.Point(12, 35);
			this.valueNameTxtBox.Name = "valueNameTxtBox";
			this.valueNameTxtBox.ReadOnly = true;
			this.valueNameTxtBox.Size = new global::System.Drawing.Size(345, 20);
			this.valueNameTxtBox.TabIndex = 9;
			this.valueDataTxtBox.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.valueDataTxtBox.Location = new global::System.Drawing.Point(12, 87);
			this.valueDataTxtBox.Name = "valueDataTxtBox";
			this.valueDataTxtBox.Size = new global::System.Drawing.Size(345, 20);
			this.valueDataTxtBox.TabIndex = 5;
			this.label1.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(9, 17);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(66, 13);
			this.label1.TabIndex = 10;
			this.label1.Text = "Value name:";
			this.label1.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(369, 164);
			base.Controls.Add(this.cancelButton);
			base.Controls.Add(this.okButton);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.valueNameTxtBox);
			base.Controls.Add(this.valueDataTxtBox);
			base.Controls.Add(this.label1);
			base.Name = "FormRegValueEditString";
			this.Text = "FormRegValueEditString";
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040002C6 RID: 710
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040002C7 RID: 711
		private global::System.Windows.Forms.Button cancelButton;

		// Token: 0x040002C8 RID: 712
		private global::System.Windows.Forms.Button okButton;

		// Token: 0x040002C9 RID: 713
		private global::System.Windows.Forms.Label label2;

		// Token: 0x040002CA RID: 714
		private global::System.Windows.Forms.TextBox valueNameTxtBox;

		// Token: 0x040002CB RID: 715
		private global::System.Windows.Forms.TextBox valueDataTxtBox;

		// Token: 0x040002CC RID: 716
		private global::System.Windows.Forms.Label label1;
	}
}
