﻿namespace Server.Forms
{
	// Token: 0x02000085 RID: 133
	public partial class FormRegValueEditMultiString : global::System.Windows.Forms.Form
	{
		// Token: 0x06000401 RID: 1025 RVA: 0x00004144 File Offset: 0x00002344
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x00021EC8 File Offset: 0x000200C8
		private void InitializeComponent()
		{
			this.cancelButton = new global::System.Windows.Forms.Button();
			this.valueDataTxtBox = new global::System.Windows.Forms.TextBox();
			this.okButton = new global::System.Windows.Forms.Button();
			this.label2 = new global::System.Windows.Forms.Label();
			this.valueNameTxtBox = new global::System.Windows.Forms.TextBox();
			this.label1 = new global::System.Windows.Forms.Label();
			base.SuspendLayout();
			this.cancelButton.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.cancelButton.DialogResult = global::System.Windows.Forms.DialogResult.Cancel;
			this.cancelButton.Location = new global::System.Drawing.Point(286, 362);
			this.cancelButton.Name = "cancelButton";
			this.cancelButton.Size = new global::System.Drawing.Size(75, 25);
			this.cancelButton.TabIndex = 7;
			this.cancelButton.Text = "Cancel";
			this.cancelButton.UseVisualStyleBackColor = true;
			this.valueDataTxtBox.AcceptsReturn = true;
			this.valueDataTxtBox.Location = new global::System.Drawing.Point(15, 82);
			this.valueDataTxtBox.Multiline = true;
			this.valueDataTxtBox.Name = "valueDataTxtBox";
			this.valueDataTxtBox.ScrollBars = global::System.Windows.Forms.ScrollBars.Both;
			this.valueDataTxtBox.Size = new global::System.Drawing.Size(346, 273);
			this.valueDataTxtBox.TabIndex = 5;
			this.valueDataTxtBox.WordWrap = false;
			this.okButton.DialogResult = global::System.Windows.Forms.DialogResult.OK;
			this.okButton.Location = new global::System.Drawing.Point(205, 362);
			this.okButton.Name = "okButton";
			this.okButton.Size = new global::System.Drawing.Size(75, 25);
			this.okButton.TabIndex = 6;
			this.okButton.Text = "OK";
			this.okButton.UseVisualStyleBackColor = true;
			this.okButton.Click += new global::System.EventHandler(this.okButton_Click);
			this.label2.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.label2.AutoSize = true;
			this.label2.Location = new global::System.Drawing.Point(12, 62);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(61, 13);
			this.label2.TabIndex = 8;
			this.label2.Text = "Value data:";
			this.label2.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.valueNameTxtBox.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.valueNameTxtBox.Location = new global::System.Drawing.Point(15, 31);
			this.valueNameTxtBox.Name = "valueNameTxtBox";
			this.valueNameTxtBox.ReadOnly = true;
			this.valueNameTxtBox.Size = new global::System.Drawing.Size(346, 20);
			this.valueNameTxtBox.TabIndex = 9;
			this.label1.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(12, 14);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(66, 13);
			this.label1.TabIndex = 10;
			this.label1.Text = "Value name:";
			this.label1.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(379, 402);
			base.Controls.Add(this.cancelButton);
			base.Controls.Add(this.valueDataTxtBox);
			base.Controls.Add(this.okButton);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.valueNameTxtBox);
			base.Controls.Add(this.label1);
			base.Name = "FormRegValueEditMultiString";
			this.Text = "FormRegValueEditMultiString";
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040002BE RID: 702
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040002BF RID: 703
		private global::System.Windows.Forms.Button cancelButton;

		// Token: 0x040002C0 RID: 704
		private global::System.Windows.Forms.TextBox valueDataTxtBox;

		// Token: 0x040002C1 RID: 705
		private global::System.Windows.Forms.Button okButton;

		// Token: 0x040002C2 RID: 706
		private global::System.Windows.Forms.Label label2;

		// Token: 0x040002C3 RID: 707
		private global::System.Windows.Forms.TextBox valueNameTxtBox;

		// Token: 0x040002C4 RID: 708
		private global::System.Windows.Forms.Label label1;
	}
}
