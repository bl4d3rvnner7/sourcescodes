﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Bunifu.UI.WinForms;
using Server.Properties;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Enums;

namespace Server.Forms
{
	// Token: 0x0200008B RID: 139
	public partial class FormBlockClients : Form
	{
		// Token: 0x06000426 RID: 1062 RVA: 0x000042E1 File Offset: 0x000024E1
		public FormBlockClients()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x000248FC File Offset: 0x00022AFC
		private void BtnAdd_Click(object sender, EventArgs e)
		{
			try
			{
				this.listBlocked.Items.Add(this.txtBlock.Text);
				this.txtBlock.Clear();
			}
			catch
			{
			}
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x00024948 File Offset: 0x00022B48
		private void BtnDelete_Click(object sender, EventArgs e)
		{
			try
			{
				for (int i = this.listBlocked.SelectedIndices.Count - 1; i >= 0; i--)
				{
					this.listBlocked.Items.RemoveAt(this.listBlocked.SelectedIndices[i]);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000429 RID: 1065 RVA: 0x000249A8 File Offset: 0x00022BA8
		private void FormBlockClients_Load(object sender, EventArgs e)
		{
			try
			{
				this.listBlocked.Items.Clear();
				if (!string.IsNullOrWhiteSpace(Settings.Default.txtBlocked))
				{
					foreach (string text in Settings.Default.txtBlocked.Split(new char[]
					{
						','
					}))
					{
						if (!string.IsNullOrWhiteSpace(text))
						{
							this.listBlocked.Items.Add(text);
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600042A RID: 1066 RVA: 0x00024A34 File Offset: 0x00022C34
		private void FormBlockClients_FormClosed(object sender, FormClosedEventArgs e)
		{
			try
			{
				List<string> blocked = Settings.Blocked;
				lock (blocked)
				{
					Settings.Blocked.Clear();
					List<string> list = new List<string>();
					foreach (object obj in this.listBlocked.Items)
					{
						string item = (string)obj;
						list.Add(item);
						Settings.Blocked.Add(item);
					}
					Settings.Default.txtBlocked = string.Join(",", list);
					Settings.Default.Save();
				}
			}
			catch
			{
			}
		}
	}
}
