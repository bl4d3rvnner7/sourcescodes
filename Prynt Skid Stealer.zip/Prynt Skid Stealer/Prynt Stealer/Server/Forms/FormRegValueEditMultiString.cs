﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Server.Helper;

namespace Server.Forms
{
	// Token: 0x02000085 RID: 133
	public partial class FormRegValueEditMultiString : Form
	{
		// Token: 0x060003FF RID: 1023 RVA: 0x00021E1C File Offset: 0x0002001C
		public FormRegValueEditMultiString(RegistrySeeker.RegValueData value)
		{
			this._value = value;
			this.InitializeComponent();
			this.valueNameTxtBox.Text = value.Name;
			this.valueDataTxtBox.Text = string.Join("\r\n", Server.Helper.ByteConverter.ToStringArray(value.Data));
		}

		// Token: 0x06000400 RID: 1024 RVA: 0x00021E70 File Offset: 0x00020070
		private void okButton_Click(object sender, EventArgs e)
		{
			this._value.Data = Server.Helper.ByteConverter.GetBytes(this.valueDataTxtBox.Text.Split(new string[]
			{
				"\r\n"
			}, StringSplitOptions.RemoveEmptyEntries));
			base.Tag = this._value;
			base.DialogResult = DialogResult.OK;
			base.Close();
		}

		// Token: 0x040002BD RID: 701
		private readonly RegistrySeeker.RegValueData _value;
	}
}
