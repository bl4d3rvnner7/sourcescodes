﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Siticone.UI.AnimatorNS;
using Siticone.UI.WinForms;

namespace Server.Forms
{
	// Token: 0x0200007F RID: 127
	public partial class Form2 : Form
	{
		// Token: 0x060003C0 RID: 960 RVA: 0x00003F8A File Offset: 0x0000218A
		public Form2()
		{
			this.InitializeComponent();
		}

		// Token: 0x060003C1 RID: 961 RVA: 0x00006BF0 File Offset: 0x00004DF0
		public DateTime UnixTimeToDateTime(long unixtime)
		{
			DateTime result = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Local);
			result = result.AddSeconds((double)unixtime).ToLocalTime();
			return result;
		}

		// Token: 0x060003C2 RID: 962 RVA: 0x0001DE64 File Offset: 0x0001C064
		private void Form2_Load(object sender, EventArgs e)
		{
			Login.KeyAuthApp.check();
			this.siticoneLabel1.Text = string.Format("Current Session Validation Status: {0}", Login.KeyAuthApp.response.success);
			this.key.Text = "Username: " + Login.KeyAuthApp.user_data.username;
			this.expiry.Text = "Expiry: " + this.UnixTimeToDateTime(long.Parse(Login.KeyAuthApp.user_data.subscriptions[0].expiry)).ToString();
			this.subscription.Text = "Subscription: " + Login.KeyAuthApp.user_data.subscriptions[0].subscription;
			this.ip.Text = "IP Address: " + Login.KeyAuthApp.user_data.ip;
			this.hwid.Text = "HWID: " + Login.KeyAuthApp.user_data.hwid;
			this.createDate.Text = "Creation date: " + this.UnixTimeToDateTime(long.Parse(Login.KeyAuthApp.user_data.createdate)).ToString();
			this.lastLogin.Text = "Last login: " + this.UnixTimeToDateTime(long.Parse(Login.KeyAuthApp.user_data.lastlogin)).ToString();
			this.subscriptionDaysLabel.Text = "Expiry in Days: " + Login.KeyAuthApp.expirydaysleft();
			this.numUsers.Text = "Number of users: " + Login.KeyAuthApp.app_data.numUsers;
			this.numOnlineUsers.Text = "Number of online users: " + Login.KeyAuthApp.app_data.numOnlineUsers;
			this.numKeys.Text = "Number of licenses: " + Login.KeyAuthApp.app_data.numKeys;
			this.version.Text = "Current version: " + Login.KeyAuthApp.app_data.version;
			this.customerPanelLink.Text = "Customer panel: " + Login.KeyAuthApp.app_data.customerPanelLink;
		}

		// Token: 0x060003C3 RID: 963 RVA: 0x0001E0C4 File Offset: 0x0001C2C4
		private void sendmsg_Click(object sender, EventArgs e)
		{
			if (Login.KeyAuthApp.chatsend(this.chatmsg.Text, this.chatchannel))
			{
				this.dataGridView1.Rows.Insert(0, new object[]
				{
					Login.KeyAuthApp.user_data.username,
					this.chatmsg.Text,
					this.UnixTimeToDateTime(DateTimeOffset.Now.ToUnixTimeSeconds())
				});
				return;
			}
			this.chatmsg.Text = "Status: " + Login.KeyAuthApp.response.message;
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x0001E168 File Offset: 0x0001C368
		private void timer1_Tick(object sender, EventArgs e)
		{
			this.dataGridView1.Rows.Clear();
			this.timer1.Interval = 15000;
			if (!string.IsNullOrEmpty(this.chatchannel))
			{
				List<api.msg> list = Login.KeyAuthApp.chatget(this.chatchannel);
				if (list == null || !list.Any<api.msg>())
				{
					this.dataGridView1.Rows.Insert(0, new object[]
					{
						"Prynt Stealer",
						"No Chat Messages",
						this.UnixTimeToDateTime(DateTimeOffset.Now.ToUnixTimeSeconds())
					});
					return;
				}
				using (List<api.msg>.Enumerator enumerator = list.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						api.msg msg = enumerator.Current;
						this.dataGridView1.Rows.Insert(0, new object[]
						{
							msg.author,
							msg.message,
							this.UnixTimeToDateTime(long.Parse(msg.timestamp))
						});
					}
					return;
				}
			}
			this.dataGridView1.Rows.Insert(0, new object[]
			{
				"Prynt Stealer",
				"No Chat Messages",
				this.UnixTimeToDateTime(DateTimeOffset.Now.ToUnixTimeSeconds())
			});
		}

		// Token: 0x0400025F RID: 607
		private string chatchannel = "PryntChat";
	}
}
