﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Net.Sockets;
using System.Windows.Forms;
using Server.Connection;
using Server.Helper;

namespace Server.Forms
{
	// Token: 0x0200009C RID: 156
	public partial class FormDownloadFile : Form
	{
		// Token: 0x170000DA RID: 218
		// (get) Token: 0x060004D1 RID: 1233 RVA: 0x00004883 File Offset: 0x00002A83
		// (set) Token: 0x060004D2 RID: 1234 RVA: 0x0000488B File Offset: 0x00002A8B
		public Form1 F { get; set; }

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x060004D3 RID: 1235 RVA: 0x00004894 File Offset: 0x00002A94
		// (set) Token: 0x060004D4 RID: 1236 RVA: 0x0000489C File Offset: 0x00002A9C
		internal Clients Client { get; set; }

		// Token: 0x060004D5 RID: 1237 RVA: 0x000048A5 File Offset: 0x00002AA5
		public FormDownloadFile()
		{
			this.InitializeComponent();
		}

		// Token: 0x060004D6 RID: 1238 RVA: 0x00030F44 File Offset: 0x0002F144
		private void timer1_Tick(object sender, EventArgs e)
		{
			if (this.FileSize >= 2147483647L)
			{
				this.timer1.Stop();
				MessageBox.Show("Don't support files larger than 2GB.");
				base.Dispose();
				return;
			}
			if (!this.IsUpload)
			{
				this.labelsize.Text = Methods.BytesToString(this.FileSize) + " \\ " + Methods.BytesToString(this.Client.BytesRecevied);
				if (this.Client.BytesRecevied >= this.FileSize)
				{
					this.labelsize.Text = "Downloaded";
					this.labelsize.ForeColor = Color.Green;
					this.timer1.Stop();
					return;
				}
			}
			else
			{
				this.labelsize.Text = Methods.BytesToString(this.FileSize) + " \\ " + Methods.BytesToString(this.BytesSent);
				if (this.BytesSent >= this.FileSize)
				{
					this.labelsize.Text = "Uploaded";
					this.labelsize.ForeColor = Color.Green;
					this.timer1.Stop();
				}
			}
		}

		// Token: 0x060004D7 RID: 1239 RVA: 0x0003105C File Offset: 0x0002F25C
		private void SocketDownload_FormClosed(object sender, FormClosedEventArgs e)
		{
			try
			{
				Clients client = this.Client;
				if (client != null)
				{
					client.Disconnected();
				}
				Timer timer = this.timer1;
				if (timer != null)
				{
					timer.Dispose();
				}
			}
			catch
			{
			}
		}

		// Token: 0x060004D8 RID: 1240 RVA: 0x000310A0 File Offset: 0x0002F2A0
		public void Send(object obj)
		{
			object sendSync = this.Client.SendSync;
			lock (sendSync)
			{
				try
				{
					this.IsUpload = true;
					byte[] array = (byte[])obj;
					byte[] bytes = BitConverter.GetBytes(array.Length);
					this.Client.TcpClient.Poll(-1, SelectMode.SelectWrite);
					this.Client.SslClient.Write(bytes, 0, bytes.Length);
					using (MemoryStream memoryStream = new MemoryStream(array))
					{
						memoryStream.Position = 0L;
						byte[] array2 = new byte[50000];
						int num;
						while ((num = memoryStream.Read(array2, 0, array2.Length)) > 0)
						{
							this.Client.TcpClient.Poll(-1, SelectMode.SelectWrite);
							this.Client.SslClient.Write(array2, 0, num);
							this.BytesSent += (long)num;
						}
					}
					Program.form1.BeginInvoke(new MethodInvoker(delegate()
					{
						base.Close();
					}));
				}
				catch
				{
					Clients client = this.Client;
					if (client != null)
					{
						client.Disconnected();
					}
					Program.form1.BeginInvoke(new MethodInvoker(delegate()
					{
						this.labelsize.Text = "Error";
						this.labelsize.ForeColor = Color.Red;
					}));
				}
			}
		}

		// Token: 0x040003FF RID: 1023
		public long FileSize;

		// Token: 0x04000400 RID: 1024
		private long BytesSent;

		// Token: 0x04000401 RID: 1025
		public string FullFileName;

		// Token: 0x04000402 RID: 1026
		public string ClientFullFileName;

		// Token: 0x04000403 RID: 1027
		private bool IsUpload;

		// Token: 0x04000404 RID: 1028
		public string DirPath;
	}
}
