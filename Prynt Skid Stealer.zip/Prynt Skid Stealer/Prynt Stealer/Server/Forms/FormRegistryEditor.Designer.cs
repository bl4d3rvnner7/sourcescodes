﻿namespace Server.Forms
{
	// Token: 0x0200009F RID: 159
	public partial class FormRegistryEditor : global::System.Windows.Forms.Form
	{
		// Token: 0x06000534 RID: 1332 RVA: 0x00004C08 File Offset: 0x00002E08
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000535 RID: 1333 RVA: 0x000339AC File Offset: 0x00031BAC
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Server.Forms.FormRegistryEditor));
			this.tableLayoutPanel = new global::System.Windows.Forms.TableLayoutPanel();
			this.splitContainer = new global::System.Windows.Forms.SplitContainer();
			this.tvRegistryDirectory = new global::Server.Helper.RegistryTreeView();
			this.imageRegistryDirectoryList = new global::System.Windows.Forms.ImageList(this.components);
			this.lstRegistryValues = new global::Server.Helper.AeroListView();
			this.hName = new global::System.Windows.Forms.ColumnHeader();
			this.hType = new global::System.Windows.Forms.ColumnHeader();
			this.hValue = new global::System.Windows.Forms.ColumnHeader();
			this.imageRegistryKeyTypeList = new global::System.Windows.Forms.ImageList(this.components);
			this.statusStrip = new global::System.Windows.Forms.StatusStrip();
			this.selectedStripStatusLabel = new global::System.Windows.Forms.ToolStripStatusLabel();
			this.menuStrip = new global::System.Windows.Forms.MenuStrip();
			this.fileToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.exitToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.editToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.modifyToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.modifyBinaryDataToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.modifyNewtoolStripSeparator = new global::System.Windows.Forms.ToolStripSeparator();
			this.newToolStripMenuItem2 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.keyToolStripMenuItem2 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator7 = new global::System.Windows.Forms.ToolStripSeparator();
			this.stringValueToolStripMenuItem2 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.binaryValueToolStripMenuItem2 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.dWORD32bitValueToolStripMenuItem2 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.qWORD64bitValueToolStripMenuItem2 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.multiStringValueToolStripMenuItem2 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.expandableStringValueToolStripMenuItem2 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator6 = new global::System.Windows.Forms.ToolStripSeparator();
			this.deleteToolStripMenuItem2 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.renameToolStripMenuItem2 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.tv_ContextMenuStrip = new global::System.Windows.Forms.ContextMenuStrip(this.components);
			this.newToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.keyToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator2 = new global::System.Windows.Forms.ToolStripSeparator();
			this.stringValueToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.binaryValueToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.dWORD32bitValueToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.qWORD64bitValueToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.multiStringValueToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.expandableStringValueToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator1 = new global::System.Windows.Forms.ToolStripSeparator();
			this.deleteToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.renameToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.selectedItem_ContextMenuStrip = new global::System.Windows.Forms.ContextMenuStrip(this.components);
			this.modifyToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.modifyBinaryDataToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.modifyToolStripSeparator1 = new global::System.Windows.Forms.ToolStripSeparator();
			this.deleteToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.renameToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.lst_ContextMenuStrip = new global::System.Windows.Forms.ContextMenuStrip(this.components);
			this.newToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.keyToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator4 = new global::System.Windows.Forms.ToolStripSeparator();
			this.stringValueToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.binaryValueToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.dWORD32bitValueToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.qWORD64bitValueToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.multiStringValueToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.expandableStringValueToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.tableLayoutPanel.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer).BeginInit();
			this.splitContainer.Panel1.SuspendLayout();
			this.splitContainer.Panel2.SuspendLayout();
			this.splitContainer.SuspendLayout();
			this.statusStrip.SuspendLayout();
			this.menuStrip.SuspendLayout();
			this.tv_ContextMenuStrip.SuspendLayout();
			this.selectedItem_ContextMenuStrip.SuspendLayout();
			this.lst_ContextMenuStrip.SuspendLayout();
			base.SuspendLayout();
			this.tableLayoutPanel.ColumnCount = 1;
			this.tableLayoutPanel.ColumnStyles.Add(new global::System.Windows.Forms.ColumnStyle(global::System.Windows.Forms.SizeType.Percent, 100f));
			this.tableLayoutPanel.Controls.Add(this.splitContainer, 0, 1);
			this.tableLayoutPanel.Controls.Add(this.statusStrip, 0, 2);
			this.tableLayoutPanel.Controls.Add(this.menuStrip, 0, 0);
			this.tableLayoutPanel.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel.GrowStyle = global::System.Windows.Forms.TableLayoutPanelGrowStyle.FixedSize;
			this.tableLayoutPanel.Location = new global::System.Drawing.Point(0, 0);
			this.tableLayoutPanel.Name = "tableLayoutPanel";
			this.tableLayoutPanel.RowCount = 3;
			this.tableLayoutPanel.RowStyles.Add(new global::System.Windows.Forms.RowStyle(global::System.Windows.Forms.SizeType.Absolute, 25f));
			this.tableLayoutPanel.RowStyles.Add(new global::System.Windows.Forms.RowStyle(global::System.Windows.Forms.SizeType.Percent, 100f));
			this.tableLayoutPanel.RowStyles.Add(new global::System.Windows.Forms.RowStyle(global::System.Windows.Forms.SizeType.Absolute, 22f));
			this.tableLayoutPanel.Size = new global::System.Drawing.Size(784, 561);
			this.tableLayoutPanel.TabIndex = 0;
			this.splitContainer.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.splitContainer.Location = new global::System.Drawing.Point(3, 28);
			this.splitContainer.Name = "splitContainer";
			this.splitContainer.Panel1.Controls.Add(this.tvRegistryDirectory);
			this.splitContainer.Panel2.Controls.Add(this.lstRegistryValues);
			this.splitContainer.Size = new global::System.Drawing.Size(778, 508);
			this.splitContainer.SplitterDistance = 259;
			this.splitContainer.TabIndex = 0;
			this.tvRegistryDirectory.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.tvRegistryDirectory.HideSelection = false;
			this.tvRegistryDirectory.ImageIndex = 0;
			this.tvRegistryDirectory.ImageList = this.imageRegistryDirectoryList;
			this.tvRegistryDirectory.Location = new global::System.Drawing.Point(0, 0);
			this.tvRegistryDirectory.Name = "tvRegistryDirectory";
			this.tvRegistryDirectory.SelectedImageIndex = 0;
			this.tvRegistryDirectory.Size = new global::System.Drawing.Size(259, 508);
			this.tvRegistryDirectory.TabIndex = 0;
			this.tvRegistryDirectory.AfterLabelEdit += new global::System.Windows.Forms.NodeLabelEditEventHandler(this.tvRegistryDirectory_AfterLabelEdit);
			this.tvRegistryDirectory.BeforeExpand += new global::System.Windows.Forms.TreeViewCancelEventHandler(this.tvRegistryDirectory_BeforeExpand);
			this.tvRegistryDirectory.BeforeSelect += new global::System.Windows.Forms.TreeViewCancelEventHandler(this.tvRegistryDirectory_BeforeSelect);
			this.tvRegistryDirectory.NodeMouseClick += new global::System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvRegistryDirectory_NodeMouseClick);
			this.tvRegistryDirectory.KeyUp += new global::System.Windows.Forms.KeyEventHandler(this.tvRegistryDirectory_KeyUp);
			this.imageRegistryDirectoryList.ImageStream = (global::System.Windows.Forms.ImageListStreamer)componentResourceManager.GetObject("imageRegistryDirectoryList.ImageStream");
			this.imageRegistryDirectoryList.TransparentColor = global::System.Drawing.Color.Transparent;
			this.imageRegistryDirectoryList.Images.SetKeyName(0, "folder.png");
			this.lstRegistryValues.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
			{
				this.hName,
				this.hType,
				this.hValue
			});
			this.lstRegistryValues.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.lstRegistryValues.FullRowSelect = true;
			this.lstRegistryValues.HeaderStyle = global::System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.lstRegistryValues.HideSelection = false;
			this.lstRegistryValues.Location = new global::System.Drawing.Point(0, 0);
			this.lstRegistryValues.Name = "lstRegistryValues";
			this.lstRegistryValues.Size = new global::System.Drawing.Size(515, 508);
			this.lstRegistryValues.SmallImageList = this.imageRegistryKeyTypeList;
			this.lstRegistryValues.TabIndex = 0;
			this.lstRegistryValues.UseCompatibleStateImageBehavior = false;
			this.lstRegistryValues.View = global::System.Windows.Forms.View.Details;
			this.lstRegistryValues.AfterLabelEdit += new global::System.Windows.Forms.LabelEditEventHandler(this.lstRegistryKeys_AfterLabelEdit);
			this.lstRegistryValues.KeyUp += new global::System.Windows.Forms.KeyEventHandler(this.lstRegistryKeys_KeyUp);
			this.lstRegistryValues.MouseUp += new global::System.Windows.Forms.MouseEventHandler(this.lstRegistryKeys_MouseClick);
			this.hName.Text = "Name";
			this.hName.Width = 173;
			this.hType.Text = "Type";
			this.hType.Width = 104;
			this.hValue.Text = "Value";
			this.hValue.Width = 214;
			this.imageRegistryKeyTypeList.ImageStream = (global::System.Windows.Forms.ImageListStreamer)componentResourceManager.GetObject("imageRegistryKeyTypeList.ImageStream");
			this.imageRegistryKeyTypeList.TransparentColor = global::System.Drawing.Color.Transparent;
			this.imageRegistryKeyTypeList.Images.SetKeyName(0, "reg_string.png");
			this.imageRegistryKeyTypeList.Images.SetKeyName(1, "reg_binary.png");
			this.statusStrip.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.statusStrip.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.selectedStripStatusLabel
			});
			this.statusStrip.Location = new global::System.Drawing.Point(0, 539);
			this.statusStrip.Name = "statusStrip";
			this.statusStrip.Size = new global::System.Drawing.Size(784, 22);
			this.statusStrip.TabIndex = 1;
			this.statusStrip.Text = "statusStrip";
			this.selectedStripStatusLabel.Name = "selectedStripStatusLabel";
			this.selectedStripStatusLabel.Size = new global::System.Drawing.Size(0, 17);
			this.menuStrip.Dock = global::System.Windows.Forms.DockStyle.None;
			this.menuStrip.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.fileToolStripMenuItem,
				this.editToolStripMenuItem
			});
			this.menuStrip.Location = new global::System.Drawing.Point(0, 0);
			this.menuStrip.Name = "menuStrip";
			this.menuStrip.Size = new global::System.Drawing.Size(84, 24);
			this.menuStrip.TabIndex = 2;
			this.fileToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.exitToolStripMenuItem
			});
			this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
			this.fileToolStripMenuItem.Size = new global::System.Drawing.Size(37, 20);
			this.fileToolStripMenuItem.Text = "File";
			this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
			this.exitToolStripMenuItem.Size = new global::System.Drawing.Size(93, 22);
			this.exitToolStripMenuItem.Text = "Exit";
			this.exitToolStripMenuItem.Click += new global::System.EventHandler(this.menuStripExit_Click);
			this.editToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.modifyToolStripMenuItem1,
				this.modifyBinaryDataToolStripMenuItem1,
				this.modifyNewtoolStripSeparator,
				this.newToolStripMenuItem2,
				this.toolStripSeparator6,
				this.deleteToolStripMenuItem2,
				this.renameToolStripMenuItem2
			});
			this.editToolStripMenuItem.Name = "editToolStripMenuItem";
			this.editToolStripMenuItem.Size = new global::System.Drawing.Size(39, 20);
			this.editToolStripMenuItem.Text = "Edit";
			this.editToolStripMenuItem.DropDownOpening += new global::System.EventHandler(this.editToolStripMenuItem_DropDownOpening);
			this.modifyToolStripMenuItem1.Enabled = false;
			this.modifyToolStripMenuItem1.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.modifyToolStripMenuItem1.Name = "modifyToolStripMenuItem1";
			this.modifyToolStripMenuItem1.Size = new global::System.Drawing.Size(184, 22);
			this.modifyToolStripMenuItem1.Text = "Modify...";
			this.modifyToolStripMenuItem1.Visible = false;
			this.modifyToolStripMenuItem1.Click += new global::System.EventHandler(this.modifyRegistryValue_Click);
			this.modifyBinaryDataToolStripMenuItem1.Enabled = false;
			this.modifyBinaryDataToolStripMenuItem1.Name = "modifyBinaryDataToolStripMenuItem1";
			this.modifyBinaryDataToolStripMenuItem1.Size = new global::System.Drawing.Size(184, 22);
			this.modifyBinaryDataToolStripMenuItem1.Text = "Modify Binary Data...";
			this.modifyBinaryDataToolStripMenuItem1.Visible = false;
			this.modifyBinaryDataToolStripMenuItem1.Click += new global::System.EventHandler(this.modifyBinaryDataRegistryValue_Click);
			this.modifyNewtoolStripSeparator.Name = "modifyNewtoolStripSeparator";
			this.modifyNewtoolStripSeparator.Size = new global::System.Drawing.Size(181, 6);
			this.modifyNewtoolStripSeparator.Visible = false;
			this.newToolStripMenuItem2.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.keyToolStripMenuItem2,
				this.toolStripSeparator7,
				this.stringValueToolStripMenuItem2,
				this.binaryValueToolStripMenuItem2,
				this.dWORD32bitValueToolStripMenuItem2,
				this.qWORD64bitValueToolStripMenuItem2,
				this.multiStringValueToolStripMenuItem2,
				this.expandableStringValueToolStripMenuItem2
			});
			this.newToolStripMenuItem2.Name = "newToolStripMenuItem2";
			this.newToolStripMenuItem2.Size = new global::System.Drawing.Size(184, 22);
			this.newToolStripMenuItem2.Text = "New";
			this.keyToolStripMenuItem2.Name = "keyToolStripMenuItem2";
			this.keyToolStripMenuItem2.Size = new global::System.Drawing.Size(200, 22);
			this.keyToolStripMenuItem2.Text = "Key";
			this.keyToolStripMenuItem2.Click += new global::System.EventHandler(this.createNewRegistryKey_Click);
			this.toolStripSeparator7.Name = "toolStripSeparator7";
			this.toolStripSeparator7.Size = new global::System.Drawing.Size(197, 6);
			this.stringValueToolStripMenuItem2.Name = "stringValueToolStripMenuItem2";
			this.stringValueToolStripMenuItem2.Size = new global::System.Drawing.Size(200, 22);
			this.stringValueToolStripMenuItem2.Text = "String Value";
			this.stringValueToolStripMenuItem2.Click += new global::System.EventHandler(this.createStringRegistryValue_Click);
			this.binaryValueToolStripMenuItem2.Name = "binaryValueToolStripMenuItem2";
			this.binaryValueToolStripMenuItem2.Size = new global::System.Drawing.Size(200, 22);
			this.binaryValueToolStripMenuItem2.Text = "Binary Value";
			this.binaryValueToolStripMenuItem2.Click += new global::System.EventHandler(this.createBinaryRegistryValue_Click);
			this.dWORD32bitValueToolStripMenuItem2.Name = "dWORD32bitValueToolStripMenuItem2";
			this.dWORD32bitValueToolStripMenuItem2.Size = new global::System.Drawing.Size(200, 22);
			this.dWORD32bitValueToolStripMenuItem2.Text = "DWORD (32-bit) Value";
			this.dWORD32bitValueToolStripMenuItem2.Click += new global::System.EventHandler(this.createDwordRegistryValue_Click);
			this.qWORD64bitValueToolStripMenuItem2.Name = "qWORD64bitValueToolStripMenuItem2";
			this.qWORD64bitValueToolStripMenuItem2.Size = new global::System.Drawing.Size(200, 22);
			this.qWORD64bitValueToolStripMenuItem2.Text = "QWORD (64-bit) Value";
			this.qWORD64bitValueToolStripMenuItem2.Click += new global::System.EventHandler(this.createQwordRegistryValue_Click);
			this.multiStringValueToolStripMenuItem2.Name = "multiStringValueToolStripMenuItem2";
			this.multiStringValueToolStripMenuItem2.Size = new global::System.Drawing.Size(200, 22);
			this.multiStringValueToolStripMenuItem2.Text = "Multi-String Value";
			this.multiStringValueToolStripMenuItem2.Click += new global::System.EventHandler(this.createMultiStringRegistryValue_Click);
			this.expandableStringValueToolStripMenuItem2.Name = "expandableStringValueToolStripMenuItem2";
			this.expandableStringValueToolStripMenuItem2.Size = new global::System.Drawing.Size(200, 22);
			this.expandableStringValueToolStripMenuItem2.Text = "Expandable String Value";
			this.expandableStringValueToolStripMenuItem2.Click += new global::System.EventHandler(this.createExpandStringRegistryValue_Click);
			this.toolStripSeparator6.Name = "toolStripSeparator6";
			this.toolStripSeparator6.Size = new global::System.Drawing.Size(181, 6);
			this.deleteToolStripMenuItem2.Enabled = false;
			this.deleteToolStripMenuItem2.Name = "deleteToolStripMenuItem2";
			this.deleteToolStripMenuItem2.ShortcutKeyDisplayString = "Del";
			this.deleteToolStripMenuItem2.Size = new global::System.Drawing.Size(184, 22);
			this.deleteToolStripMenuItem2.Text = "Delete";
			this.deleteToolStripMenuItem2.Click += new global::System.EventHandler(this.menuStripDelete_Click);
			this.renameToolStripMenuItem2.Enabled = false;
			this.renameToolStripMenuItem2.Name = "renameToolStripMenuItem2";
			this.renameToolStripMenuItem2.Size = new global::System.Drawing.Size(184, 22);
			this.renameToolStripMenuItem2.Text = "Rename";
			this.renameToolStripMenuItem2.Click += new global::System.EventHandler(this.menuStripRename_Click);
			this.tv_ContextMenuStrip.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.newToolStripMenuItem,
				this.toolStripSeparator1,
				this.deleteToolStripMenuItem,
				this.renameToolStripMenuItem
			});
			this.tv_ContextMenuStrip.Name = "contextMenuStrip";
			this.tv_ContextMenuStrip.Size = new global::System.Drawing.Size(118, 76);
			this.newToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.keyToolStripMenuItem,
				this.toolStripSeparator2,
				this.stringValueToolStripMenuItem,
				this.binaryValueToolStripMenuItem,
				this.dWORD32bitValueToolStripMenuItem,
				this.qWORD64bitValueToolStripMenuItem,
				this.multiStringValueToolStripMenuItem,
				this.expandableStringValueToolStripMenuItem
			});
			this.newToolStripMenuItem.Name = "newToolStripMenuItem";
			this.newToolStripMenuItem.Size = new global::System.Drawing.Size(117, 22);
			this.newToolStripMenuItem.Text = "New";
			this.keyToolStripMenuItem.Name = "keyToolStripMenuItem";
			this.keyToolStripMenuItem.Size = new global::System.Drawing.Size(200, 22);
			this.keyToolStripMenuItem.Text = "Key";
			this.keyToolStripMenuItem.Click += new global::System.EventHandler(this.createNewRegistryKey_Click);
			this.toolStripSeparator2.Name = "toolStripSeparator2";
			this.toolStripSeparator2.Size = new global::System.Drawing.Size(197, 6);
			this.stringValueToolStripMenuItem.Name = "stringValueToolStripMenuItem";
			this.stringValueToolStripMenuItem.Size = new global::System.Drawing.Size(200, 22);
			this.stringValueToolStripMenuItem.Text = "String Value";
			this.stringValueToolStripMenuItem.Click += new global::System.EventHandler(this.createStringRegistryValue_Click);
			this.binaryValueToolStripMenuItem.Name = "binaryValueToolStripMenuItem";
			this.binaryValueToolStripMenuItem.Size = new global::System.Drawing.Size(200, 22);
			this.binaryValueToolStripMenuItem.Text = "Binary Value";
			this.binaryValueToolStripMenuItem.Click += new global::System.EventHandler(this.createBinaryRegistryValue_Click);
			this.dWORD32bitValueToolStripMenuItem.Name = "dWORD32bitValueToolStripMenuItem";
			this.dWORD32bitValueToolStripMenuItem.Size = new global::System.Drawing.Size(200, 22);
			this.dWORD32bitValueToolStripMenuItem.Text = "DWORD (32-bit) Value";
			this.dWORD32bitValueToolStripMenuItem.Click += new global::System.EventHandler(this.createDwordRegistryValue_Click);
			this.qWORD64bitValueToolStripMenuItem.Name = "qWORD64bitValueToolStripMenuItem";
			this.qWORD64bitValueToolStripMenuItem.Size = new global::System.Drawing.Size(200, 22);
			this.qWORD64bitValueToolStripMenuItem.Text = "QWORD (64-bit) Value";
			this.qWORD64bitValueToolStripMenuItem.Click += new global::System.EventHandler(this.createQwordRegistryValue_Click);
			this.multiStringValueToolStripMenuItem.Name = "multiStringValueToolStripMenuItem";
			this.multiStringValueToolStripMenuItem.Size = new global::System.Drawing.Size(200, 22);
			this.multiStringValueToolStripMenuItem.Text = "Multi-String Value";
			this.multiStringValueToolStripMenuItem.Click += new global::System.EventHandler(this.createMultiStringRegistryValue_Click);
			this.expandableStringValueToolStripMenuItem.Name = "expandableStringValueToolStripMenuItem";
			this.expandableStringValueToolStripMenuItem.Size = new global::System.Drawing.Size(200, 22);
			this.expandableStringValueToolStripMenuItem.Text = "Expandable String Value";
			this.expandableStringValueToolStripMenuItem.Click += new global::System.EventHandler(this.createExpandStringRegistryValue_Click);
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new global::System.Drawing.Size(114, 6);
			this.deleteToolStripMenuItem.Enabled = false;
			this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
			this.deleteToolStripMenuItem.Size = new global::System.Drawing.Size(117, 22);
			this.deleteToolStripMenuItem.Text = "Delete";
			this.deleteToolStripMenuItem.Click += new global::System.EventHandler(this.deleteRegistryKey_Click);
			this.renameToolStripMenuItem.Enabled = false;
			this.renameToolStripMenuItem.Name = "renameToolStripMenuItem";
			this.renameToolStripMenuItem.Size = new global::System.Drawing.Size(117, 22);
			this.renameToolStripMenuItem.Text = "Rename";
			this.renameToolStripMenuItem.Click += new global::System.EventHandler(this.renameRegistryKey_Click);
			this.selectedItem_ContextMenuStrip.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.modifyToolStripMenuItem,
				this.modifyBinaryDataToolStripMenuItem,
				this.modifyToolStripSeparator1,
				this.deleteToolStripMenuItem1,
				this.renameToolStripMenuItem1
			});
			this.selectedItem_ContextMenuStrip.Name = "selectedItem_ContextMenuStrip";
			this.selectedItem_ContextMenuStrip.Size = new global::System.Drawing.Size(185, 98);
			this.modifyToolStripMenuItem.Enabled = false;
			this.modifyToolStripMenuItem.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.modifyToolStripMenuItem.Name = "modifyToolStripMenuItem";
			this.modifyToolStripMenuItem.Size = new global::System.Drawing.Size(184, 22);
			this.modifyToolStripMenuItem.Text = "Modify...";
			this.modifyToolStripMenuItem.Click += new global::System.EventHandler(this.modifyRegistryValue_Click);
			this.modifyBinaryDataToolStripMenuItem.Enabled = false;
			this.modifyBinaryDataToolStripMenuItem.Name = "modifyBinaryDataToolStripMenuItem";
			this.modifyBinaryDataToolStripMenuItem.Size = new global::System.Drawing.Size(184, 22);
			this.modifyBinaryDataToolStripMenuItem.Text = "Modify Binary Data...";
			this.modifyBinaryDataToolStripMenuItem.Click += new global::System.EventHandler(this.modifyBinaryDataRegistryValue_Click);
			this.modifyToolStripSeparator1.Name = "modifyToolStripSeparator1";
			this.modifyToolStripSeparator1.Size = new global::System.Drawing.Size(181, 6);
			this.deleteToolStripMenuItem1.Name = "deleteToolStripMenuItem1";
			this.deleteToolStripMenuItem1.Size = new global::System.Drawing.Size(184, 22);
			this.deleteToolStripMenuItem1.Text = "Delete";
			this.deleteToolStripMenuItem1.Click += new global::System.EventHandler(this.deleteRegistryValue_Click);
			this.renameToolStripMenuItem1.Name = "renameToolStripMenuItem1";
			this.renameToolStripMenuItem1.Size = new global::System.Drawing.Size(184, 22);
			this.renameToolStripMenuItem1.Text = "Rename";
			this.renameToolStripMenuItem1.Click += new global::System.EventHandler(this.renameRegistryValue_Click);
			this.lst_ContextMenuStrip.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.newToolStripMenuItem1
			});
			this.lst_ContextMenuStrip.Name = "lst_ContextMenuStrip";
			this.lst_ContextMenuStrip.Size = new global::System.Drawing.Size(99, 26);
			this.newToolStripMenuItem1.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.keyToolStripMenuItem1,
				this.toolStripSeparator4,
				this.stringValueToolStripMenuItem1,
				this.binaryValueToolStripMenuItem1,
				this.dWORD32bitValueToolStripMenuItem1,
				this.qWORD64bitValueToolStripMenuItem1,
				this.multiStringValueToolStripMenuItem1,
				this.expandableStringValueToolStripMenuItem1
			});
			this.newToolStripMenuItem1.Name = "newToolStripMenuItem1";
			this.newToolStripMenuItem1.Size = new global::System.Drawing.Size(98, 22);
			this.newToolStripMenuItem1.Text = "New";
			this.keyToolStripMenuItem1.Name = "keyToolStripMenuItem1";
			this.keyToolStripMenuItem1.Size = new global::System.Drawing.Size(200, 22);
			this.keyToolStripMenuItem1.Text = "Key";
			this.keyToolStripMenuItem1.Click += new global::System.EventHandler(this.createNewRegistryKey_Click);
			this.toolStripSeparator4.Name = "toolStripSeparator4";
			this.toolStripSeparator4.Size = new global::System.Drawing.Size(197, 6);
			this.stringValueToolStripMenuItem1.Name = "stringValueToolStripMenuItem1";
			this.stringValueToolStripMenuItem1.Size = new global::System.Drawing.Size(200, 22);
			this.stringValueToolStripMenuItem1.Text = "String Value";
			this.stringValueToolStripMenuItem1.Click += new global::System.EventHandler(this.createStringRegistryValue_Click);
			this.binaryValueToolStripMenuItem1.Name = "binaryValueToolStripMenuItem1";
			this.binaryValueToolStripMenuItem1.Size = new global::System.Drawing.Size(200, 22);
			this.binaryValueToolStripMenuItem1.Text = "Binary Value";
			this.binaryValueToolStripMenuItem1.Click += new global::System.EventHandler(this.createBinaryRegistryValue_Click);
			this.dWORD32bitValueToolStripMenuItem1.Name = "dWORD32bitValueToolStripMenuItem1";
			this.dWORD32bitValueToolStripMenuItem1.Size = new global::System.Drawing.Size(200, 22);
			this.dWORD32bitValueToolStripMenuItem1.Text = "DWORD (32-bit) Value";
			this.dWORD32bitValueToolStripMenuItem1.Click += new global::System.EventHandler(this.createDwordRegistryValue_Click);
			this.qWORD64bitValueToolStripMenuItem1.Name = "qWORD64bitValueToolStripMenuItem1";
			this.qWORD64bitValueToolStripMenuItem1.Size = new global::System.Drawing.Size(200, 22);
			this.qWORD64bitValueToolStripMenuItem1.Text = "QWORD (64-bit) Value";
			this.qWORD64bitValueToolStripMenuItem1.Click += new global::System.EventHandler(this.createQwordRegistryValue_Click);
			this.multiStringValueToolStripMenuItem1.Name = "multiStringValueToolStripMenuItem1";
			this.multiStringValueToolStripMenuItem1.Size = new global::System.Drawing.Size(200, 22);
			this.multiStringValueToolStripMenuItem1.Text = "Multi-String Value";
			this.multiStringValueToolStripMenuItem1.Click += new global::System.EventHandler(this.createMultiStringRegistryValue_Click);
			this.expandableStringValueToolStripMenuItem1.Name = "expandableStringValueToolStripMenuItem1";
			this.expandableStringValueToolStripMenuItem1.Size = new global::System.Drawing.Size(200, 22);
			this.expandableStringValueToolStripMenuItem1.Text = "Expandable String Value";
			this.expandableStringValueToolStripMenuItem1.Click += new global::System.EventHandler(this.createExpandStringRegistryValue_Click);
			this.timer1.Interval = 2000;
			this.timer1.Tick += new global::System.EventHandler(this.timer1_Tick);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(96f, 96f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Dpi;
			base.ClientSize = new global::System.Drawing.Size(784, 561);
			base.Controls.Add(this.tableLayoutPanel);
			this.Font = new global::System.Drawing.Font("Segoe UI", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ForeColor = global::System.Drawing.Color.Black;
			base.MainMenuStrip = this.menuStrip;
			base.Name = "FormRegistryEditor";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Registry Editor []";
			base.FormClosed += new global::System.Windows.Forms.FormClosedEventHandler(this.FormRegistryEditor_FormClosed);
			base.Load += new global::System.EventHandler(this.FrmRegistryEditor_Load);
			this.tableLayoutPanel.ResumeLayout(false);
			this.tableLayoutPanel.PerformLayout();
			this.splitContainer.Panel1.ResumeLayout(false);
			this.splitContainer.Panel2.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer).EndInit();
			this.splitContainer.ResumeLayout(false);
			this.statusStrip.ResumeLayout(false);
			this.statusStrip.PerformLayout();
			this.menuStrip.ResumeLayout(false);
			this.menuStrip.PerformLayout();
			this.tv_ContextMenuStrip.ResumeLayout(false);
			this.selectedItem_ContextMenuStrip.ResumeLayout(false);
			this.lst_ContextMenuStrip.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		// Token: 0x04000428 RID: 1064
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000429 RID: 1065
		private global::System.Windows.Forms.TableLayoutPanel tableLayoutPanel;

		// Token: 0x0400042A RID: 1066
		private global::System.Windows.Forms.SplitContainer splitContainer;

		// Token: 0x0400042B RID: 1067
		public global::Server.Helper.RegistryTreeView tvRegistryDirectory;

		// Token: 0x0400042C RID: 1068
		private global::Server.Helper.AeroListView lstRegistryValues;

		// Token: 0x0400042D RID: 1069
		private global::System.Windows.Forms.StatusStrip statusStrip;

		// Token: 0x0400042E RID: 1070
		private global::System.Windows.Forms.ToolStripStatusLabel selectedStripStatusLabel;

		// Token: 0x0400042F RID: 1071
		private global::System.Windows.Forms.ImageList imageRegistryDirectoryList;

		// Token: 0x04000430 RID: 1072
		private global::System.Windows.Forms.ColumnHeader hName;

		// Token: 0x04000431 RID: 1073
		private global::System.Windows.Forms.ColumnHeader hType;

		// Token: 0x04000432 RID: 1074
		private global::System.Windows.Forms.ColumnHeader hValue;

		// Token: 0x04000433 RID: 1075
		private global::System.Windows.Forms.ImageList imageRegistryKeyTypeList;

		// Token: 0x04000434 RID: 1076
		private global::System.Windows.Forms.ContextMenuStrip tv_ContextMenuStrip;

		// Token: 0x04000435 RID: 1077
		private global::System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;

		// Token: 0x04000436 RID: 1078
		private global::System.Windows.Forms.ToolStripMenuItem keyToolStripMenuItem;

		// Token: 0x04000437 RID: 1079
		private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator1;

		// Token: 0x04000438 RID: 1080
		private global::System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;

		// Token: 0x04000439 RID: 1081
		private global::System.Windows.Forms.ToolStripMenuItem renameToolStripMenuItem;

		// Token: 0x0400043A RID: 1082
		private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator2;

		// Token: 0x0400043B RID: 1083
		private global::System.Windows.Forms.ToolStripMenuItem stringValueToolStripMenuItem;

		// Token: 0x0400043C RID: 1084
		private global::System.Windows.Forms.ToolStripMenuItem binaryValueToolStripMenuItem;

		// Token: 0x0400043D RID: 1085
		private global::System.Windows.Forms.ToolStripMenuItem dWORD32bitValueToolStripMenuItem;

		// Token: 0x0400043E RID: 1086
		private global::System.Windows.Forms.ToolStripMenuItem qWORD64bitValueToolStripMenuItem;

		// Token: 0x0400043F RID: 1087
		private global::System.Windows.Forms.ToolStripMenuItem multiStringValueToolStripMenuItem;

		// Token: 0x04000440 RID: 1088
		private global::System.Windows.Forms.ToolStripMenuItem expandableStringValueToolStripMenuItem;

		// Token: 0x04000441 RID: 1089
		private global::System.Windows.Forms.ContextMenuStrip selectedItem_ContextMenuStrip;

		// Token: 0x04000442 RID: 1090
		private global::System.Windows.Forms.ToolStripMenuItem modifyToolStripMenuItem;

		// Token: 0x04000443 RID: 1091
		private global::System.Windows.Forms.ToolStripMenuItem modifyBinaryDataToolStripMenuItem;

		// Token: 0x04000444 RID: 1092
		private global::System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem1;

		// Token: 0x04000445 RID: 1093
		private global::System.Windows.Forms.ToolStripMenuItem renameToolStripMenuItem1;

		// Token: 0x04000446 RID: 1094
		private global::System.Windows.Forms.ContextMenuStrip lst_ContextMenuStrip;

		// Token: 0x04000447 RID: 1095
		private global::System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem1;

		// Token: 0x04000448 RID: 1096
		private global::System.Windows.Forms.ToolStripMenuItem keyToolStripMenuItem1;

		// Token: 0x04000449 RID: 1097
		private global::System.Windows.Forms.ToolStripMenuItem stringValueToolStripMenuItem1;

		// Token: 0x0400044A RID: 1098
		private global::System.Windows.Forms.ToolStripMenuItem binaryValueToolStripMenuItem1;

		// Token: 0x0400044B RID: 1099
		private global::System.Windows.Forms.ToolStripMenuItem dWORD32bitValueToolStripMenuItem1;

		// Token: 0x0400044C RID: 1100
		private global::System.Windows.Forms.ToolStripMenuItem qWORD64bitValueToolStripMenuItem1;

		// Token: 0x0400044D RID: 1101
		private global::System.Windows.Forms.ToolStripMenuItem multiStringValueToolStripMenuItem1;

		// Token: 0x0400044E RID: 1102
		private global::System.Windows.Forms.ToolStripMenuItem expandableStringValueToolStripMenuItem1;

		// Token: 0x0400044F RID: 1103
		private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator4;

		// Token: 0x04000450 RID: 1104
		private global::System.Windows.Forms.MenuStrip menuStrip;

		// Token: 0x04000451 RID: 1105
		private global::System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;

		// Token: 0x04000452 RID: 1106
		private global::System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;

		// Token: 0x04000453 RID: 1107
		private global::System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;

		// Token: 0x04000454 RID: 1108
		private global::System.Windows.Forms.ToolStripMenuItem modifyToolStripMenuItem1;

		// Token: 0x04000455 RID: 1109
		private global::System.Windows.Forms.ToolStripMenuItem modifyBinaryDataToolStripMenuItem1;

		// Token: 0x04000456 RID: 1110
		private global::System.Windows.Forms.ToolStripSeparator modifyNewtoolStripSeparator;

		// Token: 0x04000457 RID: 1111
		private global::System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem2;

		// Token: 0x04000458 RID: 1112
		private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator6;

		// Token: 0x04000459 RID: 1113
		private global::System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem2;

		// Token: 0x0400045A RID: 1114
		private global::System.Windows.Forms.ToolStripMenuItem renameToolStripMenuItem2;

		// Token: 0x0400045B RID: 1115
		private global::System.Windows.Forms.ToolStripMenuItem keyToolStripMenuItem2;

		// Token: 0x0400045C RID: 1116
		private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator7;

		// Token: 0x0400045D RID: 1117
		private global::System.Windows.Forms.ToolStripMenuItem stringValueToolStripMenuItem2;

		// Token: 0x0400045E RID: 1118
		private global::System.Windows.Forms.ToolStripMenuItem binaryValueToolStripMenuItem2;

		// Token: 0x0400045F RID: 1119
		private global::System.Windows.Forms.ToolStripMenuItem dWORD32bitValueToolStripMenuItem2;

		// Token: 0x04000460 RID: 1120
		private global::System.Windows.Forms.ToolStripMenuItem qWORD64bitValueToolStripMenuItem2;

		// Token: 0x04000461 RID: 1121
		private global::System.Windows.Forms.ToolStripMenuItem multiStringValueToolStripMenuItem2;

		// Token: 0x04000462 RID: 1122
		private global::System.Windows.Forms.ToolStripMenuItem expandableStringValueToolStripMenuItem2;

		// Token: 0x04000463 RID: 1123
		private global::System.Windows.Forms.ToolStripSeparator modifyToolStripSeparator1;

		// Token: 0x04000464 RID: 1124
		public global::System.Windows.Forms.Timer timer1;
	}
}
