﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Server.Helper;

namespace Server.Forms
{
	// Token: 0x02000086 RID: 134
	public partial class FormRegValueEditString : Form
	{
		// Token: 0x06000403 RID: 1027 RVA: 0x000222B0 File Offset: 0x000204B0
		public FormRegValueEditString(RegistrySeeker.RegValueData value)
		{
			this._value = value;
			this.InitializeComponent();
			this.valueNameTxtBox.Text = RegValueHelper.GetName(value.Name);
			this.valueDataTxtBox.Text = Server.Helper.ByteConverter.ToString(value.Data);
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x00004163 File Offset: 0x00002363
		private void okButton_Click(object sender, EventArgs e)
		{
			this._value.Data = Server.Helper.ByteConverter.GetBytes(this.valueDataTxtBox.Text);
			base.Tag = this._value;
			base.DialogResult = DialogResult.OK;
			base.Close();
		}

		// Token: 0x040002C5 RID: 709
		private readonly RegistrySeeker.RegValueData _value;
	}
}
