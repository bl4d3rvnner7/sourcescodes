﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Server.Forms
{
	// Token: 0x02000095 RID: 149
	public partial class FormFileSearcher : Form
	{
		// Token: 0x06000487 RID: 1159 RVA: 0x00004595 File Offset: 0x00002795
		public FormFileSearcher()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000488 RID: 1160 RVA: 0x000045A3 File Offset: 0x000027A3
		private void btnOk_Click(object sender, EventArgs e)
		{
			if (!string.IsNullOrWhiteSpace(this.txtExtnsions.Text) && this.numericUpDown1.Value > 0m)
			{
				base.DialogResult = DialogResult.OK;
			}
		}
	}
}
