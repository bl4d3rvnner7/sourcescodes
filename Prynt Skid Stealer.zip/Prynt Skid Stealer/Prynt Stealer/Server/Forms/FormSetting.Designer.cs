﻿namespace Server.Forms
{
	// Token: 0x02000088 RID: 136
	public partial class FormSetting : global::System.Windows.Forms.Form
	{
		// Token: 0x06000411 RID: 1041 RVA: 0x000041F1 File Offset: 0x000023F1
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x00022F10 File Offset: 0x00021110
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Server.Forms.FormSetting));
			this.button1 = new global::System.Windows.Forms.Button();
			this.checkBox1 = new global::System.Windows.Forms.CheckBox();
			this.textBox1 = new global::System.Windows.Forms.TextBox();
			this.textBox2 = new global::System.Windows.Forms.TextBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.label2 = new global::System.Windows.Forms.Label();
			base.SuspendLayout();
			this.button1.BackColor = global::System.Drawing.Color.Transparent;
			this.button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button1.Location = new global::System.Drawing.Point(12, 165);
			this.button1.Name = "button1";
			this.button1.Size = new global::System.Drawing.Size(321, 44);
			this.button1.TabIndex = 0;
			this.button1.Text = "OK";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.checkBox1.AutoSize = true;
			this.checkBox1.BackColor = global::System.Drawing.Color.Transparent;
			this.checkBox1.Location = new global::System.Drawing.Point(12, 13);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new global::System.Drawing.Size(51, 17);
			this.checkBox1.TabIndex = 1;
			this.checkBox1.Text = "Kock";
			this.checkBox1.UseVisualStyleBackColor = false;
			this.textBox1.Location = new global::System.Drawing.Point(71, 51);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new global::System.Drawing.Size(262, 20);
			this.textBox1.TabIndex = 2;
			this.textBox2.Location = new global::System.Drawing.Point(71, 113);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new global::System.Drawing.Size(262, 20);
			this.textBox2.TabIndex = 3;
			this.label1.AutoSize = true;
			this.label1.BackColor = global::System.Drawing.Color.Transparent;
			this.label1.Location = new global::System.Drawing.Point(12, 60);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(57, 13);
			this.label1.TabIndex = 4;
			this.label1.Text = "Webhook:";
			this.label2.AutoSize = true;
			this.label2.BackColor = global::System.Drawing.Color.Transparent;
			this.label2.Location = new global::System.Drawing.Point(12, 113);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(41, 13);
			this.label2.TabIndex = 5;
			this.label2.Text = "Secret:";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
			this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			base.ClientSize = new global::System.Drawing.Size(345, 222);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.textBox2);
			base.Controls.Add(this.textBox1);
			base.Controls.Add(this.checkBox1);
			base.Controls.Add(this.button1);
			this.ForeColor = global::System.Drawing.Color.White;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "FormSetting";
			base.ShowInTaskbar = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Setting";
			base.Load += new global::System.EventHandler(this.FormSetting_Load);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040002DA RID: 730
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040002DB RID: 731
		private global::System.Windows.Forms.Button button1;

		// Token: 0x040002DC RID: 732
		private global::System.Windows.Forms.CheckBox checkBox1;

		// Token: 0x040002DD RID: 733
		private global::System.Windows.Forms.TextBox textBox1;

		// Token: 0x040002DE RID: 734
		private global::System.Windows.Forms.TextBox textBox2;

		// Token: 0x040002DF RID: 735
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040002E0 RID: 736
		private global::System.Windows.Forms.Label label2;
	}
}
