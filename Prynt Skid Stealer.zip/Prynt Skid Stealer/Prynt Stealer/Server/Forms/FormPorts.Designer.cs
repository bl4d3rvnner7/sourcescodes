﻿namespace Server.Forms
{
	// Token: 0x02000097 RID: 151
	public partial class FormPorts : global::System.Windows.Forms.Form
	{
		// Token: 0x0600049F RID: 1183 RVA: 0x000046E5 File Offset: 0x000028E5
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060004A0 RID: 1184 RVA: 0x0002EBB0 File Offset: 0x0002CDB0
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Server.Forms.FormPorts));
			this.button1 = new global::System.Windows.Forms.Button();
			this.textPorts = new global::System.Windows.Forms.TextBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.listBox1 = new global::System.Windows.Forms.ListBox();
			this.btnDelete = new global::System.Windows.Forms.Button();
			this.btnAdd = new global::System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			base.SuspendLayout();
			this.button1.BackColor = global::System.Drawing.Color.Transparent;
			this.button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.button1.Location = new global::System.Drawing.Point(9, 157);
			this.button1.Margin = new global::System.Windows.Forms.Padding(2);
			this.button1.Name = "button1";
			this.button1.Size = new global::System.Drawing.Size(350, 33);
			this.button1.TabIndex = 0;
			this.button1.Text = "Start";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.textPorts.BackColor = global::System.Drawing.SystemColors.InactiveCaptionText;
			this.textPorts.ForeColor = global::System.Drawing.Color.White;
			this.textPorts.Location = new global::System.Drawing.Point(55, 31);
			this.textPorts.Margin = new global::System.Windows.Forms.Padding(2);
			this.textPorts.Name = "textPorts";
			this.textPorts.Size = new global::System.Drawing.Size(111, 20);
			this.textPorts.TabIndex = 0;
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(4, 34);
			this.label1.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(26, 13);
			this.label1.TabIndex = 1;
			this.label1.Text = "Port";
			this.groupBox1.BackColor = global::System.Drawing.Color.Transparent;
			this.groupBox1.Controls.Add(this.listBox1);
			this.groupBox1.Controls.Add(this.btnDelete);
			this.groupBox1.Controls.Add(this.btnAdd);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.textPorts);
			this.groupBox1.Location = new global::System.Drawing.Point(9, 9);
			this.groupBox1.Margin = new global::System.Windows.Forms.Padding(2);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new global::System.Windows.Forms.Padding(2);
			this.groupBox1.Size = new global::System.Drawing.Size(350, 129);
			this.groupBox1.TabIndex = 2;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Setting";
			this.listBox1.BackColor = global::System.Drawing.SystemColors.InactiveCaptionText;
			this.listBox1.ForeColor = global::System.Drawing.Color.White;
			this.listBox1.FormattingEnabled = true;
			this.listBox1.Location = new global::System.Drawing.Point(203, 31);
			this.listBox1.Margin = new global::System.Windows.Forms.Padding(2);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new global::System.Drawing.Size(117, 82);
			this.listBox1.TabIndex = 4;
			this.btnDelete.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnDelete.Location = new global::System.Drawing.Point(97, 78);
			this.btnDelete.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnDelete.Name = "btnDelete";
			this.btnDelete.Size = new global::System.Drawing.Size(75, 29);
			this.btnDelete.TabIndex = 3;
			this.btnDelete.Text = "Remove";
			this.btnDelete.UseVisualStyleBackColor = true;
			this.btnDelete.Click += new global::System.EventHandler(this.BtnDelete_Click);
			this.btnAdd.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnAdd.Location = new global::System.Drawing.Point(18, 78);
			this.btnAdd.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new global::System.Drawing.Size(75, 29);
			this.btnAdd.TabIndex = 2;
			this.btnAdd.Text = "Add";
			this.btnAdd.UseVisualStyleBackColor = true;
			this.btnAdd.Click += new global::System.EventHandler(this.BtnAdd_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(0, 0, 192);
			this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
			this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			base.ClientSize = new global::System.Drawing.Size(370, 202);
			base.Controls.Add(this.button1);
			base.Controls.Add(this.groupBox1);
			this.ForeColor = global::System.Drawing.Color.White;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Margin = new global::System.Windows.Forms.Padding(2);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "FormPorts";
			base.ShowInTaskbar = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Listen ports";
			base.TopMost = true;
			base.FormClosed += new global::System.Windows.Forms.FormClosedEventHandler(this.PortsFrm_FormClosed);
			base.Load += new global::System.EventHandler(this.PortsFrm_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x040003C3 RID: 963
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040003C4 RID: 964
		private global::System.Windows.Forms.Button button1;

		// Token: 0x040003C5 RID: 965
		public global::System.Windows.Forms.TextBox textPorts;

		// Token: 0x040003C6 RID: 966
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040003C7 RID: 967
		private global::System.Windows.Forms.GroupBox groupBox1;

		// Token: 0x040003C8 RID: 968
		private global::System.Windows.Forms.ListBox listBox1;

		// Token: 0x040003C9 RID: 969
		private global::System.Windows.Forms.Button btnDelete;

		// Token: 0x040003CA RID: 970
		private global::System.Windows.Forms.Button btnAdd;
	}
}
