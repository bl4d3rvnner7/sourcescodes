﻿namespace Server.Forms
{
	// Token: 0x0200008B RID: 139
	public partial class FormBlockClients : global::System.Windows.Forms.Form
	{
		// Token: 0x0600042B RID: 1067 RVA: 0x000042EF File Offset: 0x000024EF
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600042C RID: 1068 RVA: 0x00024B0C File Offset: 0x00022D0C
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Server.Forms.FormBlockClients));
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.listBlocked = new global::System.Windows.Forms.ListBox();
			this.btnDelete = new global::System.Windows.Forms.Button();
			this.btnAdd = new global::System.Windows.Forms.Button();
			this.label1 = new global::System.Windows.Forms.Label();
			this.txtBlock = new global::System.Windows.Forms.TextBox();
			this.bunifuGradientPanel3 = new global::Bunifu.UI.WinForms.BunifuGradientPanel();
			this.label12 = new global::System.Windows.Forms.Label();
			this.siticoneCircleButton3 = new global::Siticone.UI.WinForms.SiticoneCircleButton();
			this.label13 = new global::System.Windows.Forms.Label();
			this.label14 = new global::System.Windows.Forms.Label();
			this.groupBox1.SuspendLayout();
			this.bunifuGradientPanel3.SuspendLayout();
			base.SuspendLayout();
			this.groupBox1.Controls.Add(this.listBlocked);
			this.groupBox1.Controls.Add(this.btnDelete);
			this.groupBox1.Controls.Add(this.btnAdd);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.txtBlock);
			this.groupBox1.ForeColor = global::System.Drawing.Color.White;
			this.groupBox1.Location = new global::System.Drawing.Point(11, 11);
			this.groupBox1.Margin = new global::System.Windows.Forms.Padding(2);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new global::System.Windows.Forms.Padding(2);
			this.groupBox1.Size = new global::System.Drawing.Size(540, 235);
			this.groupBox1.TabIndex = 4;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Blocklist";
			this.listBlocked.DataBindings.Add(new global::System.Windows.Forms.Binding("Name", global::Server.Properties.Settings.Default, "txtBlocked", true, global::System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
			this.listBlocked.FormattingEnabled = true;
			this.listBlocked.Location = new global::System.Drawing.Point(225, 30);
			this.listBlocked.Margin = new global::System.Windows.Forms.Padding(2);
			this.listBlocked.Name = global::Server.Properties.Settings.Default.txtBlocked;
			this.listBlocked.SelectionMode = global::System.Windows.Forms.SelectionMode.MultiSimple;
			this.listBlocked.Size = new global::System.Drawing.Size(297, 173);
			this.listBlocked.TabIndex = 4;
			this.btnDelete.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnDelete.Location = new global::System.Drawing.Point(117, 107);
			this.btnDelete.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnDelete.Name = "btnDelete";
			this.btnDelete.Size = new global::System.Drawing.Size(38, 23);
			this.btnDelete.TabIndex = 3;
			this.btnDelete.Text = "Del";
			this.btnDelete.UseVisualStyleBackColor = true;
			this.btnDelete.Click += new global::System.EventHandler(this.BtnDelete_Click);
			this.btnAdd.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnAdd.Location = new global::System.Drawing.Point(24, 107);
			this.btnAdd.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new global::System.Drawing.Size(38, 23);
			this.btnAdd.TabIndex = 2;
			this.btnAdd.Text = "Add";
			this.btnAdd.UseVisualStyleBackColor = true;
			this.btnAdd.Click += new global::System.EventHandler(this.BtnAdd_Click);
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(4, 34);
			this.label1.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(89, 13);
			this.label1.TabIndex = 1;
			this.label1.Text = "Input HWID or IP";
			this.txtBlock.Location = new global::System.Drawing.Point(7, 56);
			this.txtBlock.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtBlock.Name = "txtBlock";
			this.txtBlock.Size = new global::System.Drawing.Size(192, 20);
			this.txtBlock.TabIndex = 0;
			this.bunifuGradientPanel3.BackColor = global::System.Drawing.Color.Transparent;
			this.bunifuGradientPanel3.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("bunifuGradientPanel3.BackgroundImage");
			this.bunifuGradientPanel3.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.bunifuGradientPanel3.BorderRadius = 1;
			this.bunifuGradientPanel3.Controls.Add(this.groupBox1);
			this.bunifuGradientPanel3.Controls.Add(this.label12);
			this.bunifuGradientPanel3.Controls.Add(this.siticoneCircleButton3);
			this.bunifuGradientPanel3.Controls.Add(this.label13);
			this.bunifuGradientPanel3.Controls.Add(this.label14);
			this.bunifuGradientPanel3.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.bunifuGradientPanel3.GradientBottomLeft = global::System.Drawing.Color.DodgerBlue;
			this.bunifuGradientPanel3.GradientBottomRight = global::System.Drawing.Color.DodgerBlue;
			this.bunifuGradientPanel3.GradientTopLeft = global::System.Drawing.Color.Navy;
			this.bunifuGradientPanel3.GradientTopRight = global::System.Drawing.Color.Navy;
			this.bunifuGradientPanel3.Location = new global::System.Drawing.Point(0, 0);
			this.bunifuGradientPanel3.Name = "bunifuGradientPanel3";
			this.bunifuGradientPanel3.Quality = 10;
			this.bunifuGradientPanel3.Size = new global::System.Drawing.Size(562, 246);
			this.bunifuGradientPanel3.TabIndex = 5;
			this.label12.AutoSize = true;
			this.label12.BackColor = global::System.Drawing.Color.Transparent;
			this.label12.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label12.ForeColor = global::System.Drawing.Color.White;
			this.label12.Location = new global::System.Drawing.Point(31, 392);
			this.label12.Name = "label12";
			this.label12.Size = new global::System.Drawing.Size(120, 16);
			this.label12.TabIndex = 23;
			this.label12.Text = "Ouner and Devs : ";
			this.siticoneCircleButton3.CheckedState.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.CustomImages.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneCircleButton3.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.siticoneCircleButton3.ForeColor = global::System.Drawing.Color.White;
			this.siticoneCircleButton3.HoveredState.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.Location = new global::System.Drawing.Point(141, 339);
			this.siticoneCircleButton3.Name = "siticoneCircleButton3";
			this.siticoneCircleButton3.ShadowDecoration.Mode = global::Siticone.UI.WinForms.Enums.ShadowMode.Circle;
			this.siticoneCircleButton3.ShadowDecoration.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.Size = new global::System.Drawing.Size(223, 26);
			this.siticoneCircleButton3.TabIndex = 22;
			this.siticoneCircleButton3.Text = "https://t.me/officialpryntsoftware";
			this.label13.AutoSize = true;
			this.label13.BackColor = global::System.Drawing.Color.Transparent;
			this.label13.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label13.ForeColor = global::System.Drawing.Color.White;
			this.label13.Location = new global::System.Drawing.Point(31, 344);
			this.label13.Name = "label13";
			this.label13.Size = new global::System.Drawing.Size(106, 16);
			this.label13.TabIndex = 21;
			this.label13.Text = "Our Telegram : ";
			this.label14.AutoSize = true;
			this.label14.BackColor = global::System.Drawing.Color.Transparent;
			this.label14.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label14.ForeColor = global::System.Drawing.Color.White;
			this.label14.Location = new global::System.Drawing.Point(31, 267);
			this.label14.Name = "label14";
			this.label14.Size = new global::System.Drawing.Size(284, 32);
			this.label14.TabIndex = 20;
			this.label14.Text = "We tend to provide the best quality hacking\r\n tools for our costumers.";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(562, 246);
			base.Controls.Add(this.bunifuGradientPanel3);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Margin = new global::System.Windows.Forms.Padding(2);
			base.Name = "FormBlockClients";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Block";
			base.FormClosed += new global::System.Windows.Forms.FormClosedEventHandler(this.FormBlockClients_FormClosed);
			base.Load += new global::System.EventHandler(this.FormBlockClients_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.bunifuGradientPanel3.ResumeLayout(false);
			this.bunifuGradientPanel3.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x04000300 RID: 768
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000301 RID: 769
		private global::System.Windows.Forms.GroupBox groupBox1;

		// Token: 0x04000302 RID: 770
		private global::System.Windows.Forms.ListBox listBlocked;

		// Token: 0x04000303 RID: 771
		private global::System.Windows.Forms.Button btnDelete;

		// Token: 0x04000304 RID: 772
		private global::System.Windows.Forms.Button btnAdd;

		// Token: 0x04000305 RID: 773
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000306 RID: 774
		public global::System.Windows.Forms.TextBox txtBlock;

		// Token: 0x04000307 RID: 775
		private global::Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel3;

		// Token: 0x04000308 RID: 776
		private global::System.Windows.Forms.Label label12;

		// Token: 0x04000309 RID: 777
		private global::Siticone.UI.WinForms.SiticoneCircleButton siticoneCircleButton3;

		// Token: 0x0400030A RID: 778
		private global::System.Windows.Forms.Label label13;

		// Token: 0x0400030B RID: 779
		private global::System.Windows.Forms.Label label14;
	}
}
