﻿namespace Server.Forms
{
	// Token: 0x0200008C RID: 140
	public partial class FormBuilder : global::System.Windows.Forms.Form
	{
		// Token: 0x06000441 RID: 1089 RVA: 0x000043C7 File Offset: 0x000025C7
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x00026B60 File Offset: 0x00024D60
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Server.Forms.FormBuilder));
			this.directoryEntry1 = new global::System.DirectoryServices.DirectoryEntry();
			this.toolTip1 = new global::System.Windows.Forms.ToolTip(this.components);
			this.btnRemoveIP = new global::System.Windows.Forms.Button();
			this.btnAddIP = new global::System.Windows.Forms.Button();
			this.textIP = new global::System.Windows.Forms.TextBox();
			this.listBoxIP = new global::System.Windows.Forms.ListBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.textPort = new global::System.Windows.Forms.TextBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.btnRemovePort = new global::System.Windows.Forms.Button();
			this.btnAddPort = new global::System.Windows.Forms.Button();
			this.chkPaste_bin = new global::System.Windows.Forms.CheckBox();
			this.listBoxPort = new global::System.Windows.Forms.ListBox();
			this.txtPaste_bin = new global::System.Windows.Forms.TextBox();
			this.bunifuGradientPanel3 = new global::Bunifu.UI.WinForms.BunifuGradientPanel();
			this.label6 = new global::System.Windows.Forms.Label();
			this.checkBox5 = new global::System.Windows.Forms.CheckBox();
			this.checkBox4 = new global::System.Windows.Forms.CheckBox();
			this.checkBox3 = new global::System.Windows.Forms.CheckBox();
			this.checkBox2 = new global::System.Windows.Forms.CheckBox();
			this.label19 = new global::System.Windows.Forms.Label();
			this.label18 = new global::System.Windows.Forms.Label();
			this.tbchatid = new global::System.Windows.Forms.TextBox();
			this.tbtoken = new global::System.Windows.Forms.TextBox();
			this.chkAntiProcess = new global::System.Windows.Forms.CheckBox();
			this.chkAnti = new global::System.Windows.Forms.CheckBox();
			this.txtGroup = new global::System.Windows.Forms.TextBox();
			this.label17 = new global::System.Windows.Forms.Label();
			this.numDelay = new global::System.Windows.Forms.NumericUpDown();
			this.label16 = new global::System.Windows.Forms.Label();
			this.chkBsod = new global::System.Windows.Forms.CheckBox();
			this.txtMutex = new global::System.Windows.Forms.TextBox();
			this.label5 = new global::System.Windows.Forms.Label();
			this.comboBoxFolder = new global::System.Windows.Forms.ComboBox();
			this.checkBox1 = new global::System.Windows.Forms.CheckBox();
			this.textFilename = new global::System.Windows.Forms.TextBox();
			this.label3 = new global::System.Windows.Forms.Label();
			this.label4 = new global::System.Windows.Forms.Label();
			this.btnBuild = new global::System.Windows.Forms.Button();
			this.chkIcon = new global::System.Windows.Forms.CheckBox();
			this.txtIcon = new global::System.Windows.Forms.TextBox();
			this.btnIcon = new global::System.Windows.Forms.Button();
			this.picIcon = new global::System.Windows.Forms.PictureBox();
			this.btnClone = new global::System.Windows.Forms.Button();
			this.btnAssembly = new global::System.Windows.Forms.CheckBox();
			this.txtFileVersion = new global::System.Windows.Forms.TextBox();
			this.txtProductVersion = new global::System.Windows.Forms.TextBox();
			this.txtOriginalFilename = new global::System.Windows.Forms.TextBox();
			this.txtTrademarks = new global::System.Windows.Forms.TextBox();
			this.txtCopyright = new global::System.Windows.Forms.TextBox();
			this.txtCompany = new global::System.Windows.Forms.TextBox();
			this.label14 = new global::System.Windows.Forms.Label();
			this.label13 = new global::System.Windows.Forms.Label();
			this.label12 = new global::System.Windows.Forms.Label();
			this.label11 = new global::System.Windows.Forms.Label();
			this.label10 = new global::System.Windows.Forms.Label();
			this.label9 = new global::System.Windows.Forms.Label();
			this.txtDescription = new global::System.Windows.Forms.TextBox();
			this.label7 = new global::System.Windows.Forms.Label();
			this.txtProduct = new global::System.Windows.Forms.TextBox();
			this.label8 = new global::System.Windows.Forms.Label();
			this.bunifuGradientPanel3.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.numDelay).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.picIcon).BeginInit();
			base.SuspendLayout();
			this.btnRemoveIP.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnRemoveIP.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.btnRemoveIP.Location = new global::System.Drawing.Point(80, 181);
			this.btnRemoveIP.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnRemoveIP.Name = "btnRemoveIP";
			this.btnRemoveIP.Size = new global::System.Drawing.Size(57, 24);
			this.btnRemoveIP.TabIndex = 72;
			this.btnRemoveIP.Text = "Del";
			this.btnRemoveIP.UseVisualStyleBackColor = true;
			this.btnRemoveIP.Click += new global::System.EventHandler(this.BtnRemoveIP_Click);
			this.btnAddIP.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnAddIP.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.btnAddIP.Location = new global::System.Drawing.Point(28, 181);
			this.btnAddIP.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnAddIP.Name = "btnAddIP";
			this.btnAddIP.Size = new global::System.Drawing.Size(47, 24);
			this.btnAddIP.TabIndex = 71;
			this.btnAddIP.Text = "Add";
			this.btnAddIP.UseVisualStyleBackColor = true;
			this.btnAddIP.Click += new global::System.EventHandler(this.BtnAddIP_Click);
			this.textIP.Location = new global::System.Drawing.Point(28, 38);
			this.textIP.Margin = new global::System.Windows.Forms.Padding(2);
			this.textIP.Name = "textIP";
			this.textIP.Size = new global::System.Drawing.Size(109, 20);
			this.textIP.TabIndex = 69;
			this.listBoxIP.FormattingEnabled = true;
			this.listBoxIP.Location = new global::System.Drawing.Point(28, 78);
			this.listBoxIP.Margin = new global::System.Windows.Forms.Padding(2);
			this.listBoxIP.Name = "listBoxIP";
			this.listBoxIP.Size = new global::System.Drawing.Size(109, 82);
			this.listBoxIP.TabIndex = 70;
			this.label2.AutoSize = true;
			this.label2.Location = new global::System.Drawing.Point(181, 15);
			this.label2.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(26, 13);
			this.label2.TabIndex = 61;
			this.label2.Text = "Port";
			this.textPort.Location = new global::System.Drawing.Point(153, 38);
			this.textPort.Margin = new global::System.Windows.Forms.Padding(2);
			this.textPort.Name = "textPort";
			this.textPort.Size = new global::System.Drawing.Size(109, 20);
			this.textPort.TabIndex = 62;
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(64, 11);
			this.label1.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(17, 13);
			this.label1.TabIndex = 68;
			this.label1.Text = "IP";
			this.btnRemovePort.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnRemovePort.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.btnRemovePort.Location = new global::System.Drawing.Point(211, 179);
			this.btnRemovePort.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnRemovePort.Name = "btnRemovePort";
			this.btnRemovePort.Size = new global::System.Drawing.Size(51, 26);
			this.btnRemovePort.TabIndex = 67;
			this.btnRemovePort.Text = "Del";
			this.btnRemovePort.UseVisualStyleBackColor = true;
			this.btnRemovePort.Click += new global::System.EventHandler(this.BtnRemovePort_Click);
			this.btnAddPort.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnAddPort.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.btnAddPort.Location = new global::System.Drawing.Point(153, 181);
			this.btnAddPort.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnAddPort.Name = "btnAddPort";
			this.btnAddPort.Size = new global::System.Drawing.Size(54, 24);
			this.btnAddPort.TabIndex = 66;
			this.btnAddPort.Text = "Add";
			this.btnAddPort.UseVisualStyleBackColor = true;
			this.btnAddPort.Click += new global::System.EventHandler(this.BtnAddPort_Click);
			this.chkPaste_bin.AutoSize = true;
			this.chkPaste_bin.Location = new global::System.Drawing.Point(28, 226);
			this.chkPaste_bin.Margin = new global::System.Windows.Forms.Padding(2);
			this.chkPaste_bin.Name = "chkPaste_bin";
			this.chkPaste_bin.Size = new global::System.Drawing.Size(109, 17);
			this.chkPaste_bin.TabIndex = 64;
			this.chkPaste_bin.Text = "Paste Bin / No-IP";
			this.chkPaste_bin.UseVisualStyleBackColor = true;
			this.chkPaste_bin.CheckedChanged += new global::System.EventHandler(this.CheckBox2_CheckedChanged);
			this.listBoxPort.FormattingEnabled = true;
			this.listBoxPort.Location = new global::System.Drawing.Point(153, 78);
			this.listBoxPort.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 2);
			this.listBoxPort.Name = "listBoxPort";
			this.listBoxPort.Size = new global::System.Drawing.Size(109, 82);
			this.listBoxPort.TabIndex = 65;
			this.txtPaste_bin.DataBindings.Add(new global::System.Windows.Forms.Binding("Text", global::Server.Properties.Settings.Default, "Paste_bin", true, global::System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
			this.txtPaste_bin.Enabled = false;
			this.txtPaste_bin.Location = new global::System.Drawing.Point(28, 250);
			this.txtPaste_bin.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtPaste_bin.Name = "txtPaste_bin";
			this.txtPaste_bin.Size = new global::System.Drawing.Size(140, 20);
			this.txtPaste_bin.TabIndex = 63;
			this.txtPaste_bin.Text = global::Server.Properties.Settings.Default.Paste_bin;
			this.bunifuGradientPanel3.BackColor = global::System.Drawing.Color.Transparent;
			this.bunifuGradientPanel3.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("bunifuGradientPanel3.BackgroundImage");
			this.bunifuGradientPanel3.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.bunifuGradientPanel3.BorderRadius = 1;
			this.bunifuGradientPanel3.Controls.Add(this.label6);
			this.bunifuGradientPanel3.Controls.Add(this.checkBox5);
			this.bunifuGradientPanel3.Controls.Add(this.checkBox4);
			this.bunifuGradientPanel3.Controls.Add(this.checkBox3);
			this.bunifuGradientPanel3.Controls.Add(this.checkBox2);
			this.bunifuGradientPanel3.Controls.Add(this.label19);
			this.bunifuGradientPanel3.Controls.Add(this.label18);
			this.bunifuGradientPanel3.Controls.Add(this.tbchatid);
			this.bunifuGradientPanel3.Controls.Add(this.tbtoken);
			this.bunifuGradientPanel3.Controls.Add(this.chkAntiProcess);
			this.bunifuGradientPanel3.Controls.Add(this.chkAnti);
			this.bunifuGradientPanel3.Controls.Add(this.txtGroup);
			this.bunifuGradientPanel3.Controls.Add(this.label17);
			this.bunifuGradientPanel3.Controls.Add(this.numDelay);
			this.bunifuGradientPanel3.Controls.Add(this.label16);
			this.bunifuGradientPanel3.Controls.Add(this.chkBsod);
			this.bunifuGradientPanel3.Controls.Add(this.txtMutex);
			this.bunifuGradientPanel3.Controls.Add(this.label5);
			this.bunifuGradientPanel3.Controls.Add(this.comboBoxFolder);
			this.bunifuGradientPanel3.Controls.Add(this.checkBox1);
			this.bunifuGradientPanel3.Controls.Add(this.textFilename);
			this.bunifuGradientPanel3.Controls.Add(this.label3);
			this.bunifuGradientPanel3.Controls.Add(this.label4);
			this.bunifuGradientPanel3.Controls.Add(this.btnBuild);
			this.bunifuGradientPanel3.Controls.Add(this.chkIcon);
			this.bunifuGradientPanel3.Controls.Add(this.txtIcon);
			this.bunifuGradientPanel3.Controls.Add(this.btnIcon);
			this.bunifuGradientPanel3.Controls.Add(this.picIcon);
			this.bunifuGradientPanel3.Controls.Add(this.btnClone);
			this.bunifuGradientPanel3.Controls.Add(this.btnAssembly);
			this.bunifuGradientPanel3.Controls.Add(this.txtFileVersion);
			this.bunifuGradientPanel3.Controls.Add(this.txtProductVersion);
			this.bunifuGradientPanel3.Controls.Add(this.txtOriginalFilename);
			this.bunifuGradientPanel3.Controls.Add(this.txtTrademarks);
			this.bunifuGradientPanel3.Controls.Add(this.txtCopyright);
			this.bunifuGradientPanel3.Controls.Add(this.txtCompany);
			this.bunifuGradientPanel3.Controls.Add(this.label14);
			this.bunifuGradientPanel3.Controls.Add(this.label13);
			this.bunifuGradientPanel3.Controls.Add(this.label12);
			this.bunifuGradientPanel3.Controls.Add(this.label11);
			this.bunifuGradientPanel3.Controls.Add(this.label10);
			this.bunifuGradientPanel3.Controls.Add(this.label9);
			this.bunifuGradientPanel3.Controls.Add(this.txtDescription);
			this.bunifuGradientPanel3.Controls.Add(this.label7);
			this.bunifuGradientPanel3.Controls.Add(this.txtProduct);
			this.bunifuGradientPanel3.Controls.Add(this.label8);
			this.bunifuGradientPanel3.Controls.Add(this.label1);
			this.bunifuGradientPanel3.Controls.Add(this.listBoxPort);
			this.bunifuGradientPanel3.Controls.Add(this.chkPaste_bin);
			this.bunifuGradientPanel3.Controls.Add(this.btnAddPort);
			this.bunifuGradientPanel3.Controls.Add(this.txtPaste_bin);
			this.bunifuGradientPanel3.Controls.Add(this.btnRemovePort);
			this.bunifuGradientPanel3.Controls.Add(this.textPort);
			this.bunifuGradientPanel3.Controls.Add(this.label2);
			this.bunifuGradientPanel3.Controls.Add(this.listBoxIP);
			this.bunifuGradientPanel3.Controls.Add(this.textIP);
			this.bunifuGradientPanel3.Controls.Add(this.btnAddIP);
			this.bunifuGradientPanel3.Controls.Add(this.btnRemoveIP);
			this.bunifuGradientPanel3.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.bunifuGradientPanel3.GradientBottomLeft = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.bunifuGradientPanel3.GradientBottomRight = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.bunifuGradientPanel3.GradientTopLeft = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.bunifuGradientPanel3.GradientTopRight = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.bunifuGradientPanel3.Location = new global::System.Drawing.Point(0, 0);
			this.bunifuGradientPanel3.Name = "bunifuGradientPanel3";
			this.bunifuGradientPanel3.Quality = 10;
			this.bunifuGradientPanel3.Size = new global::System.Drawing.Size(600, 492);
			this.bunifuGradientPanel3.TabIndex = 117;
			this.label6.AutoSize = true;
			this.label6.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 10.25f);
			this.label6.Location = new global::System.Drawing.Point(366, 320);
			this.label6.Name = "label6";
			this.label6.Size = new global::System.Drawing.Size(193, 17);
			this.label6.TabIndex = 162;
			this.label6.Text = "Telegram Reporting Settings:";
			this.checkBox5.AutoSize = true;
			this.checkBox5.Location = new global::System.Drawing.Point(381, 273);
			this.checkBox5.Name = "checkBox5";
			this.checkBox5.Size = new global::System.Drawing.Size(60, 17);
			this.checkBox5.TabIndex = 161;
			this.checkBox5.Text = "Hidden";
			this.checkBox5.UseVisualStyleBackColor = true;
			this.checkBox4.AutoSize = true;
			this.checkBox4.Location = new global::System.Drawing.Point(470, 276);
			this.checkBox4.Name = "checkBox4";
			this.checkBox4.Size = new global::System.Drawing.Size(46, 17);
			this.checkBox4.TabIndex = 160;
			this.checkBox4.Text = "Melt";
			this.checkBox4.UseVisualStyleBackColor = true;
			this.checkBox3.AutoSize = true;
			this.checkBox3.Location = new global::System.Drawing.Point(381, 299);
			this.checkBox3.Name = "checkBox3";
			this.checkBox3.Size = new global::System.Drawing.Size(54, 17);
			this.checkBox3.TabIndex = 159;
			this.checkBox3.Text = "Spoof";
			this.checkBox3.UseVisualStyleBackColor = true;
			this.checkBox2.AutoSize = true;
			this.checkBox2.Location = new global::System.Drawing.Point(470, 299);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.Size = new global::System.Drawing.Size(102, 17);
			this.checkBox2.TabIndex = 158;
			this.checkBox2.Text = "Disble Defender";
			this.checkBox2.UseVisualStyleBackColor = true;
			this.label19.AutoSize = true;
			this.label19.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 10.25f);
			this.label19.Location = new global::System.Drawing.Point(400, 386);
			this.label19.Name = "label19";
			this.label19.Size = new global::System.Drawing.Size(116, 17);
			this.label19.TabIndex = 157;
			this.label19.Text = "Telegram Chat Id";
			this.label18.AutoSize = true;
			this.label18.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 10.25f);
			this.label18.Location = new global::System.Drawing.Point(417, 341);
			this.label18.Name = "label18";
			this.label18.Size = new global::System.Drawing.Size(73, 17);
			this.label18.TabIndex = 156;
			this.label18.Text = "Bot Token";
			this.tbchatid.Location = new global::System.Drawing.Point(376, 416);
			this.tbchatid.Name = "tbchatid";
			this.tbchatid.Size = new global::System.Drawing.Size(172, 20);
			this.tbchatid.TabIndex = 155;
			this.tbtoken.Location = new global::System.Drawing.Point(376, 363);
			this.tbtoken.Name = "tbtoken";
			this.tbtoken.Size = new global::System.Drawing.Size(172, 20);
			this.tbtoken.TabIndex = 154;
			this.chkAntiProcess.AutoSize = true;
			this.chkAntiProcess.Location = new global::System.Drawing.Point(468, 254);
			this.chkAntiProcess.Name = "chkAntiProcess";
			this.chkAntiProcess.Size = new global::System.Drawing.Size(48, 17);
			this.chkAntiProcess.TabIndex = 153;
			this.chkAntiProcess.Text = "UAC";
			this.chkAntiProcess.UseVisualStyleBackColor = true;
			this.chkAnti.AutoSize = true;
			this.chkAnti.Location = new global::System.Drawing.Point(381, 254);
			this.chkAnti.Name = "chkAnti";
			this.chkAnti.Size = new global::System.Drawing.Size(63, 17);
			this.chkAnti.TabIndex = 152;
			this.chkAnti.Text = "Anti-VM";
			this.chkAnti.UseVisualStyleBackColor = true;
			this.txtGroup.DataBindings.Add(new global::System.Windows.Forms.Binding("Text", global::Server.Properties.Settings.Default, "Group", true, global::System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
			this.txtGroup.Location = new global::System.Drawing.Point(1026, 214);
			this.txtGroup.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtGroup.Name = "txtGroup";
			this.txtGroup.Size = new global::System.Drawing.Size(110, 20);
			this.txtGroup.TabIndex = 151;
			this.txtGroup.Text = global::Server.Properties.Settings.Default.Group;
			this.txtGroup.TextChanged += new global::System.EventHandler(this.txtGroup_TextChanged);
			this.label17.AutoSize = true;
			this.label17.Location = new global::System.Drawing.Point(1028, 199);
			this.label17.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label17.Name = "label17";
			this.label17.Size = new global::System.Drawing.Size(36, 13);
			this.label17.TabIndex = 150;
			this.label17.Text = "Group";
			this.numDelay.Location = new global::System.Drawing.Point(395, 455);
			this.numDelay.Margin = new global::System.Windows.Forms.Padding(2);
			global::System.Windows.Forms.NumericUpDown numericUpDown = this.numDelay;
			int[] array = new int[4];
			array[0] = 999;
			numericUpDown.Maximum = new decimal(array);
			global::System.Windows.Forms.NumericUpDown numericUpDown2 = this.numDelay;
			int[] array2 = new int[4];
			array2[0] = 1;
			numericUpDown2.Minimum = new decimal(array2);
			this.numDelay.Name = "numDelay";
			this.numDelay.Size = new global::System.Drawing.Size(56, 20);
			this.numDelay.TabIndex = 149;
			global::System.Windows.Forms.NumericUpDown numericUpDown3 = this.numDelay;
			int[] array3 = new int[4];
			array3[0] = 1;
			numericUpDown3.Value = new decimal(array3);
			this.label16.AutoSize = true;
			this.label16.Location = new global::System.Drawing.Point(337, 462);
			this.label16.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label16.Name = "label16";
			this.label16.Size = new global::System.Drawing.Size(34, 13);
			this.label16.TabIndex = 148;
			this.label16.Text = "Delay";
			this.chkBsod.AutoSize = true;
			this.chkBsod.Location = new global::System.Drawing.Point(1010, 216);
			this.chkBsod.Margin = new global::System.Windows.Forms.Padding(2);
			this.chkBsod.Name = "chkBsod";
			this.chkBsod.Size = new global::System.Drawing.Size(56, 17);
			this.chkBsod.TabIndex = 147;
			this.chkBsod.Text = "BSOD";
			this.chkBsod.UseVisualStyleBackColor = true;
			this.txtMutex.DataBindings.Add(new global::System.Windows.Forms.Binding("Text", global::Server.Properties.Settings.Default, "Mutex", true, global::System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
			this.txtMutex.Location = new global::System.Drawing.Point(1008, 137);
			this.txtMutex.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtMutex.Name = "txtMutex";
			this.txtMutex.Size = new global::System.Drawing.Size(205, 20);
			this.txtMutex.TabIndex = 146;
			this.txtMutex.Text = global::Server.Properties.Settings.Default.Mutex;
			this.label5.AutoSize = true;
			this.label5.Location = new global::System.Drawing.Point(1006, 117);
			this.label5.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(36, 13);
			this.label5.TabIndex = 145;
			this.label5.Text = "Mutex";
			this.comboBoxFolder.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxFolder.Enabled = false;
			this.comboBoxFolder.FormattingEnabled = true;
			this.comboBoxFolder.Items.AddRange(new object[]
			{
				"%AppData%",
				"%Temp%"
			});
			this.comboBoxFolder.Location = new global::System.Drawing.Point(72, 363);
			this.comboBoxFolder.Margin = new global::System.Windows.Forms.Padding(2);
			this.comboBoxFolder.Name = "comboBoxFolder";
			this.comboBoxFolder.Size = new global::System.Drawing.Size(166, 21);
			this.comboBoxFolder.TabIndex = 144;
			this.checkBox1.AutoSize = true;
			this.checkBox1.Location = new global::System.Drawing.Point(28, 341);
			this.checkBox1.Margin = new global::System.Windows.Forms.Padding(2);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new global::System.Drawing.Size(90, 17);
			this.checkBox1.TabIndex = 143;
			this.checkBox1.Text = "Hidden Install";
			this.checkBox1.UseVisualStyleBackColor = true;
			this.textFilename.DataBindings.Add(new global::System.Windows.Forms.Binding("Text", global::Server.Properties.Settings.Default, "Filename", true, global::System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
			this.textFilename.Enabled = false;
			this.textFilename.Location = new global::System.Drawing.Point(72, 416);
			this.textFilename.Margin = new global::System.Windows.Forms.Padding(2);
			this.textFilename.Name = "textFilename";
			this.textFilename.Size = new global::System.Drawing.Size(162, 20);
			this.textFilename.TabIndex = 142;
			this.textFilename.Text = global::Server.Properties.Settings.Default.Filename;
			this.label3.AutoSize = true;
			this.label3.Location = new global::System.Drawing.Point(21, 371);
			this.label3.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(47, 13);
			this.label3.TabIndex = 140;
			this.label3.Text = "File path";
			this.label4.AutoSize = true;
			this.label4.Location = new global::System.Drawing.Point(16, 419);
			this.label4.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(52, 13);
			this.label4.TabIndex = 141;
			this.label4.Text = "File name";
			this.btnBuild.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnBuild.Location = new global::System.Drawing.Point(455, 451);
			this.btnBuild.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnBuild.Name = "btnBuild";
			this.btnBuild.Size = new global::System.Drawing.Size(93, 24);
			this.btnBuild.TabIndex = 139;
			this.btnBuild.Text = "Build";
			this.btnBuild.UseVisualStyleBackColor = true;
			this.btnBuild.Click += new global::System.EventHandler(this.btnBuild_Click_1);
			this.chkIcon.AutoSize = true;
			this.chkIcon.Location = new global::System.Drawing.Point(28, 284);
			this.chkIcon.Margin = new global::System.Windows.Forms.Padding(2);
			this.chkIcon.Name = "chkIcon";
			this.chkIcon.Size = new global::System.Drawing.Size(47, 17);
			this.chkIcon.TabIndex = 138;
			this.chkIcon.Text = "Icon";
			this.chkIcon.UseVisualStyleBackColor = true;
			this.txtIcon.Enabled = false;
			this.txtIcon.Location = new global::System.Drawing.Point(28, 317);
			this.txtIcon.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtIcon.Name = "txtIcon";
			this.txtIcon.Size = new global::System.Drawing.Size(140, 20);
			this.txtIcon.TabIndex = 137;
			this.btnIcon.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnIcon.Location = new global::System.Drawing.Point(80, 284);
			this.btnIcon.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnIcon.Name = "btnIcon";
			this.btnIcon.Size = new global::System.Drawing.Size(88, 24);
			this.btnIcon.TabIndex = 136;
			this.btnIcon.Tag = "Browse";
			this.btnIcon.Text = "Choose icon";
			this.btnIcon.UseVisualStyleBackColor = true;
			this.picIcon.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.picIcon.ErrorImage = null;
			this.picIcon.InitialImage = null;
			this.picIcon.Location = new global::System.Drawing.Point(172, 284);
			this.picIcon.Margin = new global::System.Windows.Forms.Padding(2);
			this.picIcon.Name = "picIcon";
			this.picIcon.Size = new global::System.Drawing.Size(66, 53);
			this.picIcon.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.picIcon.TabIndex = 135;
			this.picIcon.TabStop = false;
			this.btnClone.Enabled = false;
			this.btnClone.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.btnClone.Location = new global::System.Drawing.Point(468, 11);
			this.btnClone.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnClone.Name = "btnClone";
			this.btnClone.Size = new global::System.Drawing.Size(69, 25);
			this.btnClone.TabIndex = 134;
			this.btnClone.Text = "Clone";
			this.btnClone.UseVisualStyleBackColor = true;
			this.btnAssembly.AutoSize = true;
			this.btnAssembly.Location = new global::System.Drawing.Point(275, 14);
			this.btnAssembly.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnAssembly.Name = "btnAssembly";
			this.btnAssembly.Size = new global::System.Drawing.Size(110, 17);
			this.btnAssembly.TabIndex = 133;
			this.btnAssembly.Text = "Change Assembly";
			this.btnAssembly.UseVisualStyleBackColor = true;
			this.txtFileVersion.DataBindings.Add(new global::System.Windows.Forms.Binding("Text", global::Server.Properties.Settings.Default, "txtFileVersion", true, global::System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
			this.txtFileVersion.Enabled = false;
			this.txtFileVersion.Location = new global::System.Drawing.Point(386, 229);
			this.txtFileVersion.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtFileVersion.Name = "txtFileVersion";
			this.txtFileVersion.Size = new global::System.Drawing.Size(151, 20);
			this.txtFileVersion.TabIndex = 132;
			this.txtFileVersion.Text = global::Server.Properties.Settings.Default.txtFileVersion;
			this.txtProductVersion.DataBindings.Add(new global::System.Windows.Forms.Binding("Text", global::Server.Properties.Settings.Default, "txtProductVersion", true, global::System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
			this.txtProductVersion.Enabled = false;
			this.txtProductVersion.Location = new global::System.Drawing.Point(386, 202);
			this.txtProductVersion.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtProductVersion.Name = "txtProductVersion";
			this.txtProductVersion.Size = new global::System.Drawing.Size(151, 20);
			this.txtProductVersion.TabIndex = 131;
			this.txtProductVersion.Text = global::Server.Properties.Settings.Default.txtProductVersion;
			this.txtOriginalFilename.DataBindings.Add(new global::System.Windows.Forms.Binding("Text", global::Server.Properties.Settings.Default, "txtOriginalFilename", true, global::System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
			this.txtOriginalFilename.Enabled = false;
			this.txtOriginalFilename.Location = new global::System.Drawing.Point(386, 174);
			this.txtOriginalFilename.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtOriginalFilename.Name = "txtOriginalFilename";
			this.txtOriginalFilename.Size = new global::System.Drawing.Size(151, 20);
			this.txtOriginalFilename.TabIndex = 130;
			this.txtOriginalFilename.Text = global::Server.Properties.Settings.Default.txtOriginalFilename;
			this.txtTrademarks.DataBindings.Add(new global::System.Windows.Forms.Binding("Text", global::Server.Properties.Settings.Default, "txtTrademarks", true, global::System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
			this.txtTrademarks.Enabled = false;
			this.txtTrademarks.Location = new global::System.Drawing.Point(386, 147);
			this.txtTrademarks.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtTrademarks.Name = "txtTrademarks";
			this.txtTrademarks.Size = new global::System.Drawing.Size(151, 20);
			this.txtTrademarks.TabIndex = 129;
			this.txtTrademarks.Text = global::Server.Properties.Settings.Default.txtTrademarks;
			this.txtCopyright.DataBindings.Add(new global::System.Windows.Forms.Binding("Text", global::Server.Properties.Settings.Default, "txtCopyright", true, global::System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
			this.txtCopyright.Enabled = false;
			this.txtCopyright.Location = new global::System.Drawing.Point(386, 120);
			this.txtCopyright.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtCopyright.Name = "txtCopyright";
			this.txtCopyright.Size = new global::System.Drawing.Size(151, 20);
			this.txtCopyright.TabIndex = 128;
			this.txtCopyright.Text = global::Server.Properties.Settings.Default.txtCopyright;
			this.txtCompany.DataBindings.Add(new global::System.Windows.Forms.Binding("Text", global::Server.Properties.Settings.Default, "txtCompany", true, global::System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
			this.txtCompany.Enabled = false;
			this.txtCompany.Location = new global::System.Drawing.Point(386, 93);
			this.txtCompany.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtCompany.Name = "txtCompany";
			this.txtCompany.Size = new global::System.Drawing.Size(151, 20);
			this.txtCompany.TabIndex = 127;
			this.txtCompany.Text = global::Server.Properties.Settings.Default.txtCompany;
			this.label14.AutoSize = true;
			this.label14.Location = new global::System.Drawing.Point(272, 204);
			this.label14.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label14.Name = "label14";
			this.label14.Size = new global::System.Drawing.Size(85, 13);
			this.label14.TabIndex = 126;
			this.label14.Text = "Product Version:";
			this.label13.AutoSize = true;
			this.label13.Location = new global::System.Drawing.Point(272, 233);
			this.label13.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label13.Name = "label13";
			this.label13.Size = new global::System.Drawing.Size(64, 13);
			this.label13.TabIndex = 125;
			this.label13.Text = "File Version:";
			this.label12.AutoSize = true;
			this.label12.Location = new global::System.Drawing.Point(272, 177);
			this.label12.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label12.Name = "label12";
			this.label12.Size = new global::System.Drawing.Size(90, 13);
			this.label12.TabIndex = 124;
			this.label12.Text = "Original Filename:";
			this.label11.AutoSize = true;
			this.label11.Location = new global::System.Drawing.Point(272, 150);
			this.label11.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label11.Name = "label11";
			this.label11.Size = new global::System.Drawing.Size(66, 13);
			this.label11.TabIndex = 123;
			this.label11.Text = "Trademarks:";
			this.label10.AutoSize = true;
			this.label10.Location = new global::System.Drawing.Point(272, 123);
			this.label10.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label10.Name = "label10";
			this.label10.Size = new global::System.Drawing.Size(54, 13);
			this.label10.TabIndex = 122;
			this.label10.Text = "Copyright:";
			this.label9.AutoSize = true;
			this.label9.Location = new global::System.Drawing.Point(272, 96);
			this.label9.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label9.Name = "label9";
			this.label9.Size = new global::System.Drawing.Size(54, 13);
			this.label9.TabIndex = 121;
			this.label9.Text = "Company:";
			this.txtDescription.DataBindings.Add(new global::System.Windows.Forms.Binding("Text", global::Server.Properties.Settings.Default, "txtDescription", true, global::System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
			this.txtDescription.Enabled = false;
			this.txtDescription.Location = new global::System.Drawing.Point(386, 66);
			this.txtDescription.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtDescription.Name = "txtDescription";
			this.txtDescription.Size = new global::System.Drawing.Size(151, 20);
			this.txtDescription.TabIndex = 120;
			this.txtDescription.Text = global::Server.Properties.Settings.Default.txtDescription;
			this.label7.AutoSize = true;
			this.label7.Location = new global::System.Drawing.Point(272, 68);
			this.label7.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label7.Name = "label7";
			this.label7.Size = new global::System.Drawing.Size(63, 13);
			this.label7.TabIndex = 119;
			this.label7.Text = "Description:";
			this.txtProduct.DataBindings.Add(new global::System.Windows.Forms.Binding("Text", global::Server.Properties.Settings.Default, "ProductName", true, global::System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
			this.txtProduct.Enabled = false;
			this.txtProduct.Location = new global::System.Drawing.Point(386, 38);
			this.txtProduct.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtProduct.Name = "txtProduct";
			this.txtProduct.Size = new global::System.Drawing.Size(151, 20);
			this.txtProduct.TabIndex = 118;
			this.txtProduct.Text = global::Server.Properties.Settings.Default.ProductName;
			this.label8.AutoSize = true;
			this.label8.Location = new global::System.Drawing.Point(272, 41);
			this.label8.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label8.Name = "label8";
			this.label8.Size = new global::System.Drawing.Size(47, 13);
			this.label8.TabIndex = 117;
			this.label8.Text = "Product:";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
			base.ClientSize = new global::System.Drawing.Size(600, 492);
			base.Controls.Add(this.bunifuGradientPanel3);
			this.ForeColor = global::System.Drawing.Color.White;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Margin = new global::System.Windows.Forms.Padding(2);
			this.MaximumSize = new global::System.Drawing.Size(616, 531);
			base.Name = "FormBuilder";
			base.SizeGripStyle = global::System.Windows.Forms.SizeGripStyle.Hide;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Prynt Builder";
			base.Load += new global::System.EventHandler(this.Builder_Load);
			this.bunifuGradientPanel3.ResumeLayout(false);
			this.bunifuGradientPanel3.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.numDelay).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.picIcon).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x0400030E RID: 782
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400030F RID: 783
		private global::System.DirectoryServices.DirectoryEntry directoryEntry1;

		// Token: 0x04000310 RID: 784
		private global::System.Windows.Forms.ToolTip toolTip1;

		// Token: 0x04000311 RID: 785
		private global::System.Windows.Forms.Button btnRemoveIP;

		// Token: 0x04000312 RID: 786
		private global::System.Windows.Forms.Button btnAddIP;

		// Token: 0x04000313 RID: 787
		private global::System.Windows.Forms.TextBox textIP;

		// Token: 0x04000314 RID: 788
		private global::System.Windows.Forms.ListBox listBoxIP;

		// Token: 0x04000315 RID: 789
		private global::System.Windows.Forms.Label label2;

		// Token: 0x04000316 RID: 790
		private global::System.Windows.Forms.TextBox textPort;

		// Token: 0x04000317 RID: 791
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000318 RID: 792
		private global::System.Windows.Forms.Button btnRemovePort;

		// Token: 0x04000319 RID: 793
		private global::System.Windows.Forms.TextBox txtPaste_bin;

		// Token: 0x0400031A RID: 794
		private global::System.Windows.Forms.Button btnAddPort;

		// Token: 0x0400031B RID: 795
		private global::System.Windows.Forms.CheckBox chkPaste_bin;

		// Token: 0x0400031C RID: 796
		private global::System.Windows.Forms.ListBox listBoxPort;

		// Token: 0x0400031D RID: 797
		private global::Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel3;

		// Token: 0x0400031E RID: 798
		private global::System.Windows.Forms.Label label19;

		// Token: 0x0400031F RID: 799
		private global::System.Windows.Forms.Label label18;

		// Token: 0x04000320 RID: 800
		private global::System.Windows.Forms.TextBox tbchatid;

		// Token: 0x04000321 RID: 801
		private global::System.Windows.Forms.TextBox tbtoken;

		// Token: 0x04000322 RID: 802
		private global::System.Windows.Forms.CheckBox chkAntiProcess;

		// Token: 0x04000323 RID: 803
		private global::System.Windows.Forms.CheckBox chkAnti;

		// Token: 0x04000324 RID: 804
		private global::System.Windows.Forms.TextBox txtGroup;

		// Token: 0x04000325 RID: 805
		private global::System.Windows.Forms.Label label17;

		// Token: 0x04000326 RID: 806
		private global::System.Windows.Forms.NumericUpDown numDelay;

		// Token: 0x04000327 RID: 807
		private global::System.Windows.Forms.Label label16;

		// Token: 0x04000328 RID: 808
		private global::System.Windows.Forms.CheckBox chkBsod;

		// Token: 0x04000329 RID: 809
		private global::System.Windows.Forms.TextBox txtMutex;

		// Token: 0x0400032A RID: 810
		private global::System.Windows.Forms.Label label5;

		// Token: 0x0400032B RID: 811
		private global::System.Windows.Forms.ComboBox comboBoxFolder;

		// Token: 0x0400032C RID: 812
		private global::System.Windows.Forms.CheckBox checkBox1;

		// Token: 0x0400032D RID: 813
		private global::System.Windows.Forms.TextBox textFilename;

		// Token: 0x0400032E RID: 814
		private global::System.Windows.Forms.Label label3;

		// Token: 0x0400032F RID: 815
		private global::System.Windows.Forms.Label label4;

		// Token: 0x04000330 RID: 816
		private global::System.Windows.Forms.Button btnBuild;

		// Token: 0x04000331 RID: 817
		private global::System.Windows.Forms.CheckBox chkIcon;

		// Token: 0x04000332 RID: 818
		private global::System.Windows.Forms.TextBox txtIcon;

		// Token: 0x04000333 RID: 819
		private global::System.Windows.Forms.Button btnIcon;

		// Token: 0x04000334 RID: 820
		private global::System.Windows.Forms.PictureBox picIcon;

		// Token: 0x04000335 RID: 821
		private global::System.Windows.Forms.Button btnClone;

		// Token: 0x04000336 RID: 822
		private global::System.Windows.Forms.CheckBox btnAssembly;

		// Token: 0x04000337 RID: 823
		private global::System.Windows.Forms.TextBox txtFileVersion;

		// Token: 0x04000338 RID: 824
		private global::System.Windows.Forms.TextBox txtProductVersion;

		// Token: 0x04000339 RID: 825
		private global::System.Windows.Forms.TextBox txtOriginalFilename;

		// Token: 0x0400033A RID: 826
		private global::System.Windows.Forms.TextBox txtTrademarks;

		// Token: 0x0400033B RID: 827
		private global::System.Windows.Forms.TextBox txtCopyright;

		// Token: 0x0400033C RID: 828
		private global::System.Windows.Forms.TextBox txtCompany;

		// Token: 0x0400033D RID: 829
		private global::System.Windows.Forms.Label label14;

		// Token: 0x0400033E RID: 830
		private global::System.Windows.Forms.Label label13;

		// Token: 0x0400033F RID: 831
		private global::System.Windows.Forms.Label label12;

		// Token: 0x04000340 RID: 832
		private global::System.Windows.Forms.Label label11;

		// Token: 0x04000341 RID: 833
		private global::System.Windows.Forms.Label label10;

		// Token: 0x04000342 RID: 834
		private global::System.Windows.Forms.Label label9;

		// Token: 0x04000343 RID: 835
		private global::System.Windows.Forms.TextBox txtDescription;

		// Token: 0x04000344 RID: 836
		private global::System.Windows.Forms.Label label7;

		// Token: 0x04000345 RID: 837
		private global::System.Windows.Forms.TextBox txtProduct;

		// Token: 0x04000346 RID: 838
		private global::System.Windows.Forms.Label label8;

		// Token: 0x04000347 RID: 839
		private global::System.Windows.Forms.CheckBox checkBox5;

		// Token: 0x04000348 RID: 840
		private global::System.Windows.Forms.CheckBox checkBox4;

		// Token: 0x04000349 RID: 841
		private global::System.Windows.Forms.CheckBox checkBox3;

		// Token: 0x0400034A RID: 842
		private global::System.Windows.Forms.CheckBox checkBox2;

		// Token: 0x0400034B RID: 843
		private global::System.Windows.Forms.Label label6;
	}
}
