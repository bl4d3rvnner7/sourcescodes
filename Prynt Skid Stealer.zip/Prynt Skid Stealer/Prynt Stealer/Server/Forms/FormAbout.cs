﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Bunifu.UI.WinForms;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Enums;

namespace Server.Forms
{
	// Token: 0x02000089 RID: 137
	public partial class FormAbout : Form
	{
		// Token: 0x06000413 RID: 1043 RVA: 0x00004210 File Offset: 0x00002410
		public FormAbout()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x00002239 File Offset: 0x00000439
		private void richTextBox1_TextChanged(object sender, EventArgs e)
		{
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x0000421E File Offset: 0x0000241E
		private void siticoneLabel2_Click(object sender, EventArgs e)
		{
			Process.Start("https://t.me/officialpryntsoftware");
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x0000422B File Offset: 0x0000242B
		private void siticoneLabel1_Click(object sender, EventArgs e)
		{
			Process.Start("https://t.me/flatlinestealerofficial");
		}
	}
}
