﻿namespace Server.Forms
{
	// Token: 0x02000082 RID: 130
	public partial class FormNetstat : global::System.Windows.Forms.Form
	{
		// Token: 0x060003F7 RID: 1015 RVA: 0x00004105 File Offset: 0x00002305
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060003F8 RID: 1016 RVA: 0x000217E8 File Offset: 0x0001F9E8
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			this.listView1 = new global::System.Windows.Forms.ListView();
			this.lv_id = new global::System.Windows.Forms.ColumnHeader();
			this.lv_localAddr = new global::System.Windows.Forms.ColumnHeader();
			this.lv_remoteAddr = new global::System.Windows.Forms.ColumnHeader();
			this.lv_state = new global::System.Windows.Forms.ColumnHeader();
			this.contextMenuStrip1 = new global::System.Windows.Forms.ContextMenuStrip(this.components);
			this.killToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.refreshToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.contextMenuStrip1.SuspendLayout();
			base.SuspendLayout();
			this.listView1.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.listView1.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
			{
				this.lv_id,
				this.lv_localAddr,
				this.lv_remoteAddr,
				this.lv_state
			});
			this.listView1.ContextMenuStrip = this.contextMenuStrip1;
			this.listView1.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.listView1.Enabled = false;
			this.listView1.FullRowSelect = true;
			this.listView1.GridLines = true;
			this.listView1.HeaderStyle = global::System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.listView1.HideSelection = false;
			this.listView1.Location = new global::System.Drawing.Point(0, 0);
			this.listView1.Margin = new global::System.Windows.Forms.Padding(2);
			this.listView1.Name = "listView1";
			this.listView1.ShowGroups = false;
			this.listView1.ShowItemToolTips = true;
			this.listView1.Size = new global::System.Drawing.Size(545, 375);
			this.listView1.Sorting = global::System.Windows.Forms.SortOrder.Ascending;
			this.listView1.TabIndex = 0;
			this.listView1.UseCompatibleStateImageBehavior = false;
			this.listView1.View = global::System.Windows.Forms.View.Details;
			this.lv_id.Text = "ID";
			this.lv_id.Width = 92;
			this.lv_localAddr.Text = "LocalAddress";
			this.lv_localAddr.Width = 161;
			this.lv_remoteAddr.Text = "RemoteAddress";
			this.lv_remoteAddr.Width = 177;
			this.lv_state.Text = "State";
			this.lv_state.Width = 110;
			this.contextMenuStrip1.ImageScalingSize = new global::System.Drawing.Size(24, 24);
			this.contextMenuStrip1.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.killToolStripMenuItem,
				this.refreshToolStripMenuItem
			});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new global::System.Drawing.Size(114, 48);
			this.killToolStripMenuItem.Name = "killToolStripMenuItem";
			this.killToolStripMenuItem.Size = new global::System.Drawing.Size(113, 22);
			this.killToolStripMenuItem.Text = "Kill";
			this.killToolStripMenuItem.Click += new global::System.EventHandler(this.killToolStripMenuItem_Click);
			this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
			this.refreshToolStripMenuItem.Size = new global::System.Drawing.Size(113, 22);
			this.refreshToolStripMenuItem.Text = "Refresh";
			this.refreshToolStripMenuItem.Click += new global::System.EventHandler(this.refreshToolStripMenuItem_Click);
			this.timer1.Interval = 1000;
			this.timer1.Tick += new global::System.EventHandler(this.timer1_Tick);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(545, 375);
			base.Controls.Add(this.listView1);
			base.Margin = new global::System.Windows.Forms.Padding(2);
			base.Name = "FormNetstat";
			this.Text = "Netstat";
			base.FormClosed += new global::System.Windows.Forms.FormClosedEventHandler(this.FormNetstat_FormClosed);
			this.contextMenuStrip1.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		// Token: 0x040002AC RID: 684
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040002AD RID: 685
		private global::System.Windows.Forms.ColumnHeader lv_id;

		// Token: 0x040002AE RID: 686
		public global::System.Windows.Forms.ListView listView1;

		// Token: 0x040002AF RID: 687
		private global::System.Windows.Forms.ContextMenuStrip contextMenuStrip1;

		// Token: 0x040002B0 RID: 688
		private global::System.Windows.Forms.ToolStripMenuItem killToolStripMenuItem;

		// Token: 0x040002B1 RID: 689
		private global::System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;

		// Token: 0x040002B2 RID: 690
		public global::System.Windows.Forms.Timer timer1;

		// Token: 0x040002B3 RID: 691
		private global::System.Windows.Forms.ColumnHeader lv_localAddr;

		// Token: 0x040002B4 RID: 692
		private global::System.Windows.Forms.ColumnHeader lv_remoteAddr;

		// Token: 0x040002B5 RID: 693
		private global::System.Windows.Forms.ColumnHeader lv_state;
	}
}
