﻿namespace Server.Forms
{
	// Token: 0x02000091 RID: 145
	public partial class FormChat : global::System.Windows.Forms.Form
	{
		// Token: 0x0600045B RID: 1115 RVA: 0x00004497 File Offset: 0x00002697
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x0002A048 File Offset: 0x00028248
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Server.Forms.FormChat));
			this.richTextBox1 = new global::System.Windows.Forms.RichTextBox();
			this.textBox1 = new global::System.Windows.Forms.TextBox();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.button1 = new global::System.Windows.Forms.Button();
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.label1 = new global::System.Windows.Forms.Label();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			base.SuspendLayout();
			this.richTextBox1.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.richTextBox1.BackColor = global::System.Drawing.Color.Black;
			this.richTextBox1.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.richTextBox1.CausesValidation = false;
			this.richTextBox1.Cursor = global::System.Windows.Forms.Cursors.IBeam;
			this.richTextBox1.Font = new global::System.Drawing.Font("SimSun", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.richTextBox1.ForeColor = global::System.Drawing.Color.White;
			this.richTextBox1.Location = new global::System.Drawing.Point(11, 12);
			this.richTextBox1.Margin = new global::System.Windows.Forms.Padding(2);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.ReadOnly = true;
			this.richTextBox1.Size = new global::System.Drawing.Size(364, 293);
			this.richTextBox1.TabIndex = 3;
			this.richTextBox1.Text = "";
			this.textBox1.Anchor = global::System.Windows.Forms.AnchorStyles.Top;
			this.textBox1.BackColor = global::System.Drawing.Color.Black;
			this.textBox1.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.textBox1.Enabled = false;
			this.textBox1.Font = new global::System.Drawing.Font("SimSun", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.textBox1.ForeColor = global::System.Drawing.Color.White;
			this.textBox1.Location = new global::System.Drawing.Point(11, 310);
			this.textBox1.Margin = new global::System.Windows.Forms.Padding(2);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new global::System.Drawing.Size(483, 172);
			this.textBox1.TabIndex = 0;
			this.timer1.Interval = 1000;
			this.timer1.Tick += new global::System.EventHandler(this.Timer1_Tick);
			this.button1.Location = new global::System.Drawing.Point(415, 453);
			this.button1.Name = "button1";
			this.button1.Size = new global::System.Drawing.Size(78, 28);
			this.button1.TabIndex = 2;
			this.button1.Text = "Send";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.pictureBox1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			this.pictureBox1.Location = new global::System.Drawing.Point(380, 13);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new global::System.Drawing.Size(114, 124);
			this.pictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 3;
			this.pictureBox1.TabStop = false;
			this.label1.AutoSize = true;
			this.label1.BackColor = global::System.Drawing.Color.Transparent;
			this.label1.Font = new global::System.Drawing.Font("Cooper Black", 15f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label1.ForeColor = global::System.Drawing.Color.White;
			this.label1.Location = new global::System.Drawing.Point(381, 180);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(118, 69);
			this.label1.TabIndex = 4;
			this.label1.Text = "Connected\r\n\r\nChat Now!";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.SystemColors.Window;
			this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
			this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			base.ClientSize = new global::System.Drawing.Size(505, 494);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.pictureBox1);
			base.Controls.Add(this.button1);
			base.Controls.Add(this.textBox1);
			base.Controls.Add(this.richTextBox1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Margin = new global::System.Windows.Forms.Padding(2);
			base.Name = "FormChat";
			this.Text = "Chat";
			base.FormClosed += new global::System.Windows.Forms.FormClosedEventHandler(this.FormChat_FormClosed);
			base.Load += new global::System.EventHandler(this.FormChat_Load);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400035E RID: 862
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400035F RID: 863
		public global::System.Windows.Forms.RichTextBox richTextBox1;

		// Token: 0x04000360 RID: 864
		public global::System.Windows.Forms.Timer timer1;

		// Token: 0x04000361 RID: 865
		public global::System.Windows.Forms.TextBox textBox1;

		// Token: 0x04000362 RID: 866
		private global::System.Windows.Forms.Button button1;

		// Token: 0x04000363 RID: 867
		private global::System.Windows.Forms.PictureBox pictureBox1;

		// Token: 0x04000364 RID: 868
		private global::System.Windows.Forms.Label label1;
	}
}
