﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Server.Connection;
using Server.MessagePack;

namespace Server.Forms
{
	// Token: 0x02000098 RID: 152
	public partial class FormProcessManager : Form
	{
		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x060004A1 RID: 1185 RVA: 0x00004704 File Offset: 0x00002904
		// (set) Token: 0x060004A2 RID: 1186 RVA: 0x0000470C File Offset: 0x0000290C
		public Form1 F { get; set; }

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x060004A3 RID: 1187 RVA: 0x00004715 File Offset: 0x00002915
		// (set) Token: 0x060004A4 RID: 1188 RVA: 0x0000471D File Offset: 0x0000291D
		internal Clients Client { get; set; }

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x060004A5 RID: 1189 RVA: 0x00004726 File Offset: 0x00002926
		// (set) Token: 0x060004A6 RID: 1190 RVA: 0x0000472E File Offset: 0x0000292E
		internal Clients ParentClient { get; set; }

		// Token: 0x060004A7 RID: 1191 RVA: 0x00004737 File Offset: 0x00002937
		public FormProcessManager()
		{
			this.InitializeComponent();
		}

		// Token: 0x060004A8 RID: 1192 RVA: 0x0002F18C File Offset: 0x0002D38C
		private void timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				if (!this.Client.TcpClient.Connected || !this.ParentClient.TcpClient.Connected)
				{
					base.Close();
				}
			}
			catch
			{
				base.Close();
			}
		}

		// Token: 0x060004A9 RID: 1193 RVA: 0x0002F1E0 File Offset: 0x0002D3E0
		private void killToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FormProcessManager.<killToolStripMenuItem_Click>d__14 <killToolStripMenuItem_Click>d__;
			<killToolStripMenuItem_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<killToolStripMenuItem_Click>d__.<>4__this = this;
			<killToolStripMenuItem_Click>d__.<>1__state = -1;
			<killToolStripMenuItem_Click>d__.<>t__builder.Start<FormProcessManager.<killToolStripMenuItem_Click>d__14>(ref <killToolStripMenuItem_Click>d__);
		}

		// Token: 0x060004AA RID: 1194 RVA: 0x00004745 File Offset: 0x00002945
		private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ThreadPool.QueueUserWorkItem(delegate(object o)
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "processManager";
				msgPack.ForcePathObject("Option").AsString = "List";
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			});
		}

		// Token: 0x060004AB RID: 1195 RVA: 0x0002F218 File Offset: 0x0002D418
		private void FormProcessManager_FormClosed(object sender, FormClosedEventArgs e)
		{
			try
			{
				ThreadPool.QueueUserWorkItem(delegate(object o)
				{
					Clients client = this.Client;
					if (client == null)
					{
						return;
					}
					client.Disconnected();
				});
			}
			catch
			{
			}
		}
	}
}
