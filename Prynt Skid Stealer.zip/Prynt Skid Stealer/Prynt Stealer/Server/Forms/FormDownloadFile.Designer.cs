﻿namespace Server.Forms
{
	// Token: 0x0200009C RID: 156
	public partial class FormDownloadFile : global::System.Windows.Forms.Form
	{
		// Token: 0x060004D9 RID: 1241 RVA: 0x000048B3 File Offset: 0x00002AB3
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060004DA RID: 1242 RVA: 0x00031214 File Offset: 0x0002F414
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Server.Forms.FormDownloadFile));
			this.label1 = new global::System.Windows.Forms.Label();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.labelsize = new global::System.Windows.Forms.Label();
			this.label3 = new global::System.Windows.Forms.Label();
			this.labelfile = new global::System.Windows.Forms.Label();
			base.SuspendLayout();
			this.label1.AutoSize = true;
			this.label1.BackColor = global::System.Drawing.Color.Transparent;
			this.label1.ForeColor = global::System.Drawing.Color.White;
			this.label1.Location = new global::System.Drawing.Point(8, 59);
			this.label1.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(64, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Downloaad:";
			this.timer1.Interval = 1000;
			this.timer1.Tick += new global::System.EventHandler(this.timer1_Tick);
			this.labelsize.AutoSize = true;
			this.labelsize.BackColor = global::System.Drawing.Color.Transparent;
			this.labelsize.ForeColor = global::System.Drawing.Color.White;
			this.labelsize.Location = new global::System.Drawing.Point(69, 59);
			this.labelsize.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.labelsize.Name = "labelsize";
			this.labelsize.Size = new global::System.Drawing.Size(13, 13);
			this.labelsize.TabIndex = 0;
			this.labelsize.Text = "..";
			this.label3.AutoSize = true;
			this.label3.BackColor = global::System.Drawing.Color.Transparent;
			this.label3.ForeColor = global::System.Drawing.Color.White;
			this.label3.Location = new global::System.Drawing.Point(8, 25);
			this.label3.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(26, 13);
			this.label3.TabIndex = 0;
			this.label3.Text = "File:";
			this.labelfile.AutoSize = true;
			this.labelfile.BackColor = global::System.Drawing.Color.Transparent;
			this.labelfile.ForeColor = global::System.Drawing.Color.White;
			this.labelfile.Location = new global::System.Drawing.Point(69, 25);
			this.labelfile.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.labelfile.Name = "labelfile";
			this.labelfile.Size = new global::System.Drawing.Size(13, 13);
			this.labelfile.TabIndex = 0;
			this.labelfile.Text = "..";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
			this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			base.ClientSize = new global::System.Drawing.Size(410, 99);
			base.Controls.Add(this.labelfile);
			base.Controls.Add(this.labelsize);
			base.Controls.Add(this.label3);
			base.Controls.Add(this.label1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Margin = new global::System.Windows.Forms.Padding(2);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "FormDownloadFile";
			this.Text = "Download";
			base.FormClosed += new global::System.Windows.Forms.FormClosedEventHandler(this.SocketDownload_FormClosed);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000405 RID: 1029
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000406 RID: 1030
		public global::System.Windows.Forms.Timer timer1;

		// Token: 0x04000407 RID: 1031
		public global::System.Windows.Forms.Label labelsize;

		// Token: 0x04000408 RID: 1032
		private global::System.Windows.Forms.Label label3;

		// Token: 0x04000409 RID: 1033
		public global::System.Windows.Forms.Label labelfile;

		// Token: 0x0400040A RID: 1034
		public global::System.Windows.Forms.Label label1;
	}
}
