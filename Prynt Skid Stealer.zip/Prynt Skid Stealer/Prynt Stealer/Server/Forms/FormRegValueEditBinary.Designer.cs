﻿namespace Server.Forms
{
	// Token: 0x02000081 RID: 129
	public partial class FormRegValueEditBinary : global::System.Windows.Forms.Form
	{
		// Token: 0x060003EA RID: 1002 RVA: 0x00004091 File Offset: 0x00002291
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060003EB RID: 1003 RVA: 0x0002132C File Offset: 0x0001F52C
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Server.Forms.FormRegValueEditBinary));
			this.cancelButton = new global::System.Windows.Forms.Button();
			this.okButton = new global::System.Windows.Forms.Button();
			this.label2 = new global::System.Windows.Forms.Label();
			this.valueNameTxtBox = new global::System.Windows.Forms.TextBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.hexEditor = new global::Server.Helper.HexEditor.HexEditor();
			base.SuspendLayout();
			this.cancelButton.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.cancelButton.DialogResult = global::System.Windows.Forms.DialogResult.Cancel;
			this.cancelButton.Location = new global::System.Drawing.Point(280, 262);
			this.cancelButton.Name = "cancelButton";
			this.cancelButton.Size = new global::System.Drawing.Size(75, 23);
			this.cancelButton.TabIndex = 6;
			this.cancelButton.Text = "Cancel";
			this.cancelButton.UseVisualStyleBackColor = true;
			this.okButton.DialogResult = global::System.Windows.Forms.DialogResult.OK;
			this.okButton.Location = new global::System.Drawing.Point(188, 262);
			this.okButton.Name = "okButton";
			this.okButton.Size = new global::System.Drawing.Size(75, 23);
			this.okButton.TabIndex = 5;
			this.okButton.Text = "OK";
			this.okButton.UseVisualStyleBackColor = true;
			this.okButton.Click += new global::System.EventHandler(this.okButton_Click);
			this.label2.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.label2.AutoSize = true;
			this.label2.Location = new global::System.Drawing.Point(12, 54);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(71, 12);
			this.label2.TabIndex = 7;
			this.label2.Text = "Value data:";
			this.label2.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.valueNameTxtBox.Anchor = global::System.Windows.Forms.AnchorStyles.Left;
			this.valueNameTxtBox.Location = new global::System.Drawing.Point(14, 30);
			this.valueNameTxtBox.Name = "valueNameTxtBox";
			this.valueNameTxtBox.ReadOnly = true;
			this.valueNameTxtBox.Size = new global::System.Drawing.Size(341, 21);
			this.valueNameTxtBox.TabIndex = 8;
			this.label1.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(12, 15);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(71, 12);
			this.label1.TabIndex = 9;
			this.label1.Text = "Value name:";
			this.label1.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.hexEditor.BorderColor = global::System.Drawing.Color.Empty;
			this.hexEditor.Cursor = global::System.Windows.Forms.Cursors.IBeam;
			this.hexEditor.Location = new global::System.Drawing.Point(13, 69);
			this.hexEditor.Name = "hexEditor";
			this.hexEditor.Size = new global::System.Drawing.Size(342, 187);
			this.hexEditor.TabIndex = 10;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 12f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(373, 308);
			base.Controls.Add(this.hexEditor);
			base.Controls.Add(this.cancelButton);
			base.Controls.Add(this.okButton);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.valueNameTxtBox);
			base.Controls.Add(this.label1);
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Name = "FormRegValueEditBinary";
			this.Text = "FormRegValueEditBinary";
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040002A2 RID: 674
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040002A3 RID: 675
		private global::System.Windows.Forms.Button cancelButton;

		// Token: 0x040002A4 RID: 676
		private global::System.Windows.Forms.Button okButton;

		// Token: 0x040002A5 RID: 677
		private global::System.Windows.Forms.Label label2;

		// Token: 0x040002A6 RID: 678
		private global::System.Windows.Forms.TextBox valueNameTxtBox;

		// Token: 0x040002A7 RID: 679
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040002A8 RID: 680
		private global::Server.Helper.HexEditor.HexEditor hexEditor;
	}
}
