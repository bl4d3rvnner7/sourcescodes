﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Win32;
using Server.Helper;

namespace Server.Forms
{
	// Token: 0x02000087 RID: 135
	public partial class FormRegValueEditWord : Form
	{
		// Token: 0x06000407 RID: 1031 RVA: 0x000226B8 File Offset: 0x000208B8
		public FormRegValueEditWord(RegistrySeeker.RegValueData value)
		{
			this._value = value;
			this.InitializeComponent();
			this.valueNameTxtBox.Text = value.Name;
			if (value.Kind == RegistryValueKind.DWord)
			{
				this.Text = "Edit DWORD (32-bit) Value";
				this.valueDataTxtBox.Type = WordTextBox.WordType.DWORD;
				this.valueDataTxtBox.Text = Server.Helper.ByteConverter.ToUInt32(value.Data).ToString("x");
				return;
			}
			this.Text = "Edit QWORD (64-bit) Value";
			this.valueDataTxtBox.Type = WordTextBox.WordType.QWORD;
			this.valueDataTxtBox.Text = Server.Helper.ByteConverter.ToUInt64(value.Data).ToString("x");
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x00022768 File Offset: 0x00020968
		private void radioHex_CheckboxChanged(object sender, EventArgs e)
		{
			if (this.valueDataTxtBox.IsHexNumber == this.radioHexa.Checked)
			{
				return;
			}
			if (this.valueDataTxtBox.IsConversionValid() || this.IsOverridePossible())
			{
				this.valueDataTxtBox.IsHexNumber = this.radioHexa.Checked;
				return;
			}
			this.radioDecimal.Checked = true;
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x000227C8 File Offset: 0x000209C8
		private void okButton_Click(object sender, EventArgs e)
		{
			if (this.valueDataTxtBox.IsConversionValid() || this.IsOverridePossible())
			{
				this._value.Data = ((this._value.Kind == RegistryValueKind.DWord) ? Server.Helper.ByteConverter.GetBytes(this.valueDataTxtBox.UIntValue) : Server.Helper.ByteConverter.GetBytes(this.valueDataTxtBox.ULongValue));
				base.Tag = this._value;
				base.DialogResult = DialogResult.OK;
			}
			else
			{
				base.DialogResult = DialogResult.None;
			}
			base.Close();
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x000041B8 File Offset: 0x000023B8
		private DialogResult ShowWarning(string msg, string caption)
		{
			return MessageBox.Show(msg, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x00022848 File Offset: 0x00020A48
		private bool IsOverridePossible()
		{
			string msg = (this._value.Kind == RegistryValueKind.DWord) ? "The decimal value entered is greater than the maximum value of a DWORD (32-bit number). Should the value be truncated in order to continue?" : "The decimal value entered is greater than the maximum value of a QWORD (64-bit number). Should the value be truncated in order to continue?";
			return this.ShowWarning(msg, "Overflow") == DialogResult.Yes;
		}

		// Token: 0x040002CD RID: 717
		private readonly RegistrySeeker.RegValueData _value;

		// Token: 0x040002CE RID: 718
		private const string DWORD_WARNING = "The decimal value entered is greater than the maximum value of a DWORD (32-bit number). Should the value be truncated in order to continue?";

		// Token: 0x040002CF RID: 719
		private const string QWORD_WARNING = "The decimal value entered is greater than the maximum value of a QWORD (64-bit number). Should the value be truncated in order to continue?";
	}
}
