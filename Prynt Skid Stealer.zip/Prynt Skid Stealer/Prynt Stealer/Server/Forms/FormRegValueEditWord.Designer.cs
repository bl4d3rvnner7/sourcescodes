﻿namespace Server.Forms
{
	// Token: 0x02000087 RID: 135
	public partial class FormRegValueEditWord : global::System.Windows.Forms.Form
	{
		// Token: 0x0600040C RID: 1036 RVA: 0x000041C4 File Offset: 0x000023C4
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x00022880 File Offset: 0x00020A80
		private void InitializeComponent()
		{
			this.cancelButton = new global::System.Windows.Forms.Button();
			this.baseBox = new global::System.Windows.Forms.GroupBox();
			this.radioDecimal = new global::System.Windows.Forms.RadioButton();
			this.radioHexa = new global::System.Windows.Forms.RadioButton();
			this.okButton = new global::System.Windows.Forms.Button();
			this.label2 = new global::System.Windows.Forms.Label();
			this.valueNameTxtBox = new global::System.Windows.Forms.TextBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.valueDataTxtBox = new global::Server.Helper.WordTextBox();
			this.baseBox.SuspendLayout();
			base.SuspendLayout();
			this.cancelButton.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.cancelButton.DialogResult = global::System.Windows.Forms.DialogResult.Cancel;
			this.cancelButton.Location = new global::System.Drawing.Point(271, 146);
			this.cancelButton.Name = "cancelButton";
			this.cancelButton.Size = new global::System.Drawing.Size(75, 25);
			this.cancelButton.TabIndex = 12;
			this.cancelButton.Text = "Cancel";
			this.cancelButton.UseVisualStyleBackColor = true;
			this.baseBox.Controls.Add(this.radioDecimal);
			this.baseBox.Controls.Add(this.radioHexa);
			this.baseBox.Location = new global::System.Drawing.Point(190, 65);
			this.baseBox.Name = "baseBox";
			this.baseBox.Size = new global::System.Drawing.Size(156, 68);
			this.baseBox.TabIndex = 14;
			this.baseBox.TabStop = false;
			this.baseBox.Text = "Base";
			this.radioDecimal.AutoSize = true;
			this.radioDecimal.Location = new global::System.Drawing.Point(14, 43);
			this.radioDecimal.Name = "radioDecimal";
			this.radioDecimal.Size = new global::System.Drawing.Size(63, 17);
			this.radioDecimal.TabIndex = 4;
			this.radioDecimal.Text = "Decimal";
			this.radioDecimal.UseVisualStyleBackColor = true;
			this.radioHexa.AutoSize = true;
			this.radioHexa.Checked = true;
			this.radioHexa.Location = new global::System.Drawing.Point(14, 18);
			this.radioHexa.Name = "radioHexa";
			this.radioHexa.Size = new global::System.Drawing.Size(86, 17);
			this.radioHexa.TabIndex = 3;
			this.radioHexa.TabStop = true;
			this.radioHexa.Text = "Hexadecimal";
			this.radioHexa.UseVisualStyleBackColor = true;
			this.okButton.DialogResult = global::System.Windows.Forms.DialogResult.OK;
			this.okButton.Location = new global::System.Drawing.Point(190, 146);
			this.okButton.Name = "okButton";
			this.okButton.Size = new global::System.Drawing.Size(75, 25);
			this.okButton.TabIndex = 11;
			this.okButton.Text = "OK";
			this.okButton.UseVisualStyleBackColor = true;
			this.okButton.Click += new global::System.EventHandler(this.okButton_Click);
			this.label2.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.label2.AutoSize = true;
			this.label2.Location = new global::System.Drawing.Point(9, 65);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(61, 13);
			this.label2.TabIndex = 15;
			this.label2.Text = "Value data:";
			this.label2.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.valueNameTxtBox.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.valueNameTxtBox.Location = new global::System.Drawing.Point(12, 37);
			this.valueNameTxtBox.Name = "valueNameTxtBox";
			this.valueNameTxtBox.ReadOnly = true;
			this.valueNameTxtBox.Size = new global::System.Drawing.Size(334, 20);
			this.valueNameTxtBox.TabIndex = 13;
			this.label1.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(9, 20);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(66, 13);
			this.label1.TabIndex = 16;
			this.label1.Text = "Value name:";
			this.label1.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.valueDataTxtBox.IsHexNumber = false;
			this.valueDataTxtBox.Location = new global::System.Drawing.Point(13, 83);
			this.valueDataTxtBox.MaxLength = 8;
			this.valueDataTxtBox.Name = "valueDataTxtBox";
			this.valueDataTxtBox.Size = new global::System.Drawing.Size(171, 20);
			this.valueDataTxtBox.TabIndex = 17;
			this.valueDataTxtBox.Type = global::Server.Helper.WordTextBox.WordType.DWORD;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(362, 185);
			base.Controls.Add(this.valueDataTxtBox);
			base.Controls.Add(this.cancelButton);
			base.Controls.Add(this.baseBox);
			base.Controls.Add(this.okButton);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.valueNameTxtBox);
			base.Controls.Add(this.label1);
			base.Name = "FormRegValueEditWord";
			this.Text = "FormRegValueEditWord";
			this.baseBox.ResumeLayout(false);
			this.baseBox.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040002D0 RID: 720
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040002D1 RID: 721
		private global::System.Windows.Forms.Button cancelButton;

		// Token: 0x040002D2 RID: 722
		private global::System.Windows.Forms.GroupBox baseBox;

		// Token: 0x040002D3 RID: 723
		private global::System.Windows.Forms.RadioButton radioDecimal;

		// Token: 0x040002D4 RID: 724
		private global::System.Windows.Forms.RadioButton radioHexa;

		// Token: 0x040002D5 RID: 725
		private global::System.Windows.Forms.Button okButton;

		// Token: 0x040002D6 RID: 726
		private global::System.Windows.Forms.Label label2;

		// Token: 0x040002D7 RID: 727
		private global::System.Windows.Forms.TextBox valueNameTxtBox;

		// Token: 0x040002D8 RID: 728
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040002D9 RID: 729
		private global::Server.Helper.WordTextBox valueDataTxtBox;
	}
}
