﻿namespace Server.Forms
{
	// Token: 0x0200008A RID: 138
	public partial class FormAudio : global::System.Windows.Forms.Form
	{
		// Token: 0x06000424 RID: 1060 RVA: 0x000042C2 File Offset: 0x000024C2
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x0002407C File Offset: 0x0002227C
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Server.Forms.FormAudio));
			this.btnStartStopRecord = new global::System.Windows.Forms.Button();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.textBox1 = new global::System.Windows.Forms.TextBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.bunifuGradientPanel3 = new global::Bunifu.UI.WinForms.BunifuGradientPanel();
			this.label11 = new global::System.Windows.Forms.Label();
			this.label12 = new global::System.Windows.Forms.Label();
			this.siticoneCircleButton3 = new global::Siticone.UI.WinForms.SiticoneCircleButton();
			this.label13 = new global::System.Windows.Forms.Label();
			this.label14 = new global::System.Windows.Forms.Label();
			this.label15 = new global::System.Windows.Forms.Label();
			this.bunifuGradientPanel3.SuspendLayout();
			base.SuspendLayout();
			this.btnStartStopRecord.Location = new global::System.Drawing.Point(34, 87);
			this.btnStartStopRecord.Name = "btnStartStopRecord";
			this.btnStartStopRecord.Size = new global::System.Drawing.Size(297, 23);
			this.btnStartStopRecord.TabIndex = 0;
			this.btnStartStopRecord.Text = "Start Recording";
			this.btnStartStopRecord.UseVisualStyleBackColor = true;
			this.btnStartStopRecord.Click += new global::System.EventHandler(this.btnStartStopRecord_Click);
			this.timer1.Tick += new global::System.EventHandler(this.timer1_Tick);
			this.textBox1.Location = new global::System.Drawing.Point(34, 34);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new global::System.Drawing.Size(244, 20);
			this.textBox1.TabIndex = 2;
			this.textBox1.Text = "10";
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(284, 37);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(47, 13);
			this.label1.TabIndex = 3;
			this.label1.Text = "seconds";
			this.bunifuGradientPanel3.BackColor = global::System.Drawing.Color.Transparent;
			this.bunifuGradientPanel3.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("bunifuGradientPanel3.BackgroundImage");
			this.bunifuGradientPanel3.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.bunifuGradientPanel3.BorderRadius = 1;
			this.bunifuGradientPanel3.Controls.Add(this.label11);
			this.bunifuGradientPanel3.Controls.Add(this.label1);
			this.bunifuGradientPanel3.Controls.Add(this.label12);
			this.bunifuGradientPanel3.Controls.Add(this.textBox1);
			this.bunifuGradientPanel3.Controls.Add(this.btnStartStopRecord);
			this.bunifuGradientPanel3.Controls.Add(this.siticoneCircleButton3);
			this.bunifuGradientPanel3.Controls.Add(this.label13);
			this.bunifuGradientPanel3.Controls.Add(this.label14);
			this.bunifuGradientPanel3.Controls.Add(this.label15);
			this.bunifuGradientPanel3.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.bunifuGradientPanel3.GradientBottomLeft = global::System.Drawing.Color.DodgerBlue;
			this.bunifuGradientPanel3.GradientBottomRight = global::System.Drawing.Color.DodgerBlue;
			this.bunifuGradientPanel3.GradientTopLeft = global::System.Drawing.Color.Navy;
			this.bunifuGradientPanel3.GradientTopRight = global::System.Drawing.Color.Navy;
			this.bunifuGradientPanel3.Location = new global::System.Drawing.Point(0, 0);
			this.bunifuGradientPanel3.Name = "bunifuGradientPanel3";
			this.bunifuGradientPanel3.Quality = 10;
			this.bunifuGradientPanel3.Size = new global::System.Drawing.Size(423, 146);
			this.bunifuGradientPanel3.TabIndex = 4;
			this.label11.AutoSize = true;
			this.label11.BackColor = global::System.Drawing.Color.Transparent;
			this.label11.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label11.ForeColor = global::System.Drawing.Color.White;
			this.label11.Location = new global::System.Drawing.Point(157, 377);
			this.label11.Name = "label11";
			this.label11.Size = new global::System.Drawing.Size(159, 48);
			this.label11.TabIndex = 24;
			this.label11.Text = "@FlatLineStealerOfficial\r\n@youhacker55\r\n@thisIsDali";
			this.label12.AutoSize = true;
			this.label12.BackColor = global::System.Drawing.Color.Transparent;
			this.label12.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label12.ForeColor = global::System.Drawing.Color.White;
			this.label12.Location = new global::System.Drawing.Point(31, 392);
			this.label12.Name = "label12";
			this.label12.Size = new global::System.Drawing.Size(120, 16);
			this.label12.TabIndex = 23;
			this.label12.Text = "Ouner and Devs : ";
			this.siticoneCircleButton3.CheckedState.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.CustomImages.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneCircleButton3.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.siticoneCircleButton3.ForeColor = global::System.Drawing.Color.White;
			this.siticoneCircleButton3.HoveredState.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.Location = new global::System.Drawing.Point(141, 339);
			this.siticoneCircleButton3.Name = "siticoneCircleButton3";
			this.siticoneCircleButton3.ShadowDecoration.Mode = global::Siticone.UI.WinForms.Enums.ShadowMode.Circle;
			this.siticoneCircleButton3.ShadowDecoration.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.Size = new global::System.Drawing.Size(223, 26);
			this.siticoneCircleButton3.TabIndex = 22;
			this.siticoneCircleButton3.Text = "https://t.me/officialpryntsoftware";
			this.label13.AutoSize = true;
			this.label13.BackColor = global::System.Drawing.Color.Transparent;
			this.label13.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label13.ForeColor = global::System.Drawing.Color.White;
			this.label13.Location = new global::System.Drawing.Point(31, 344);
			this.label13.Name = "label13";
			this.label13.Size = new global::System.Drawing.Size(106, 16);
			this.label13.TabIndex = 21;
			this.label13.Text = "Our Telegram : ";
			this.label14.AutoSize = true;
			this.label14.BackColor = global::System.Drawing.Color.Transparent;
			this.label14.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label14.ForeColor = global::System.Drawing.Color.White;
			this.label14.Location = new global::System.Drawing.Point(31, 267);
			this.label14.Name = "label14";
			this.label14.Size = new global::System.Drawing.Size(284, 32);
			this.label14.TabIndex = 20;
			this.label14.Text = "We tend to provide the best quality hacking\r\n tools for our costumers.";
			this.label15.AutoSize = true;
			this.label15.BackColor = global::System.Drawing.Color.Transparent;
			this.label15.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label15.ForeColor = global::System.Drawing.Color.White;
			this.label15.Location = new global::System.Drawing.Point(31, 239);
			this.label15.Name = "label15";
			this.label15.Size = new global::System.Drawing.Size(309, 16);
			this.label15.TabIndex = 19;
			this.label15.Text = "Citizen of the world we are Prynt Stealer Team.\r\n";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(423, 146);
			base.Controls.Add(this.bunifuGradientPanel3);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximumSize = new global::System.Drawing.Size(439, 185);
			this.MinimumSize = new global::System.Drawing.Size(439, 185);
			base.Name = "FormAudio";
			base.ShowIcon = false;
			this.Text = "Record Microphone";
			this.bunifuGradientPanel3.ResumeLayout(false);
			this.bunifuGradientPanel3.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x040002F4 RID: 756
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040002F5 RID: 757
		public global::System.Windows.Forms.Button btnStartStopRecord;

		// Token: 0x040002F6 RID: 758
		private global::System.Windows.Forms.Timer timer1;

		// Token: 0x040002F7 RID: 759
		private global::System.Windows.Forms.TextBox textBox1;

		// Token: 0x040002F8 RID: 760
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040002F9 RID: 761
		private global::Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel3;

		// Token: 0x040002FA RID: 762
		private global::System.Windows.Forms.Label label11;

		// Token: 0x040002FB RID: 763
		private global::System.Windows.Forms.Label label12;

		// Token: 0x040002FC RID: 764
		private global::Siticone.UI.WinForms.SiticoneCircleButton siticoneCircleButton3;

		// Token: 0x040002FD RID: 765
		private global::System.Windows.Forms.Label label13;

		// Token: 0x040002FE RID: 766
		private global::System.Windows.Forms.Label label14;

		// Token: 0x040002FF RID: 767
		private global::System.Windows.Forms.Label label15;
	}
}
