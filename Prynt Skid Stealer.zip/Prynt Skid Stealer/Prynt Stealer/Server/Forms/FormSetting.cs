﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Server.Properties;

namespace Server.Forms
{
	// Token: 0x02000088 RID: 136
	public partial class FormSetting : Form
	{
		// Token: 0x0600040E RID: 1038 RVA: 0x000041E3 File Offset: 0x000023E3
		public FormSetting()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x00022E34 File Offset: 0x00021034
		private void button1_Click(object sender, EventArgs e)
		{
			if (this.checkBox1.Checked && (this.textBox1.Text == null || this.textBox2.Text == null))
			{
				MessageBox.Show("Input the WebHook and secret");
			}
			Settings.Default.DingDing = this.checkBox1.Checked;
			Settings.Default.WebHook = this.textBox1.Text;
			Settings.Default.Secret = this.textBox2.Text;
			Settings.Default.Save();
			base.Close();
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x00022EC4 File Offset: 0x000210C4
		private void FormSetting_Load(object sender, EventArgs e)
		{
			this.checkBox1.Checked = Settings.Default.DingDing;
			this.textBox1.Text = Settings.Default.WebHook;
			this.textBox2.Text = Settings.Default.Secret;
		}
	}
}
