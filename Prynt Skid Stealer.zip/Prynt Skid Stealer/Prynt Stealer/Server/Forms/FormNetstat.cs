﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Server.Connection;
using Server.MessagePack;

namespace Server.Forms
{
	// Token: 0x02000082 RID: 130
	public partial class FormNetstat : Form
	{
		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x060003EC RID: 1004 RVA: 0x000040B0 File Offset: 0x000022B0
		// (set) Token: 0x060003ED RID: 1005 RVA: 0x000040B8 File Offset: 0x000022B8
		public Form1 F { get; set; }

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x060003EE RID: 1006 RVA: 0x000040C1 File Offset: 0x000022C1
		// (set) Token: 0x060003EF RID: 1007 RVA: 0x000040C9 File Offset: 0x000022C9
		internal Clients Client { get; set; }

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x060003F0 RID: 1008 RVA: 0x000040D2 File Offset: 0x000022D2
		// (set) Token: 0x060003F1 RID: 1009 RVA: 0x000040DA File Offset: 0x000022DA
		internal Clients ParentClient { get; set; }

		// Token: 0x060003F2 RID: 1010 RVA: 0x000040E3 File Offset: 0x000022E3
		public FormNetstat()
		{
			this.InitializeComponent();
		}

		// Token: 0x060003F3 RID: 1011 RVA: 0x00021728 File Offset: 0x0001F928
		private void timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				if (!this.Client.TcpClient.Connected || !this.ParentClient.TcpClient.Connected)
				{
					base.Close();
				}
			}
			catch
			{
				base.Close();
			}
		}

		// Token: 0x060003F4 RID: 1012 RVA: 0x0002177C File Offset: 0x0001F97C
		private void killToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FormNetstat.<killToolStripMenuItem_Click>d__14 <killToolStripMenuItem_Click>d__;
			<killToolStripMenuItem_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<killToolStripMenuItem_Click>d__.<>4__this = this;
			<killToolStripMenuItem_Click>d__.<>1__state = -1;
			<killToolStripMenuItem_Click>d__.<>t__builder.Start<FormNetstat.<killToolStripMenuItem_Click>d__14>(ref <killToolStripMenuItem_Click>d__);
		}

		// Token: 0x060003F5 RID: 1013 RVA: 0x000040F1 File Offset: 0x000022F1
		private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
		{
			ThreadPool.QueueUserWorkItem(delegate(object o)
			{
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "Netstat";
				msgPack.ForcePathObject("Option").AsString = "List";
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
			});
		}

		// Token: 0x060003F6 RID: 1014 RVA: 0x000217B4 File Offset: 0x0001F9B4
		private void FormNetstat_FormClosed(object sender, FormClosedEventArgs e)
		{
			try
			{
				ThreadPool.QueueUserWorkItem(delegate(object o)
				{
					Clients client = this.Client;
					if (client == null)
					{
						return;
					}
					client.Disconnected();
				});
			}
			catch
			{
			}
		}
	}
}
