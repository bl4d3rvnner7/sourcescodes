﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms;

namespace Server.Forms
{
	// Token: 0x0200008E RID: 142
	public partial class FormCertificate : Form
	{
		// Token: 0x06000445 RID: 1093 RVA: 0x000043F4 File Offset: 0x000025F4
		public FormCertificate()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x0002972C File Offset: 0x0002792C
		private void FormCertificate_Load(object sender, EventArgs e)
		{
			try
			{
				string text = Application.StartupPath + "\\BackupCertificate.zip";
				if (File.Exists(text))
				{
					MessageBox.Show(this, "Found a zip backup, Extracting (BackupCertificate.zip)", "Certificate backup", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					ZipFile.ExtractToDirectory(text, Application.StartupPath);
					Settings.ServerCertificate = new X509Certificate2(Settings.CertificatePath);
					base.Close();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(this, ex.Message, "Certificate", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		// Token: 0x06000447 RID: 1095 RVA: 0x000297B0 File Offset: 0x000279B0
		private void Button1_Click(object sender, EventArgs e)
		{
			FormCertificate.<Button1_Click>d__2 <Button1_Click>d__;
			<Button1_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Button1_Click>d__.<>4__this = this;
			<Button1_Click>d__.<>1__state = -1;
			<Button1_Click>d__.<>t__builder.Start<FormCertificate.<Button1_Click>d__2>(ref <Button1_Click>d__);
		}
	}
}
