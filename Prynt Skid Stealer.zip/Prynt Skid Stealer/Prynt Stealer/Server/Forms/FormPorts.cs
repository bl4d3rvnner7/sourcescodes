﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms;
using Server.Helper;
using Server.Properties;

namespace Server.Forms
{
	// Token: 0x02000097 RID: 151
	public partial class FormPorts : Form
	{
		// Token: 0x06000499 RID: 1177 RVA: 0x0000468D File Offset: 0x0000288D
		public FormPorts()
		{
			this.InitializeComponent();
			base.Opacity = 0.0;
		}

		// Token: 0x0600049A RID: 1178 RVA: 0x0002E998 File Offset: 0x0002CB98
		private void PortsFrm_Load(object sender, EventArgs e)
		{
			Methods.FadeIn(this, 5);
			if (Settings.Default.Ports.Length == 0)
			{
				this.listBox1.Items.AddRange(new object[]
				{
					"8848"
				});
			}
			else
			{
				try
				{
					foreach (string text in Settings.Default.Ports.Split(new string[]
					{
						","
					}, StringSplitOptions.None))
					{
						if (!string.IsNullOrWhiteSpace(text))
						{
							this.listBox1.Items.Add(text.Trim());
						}
					}
				}
				catch
				{
				}
			}
			this.Text = Settings.Version + " | Welcome " + Environment.UserName;
			if (!File.Exists(Settings.CertificatePath))
			{
				using (FormCertificate formCertificate = new FormCertificate())
				{
					formCertificate.ShowDialog();
					return;
				}
			}
			Settings.ServerCertificate = new X509Certificate2(Settings.CertificatePath);
		}

		// Token: 0x0600049B RID: 1179 RVA: 0x0002EAA0 File Offset: 0x0002CCA0
		private void button1_Click(object sender, EventArgs e)
		{
			if (this.listBox1.Items.Count > 0)
			{
				string text = "";
				foreach (object obj in this.listBox1.Items)
				{
					string str = (string)obj;
					text = text + str + ",";
				}
				Settings.Default.Ports = text.Remove(text.Length - 1);
				Settings.Default.Save();
				FormPorts.isOK = true;
				base.Close();
			}
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x000046AA File Offset: 0x000028AA
		private void PortsFrm_FormClosed(object sender, FormClosedEventArgs e)
		{
			if (!FormPorts.isOK)
			{
				Program.form1.notifyIcon1.Dispose();
				Environment.Exit(0);
			}
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x0002EB4C File Offset: 0x0002CD4C
		private void BtnAdd_Click(object sender, EventArgs e)
		{
			try
			{
				Convert.ToInt32(this.textPorts.Text.Trim());
				this.listBox1.Items.Add(this.textPorts.Text.Trim());
				this.textPorts.Clear();
			}
			catch
			{
			}
		}

		// Token: 0x0600049E RID: 1182 RVA: 0x000046C8 File Offset: 0x000028C8
		private void BtnDelete_Click(object sender, EventArgs e)
		{
			this.listBox1.Items.Remove(this.listBox1.SelectedItem);
		}

		// Token: 0x040003C2 RID: 962
		private static bool isOK;
	}
}
