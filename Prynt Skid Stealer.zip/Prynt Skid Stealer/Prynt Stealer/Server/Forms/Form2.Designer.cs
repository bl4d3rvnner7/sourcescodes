﻿namespace Server.Forms
{
	// Token: 0x0200007F RID: 127
	public partial class Form2 : global::System.Windows.Forms.Form
	{
		// Token: 0x060003C5 RID: 965 RVA: 0x00003FA3 File Offset: 0x000021A3
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x0001E2C4 File Offset: 0x0001C4C4
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::Siticone.UI.AnimatorNS.Animation animation = new global::Siticone.UI.AnimatorNS.Animation();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Server.Forms.Form2));
			this.subscriptionDaysLabel = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.siticoneLabel1 = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.customerPanelLink = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.version = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.numKeys = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.numOnlineUsers = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.numUsers = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.lastLogin = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.createDate = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.hwid = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.ip = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.subscription = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.expiry = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.key = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.siticoneDragControl1 = new global::Siticone.UI.WinForms.SiticoneDragControl(this.components);
			this.siticoneTransition1 = new global::Siticone.UI.WinForms.SiticoneTransition();
			this.siticoneShadowForm = new global::Siticone.UI.WinForms.SiticoneShadowForm(this.components);
			this.dataGridView1 = new global::System.Windows.Forms.DataGridView();
			this.Sender = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Message = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Time = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.chatmsg = new global::Siticone.UI.WinForms.SiticoneRoundedTextBox();
			this.sendmsg = new global::Siticone.UI.WinForms.SiticoneRoundedButton();
			((global::System.ComponentModel.ISupportInitialize)this.dataGridView1).BeginInit();
			base.SuspendLayout();
			this.subscriptionDaysLabel.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneTransition1.SetDecoration(this.subscriptionDaysLabel, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.subscriptionDaysLabel.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.subscriptionDaysLabel.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.subscriptionDaysLabel.Location = new global::System.Drawing.Point(22, 161);
			this.subscriptionDaysLabel.Margin = new global::System.Windows.Forms.Padding(2);
			this.subscriptionDaysLabel.Name = "subscriptionDaysLabel";
			this.subscriptionDaysLabel.Size = new global::System.Drawing.Size(105, 14);
			this.subscriptionDaysLabel.TabIndex = 66;
			this.subscriptionDaysLabel.Text = "subscriptionDaysLabel";
			this.siticoneLabel1.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneTransition1.SetDecoration(this.siticoneLabel1, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.siticoneLabel1.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.siticoneLabel1.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.siticoneLabel1.Location = new global::System.Drawing.Point(22, 142);
			this.siticoneLabel1.Margin = new global::System.Windows.Forms.Padding(2);
			this.siticoneLabel1.Name = "siticoneLabel1";
			this.siticoneLabel1.Size = new global::System.Drawing.Size(161, 14);
			this.siticoneLabel1.TabIndex = 67;
			this.siticoneLabel1.Text = "Current Session Valdiation Status: ";
			this.customerPanelLink.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneTransition1.SetDecoration(this.customerPanelLink, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.customerPanelLink.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.customerPanelLink.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.customerPanelLink.Location = new global::System.Drawing.Point(674, 22);
			this.customerPanelLink.Margin = new global::System.Windows.Forms.Padding(2);
			this.customerPanelLink.Name = "customerPanelLink";
			this.customerPanelLink.Size = new global::System.Drawing.Size(115, 14);
			this.customerPanelLink.TabIndex = 65;
			this.customerPanelLink.Text = "customerPanelLinkLabel";
			this.version.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneTransition1.SetDecoration(this.version, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.version.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.version.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.version.Location = new global::System.Drawing.Point(688, 52);
			this.version.Margin = new global::System.Windows.Forms.Padding(2);
			this.version.Name = "version";
			this.version.Size = new global::System.Drawing.Size(60, 14);
			this.version.TabIndex = 64;
			this.version.Text = "versionLabel";
			this.numKeys.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneTransition1.SetDecoration(this.numKeys, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.numKeys.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.numKeys.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.numKeys.Location = new global::System.Drawing.Point(703, 88);
			this.numKeys.Margin = new global::System.Windows.Forms.Padding(2);
			this.numKeys.Name = "numKeys";
			this.numKeys.Size = new global::System.Drawing.Size(68, 14);
			this.numKeys.TabIndex = 63;
			this.numKeys.Text = "numKeysLabel";
			this.numOnlineUsers.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneTransition1.SetDecoration(this.numOnlineUsers, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.numOnlineUsers.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.numOnlineUsers.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.numOnlineUsers.Location = new global::System.Drawing.Point(327, 31);
			this.numOnlineUsers.Margin = new global::System.Windows.Forms.Padding(2);
			this.numOnlineUsers.Name = "numOnlineUsers";
			this.numOnlineUsers.Size = new global::System.Drawing.Size(103, 14);
			this.numOnlineUsers.TabIndex = 62;
			this.numOnlineUsers.Text = "numOnlineUsersLabel";
			this.numUsers.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneTransition1.SetDecoration(this.numUsers, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.numUsers.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.numUsers.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.numUsers.Location = new global::System.Drawing.Point(327, 11);
			this.numUsers.Margin = new global::System.Windows.Forms.Padding(2);
			this.numUsers.Name = "numUsers";
			this.numUsers.Size = new global::System.Drawing.Size(72, 14);
			this.numUsers.TabIndex = 61;
			this.numUsers.Text = "numUsersLabel";
			this.lastLogin.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneTransition1.SetDecoration(this.lastLogin, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.lastLogin.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.lastLogin.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.lastLogin.Location = new global::System.Drawing.Point(688, 123);
			this.lastLogin.Margin = new global::System.Windows.Forms.Padding(2);
			this.lastLogin.Name = "lastLogin";
			this.lastLogin.Size = new global::System.Drawing.Size(69, 14);
			this.lastLogin.TabIndex = 60;
			this.lastLogin.Text = "lastLoginLabel";
			this.createDate.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneTransition1.SetDecoration(this.createDate, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.createDate.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.createDate.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.createDate.Location = new global::System.Drawing.Point(695, 105);
			this.createDate.Margin = new global::System.Windows.Forms.Padding(2);
			this.createDate.Name = "createDate";
			this.createDate.Size = new global::System.Drawing.Size(76, 14);
			this.createDate.TabIndex = 59;
			this.createDate.Text = "createDateLabel";
			this.hwid.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneTransition1.SetDecoration(this.hwid, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.hwid.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.hwid.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.hwid.Location = new global::System.Drawing.Point(22, 88);
			this.hwid.Margin = new global::System.Windows.Forms.Padding(2);
			this.hwid.Name = "hwid";
			this.hwid.Size = new global::System.Drawing.Size(50, 14);
			this.hwid.TabIndex = 58;
			this.hwid.Text = "hwidLabel";
			this.ip.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneTransition1.SetDecoration(this.ip, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.ip.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ip.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.ip.Location = new global::System.Drawing.Point(22, 70);
			this.ip.Margin = new global::System.Windows.Forms.Padding(2);
			this.ip.Name = "ip";
			this.ip.Size = new global::System.Drawing.Size(36, 14);
			this.ip.TabIndex = 57;
			this.ip.Text = "ipLabel";
			this.subscription.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneTransition1.SetDecoration(this.subscription, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.subscription.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.subscription.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.subscription.Location = new global::System.Drawing.Point(22, 52);
			this.subscription.Margin = new global::System.Windows.Forms.Padding(2);
			this.subscription.Name = "subscription";
			this.subscription.Size = new global::System.Drawing.Size(84, 14);
			this.subscription.TabIndex = 56;
			this.subscription.Text = "subscriptionLabel";
			this.expiry.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneTransition1.SetDecoration(this.expiry, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.expiry.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.expiry.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.expiry.Location = new global::System.Drawing.Point(22, 31);
			this.expiry.Margin = new global::System.Windows.Forms.Padding(2);
			this.expiry.Name = "expiry";
			this.expiry.Size = new global::System.Drawing.Size(56, 14);
			this.expiry.TabIndex = 55;
			this.expiry.Text = "expiryLabel";
			this.key.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneTransition1.SetDecoration(this.key, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.key.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.key.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.key.Location = new global::System.Drawing.Point(22, 11);
			this.key.Margin = new global::System.Windows.Forms.Padding(2);
			this.key.Name = "key";
			this.key.Size = new global::System.Drawing.Size(71, 14);
			this.key.TabIndex = 54;
			this.key.Text = "usernameLabel";
			this.timer1.Enabled = true;
			this.timer1.Interval = 1;
			this.timer1.Tick += new global::System.EventHandler(this.timer1_Tick);
			this.siticoneDragControl1.TargetControl = null;
			this.siticoneTransition1.AnimationType = global::Siticone.UI.AnimatorNS.AnimationType.Rotate;
			this.siticoneTransition1.Cursor = null;
			animation.AnimateOnlyDifferences = true;
			animation.BlindCoeff = (global::System.Drawing.PointF)componentResourceManager.GetObject("animation4.BlindCoeff");
			animation.LeafCoeff = 0f;
			animation.MaxTime = 1f;
			animation.MinTime = 0f;
			animation.MosaicCoeff = (global::System.Drawing.PointF)componentResourceManager.GetObject("animation4.MosaicCoeff");
			animation.MosaicShift = (global::System.Drawing.PointF)componentResourceManager.GetObject("animation4.MosaicShift");
			animation.MosaicSize = 0;
			animation.Padding = new global::System.Windows.Forms.Padding(50);
			animation.RotateCoeff = 1f;
			animation.RotateLimit = 0f;
			animation.ScaleCoeff = (global::System.Drawing.PointF)componentResourceManager.GetObject("animation4.ScaleCoeff");
			animation.SlideCoeff = (global::System.Drawing.PointF)componentResourceManager.GetObject("animation4.SlideCoeff");
			animation.TimeCoeff = 0f;
			animation.TransparencyCoeff = 1f;
			this.siticoneTransition1.DefaultAnimation = animation;
			this.dataGridView1.BackgroundColor = global::System.Drawing.Color.Black;
			this.dataGridView1.ColumnHeadersHeightSizeMode = global::System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Columns.AddRange(new global::System.Windows.Forms.DataGridViewColumn[]
			{
				this.Sender,
				this.Message,
				this.Time
			});
			this.siticoneTransition1.SetDecoration(this.dataGridView1, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.dataGridView1.Location = new global::System.Drawing.Point(12, 142);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.Size = new global::System.Drawing.Size(565, 192);
			this.dataGridView1.TabIndex = 68;
			this.Sender.HeaderText = "Sender";
			this.Sender.Name = "Sender";
			this.Sender.Width = 75;
			this.Message.HeaderText = "Message";
			this.Message.Name = "Message";
			this.Message.Width = 200;
			this.Time.HeaderText = "Time";
			this.Time.MaxInputLength = 50000;
			this.Time.Name = "Time";
			this.Time.Width = 175;
			this.chatmsg.AllowDrop = true;
			this.chatmsg.BorderColor = global::System.Drawing.Color.FromArgb(7, 127, 243);
			this.chatmsg.Cursor = global::System.Windows.Forms.Cursors.IBeam;
			this.siticoneTransition1.SetDecoration(this.chatmsg, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.chatmsg.DefaultText = "Your message here";
			this.chatmsg.DisabledState.BorderColor = global::System.Drawing.Color.FromArgb(208, 208, 208);
			this.chatmsg.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(226, 226, 226);
			this.chatmsg.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(138, 138, 138);
			this.chatmsg.DisabledState.Parent = this.chatmsg;
			this.chatmsg.DisabledState.PlaceholderForeColor = global::System.Drawing.Color.FromArgb(138, 138, 138);
			this.chatmsg.FillColor = global::System.Drawing.Color.FromArgb(35, 39, 42);
			this.chatmsg.FocusedState.BorderColor = global::System.Drawing.Color.FromArgb(94, 148, 255);
			this.chatmsg.FocusedState.Parent = this.chatmsg;
			this.chatmsg.HoveredState.BorderColor = global::System.Drawing.Color.FromArgb(94, 148, 255);
			this.chatmsg.HoveredState.Parent = this.chatmsg;
			this.chatmsg.Location = new global::System.Drawing.Point(13, 341);
			this.chatmsg.Margin = new global::System.Windows.Forms.Padding(4);
			this.chatmsg.Name = "chatmsg";
			this.chatmsg.PasswordChar = '\0';
			this.chatmsg.PlaceholderText = "";
			this.chatmsg.SelectedText = "";
			this.chatmsg.ShadowDecoration.Parent = this.chatmsg;
			this.chatmsg.Size = new global::System.Drawing.Size(335, 30);
			this.chatmsg.TabIndex = 70;
			this.chatmsg.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.sendmsg.BorderColor = global::System.Drawing.Color.DodgerBlue;
			this.sendmsg.BorderThickness = 1;
			this.sendmsg.CheckedState.Parent = this.sendmsg;
			this.sendmsg.CustomImages.Parent = this.sendmsg;
			this.siticoneTransition1.SetDecoration(this.sendmsg, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.sendmsg.FillColor = global::System.Drawing.Color.FromArgb(7, 127, 243);
			this.sendmsg.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.sendmsg.ForeColor = global::System.Drawing.Color.White;
			this.sendmsg.HoveredState.BorderColor = global::System.Drawing.Color.FromArgb(213, 218, 223);
			this.sendmsg.HoveredState.Parent = this.sendmsg;
			this.sendmsg.Location = new global::System.Drawing.Point(389, 341);
			this.sendmsg.Name = "sendmsg";
			this.sendmsg.ShadowDecoration.Parent = this.sendmsg;
			this.sendmsg.Size = new global::System.Drawing.Size(151, 27);
			this.sendmsg.TabIndex = 69;
			this.sendmsg.Text = "Send";
			this.sendmsg.Click += new global::System.EventHandler(this.sendmsg_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.Black;
			base.ClientSize = new global::System.Drawing.Size(611, 417);
			base.Controls.Add(this.chatmsg);
			base.Controls.Add(this.sendmsg);
			base.Controls.Add(this.dataGridView1);
			base.Controls.Add(this.subscriptionDaysLabel);
			base.Controls.Add(this.siticoneLabel1);
			base.Controls.Add(this.customerPanelLink);
			base.Controls.Add(this.version);
			base.Controls.Add(this.numKeys);
			base.Controls.Add(this.numOnlineUsers);
			base.Controls.Add(this.numUsers);
			base.Controls.Add(this.lastLogin);
			base.Controls.Add(this.createDate);
			base.Controls.Add(this.hwid);
			base.Controls.Add(this.ip);
			base.Controls.Add(this.subscription);
			base.Controls.Add(this.expiry);
			base.Controls.Add(this.key);
			this.siticoneTransition1.SetDecoration(this, global::Siticone.UI.AnimatorNS.DecorationType.None);
			this.MaximumSize = new global::System.Drawing.Size(627, 456);
			this.MinimumSize = new global::System.Drawing.Size(627, 456);
			base.Name = "Form2";
			this.Text = "Private Chat";
			base.Load += new global::System.EventHandler(this.Form2_Load);
			((global::System.ComponentModel.ISupportInitialize)this.dataGridView1).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000260 RID: 608
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000261 RID: 609
		private global::Siticone.UI.WinForms.SiticoneLabel subscriptionDaysLabel;

		// Token: 0x04000262 RID: 610
		private global::Siticone.UI.WinForms.SiticoneTransition siticoneTransition1;

		// Token: 0x04000263 RID: 611
		private global::Siticone.UI.WinForms.SiticoneLabel siticoneLabel1;

		// Token: 0x04000264 RID: 612
		private global::Siticone.UI.WinForms.SiticoneLabel customerPanelLink;

		// Token: 0x04000265 RID: 613
		private global::Siticone.UI.WinForms.SiticoneLabel version;

		// Token: 0x04000266 RID: 614
		private global::Siticone.UI.WinForms.SiticoneLabel numKeys;

		// Token: 0x04000267 RID: 615
		private global::Siticone.UI.WinForms.SiticoneLabel numOnlineUsers;

		// Token: 0x04000268 RID: 616
		private global::Siticone.UI.WinForms.SiticoneLabel numUsers;

		// Token: 0x04000269 RID: 617
		private global::Siticone.UI.WinForms.SiticoneLabel lastLogin;

		// Token: 0x0400026A RID: 618
		private global::Siticone.UI.WinForms.SiticoneLabel createDate;

		// Token: 0x0400026B RID: 619
		private global::Siticone.UI.WinForms.SiticoneLabel hwid;

		// Token: 0x0400026C RID: 620
		private global::Siticone.UI.WinForms.SiticoneLabel ip;

		// Token: 0x0400026D RID: 621
		private global::Siticone.UI.WinForms.SiticoneLabel subscription;

		// Token: 0x0400026E RID: 622
		private global::Siticone.UI.WinForms.SiticoneLabel expiry;

		// Token: 0x0400026F RID: 623
		private global::Siticone.UI.WinForms.SiticoneLabel key;

		// Token: 0x04000270 RID: 624
		private global::System.Windows.Forms.Timer timer1;

		// Token: 0x04000271 RID: 625
		private global::Siticone.UI.WinForms.SiticoneDragControl siticoneDragControl1;

		// Token: 0x04000272 RID: 626
		private global::Siticone.UI.WinForms.SiticoneShadowForm siticoneShadowForm;

		// Token: 0x04000273 RID: 627
		private global::System.Windows.Forms.DataGridView dataGridView1;

		// Token: 0x04000274 RID: 628
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Sender;

		// Token: 0x04000275 RID: 629
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Message;

		// Token: 0x04000276 RID: 630
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Time;

		// Token: 0x04000277 RID: 631
		private global::Siticone.UI.WinForms.SiticoneRoundedTextBox chatmsg;

		// Token: 0x04000278 RID: 632
		private global::Siticone.UI.WinForms.SiticoneRoundedButton sendmsg;
	}
}
