﻿namespace Server.Forms
{
	// Token: 0x02000092 RID: 146
	public partial class FormDOS : global::System.Windows.Forms.Form
	{
		// Token: 0x06000463 RID: 1123 RVA: 0x000044F0 File Offset: 0x000026F0
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x0002AA10 File Offset: 0x00028C10
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Server.Forms.FormDOS));
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.label1 = new global::System.Windows.Forms.Label();
			this.txtPort = new global::System.Windows.Forms.TextBox();
			this.txtHost = new global::System.Windows.Forms.TextBox();
			this.groupBox2 = new global::System.Windows.Forms.GroupBox();
			this.label4 = new global::System.Windows.Forms.Label();
			this.label3 = new global::System.Windows.Forms.Label();
			this.txtTimeout = new global::System.Windows.Forms.TextBox();
			this.groupBox3 = new global::System.Windows.Forms.GroupBox();
			this.radioButton4 = new global::System.Windows.Forms.RadioButton();
			this.radioButton3 = new global::System.Windows.Forms.RadioButton();
			this.radioButton2 = new global::System.Windows.Forms.RadioButton();
			this.radioButton1 = new global::System.Windows.Forms.RadioButton();
			this.btnStop = new global::System.Windows.Forms.Button();
			this.btnAttack = new global::System.Windows.Forms.Button();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.timer2 = new global::System.Windows.Forms.Timer(this.components);
			this.bunifuGradientPanel3 = new global::Bunifu.UI.WinForms.BunifuGradientPanel();
			this.label5 = new global::System.Windows.Forms.Label();
			this.label11 = new global::System.Windows.Forms.Label();
			this.label12 = new global::System.Windows.Forms.Label();
			this.siticoneCircleButton3 = new global::Siticone.UI.WinForms.SiticoneCircleButton();
			this.label13 = new global::System.Windows.Forms.Label();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.bunifuGradientPanel3.SuspendLayout();
			base.SuspendLayout();
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.txtPort);
			this.groupBox1.Controls.Add(this.txtHost);
			this.groupBox1.Location = new global::System.Drawing.Point(2, 11);
			this.groupBox1.Margin = new global::System.Windows.Forms.Padding(2);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new global::System.Windows.Forms.Padding(2);
			this.groupBox1.Size = new global::System.Drawing.Size(387, 131);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Target";
			this.label2.AutoSize = true;
			this.label2.Location = new global::System.Drawing.Point(11, 87);
			this.label2.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(37, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = "PORT";
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(11, 42);
			this.label1.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(37, 13);
			this.label1.TabIndex = 2;
			this.label1.Text = "HOST";
			this.txtPort.BackColor = global::System.Drawing.SystemColors.InfoText;
			this.txtPort.ForeColor = global::System.Drawing.Color.White;
			this.txtPort.Location = new global::System.Drawing.Point(55, 83);
			this.txtPort.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtPort.Name = "txtPort";
			this.txtPort.Size = new global::System.Drawing.Size(48, 20);
			this.txtPort.TabIndex = 1;
			this.txtPort.Text = "80";
			this.txtHost.BackColor = global::System.Drawing.SystemColors.InfoText;
			this.txtHost.ForeColor = global::System.Drawing.Color.White;
			this.txtHost.Location = new global::System.Drawing.Point(55, 39);
			this.txtHost.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtHost.Name = "txtHost";
			this.txtHost.Size = new global::System.Drawing.Size(287, 20);
			this.txtHost.TabIndex = 1;
			this.txtHost.Text = "www.baidu.com";
			this.groupBox2.Controls.Add(this.label4);
			this.groupBox2.Controls.Add(this.label3);
			this.groupBox2.Controls.Add(this.txtTimeout);
			this.groupBox2.Location = new global::System.Drawing.Point(2, 146);
			this.groupBox2.Margin = new global::System.Windows.Forms.Padding(2);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Padding = new global::System.Windows.Forms.Padding(2);
			this.groupBox2.Size = new global::System.Drawing.Size(387, 111);
			this.groupBox2.TabIndex = 1;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Setting";
			this.label4.AutoSize = true;
			this.label4.Location = new global::System.Drawing.Point(121, 55);
			this.label4.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(26, 13);
			this.label4.TabIndex = 5;
			this.label4.Text = "min.";
			this.label3.AutoSize = true;
			this.label3.Location = new global::System.Drawing.Point(11, 55);
			this.label3.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(45, 13);
			this.label3.TabIndex = 4;
			this.label3.Text = "Timeout";
			this.txtTimeout.BackColor = global::System.Drawing.SystemColors.InfoText;
			this.txtTimeout.ForeColor = global::System.Drawing.Color.White;
			this.txtTimeout.Location = new global::System.Drawing.Point(74, 52);
			this.txtTimeout.Margin = new global::System.Windows.Forms.Padding(2);
			this.txtTimeout.Name = "txtTimeout";
			this.txtTimeout.Size = new global::System.Drawing.Size(43, 20);
			this.txtTimeout.TabIndex = 3;
			this.txtTimeout.Text = "5";
			this.groupBox3.Controls.Add(this.radioButton4);
			this.groupBox3.Controls.Add(this.radioButton3);
			this.groupBox3.Controls.Add(this.radioButton2);
			this.groupBox3.Controls.Add(this.radioButton1);
			this.groupBox3.Controls.Add(this.btnStop);
			this.groupBox3.Controls.Add(this.btnAttack);
			this.groupBox3.Location = new global::System.Drawing.Point(408, 25);
			this.groupBox3.Margin = new global::System.Windows.Forms.Padding(2);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Padding = new global::System.Windows.Forms.Padding(2);
			this.groupBox3.Size = new global::System.Drawing.Size(103, 232);
			this.groupBox3.TabIndex = 2;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Order";
			this.radioButton4.AutoSize = true;
			this.radioButton4.ForeColor = global::System.Drawing.Color.White;
			this.radioButton4.Location = new global::System.Drawing.Point(26, 93);
			this.radioButton4.Name = "radioButton4";
			this.radioButton4.Size = new global::System.Drawing.Size(52, 17);
			this.radioButton4.TabIndex = 5;
			this.radioButton4.TabStop = true;
			this.radioButton4.Text = "Mega";
			this.radioButton4.UseVisualStyleBackColor = true;
			this.radioButton3.AutoSize = true;
			this.radioButton3.ForeColor = global::System.Drawing.Color.White;
			this.radioButton3.Location = new global::System.Drawing.Point(26, 70);
			this.radioButton3.Name = "radioButton3";
			this.radioButton3.Size = new global::System.Drawing.Size(48, 17);
			this.radioButton3.TabIndex = 4;
			this.radioButton3.TabStop = true;
			this.radioButton3.Text = "POD";
			this.radioButton3.UseVisualStyleBackColor = true;
			this.radioButton2.AutoSize = true;
			this.radioButton2.ForeColor = global::System.Drawing.Color.White;
			this.radioButton2.Location = new global::System.Drawing.Point(26, 47);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.Size = new global::System.Drawing.Size(54, 17);
			this.radioButton2.TabIndex = 3;
			this.radioButton2.TabStop = true;
			this.radioButton2.Text = "HTTP";
			this.radioButton2.UseVisualStyleBackColor = true;
			this.radioButton1.AutoSize = true;
			this.radioButton1.ForeColor = global::System.Drawing.Color.White;
			this.radioButton1.Location = new global::System.Drawing.Point(26, 24);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.Size = new global::System.Drawing.Size(46, 17);
			this.radioButton1.TabIndex = 2;
			this.radioButton1.TabStop = true;
			this.radioButton1.Text = "TCP";
			this.radioButton1.UseVisualStyleBackColor = true;
			this.btnStop.Enabled = false;
			this.btnStop.Location = new global::System.Drawing.Point(15, 189);
			this.btnStop.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnStop.Name = "btnStop";
			this.btnStop.Size = new global::System.Drawing.Size(71, 29);
			this.btnStop.TabIndex = 1;
			this.btnStop.Text = "Stop";
			this.btnStop.UseVisualStyleBackColor = true;
			this.btnStop.Click += new global::System.EventHandler(this.BtnStop_Click);
			this.btnAttack.Location = new global::System.Drawing.Point(15, 143);
			this.btnAttack.Margin = new global::System.Windows.Forms.Padding(2);
			this.btnAttack.Name = "btnAttack";
			this.btnAttack.Size = new global::System.Drawing.Size(71, 32);
			this.btnAttack.TabIndex = 0;
			this.btnAttack.Text = "Start";
			this.btnAttack.UseVisualStyleBackColor = true;
			this.btnAttack.Click += new global::System.EventHandler(this.BtnAttack_Click);
			this.timer1.Interval = 1000;
			this.timer1.Tick += new global::System.EventHandler(this.Timer1_Tick);
			this.timer2.Interval = 5000;
			this.timer2.Tick += new global::System.EventHandler(this.Timer2_Tick);
			this.bunifuGradientPanel3.BackColor = global::System.Drawing.Color.Transparent;
			this.bunifuGradientPanel3.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("bunifuGradientPanel3.BackgroundImage");
			this.bunifuGradientPanel3.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.bunifuGradientPanel3.BorderRadius = 1;
			this.bunifuGradientPanel3.Controls.Add(this.label5);
			this.bunifuGradientPanel3.Controls.Add(this.label11);
			this.bunifuGradientPanel3.Controls.Add(this.groupBox3);
			this.bunifuGradientPanel3.Controls.Add(this.label12);
			this.bunifuGradientPanel3.Controls.Add(this.groupBox2);
			this.bunifuGradientPanel3.Controls.Add(this.siticoneCircleButton3);
			this.bunifuGradientPanel3.Controls.Add(this.groupBox1);
			this.bunifuGradientPanel3.Controls.Add(this.label13);
			this.bunifuGradientPanel3.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.bunifuGradientPanel3.GradientBottomLeft = global::System.Drawing.Color.DodgerBlue;
			this.bunifuGradientPanel3.GradientBottomRight = global::System.Drawing.Color.DodgerBlue;
			this.bunifuGradientPanel3.GradientTopLeft = global::System.Drawing.Color.Navy;
			this.bunifuGradientPanel3.GradientTopRight = global::System.Drawing.Color.Navy;
			this.bunifuGradientPanel3.Location = new global::System.Drawing.Point(0, 0);
			this.bunifuGradientPanel3.Name = "bunifuGradientPanel3";
			this.bunifuGradientPanel3.Quality = 10;
			this.bunifuGradientPanel3.Size = new global::System.Drawing.Size(541, 304);
			this.bunifuGradientPanel3.TabIndex = 4;
			this.label5.AutoSize = true;
			this.label5.ForeColor = global::System.Drawing.Color.White;
			this.label5.Location = new global::System.Drawing.Point(175, 270);
			this.label5.Margin = new global::System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(117, 13);
			this.label5.TabIndex = 3;
			this.label5.Text = "Send That Fuck Offline";
			this.label11.AutoSize = true;
			this.label11.BackColor = global::System.Drawing.Color.Transparent;
			this.label11.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label11.ForeColor = global::System.Drawing.Color.White;
			this.label11.Location = new global::System.Drawing.Point(157, 377);
			this.label11.Name = "label11";
			this.label11.Size = new global::System.Drawing.Size(159, 48);
			this.label11.TabIndex = 24;
			this.label11.Text = "@FlatLineStealerOfficial\r\n@youhacker55\r\n@thisIsDali";
			this.label12.AutoSize = true;
			this.label12.BackColor = global::System.Drawing.Color.Transparent;
			this.label12.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label12.ForeColor = global::System.Drawing.Color.White;
			this.label12.Location = new global::System.Drawing.Point(31, 392);
			this.label12.Name = "label12";
			this.label12.Size = new global::System.Drawing.Size(120, 16);
			this.label12.TabIndex = 23;
			this.label12.Text = "Ouner and Devs : ";
			this.siticoneCircleButton3.CheckedState.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.CustomImages.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneCircleButton3.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.siticoneCircleButton3.ForeColor = global::System.Drawing.Color.White;
			this.siticoneCircleButton3.HoveredState.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.Location = new global::System.Drawing.Point(141, 339);
			this.siticoneCircleButton3.Name = "siticoneCircleButton3";
			this.siticoneCircleButton3.ShadowDecoration.Mode = global::Siticone.UI.WinForms.Enums.ShadowMode.Circle;
			this.siticoneCircleButton3.ShadowDecoration.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.Size = new global::System.Drawing.Size(223, 26);
			this.siticoneCircleButton3.TabIndex = 22;
			this.siticoneCircleButton3.Text = "https://t.me/officialpryntsoftware";
			this.label13.AutoSize = true;
			this.label13.BackColor = global::System.Drawing.Color.Transparent;
			this.label13.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label13.ForeColor = global::System.Drawing.Color.White;
			this.label13.Location = new global::System.Drawing.Point(31, 344);
			this.label13.Name = "label13";
			this.label13.Size = new global::System.Drawing.Size(106, 16);
			this.label13.TabIndex = 21;
			this.label13.Text = "Our Telegram : ";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
			base.ClientSize = new global::System.Drawing.Size(541, 304);
			base.Controls.Add(this.bunifuGradientPanel3);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Margin = new global::System.Windows.Forms.Padding(2);
			this.MaximumSize = new global::System.Drawing.Size(557, 343);
			this.MinimumSize = new global::System.Drawing.Size(557, 343);
			base.Name = "FormDOS";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "DDOS";
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.FormDOS_FormClosing);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.bunifuGradientPanel3.ResumeLayout(false);
			this.bunifuGradientPanel3.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x0400036B RID: 875
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400036C RID: 876
		private global::System.Windows.Forms.GroupBox groupBox1;

		// Token: 0x0400036D RID: 877
		private global::System.Windows.Forms.Label label2;

		// Token: 0x0400036E RID: 878
		private global::System.Windows.Forms.Label label1;

		// Token: 0x0400036F RID: 879
		private global::System.Windows.Forms.TextBox txtPort;

		// Token: 0x04000370 RID: 880
		private global::System.Windows.Forms.TextBox txtHost;

		// Token: 0x04000371 RID: 881
		private global::System.Windows.Forms.GroupBox groupBox2;

		// Token: 0x04000372 RID: 882
		private global::System.Windows.Forms.Label label4;

		// Token: 0x04000373 RID: 883
		private global::System.Windows.Forms.Label label3;

		// Token: 0x04000374 RID: 884
		private global::System.Windows.Forms.TextBox txtTimeout;

		// Token: 0x04000375 RID: 885
		private global::System.Windows.Forms.GroupBox groupBox3;

		// Token: 0x04000376 RID: 886
		private global::System.Windows.Forms.Button btnStop;

		// Token: 0x04000377 RID: 887
		private global::System.Windows.Forms.Button btnAttack;

		// Token: 0x04000378 RID: 888
		private global::System.Windows.Forms.Timer timer1;

		// Token: 0x04000379 RID: 889
		private global::System.Windows.Forms.Timer timer2;

		// Token: 0x0400037A RID: 890
		private global::Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel3;

		// Token: 0x0400037B RID: 891
		private global::System.Windows.Forms.Label label11;

		// Token: 0x0400037C RID: 892
		private global::System.Windows.Forms.Label label12;

		// Token: 0x0400037D RID: 893
		private global::Siticone.UI.WinForms.SiticoneCircleButton siticoneCircleButton3;

		// Token: 0x0400037E RID: 894
		private global::System.Windows.Forms.Label label13;

		// Token: 0x0400037F RID: 895
		private global::System.Windows.Forms.RadioButton radioButton4;

		// Token: 0x04000380 RID: 896
		private global::System.Windows.Forms.RadioButton radioButton3;

		// Token: 0x04000381 RID: 897
		private global::System.Windows.Forms.RadioButton radioButton2;

		// Token: 0x04000382 RID: 898
		private global::System.Windows.Forms.RadioButton radioButton1;

		// Token: 0x04000383 RID: 899
		private global::System.Windows.Forms.Label label5;
	}
}
