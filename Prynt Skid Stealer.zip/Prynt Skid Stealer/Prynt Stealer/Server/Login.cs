﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Siticone.UI.AnimatorNS;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Enums;

namespace Server
{
	// Token: 0x02000017 RID: 23
	public partial class Login : Form
	{
		// Token: 0x060000C4 RID: 196 RVA: 0x000022A6 File Offset: 0x000004A6
		public Login()
		{
			this.InitializeComponent();
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x000022B4 File Offset: 0x000004B4
		private void siticoneControlBox1_Click(object sender, EventArgs e)
		{
			Environment.Exit(0);
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x00002239 File Offset: 0x00000439
		private void Login_Load(object sender, EventArgs e)
		{
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x0000FFCC File Offset: 0x0000E1CC
		private static string random_string()
		{
			string text = null;
			Random random = new Random();
			for (int i = 0; i < 5; i++)
			{
				text += Convert.ToChar(Convert.ToInt32(Math.Floor(26.0 * random.NextDouble() + 65.0))).ToString();
			}
			return text;
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x0000222C File Offset: 0x0000042C
		private void UpgradeBtn_Click(object sender, EventArgs e)
		{
			Process.Start("https://t.me/toxicnetarmy");
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x000022BC File Offset: 0x000004BC
		private void LoginBtn_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Fuck you Flat Gay Cracked By NetPain");
			Program.form1 = new Form1();
			Program.form1.Show();
			base.Hide();
		}

		// Token: 0x060000CA RID: 202 RVA: 0x000022E3 File Offset: 0x000004E3
		private void RgstrBtn_Click(object sender, EventArgs e)
		{
			Program.form1 = new Form1();
			Program.form1.Show();
			base.Hide();
		}

		// Token: 0x060000CB RID: 203 RVA: 0x000022E3 File Offset: 0x000004E3
		private void LicBtn_Click(object sender, EventArgs e)
		{
			Program.form1 = new Form1();
			Program.form1.Show();
			base.Hide();
		}

		// Token: 0x060000CC RID: 204 RVA: 0x000022FF File Offset: 0x000004FF
		private void username_Click(object sender, EventArgs e)
		{
			this.username.Clear();
		}

		// Token: 0x060000CD RID: 205 RVA: 0x0000230C File Offset: 0x0000050C
		private void password_Click(object sender, EventArgs e)
		{
			this.password.Clear();
		}

		// Token: 0x060000CE RID: 206 RVA: 0x00002319 File Offset: 0x00000519
		private void key_Click(object sender, EventArgs e)
		{
			this.key.Clear();
		}

		// Token: 0x060000CF RID: 207 RVA: 0x0000222C File Offset: 0x0000042C
		private void siticoneRoundedButton1_Click(object sender, EventArgs e)
		{
			Process.Start("https://t.me/toxicnetarmy");
		}

		// Token: 0x040000E3 RID: 227
		public static api KeyAuthApp = new api("pryntstealer3", "UVH9g2bJwp", "aa210a601c144f0231f9c0e98d6bc1d4466c8b6c3d4ccb395e096714b5c3f287", "1.0");
	}
}
