﻿namespace Server
{
	// Token: 0x0200000E RID: 14
	public partial class Form1 : global::System.Windows.Forms.Form
	{
		// Token: 0x060000B1 RID: 177 RVA: 0x0000223B File Offset: 0x0000043B
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x0000A178 File Offset: 0x00008378
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Server.Form1));
			this.contextMenuClient = new global::System.Windows.Forms.ContextMenuStrip(this.components);
			this.RemoteManagerToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.RemoteShellToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.RemoteScreenToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.RemoteCameraToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.remoteRegeditToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.FileManagerToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ProcessManagerToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.netstatToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.RecordToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ProgramNotificationToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.StartToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.StopToolStripMenuItem2 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.RemoteControlToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.SendFileToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.fromUrlToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.SendFileToDiskToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.SendFileToMemoryToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.MessageBoxToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ChatToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.VisteWebsiteToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ChangeWallpaperToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.KeyloggerToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.FileSearchToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.MalwareToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.dDOSToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.RansomwareToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.EncryptToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.DecryptToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.DisableWDToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.PasswordRecoveryToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.DisableUACToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.SystemControlToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ClientControlToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.StopToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.RestartToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.UpdateToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.UninstallToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ClientFolderToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.SystemToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ShutDownToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.RebootToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.LogoutToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.BypassUACAToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.SilentCleanupToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.FodhelperToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.RunasToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.CompMgmtLauncherToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.InstallToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.SchtaskInstallToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.SchtaskUninstallToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.normalInstallToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.normalUninstallToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.justForFunToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.InformationToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.statusStrip1 = new global::System.Windows.Forms.StatusStrip();
			this.toolStripStatusLabel1 = new global::System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripStatusLabel2 = new global::System.Windows.Forms.ToolStripStatusLabel();
			this.ping = new global::System.Windows.Forms.Timer(this.components);
			this.UpdateUI = new global::System.Windows.Forms.Timer(this.components);
			this.contextMenuLogs = new global::System.Windows.Forms.ContextMenuStrip(this.components);
			this.cLEARToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.contextMenuThumbnail = new global::System.Windows.Forms.ContextMenuStrip(this.components);
			this.sTARTToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.sTOPToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ThumbnailImageList = new global::System.Windows.Forms.ImageList(this.components);
			this.contextMenuTasks = new global::System.Windows.Forms.ContextMenuStrip(this.components);
			this.sendFileFromUrlToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.downloadAndExecuteToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.sENDFILETOMEMORYToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.disableUACToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.disableWDToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.installSchtaskToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.uPDATEToolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.autoKeyloggerToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.fakeBinderToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator4 = new global::System.Windows.Forms.ToolStripSeparator();
			this.dELETETASKToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.performanceCounter1 = new global::System.Diagnostics.PerformanceCounter();
			this.performanceCounter2 = new global::System.Diagnostics.PerformanceCounter();
			this.notifyIcon1 = new global::System.Windows.Forms.NotifyIcon(this.components);
			this.TimerTask = new global::System.Windows.Forms.Timer(this.components);
			this.menuStrip1 = new global::System.Windows.Forms.MenuStrip();
			this.FileToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.BuilderToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.BlockToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.SettingToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.ExitToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.HelpToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.DocumentToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.AboutToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem1 = new global::System.Windows.Forms.ToolStripMenuItem();
			this.splitContainer1 = new global::System.Windows.Forms.SplitContainer();
			this.panel2 = new global::System.Windows.Forms.Panel();
			this.bunifuGradientPanel2 = new global::Bunifu.UI.WinForms.BunifuGradientPanel();
			this.subscriptionDaysLabel = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.lastLogin = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.hwid = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.ip = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.subscription = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.expiry = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.key = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.bunifuPictureBox2 = new global::Bunifu.UI.WinForms.BunifuPictureBox();
			this.bunifuGradientPanel1 = new global::Bunifu.UI.WinForms.BunifuGradientPanel();
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.tabControl1 = new global::System.Windows.Forms.TabControl();
			this.tabPage1 = new global::System.Windows.Forms.TabPage();
			this.listView1 = new global::System.Windows.Forms.ListView();
			this.lv_ip = new global::System.Windows.Forms.ColumnHeader();
			this.lv_country = new global::System.Windows.Forms.ColumnHeader();
			this.lv_group = new global::System.Windows.Forms.ColumnHeader();
			this.lv_hwid = new global::System.Windows.Forms.ColumnHeader();
			this.lv_user = new global::System.Windows.Forms.ColumnHeader();
			this.lv_camera = new global::System.Windows.Forms.ColumnHeader();
			this.lv_os = new global::System.Windows.Forms.ColumnHeader();
			this.lv_version = new global::System.Windows.Forms.ColumnHeader();
			this.lv_ins = new global::System.Windows.Forms.ColumnHeader();
			this.lv_admin = new global::System.Windows.Forms.ColumnHeader();
			this.lv_av = new global::System.Windows.Forms.ColumnHeader();
			this.lv_ping = new global::System.Windows.Forms.ColumnHeader();
			this.lv_act = new global::System.Windows.Forms.ColumnHeader();
			this.listView2 = new global::System.Windows.Forms.ListView();
			this.columnHeader1 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new global::System.Windows.Forms.ColumnHeader();
			this.siticoneLabel1 = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.tabPage3 = new global::System.Windows.Forms.TabPage();
			this.listView3 = new global::System.Windows.Forms.ListView();
			this.tabPage4 = new global::System.Windows.Forms.TabPage();
			this.version = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.customerPanelLink = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.createDate = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.numKeys = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.listView4 = new global::System.Windows.Forms.ListView();
			this.columnHeader4 = new global::System.Windows.Forms.ColumnHeader();
			this.columnHeader5 = new global::System.Windows.Forms.ColumnHeader();
			this.numOnlineUsers = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.numUsers = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.bunifuGradientPanel3 = new global::Bunifu.UI.WinForms.BunifuGradientPanel();
			this.label11 = new global::System.Windows.Forms.Label();
			this.label12 = new global::System.Windows.Forms.Label();
			this.siticoneCircleButton3 = new global::Siticone.UI.WinForms.SiticoneCircleButton();
			this.label13 = new global::System.Windows.Forms.Label();
			this.label14 = new global::System.Windows.Forms.Label();
			this.label15 = new global::System.Windows.Forms.Label();
			this.ConnectTimeout = new global::System.Windows.Forms.Timer(this.components);
			this.bunifuGradientPanel5 = new global::Bunifu.UI.WinForms.BunifuGradientPanel();
			this.bunifuGradientPanel4 = new global::Bunifu.UI.WinForms.BunifuGradientPanel();
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.pictureBox2 = new global::System.Windows.Forms.PictureBox();
			this.pictureBox3 = new global::System.Windows.Forms.PictureBox();
			this.pictureBox4 = new global::System.Windows.Forms.PictureBox();
			this.pictureBox5 = new global::System.Windows.Forms.PictureBox();
			this.siticoneLabel2 = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.siticoneLabel3 = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.siticoneLabel4 = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.siticoneLabel5 = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.siticoneLabel6 = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.contextMenuClient.SuspendLayout();
			this.statusStrip1.SuspendLayout();
			this.contextMenuLogs.SuspendLayout();
			this.contextMenuThumbnail.SuspendLayout();
			this.contextMenuTasks.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.performanceCounter1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.performanceCounter2).BeginInit();
			this.menuStrip1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer1).BeginInit();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.bunifuGradientPanel2.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.bunifuPictureBox2).BeginInit();
			this.bunifuGradientPanel1.SuspendLayout();
			this.panel1.SuspendLayout();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage4.SuspendLayout();
			this.bunifuGradientPanel3.SuspendLayout();
			this.bunifuGradientPanel5.SuspendLayout();
			this.bunifuGradientPanel4.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox2).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox4).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox5).BeginInit();
			base.SuspendLayout();
			this.contextMenuClient.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("contextMenuClient.BackgroundImage");
			this.contextMenuClient.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.contextMenuClient.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.RemoteManagerToolStripMenuItem,
				this.RemoteControlToolStripMenuItem,
				this.MalwareToolStripMenuItem,
				this.SystemControlToolStripMenuItem,
				this.BypassUACAToolStripMenuItem,
				this.InstallToolStripMenuItem,
				this.justForFunToolStripMenuItem,
				this.InformationToolStripMenuItem
			});
			this.contextMenuClient.Name = "contextMenuStrip1";
			this.contextMenuClient.ShowImageMargin = false;
			this.contextMenuClient.Size = new global::System.Drawing.Size(131, 180);
			this.RemoteManagerToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.RemoteShellToolStripMenuItem,
				this.RemoteScreenToolStripMenuItem,
				this.RemoteCameraToolStripMenuItem,
				this.remoteRegeditToolStripMenuItem,
				this.FileManagerToolStripMenuItem1,
				this.ProcessManagerToolStripMenuItem,
				this.netstatToolStripMenuItem,
				this.RecordToolStripMenuItem,
				this.ProgramNotificationToolStripMenuItem
			});
			this.RemoteManagerToolStripMenuItem.Name = "RemoteManagerToolStripMenuItem";
			this.RemoteManagerToolStripMenuItem.Size = new global::System.Drawing.Size(130, 22);
			this.RemoteManagerToolStripMenuItem.Text = "SpyWare";
			this.RemoteShellToolStripMenuItem.Name = "RemoteShellToolStripMenuItem";
			this.RemoteShellToolStripMenuItem.Size = new global::System.Drawing.Size(186, 22);
			this.RemoteShellToolStripMenuItem.Text = "Remote Shell";
			this.RemoteShellToolStripMenuItem.Click += new global::System.EventHandler(this.RemoteShellToolStripMenuItem_Click);
			this.RemoteScreenToolStripMenuItem.Name = "RemoteScreenToolStripMenuItem";
			this.RemoteScreenToolStripMenuItem.Size = new global::System.Drawing.Size(186, 22);
			this.RemoteScreenToolStripMenuItem.Text = "Remote Screen";
			this.RemoteScreenToolStripMenuItem.Click += new global::System.EventHandler(this.RemoteScreenToolStripMenuItem_Click);
			this.RemoteCameraToolStripMenuItem.Name = "RemoteCameraToolStripMenuItem";
			this.RemoteCameraToolStripMenuItem.Size = new global::System.Drawing.Size(186, 22);
			this.RemoteCameraToolStripMenuItem.Text = "Remote Camera";
			this.RemoteCameraToolStripMenuItem.Click += new global::System.EventHandler(this.RemoteCameraToolStripMenuItem_Click);
			this.remoteRegeditToolStripMenuItem.Name = "remoteRegeditToolStripMenuItem";
			this.remoteRegeditToolStripMenuItem.Size = new global::System.Drawing.Size(186, 22);
			this.remoteRegeditToolStripMenuItem.Text = "Remote Regedit";
			this.remoteRegeditToolStripMenuItem.Click += new global::System.EventHandler(this.remoteRegeditToolStripMenuItem_Click);
			this.FileManagerToolStripMenuItem1.Name = "FileManagerToolStripMenuItem1";
			this.FileManagerToolStripMenuItem1.Size = new global::System.Drawing.Size(186, 22);
			this.FileManagerToolStripMenuItem1.Text = "File Manager";
			this.FileManagerToolStripMenuItem1.Click += new global::System.EventHandler(this.FileManagerToolStripMenuItem1_Click);
			this.ProcessManagerToolStripMenuItem.Name = "ProcessManagerToolStripMenuItem";
			this.ProcessManagerToolStripMenuItem.Size = new global::System.Drawing.Size(186, 22);
			this.ProcessManagerToolStripMenuItem.Text = "Process Manager";
			this.ProcessManagerToolStripMenuItem.Click += new global::System.EventHandler(this.ProcessManagerToolStripMenuItem_Click);
			this.netstatToolStripMenuItem.Name = "netstatToolStripMenuItem";
			this.netstatToolStripMenuItem.Size = new global::System.Drawing.Size(186, 22);
			this.netstatToolStripMenuItem.Text = "Netstat";
			this.netstatToolStripMenuItem.Click += new global::System.EventHandler(this.netstatToolStripMenuItem_Click);
			this.RecordToolStripMenuItem.Name = "RecordToolStripMenuItem";
			this.RecordToolStripMenuItem.Size = new global::System.Drawing.Size(186, 22);
			this.RecordToolStripMenuItem.Text = "Record";
			this.RecordToolStripMenuItem.Click += new global::System.EventHandler(this.RecordToolStripMenuItem_Click);
			this.ProgramNotificationToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.StartToolStripMenuItem1,
				this.StopToolStripMenuItem2
			});
			this.ProgramNotificationToolStripMenuItem.Name = "ProgramNotificationToolStripMenuItem";
			this.ProgramNotificationToolStripMenuItem.Size = new global::System.Drawing.Size(186, 22);
			this.ProgramNotificationToolStripMenuItem.Text = "Program Notification";
			this.StartToolStripMenuItem1.Name = "StartToolStripMenuItem1";
			this.StartToolStripMenuItem1.Size = new global::System.Drawing.Size(98, 22);
			this.StartToolStripMenuItem1.Text = "Start";
			this.StartToolStripMenuItem1.Click += new global::System.EventHandler(this.StartToolStripMenuItem1_Click);
			this.StopToolStripMenuItem2.Name = "StopToolStripMenuItem2";
			this.StopToolStripMenuItem2.Size = new global::System.Drawing.Size(98, 22);
			this.StopToolStripMenuItem2.Text = "Stop";
			this.StopToolStripMenuItem2.Click += new global::System.EventHandler(this.StopToolStripMenuItem2_Click);
			this.RemoteControlToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.SendFileToolStripMenuItem1,
				this.MessageBoxToolStripMenuItem,
				this.ChatToolStripMenuItem1,
				this.VisteWebsiteToolStripMenuItem1,
				this.ChangeWallpaperToolStripMenuItem1,
				this.KeyloggerToolStripMenuItem1,
				this.FileSearchToolStripMenuItem
			});
			this.RemoteControlToolStripMenuItem.Name = "RemoteControlToolStripMenuItem";
			this.RemoteControlToolStripMenuItem.Size = new global::System.Drawing.Size(130, 22);
			this.RemoteControlToolStripMenuItem.Text = "Control";
			this.SendFileToolStripMenuItem1.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.fromUrlToolStripMenuItem,
				this.SendFileToDiskToolStripMenuItem,
				this.SendFileToMemoryToolStripMenuItem
			});
			this.SendFileToolStripMenuItem1.Name = "SendFileToolStripMenuItem1";
			this.SendFileToolStripMenuItem1.Size = new global::System.Drawing.Size(180, 22);
			this.SendFileToolStripMenuItem1.Text = "Send File";
			this.fromUrlToolStripMenuItem.Name = "fromUrlToolStripMenuItem";
			this.fromUrlToolStripMenuItem.Size = new global::System.Drawing.Size(184, 22);
			this.fromUrlToolStripMenuItem.Text = "From Url";
			this.fromUrlToolStripMenuItem.Click += new global::System.EventHandler(this.fromUrlToolStripMenuItem_Click);
			this.SendFileToDiskToolStripMenuItem.Name = "SendFileToDiskToolStripMenuItem";
			this.SendFileToDiskToolStripMenuItem.Size = new global::System.Drawing.Size(184, 22);
			this.SendFileToDiskToolStripMenuItem.Text = "Send File To Disk";
			this.SendFileToDiskToolStripMenuItem.Click += new global::System.EventHandler(this.SendFileToDiskToolStripMenuItem_Click);
			this.SendFileToMemoryToolStripMenuItem.Name = "SendFileToMemoryToolStripMenuItem";
			this.SendFileToMemoryToolStripMenuItem.Size = new global::System.Drawing.Size(184, 22);
			this.SendFileToMemoryToolStripMenuItem.Text = "Send File To Memory";
			this.SendFileToMemoryToolStripMenuItem.Click += new global::System.EventHandler(this.SendFileToMemoryToolStripMenuItem_Click);
			this.MessageBoxToolStripMenuItem.Name = "MessageBoxToolStripMenuItem";
			this.MessageBoxToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.MessageBoxToolStripMenuItem.Text = "MessageBox";
			this.MessageBoxToolStripMenuItem.Click += new global::System.EventHandler(this.MessageBoxToolStripMenuItem_Click);
			this.ChatToolStripMenuItem1.Name = "ChatToolStripMenuItem1";
			this.ChatToolStripMenuItem1.Size = new global::System.Drawing.Size(180, 22);
			this.ChatToolStripMenuItem1.Text = "Chat";
			this.ChatToolStripMenuItem1.Click += new global::System.EventHandler(this.ChatToolStripMenuItem1_Click);
			this.VisteWebsiteToolStripMenuItem1.Name = "VisteWebsiteToolStripMenuItem1";
			this.VisteWebsiteToolStripMenuItem1.Size = new global::System.Drawing.Size(180, 22);
			this.VisteWebsiteToolStripMenuItem1.Text = "Viste Website";
			this.VisteWebsiteToolStripMenuItem1.Click += new global::System.EventHandler(this.VisteWebsiteToolStripMenuItem1_Click);
			this.ChangeWallpaperToolStripMenuItem1.Name = "ChangeWallpaperToolStripMenuItem1";
			this.ChangeWallpaperToolStripMenuItem1.Size = new global::System.Drawing.Size(180, 22);
			this.ChangeWallpaperToolStripMenuItem1.Text = "Change Wallpaper";
			this.ChangeWallpaperToolStripMenuItem1.Click += new global::System.EventHandler(this.ChangeWallpaperToolStripMenuItem1_Click);
			this.KeyloggerToolStripMenuItem1.Name = "KeyloggerToolStripMenuItem1";
			this.KeyloggerToolStripMenuItem1.Size = new global::System.Drawing.Size(180, 22);
			this.KeyloggerToolStripMenuItem1.Text = "Keylogger";
			this.KeyloggerToolStripMenuItem1.Click += new global::System.EventHandler(this.KeyloggerToolStripMenuItem1_Click);
			this.FileSearchToolStripMenuItem.Name = "FileSearchToolStripMenuItem";
			this.FileSearchToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.FileSearchToolStripMenuItem.Text = "File Search";
			this.FileSearchToolStripMenuItem.Click += new global::System.EventHandler(this.FileSearchToolStripMenuItem_Click);
			this.MalwareToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.dDOSToolStripMenuItem,
				this.RansomwareToolStripMenuItem,
				this.DisableWDToolStripMenuItem,
				this.PasswordRecoveryToolStripMenuItem,
				this.DisableUACToolStripMenuItem
			});
			this.MalwareToolStripMenuItem.Name = "MalwareToolStripMenuItem";
			this.MalwareToolStripMenuItem.Size = new global::System.Drawing.Size(130, 22);
			this.MalwareToolStripMenuItem.Text = "Malware";
			this.dDOSToolStripMenuItem.Name = "dDOSToolStripMenuItem";
			this.dDOSToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.dDOSToolStripMenuItem.Text = "DDOS";
			this.dDOSToolStripMenuItem.Click += new global::System.EventHandler(this.dDOSToolStripMenuItem_Click);
			this.RansomwareToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.EncryptToolStripMenuItem,
				this.DecryptToolStripMenuItem
			});
			this.RansomwareToolStripMenuItem.Name = "RansomwareToolStripMenuItem";
			this.RansomwareToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.RansomwareToolStripMenuItem.Text = "Ransomware";
			this.EncryptToolStripMenuItem.Name = "EncryptToolStripMenuItem";
			this.EncryptToolStripMenuItem.Size = new global::System.Drawing.Size(115, 22);
			this.EncryptToolStripMenuItem.Text = "Encrypt";
			this.EncryptToolStripMenuItem.Click += new global::System.EventHandler(this.EncryptToolStripMenuItem_Click);
			this.DecryptToolStripMenuItem.Name = "DecryptToolStripMenuItem";
			this.DecryptToolStripMenuItem.Size = new global::System.Drawing.Size(115, 22);
			this.DecryptToolStripMenuItem.Text = "Decrypt";
			this.DecryptToolStripMenuItem.Click += new global::System.EventHandler(this.DecryptToolStripMenuItem_Click);
			this.DisableWDToolStripMenuItem.Name = "DisableWDToolStripMenuItem";
			this.DisableWDToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.DisableWDToolStripMenuItem.Text = "Disable WD";
			this.DisableWDToolStripMenuItem.Click += new global::System.EventHandler(this.DisableWDToolStripMenuItem_Click);
			this.PasswordRecoveryToolStripMenuItem.Name = "PasswordRecoveryToolStripMenuItem";
			this.PasswordRecoveryToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.PasswordRecoveryToolStripMenuItem.Text = "Password Recovery";
			this.PasswordRecoveryToolStripMenuItem.Click += new global::System.EventHandler(this.PasswordRecoveryToolStripMenuItem_Click);
			this.DisableUACToolStripMenuItem.Name = "DisableUACToolStripMenuItem";
			this.DisableUACToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.DisableUACToolStripMenuItem.Text = "Disable UAC";
			this.DisableUACToolStripMenuItem.Click += new global::System.EventHandler(this.DisableUACToolStripMenuItem_Click);
			this.SystemControlToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.ClientControlToolStripMenuItem,
				this.SystemToolStripMenuItem
			});
			this.SystemControlToolStripMenuItem.Name = "SystemControlToolStripMenuItem";
			this.SystemControlToolStripMenuItem.Size = new global::System.Drawing.Size(130, 22);
			this.SystemControlToolStripMenuItem.Text = "System Control";
			this.ClientControlToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.StopToolStripMenuItem1,
				this.RestartToolStripMenuItem1,
				this.UpdateToolStripMenuItem,
				this.UninstallToolStripMenuItem,
				this.ClientFolderToolStripMenuItem
			});
			this.ClientControlToolStripMenuItem.Name = "ClientControlToolStripMenuItem";
			this.ClientControlToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.ClientControlToolStripMenuItem.Text = "Client Control";
			this.StopToolStripMenuItem1.Name = "StopToolStripMenuItem1";
			this.StopToolStripMenuItem1.Size = new global::System.Drawing.Size(141, 22);
			this.StopToolStripMenuItem1.Text = "Stop";
			this.StopToolStripMenuItem1.Click += new global::System.EventHandler(this.StopToolStripMenuItem1_Click);
			this.RestartToolStripMenuItem1.Name = "RestartToolStripMenuItem1";
			this.RestartToolStripMenuItem1.Size = new global::System.Drawing.Size(141, 22);
			this.RestartToolStripMenuItem1.Text = "Restart";
			this.RestartToolStripMenuItem1.Click += new global::System.EventHandler(this.RestartToolStripMenuItem1_Click);
			this.UpdateToolStripMenuItem.Name = "UpdateToolStripMenuItem";
			this.UpdateToolStripMenuItem.Size = new global::System.Drawing.Size(141, 22);
			this.UpdateToolStripMenuItem.Text = "Update";
			this.UpdateToolStripMenuItem.Click += new global::System.EventHandler(this.UpdateToolStripMenuItem_Click);
			this.UninstallToolStripMenuItem.Name = "UninstallToolStripMenuItem";
			this.UninstallToolStripMenuItem.Size = new global::System.Drawing.Size(141, 22);
			this.UninstallToolStripMenuItem.Text = "Uninstall";
			this.UninstallToolStripMenuItem.Click += new global::System.EventHandler(this.UninstallToolStripMenuItem_Click);
			this.ClientFolderToolStripMenuItem.Name = "ClientFolderToolStripMenuItem";
			this.ClientFolderToolStripMenuItem.Size = new global::System.Drawing.Size(141, 22);
			this.ClientFolderToolStripMenuItem.Text = "Client Folder";
			this.ClientFolderToolStripMenuItem.Click += new global::System.EventHandler(this.ClientFolderToolStripMenuItem_Click);
			this.SystemToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.ShutDownToolStripMenuItem,
				this.RebootToolStripMenuItem,
				this.LogoutToolStripMenuItem
			});
			this.SystemToolStripMenuItem.Name = "SystemToolStripMenuItem";
			this.SystemToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.SystemToolStripMenuItem.Text = "System";
			this.ShutDownToolStripMenuItem.Name = "ShutDownToolStripMenuItem";
			this.ShutDownToolStripMenuItem.Size = new global::System.Drawing.Size(132, 22);
			this.ShutDownToolStripMenuItem.Text = "Shut Down";
			this.ShutDownToolStripMenuItem.Click += new global::System.EventHandler(this.ShutDownToolStripMenuItem_Click);
			this.RebootToolStripMenuItem.Name = "RebootToolStripMenuItem";
			this.RebootToolStripMenuItem.Size = new global::System.Drawing.Size(132, 22);
			this.RebootToolStripMenuItem.Text = "Reboot";
			this.RebootToolStripMenuItem.Click += new global::System.EventHandler(this.RebootToolStripMenuItem_Click);
			this.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem";
			this.LogoutToolStripMenuItem.Size = new global::System.Drawing.Size(132, 22);
			this.LogoutToolStripMenuItem.Text = "Logout";
			this.LogoutToolStripMenuItem.Click += new global::System.EventHandler(this.LogoutToolStripMenuItem_Click);
			this.BypassUACAToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.SilentCleanupToolStripMenuItem,
				this.FodhelperToolStripMenuItem,
				this.RunasToolStripMenuItem,
				this.CompMgmtLauncherToolStripMenuItem
			});
			this.BypassUACAToolStripMenuItem.Name = "BypassUACAToolStripMenuItem";
			this.BypassUACAToolStripMenuItem.Size = new global::System.Drawing.Size(130, 22);
			this.BypassUACAToolStripMenuItem.Text = "Bypass UAC";
			this.SilentCleanupToolStripMenuItem.Name = "SilentCleanupToolStripMenuItem";
			this.SilentCleanupToolStripMenuItem.Size = new global::System.Drawing.Size(189, 22);
			this.SilentCleanupToolStripMenuItem.Text = "Silent Cleanup";
			this.SilentCleanupToolStripMenuItem.Click += new global::System.EventHandler(this.SilentCleanupToolStripMenuItem_Click);
			this.FodhelperToolStripMenuItem.Name = "FodhelperToolStripMenuItem";
			this.FodhelperToolStripMenuItem.Size = new global::System.Drawing.Size(189, 22);
			this.FodhelperToolStripMenuItem.Text = "Fodhelper";
			this.FodhelperToolStripMenuItem.Click += new global::System.EventHandler(this.FodhelperToolStripMenuItem_Click);
			this.RunasToolStripMenuItem.Name = "RunasToolStripMenuItem";
			this.RunasToolStripMenuItem.Size = new global::System.Drawing.Size(189, 22);
			this.RunasToolStripMenuItem.Text = "Runas";
			this.RunasToolStripMenuItem.Click += new global::System.EventHandler(this.RunasToolStripMenuItem_Click);
			this.CompMgmtLauncherToolStripMenuItem.Name = "CompMgmtLauncherToolStripMenuItem";
			this.CompMgmtLauncherToolStripMenuItem.Size = new global::System.Drawing.Size(189, 22);
			this.CompMgmtLauncherToolStripMenuItem.Text = "CompMgmtLauncher";
			this.CompMgmtLauncherToolStripMenuItem.Click += new global::System.EventHandler(this.CompMgmtLauncherToolStripMenuItem_Click);
			this.InstallToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.SchtaskInstallToolStripMenuItem,
				this.SchtaskUninstallToolStripMenuItem,
				this.normalInstallToolStripMenuItem,
				this.normalUninstallToolStripMenuItem
			});
			this.InstallToolStripMenuItem.Name = "InstallToolStripMenuItem";
			this.InstallToolStripMenuItem.Size = new global::System.Drawing.Size(130, 22);
			this.InstallToolStripMenuItem.Text = "Install";
			this.SchtaskInstallToolStripMenuItem.Name = "SchtaskInstallToolStripMenuItem";
			this.SchtaskInstallToolStripMenuItem.Size = new global::System.Drawing.Size(163, 22);
			this.SchtaskInstallToolStripMenuItem.Text = "Schtask Install";
			this.SchtaskInstallToolStripMenuItem.Click += new global::System.EventHandler(this.SchtaskInstallToolStripMenuItem_Click);
			this.SchtaskUninstallToolStripMenuItem.Name = "SchtaskUninstallToolStripMenuItem";
			this.SchtaskUninstallToolStripMenuItem.Size = new global::System.Drawing.Size(163, 22);
			this.SchtaskUninstallToolStripMenuItem.Text = "Schtask Uninstall";
			this.SchtaskUninstallToolStripMenuItem.Click += new global::System.EventHandler(this.SchtaskUninstallToolStripMenuItem_Click);
			this.normalInstallToolStripMenuItem.Name = "normalInstallToolStripMenuItem";
			this.normalInstallToolStripMenuItem.Size = new global::System.Drawing.Size(163, 22);
			this.normalInstallToolStripMenuItem.Text = "Normal Install";
			this.normalInstallToolStripMenuItem.Click += new global::System.EventHandler(this.normalInstallToolStripMenuItem_Click);
			this.normalUninstallToolStripMenuItem.Name = "normalUninstallToolStripMenuItem";
			this.normalUninstallToolStripMenuItem.Size = new global::System.Drawing.Size(163, 22);
			this.normalUninstallToolStripMenuItem.Text = "Normal Uninstall";
			this.normalUninstallToolStripMenuItem.Click += new global::System.EventHandler(this.normalUninstallToolStripMenuItem_Click);
			this.justForFunToolStripMenuItem.Name = "justForFunToolStripMenuItem";
			this.justForFunToolStripMenuItem.Size = new global::System.Drawing.Size(130, 22);
			this.justForFunToolStripMenuItem.Text = "Fun Shit";
			this.justForFunToolStripMenuItem.Click += new global::System.EventHandler(this.justForFunToolStripMenuItem_Click);
			this.InformationToolStripMenuItem.Name = "InformationToolStripMenuItem";
			this.InformationToolStripMenuItem.Size = new global::System.Drawing.Size(130, 22);
			this.InformationToolStripMenuItem.Text = "Information";
			this.InformationToolStripMenuItem.Click += new global::System.EventHandler(this.InformationToolStripMenuItem_Click);
			this.statusStrip1.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("statusStrip1.BackgroundImage");
			this.statusStrip1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.statusStrip1.ImageScalingSize = new global::System.Drawing.Size(24, 24);
			this.statusStrip1.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.toolStripStatusLabel1,
				this.toolStripStatusLabel2
			});
			this.statusStrip1.Location = new global::System.Drawing.Point(0, 436);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Padding = new global::System.Windows.Forms.Padding(1, 0, 9, 0);
			this.statusStrip1.Size = new global::System.Drawing.Size(925, 22);
			this.statusStrip1.TabIndex = 1;
			this.statusStrip1.Text = "statusStrip1";
			this.toolStripStatusLabel1.ForeColor = global::System.Drawing.Color.White;
			this.toolStripStatusLabel1.LinkColor = global::System.Drawing.Color.White;
			this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
			this.toolStripStatusLabel1.Size = new global::System.Drawing.Size(16, 17);
			this.toolStripStatusLabel1.Text = "...";
			this.toolStripStatusLabel1.VisitedLinkColor = global::System.Drawing.Color.White;
			this.toolStripStatusLabel2.ActiveLinkColor = global::System.Drawing.Color.White;
			this.toolStripStatusLabel2.ForeColor = global::System.Drawing.Color.White;
			this.toolStripStatusLabel2.LinkColor = global::System.Drawing.Color.White;
			this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
			this.toolStripStatusLabel2.Size = new global::System.Drawing.Size(130, 17);
			this.toolStripStatusLabel2.Text = "                    Notification";
			this.toolStripStatusLabel2.VisitedLinkColor = global::System.Drawing.Color.White;
			this.toolStripStatusLabel2.Click += new global::System.EventHandler(this.ToolStripStatusLabel2_Click);
			this.ping.Enabled = true;
			this.ping.Interval = 30000;
			this.ping.Tick += new global::System.EventHandler(this.ping_Tick);
			this.UpdateUI.Enabled = true;
			this.UpdateUI.Interval = 500;
			this.UpdateUI.Tick += new global::System.EventHandler(this.UpdateUI_Tick);
			this.contextMenuLogs.ImageScalingSize = new global::System.Drawing.Size(24, 24);
			this.contextMenuLogs.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.cLEARToolStripMenuItem
			});
			this.contextMenuLogs.Name = "contextMenuLogs";
			this.contextMenuLogs.ShowImageMargin = false;
			this.contextMenuLogs.Size = new global::System.Drawing.Size(77, 26);
			this.cLEARToolStripMenuItem.Name = "cLEARToolStripMenuItem";
			this.cLEARToolStripMenuItem.Size = new global::System.Drawing.Size(76, 22);
			this.cLEARToolStripMenuItem.Text = "Clear";
			this.cLEARToolStripMenuItem.Click += new global::System.EventHandler(this.CLEARToolStripMenuItem_Click);
			this.contextMenuThumbnail.ImageScalingSize = new global::System.Drawing.Size(24, 24);
			this.contextMenuThumbnail.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.sTARTToolStripMenuItem,
				this.sTOPToolStripMenuItem
			});
			this.contextMenuThumbnail.Name = "contextMenuStrip2";
			this.contextMenuThumbnail.Size = new global::System.Drawing.Size(99, 48);
			this.sTARTToolStripMenuItem.ForeColor = global::System.Drawing.SystemColors.ControlText;
			this.sTARTToolStripMenuItem.Name = "sTARTToolStripMenuItem";
			this.sTARTToolStripMenuItem.Size = new global::System.Drawing.Size(98, 22);
			this.sTARTToolStripMenuItem.Text = "Start";
			this.sTARTToolStripMenuItem.Click += new global::System.EventHandler(this.STARTToolStripMenuItem_Click);
			this.sTOPToolStripMenuItem.Name = "sTOPToolStripMenuItem";
			this.sTOPToolStripMenuItem.Size = new global::System.Drawing.Size(98, 22);
			this.sTOPToolStripMenuItem.Text = "Stop";
			this.sTOPToolStripMenuItem.Click += new global::System.EventHandler(this.STOPToolStripMenuItem_Click);
			this.ThumbnailImageList.ColorDepth = global::System.Windows.Forms.ColorDepth.Depth16Bit;
			this.ThumbnailImageList.ImageSize = new global::System.Drawing.Size(256, 256);
			this.ThumbnailImageList.TransparentColor = global::System.Drawing.Color.Transparent;
			this.contextMenuTasks.ImageScalingSize = new global::System.Drawing.Size(24, 24);
			this.contextMenuTasks.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.sendFileFromUrlToolStripMenuItem,
				this.downloadAndExecuteToolStripMenuItem,
				this.sENDFILETOMEMORYToolStripMenuItem1,
				this.disableUACToolStripMenuItem1,
				this.disableWDToolStripMenuItem1,
				this.installSchtaskToolStripMenuItem,
				this.uPDATEToolStripMenuItem1,
				this.autoKeyloggerToolStripMenuItem,
				this.fakeBinderToolStripMenuItem,
				this.toolStripSeparator4,
				this.dELETETASKToolStripMenuItem
			});
			this.contextMenuTasks.Name = "contextMenuStrip4";
			this.contextMenuTasks.ShowImageMargin = false;
			this.contextMenuTasks.Size = new global::System.Drawing.Size(157, 230);
			this.sendFileFromUrlToolStripMenuItem.Name = "sendFileFromUrlToolStripMenuItem";
			this.sendFileFromUrlToolStripMenuItem.Size = new global::System.Drawing.Size(156, 22);
			this.sendFileFromUrlToolStripMenuItem.Text = "Send file from url";
			this.sendFileFromUrlToolStripMenuItem.Click += new global::System.EventHandler(this.sendFileFromUrlToolStripMenuItem_Click);
			this.downloadAndExecuteToolStripMenuItem.Name = "downloadAndExecuteToolStripMenuItem";
			this.downloadAndExecuteToolStripMenuItem.Size = new global::System.Drawing.Size(156, 22);
			this.downloadAndExecuteToolStripMenuItem.Text = "Send file to disk";
			this.downloadAndExecuteToolStripMenuItem.Click += new global::System.EventHandler(this.DownloadAndExecuteToolStripMenuItem_Click);
			this.sENDFILETOMEMORYToolStripMenuItem1.Name = "sENDFILETOMEMORYToolStripMenuItem1";
			this.sENDFILETOMEMORYToolStripMenuItem1.Size = new global::System.Drawing.Size(156, 22);
			this.sENDFILETOMEMORYToolStripMenuItem1.Text = "Send file to memory";
			this.sENDFILETOMEMORYToolStripMenuItem1.Click += new global::System.EventHandler(this.SENDFILETOMEMORYToolStripMenuItem1_Click);
			this.disableUACToolStripMenuItem1.Name = "disableUACToolStripMenuItem1";
			this.disableUACToolStripMenuItem1.Size = new global::System.Drawing.Size(156, 22);
			this.disableUACToolStripMenuItem1.Text = "Disable UAC";
			this.disableUACToolStripMenuItem1.Click += new global::System.EventHandler(this.disableUACToolStripMenuItem1_Click);
			this.disableWDToolStripMenuItem1.Name = "disableWDToolStripMenuItem1";
			this.disableWDToolStripMenuItem1.Size = new global::System.Drawing.Size(156, 22);
			this.disableWDToolStripMenuItem1.Text = "Disable WD";
			this.disableWDToolStripMenuItem1.Click += new global::System.EventHandler(this.disableWDToolStripMenuItem1_Click);
			this.installSchtaskToolStripMenuItem.Name = "installSchtaskToolStripMenuItem";
			this.installSchtaskToolStripMenuItem.Size = new global::System.Drawing.Size(156, 22);
			this.installSchtaskToolStripMenuItem.Text = "Install Schtask";
			this.installSchtaskToolStripMenuItem.Click += new global::System.EventHandler(this.installSchtaskToolStripMenuItem_Click);
			this.uPDATEToolStripMenuItem1.Name = "uPDATEToolStripMenuItem1";
			this.uPDATEToolStripMenuItem1.Size = new global::System.Drawing.Size(156, 22);
			this.uPDATEToolStripMenuItem1.Text = "Update all clients";
			this.uPDATEToolStripMenuItem1.Click += new global::System.EventHandler(this.UPDATEToolStripMenuItem1_Click);
			this.autoKeyloggerToolStripMenuItem.Name = "autoKeyloggerToolStripMenuItem";
			this.autoKeyloggerToolStripMenuItem.Size = new global::System.Drawing.Size(156, 22);
			this.autoKeyloggerToolStripMenuItem.Text = "Auto Keylogger";
			this.autoKeyloggerToolStripMenuItem.Click += new global::System.EventHandler(this.autoKeyloggerToolStripMenuItem_Click);
			this.fakeBinderToolStripMenuItem.Name = "fakeBinderToolStripMenuItem";
			this.fakeBinderToolStripMenuItem.Size = new global::System.Drawing.Size(156, 22);
			this.fakeBinderToolStripMenuItem.Text = "Fake Binder";
			this.fakeBinderToolStripMenuItem.Click += new global::System.EventHandler(this.fakeBinderToolStripMenuItem_Click);
			this.toolStripSeparator4.Name = "toolStripSeparator4";
			this.toolStripSeparator4.Size = new global::System.Drawing.Size(153, 6);
			this.dELETETASKToolStripMenuItem.Name = "dELETETASKToolStripMenuItem";
			this.dELETETASKToolStripMenuItem.Size = new global::System.Drawing.Size(156, 22);
			this.dELETETASKToolStripMenuItem.Text = "Delete";
			this.dELETETASKToolStripMenuItem.Click += new global::System.EventHandler(this.DELETETASKToolStripMenuItem_Click);
			this.performanceCounter1.CategoryName = "Processor";
			this.performanceCounter1.CounterName = "% Processor Time";
			this.performanceCounter1.InstanceName = "_Total";
			this.performanceCounter2.CategoryName = "Memory";
			this.performanceCounter2.CounterName = "% Committed Bytes In Use";
			this.notifyIcon1.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("notifyIcon1.Icon");
			this.notifyIcon1.Text = "Prynt Stealer";
			this.notifyIcon1.Visible = true;
			this.TimerTask.Enabled = true;
			this.TimerTask.Interval = 5000;
			this.TimerTask.Tick += new global::System.EventHandler(this.TimerTask_Tick);
			this.menuStrip1.BackColor = global::System.Drawing.SystemColors.MenuHighlight;
			this.menuStrip1.Dock = global::System.Windows.Forms.DockStyle.None;
			this.menuStrip1.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.FileToolStripMenuItem,
				this.HelpToolStripMenuItem,
				this.toolStripMenuItem1
			});
			this.menuStrip1.Location = new global::System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new global::System.Drawing.Size(208, 24);
			this.menuStrip1.TabIndex = 4;
			this.menuStrip1.Text = "menuStrip1";
			this.FileToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.BuilderToolStripMenuItem,
				this.BlockToolStripMenuItem,
				this.SettingToolStripMenuItem,
				this.ExitToolStripMenuItem
			});
			this.FileToolStripMenuItem.Name = "FileToolStripMenuItem";
			this.FileToolStripMenuItem.Size = new global::System.Drawing.Size(56, 20);
			this.FileToolStripMenuItem.Text = "Builder";
			this.BuilderToolStripMenuItem.Name = "BuilderToolStripMenuItem";
			this.BuilderToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.BuilderToolStripMenuItem.Text = "Builder";
			this.BuilderToolStripMenuItem.Click += new global::System.EventHandler(this.builderToolStripMenuItem1_Click);
			this.BlockToolStripMenuItem.Name = "BlockToolStripMenuItem";
			this.BlockToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.BlockToolStripMenuItem.Text = "Block";
			this.BlockToolStripMenuItem.Click += new global::System.EventHandler(this.BlockToolStripMenuItem_Click);
			this.SettingToolStripMenuItem.Name = "SettingToolStripMenuItem";
			this.SettingToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.SettingToolStripMenuItem.Text = "Setting";
			this.SettingToolStripMenuItem.Click += new global::System.EventHandler(this.SettingToolStripMenuItem_Click);
			this.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem";
			this.ExitToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.ExitToolStripMenuItem.Text = "Exit";
			this.ExitToolStripMenuItem.Click += new global::System.EventHandler(this.ExitToolStripMenuItem_Click);
			this.HelpToolStripMenuItem.DropDownItems.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.DocumentToolStripMenuItem,
				this.AboutToolStripMenuItem
			});
			this.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem";
			this.HelpToolStripMenuItem.Size = new global::System.Drawing.Size(61, 20);
			this.HelpToolStripMenuItem.Text = "Support";
			this.HelpToolStripMenuItem.Click += new global::System.EventHandler(this.HelpToolStripMenuItem_Click);
			this.DocumentToolStripMenuItem.Name = "DocumentToolStripMenuItem";
			this.DocumentToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.DocumentToolStripMenuItem.Text = "Document";
			this.DocumentToolStripMenuItem.Click += new global::System.EventHandler(this.DocumentToolStripMenuItem_Click);
			this.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem";
			this.AboutToolStripMenuItem.Size = new global::System.Drawing.Size(180, 22);
			this.AboutToolStripMenuItem.Text = "About";
			this.AboutToolStripMenuItem.Click += new global::System.EventHandler(this.aboutToolStripMenuItem1_Click);
			this.toolStripMenuItem1.Name = "toolStripMenuItem1";
			this.toolStripMenuItem1.Size = new global::System.Drawing.Size(83, 20);
			this.toolStripMenuItem1.Text = "Private Chat";
			this.toolStripMenuItem1.Click += new global::System.EventHandler(this.toolStripMenuItem1_Click);
			this.splitContainer1.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.Location = new global::System.Drawing.Point(0, 0);
			this.splitContainer1.Name = "splitContainer1";
			this.splitContainer1.Orientation = global::System.Windows.Forms.Orientation.Horizontal;
			this.splitContainer1.Panel1.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("splitContainer1.Panel1.BackgroundImage");
			this.splitContainer1.Panel1.Controls.Add(this.panel2);
			this.splitContainer1.Panel1.Controls.Add(this.bunifuGradientPanel1);
			this.splitContainer1.Panel2.Controls.Add(this.bunifuGradientPanel3);
			this.splitContainer1.Panel2Collapsed = true;
			this.splitContainer1.Size = new global::System.Drawing.Size(925, 436);
			this.splitContainer1.SplitterDistance = 239;
			this.splitContainer1.TabIndex = 5;
			this.panel2.Controls.Add(this.bunifuGradientPanel2);
			this.panel2.Dock = global::System.Windows.Forms.DockStyle.Left;
			this.panel2.Location = new global::System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new global::System.Drawing.Size(249, 436);
			this.panel2.TabIndex = 5;
			this.bunifuGradientPanel2.BackColor = global::System.Drawing.Color.Transparent;
			this.bunifuGradientPanel2.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("bunifuGradientPanel2.BackgroundImage");
			this.bunifuGradientPanel2.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.bunifuGradientPanel2.BorderRadius = 1;
			this.bunifuGradientPanel2.Controls.Add(this.lastLogin);
			this.bunifuGradientPanel2.Controls.Add(this.hwid);
			this.bunifuGradientPanel2.Controls.Add(this.ip);
			this.bunifuGradientPanel2.Controls.Add(this.subscription);
			this.bunifuGradientPanel2.Dock = global::System.Windows.Forms.DockStyle.Left;
			this.bunifuGradientPanel2.GradientBottomLeft = global::System.Drawing.Color.Navy;
			this.bunifuGradientPanel2.GradientBottomRight = global::System.Drawing.Color.Navy;
			this.bunifuGradientPanel2.GradientTopLeft = global::System.Drawing.Color.DodgerBlue;
			this.bunifuGradientPanel2.GradientTopRight = global::System.Drawing.Color.DodgerBlue;
			this.bunifuGradientPanel2.Location = new global::System.Drawing.Point(0, 0);
			this.bunifuGradientPanel2.Name = "bunifuGradientPanel2";
			this.bunifuGradientPanel2.Quality = 10;
			this.bunifuGradientPanel2.Size = new global::System.Drawing.Size(261, 436);
			this.bunifuGradientPanel2.TabIndex = 6;
			this.subscriptionDaysLabel.BackColor = global::System.Drawing.Color.Transparent;
			this.subscriptionDaysLabel.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.subscriptionDaysLabel.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.subscriptionDaysLabel.Location = new global::System.Drawing.Point(29, 126);
			this.subscriptionDaysLabel.Margin = new global::System.Windows.Forms.Padding(2);
			this.subscriptionDaysLabel.Name = "subscriptionDaysLabel";
			this.subscriptionDaysLabel.Size = new global::System.Drawing.Size(130, 17);
			this.subscriptionDaysLabel.TabIndex = 61;
			this.subscriptionDaysLabel.Text = "subscriptionDaysLabel";
			this.lastLogin.BackColor = global::System.Drawing.Color.Transparent;
			this.lastLogin.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.lastLogin.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.lastLogin.Location = new global::System.Drawing.Point(11, 313);
			this.lastLogin.Margin = new global::System.Windows.Forms.Padding(2);
			this.lastLogin.Name = "lastLogin";
			this.lastLogin.Size = new global::System.Drawing.Size(85, 17);
			this.lastLogin.TabIndex = 60;
			this.lastLogin.Text = "lastLoginLabel";
			this.hwid.BackColor = global::System.Drawing.Color.Transparent;
			this.hwid.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.hwid.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.hwid.Location = new global::System.Drawing.Point(11, 270);
			this.hwid.Margin = new global::System.Windows.Forms.Padding(2);
			this.hwid.Name = "hwid";
			this.hwid.Size = new global::System.Drawing.Size(60, 17);
			this.hwid.TabIndex = 58;
			this.hwid.Text = "hwidLabel";
			this.ip.BackColor = global::System.Drawing.Color.Transparent;
			this.ip.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ip.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.ip.Location = new global::System.Drawing.Point(11, 237);
			this.ip.Margin = new global::System.Windows.Forms.Padding(2);
			this.ip.Name = "ip";
			this.ip.Size = new global::System.Drawing.Size(44, 17);
			this.ip.TabIndex = 57;
			this.ip.Text = "ipLabel";
			this.subscription.BackColor = global::System.Drawing.Color.Transparent;
			this.subscription.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.subscription.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.subscription.Location = new global::System.Drawing.Point(11, 200);
			this.subscription.Margin = new global::System.Windows.Forms.Padding(2);
			this.subscription.Name = "subscription";
			this.subscription.Size = new global::System.Drawing.Size(102, 17);
			this.subscription.TabIndex = 56;
			this.subscription.Text = "subscriptionLabel";
			this.expiry.BackColor = global::System.Drawing.Color.Transparent;
			this.expiry.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.expiry.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.expiry.Location = new global::System.Drawing.Point(48, 105);
			this.expiry.Margin = new global::System.Windows.Forms.Padding(2);
			this.expiry.Name = "expiry";
			this.expiry.Size = new global::System.Drawing.Size(65, 17);
			this.expiry.TabIndex = 55;
			this.expiry.Text = "expiryLabel";
			this.key.BackColor = global::System.Drawing.Color.Transparent;
			this.key.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.key.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.key.Location = new global::System.Drawing.Point(40, 84);
			this.key.Margin = new global::System.Windows.Forms.Padding(2);
			this.key.Name = "key";
			this.key.Size = new global::System.Drawing.Size(91, 17);
			this.key.TabIndex = 54;
			this.key.Text = "usernameLabel";
			this.bunifuPictureBox2.AllowFocused = false;
			this.bunifuPictureBox2.Anchor = global::System.Windows.Forms.AnchorStyles.None;
			this.bunifuPictureBox2.AutoSizeHeight = true;
			this.bunifuPictureBox2.BorderRadius = 0;
			this.bunifuPictureBox2.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("bunifuPictureBox2.Image");
			this.bunifuPictureBox2.IsCircle = true;
			this.bunifuPictureBox2.Location = new global::System.Drawing.Point(70, 12);
			this.bunifuPictureBox2.Name = "bunifuPictureBox2";
			this.bunifuPictureBox2.Size = new global::System.Drawing.Size(67, 67);
			this.bunifuPictureBox2.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.bunifuPictureBox2.TabIndex = 0;
			this.bunifuPictureBox2.TabStop = false;
			this.bunifuPictureBox2.Type = global::Bunifu.UI.WinForms.BunifuPictureBox.Types.Square;
			this.bunifuGradientPanel1.BackColor = global::System.Drawing.Color.Transparent;
			this.bunifuGradientPanel1.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("bunifuGradientPanel1.BackgroundImage");
			this.bunifuGradientPanel1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.bunifuGradientPanel1.BorderRadius = 1;
			this.bunifuGradientPanel1.Controls.Add(this.panel1);
			this.bunifuGradientPanel1.Dock = global::System.Windows.Forms.DockStyle.Right;
			this.bunifuGradientPanel1.GradientBottomLeft = global::System.Drawing.Color.Navy;
			this.bunifuGradientPanel1.GradientBottomRight = global::System.Drawing.Color.Navy;
			this.bunifuGradientPanel1.GradientTopLeft = global::System.Drawing.Color.DodgerBlue;
			this.bunifuGradientPanel1.GradientTopRight = global::System.Drawing.Color.DodgerBlue;
			this.bunifuGradientPanel1.Location = new global::System.Drawing.Point(239, 0);
			this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
			this.bunifuGradientPanel1.Quality = 10;
			this.bunifuGradientPanel1.Size = new global::System.Drawing.Size(686, 436);
			this.bunifuGradientPanel1.TabIndex = 4;
			this.panel1.Controls.Add(this.tabControl1);
			this.panel1.Location = new global::System.Drawing.Point(471, 230);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(17, 112);
			this.panel1.TabIndex = 25;
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Controls.Add(this.tabPage4);
			this.tabControl1.Location = new global::System.Drawing.Point(240, 29);
			this.tabControl1.Margin = new global::System.Windows.Forms.Padding(2);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new global::System.Drawing.Size(437, 283);
			this.tabControl1.SizeMode = global::System.Windows.Forms.TabSizeMode.Fixed;
			this.tabControl1.TabIndex = 3;
			this.tabPage1.Controls.Add(this.siticoneLabel1);
			this.tabPage1.Location = new global::System.Drawing.Point(4, 22);
			this.tabPage1.Margin = new global::System.Windows.Forms.Padding(2);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new global::System.Windows.Forms.Padding(2);
			this.tabPage1.Size = new global::System.Drawing.Size(429, 257);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Clients";
			this.listView1.BackColor = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.listView1.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("listView1.BackgroundImage");
			this.listView1.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.listView1.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
			{
				this.lv_ip,
				this.lv_country,
				this.lv_group,
				this.lv_hwid,
				this.lv_user,
				this.lv_camera,
				this.lv_os,
				this.lv_version,
				this.lv_ins,
				this.lv_admin,
				this.lv_av,
				this.lv_ping,
				this.lv_act
			});
			this.listView1.ContextMenuStrip = this.contextMenuClient;
			this.listView1.Dock = global::System.Windows.Forms.DockStyle.Right;
			this.listView1.ForeColor = global::System.Drawing.Color.White;
			this.listView1.FullRowSelect = true;
			this.listView1.HideSelection = false;
			this.listView1.Location = new global::System.Drawing.Point(284, 0);
			this.listView1.Margin = new global::System.Windows.Forms.Padding(2);
			this.listView1.Name = "listView1";
			this.listView1.ShowGroups = false;
			this.listView1.ShowItemToolTips = true;
			this.listView1.Size = new global::System.Drawing.Size(641, 436);
			this.listView1.TabIndex = 0;
			this.listView1.UseCompatibleStateImageBehavior = false;
			this.listView1.View = global::System.Windows.Forms.View.Details;
			this.listView1.ColumnClick += new global::System.Windows.Forms.ColumnClickEventHandler(this.ListView1_ColumnClick);
			this.listView1.KeyDown += new global::System.Windows.Forms.KeyEventHandler(this.listView1_KeyDown);
			this.listView1.MouseMove += new global::System.Windows.Forms.MouseEventHandler(this.listView1_MouseMove);
			this.lv_ip.Text = "IP Port";
			this.lv_ip.Width = 121;
			this.lv_country.Text = "Country";
			this.lv_country.Width = 124;
			this.lv_group.Text = "Group";
			this.lv_hwid.Text = "HWID";
			this.lv_hwid.Width = 117;
			this.lv_user.Text = "User";
			this.lv_user.Width = 117;
			this.lv_camera.Text = "Camera";
			this.lv_os.Text = "OS version";
			this.lv_os.Width = 179;
			this.lv_version.Text = "Client version";
			this.lv_version.Width = 126;
			this.lv_ins.Text = "Installed time";
			this.lv_ins.Width = 120;
			this.lv_admin.Text = "Permission";
			this.lv_admin.Width = 166;
			this.lv_av.Text = "Anti-virus";
			this.lv_av.Width = 136;
			this.lv_ping.Text = "Ping";
			this.lv_act.Text = "Activity Program";
			this.lv_act.Width = 350;
			this.listView2.Anchor = global::System.Windows.Forms.AnchorStyles.None;
			this.listView2.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.listView2.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
			{
				this.columnHeader1,
				this.columnHeader2
			});
			this.listView2.ContextMenuStrip = this.contextMenuLogs;
			this.listView2.FullRowSelect = true;
			this.listView2.GridLines = true;
			this.listView2.HideSelection = false;
			this.listView2.Location = new global::System.Drawing.Point(671, 244);
			this.listView2.Margin = new global::System.Windows.Forms.Padding(2);
			this.listView2.Name = "listView2";
			this.listView2.ShowGroups = false;
			this.listView2.ShowItemToolTips = true;
			this.listView2.Size = new global::System.Drawing.Size(150, 167);
			this.listView2.TabIndex = 2;
			this.listView2.UseCompatibleStateImageBehavior = false;
			this.listView2.View = global::System.Windows.Forms.View.Details;
			this.columnHeader1.Text = "Time";
			this.columnHeader1.Width = 150;
			this.columnHeader2.Text = "Logs";
			this.columnHeader2.Width = 705;
			this.siticoneLabel1.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneLabel1.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.siticoneLabel1.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.siticoneLabel1.Location = new global::System.Drawing.Point(-2, 363);
			this.siticoneLabel1.Margin = new global::System.Windows.Forms.Padding(2);
			this.siticoneLabel1.Name = "siticoneLabel1";
			this.siticoneLabel1.Size = new global::System.Drawing.Size(161, 14);
			this.siticoneLabel1.TabIndex = 62;
			this.siticoneLabel1.Text = "Current Session Valdiation Status: ";
			this.tabPage3.Location = new global::System.Drawing.Point(4, 22);
			this.tabPage3.Margin = new global::System.Windows.Forms.Padding(2);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new global::System.Drawing.Size(429, 257);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Screens";
			this.tabPage3.UseVisualStyleBackColor = true;
			this.listView3.ContextMenuStrip = this.contextMenuThumbnail;
			this.listView3.HideSelection = false;
			this.listView3.LargeImageList = this.ThumbnailImageList;
			this.listView3.Location = new global::System.Drawing.Point(317, 237);
			this.listView3.Margin = new global::System.Windows.Forms.Padding(2);
			this.listView3.Name = "listView3";
			this.listView3.ShowItemToolTips = true;
			this.listView3.Size = new global::System.Drawing.Size(181, 129);
			this.listView3.SmallImageList = this.ThumbnailImageList;
			this.listView3.TabIndex = 0;
			this.listView3.UseCompatibleStateImageBehavior = false;
			this.tabPage4.Controls.Add(this.version);
			this.tabPage4.Controls.Add(this.customerPanelLink);
			this.tabPage4.Controls.Add(this.createDate);
			this.tabPage4.Controls.Add(this.numKeys);
			this.tabPage4.Controls.Add(this.listView4);
			this.tabPage4.Controls.Add(this.numOnlineUsers);
			this.tabPage4.Controls.Add(this.numUsers);
			this.tabPage4.Location = new global::System.Drawing.Point(4, 22);
			this.tabPage4.Margin = new global::System.Windows.Forms.Padding(2);
			this.tabPage4.Name = "tabPage4";
			this.tabPage4.Padding = new global::System.Windows.Forms.Padding(2);
			this.tabPage4.Size = new global::System.Drawing.Size(673, 386);
			this.tabPage4.TabIndex = 3;
			this.tabPage4.Text = "Auto Task";
			this.tabPage4.UseVisualStyleBackColor = true;
			this.version.BackColor = global::System.Drawing.Color.Transparent;
			this.version.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.version.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.version.Location = new global::System.Drawing.Point(4, 288);
			this.version.Margin = new global::System.Windows.Forms.Padding(2);
			this.version.Name = "version";
			this.version.Size = new global::System.Drawing.Size(60, 14);
			this.version.TabIndex = 66;
			this.version.Text = "versionLabel";
			this.customerPanelLink.BackColor = global::System.Drawing.Color.Transparent;
			this.customerPanelLink.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.customerPanelLink.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.customerPanelLink.Location = new global::System.Drawing.Point(62, 217);
			this.customerPanelLink.Margin = new global::System.Windows.Forms.Padding(2);
			this.customerPanelLink.Name = "customerPanelLink";
			this.customerPanelLink.Size = new global::System.Drawing.Size(115, 14);
			this.customerPanelLink.TabIndex = 67;
			this.customerPanelLink.Text = "customerPanelLinkLabel";
			this.createDate.BackColor = global::System.Drawing.Color.Transparent;
			this.createDate.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.createDate.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.createDate.Location = new global::System.Drawing.Point(4, 229);
			this.createDate.Margin = new global::System.Windows.Forms.Padding(2);
			this.createDate.Name = "createDate";
			this.createDate.Size = new global::System.Drawing.Size(76, 14);
			this.createDate.TabIndex = 59;
			this.createDate.Text = "createDateLabel";
			this.createDate.Click += new global::System.EventHandler(this.createDate_Click);
			this.numKeys.BackColor = global::System.Drawing.Color.Transparent;
			this.numKeys.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.numKeys.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.numKeys.Location = new global::System.Drawing.Point(4, 270);
			this.numKeys.Margin = new global::System.Windows.Forms.Padding(2);
			this.numKeys.Name = "numKeys";
			this.numKeys.Size = new global::System.Drawing.Size(68, 14);
			this.numKeys.TabIndex = 65;
			this.numKeys.Text = "numKeysLabel";
			this.listView4.BackColor = global::System.Drawing.SystemColors.HotTrack;
			this.listView4.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.listView4.Columns.AddRange(new global::System.Windows.Forms.ColumnHeader[]
			{
				this.columnHeader4,
				this.columnHeader5
			});
			this.listView4.ContextMenuStrip = this.contextMenuTasks;
			this.listView4.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.listView4.ForeColor = global::System.Drawing.SystemColors.InactiveBorder;
			this.listView4.FullRowSelect = true;
			this.listView4.HideSelection = false;
			this.listView4.Location = new global::System.Drawing.Point(2, 2);
			this.listView4.Margin = new global::System.Windows.Forms.Padding(2);
			this.listView4.Name = "listView4";
			this.listView4.Size = new global::System.Drawing.Size(669, 382);
			this.listView4.TabIndex = 0;
			this.listView4.UseCompatibleStateImageBehavior = false;
			this.listView4.View = global::System.Windows.Forms.View.Details;
			this.columnHeader4.Text = "Task";
			this.columnHeader4.Width = 97;
			this.columnHeader5.Text = "Run times";
			this.columnHeader5.Width = 116;
			this.numOnlineUsers.BackColor = global::System.Drawing.Color.Transparent;
			this.numOnlineUsers.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.numOnlineUsers.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.numOnlineUsers.Location = new global::System.Drawing.Point(4, 249);
			this.numOnlineUsers.Margin = new global::System.Windows.Forms.Padding(2);
			this.numOnlineUsers.Name = "numOnlineUsers";
			this.numOnlineUsers.Size = new global::System.Drawing.Size(103, 14);
			this.numOnlineUsers.TabIndex = 64;
			this.numOnlineUsers.Text = "numOnlineUsersLabel";
			this.numUsers.BackColor = global::System.Drawing.Color.Transparent;
			this.numUsers.Font = new global::System.Drawing.Font("Segoe UI", 7.8f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.numUsers.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.numUsers.Location = new global::System.Drawing.Point(4, 229);
			this.numUsers.Margin = new global::System.Windows.Forms.Padding(2);
			this.numUsers.Name = "numUsers";
			this.numUsers.Size = new global::System.Drawing.Size(72, 14);
			this.numUsers.TabIndex = 63;
			this.numUsers.Text = "numUsersLabel";
			this.bunifuGradientPanel3.BackColor = global::System.Drawing.Color.Transparent;
			this.bunifuGradientPanel3.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("bunifuGradientPanel3.BackgroundImage");
			this.bunifuGradientPanel3.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.bunifuGradientPanel3.BorderRadius = 1;
			this.bunifuGradientPanel3.Controls.Add(this.label11);
			this.bunifuGradientPanel3.Controls.Add(this.label12);
			this.bunifuGradientPanel3.Controls.Add(this.siticoneCircleButton3);
			this.bunifuGradientPanel3.Controls.Add(this.label13);
			this.bunifuGradientPanel3.Controls.Add(this.label14);
			this.bunifuGradientPanel3.Controls.Add(this.label15);
			this.bunifuGradientPanel3.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.bunifuGradientPanel3.GradientBottomLeft = global::System.Drawing.Color.DodgerBlue;
			this.bunifuGradientPanel3.GradientBottomRight = global::System.Drawing.Color.DodgerBlue;
			this.bunifuGradientPanel3.GradientTopLeft = global::System.Drawing.Color.Navy;
			this.bunifuGradientPanel3.GradientTopRight = global::System.Drawing.Color.Navy;
			this.bunifuGradientPanel3.Location = new global::System.Drawing.Point(0, 0);
			this.bunifuGradientPanel3.Name = "bunifuGradientPanel3";
			this.bunifuGradientPanel3.Quality = 10;
			this.bunifuGradientPanel3.Size = new global::System.Drawing.Size(150, 46);
			this.bunifuGradientPanel3.TabIndex = 3;
			this.bunifuGradientPanel3.Click += new global::System.EventHandler(this.bunifuGradientPanel3_Click);
			this.label11.AutoSize = true;
			this.label11.BackColor = global::System.Drawing.Color.Transparent;
			this.label11.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label11.ForeColor = global::System.Drawing.Color.White;
			this.label11.Location = new global::System.Drawing.Point(157, 377);
			this.label11.Name = "label11";
			this.label11.Size = new global::System.Drawing.Size(159, 48);
			this.label11.TabIndex = 24;
			this.label11.Text = "Fuck you flatline Leaked by youhacker";
			this.label12.AutoSize = true;
			this.label12.BackColor = global::System.Drawing.Color.Transparent;
			this.label12.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label12.ForeColor = global::System.Drawing.Color.White;
			this.label12.Location = new global::System.Drawing.Point(31, 392);
			this.label12.Name = "label12";
			this.label12.Size = new global::System.Drawing.Size(120, 16);
			this.label12.TabIndex = 23;
			this.label12.Text = "Ouner and Devs : ";
			this.siticoneCircleButton3.CheckedState.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.CustomImages.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneCircleButton3.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.siticoneCircleButton3.ForeColor = global::System.Drawing.Color.White;
			this.siticoneCircleButton3.HoveredState.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.Location = new global::System.Drawing.Point(141, 339);
			this.siticoneCircleButton3.Name = "siticoneCircleButton3";
			this.siticoneCircleButton3.ShadowDecoration.Mode = global::Siticone.UI.WinForms.Enums.ShadowMode.Circle;
			this.siticoneCircleButton3.ShadowDecoration.Parent = this.siticoneCircleButton3;
			this.siticoneCircleButton3.Size = new global::System.Drawing.Size(223, 26);
			this.siticoneCircleButton3.TabIndex = 22;
			this.siticoneCircleButton3.Text = "https://t.me/toxicnetarmy";
			this.label13.AutoSize = true;
			this.label13.BackColor = global::System.Drawing.Color.Transparent;
			this.label13.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label13.ForeColor = global::System.Drawing.Color.White;
			this.label13.Location = new global::System.Drawing.Point(31, 344);
			this.label13.Name = "label13";
			this.label13.Size = new global::System.Drawing.Size(106, 16);
			this.label13.TabIndex = 21;
			this.label13.Text = "Our Telegram : ";
			this.label14.AutoSize = true;
			this.label14.BackColor = global::System.Drawing.Color.Transparent;
			this.label14.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label14.ForeColor = global::System.Drawing.Color.White;
			this.label14.Location = new global::System.Drawing.Point(31, 267);
			this.label14.Name = "label14";
			this.label14.Size = new global::System.Drawing.Size(284, 32);
			this.label14.TabIndex = 20;
			this.label14.Text = "We tend to provide the best quality hacking\r\n tools for our costumers.";
			this.label15.AutoSize = true;
			this.label15.BackColor = global::System.Drawing.Color.Transparent;
			this.label15.Font = new global::System.Drawing.Font("Bauhaus 93", 10.25f);
			this.label15.ForeColor = global::System.Drawing.Color.White;
			this.label15.Location = new global::System.Drawing.Point(31, 239);
			this.label15.Name = "label15";
			this.label15.Size = new global::System.Drawing.Size(309, 16);
			this.label15.TabIndex = 19;
			this.label15.Text = "Citizen of the world we are Prynt Stealer Team.\r\n";
			this.ConnectTimeout.Enabled = true;
			this.ConnectTimeout.Interval = 5000;
			this.ConnectTimeout.Tick += new global::System.EventHandler(this.ConnectTimeout_Tick);
			this.bunifuGradientPanel5.BackColor = global::System.Drawing.Color.Transparent;
			this.bunifuGradientPanel5.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("bunifuGradientPanel5.BackgroundImage");
			this.bunifuGradientPanel5.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.bunifuGradientPanel5.BorderRadius = 1;
			this.bunifuGradientPanel5.Controls.Add(this.listView1);
			this.bunifuGradientPanel5.Controls.Add(this.bunifuGradientPanel4);
			this.bunifuGradientPanel5.Controls.Add(this.listView3);
			this.bunifuGradientPanel5.Controls.Add(this.listView2);
			this.bunifuGradientPanel5.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.bunifuGradientPanel5.GradientBottomLeft = global::System.Drawing.Color.Black;
			this.bunifuGradientPanel5.GradientBottomRight = global::System.Drawing.Color.Black;
			this.bunifuGradientPanel5.GradientTopLeft = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.bunifuGradientPanel5.GradientTopRight = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.bunifuGradientPanel5.Location = new global::System.Drawing.Point(0, 0);
			this.bunifuGradientPanel5.Name = "bunifuGradientPanel5";
			this.bunifuGradientPanel5.Quality = 10;
			this.bunifuGradientPanel5.Size = new global::System.Drawing.Size(925, 436);
			this.bunifuGradientPanel5.TabIndex = 64;
			this.bunifuGradientPanel4.BackColor = global::System.Drawing.Color.Transparent;
			this.bunifuGradientPanel4.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("bunifuGradientPanel4.BackgroundImage");
			this.bunifuGradientPanel4.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.bunifuGradientPanel4.BorderRadius = 1;
			this.bunifuGradientPanel4.Controls.Add(this.bunifuPictureBox2);
			this.bunifuGradientPanel4.Controls.Add(this.siticoneLabel6);
			this.bunifuGradientPanel4.Controls.Add(this.expiry);
			this.bunifuGradientPanel4.Controls.Add(this.siticoneLabel5);
			this.bunifuGradientPanel4.Controls.Add(this.siticoneLabel4);
			this.bunifuGradientPanel4.Controls.Add(this.key);
			this.bunifuGradientPanel4.Controls.Add(this.subscriptionDaysLabel);
			this.bunifuGradientPanel4.Controls.Add(this.siticoneLabel3);
			this.bunifuGradientPanel4.Controls.Add(this.siticoneLabel2);
			this.bunifuGradientPanel4.Controls.Add(this.pictureBox5);
			this.bunifuGradientPanel4.Controls.Add(this.pictureBox4);
			this.bunifuGradientPanel4.Controls.Add(this.pictureBox3);
			this.bunifuGradientPanel4.Controls.Add(this.pictureBox2);
			this.bunifuGradientPanel4.Controls.Add(this.pictureBox1);
			this.bunifuGradientPanel4.Dock = global::System.Windows.Forms.DockStyle.Left;
			this.bunifuGradientPanel4.GradientBottomLeft = global::System.Drawing.Color.Black;
			this.bunifuGradientPanel4.GradientBottomRight = global::System.Drawing.Color.Black;
			this.bunifuGradientPanel4.GradientTopLeft = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.bunifuGradientPanel4.GradientTopRight = global::System.Drawing.Color.FromArgb(64, 64, 64);
			this.bunifuGradientPanel4.Location = new global::System.Drawing.Point(0, 0);
			this.bunifuGradientPanel4.Name = "bunifuGradientPanel4";
			this.bunifuGradientPanel4.Quality = 10;
			this.bunifuGradientPanel4.Size = new global::System.Drawing.Size(279, 436);
			this.bunifuGradientPanel4.TabIndex = 64;
			this.bunifuGradientPanel4.Click += new global::System.EventHandler(this.bunifuGradientPanel4_Click);
			this.pictureBox1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			this.pictureBox1.Location = new global::System.Drawing.Point(12, 176);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new global::System.Drawing.Size(33, 30);
			this.pictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.pictureBox2.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox2.Image");
			this.pictureBox2.Location = new global::System.Drawing.Point(12, 214);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new global::System.Drawing.Size(34, 30);
			this.pictureBox2.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox2.TabIndex = 1;
			this.pictureBox2.TabStop = false;
			this.pictureBox3.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox3.Image");
			this.pictureBox3.Location = new global::System.Drawing.Point(12, 250);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new global::System.Drawing.Size(33, 30);
			this.pictureBox3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox3.TabIndex = 2;
			this.pictureBox3.TabStop = false;
			this.pictureBox4.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox4.Image");
			this.pictureBox4.Location = new global::System.Drawing.Point(11, 286);
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.Size = new global::System.Drawing.Size(33, 30);
			this.pictureBox4.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox4.TabIndex = 3;
			this.pictureBox4.TabStop = false;
			this.pictureBox5.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox5.Image");
			this.pictureBox5.Location = new global::System.Drawing.Point(11, 322);
			this.pictureBox5.Name = "pictureBox5";
			this.pictureBox5.Size = new global::System.Drawing.Size(33, 30);
			this.pictureBox5.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox5.TabIndex = 4;
			this.pictureBox5.TabStop = false;
			this.siticoneLabel2.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneLabel2.Font = new global::System.Drawing.Font("Bauhaus 93", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.siticoneLabel2.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.siticoneLabel2.Location = new global::System.Drawing.Point(60, 189);
			this.siticoneLabel2.Margin = new global::System.Windows.Forms.Padding(2);
			this.siticoneLabel2.Name = "siticoneLabel2";
			this.siticoneLabel2.Size = new global::System.Drawing.Size(54, 20);
			this.siticoneLabel2.TabIndex = 55;
			this.siticoneLabel2.Text = "Builder";
			this.siticoneLabel2.Click += new global::System.EventHandler(this.siticoneLabel2_Click);
			this.siticoneLabel3.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneLabel3.Font = new global::System.Drawing.Font("Bauhaus 93", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.siticoneLabel3.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.siticoneLabel3.Location = new global::System.Drawing.Point(60, 227);
			this.siticoneLabel3.Margin = new global::System.Windows.Forms.Padding(2);
			this.siticoneLabel3.Name = "siticoneLabel3";
			this.siticoneLabel3.Size = new global::System.Drawing.Size(58, 20);
			this.siticoneLabel3.TabIndex = 56;
			this.siticoneLabel3.Text = "Settings";
			this.siticoneLabel3.Click += new global::System.EventHandler(this.siticoneLabel3_Click);
			this.siticoneLabel4.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneLabel4.Font = new global::System.Drawing.Font("Bauhaus 93", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.siticoneLabel4.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.siticoneLabel4.Location = new global::System.Drawing.Point(60, 263);
			this.siticoneLabel4.Margin = new global::System.Windows.Forms.Padding(2);
			this.siticoneLabel4.Name = "siticoneLabel4";
			this.siticoneLabel4.Size = new global::System.Drawing.Size(44, 20);
			this.siticoneLabel4.TabIndex = 57;
			this.siticoneLabel4.Text = "Block";
			this.siticoneLabel4.Click += new global::System.EventHandler(this.siticoneLabel4_Click);
			this.siticoneLabel5.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneLabel5.Font = new global::System.Drawing.Font("Bauhaus 93", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.siticoneLabel5.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.siticoneLabel5.Location = new global::System.Drawing.Point(54, 299);
			this.siticoneLabel5.Margin = new global::System.Windows.Forms.Padding(2);
			this.siticoneLabel5.Name = "siticoneLabel5";
			this.siticoneLabel5.Size = new global::System.Drawing.Size(83, 20);
			this.siticoneLabel5.TabIndex = 58;
			this.siticoneLabel5.Text = "Support Bot";
			this.siticoneLabel5.Click += new global::System.EventHandler(this.siticoneLabel5_Click);
			this.siticoneLabel6.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneLabel6.Font = new global::System.Drawing.Font("Bauhaus 93", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.siticoneLabel6.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.siticoneLabel6.Location = new global::System.Drawing.Point(54, 335);
			this.siticoneLabel6.Margin = new global::System.Windows.Forms.Padding(2);
			this.siticoneLabel6.Name = "siticoneLabel6";
			this.siticoneLabel6.Size = new global::System.Drawing.Size(129, 20);
			this.siticoneLabel6.TabIndex = 59;
			this.siticoneLabel6.Text = "Private Users Chat";
			this.siticoneLabel6.Click += new global::System.EventHandler(this.siticoneLabel6_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(925, 458);
			base.Controls.Add(this.bunifuGradientPanel5);
			base.Controls.Add(this.splitContainer1);
			base.Controls.Add(this.statusStrip1);
			base.Controls.Add(this.menuStrip1);
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.MainMenuStrip = this.menuStrip1;
			base.Margin = new global::System.Windows.Forms.Padding(2);
			this.MaximumSize = new global::System.Drawing.Size(941, 497);
			this.MinimumSize = new global::System.Drawing.Size(941, 497);
			base.Name = "Form1";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Prynt Stealer";
			base.Activated += new global::System.EventHandler(this.Form1_Activated);
			base.Deactivate += new global::System.EventHandler(this.Form1_Deactivate);
			base.FormClosed += new global::System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
			base.Load += new global::System.EventHandler(this.Form1_Load);
			this.contextMenuClient.ResumeLayout(false);
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			this.contextMenuLogs.ResumeLayout(false);
			this.contextMenuThumbnail.ResumeLayout(false);
			this.contextMenuTasks.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.performanceCounter1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.performanceCounter2).EndInit();
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel2.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer1).EndInit();
			this.splitContainer1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.bunifuGradientPanel2.ResumeLayout(false);
			this.bunifuGradientPanel2.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.bunifuPictureBox2).EndInit();
			this.bunifuGradientPanel1.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			this.tabPage4.ResumeLayout(false);
			this.tabPage4.PerformLayout();
			this.bunifuGradientPanel3.ResumeLayout(false);
			this.bunifuGradientPanel3.PerformLayout();
			this.bunifuGradientPanel5.ResumeLayout(false);
			this.bunifuGradientPanel4.ResumeLayout(false);
			this.bunifuGradientPanel4.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox2).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox4).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox5).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000024 RID: 36
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000025 RID: 37
		private global::System.Windows.Forms.StatusStrip statusStrip1;

		// Token: 0x04000026 RID: 38
		private global::System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;

		// Token: 0x04000027 RID: 39
		private global::System.Windows.Forms.Timer ping;

		// Token: 0x04000028 RID: 40
		private global::System.Windows.Forms.Timer UpdateUI;

		// Token: 0x04000029 RID: 41
		private global::System.Diagnostics.PerformanceCounter performanceCounter1;

		// Token: 0x0400002A RID: 42
		private global::System.Diagnostics.PerformanceCounter performanceCounter2;

		// Token: 0x0400002B RID: 43
		private global::System.Windows.Forms.ContextMenuStrip contextMenuThumbnail;

		// Token: 0x0400002C RID: 44
		private global::System.Windows.Forms.ToolStripMenuItem sTARTToolStripMenuItem;

		// Token: 0x0400002D RID: 45
		private global::System.Windows.Forms.ToolStripMenuItem sTOPToolStripMenuItem;

		// Token: 0x0400002E RID: 46
		public global::System.Windows.Forms.ImageList ThumbnailImageList;

		// Token: 0x0400002F RID: 47
		public global::System.Windows.Forms.NotifyIcon notifyIcon1;

		// Token: 0x04000030 RID: 48
		private global::System.Windows.Forms.ContextMenuStrip contextMenuTasks;

		// Token: 0x04000031 RID: 49
		private global::System.Windows.Forms.ToolStripMenuItem downloadAndExecuteToolStripMenuItem;

		// Token: 0x04000032 RID: 50
		private global::System.Windows.Forms.ToolStripMenuItem sENDFILETOMEMORYToolStripMenuItem1;

		// Token: 0x04000033 RID: 51
		private global::System.Windows.Forms.ToolStripMenuItem uPDATEToolStripMenuItem1;

		// Token: 0x04000034 RID: 52
		private global::System.Windows.Forms.ToolStripSeparator toolStripSeparator4;

		// Token: 0x04000035 RID: 53
		private global::System.Windows.Forms.ToolStripMenuItem dELETETASKToolStripMenuItem;

		// Token: 0x04000036 RID: 54
		private global::System.Windows.Forms.Timer TimerTask;

		// Token: 0x04000037 RID: 55
		private global::System.Windows.Forms.ContextMenuStrip contextMenuLogs;

		// Token: 0x04000038 RID: 56
		private global::System.Windows.Forms.ToolStripMenuItem cLEARToolStripMenuItem;

		// Token: 0x04000039 RID: 57
		private global::System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;

		// Token: 0x0400003A RID: 58
		private global::System.Windows.Forms.MenuStrip menuStrip1;

		// Token: 0x0400003B RID: 59
		private global::System.Windows.Forms.ContextMenuStrip contextMenuClient;

		// Token: 0x0400003C RID: 60
		private global::System.Windows.Forms.ToolStripMenuItem RemoteManagerToolStripMenuItem;

		// Token: 0x0400003D RID: 61
		private global::System.Windows.Forms.ToolStripMenuItem RemoteShellToolStripMenuItem;

		// Token: 0x0400003E RID: 62
		private global::System.Windows.Forms.ToolStripMenuItem RemoteScreenToolStripMenuItem;

		// Token: 0x0400003F RID: 63
		private global::System.Windows.Forms.ToolStripMenuItem RemoteCameraToolStripMenuItem;

		// Token: 0x04000040 RID: 64
		private global::System.Windows.Forms.ToolStripMenuItem FileManagerToolStripMenuItem1;

		// Token: 0x04000041 RID: 65
		private global::System.Windows.Forms.ToolStripMenuItem ProcessManagerToolStripMenuItem;

		// Token: 0x04000042 RID: 66
		private global::System.Windows.Forms.ToolStripMenuItem ProgramNotificationToolStripMenuItem;

		// Token: 0x04000043 RID: 67
		private global::System.Windows.Forms.ToolStripMenuItem RemoteControlToolStripMenuItem;

		// Token: 0x04000044 RID: 68
		private global::System.Windows.Forms.ToolStripMenuItem SendFileToolStripMenuItem1;

		// Token: 0x04000045 RID: 69
		private global::System.Windows.Forms.ToolStripMenuItem SendFileToDiskToolStripMenuItem;

		// Token: 0x04000046 RID: 70
		private global::System.Windows.Forms.ToolStripMenuItem SendFileToMemoryToolStripMenuItem;

		// Token: 0x04000047 RID: 71
		private global::System.Windows.Forms.ToolStripMenuItem MessageBoxToolStripMenuItem;

		// Token: 0x04000048 RID: 72
		private global::System.Windows.Forms.ToolStripMenuItem ChatToolStripMenuItem1;

		// Token: 0x04000049 RID: 73
		private global::System.Windows.Forms.ToolStripMenuItem VisteWebsiteToolStripMenuItem1;

		// Token: 0x0400004A RID: 74
		private global::System.Windows.Forms.ToolStripMenuItem ChangeWallpaperToolStripMenuItem1;

		// Token: 0x0400004B RID: 75
		private global::System.Windows.Forms.ToolStripMenuItem KeyloggerToolStripMenuItem1;

		// Token: 0x0400004C RID: 76
		private global::System.Windows.Forms.ToolStripMenuItem SystemControlToolStripMenuItem;

		// Token: 0x0400004D RID: 77
		private global::System.Windows.Forms.ToolStripMenuItem ClientControlToolStripMenuItem;

		// Token: 0x0400004E RID: 78
		private global::System.Windows.Forms.ToolStripMenuItem StopToolStripMenuItem1;

		// Token: 0x0400004F RID: 79
		private global::System.Windows.Forms.ToolStripMenuItem RestartToolStripMenuItem1;

		// Token: 0x04000050 RID: 80
		private global::System.Windows.Forms.ToolStripMenuItem UpdateToolStripMenuItem;

		// Token: 0x04000051 RID: 81
		private global::System.Windows.Forms.ToolStripMenuItem UninstallToolStripMenuItem;

		// Token: 0x04000052 RID: 82
		private global::System.Windows.Forms.ToolStripMenuItem ClientFolderToolStripMenuItem;

		// Token: 0x04000053 RID: 83
		private global::System.Windows.Forms.ToolStripMenuItem SystemToolStripMenuItem;

		// Token: 0x04000054 RID: 84
		private global::System.Windows.Forms.ToolStripMenuItem ShutDownToolStripMenuItem;

		// Token: 0x04000055 RID: 85
		private global::System.Windows.Forms.ToolStripMenuItem RebootToolStripMenuItem;

		// Token: 0x04000056 RID: 86
		private global::System.Windows.Forms.ToolStripMenuItem LogoutToolStripMenuItem;

		// Token: 0x04000057 RID: 87
		private global::System.Windows.Forms.ToolStripMenuItem BypassUACAToolStripMenuItem;

		// Token: 0x04000058 RID: 88
		private global::System.Windows.Forms.SplitContainer splitContainer1;

		// Token: 0x04000059 RID: 89
		private global::System.Windows.Forms.TabControl tabControl1;

		// Token: 0x0400005A RID: 90
		private global::System.Windows.Forms.TabPage tabPage1;

		// Token: 0x0400005B RID: 91
		public global::System.Windows.Forms.ListView listView1;

		// Token: 0x0400005C RID: 92
		private global::System.Windows.Forms.ColumnHeader lv_ip;

		// Token: 0x0400005D RID: 93
		private global::System.Windows.Forms.ColumnHeader lv_country;

		// Token: 0x0400005E RID: 94
		public global::System.Windows.Forms.ColumnHeader lv_hwid;

		// Token: 0x0400005F RID: 95
		private global::System.Windows.Forms.ColumnHeader lv_user;

		// Token: 0x04000060 RID: 96
		private global::System.Windows.Forms.ColumnHeader lv_os;

		// Token: 0x04000061 RID: 97
		private global::System.Windows.Forms.ColumnHeader lv_version;

		// Token: 0x04000062 RID: 98
		private global::System.Windows.Forms.ColumnHeader lv_ins;

		// Token: 0x04000063 RID: 99
		private global::System.Windows.Forms.ColumnHeader lv_admin;

		// Token: 0x04000064 RID: 100
		private global::System.Windows.Forms.ColumnHeader lv_av;

		// Token: 0x04000065 RID: 101
		public global::System.Windows.Forms.ColumnHeader lv_ping;

		// Token: 0x04000066 RID: 102
		public global::System.Windows.Forms.ColumnHeader lv_act;

		// Token: 0x04000067 RID: 103
		private global::System.Windows.Forms.TabPage tabPage3;

		// Token: 0x04000068 RID: 104
		public global::System.Windows.Forms.ListView listView3;

		// Token: 0x04000069 RID: 105
		private global::System.Windows.Forms.TabPage tabPage4;

		// Token: 0x0400006A RID: 106
		public global::System.Windows.Forms.ListView listView4;

		// Token: 0x0400006B RID: 107
		private global::System.Windows.Forms.ColumnHeader columnHeader4;

		// Token: 0x0400006C RID: 108
		private global::System.Windows.Forms.ColumnHeader columnHeader5;

		// Token: 0x0400006D RID: 109
		public global::System.Windows.Forms.ListView listView2;

		// Token: 0x0400006E RID: 110
		private global::System.Windows.Forms.ColumnHeader columnHeader1;

		// Token: 0x0400006F RID: 111
		private global::System.Windows.Forms.ColumnHeader columnHeader2;

		// Token: 0x04000070 RID: 112
		private global::System.Windows.Forms.ToolStripMenuItem FileToolStripMenuItem;

		// Token: 0x04000071 RID: 113
		private global::System.Windows.Forms.ToolStripMenuItem BuilderToolStripMenuItem;

		// Token: 0x04000072 RID: 114
		private global::System.Windows.Forms.ToolStripMenuItem ExitToolStripMenuItem;

		// Token: 0x04000073 RID: 115
		private global::System.Windows.Forms.ToolStripMenuItem HelpToolStripMenuItem;

		// Token: 0x04000074 RID: 116
		private global::System.Windows.Forms.ToolStripMenuItem DocumentToolStripMenuItem;

		// Token: 0x04000075 RID: 117
		private global::System.Windows.Forms.ToolStripMenuItem AboutToolStripMenuItem;

		// Token: 0x04000076 RID: 118
		private global::System.Windows.Forms.ToolStripMenuItem StartToolStripMenuItem1;

		// Token: 0x04000077 RID: 119
		private global::System.Windows.Forms.ToolStripMenuItem StopToolStripMenuItem2;

		// Token: 0x04000078 RID: 120
		private global::System.Windows.Forms.ToolStripMenuItem BlockToolStripMenuItem;

		// Token: 0x04000079 RID: 121
		private global::System.Windows.Forms.ToolStripMenuItem FileSearchToolStripMenuItem;

		// Token: 0x0400007A RID: 122
		private global::System.Windows.Forms.ColumnHeader lv_group;

		// Token: 0x0400007B RID: 123
		private global::System.Windows.Forms.ToolStripMenuItem InformationToolStripMenuItem;

		// Token: 0x0400007C RID: 124
		private global::System.Windows.Forms.ToolStripMenuItem MalwareToolStripMenuItem;

		// Token: 0x0400007D RID: 125
		private global::System.Windows.Forms.ToolStripMenuItem dDOSToolStripMenuItem;

		// Token: 0x0400007E RID: 126
		private global::System.Windows.Forms.ToolStripMenuItem RansomwareToolStripMenuItem;

		// Token: 0x0400007F RID: 127
		private global::System.Windows.Forms.ToolStripMenuItem EncryptToolStripMenuItem;

		// Token: 0x04000080 RID: 128
		private global::System.Windows.Forms.ToolStripMenuItem DecryptToolStripMenuItem;

		// Token: 0x04000081 RID: 129
		private global::System.Windows.Forms.ToolStripMenuItem DisableWDToolStripMenuItem;

		// Token: 0x04000082 RID: 130
		private global::System.Windows.Forms.ToolStripMenuItem RecordToolStripMenuItem;

		// Token: 0x04000083 RID: 131
		private global::System.Windows.Forms.ToolStripMenuItem SilentCleanupToolStripMenuItem;

		// Token: 0x04000084 RID: 132
		private global::System.Windows.Forms.ToolStripMenuItem RunasToolStripMenuItem;

		// Token: 0x04000085 RID: 133
		private global::System.Windows.Forms.ToolStripMenuItem InstallToolStripMenuItem;

		// Token: 0x04000086 RID: 134
		private global::System.Windows.Forms.ToolStripMenuItem SchtaskInstallToolStripMenuItem;

		// Token: 0x04000087 RID: 135
		private global::System.Windows.Forms.ToolStripMenuItem PasswordRecoveryToolStripMenuItem;

		// Token: 0x04000088 RID: 136
		private global::System.Windows.Forms.ToolStripMenuItem FodhelperToolStripMenuItem;

		// Token: 0x04000089 RID: 137
		private global::System.Windows.Forms.ToolStripMenuItem DisableUACToolStripMenuItem;

		// Token: 0x0400008A RID: 138
		private global::System.Windows.Forms.ToolStripMenuItem CompMgmtLauncherToolStripMenuItem;

		// Token: 0x0400008B RID: 139
		private global::System.Windows.Forms.ToolStripMenuItem SettingToolStripMenuItem;

		// Token: 0x0400008C RID: 140
		private global::System.Windows.Forms.ToolStripMenuItem autoKeyloggerToolStripMenuItem;

		// Token: 0x0400008D RID: 141
		private global::System.Windows.Forms.ToolStripMenuItem SchtaskUninstallToolStripMenuItem;

		// Token: 0x0400008E RID: 142
		private global::System.Windows.Forms.ColumnHeader lv_camera;

		// Token: 0x0400008F RID: 143
		private global::System.Windows.Forms.ToolStripMenuItem fakeBinderToolStripMenuItem;

		// Token: 0x04000090 RID: 144
		private global::System.Windows.Forms.ToolStripMenuItem netstatToolStripMenuItem;

		// Token: 0x04000091 RID: 145
		private global::System.Windows.Forms.ToolStripMenuItem fromUrlToolStripMenuItem;

		// Token: 0x04000092 RID: 146
		private global::System.Windows.Forms.ToolStripMenuItem sendFileFromUrlToolStripMenuItem;

		// Token: 0x04000093 RID: 147
		private global::System.Windows.Forms.ToolStripMenuItem installSchtaskToolStripMenuItem;

		// Token: 0x04000094 RID: 148
		private global::System.Windows.Forms.ToolStripMenuItem disableUACToolStripMenuItem1;

		// Token: 0x04000095 RID: 149
		private global::System.Windows.Forms.ToolStripMenuItem disableWDToolStripMenuItem1;

		// Token: 0x04000096 RID: 150
		private global::System.Windows.Forms.Timer ConnectTimeout;

		// Token: 0x04000097 RID: 151
		private global::System.Windows.Forms.ToolStripMenuItem remoteRegeditToolStripMenuItem;

		// Token: 0x04000098 RID: 152
		private global::System.Windows.Forms.ToolStripMenuItem normalInstallToolStripMenuItem;

		// Token: 0x04000099 RID: 153
		private global::System.Windows.Forms.ToolStripMenuItem normalUninstallToolStripMenuItem;

		// Token: 0x0400009A RID: 154
		private global::System.Windows.Forms.ToolStripMenuItem justForFunToolStripMenuItem;

		// Token: 0x0400009B RID: 155
		private global::Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;

		// Token: 0x0400009C RID: 156
		private global::Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel2;

		// Token: 0x0400009D RID: 157
		private global::Bunifu.UI.WinForms.BunifuPictureBox bunifuPictureBox2;

		// Token: 0x0400009E RID: 158
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x0400009F RID: 159
		private global::Siticone.UI.WinForms.SiticoneLabel siticoneLabel1;

		// Token: 0x040000A0 RID: 160
		private global::Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel3;

		// Token: 0x040000A1 RID: 161
		private global::System.Windows.Forms.Label label11;

		// Token: 0x040000A2 RID: 162
		private global::System.Windows.Forms.Label label12;

		// Token: 0x040000A3 RID: 163
		private global::Siticone.UI.WinForms.SiticoneCircleButton siticoneCircleButton3;

		// Token: 0x040000A4 RID: 164
		private global::System.Windows.Forms.Label label13;

		// Token: 0x040000A5 RID: 165
		private global::System.Windows.Forms.Label label14;

		// Token: 0x040000A6 RID: 166
		private global::System.Windows.Forms.Label label15;

		// Token: 0x040000A7 RID: 167
		private global::Siticone.UI.WinForms.SiticoneLabel customerPanelLink;

		// Token: 0x040000A8 RID: 168
		private global::Siticone.UI.WinForms.SiticoneLabel version;

		// Token: 0x040000A9 RID: 169
		private global::Siticone.UI.WinForms.SiticoneLabel numKeys;

		// Token: 0x040000AA RID: 170
		private global::Siticone.UI.WinForms.SiticoneLabel numOnlineUsers;

		// Token: 0x040000AB RID: 171
		private global::Siticone.UI.WinForms.SiticoneLabel numUsers;

		// Token: 0x040000AC RID: 172
		private global::Siticone.UI.WinForms.SiticoneLabel subscriptionDaysLabel;

		// Token: 0x040000AD RID: 173
		private global::Siticone.UI.WinForms.SiticoneLabel lastLogin;

		// Token: 0x040000AE RID: 174
		private global::Siticone.UI.WinForms.SiticoneLabel createDate;

		// Token: 0x040000AF RID: 175
		private global::Siticone.UI.WinForms.SiticoneLabel hwid;

		// Token: 0x040000B0 RID: 176
		private global::Siticone.UI.WinForms.SiticoneLabel ip;

		// Token: 0x040000B1 RID: 177
		private global::Siticone.UI.WinForms.SiticoneLabel subscription;

		// Token: 0x040000B2 RID: 178
		private global::Siticone.UI.WinForms.SiticoneLabel expiry;

		// Token: 0x040000B3 RID: 179
		private global::Siticone.UI.WinForms.SiticoneLabel key;

		// Token: 0x040000B4 RID: 180
		private global::System.Windows.Forms.Panel panel2;

		// Token: 0x040000B5 RID: 181
		private global::System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;

		// Token: 0x040000B6 RID: 182
		private global::Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel5;

		// Token: 0x040000B7 RID: 183
		private global::Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel4;

		// Token: 0x040000B8 RID: 184
		private global::Siticone.UI.WinForms.SiticoneLabel siticoneLabel6;

		// Token: 0x040000B9 RID: 185
		private global::Siticone.UI.WinForms.SiticoneLabel siticoneLabel5;

		// Token: 0x040000BA RID: 186
		private global::Siticone.UI.WinForms.SiticoneLabel siticoneLabel4;

		// Token: 0x040000BB RID: 187
		private global::Siticone.UI.WinForms.SiticoneLabel siticoneLabel3;

		// Token: 0x040000BC RID: 188
		private global::Siticone.UI.WinForms.SiticoneLabel siticoneLabel2;

		// Token: 0x040000BD RID: 189
		private global::System.Windows.Forms.PictureBox pictureBox5;

		// Token: 0x040000BE RID: 190
		private global::System.Windows.Forms.PictureBox pictureBox4;

		// Token: 0x040000BF RID: 191
		private global::System.Windows.Forms.PictureBox pictureBox3;

		// Token: 0x040000C0 RID: 192
		private global::System.Windows.Forms.PictureBox pictureBox2;

		// Token: 0x040000C1 RID: 193
		private global::System.Windows.Forms.PictureBox pictureBox1;
	}
}
