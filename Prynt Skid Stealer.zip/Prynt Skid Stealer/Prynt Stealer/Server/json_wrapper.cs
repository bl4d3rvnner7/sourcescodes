﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;

namespace Server
{
	// Token: 0x02000023 RID: 35
	public class json_wrapper
	{
		// Token: 0x06000156 RID: 342 RVA: 0x00002696 File Offset: 0x00000896
		public static bool is_serializable(Type to_check)
		{
			return to_check.IsSerializable || to_check.IsDefined(typeof(DataContractAttribute), true);
		}

		// Token: 0x06000157 RID: 343 RVA: 0x00012A68 File Offset: 0x00010C68
		public json_wrapper(object obj_to_work_with)
		{
			this.current_object = obj_to_work_with;
			Type type = this.current_object.GetType();
			this.serializer = new DataContractJsonSerializer(type);
			if (!json_wrapper.is_serializable(type))
			{
				throw new Exception(string.Format("the object {0} isn't a serializable", this.current_object));
			}
		}

		// Token: 0x06000158 RID: 344 RVA: 0x00012AB8 File Offset: 0x00010CB8
		public object string_to_object(string json)
		{
			object result;
			using (MemoryStream memoryStream = new MemoryStream(Encoding.Default.GetBytes(json)))
			{
				result = this.serializer.ReadObject(memoryStream);
			}
			return result;
		}

		// Token: 0x06000159 RID: 345 RVA: 0x000026B3 File Offset: 0x000008B3
		public T string_to_generic<T>(string json)
		{
			return (T)((object)this.string_to_object(json));
		}

		// Token: 0x0400012C RID: 300
		private DataContractJsonSerializer serializer;

		// Token: 0x0400012D RID: 301
		private object current_object;
	}
}
