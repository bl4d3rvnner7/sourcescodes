﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace Server.Algorithm
{
	// Token: 0x020000A7 RID: 167
	public static class Sha256
	{
		// Token: 0x0600054E RID: 1358 RVA: 0x00035794 File Offset: 0x00033994
		public static string ComputeHash(string input)
		{
			byte[] array = Encoding.UTF8.GetBytes(input);
			using (SHA256Managed sha256Managed = new SHA256Managed())
			{
				array = sha256Managed.ComputeHash(array);
			}
			StringBuilder stringBuilder = new StringBuilder();
			foreach (byte b in array)
			{
				stringBuilder.Append(b.ToString("X2"));
			}
			return stringBuilder.ToString().ToUpper();
		}

		// Token: 0x0600054F RID: 1359 RVA: 0x00035818 File Offset: 0x00033A18
		public static byte[] ComputeHash(byte[] input)
		{
			byte[] result;
			using (SHA256Managed sha256Managed = new SHA256Managed())
			{
				result = sha256Managed.ComputeHash(input);
			}
			return result;
		}
	}
}
