﻿using System;
using System.IO;
using System.Security.Cryptography;

namespace Server.Algorithm
{
	// Token: 0x020000A6 RID: 166
	public static class GetHash
	{
		// Token: 0x0600054D RID: 1357 RVA: 0x00035740 File Offset: 0x00033940
		public static string GetChecksum(string file)
		{
			string result;
			using (FileStream fileStream = File.OpenRead(file))
			{
				result = BitConverter.ToString(new SHA256Managed().ComputeHash(fileStream)).Replace("-", string.Empty);
			}
			return result;
		}
	}
}
