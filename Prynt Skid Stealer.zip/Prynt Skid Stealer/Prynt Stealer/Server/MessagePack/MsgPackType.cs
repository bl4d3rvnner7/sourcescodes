﻿using System;

namespace Server.MessagePack
{
	// Token: 0x02000031 RID: 49
	public enum MsgPackType
	{
		// Token: 0x04000178 RID: 376
		Unknown,
		// Token: 0x04000179 RID: 377
		Null,
		// Token: 0x0400017A RID: 378
		Map,
		// Token: 0x0400017B RID: 379
		Array,
		// Token: 0x0400017C RID: 380
		String,
		// Token: 0x0400017D RID: 381
		Integer,
		// Token: 0x0400017E RID: 382
		UInt64,
		// Token: 0x0400017F RID: 383
		Boolean,
		// Token: 0x04000180 RID: 384
		Float,
		// Token: 0x04000181 RID: 385
		Single,
		// Token: 0x04000182 RID: 386
		DateTime,
		// Token: 0x04000183 RID: 387
		Binary
	}
}
