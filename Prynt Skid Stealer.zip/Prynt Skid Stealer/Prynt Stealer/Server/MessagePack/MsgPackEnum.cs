﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Server.MessagePack
{
	// Token: 0x0200002C RID: 44
	public class MsgPackEnum : IEnumerator
	{
		// Token: 0x060001E8 RID: 488 RVA: 0x00002EDD File Offset: 0x000010DD
		public MsgPackEnum(List<MsgPack> obj)
		{
			this.children = obj;
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x060001E9 RID: 489 RVA: 0x00002EF3 File Offset: 0x000010F3
		object IEnumerator.Current
		{
			get
			{
				return this.children[this.position];
			}
		}

		// Token: 0x060001EA RID: 490 RVA: 0x00002F06 File Offset: 0x00001106
		bool IEnumerator.MoveNext()
		{
			this.position++;
			return this.position < this.children.Count;
		}

		// Token: 0x060001EB RID: 491 RVA: 0x00002F29 File Offset: 0x00001129
		void IEnumerator.Reset()
		{
			this.position = -1;
		}

		// Token: 0x0400015E RID: 350
		private List<MsgPack> children;

		// Token: 0x0400015F RID: 351
		private int position = -1;
	}
}
