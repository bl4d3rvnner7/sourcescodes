﻿using System;
using System.Text;

namespace Server.MessagePack
{
	// Token: 0x0200002B RID: 43
	public class BytesTools
	{
		// Token: 0x060001DD RID: 477 RVA: 0x00002E65 File Offset: 0x00001065
		public static byte[] GetUtf8Bytes(string s)
		{
			return BytesTools.utf8Encode.GetBytes(s);
		}

		// Token: 0x060001DE RID: 478 RVA: 0x00002E72 File Offset: 0x00001072
		public static string GetString(byte[] utf8Bytes)
		{
			return BytesTools.utf8Encode.GetString(utf8Bytes);
		}

		// Token: 0x060001DF RID: 479 RVA: 0x00013DEC File Offset: 0x00011FEC
		public static string BytesAsString(byte[] bytes)
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (byte b in bytes)
			{
				stringBuilder.Append(string.Format("{0:D3} ", b));
			}
			return stringBuilder.ToString();
		}

		// Token: 0x060001E0 RID: 480 RVA: 0x00013E30 File Offset: 0x00012030
		public static string BytesAsHexString(byte[] bytes)
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (byte b in bytes)
			{
				stringBuilder.Append(string.Format("{0:X2} ", b));
			}
			return stringBuilder.ToString();
		}

		// Token: 0x060001E1 RID: 481 RVA: 0x00013E74 File Offset: 0x00012074
		public static byte[] SwapBytes(byte[] v)
		{
			byte[] array = new byte[v.Length];
			int num = v.Length - 1;
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = v[num];
				num--;
			}
			return array;
		}

		// Token: 0x060001E2 RID: 482 RVA: 0x00002E7F File Offset: 0x0000107F
		public static byte[] SwapInt64(long v)
		{
			return BytesTools.SwapBytes(BitConverter.GetBytes(v));
		}

		// Token: 0x060001E3 RID: 483 RVA: 0x00002E8C File Offset: 0x0000108C
		public static byte[] SwapInt32(int v)
		{
			byte[] array = new byte[]
			{
				0,
				0,
				0,
				(byte)v
			};
			array[2] = (byte)(v >> 8);
			array[1] = (byte)(v >> 16);
			array[0] = (byte)(v >> 24);
			return array;
		}

		// Token: 0x060001E4 RID: 484 RVA: 0x00002EB0 File Offset: 0x000010B0
		public static byte[] SwapInt16(short v)
		{
			byte[] array = new byte[]
			{
				0,
				(byte)v
			};
			array[0] = (byte)(v >> 8);
			return array;
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x00002EC4 File Offset: 0x000010C4
		public static byte[] SwapDouble(double v)
		{
			return BytesTools.SwapBytes(BitConverter.GetBytes(v));
		}

		// Token: 0x0400015D RID: 349
		private static UTF8Encoding utf8Encode = new UTF8Encoding();
	}
}
