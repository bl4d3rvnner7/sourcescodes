﻿using System;
using System.Collections.Generic;

namespace Server.MessagePack
{
	// Token: 0x0200002D RID: 45
	public class MsgPackArray
	{
		// Token: 0x060001EC RID: 492 RVA: 0x00002F32 File Offset: 0x00001132
		public MsgPackArray(MsgPack msgpackObj, List<MsgPack> listObj)
		{
			this.owner = msgpackObj;
			this.children = listObj;
		}

		// Token: 0x060001ED RID: 493 RVA: 0x00002F48 File Offset: 0x00001148
		public MsgPack Add()
		{
			return this.owner.AddArrayChild();
		}

		// Token: 0x060001EE RID: 494 RVA: 0x00002F55 File Offset: 0x00001155
		public MsgPack Add(string value)
		{
			MsgPack msgPack = this.owner.AddArrayChild();
			msgPack.AsString = value;
			return msgPack;
		}

		// Token: 0x060001EF RID: 495 RVA: 0x00002F69 File Offset: 0x00001169
		public MsgPack Add(long value)
		{
			MsgPack msgPack = this.owner.AddArrayChild();
			msgPack.SetAsInteger(value);
			return msgPack;
		}

		// Token: 0x060001F0 RID: 496 RVA: 0x00002F7D File Offset: 0x0000117D
		public MsgPack Add(double value)
		{
			MsgPack msgPack = this.owner.AddArrayChild();
			msgPack.SetAsFloat(value);
			return msgPack;
		}

		// Token: 0x17000083 RID: 131
		public MsgPack this[int index]
		{
			get
			{
				return this.children[index];
			}
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x060001F2 RID: 498 RVA: 0x00002F9F File Offset: 0x0000119F
		public int Length
		{
			get
			{
				return this.children.Count;
			}
		}

		// Token: 0x04000160 RID: 352
		private List<MsgPack> children;

		// Token: 0x04000161 RID: 353
		private MsgPack owner;
	}
}
