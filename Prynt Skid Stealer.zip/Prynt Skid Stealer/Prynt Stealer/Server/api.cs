﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Threading;

namespace Server
{
	// Token: 0x02000018 RID: 24
	public class api
	{
		// Token: 0x060000D3 RID: 211 RVA: 0x00011620 File Offset: 0x0000F820
		public api(string name, string ownerid, string secret, string version)
		{
			if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(ownerid) || string.IsNullOrWhiteSpace(secret) || string.IsNullOrWhiteSpace(version))
			{
				api.error("Application not setup correctly. Please watch video link found in Program.cs");
				Environment.Exit(0);
			}
			this.name = name;
			this.ownerid = ownerid;
			this.secret = secret;
			this.version = version;
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x00002365 File Offset: 0x00000565
		public void init()
		{
			Program.form1 = new Form1();
			Program.form1.Show();
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x00002239 File Offset: 0x00000439
		public void register(string username, string pass, string key)
		{
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x00002365 File Offset: 0x00000565
		public void login(string username, string pass)
		{
			Program.form1 = new Form1();
			Program.form1.Show();
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x00002239 File Offset: 0x00000439
		public void web_login()
		{
		}

		// Token: 0x060000D8 RID: 216 RVA: 0x00002239 File Offset: 0x00000439
		public void button(string button)
		{
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x00002239 File Offset: 0x00000439
		public void upgrade(string username, string key)
		{
		}

		// Token: 0x060000DA RID: 218 RVA: 0x000116B4 File Offset: 0x0000F8B4
		public void license(string key)
		{
			if (!this.initzalized)
			{
				api.error("Please initzalize first");
				Environment.Exit(0);
			}
			string value = WindowsIdentity.GetCurrent().User.Value;
			string text = encryption.sha256(encryption.iv_key());
			NameValueCollection nameValueCollection = new NameValueCollection();
			nameValueCollection["type"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes("license"));
			nameValueCollection["key"] = encryption.encrypt(key, this.enckey, text);
			nameValueCollection["hwid"] = encryption.encrypt(value, this.enckey, text);
			nameValueCollection["sessionid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.sessionid));
			nameValueCollection["name"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.name));
			nameValueCollection["ownerid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.ownerid));
			nameValueCollection["init_iv"] = text;
			string text2 = api.req(nameValueCollection);
			text2 = encryption.decrypt(text2, this.enckey, text);
			api.response_structure response_structure = this.response_decoder.string_to_generic<api.response_structure>(text2);
			this.load_response_struct(response_structure);
			if (response_structure.success)
			{
				this.load_user_data(response_structure.info);
			}
		}

		// Token: 0x060000DB RID: 219 RVA: 0x00002239 File Offset: 0x00000439
		public void check()
		{
		}

		// Token: 0x060000DC RID: 220 RVA: 0x000117F0 File Offset: 0x0000F9F0
		public void setvar(string var, string data)
		{
			if (!this.initzalized)
			{
				api.error("Please initzalize first");
				Environment.Exit(0);
			}
			string text = encryption.sha256(encryption.iv_key());
			NameValueCollection nameValueCollection = new NameValueCollection();
			nameValueCollection["type"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes("setvar"));
			nameValueCollection["var"] = encryption.encrypt(var, this.enckey, text);
			nameValueCollection["data"] = encryption.encrypt(data, this.enckey, text);
			nameValueCollection["sessionid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.sessionid));
			nameValueCollection["name"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.name));
			nameValueCollection["ownerid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.ownerid));
			nameValueCollection["init_iv"] = text;
			string text2 = api.req(nameValueCollection);
			text2 = encryption.decrypt(text2, this.enckey, text);
			api.response_structure data2 = this.response_decoder.string_to_generic<api.response_structure>(text2);
			this.load_response_struct(data2);
		}

		// Token: 0x060000DD RID: 221 RVA: 0x00011908 File Offset: 0x0000FB08
		public string getvar(string var)
		{
			if (!this.initzalized)
			{
				api.error("Please initzalize first");
				Environment.Exit(0);
			}
			string text = encryption.sha256(encryption.iv_key());
			NameValueCollection nameValueCollection = new NameValueCollection();
			nameValueCollection["type"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes("getvar"));
			nameValueCollection["var"] = encryption.encrypt(var, this.enckey, text);
			nameValueCollection["sessionid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.sessionid));
			nameValueCollection["name"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.name));
			nameValueCollection["ownerid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.ownerid));
			nameValueCollection["init_iv"] = text;
			string text2 = api.req(nameValueCollection);
			text2 = encryption.decrypt(text2, this.enckey, text);
			api.response_structure response_structure = this.response_decoder.string_to_generic<api.response_structure>(text2);
			this.load_response_struct(response_structure);
			if (response_structure.success)
			{
				return response_structure.response;
			}
			return null;
		}

		// Token: 0x060000DE RID: 222 RVA: 0x00011A18 File Offset: 0x0000FC18
		public void ban()
		{
			if (!this.initzalized)
			{
				api.error("Please initzalize first");
				Environment.Exit(0);
			}
			string text = encryption.sha256(encryption.iv_key());
			NameValueCollection nameValueCollection = new NameValueCollection();
			nameValueCollection["type"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes("ban"));
			nameValueCollection["sessionid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.sessionid));
			nameValueCollection["name"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.name));
			nameValueCollection["ownerid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.ownerid));
			nameValueCollection["init_iv"] = text;
			string text2 = api.req(nameValueCollection);
			text2 = encryption.decrypt(text2, this.enckey, text);
			api.response_structure data = this.response_decoder.string_to_generic<api.response_structure>(text2);
			this.load_response_struct(data);
		}

		// Token: 0x060000DF RID: 223 RVA: 0x00011B00 File Offset: 0x0000FD00
		public string var(string varid)
		{
			if (!this.initzalized)
			{
				api.error("Please initzalize first");
				Environment.Exit(0);
			}
			string value = WindowsIdentity.GetCurrent().User.Value;
			string text = encryption.sha256(encryption.iv_key());
			NameValueCollection nameValueCollection = new NameValueCollection();
			nameValueCollection["type"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes("var"));
			nameValueCollection["varid"] = encryption.encrypt(varid, this.enckey, text);
			nameValueCollection["sessionid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.sessionid));
			nameValueCollection["name"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.name));
			nameValueCollection["ownerid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.ownerid));
			nameValueCollection["init_iv"] = text;
			string text2 = api.req(nameValueCollection);
			text2 = encryption.decrypt(text2, this.enckey, text);
			api.response_structure response_structure = this.response_decoder.string_to_generic<api.response_structure>(text2);
			this.load_response_struct(response_structure);
			if (response_structure.success)
			{
				return response_structure.message;
			}
			return null;
		}

		// Token: 0x060000E0 RID: 224 RVA: 0x00011C20 File Offset: 0x0000FE20
		public List<api.users> fetchOnline()
		{
			if (!this.initzalized)
			{
				api.error("Please initzalize first");
				Environment.Exit(0);
			}
			string text = encryption.sha256(encryption.iv_key());
			NameValueCollection nameValueCollection = new NameValueCollection();
			nameValueCollection["type"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes("fetchOnline"));
			nameValueCollection["sessionid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.sessionid));
			nameValueCollection["name"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.name));
			nameValueCollection["ownerid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.ownerid));
			nameValueCollection["init_iv"] = text;
			string text2 = api.req(nameValueCollection);
			text2 = encryption.decrypt(text2, this.enckey, text);
			api.response_structure response_structure = this.response_decoder.string_to_generic<api.response_structure>(text2);
			this.load_response_struct(response_structure);
			if (response_structure.success)
			{
				return response_structure.users;
			}
			return null;
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x00011D18 File Offset: 0x0000FF18
		public List<api.msg> chatget(string channelname)
		{
			if (!this.initzalized)
			{
				api.error("Please initzalize first");
				Environment.Exit(0);
			}
			string text = encryption.sha256(encryption.iv_key());
			NameValueCollection nameValueCollection = new NameValueCollection();
			nameValueCollection["type"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes("chatget"));
			nameValueCollection["channel"] = encryption.encrypt(channelname, this.enckey, text);
			nameValueCollection["sessionid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.sessionid));
			nameValueCollection["name"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.name));
			nameValueCollection["ownerid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.ownerid));
			nameValueCollection["init_iv"] = text;
			string text2 = api.req(nameValueCollection);
			text2 = encryption.decrypt(text2, this.enckey, text);
			api.response_structure response_structure = this.response_decoder.string_to_generic<api.response_structure>(text2);
			this.load_response_struct(response_structure);
			if (!response_structure.success)
			{
				return null;
			}
			if (response_structure.messages[0].message == "not_found")
			{
				return null;
			}
			return response_structure.messages;
		}

		// Token: 0x060000E2 RID: 226 RVA: 0x00011E48 File Offset: 0x00010048
		public bool chatsend(string msg, string channelname)
		{
			if (!this.initzalized)
			{
				api.error("Please initzalize first");
				Environment.Exit(0);
			}
			string text = encryption.sha256(encryption.iv_key());
			NameValueCollection nameValueCollection = new NameValueCollection();
			nameValueCollection["type"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes("chatsend"));
			nameValueCollection["message"] = encryption.encrypt(msg, this.enckey, text);
			nameValueCollection["channel"] = encryption.encrypt(channelname, this.enckey, text);
			nameValueCollection["sessionid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.sessionid));
			nameValueCollection["name"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.name));
			nameValueCollection["ownerid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.ownerid));
			nameValueCollection["init_iv"] = text;
			string text2 = api.req(nameValueCollection);
			text2 = encryption.decrypt(text2, this.enckey, text);
			api.response_structure response_structure = this.response_decoder.string_to_generic<api.response_structure>(text2);
			this.load_response_struct(response_structure);
			return response_structure.success;
		}

		// Token: 0x060000E3 RID: 227 RVA: 0x00011F68 File Offset: 0x00010168
		public bool checkblack()
		{
			if (!this.initzalized)
			{
				api.error("Please initzalize first");
				Environment.Exit(0);
			}
			string value = WindowsIdentity.GetCurrent().User.Value;
			string text = encryption.sha256(encryption.iv_key());
			NameValueCollection nameValueCollection = new NameValueCollection();
			nameValueCollection["type"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes("checkblacklist"));
			nameValueCollection["hwid"] = encryption.encrypt(value, this.enckey, text);
			nameValueCollection["sessionid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.sessionid));
			nameValueCollection["name"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.name));
			nameValueCollection["ownerid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.ownerid));
			nameValueCollection["init_iv"] = text;
			string text2 = api.req(nameValueCollection);
			text2 = encryption.decrypt(text2, this.enckey, text);
			api.response_structure response_structure = this.response_decoder.string_to_generic<api.response_structure>(text2);
			this.load_response_struct(response_structure);
			return response_structure.success;
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x00012080 File Offset: 0x00010280
		public string webhook(string webid, string param, string body = "", string conttype = "")
		{
			if (!this.initzalized)
			{
				api.error("Please initzalize first");
				Environment.Exit(0);
				return null;
			}
			string text = encryption.sha256(encryption.iv_key());
			NameValueCollection nameValueCollection = new NameValueCollection();
			nameValueCollection["type"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes("webhook"));
			nameValueCollection["webid"] = encryption.encrypt(webid, this.enckey, text);
			nameValueCollection["params"] = encryption.encrypt(param, this.enckey, text);
			nameValueCollection["body"] = encryption.encrypt(body, this.enckey, text);
			nameValueCollection["conttype"] = encryption.encrypt(conttype, this.enckey, text);
			nameValueCollection["sessionid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.sessionid));
			nameValueCollection["name"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.name));
			nameValueCollection["ownerid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.ownerid));
			nameValueCollection["init_iv"] = text;
			string text2 = api.req(nameValueCollection);
			text2 = encryption.decrypt(text2, this.enckey, text);
			api.response_structure response_structure = this.response_decoder.string_to_generic<api.response_structure>(text2);
			this.load_response_struct(response_structure);
			if (response_structure.success)
			{
				return response_structure.response;
			}
			return null;
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x000121DC File Offset: 0x000103DC
		public byte[] download(string fileid)
		{
			if (!this.initzalized)
			{
				api.error("Please initzalize first. File is empty since no request could be made.");
				Environment.Exit(0);
			}
			string text = encryption.sha256(encryption.iv_key());
			NameValueCollection nameValueCollection = new NameValueCollection();
			nameValueCollection["type"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes("file"));
			nameValueCollection["fileid"] = encryption.encrypt(fileid, this.enckey, text);
			nameValueCollection["sessionid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.sessionid));
			nameValueCollection["name"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.name));
			nameValueCollection["ownerid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.ownerid));
			nameValueCollection["init_iv"] = text;
			string text2 = api.req(nameValueCollection);
			text2 = encryption.decrypt(text2, this.enckey, text);
			api.response_structure response_structure = this.response_decoder.string_to_generic<api.response_structure>(text2);
			this.load_response_struct(response_structure);
			if (response_structure.success)
			{
				return encryption.str_to_byte_arr(response_structure.contents);
			}
			return null;
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x000122F4 File Offset: 0x000104F4
		public void log(string message)
		{
			if (!this.initzalized)
			{
				api.error("Please initzalize first");
				Environment.Exit(0);
			}
			string text = encryption.sha256(encryption.iv_key());
			NameValueCollection nameValueCollection = new NameValueCollection();
			nameValueCollection["type"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes("log"));
			nameValueCollection["pcuser"] = encryption.encrypt(Environment.UserName, this.enckey, text);
			nameValueCollection["message"] = encryption.encrypt(message, this.enckey, text);
			nameValueCollection["sessionid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.sessionid));
			nameValueCollection["name"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.name));
			nameValueCollection["ownerid"] = encryption.byte_arr_to_str(Encoding.Default.GetBytes(this.ownerid));
			nameValueCollection["init_iv"] = text;
			api.req(nameValueCollection);
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x000123F0 File Offset: 0x000105F0
		public static string checksum(string filename)
		{
			string result;
			using (MD5 md = MD5.Create())
			{
				using (FileStream fileStream = File.OpenRead(filename))
				{
					result = BitConverter.ToString(md.ComputeHash(fileStream)).Replace("-", "").ToLowerInvariant();
				}
			}
			return result;
		}

		// Token: 0x060000E8 RID: 232 RVA: 0x00012460 File Offset: 0x00010660
		public static void error(string message)
		{
			Process.Start(new ProcessStartInfo("cmd.exe", "/c start cmd /C \"color b && title Error && echo " + message + " && timeout /t 5\"")
			{
				CreateNoWindow = true,
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				UseShellExecute = false
			});
			Environment.Exit(0);
		}

		// Token: 0x060000E9 RID: 233 RVA: 0x000124B0 File Offset: 0x000106B0
		private static string req(NameValueCollection post_data)
		{
			string result;
			try
			{
				using (WebClient webClient = new WebClient())
				{
					byte[] bytes = webClient.UploadValues("https://keyauth.win/api/1.0/", post_data);
					result = Encoding.Default.GetString(bytes);
				}
			}
			catch (WebException ex)
			{
				if (((HttpWebResponse)ex.Response).StatusCode == (HttpStatusCode)429)
				{
					api.error("You're connecting too fast to loader, slow down.");
					Environment.Exit(0);
					result = "";
				}
				else
				{
					api.error("Connection failure. Please try again, or contact us for help.");
					Environment.Exit(0);
					result = "";
				}
			}
			return result;
		}

		// Token: 0x060000EA RID: 234 RVA: 0x00012550 File Offset: 0x00010750
		private static string req_unenc(NameValueCollection post_data)
		{
			string result;
			try
			{
				using (WebClient webClient = new WebClient())
				{
					byte[] bytes = webClient.UploadValues("https://keyauth.win/api/1.1/", post_data);
					result = Encoding.Default.GetString(bytes);
				}
			}
			catch (WebException ex)
			{
				if (((HttpWebResponse)ex.Response).StatusCode == (HttpStatusCode)429)
				{
					Thread.Sleep(1000);
					result = api.req(post_data);
				}
				else
				{
					api.error("Connection failure. Please try again, or contact us for help.");
					Environment.Exit(0);
					result = "";
				}
			}
			return result;
		}

		// Token: 0x060000EB RID: 235 RVA: 0x000125E8 File Offset: 0x000107E8
		private void load_app_data(api.app_data_structure data)
		{
			this.app_data.numUsers = data.numUsers;
			this.app_data.numOnlineUsers = data.numOnlineUsers;
			this.app_data.numKeys = data.numKeys;
			this.app_data.version = data.version;
			this.app_data.customerPanelLink = data.customerPanelLink;
		}

		// Token: 0x060000EC RID: 236 RVA: 0x0001264C File Offset: 0x0001084C
		private void load_user_data(api.user_data_structure data)
		{
			this.user_data.username = data.username;
			this.user_data.ip = data.ip;
			this.user_data.hwid = data.hwid;
			this.user_data.createdate = data.createdate;
			this.user_data.lastlogin = data.lastlogin;
			this.user_data.subscriptions = data.subscriptions;
		}

		// Token: 0x060000ED RID: 237 RVA: 0x000126C0 File Offset: 0x000108C0
		public string expirydaysleft()
		{
			if (!this.initzalized)
			{
				api.error("Please initzalize first");
				Environment.Exit(0);
			}
			DateTime d = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Local);
			d = d.AddSeconds((double)long.Parse(this.user_data.subscriptions[0].expiry)).ToLocalTime();
			TimeSpan timeSpan = d - DateTime.Now;
			return Convert.ToString(timeSpan.Days.ToString() + " Days " + timeSpan.Hours.ToString() + " Hours Left");
		}

		// Token: 0x060000EE RID: 238 RVA: 0x0000237B File Offset: 0x0000057B
		private void load_response_struct(api.response_structure data)
		{
			this.response.success = data.success;
			this.response.message = data.message;
		}

		// Token: 0x040000F6 RID: 246
		public string name;

		// Token: 0x040000F7 RID: 247
		public string ownerid;

		// Token: 0x040000F8 RID: 248
		public string secret;

		// Token: 0x040000F9 RID: 249
		public string version;

		// Token: 0x040000FA RID: 250
		private string sessionid;

		// Token: 0x040000FB RID: 251
		private string enckey;

		// Token: 0x040000FC RID: 252
		private bool initzalized;

		// Token: 0x040000FD RID: 253
		public api.app_data_class app_data = new api.app_data_class();

		// Token: 0x040000FE RID: 254
		public api.user_data_class user_data = new api.user_data_class();

		// Token: 0x040000FF RID: 255
		public api.response_class response = new api.response_class();

		// Token: 0x04000100 RID: 256
		private json_wrapper response_decoder = new json_wrapper(new api.response_structure());

		// Token: 0x02000019 RID: 25
		[DataContract]
		private class response_structure
		{
			// Token: 0x17000011 RID: 17
			// (get) Token: 0x060000EF RID: 239 RVA: 0x0000239F File Offset: 0x0000059F
			// (set) Token: 0x060000F0 RID: 240 RVA: 0x000023A7 File Offset: 0x000005A7
			[DataMember]
			public bool success { get; set; }

			// Token: 0x17000012 RID: 18
			// (get) Token: 0x060000F1 RID: 241 RVA: 0x000023B0 File Offset: 0x000005B0
			// (set) Token: 0x060000F2 RID: 242 RVA: 0x000023B8 File Offset: 0x000005B8
			[DataMember]
			public string sessionid { get; set; }

			// Token: 0x17000013 RID: 19
			// (get) Token: 0x060000F3 RID: 243 RVA: 0x000023C1 File Offset: 0x000005C1
			// (set) Token: 0x060000F4 RID: 244 RVA: 0x000023C9 File Offset: 0x000005C9
			[DataMember]
			public string contents { get; set; }

			// Token: 0x17000014 RID: 20
			// (get) Token: 0x060000F5 RID: 245 RVA: 0x000023D2 File Offset: 0x000005D2
			// (set) Token: 0x060000F6 RID: 246 RVA: 0x000023DA File Offset: 0x000005DA
			[DataMember]
			public string response { get; set; }

			// Token: 0x17000015 RID: 21
			// (get) Token: 0x060000F7 RID: 247 RVA: 0x000023E3 File Offset: 0x000005E3
			// (set) Token: 0x060000F8 RID: 248 RVA: 0x000023EB File Offset: 0x000005EB
			[DataMember]
			public string message { get; set; }

			// Token: 0x17000016 RID: 22
			// (get) Token: 0x060000F9 RID: 249 RVA: 0x000023F4 File Offset: 0x000005F4
			// (set) Token: 0x060000FA RID: 250 RVA: 0x000023FC File Offset: 0x000005FC
			[DataMember]
			public string download { get; set; }

			// Token: 0x17000017 RID: 23
			// (get) Token: 0x060000FB RID: 251 RVA: 0x00002405 File Offset: 0x00000605
			// (set) Token: 0x060000FC RID: 252 RVA: 0x0000240D File Offset: 0x0000060D
			[DataMember(IsRequired = false, EmitDefaultValue = false)]
			public api.user_data_structure info { get; set; }

			// Token: 0x17000018 RID: 24
			// (get) Token: 0x060000FD RID: 253 RVA: 0x00002416 File Offset: 0x00000616
			// (set) Token: 0x060000FE RID: 254 RVA: 0x0000241E File Offset: 0x0000061E
			[DataMember(IsRequired = false, EmitDefaultValue = false)]
			public api.app_data_structure appinfo { get; set; }

			// Token: 0x17000019 RID: 25
			// (get) Token: 0x060000FF RID: 255 RVA: 0x00002427 File Offset: 0x00000627
			// (set) Token: 0x06000100 RID: 256 RVA: 0x0000242F File Offset: 0x0000062F
			[DataMember]
			public List<api.msg> messages { get; set; }

			// Token: 0x1700001A RID: 26
			// (get) Token: 0x06000101 RID: 257 RVA: 0x00002438 File Offset: 0x00000638
			// (set) Token: 0x06000102 RID: 258 RVA: 0x00002440 File Offset: 0x00000640
			[DataMember]
			public List<api.users> users { get; set; }
		}

		// Token: 0x0200001A RID: 26
		public class msg
		{
			// Token: 0x1700001B RID: 27
			// (get) Token: 0x06000104 RID: 260 RVA: 0x00002449 File Offset: 0x00000649
			// (set) Token: 0x06000105 RID: 261 RVA: 0x00002451 File Offset: 0x00000651
			public string message { get; set; }

			// Token: 0x1700001C RID: 28
			// (get) Token: 0x06000106 RID: 262 RVA: 0x0000245A File Offset: 0x0000065A
			// (set) Token: 0x06000107 RID: 263 RVA: 0x00002462 File Offset: 0x00000662
			public string author { get; set; }

			// Token: 0x1700001D RID: 29
			// (get) Token: 0x06000108 RID: 264 RVA: 0x0000246B File Offset: 0x0000066B
			// (set) Token: 0x06000109 RID: 265 RVA: 0x00002473 File Offset: 0x00000673
			public string timestamp { get; set; }
		}

		// Token: 0x0200001B RID: 27
		public class users
		{
			// Token: 0x1700001E RID: 30
			// (get) Token: 0x0600010B RID: 267 RVA: 0x0000247C File Offset: 0x0000067C
			// (set) Token: 0x0600010C RID: 268 RVA: 0x00002484 File Offset: 0x00000684
			public string credential { get; set; }
		}

		// Token: 0x0200001C RID: 28
		[DataContract]
		private class user_data_structure
		{
			// Token: 0x1700001F RID: 31
			// (get) Token: 0x0600010E RID: 270 RVA: 0x0000248D File Offset: 0x0000068D
			// (set) Token: 0x0600010F RID: 271 RVA: 0x00002495 File Offset: 0x00000695
			[DataMember]
			public string username { get; set; }

			// Token: 0x17000020 RID: 32
			// (get) Token: 0x06000110 RID: 272 RVA: 0x0000249E File Offset: 0x0000069E
			// (set) Token: 0x06000111 RID: 273 RVA: 0x000024A6 File Offset: 0x000006A6
			[DataMember]
			public string ip { get; set; }

			// Token: 0x17000021 RID: 33
			// (get) Token: 0x06000112 RID: 274 RVA: 0x000024AF File Offset: 0x000006AF
			// (set) Token: 0x06000113 RID: 275 RVA: 0x000024B7 File Offset: 0x000006B7
			[DataMember]
			public string hwid { get; set; }

			// Token: 0x17000022 RID: 34
			// (get) Token: 0x06000114 RID: 276 RVA: 0x000024C0 File Offset: 0x000006C0
			// (set) Token: 0x06000115 RID: 277 RVA: 0x000024C8 File Offset: 0x000006C8
			[DataMember]
			public string createdate { get; set; }

			// Token: 0x17000023 RID: 35
			// (get) Token: 0x06000116 RID: 278 RVA: 0x000024D1 File Offset: 0x000006D1
			// (set) Token: 0x06000117 RID: 279 RVA: 0x000024D9 File Offset: 0x000006D9
			[DataMember]
			public string lastlogin { get; set; }

			// Token: 0x17000024 RID: 36
			// (get) Token: 0x06000118 RID: 280 RVA: 0x000024E2 File Offset: 0x000006E2
			// (set) Token: 0x06000119 RID: 281 RVA: 0x000024EA File Offset: 0x000006EA
			[DataMember]
			public List<api.Data> subscriptions { get; set; }
		}

		// Token: 0x0200001D RID: 29
		[DataContract]
		private class app_data_structure
		{
			// Token: 0x17000025 RID: 37
			// (get) Token: 0x0600011B RID: 283 RVA: 0x000024F3 File Offset: 0x000006F3
			// (set) Token: 0x0600011C RID: 284 RVA: 0x000024FB File Offset: 0x000006FB
			[DataMember]
			public string numUsers { get; set; }

			// Token: 0x17000026 RID: 38
			// (get) Token: 0x0600011D RID: 285 RVA: 0x00002504 File Offset: 0x00000704
			// (set) Token: 0x0600011E RID: 286 RVA: 0x0000250C File Offset: 0x0000070C
			[DataMember]
			public string numOnlineUsers { get; set; }

			// Token: 0x17000027 RID: 39
			// (get) Token: 0x0600011F RID: 287 RVA: 0x00002515 File Offset: 0x00000715
			// (set) Token: 0x06000120 RID: 288 RVA: 0x0000251D File Offset: 0x0000071D
			[DataMember]
			public string numKeys { get; set; }

			// Token: 0x17000028 RID: 40
			// (get) Token: 0x06000121 RID: 289 RVA: 0x00002526 File Offset: 0x00000726
			// (set) Token: 0x06000122 RID: 290 RVA: 0x0000252E File Offset: 0x0000072E
			[DataMember]
			public string version { get; set; }

			// Token: 0x17000029 RID: 41
			// (get) Token: 0x06000123 RID: 291 RVA: 0x00002537 File Offset: 0x00000737
			// (set) Token: 0x06000124 RID: 292 RVA: 0x0000253F File Offset: 0x0000073F
			[DataMember]
			public string customerPanelLink { get; set; }

			// Token: 0x1700002A RID: 42
			// (get) Token: 0x06000125 RID: 293 RVA: 0x00002548 File Offset: 0x00000748
			// (set) Token: 0x06000126 RID: 294 RVA: 0x00002550 File Offset: 0x00000750
			[DataMember]
			public string downloadLink { get; set; }
		}

		// Token: 0x0200001E RID: 30
		public class app_data_class
		{
			// Token: 0x1700002B RID: 43
			// (get) Token: 0x06000128 RID: 296 RVA: 0x00002559 File Offset: 0x00000759
			// (set) Token: 0x06000129 RID: 297 RVA: 0x00002561 File Offset: 0x00000761
			public string numUsers { get; set; }

			// Token: 0x1700002C RID: 44
			// (get) Token: 0x0600012A RID: 298 RVA: 0x0000256A File Offset: 0x0000076A
			// (set) Token: 0x0600012B RID: 299 RVA: 0x00002572 File Offset: 0x00000772
			public string numOnlineUsers { get; set; }

			// Token: 0x1700002D RID: 45
			// (get) Token: 0x0600012C RID: 300 RVA: 0x0000257B File Offset: 0x0000077B
			// (set) Token: 0x0600012D RID: 301 RVA: 0x00002583 File Offset: 0x00000783
			public string numKeys { get; set; }

			// Token: 0x1700002E RID: 46
			// (get) Token: 0x0600012E RID: 302 RVA: 0x0000258C File Offset: 0x0000078C
			// (set) Token: 0x0600012F RID: 303 RVA: 0x00002594 File Offset: 0x00000794
			public string version { get; set; }

			// Token: 0x1700002F RID: 47
			// (get) Token: 0x06000130 RID: 304 RVA: 0x0000259D File Offset: 0x0000079D
			// (set) Token: 0x06000131 RID: 305 RVA: 0x000025A5 File Offset: 0x000007A5
			public string customerPanelLink { get; set; }

			// Token: 0x17000030 RID: 48
			// (get) Token: 0x06000132 RID: 306 RVA: 0x000025AE File Offset: 0x000007AE
			// (set) Token: 0x06000133 RID: 307 RVA: 0x000025B6 File Offset: 0x000007B6
			public string downloadLink { get; set; }
		}

		// Token: 0x0200001F RID: 31
		public class user_data_class
		{
			// Token: 0x17000031 RID: 49
			// (get) Token: 0x06000135 RID: 309 RVA: 0x000025BF File Offset: 0x000007BF
			// (set) Token: 0x06000136 RID: 310 RVA: 0x000025C7 File Offset: 0x000007C7
			public string username { get; set; }

			// Token: 0x17000032 RID: 50
			// (get) Token: 0x06000137 RID: 311 RVA: 0x000025D0 File Offset: 0x000007D0
			// (set) Token: 0x06000138 RID: 312 RVA: 0x000025D8 File Offset: 0x000007D8
			public string ip { get; set; }

			// Token: 0x17000033 RID: 51
			// (get) Token: 0x06000139 RID: 313 RVA: 0x000025E1 File Offset: 0x000007E1
			// (set) Token: 0x0600013A RID: 314 RVA: 0x000025E9 File Offset: 0x000007E9
			public string hwid { get; set; }

			// Token: 0x17000034 RID: 52
			// (get) Token: 0x0600013B RID: 315 RVA: 0x000025F2 File Offset: 0x000007F2
			// (set) Token: 0x0600013C RID: 316 RVA: 0x000025FA File Offset: 0x000007FA
			public string createdate { get; set; }

			// Token: 0x17000035 RID: 53
			// (get) Token: 0x0600013D RID: 317 RVA: 0x00002603 File Offset: 0x00000803
			// (set) Token: 0x0600013E RID: 318 RVA: 0x0000260B File Offset: 0x0000080B
			public string lastlogin { get; set; }

			// Token: 0x17000036 RID: 54
			// (get) Token: 0x0600013F RID: 319 RVA: 0x00002614 File Offset: 0x00000814
			// (set) Token: 0x06000140 RID: 320 RVA: 0x0000261C File Offset: 0x0000081C
			public List<api.Data> subscriptions { get; set; }
		}

		// Token: 0x02000020 RID: 32
		public class Data
		{
			// Token: 0x17000037 RID: 55
			// (get) Token: 0x06000142 RID: 322 RVA: 0x00002625 File Offset: 0x00000825
			// (set) Token: 0x06000143 RID: 323 RVA: 0x0000262D File Offset: 0x0000082D
			public string subscription { get; set; }

			// Token: 0x17000038 RID: 56
			// (get) Token: 0x06000144 RID: 324 RVA: 0x00002636 File Offset: 0x00000836
			// (set) Token: 0x06000145 RID: 325 RVA: 0x0000263E File Offset: 0x0000083E
			public string expiry { get; set; }

			// Token: 0x17000039 RID: 57
			// (get) Token: 0x06000146 RID: 326 RVA: 0x00002647 File Offset: 0x00000847
			// (set) Token: 0x06000147 RID: 327 RVA: 0x0000264F File Offset: 0x0000084F
			public string timeleft { get; set; }
		}

		// Token: 0x02000021 RID: 33
		public class response_class
		{
			// Token: 0x1700003A RID: 58
			// (get) Token: 0x06000149 RID: 329 RVA: 0x00002658 File Offset: 0x00000858
			// (set) Token: 0x0600014A RID: 330 RVA: 0x00002660 File Offset: 0x00000860
			public bool success { get; set; }

			// Token: 0x1700003B RID: 59
			// (get) Token: 0x0600014B RID: 331 RVA: 0x00002669 File Offset: 0x00000869
			// (set) Token: 0x0600014C RID: 332 RVA: 0x00002671 File Offset: 0x00000871
			public string message { get; set; }
		}
	}
}
