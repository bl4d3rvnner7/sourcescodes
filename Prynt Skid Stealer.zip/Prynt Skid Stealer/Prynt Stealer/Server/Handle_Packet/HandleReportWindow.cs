﻿using System;
using System.Drawing;
using Server.Connection;
using Server.Properties;

namespace Server.Handle_Packet
{
	// Token: 0x02000078 RID: 120
	public class HandleReportWindow
	{
		// Token: 0x060003B4 RID: 948 RVA: 0x0001CDB0 File Offset: 0x0001AFB0
		public HandleReportWindow(Clients client, string title)
		{
			new HandleLogs().Addmsg(string.Concat(new string[]
			{
				"Client ",
				client.Ip,
				" opened [",
				title,
				"]"
			}), Color.Blue);
			if (Settings.Default.Notification)
			{
				Program.form1.notifyIcon1.BalloonTipText = string.Concat(new string[]
				{
					"Client ",
					client.Ip,
					" opened [",
					title,
					"]"
				});
				Program.form1.notifyIcon1.ShowBalloonTip(100);
			}
		}
	}
}
