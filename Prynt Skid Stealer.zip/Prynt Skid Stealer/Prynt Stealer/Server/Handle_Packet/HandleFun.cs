﻿using System;
using System.Windows.Forms;
using Server.Connection;
using Server.Forms;
using Server.MessagePack;

namespace Server.Handle_Packet
{
	// Token: 0x0200005E RID: 94
	public class HandleFun
	{
		// Token: 0x06000378 RID: 888 RVA: 0x00019DB4 File Offset: 0x00017FB4
		public void Fun(Clients client, MsgPack unpack_msgpack)
		{
			try
			{
				FormFun formFun = (FormFun)Application.OpenForms["fun:" + unpack_msgpack.ForcePathObject("Hwid").AsString];
				if (formFun != null && formFun.Client == null)
				{
					formFun.Client = client;
					formFun.timer1.Enabled = true;
				}
			}
			catch
			{
			}
		}
	}
}
