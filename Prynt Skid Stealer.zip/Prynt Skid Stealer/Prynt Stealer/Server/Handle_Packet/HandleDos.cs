﻿using System;
using System.Windows.Forms;
using Server.Connection;
using Server.Forms;
using Server.MessagePack;

namespace Server.Handle_Packet
{
	// Token: 0x02000068 RID: 104
	internal class HandleDos
	{
		// Token: 0x0600038F RID: 911 RVA: 0x0001ADCC File Offset: 0x00018FCC
		public void Add(Clients client, MsgPack unpack_msgpack)
		{
			try
			{
				FormDOS formDOS = (FormDOS)Application.OpenForms["DOS"];
				if (formDOS != null)
				{
					object sync = formDOS.sync;
					lock (sync)
					{
						formDOS.PlguinClients.Add(client);
					}
				}
			}
			catch
			{
			}
		}
	}
}
