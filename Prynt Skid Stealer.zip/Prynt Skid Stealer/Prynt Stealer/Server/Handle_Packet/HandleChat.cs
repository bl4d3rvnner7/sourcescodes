﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Server.Connection;
using Server.Forms;
using Server.MessagePack;

namespace Server.Handle_Packet
{
	// Token: 0x02000067 RID: 103
	public class HandleChat
	{
		// Token: 0x0600038C RID: 908 RVA: 0x0001AC60 File Offset: 0x00018E60
		public void Read(MsgPack unpack_msgpack, Clients client)
		{
			try
			{
				FormChat formChat = (FormChat)Application.OpenForms["chat:" + unpack_msgpack.ForcePathObject("Hwid").AsString];
				if (formChat != null)
				{
					Console.Beep();
					formChat.richTextBox1.SelectionColor = Color.Blue;
					formChat.richTextBox1.AppendText(unpack_msgpack.ForcePathObject("WriteInput").AsString);
					formChat.richTextBox1.SelectionColor = Color.Black;
					formChat.richTextBox1.AppendText(unpack_msgpack.ForcePathObject("WriteInput2").AsString);
					formChat.richTextBox1.SelectionStart = formChat.richTextBox1.TextLength;
					formChat.richTextBox1.ScrollToCaret();
				}
				else
				{
					MsgPack msgPack = new MsgPack();
					msgPack.ForcePathObject("Pac_ket").AsString = "chatExit";
					ThreadPool.QueueUserWorkItem(new WaitCallback(client.Send), msgPack.Encode2Bytes());
					client.Disconnected();
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600038D RID: 909 RVA: 0x0001AD68 File Offset: 0x00018F68
		public void GetClient(MsgPack unpack_msgpack, Clients client)
		{
			FormChat formChat = (FormChat)Application.OpenForms["chat:" + unpack_msgpack.ForcePathObject("Hwid").AsString];
			if (formChat != null && formChat.Client == null)
			{
				formChat.Client = client;
				formChat.textBox1.Enabled = true;
				formChat.timer1.Enabled = true;
			}
		}
	}
}
