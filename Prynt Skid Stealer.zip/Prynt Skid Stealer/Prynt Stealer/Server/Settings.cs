﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms;
using Server.Connection;

namespace Server
{
	// Token: 0x02000026 RID: 38
	public static class Settings
	{
		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000163 RID: 355 RVA: 0x00002748 File Offset: 0x00000948
		// (set) Token: 0x06000164 RID: 356 RVA: 0x0000274F File Offset: 0x0000094F
		public static long SentValue { get; set; }

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000165 RID: 357 RVA: 0x00002757 File Offset: 0x00000957
		// (set) Token: 0x06000166 RID: 358 RVA: 0x0000275E File Offset: 0x0000095E
		public static long ReceivedValue { get; set; }

		// Token: 0x0400013D RID: 317
		public static List<string> Blocked = new List<string>();

		// Token: 0x0400013E RID: 318
		public static object LockBlocked = new object();

		// Token: 0x04000141 RID: 321
		public static object LockReceivedSendValue = new object();

		// Token: 0x04000142 RID: 322
		public static string CertificatePath = Application.StartupPath + "\\ServerCertificate.p12";

		// Token: 0x04000143 RID: 323
		public static X509Certificate2 ServerCertificate;

		// Token: 0x04000144 RID: 324
		public static readonly string Version = "Prynt Stealer 7.2";

		// Token: 0x04000145 RID: 325
		public static object LockListviewClients = new object();

		// Token: 0x04000146 RID: 326
		public static object LockListviewLogs = new object();

		// Token: 0x04000147 RID: 327
		public static object LockListviewThumb = new object();

		// Token: 0x04000148 RID: 328
		public static bool ReportWindow = false;

		// Token: 0x04000149 RID: 329
		public static List<Clients> ReportWindowClients = new List<Clients>();

		// Token: 0x0400014A RID: 330
		public static object LockReportWindowClients = new object();
	}
}
