﻿using System;
using System.Windows.Forms;

namespace Server
{
	// Token: 0x02000024 RID: 36
	internal static class Program
	{
		// Token: 0x0600015A RID: 346 RVA: 0x000026C1 File Offset: 0x000008C1
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Program.login_form = new Login();
			Application.Run(Program.login_form);
		}

		// Token: 0x0400012E RID: 302
		public static Form1 form1;

		// Token: 0x0400012F RID: 303
		public static Login login_form;
	}
}
