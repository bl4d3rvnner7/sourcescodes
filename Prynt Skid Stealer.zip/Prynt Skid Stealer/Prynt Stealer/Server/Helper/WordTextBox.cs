﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Windows.Forms;

namespace Server.Helper
{
	// Token: 0x0200004B RID: 75
	public class WordTextBox : TextBox
	{
		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06000284 RID: 644 RVA: 0x00003434 File Offset: 0x00001634
		// (set) Token: 0x06000285 RID: 645 RVA: 0x00002239 File Offset: 0x00000439
		public override int MaxLength
		{
			get
			{
				return base.MaxLength;
			}
			set
			{
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x06000286 RID: 646 RVA: 0x0000343C File Offset: 0x0000163C
		// (set) Token: 0x06000287 RID: 647 RVA: 0x000161C8 File Offset: 0x000143C8
		public bool IsHexNumber
		{
			get
			{
				return this.isHexNumber;
			}
			set
			{
				if (this.isHexNumber == value)
				{
					return;
				}
				if (value)
				{
					if (this.Type == WordTextBox.WordType.DWORD)
					{
						this.Text = this.UIntValue.ToString("x");
					}
					else
					{
						this.Text = this.ULongValue.ToString("x");
					}
				}
				else if (this.Type == WordTextBox.WordType.DWORD)
				{
					this.Text = this.UIntValue.ToString();
				}
				else
				{
					this.Text = this.ULongValue.ToString();
				}
				this.isHexNumber = value;
				this.UpdateMaxLength();
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x06000288 RID: 648 RVA: 0x00003444 File Offset: 0x00001644
		// (set) Token: 0x06000289 RID: 649 RVA: 0x0000344C File Offset: 0x0000164C
		public WordTextBox.WordType Type
		{
			get
			{
				return this.type;
			}
			set
			{
				if (this.type == value)
				{
					return;
				}
				this.type = value;
				this.UpdateMaxLength();
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x0600028A RID: 650 RVA: 0x00016260 File Offset: 0x00014460
		public uint UIntValue
		{
			get
			{
				uint result;
				try
				{
					if (string.IsNullOrEmpty(this.Text))
					{
						result = 0U;
					}
					else if (this.IsHexNumber)
					{
						result = uint.Parse(this.Text, NumberStyles.HexNumber);
					}
					else
					{
						result = uint.Parse(this.Text);
					}
				}
				catch (Exception)
				{
					result = uint.MaxValue;
				}
				return result;
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x0600028B RID: 651 RVA: 0x000162C0 File Offset: 0x000144C0
		public ulong ULongValue
		{
			get
			{
				ulong result;
				try
				{
					if (string.IsNullOrEmpty(this.Text))
					{
						result = 0UL;
					}
					else if (this.IsHexNumber)
					{
						result = ulong.Parse(this.Text, NumberStyles.HexNumber);
					}
					else
					{
						result = ulong.Parse(this.Text);
					}
				}
				catch (Exception)
				{
					result = ulong.MaxValue;
				}
				return result;
			}
		}

		// Token: 0x0600028C RID: 652 RVA: 0x00003465 File Offset: 0x00001665
		public bool IsConversionValid()
		{
			return string.IsNullOrEmpty(this.Text) || this.IsHexNumber || this.ConvertToHex();
		}

		// Token: 0x0600028D RID: 653 RVA: 0x00003486 File Offset: 0x00001686
		public WordTextBox()
		{
			this.InitializeComponent();
			base.MaxLength = 8;
		}

		// Token: 0x0600028E RID: 654 RVA: 0x0000349B File Offset: 0x0000169B
		protected override void OnKeyPress(KeyPressEventArgs e)
		{
			base.OnKeyPress(e);
			e.Handled = !this.IsValidChar(e.KeyChar);
		}

		// Token: 0x0600028F RID: 655 RVA: 0x000034B9 File Offset: 0x000016B9
		private bool IsValidChar(char ch)
		{
			return char.IsControl(ch) || char.IsDigit(ch) || (this.IsHexNumber && char.IsLetter(ch) && char.ToLower(ch) <= 'f');
		}

		// Token: 0x06000290 RID: 656 RVA: 0x000034EC File Offset: 0x000016EC
		private void UpdateMaxLength()
		{
			if (this.Type == WordTextBox.WordType.DWORD)
			{
				if (this.IsHexNumber)
				{
					base.MaxLength = 8;
					return;
				}
				base.MaxLength = 10;
				return;
			}
			else
			{
				if (this.IsHexNumber)
				{
					base.MaxLength = 16;
					return;
				}
				base.MaxLength = 20;
				return;
			}
		}

		// Token: 0x06000291 RID: 657 RVA: 0x00016320 File Offset: 0x00014520
		private bool ConvertToHex()
		{
			bool result;
			try
			{
				if (this.Type == WordTextBox.WordType.DWORD)
				{
					uint.Parse(this.Text);
				}
				else
				{
					ulong.Parse(this.Text);
				}
				result = true;
			}
			catch (Exception)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000292 RID: 658 RVA: 0x00003528 File Offset: 0x00001728
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000293 RID: 659 RVA: 0x00003547 File Offset: 0x00001747
		private void InitializeComponent()
		{
			this.components = new Container();
		}

		// Token: 0x040001D1 RID: 465
		private bool isHexNumber;

		// Token: 0x040001D2 RID: 466
		private WordTextBox.WordType type;

		// Token: 0x040001D3 RID: 467
		private IContainer components;

		// Token: 0x0200004C RID: 76
		public enum WordType
		{
			// Token: 0x040001D5 RID: 469
			DWORD,
			// Token: 0x040001D6 RID: 470
			QWORD
		}
	}
}
