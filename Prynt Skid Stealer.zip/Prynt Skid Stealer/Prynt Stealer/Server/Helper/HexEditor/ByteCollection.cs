﻿using System;
using System.Collections.Generic;

namespace Server.Helper.HexEditor
{
	// Token: 0x02000053 RID: 83
	public class ByteCollection
	{
		// Token: 0x1700009F RID: 159
		// (get) Token: 0x060002BC RID: 700 RVA: 0x00003675 File Offset: 0x00001875
		public int Length
		{
			get
			{
				return this._bytes.Count;
			}
		}

		// Token: 0x060002BD RID: 701 RVA: 0x00003682 File Offset: 0x00001882
		public ByteCollection()
		{
			this._bytes = new List<byte>();
		}

		// Token: 0x060002BE RID: 702 RVA: 0x00003695 File Offset: 0x00001895
		public ByteCollection(byte[] bytes)
		{
			this._bytes = new List<byte>(bytes);
		}

		// Token: 0x060002BF RID: 703 RVA: 0x000036A9 File Offset: 0x000018A9
		public void Add(byte item)
		{
			this._bytes.Add(item);
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x000036B7 File Offset: 0x000018B7
		public void Insert(int index, byte item)
		{
			this._bytes.Insert(index, item);
		}

		// Token: 0x060002C1 RID: 705 RVA: 0x000036C6 File Offset: 0x000018C6
		public void Remove(byte item)
		{
			this._bytes.Remove(item);
		}

		// Token: 0x060002C2 RID: 706 RVA: 0x000036D5 File Offset: 0x000018D5
		public void RemoveAt(int index)
		{
			this._bytes.RemoveAt(index);
		}

		// Token: 0x060002C3 RID: 707 RVA: 0x000036E3 File Offset: 0x000018E3
		public void RemoveRange(int startIndex, int count)
		{
			this._bytes.RemoveRange(startIndex, count);
		}

		// Token: 0x060002C4 RID: 708 RVA: 0x000036F2 File Offset: 0x000018F2
		public byte GetAt(int index)
		{
			return this._bytes[index];
		}

		// Token: 0x060002C5 RID: 709 RVA: 0x00003700 File Offset: 0x00001900
		public void SetAt(int index, byte item)
		{
			this._bytes[index] = item;
		}

		// Token: 0x060002C6 RID: 710 RVA: 0x0000370F File Offset: 0x0000190F
		public char GetCharAt(int index)
		{
			return Convert.ToChar(this._bytes[index]);
		}

		// Token: 0x060002C7 RID: 711 RVA: 0x00003722 File Offset: 0x00001922
		public byte[] ToArray()
		{
			return this._bytes.ToArray();
		}

		// Token: 0x040001E1 RID: 481
		private List<byte> _bytes;
	}
}
