﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Server.Helper.HexEditor
{
	// Token: 0x02000056 RID: 86
	public class HexEditor : Control
	{
		// Token: 0x170000A5 RID: 165
		// (set) Token: 0x060002EE RID: 750 RVA: 0x000039B8 File Offset: 0x00001BB8
		public override Font Font
		{
			set
			{
				base.Font = value;
				this.UpdateRectanglePositioning();
				base.Invalidate();
			}
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x060002EF RID: 751 RVA: 0x000039CD File Offset: 0x00001BCD
		// (set) Token: 0x060002F0 RID: 752 RVA: 0x000039D5 File Offset: 0x00001BD5
		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public override string Text
		{
			get
			{
				return base.Text;
			}
			set
			{
				base.Text = value;
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x060002F1 RID: 753 RVA: 0x00016DC4 File Offset: 0x00014FC4
		// (set) Token: 0x060002F2 RID: 754 RVA: 0x00016E0C File Offset: 0x0001500C
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public byte[] HexTable
		{
			get
			{
				object hexTableLock = this._hexTableLock;
				byte[] result;
				lock (hexTableLock)
				{
					result = this._hexTable.ToArray();
				}
				return result;
			}
			set
			{
				object hexTableLock = this._hexTableLock;
				lock (hexTableLock)
				{
					if (value == this._hexTable.ToArray())
					{
						return;
					}
					this._hexTable = new ByteCollection(value);
				}
				this.UpdateRectanglePositioning();
				base.Invalidate();
			}
		}

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x060002F3 RID: 755 RVA: 0x000039DE File Offset: 0x00001BDE
		// (set) Token: 0x060002F4 RID: 756 RVA: 0x000039E6 File Offset: 0x00001BE6
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public SizeF CharSize
		{
			get
			{
				return this._charSize;
			}
			private set
			{
				if (this._charSize == value)
				{
					return;
				}
				this._charSize = value;
				if (this.CharSizeChanged != null)
				{
					this.CharSizeChanged(this, EventArgs.Empty);
				}
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x060002F5 RID: 757 RVA: 0x00003A17 File Offset: 0x00001C17
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public int MaxBytesV
		{
			get
			{
				return this._maxBytesV;
			}
		}

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x060002F6 RID: 758 RVA: 0x00003A1F File Offset: 0x00001C1F
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public int FirstVisibleByte
		{
			get
			{
				return this._firstByte;
			}
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x060002F7 RID: 759 RVA: 0x00003A27 File Offset: 0x00001C27
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public int LastVisibleByte
		{
			get
			{
				return this._lastByte;
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x060002F8 RID: 760 RVA: 0x00003A2F File Offset: 0x00001C2F
		// (set) Token: 0x060002F9 RID: 761 RVA: 0x00016E70 File Offset: 0x00015070
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public bool VScrollBarHidden
		{
			get
			{
				return this._isVScrollHidden;
			}
			set
			{
				if (this._isVScrollHidden == value)
				{
					return;
				}
				this._isVScrollHidden = value;
				if (!this._isVScrollHidden)
				{
					base.Controls.Add(this._vScrollBar);
				}
				else
				{
					base.Controls.Remove(this._vScrollBar);
				}
				this.UpdateRectanglePositioning();
				base.Invalidate();
			}
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x060002FA RID: 762 RVA: 0x00003A37 File Offset: 0x00001C37
		// (set) Token: 0x060002FB RID: 763 RVA: 0x00003A3F File Offset: 0x00001C3F
		[DefaultValue(8)]
		[Category("Hex")]
		[Description("Property that specifies the number of bytes to display per line.")]
		public int BytesPerLine
		{
			get
			{
				return this._bytesPerLine;
			}
			set
			{
				if (this._bytesPerLine == value)
				{
					return;
				}
				this._bytesPerLine = value;
				this.UpdateRectanglePositioning();
				base.Invalidate();
			}
		}

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x060002FC RID: 764 RVA: 0x00003A5E File Offset: 0x00001C5E
		// (set) Token: 0x060002FD RID: 765 RVA: 0x00003A66 File Offset: 0x00001C66
		[DefaultValue(10)]
		[Category("Hex")]
		[Description("Property that specifies the margin between each of the entitys in the control.")]
		public int EntityMargin
		{
			get
			{
				return this._entityMargin;
			}
			set
			{
				if (this._entityMargin == value)
				{
					return;
				}
				this._entityMargin = value;
				this.UpdateRectanglePositioning();
				base.Invalidate();
			}
		}

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x060002FE RID: 766 RVA: 0x00003A85 File Offset: 0x00001C85
		// (set) Token: 0x060002FF RID: 767 RVA: 0x00003A8D File Offset: 0x00001C8D
		[DefaultValue(BorderStyle.Fixed3D)]
		[Category("Appearance")]
		[Description("Indicates where the control should have a border.")]
		public BorderStyle BorderStyle
		{
			get
			{
				return this._borderStyle;
			}
			set
			{
				if (this._borderStyle == value)
				{
					return;
				}
				if (value != BorderStyle.FixedSingle)
				{
					this._borderColor = Color.Empty;
				}
				this._borderStyle = value;
				this.UpdateRectanglePositioning();
				base.Invalidate();
			}
		}

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x06000300 RID: 768 RVA: 0x00003ABB File Offset: 0x00001CBB
		// (set) Token: 0x06000301 RID: 769 RVA: 0x00003AC3 File Offset: 0x00001CC3
		[DefaultValue(typeof(Color), "Empty")]
		[Category("Appearance")]
		[Description("Indicates the color to be used when displaying a FixedSingle border.")]
		public Color BorderColor
		{
			get
			{
				return this._borderColor;
			}
			set
			{
				if (this.BorderStyle != BorderStyle.FixedSingle || this._borderColor == value)
				{
					return;
				}
				this._borderColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x06000302 RID: 770 RVA: 0x00003AEA File Offset: 0x00001CEA
		// (set) Token: 0x06000303 RID: 771 RVA: 0x00003AF2 File Offset: 0x00001CF2
		[DefaultValue(typeof(Color), "Blue")]
		[Category("Hex")]
		[Description("Property for the background color of the selected text areas.")]
		public Color SelectionBackColor
		{
			get
			{
				return this._selectionBackColor;
			}
			set
			{
				if (this._selectionBackColor == value)
				{
					return;
				}
				this._selectionBackColor = value;
			}
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x06000304 RID: 772 RVA: 0x00003B0A File Offset: 0x00001D0A
		// (set) Token: 0x06000305 RID: 773 RVA: 0x00003B12 File Offset: 0x00001D12
		[DefaultValue(typeof(Color), "White")]
		[Category("Hex")]
		[Description("Property for the foreground color of the selected text areas.")]
		public Color SelectionForeColor
		{
			get
			{
				return this._selectionForeColor;
			}
			set
			{
				if (this._selectionForeColor == value)
				{
					return;
				}
				this._selectionForeColor = value;
			}
		}

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x06000306 RID: 774 RVA: 0x00003B2A File Offset: 0x00001D2A
		// (set) Token: 0x06000307 RID: 775 RVA: 0x00003B32 File Offset: 0x00001D32
		[DefaultValue(HexEditor.CaseStyle.UpperCase)]
		[Category("Hex")]
		[Description("Property for the case type to use on the line counter.")]
		public HexEditor.CaseStyle LineCountCaseStyle
		{
			get
			{
				return this._lineCountCaseStyle;
			}
			set
			{
				if (this._lineCountCaseStyle == value)
				{
					return;
				}
				this._lineCountCaseStyle = value;
				if (this._lineCountCaseStyle == HexEditor.CaseStyle.LowerCase)
				{
					this._lineCountCaps = "x";
				}
				else
				{
					this._lineCountCaps = "X";
				}
				base.Invalidate();
			}
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x06000308 RID: 776 RVA: 0x00003B6B File Offset: 0x00001D6B
		// (set) Token: 0x06000309 RID: 777 RVA: 0x00003B73 File Offset: 0x00001D73
		[DefaultValue(HexEditor.CaseStyle.UpperCase)]
		[Category("Hex")]
		[Description("Property for the case type to use for the hexadecimal values view.")]
		public HexEditor.CaseStyle HexViewCaseStyle
		{
			get
			{
				return this._hexViewCaseStyle;
			}
			set
			{
				if (this._hexViewCaseStyle == value)
				{
					return;
				}
				this._hexViewCaseStyle = value;
				if (this._hexViewCaseStyle == HexEditor.CaseStyle.LowerCase)
				{
					this._editView.SetLowerCase();
				}
				else
				{
					this._editView.SetUpperCase();
				}
				base.Invalidate();
			}
		}

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x0600030A RID: 778 RVA: 0x00003BAC File Offset: 0x00001DAC
		// (set) Token: 0x0600030B RID: 779 RVA: 0x00003BB4 File Offset: 0x00001DB4
		[DefaultValue(false)]
		[Category("Hex")]
		[Description("Property for the visibility of the vertical scrollbar.")]
		public bool VScrollBarVisisble
		{
			get
			{
				return this._isVScrollVisible;
			}
			set
			{
				if (this._isVScrollVisible == value)
				{
					return;
				}
				this._isVScrollVisible = value;
				this.UpdateRectanglePositioning();
				base.Invalidate();
			}
		}

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x0600030C RID: 780 RVA: 0x00016EC8 File Offset: 0x000150C8
		// (remove) Token: 0x0600030D RID: 781 RVA: 0x00016F00 File Offset: 0x00015100
		[Description("Event that is triggered whenever the hextable has been changed.")]
		public event EventHandler HexTableChanged;

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x0600030E RID: 782 RVA: 0x00016F38 File Offset: 0x00015138
		// (remove) Token: 0x0600030F RID: 783 RVA: 0x00016F70 File Offset: 0x00015170
		[Description("Event that is triggered whenever the SelectionStart value is changed.")]
		public event EventHandler SelectionStartChanged;

		// Token: 0x1400000D RID: 13
		// (add) Token: 0x06000310 RID: 784 RVA: 0x00016FA8 File Offset: 0x000151A8
		// (remove) Token: 0x06000311 RID: 785 RVA: 0x00016FE0 File Offset: 0x000151E0
		[Description("Event that is triggered whenever the SelectionLength value is changed.")]
		public event EventHandler SelectionLengthChanged;

		// Token: 0x1400000E RID: 14
		// (add) Token: 0x06000312 RID: 786 RVA: 0x00017018 File Offset: 0x00015218
		// (remove) Token: 0x06000313 RID: 787 RVA: 0x00017050 File Offset: 0x00015250
		[Description("Event that is triggered whenever the size of the char is changed.")]
		public event EventHandler CharSizeChanged;

		// Token: 0x06000314 RID: 788 RVA: 0x00017088 File Offset: 0x00015288
		protected void OnVScrollBarScroll(object sender, ScrollEventArgs e)
		{
			switch (e.Type)
			{
			case ScrollEventType.SmallDecrement:
				this.ScrollLineUp(1);
				break;
			case ScrollEventType.SmallIncrement:
				this.ScrollLineDown(1);
				break;
			case ScrollEventType.LargeDecrement:
				this.ScrollLineUp(this._vScrollLarge);
				break;
			case ScrollEventType.LargeIncrement:
				this.ScrollLineDown(this._vScrollLarge);
				break;
			case ScrollEventType.ThumbTrack:
				this.ScrollThumbTrack(e.NewValue - e.OldValue);
				break;
			}
			base.Invalidate();
		}

		// Token: 0x06000315 RID: 789 RVA: 0x00003BD3 File Offset: 0x00001DD3
		protected void CaretSelectionStartChanged(object sender, EventArgs e)
		{
			if (this.SelectionStartChanged != null)
			{
				this.SelectionStartChanged(this, e);
			}
		}

		// Token: 0x06000316 RID: 790 RVA: 0x00003BEA File Offset: 0x00001DEA
		protected void CaretSelectionLengthChanged(object sender, EventArgs e)
		{
			if (this.SelectionLengthChanged != null)
			{
				this.SelectionLengthChanged(this, e);
			}
		}

		// Token: 0x06000317 RID: 791 RVA: 0x00003C01 File Offset: 0x00001E01
		protected override void OnMarginChanged(EventArgs e)
		{
			base.OnMarginChanged(e);
			this.UpdateRectanglePositioning();
			base.Invalidate();
		}

		// Token: 0x06000318 RID: 792 RVA: 0x00003C16 File Offset: 0x00001E16
		protected override void OnGotFocus(EventArgs e)
		{
			if (this._handler != null)
			{
				this._handler.OnGotFocus(e);
			}
			this.UpdateRectanglePositioning();
			base.Invalidate();
			base.OnGotFocus(e);
		}

		// Token: 0x06000319 RID: 793 RVA: 0x00003C3F File Offset: 0x00001E3F
		protected override void OnLostFocus(EventArgs e)
		{
			this._dragging = false;
			this.DestroyCaret();
			base.OnLostFocus(e);
		}

		// Token: 0x0600031A RID: 794 RVA: 0x00003C55 File Offset: 0x00001E55
		protected override bool IsInputKey(Keys keyData)
		{
			return keyData - Keys.Left <= 3 || keyData - (Keys.LButton | Keys.MButton | Keys.Space | Keys.Shift) <= 3 || base.IsInputKey(keyData);
		}

		// Token: 0x0600031B RID: 795 RVA: 0x00003C71 File Offset: 0x00001E71
		protected override void OnKeyPress(KeyPressEventArgs e)
		{
			if (this._handler != null)
			{
				this._handler.OnKeyPress(e);
			}
			base.OnKeyPress(e);
		}

		// Token: 0x0600031C RID: 796 RVA: 0x00017104 File Offset: 0x00015304
		protected override void OnKeyDown(KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Next)
			{
				if (!this._isVScrollHidden)
				{
					this.ScrollLineDown(this._vScrollLarge);
					base.Invalidate();
				}
			}
			else if (e.KeyCode == Keys.Prior)
			{
				if (!this._isVScrollHidden)
				{
					this.ScrollLineUp(this._vScrollLarge);
					base.Invalidate();
				}
			}
			else if (this._handler != null)
			{
				this._handler.OnKeyDown(e);
			}
			base.OnKeyDown(e);
		}

		// Token: 0x0600031D RID: 797 RVA: 0x00003C8E File Offset: 0x00001E8E
		protected override void OnKeyUp(KeyEventArgs e)
		{
			if (this._handler != null)
			{
				this._handler.OnKeyUp(e);
			}
			base.OnKeyUp(e);
		}

		// Token: 0x0600031E RID: 798 RVA: 0x00017178 File Offset: 0x00015378
		protected override void OnMouseDown(MouseEventArgs e)
		{
			if (this.Focused)
			{
				if (this._handler != null)
				{
					this._handler.OnMouseDown(e);
				}
				if (e.Button == MouseButtons.Left)
				{
					this._dragging = true;
					base.Invalidate();
				}
			}
			else
			{
				base.Focus();
			}
			base.OnMouseDown(e);
		}

		// Token: 0x0600031F RID: 799 RVA: 0x00003CAB File Offset: 0x00001EAB
		protected override void OnMouseMove(MouseEventArgs e)
		{
			if (this.Focused && this._dragging)
			{
				if (this._handler != null)
				{
					this._handler.OnMouseDragged(e);
				}
				base.Invalidate();
			}
			base.OnMouseMove(e);
		}

		// Token: 0x06000320 RID: 800 RVA: 0x00003CDE File Offset: 0x00001EDE
		protected override void OnMouseUp(MouseEventArgs e)
		{
			this._dragging = false;
			if (this.Focused && this._handler != null)
			{
				this._handler.OnMouseUp(e);
			}
			base.OnMouseUp(e);
		}

		// Token: 0x06000321 RID: 801 RVA: 0x00003D0A File Offset: 0x00001F0A
		protected override void OnMouseDoubleClick(MouseEventArgs e)
		{
			if (this.Focused && this._handler != null)
			{
				this._handler.OnMouseDoubleClick(e);
			}
			base.OnMouseDoubleClick(e);
		}

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x06000322 RID: 802 RVA: 0x000171CC File Offset: 0x000153CC
		public int CaretPosX
		{
			get
			{
				object caretLock = this._caretLock;
				int x;
				lock (caretLock)
				{
					x = this._caret.Location.X;
				}
				return x;
			}
		}

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x06000323 RID: 803 RVA: 0x0001721C File Offset: 0x0001541C
		public int CaretPosY
		{
			get
			{
				object caretLock = this._caretLock;
				int y;
				lock (caretLock)
				{
					y = this._caret.Location.Y;
				}
				return y;
			}
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x06000324 RID: 804 RVA: 0x0001726C File Offset: 0x0001546C
		public int SelectionStart
		{
			get
			{
				object caretLock = this._caretLock;
				int selectionStart;
				lock (caretLock)
				{
					selectionStart = this._caret.SelectionStart;
				}
				return selectionStart;
			}
		}

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x06000325 RID: 805 RVA: 0x000172B4 File Offset: 0x000154B4
		public int SelectionLength
		{
			get
			{
				object caretLock = this._caretLock;
				int selectionLength;
				lock (caretLock)
				{
					selectionLength = this._caret.SelectionLength;
				}
				return selectionLength;
			}
		}

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x06000326 RID: 806 RVA: 0x000172FC File Offset: 0x000154FC
		public int CaretIndex
		{
			get
			{
				object caretLock = this._caretLock;
				int currentIndex;
				lock (caretLock)
				{
					currentIndex = this._caret.CurrentIndex;
				}
				return currentIndex;
			}
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x06000327 RID: 807 RVA: 0x00017344 File Offset: 0x00015544
		public bool CaretFocused
		{
			get
			{
				object caretLock = this._caretLock;
				bool focused;
				lock (caretLock)
				{
					focused = this._caret.Focused;
				}
				return focused;
			}
		}

		// Token: 0x06000328 RID: 808 RVA: 0x0001738C File Offset: 0x0001558C
		public void SetCaretStart(int index, Point location)
		{
			location = this.ScrollToCaret(index, location);
			object caretLock = this._caretLock;
			lock (caretLock)
			{
				this._caret.SetStartIndex(index);
				this._caret.SetCaretLocation(location);
			}
			base.Invalidate();
		}

		// Token: 0x06000329 RID: 809 RVA: 0x000173F0 File Offset: 0x000155F0
		public void SetCaretEnd(int index, Point location)
		{
			location = this.ScrollToCaret(index, location);
			object caretLock = this._caretLock;
			lock (caretLock)
			{
				this._caret.SetEndIndex(index);
				this._caret.SetCaretLocation(location);
			}
			base.Invalidate();
		}

		// Token: 0x0600032A RID: 810 RVA: 0x00017454 File Offset: 0x00015654
		public bool IsSelected(int byteIndex)
		{
			object caretLock = this._caretLock;
			bool result;
			lock (caretLock)
			{
				result = this._caret.IsSelected(byteIndex);
			}
			return result;
		}

		// Token: 0x0600032B RID: 811 RVA: 0x0001749C File Offset: 0x0001569C
		public void DestroyCaret()
		{
			object caretLock = this._caretLock;
			lock (caretLock)
			{
				this._caret.Destroy();
			}
		}

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x0600032C RID: 812 RVA: 0x000174E4 File Offset: 0x000156E4
		public int HexTableLength
		{
			get
			{
				object hexTableLock = this._hexTableLock;
				int length;
				lock (hexTableLock)
				{
					length = this._hexTable.Length;
				}
				return length;
			}
		}

		// Token: 0x0600032D RID: 813 RVA: 0x0001752C File Offset: 0x0001572C
		public void RemoveSelectedBytes()
		{
			int selectionStart = this.SelectionStart;
			int selectionLength = this.SelectionLength;
			if (selectionLength > 0)
			{
				object hexTableLock = this._hexTableLock;
				lock (hexTableLock)
				{
					this._hexTable.RemoveRange(selectionStart, selectionLength);
				}
				this.UpdateRectanglePositioning();
				base.Invalidate();
				if (this.HexTableChanged != null)
				{
					this.HexTableChanged(this, EventArgs.Empty);
				}
			}
		}

		// Token: 0x0600032E RID: 814 RVA: 0x000175AC File Offset: 0x000157AC
		public void RemoveByteAt(int index)
		{
			object hexTableLock = this._hexTableLock;
			lock (hexTableLock)
			{
				this._hexTable.RemoveAt(index);
			}
			this.UpdateRectanglePositioning();
			base.Invalidate();
			if (this.HexTableChanged != null)
			{
				this.HexTableChanged(this, EventArgs.Empty);
			}
		}

		// Token: 0x0600032F RID: 815 RVA: 0x00017618 File Offset: 0x00015818
		public void AppendByte(byte item)
		{
			object hexTableLock = this._hexTableLock;
			lock (hexTableLock)
			{
				this._hexTable.Add(item);
			}
			this.UpdateRectanglePositioning();
			base.Invalidate();
			if (this.HexTableChanged != null)
			{
				this.HexTableChanged(this, EventArgs.Empty);
			}
		}

		// Token: 0x06000330 RID: 816 RVA: 0x00017684 File Offset: 0x00015884
		public void InsertByte(int index, byte item)
		{
			object hexTableLock = this._hexTableLock;
			lock (hexTableLock)
			{
				this._hexTable.Insert(index, item);
			}
			this.UpdateRectanglePositioning();
			base.Invalidate();
			if (this.HexTableChanged != null)
			{
				this.HexTableChanged(this, EventArgs.Empty);
			}
		}

		// Token: 0x06000331 RID: 817 RVA: 0x000176F0 File Offset: 0x000158F0
		public char GetByteAsChar(int index)
		{
			object hexTableLock = this._hexTableLock;
			char charAt;
			lock (hexTableLock)
			{
				charAt = this._hexTable.GetCharAt(index);
			}
			return charAt;
		}

		// Token: 0x06000332 RID: 818 RVA: 0x00017738 File Offset: 0x00015938
		public byte GetByte(int index)
		{
			object hexTableLock = this._hexTableLock;
			byte at;
			lock (hexTableLock)
			{
				at = this._hexTable.GetAt(index);
			}
			return at;
		}

		// Token: 0x06000333 RID: 819 RVA: 0x00017780 File Offset: 0x00015980
		public void SetByte(int index, byte item)
		{
			object hexTableLock = this._hexTableLock;
			lock (hexTableLock)
			{
				this._hexTable.SetAt(index, item);
			}
			base.Invalidate();
			if (this.HexTableChanged != null)
			{
				this.HexTableChanged(this, EventArgs.Empty);
			}
		}

		// Token: 0x06000334 RID: 820 RVA: 0x000177E8 File Offset: 0x000159E8
		public void ScrollLineUp(int lines)
		{
			if (this._firstByte > 0)
			{
				lines = ((lines > this._vScrollPos) ? this._vScrollPos : lines);
				this._vScrollPos -= this._vScrollSmall * lines;
				this.UpdateVisibleByteIndex();
				this.UpdateScrollValues();
				if (this.CaretFocused)
				{
					Point caretLocation = new Point(this.CaretPosX, this.CaretPosY);
					caretLocation.Y += this._recLineCount.Height * lines;
					object caretLock = this._caretLock;
					lock (caretLock)
					{
						this._caret.SetCaretLocation(caretLocation);
					}
				}
			}
		}

		// Token: 0x06000335 RID: 821 RVA: 0x000178A8 File Offset: 0x00015AA8
		public void ScrollLineDown(int lines)
		{
			if (this._vScrollPos <= this._vScrollMax - this._vScrollLarge)
			{
				lines = ((lines + this._vScrollPos > this._vScrollMax - this._vScrollLarge) ? (this._vScrollMax - this._vScrollLarge - this._vScrollPos + 1) : lines);
				this._vScrollPos += this._vScrollSmall * lines;
				this.UpdateVisibleByteIndex();
				this.UpdateScrollValues();
				if (this.CaretFocused)
				{
					Point caretLocation = new Point(this.CaretPosX, this.CaretPosY);
					caretLocation.Y -= this._recLineCount.Height * lines;
					object caretLock = this._caretLock;
					lock (caretLock)
					{
						this._caret.SetCaretLocation(caretLocation);
						if (caretLocation.Y < this._recContent.Y)
						{
							this._caret.Hide(base.Handle);
						}
					}
				}
			}
		}

		// Token: 0x06000336 RID: 822 RVA: 0x00003D2F File Offset: 0x00001F2F
		public void ScrollThumbTrack(int lines)
		{
			if (lines == 0)
			{
				return;
			}
			if (lines < 0)
			{
				this.ScrollLineUp(-1 * lines);
				return;
			}
			this.ScrollLineDown(lines);
		}

		// Token: 0x06000337 RID: 823 RVA: 0x000179B8 File Offset: 0x00015BB8
		public Point ScrollToCaret(int caretIndex, Point position)
		{
			if (position.Y < 0)
			{
				this._vScrollPos -= Math.Abs((position.Y - this._recContent.Y) / this._recLineCount.Height) * this._vScrollSmall;
				this.UpdateVisibleByteIndex();
				this.UpdateScrollValues();
				if (this.CaretFocused)
				{
					position.Y = this._recContent.Y;
				}
			}
			else if (position.Y > this._maxVisibleBytesV * this._recLineCount.Height)
			{
				this._vScrollPos += (position.Y / this._recLineCount.Height - (this._maxVisibleBytesV - 1)) * this._vScrollSmall;
				if (this._vScrollPos > this._vScrollMax - (this._vScrollLarge - 1))
				{
					this._vScrollPos = this._vScrollMax - (this._vScrollLarge - 1);
				}
				this.UpdateVisibleByteIndex();
				this.UpdateScrollValues();
				if (this.CaretFocused)
				{
					position.Y = (this._maxVisibleBytesV - 1) * this._recLineCount.Height + this._recContent.Y;
				}
			}
			return position;
		}

		// Token: 0x06000338 RID: 824 RVA: 0x00017AEC File Offset: 0x00015CEC
		private void UpdateRectanglePositioning()
		{
			if (base.ClientRectangle.Width == 0)
			{
				return;
			}
			SizeF sizeF;
			using (Graphics graphics = base.CreateGraphics())
			{
				sizeF = graphics.MeasureString("D", this.Font, 100, this._stringFormat);
			}
			this.CharSize = new SizeF((float)Math.Ceiling((double)sizeF.Width), (float)Math.Ceiling((double)sizeF.Height));
			this._recContent = base.ClientRectangle;
			this._recContent.X = this._recContent.X + base.Margin.Left;
			this._recContent.Y = this._recContent.Y + base.Margin.Top;
			this._recContent.Width = this._recContent.Width - base.Margin.Right;
			this._recContent.Height = this._recContent.Height - base.Margin.Bottom;
			if (this.BorderStyle == BorderStyle.Fixed3D)
			{
				this._recContent.X = this._recContent.X + 2;
				this._recContent.Y = this._recContent.Y + 2;
				this._recContent.Width = this._recContent.Width - 1;
				this._recContent.Height = this._recContent.Height - 1;
			}
			else if (this.BorderStyle == BorderStyle.FixedSingle)
			{
				this._recContent.X = this._recContent.X + 1;
				this._recContent.Y = this._recContent.Y + 1;
				this._recContent.Width = this._recContent.Width - 1;
				this._recContent.Height = this._recContent.Height - 1;
			}
			if (!this.VScrollBarHidden)
			{
				this._recContent.Width = this._recContent.Width - this._vScrollBarWidth;
				this._vScrollBar.Left = this._recContent.X + this._recContent.Width - base.Margin.Left;
				this._vScrollBar.Top = this._recContent.Y - base.Margin.Top;
				this._vScrollBar.Width = this._vScrollBarWidth;
				this._vScrollBar.Height = this._recContent.Height;
			}
			this._recLineCount = new Rectangle(this._recContent.X, this._recContent.Y, (int)(this._charSize.Width * 4f), (int)this._charSize.Height - 2);
			this._editView.Update(this._recLineCount.X + this._recLineCount.Width + this._entityMargin / 2, this._recContent);
			this._maxBytesH = this._bytesPerLine;
			this._maxBytesV = (int)Math.Ceiling((double)((float)this._recContent.Height / (float)this._recLineCount.Height));
			this._maxBytes = this._maxBytesH * this._maxBytesV;
			this._maxVisibleBytesV = (int)Math.Floor((double)((float)this._recContent.Height / (float)this._recLineCount.Height));
			this.UpdateScrollBarSize();
		}

		// Token: 0x06000339 RID: 825 RVA: 0x00017E2C File Offset: 0x0001602C
		private void UpdateVisibleByteIndex()
		{
			if (this._hexTable.Length == 0)
			{
				this._firstByte = 0;
				this._lastByte = 0;
				return;
			}
			this._firstByte = this._vScrollPos * this._maxBytesH;
			this._lastByte = Math.Min(this.HexTableLength, this._firstByte + this._maxBytes);
		}

		// Token: 0x0600033A RID: 826 RVA: 0x00017E88 File Offset: 0x00016088
		private void UpdateScrollValues()
		{
			if (!this._isVScrollHidden)
			{
				this._vScrollBar.Minimum = this._vScrollMin;
				this._vScrollBar.Maximum = this._vScrollMax;
				this._vScrollBar.Value = this._vScrollPos;
				this._vScrollBar.SmallChange = this._vScrollSmall;
				this._vScrollBar.LargeChange = this._vScrollLarge;
				this._vScrollBar.Visible = true;
				return;
			}
			this._vScrollBar.Visible = false;
		}

		// Token: 0x0600033B RID: 827 RVA: 0x00017F0C File Offset: 0x0001610C
		private void UpdateScrollBarSize()
		{
			if (!this.VScrollBarVisisble || this._maxVisibleBytesV <= 0 || this._maxBytesH <= 0)
			{
				this.VScrollBarHidden = true;
				return;
			}
			int maxVisibleBytesV = this._maxVisibleBytesV;
			int num = 1;
			int vScrollMin = 0;
			int num2 = this.HexTableLength / this._maxBytesH;
			int num3 = this._firstByte / this._maxBytesH;
			if (maxVisibleBytesV != this._vScrollLarge || num != this._vScrollSmall)
			{
				this._vScrollLarge = maxVisibleBytesV;
				this._vScrollSmall = num;
			}
			if (num2 >= maxVisibleBytesV)
			{
				if (num2 != this._vScrollMax || num3 != this._vScrollPos)
				{
					this._vScrollMin = vScrollMin;
					this._vScrollMax = num2;
					this._vScrollPos = num3;
				}
				this.VScrollBarHidden = false;
				this.UpdateScrollValues();
				return;
			}
			this.VScrollBarHidden = true;
		}

		// Token: 0x0600033C RID: 828 RVA: 0x00003D4A File Offset: 0x00001F4A
		public HexEditor() : this(new ByteCollection())
		{
		}

		// Token: 0x0600033D RID: 829 RVA: 0x00017FD0 File Offset: 0x000161D0
		public HexEditor(ByteCollection collection)
		{
			this._stringFormat = new StringFormat(StringFormat.GenericTypographic);
			this._stringFormat.Alignment = StringAlignment.Center;
			this._stringFormat.LineAlignment = StringAlignment.Center;
			this._hexTable = collection;
			this._vScrollBar = new VScrollBar();
			this._vScrollBar.Scroll += this.OnVScrollBarScroll;
			base.SetStyle(ControlStyles.ResizeRedraw, true);
			base.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.SetStyle(ControlStyles.Selectable, true);
			this._caret = new Caret(this);
			this._caret.SelectionStartChanged += this.CaretSelectionStartChanged;
			this._caret.SelectionLengthChanged += this.CaretSelectionLengthChanged;
			this._editView = new EditView(this);
			this._handler = this._editView;
			this.Cursor = Cursors.IBeam;
		}

		// Token: 0x0600033E RID: 830 RVA: 0x00018130 File Offset: 0x00016330
		private RectangleF GetLineCountBound(int index)
		{
			return new RectangleF((float)this._recLineCount.X, (float)(this._recLineCount.Y + this._recLineCount.Height * index), (float)this._recLineCount.Width, (float)this._recLineCount.Height);
		}

		// Token: 0x0600033F RID: 831 RVA: 0x00018180 File Offset: 0x00016380
		protected override void OnPaintBackground(PaintEventArgs pevent)
		{
			if (this.BorderStyle == BorderStyle.Fixed3D)
			{
				SolidBrush brush = new SolidBrush(this.BackColor);
				Rectangle clientRectangle = base.ClientRectangle;
				pevent.Graphics.FillRectangle(brush, clientRectangle);
				ControlPaint.DrawBorder3D(pevent.Graphics, base.ClientRectangle, Border3DStyle.Sunken);
				return;
			}
			if (this.BorderStyle == BorderStyle.FixedSingle)
			{
				SolidBrush brush2 = new SolidBrush(this.BackColor);
				Rectangle clientRectangle2 = base.ClientRectangle;
				pevent.Graphics.FillRectangle(brush2, clientRectangle2);
				ControlPaint.DrawBorder(pevent.Graphics, base.ClientRectangle, this.BorderColor, ButtonBorderStyle.Solid);
				return;
			}
			base.OnPaintBackground(pevent);
		}

		// Token: 0x06000340 RID: 832 RVA: 0x00018214 File Offset: 0x00016414
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Region region = new Region(base.ClientRectangle);
			region.Exclude(this._recContent);
			e.Graphics.ExcludeClip(region);
			this.UpdateVisibleByteIndex();
			this.PaintLineCount(e.Graphics, this._firstByte, this._lastByte);
			this._editView.Paint(e.Graphics, this._firstByte, this._lastByte);
		}

		// Token: 0x06000341 RID: 833 RVA: 0x00018288 File Offset: 0x00016488
		private void PaintLineCount(Graphics g, int startIndex, int lastIndex)
		{
			SolidBrush brush = new SolidBrush(this.ForeColor);
			int num = 0;
			while (num * this._maxBytesH + startIndex <= lastIndex)
			{
				RectangleF lineCountBound = this.GetLineCountBound(num);
				string text = (startIndex + num * this._maxBytesH).ToString(this._lineCountCaps);
				int num2 = this._nrCharsLineCount - text.Length;
				string s;
				if (num2 > -1)
				{
					s = new string('0', num2) + text;
				}
				else
				{
					s = new string('~', this._nrCharsLineCount);
				}
				g.DrawString(s, this.Font, brush, lineCountBound, this._stringFormat);
				num++;
			}
		}

		// Token: 0x06000342 RID: 834 RVA: 0x00003D57 File Offset: 0x00001F57
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.UpdateRectanglePositioning();
			base.Invalidate();
		}

		// Token: 0x040001ED RID: 493
		private object _caretLock = new object();

		// Token: 0x040001EE RID: 494
		private object _hexTableLock = new object();

		// Token: 0x040001EF RID: 495
		private IKeyMouseEventHandler _handler;

		// Token: 0x040001F0 RID: 496
		private EditView _editView;

		// Token: 0x040001F1 RID: 497
		private ByteCollection _hexTable;

		// Token: 0x040001F2 RID: 498
		private string _lineCountCaps = "X";

		// Token: 0x040001F3 RID: 499
		private int _nrCharsLineCount = 4;

		// Token: 0x040001F4 RID: 500
		private Caret _caret;

		// Token: 0x040001F5 RID: 501
		private Rectangle _recContent;

		// Token: 0x040001F6 RID: 502
		private Rectangle _recLineCount;

		// Token: 0x040001F7 RID: 503
		private StringFormat _stringFormat;

		// Token: 0x040001F8 RID: 504
		private int _firstByte;

		// Token: 0x040001F9 RID: 505
		private int _lastByte;

		// Token: 0x040001FA RID: 506
		private int _maxBytesH;

		// Token: 0x040001FB RID: 507
		private int _maxBytesV;

		// Token: 0x040001FC RID: 508
		private int _maxBytes;

		// Token: 0x040001FD RID: 509
		private int _maxVisibleBytesV;

		// Token: 0x040001FE RID: 510
		private VScrollBar _vScrollBar;

		// Token: 0x040001FF RID: 511
		private int _vScrollBarWidth = 20;

		// Token: 0x04000200 RID: 512
		private int _vScrollPos;

		// Token: 0x04000201 RID: 513
		private int _vScrollMax;

		// Token: 0x04000202 RID: 514
		private int _vScrollMin;

		// Token: 0x04000203 RID: 515
		private int _vScrollSmall;

		// Token: 0x04000204 RID: 516
		private int _vScrollLarge;

		// Token: 0x04000205 RID: 517
		private SizeF _charSize;

		// Token: 0x04000206 RID: 518
		private bool _isVScrollHidden = true;

		// Token: 0x04000207 RID: 519
		private int _bytesPerLine = 8;

		// Token: 0x04000208 RID: 520
		private int _entityMargin = 10;

		// Token: 0x04000209 RID: 521
		private BorderStyle _borderStyle = BorderStyle.Fixed3D;

		// Token: 0x0400020A RID: 522
		private Color _borderColor = Color.Empty;

		// Token: 0x0400020B RID: 523
		private Color _selectionBackColor = Color.Blue;

		// Token: 0x0400020C RID: 524
		private Color _selectionForeColor = Color.White;

		// Token: 0x0400020D RID: 525
		private HexEditor.CaseStyle _lineCountCaseStyle = HexEditor.CaseStyle.UpperCase;

		// Token: 0x0400020E RID: 526
		private HexEditor.CaseStyle _hexViewCaseStyle = HexEditor.CaseStyle.UpperCase;

		// Token: 0x0400020F RID: 527
		private bool _isVScrollVisible;

		// Token: 0x04000214 RID: 532
		private bool _dragging;

		// Token: 0x02000057 RID: 87
		public enum CaseStyle
		{
			// Token: 0x04000216 RID: 534
			LowerCase,
			// Token: 0x04000217 RID: 535
			UpperCase
		}
	}
}
