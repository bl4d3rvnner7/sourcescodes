﻿using System;
using System.Windows.Forms;

namespace Server.Helper.HexEditor
{
	// Token: 0x02000059 RID: 89
	public interface IKeyMouseEventHandler
	{
		// Token: 0x06000358 RID: 856
		void OnKeyPress(KeyPressEventArgs e);

		// Token: 0x06000359 RID: 857
		void OnKeyDown(KeyEventArgs e);

		// Token: 0x0600035A RID: 858
		void OnKeyUp(KeyEventArgs e);

		// Token: 0x0600035B RID: 859
		void OnMouseDown(MouseEventArgs e);

		// Token: 0x0600035C RID: 860
		void OnMouseDragged(MouseEventArgs e);

		// Token: 0x0600035D RID: 861
		void OnMouseUp(MouseEventArgs e);

		// Token: 0x0600035E RID: 862
		void OnMouseDoubleClick(MouseEventArgs e);

		// Token: 0x0600035F RID: 863
		void OnGotFocus(EventArgs e);
	}
}
