﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Server.Helper.HexEditor
{
	// Token: 0x02000058 RID: 88
	public class HexViewHandler
	{
		// Token: 0x170000BD RID: 189
		// (get) Token: 0x06000343 RID: 835 RVA: 0x00003D6C File Offset: 0x00001F6C
		public int MaxWidth
		{
			get
			{
				return this._recHexValue.X + this._recHexValue.Width * this._editor.BytesPerLine;
			}
		}

		// Token: 0x06000344 RID: 836 RVA: 0x00018324 File Offset: 0x00016524
		public HexViewHandler(HexEditor editor)
		{
			this._editor = editor;
			this._stringFormat = new StringFormat(StringFormat.GenericTypographic);
			this._stringFormat.Alignment = StringAlignment.Center;
			this._stringFormat.LineAlignment = StringAlignment.Center;
		}

		// Token: 0x06000345 RID: 837 RVA: 0x00003D91 File Offset: 0x00001F91
		public void OnKeyPress(KeyPressEventArgs e)
		{
			if (this.IsHex(e.KeyChar))
			{
				this.HandleUserInput(e.KeyChar);
			}
		}

		// Token: 0x06000346 RID: 838 RVA: 0x00018374 File Offset: 0x00016574
		public void OnKeyDown(KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Delete || e.KeyCode == Keys.Back)
			{
				if (this._editor.SelectionLength > 0)
				{
					this.HandleUserRemove();
					int caretIndex = this._editor.CaretIndex;
					Point caretLocation = this.GetCaretLocation(caretIndex);
					this._editor.SetCaretStart(caretIndex, caretLocation);
				}
				else if (this._editor.CaretIndex < this._editor.LastVisibleByte && e.KeyCode == Keys.Delete)
				{
					this._editor.RemoveByteAt(this._editor.CaretIndex);
					Point caretLocation2 = this.GetCaretLocation(this._editor.CaretIndex);
					this._editor.SetCaretStart(this._editor.CaretIndex, caretLocation2);
				}
				else if (this._editor.CaretIndex > 0 && e.KeyCode == Keys.Back)
				{
					int index = this._editor.CaretIndex - 1;
					if (this._isEditing)
					{
						index = this._editor.CaretIndex;
					}
					this._editor.RemoveByteAt(index);
					Point caretLocation3 = this.GetCaretLocation(index);
					this._editor.SetCaretStart(index, caretLocation3);
				}
				this._isEditing = false;
				return;
			}
			if (e.KeyCode == Keys.Up && this._editor.CaretIndex - this._editor.BytesPerLine >= 0)
			{
				int num = this._editor.CaretIndex - this._editor.BytesPerLine;
				if (num % this._editor.BytesPerLine == 0 && this._editor.CaretPosX >= this._recHexValue.X + this._recHexValue.Width * this._editor.BytesPerLine)
				{
					Point location = new Point(this._editor.CaretPosX, this._editor.CaretPosY - this._recHexValue.Height);
					if (num == 0)
					{
						location = new Point(this._editor.CaretPosX, this._editor.CaretPosY);
						num = this._editor.BytesPerLine;
					}
					if (e.Shift)
					{
						this._editor.SetCaretEnd(num, location);
					}
					else
					{
						this._editor.SetCaretStart(num, location);
					}
					this._isEditing = false;
					return;
				}
				this.HandleArrowKeys(num, e.Shift);
				return;
			}
			else if (e.KeyCode == Keys.Down && (this._editor.CaretIndex - 1) / this._editor.BytesPerLine < this._editor.HexTableLength / this._editor.BytesPerLine)
			{
				int num2 = this._editor.CaretIndex + this._editor.BytesPerLine;
				if (num2 > this._editor.HexTableLength)
				{
					num2 = this._editor.HexTableLength;
					this.HandleArrowKeys(num2, e.Shift);
					return;
				}
				Point location2 = new Point(this._editor.CaretPosX, this._editor.CaretPosY + this._recHexValue.Height);
				if (e.Shift)
				{
					this._editor.SetCaretEnd(num2, location2);
				}
				else
				{
					this._editor.SetCaretStart(num2, location2);
				}
				this._isEditing = false;
				return;
			}
			else
			{
				if (e.KeyCode == Keys.Left && this._editor.CaretIndex - 1 >= 0)
				{
					int index2 = this._editor.CaretIndex - 1;
					this.HandleArrowKeys(index2, e.Shift);
					return;
				}
				if (e.KeyCode == Keys.Right && this._editor.CaretIndex + 1 <= this._editor.HexTableLength)
				{
					int index3 = this._editor.CaretIndex + 1;
					this.HandleArrowKeys(index3, e.Shift);
				}
				return;
			}
		}

		// Token: 0x06000347 RID: 839 RVA: 0x00018710 File Offset: 0x00016910
		public void HandleArrowKeys(int index, bool isShiftDown)
		{
			Point caretLocation = this.GetCaretLocation(index);
			if (isShiftDown)
			{
				this._editor.SetCaretEnd(index, caretLocation);
			}
			else
			{
				this._editor.SetCaretStart(index, caretLocation);
			}
			this._isEditing = false;
		}

		// Token: 0x06000348 RID: 840 RVA: 0x0001874C File Offset: 0x0001694C
		public void OnMouseDown(int x, int y)
		{
			int num = (x - this._recHexValue.X) / this._recHexValue.Width;
			int num2 = (y - this._recHexValue.Y) / this._recHexValue.Height;
			num = ((num > this._editor.BytesPerLine) ? this._editor.BytesPerLine : num);
			num = ((num < 0) ? 0 : num);
			num2 = ((num2 > this._editor.MaxBytesV) ? this._editor.MaxBytesV : num2);
			num2 = ((num2 < 0) ? 0 : num2);
			if ((this._editor.LastVisibleByte - this._editor.FirstVisibleByte) / this._editor.BytesPerLine <= num2)
			{
				if ((this._editor.LastVisibleByte - this._editor.FirstVisibleByte) % this._editor.BytesPerLine <= num)
				{
					num = (this._editor.LastVisibleByte - this._editor.FirstVisibleByte) % this._editor.BytesPerLine;
				}
				num2 = (this._editor.LastVisibleByte - this._editor.FirstVisibleByte) / this._editor.BytesPerLine;
			}
			int index = Math.Min(this._editor.LastVisibleByte, this._editor.FirstVisibleByte + num + num2 * this._editor.BytesPerLine);
			int x2 = num * this._recHexValue.Width + this._recHexValue.X;
			int y2 = num2 * this._recHexValue.Height + this._recHexValue.Y;
			this._editor.SetCaretStart(index, new Point(x2, y2));
			this._isEditing = false;
		}

		// Token: 0x06000349 RID: 841 RVA: 0x000188EC File Offset: 0x00016AEC
		public void OnMouseDragged(int x, int y)
		{
			int num = (x - this._recHexValue.X) / this._recHexValue.Width;
			int num2 = (y - this._recHexValue.Y) / this._recHexValue.Height;
			num = ((num > this._editor.BytesPerLine) ? this._editor.BytesPerLine : num);
			num = ((num < 0) ? 0 : num);
			num2 = ((num2 > this._editor.MaxBytesV) ? this._editor.MaxBytesV : num2);
			if (this._editor.FirstVisibleByte > 0)
			{
				num2 = ((num2 < 0) ? -1 : num2);
			}
			else
			{
				num2 = ((num2 < 0) ? 0 : num2);
			}
			if ((this._editor.LastVisibleByte - this._editor.FirstVisibleByte) / this._editor.BytesPerLine <= num2)
			{
				if ((this._editor.LastVisibleByte - this._editor.FirstVisibleByte) % this._editor.BytesPerLine <= num)
				{
					num = (this._editor.LastVisibleByte - this._editor.FirstVisibleByte) % this._editor.BytesPerLine;
				}
				num2 = (this._editor.LastVisibleByte - this._editor.FirstVisibleByte) / this._editor.BytesPerLine;
			}
			int index = Math.Min(this._editor.LastVisibleByte, this._editor.FirstVisibleByte + num + num2 * this._editor.BytesPerLine);
			int x2 = num * this._recHexValue.Width + this._recHexValue.X;
			int y2 = num2 * this._recHexValue.Height + this._recHexValue.Y;
			this._editor.SetCaretEnd(index, new Point(x2, y2));
		}

		// Token: 0x0600034A RID: 842 RVA: 0x00018A9C File Offset: 0x00016C9C
		public void OnMouseDoubleClick()
		{
			if (this._editor.CaretIndex < this._editor.LastVisibleByte)
			{
				int index = this._editor.CaretIndex + 1;
				Point caretLocation = this.GetCaretLocation(index);
				this._editor.SetCaretEnd(index, caretLocation);
			}
		}

		// Token: 0x0600034B RID: 843 RVA: 0x00018AE4 File Offset: 0x00016CE4
		public void Update(int startPositionX, Rectangle area)
		{
			this._recHexValue = new Rectangle(startPositionX, area.Y, (int)(this._editor.CharSize.Width * 3f), (int)this._editor.CharSize.Height - 2);
			this._recHexValue.X = this._recHexValue.X + this._editor.EntityMargin;
		}

		// Token: 0x0600034C RID: 844 RVA: 0x00018B54 File Offset: 0x00016D54
		public void Paint(Graphics g, int index, int startIndex)
		{
			Point byteColumnAndRow = this.GetByteColumnAndRow(index);
			if (this._editor.IsSelected(index + startIndex))
			{
				this.PaintByteAsSelected(g, byteColumnAndRow, index + startIndex);
				return;
			}
			this.PaintByte(g, byteColumnAndRow, index + startIndex);
		}

		// Token: 0x0600034D RID: 845 RVA: 0x00018B90 File Offset: 0x00016D90
		private void PaintByteAsSelected(Graphics g, Point point, int index)
		{
			SolidBrush brush = new SolidBrush(this._editor.SelectionBackColor);
			SolidBrush brush2 = new SolidBrush(this._editor.SelectionForeColor);
			RectangleF bound = this.GetBound(point);
			string s = this._editor.GetByte(index).ToString(this._hexType);
			g.FillRectangle(brush, bound);
			g.DrawString(s, this._editor.Font, brush2, bound, this._stringFormat);
		}

		// Token: 0x0600034E RID: 846 RVA: 0x00018C08 File Offset: 0x00016E08
		private void PaintByte(Graphics g, Point point, int index)
		{
			SolidBrush brush = new SolidBrush(this._editor.ForeColor);
			RectangleF bound = this.GetBound(point);
			string s = this._editor.GetByte(index).ToString(this._hexType);
			g.DrawString(s, this._editor.Font, brush, bound, this._stringFormat);
		}

		// Token: 0x0600034F RID: 847 RVA: 0x00003DAD File Offset: 0x00001FAD
		public void SetLowerCase()
		{
			this._hexType = "x2";
		}

		// Token: 0x06000350 RID: 848 RVA: 0x00003DBA File Offset: 0x00001FBA
		public void SetUpperCase()
		{
			this._hexType = "X2";
		}

		// Token: 0x06000351 RID: 849 RVA: 0x00018C64 File Offset: 0x00016E64
		public void Focus()
		{
			int caretIndex = this._editor.CaretIndex;
			Point caretLocation = this.GetCaretLocation(caretIndex);
			this._editor.SetCaretStart(caretIndex, caretLocation);
		}

		// Token: 0x06000352 RID: 850 RVA: 0x00018C94 File Offset: 0x00016E94
		private Point GetCaretLocation(int index)
		{
			int x = this._recHexValue.X + this._recHexValue.Width * (index % this._editor.BytesPerLine);
			int y = this._recHexValue.Y + this._recHexValue.Height * ((index - (this._editor.FirstVisibleByte + index % this._editor.BytesPerLine)) / this._editor.BytesPerLine);
			return new Point(x, y);
		}

		// Token: 0x06000353 RID: 851 RVA: 0x00018D10 File Offset: 0x00016F10
		private void HandleUserRemove()
		{
			int selectionStart = this._editor.SelectionStart;
			Point caretLocation = this.GetCaretLocation(selectionStart);
			this._editor.RemoveSelectedBytes();
			this._editor.SetCaretStart(selectionStart, caretLocation);
		}

		// Token: 0x06000354 RID: 852 RVA: 0x00018D4C File Offset: 0x00016F4C
		private void HandleUserInput(char key)
		{
			if (!this._editor.CaretFocused)
			{
				return;
			}
			this.HandleUserRemove();
			if (this._isEditing)
			{
				this._isEditing = false;
				byte b = this._editor.GetByte(this._editor.CaretIndex);
				b += Convert.ToByte(key.ToString(), 16);
				this._editor.SetByte(this._editor.CaretIndex, b);
				int index = this._editor.CaretIndex + 1;
				Point caretLocation = this.GetCaretLocation(index);
				this._editor.SetCaretStart(index, caretLocation);
				return;
			}
			this._isEditing = true;
			byte item = Convert.ToByte(key.ToString() + "0", 16);
			if (this._editor.HexTable.Length == 0)
			{
				this._editor.AppendByte(item);
			}
			else
			{
				this._editor.InsertByte(this._editor.CaretIndex, item);
			}
			int x = this._recHexValue.X + this._recHexValue.Width * (this._editor.CaretIndex % this._editor.BytesPerLine) + this._recHexValue.Width / 2;
			int y = this._recHexValue.Y + this._recHexValue.Height * ((this._editor.CaretIndex - (this._editor.FirstVisibleByte + this._editor.CaretIndex % this._editor.BytesPerLine)) / this._editor.BytesPerLine);
			this._editor.SetCaretStart(this._editor.CaretIndex, new Point(x, y));
		}

		// Token: 0x06000355 RID: 853 RVA: 0x00018EE8 File Offset: 0x000170E8
		private Point GetByteColumnAndRow(int index)
		{
			int x = index % this._editor.BytesPerLine;
			int y = index / this._editor.BytesPerLine;
			return new Point(x, y);
		}

		// Token: 0x06000356 RID: 854 RVA: 0x00018F18 File Offset: 0x00017118
		private RectangleF GetBound(Point point)
		{
			return new RectangleF((float)(this._recHexValue.X + point.X * this._recHexValue.Width), (float)(this._recHexValue.Y + point.Y * this._recHexValue.Height), (float)this._recHexValue.Width, (float)this._recHexValue.Height);
		}

		// Token: 0x06000357 RID: 855 RVA: 0x00003DC7 File Offset: 0x00001FC7
		private bool IsHex(char c)
		{
			return (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F') || char.IsDigit(c);
		}

		// Token: 0x04000218 RID: 536
		private bool _isEditing;

		// Token: 0x04000219 RID: 537
		private string _hexType = "X2";

		// Token: 0x0400021A RID: 538
		private Rectangle _recHexValue;

		// Token: 0x0400021B RID: 539
		private StringFormat _stringFormat;

		// Token: 0x0400021C RID: 540
		private HexEditor _editor;
	}
}
