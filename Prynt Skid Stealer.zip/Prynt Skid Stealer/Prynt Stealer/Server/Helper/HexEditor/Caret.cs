﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace Server.Helper.HexEditor
{
	// Token: 0x02000054 RID: 84
	public class Caret
	{
		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x060002C8 RID: 712 RVA: 0x0000372F File Offset: 0x0000192F
		public int SelectionStart
		{
			get
			{
				if (this._endIndex < this._startIndex)
				{
					return this._endIndex;
				}
				return this._startIndex;
			}
		}

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x060002C9 RID: 713 RVA: 0x0000374C File Offset: 0x0000194C
		public int SelectionLength
		{
			get
			{
				if (this._endIndex < this._startIndex)
				{
					return this._startIndex - this._endIndex;
				}
				return this._endIndex - this._startIndex;
			}
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x060002CA RID: 714 RVA: 0x00003777 File Offset: 0x00001977
		public bool Focused
		{
			get
			{
				return this._isCaretActive;
			}
		}

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x060002CB RID: 715 RVA: 0x0000377F File Offset: 0x0000197F
		public int CurrentIndex
		{
			get
			{
				return this._endIndex;
			}
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x060002CC RID: 716 RVA: 0x00003787 File Offset: 0x00001987
		public Point Location
		{
			get
			{
				return this._location;
			}
		}

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x060002CD RID: 717 RVA: 0x00016AAC File Offset: 0x00014CAC
		// (remove) Token: 0x060002CE RID: 718 RVA: 0x00016AE4 File Offset: 0x00014CE4
		public event EventHandler SelectionStartChanged;

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x060002CF RID: 719 RVA: 0x00016B1C File Offset: 0x00014D1C
		// (remove) Token: 0x060002D0 RID: 720 RVA: 0x00016B54 File Offset: 0x00014D54
		public event EventHandler SelectionLengthChanged;

		// Token: 0x060002D1 RID: 721 RVA: 0x0000378F File Offset: 0x0000198F
		public Caret(HexEditor editor)
		{
			this._editor = editor;
			this._isCaretActive = false;
			this._startIndex = 0;
			this._endIndex = 0;
			this._isCaretHidden = true;
			this._location = new Point(0, 0);
		}

		// Token: 0x060002D2 RID: 722 RVA: 0x00016B8C File Offset: 0x00014D8C
		private bool Create(IntPtr hWHandler)
		{
			if (!this._isCaretActive)
			{
				this._isCaretActive = true;
				return Caret.CreateCaret(hWHandler, IntPtr.Zero, 0, (int)this._editor.CharSize.Height - 2);
			}
			return false;
		}

		// Token: 0x060002D3 RID: 723 RVA: 0x000037C7 File Offset: 0x000019C7
		private bool Show(IntPtr hWnd)
		{
			if (this._isCaretActive)
			{
				this._isCaretHidden = false;
				return Caret.ShowCaret(hWnd);
			}
			return false;
		}

		// Token: 0x060002D4 RID: 724 RVA: 0x000037E0 File Offset: 0x000019E0
		public bool Hide(IntPtr hWnd)
		{
			if (this._isCaretActive && !this._isCaretHidden)
			{
				this._isCaretHidden = true;
				return Caret.HideCaret(hWnd);
			}
			return false;
		}

		// Token: 0x060002D5 RID: 725 RVA: 0x00003801 File Offset: 0x00001A01
		public bool Destroy()
		{
			if (this._isCaretActive)
			{
				this._isCaretActive = false;
				this.DeSelect();
				Caret.DestroyCaret();
			}
			return false;
		}

		// Token: 0x060002D6 RID: 726 RVA: 0x00016BCC File Offset: 0x00014DCC
		public void SetStartIndex(int index)
		{
			this._startIndex = index;
			this._endIndex = this._startIndex;
			if (this.SelectionStartChanged != null)
			{
				this.SelectionStartChanged(this, EventArgs.Empty);
			}
			if (this.SelectionLengthChanged != null)
			{
				this.SelectionLengthChanged(this, EventArgs.Empty);
			}
		}

		// Token: 0x060002D7 RID: 727 RVA: 0x0000381F File Offset: 0x00001A1F
		public void SetEndIndex(int index)
		{
			this._endIndex = index;
			if (this.SelectionStartChanged != null)
			{
				this.SelectionStartChanged(this, EventArgs.Empty);
			}
			if (this.SelectionLengthChanged != null)
			{
				this.SelectionLengthChanged(this, EventArgs.Empty);
			}
		}

		// Token: 0x060002D8 RID: 728 RVA: 0x00016C20 File Offset: 0x00014E20
		public void SetCaretLocation(Point start)
		{
			this.Create(this._editor.Handle);
			this._location = start;
			Caret.SetCaretPos(this._location.X, this._location.Y);
			this.Show(this._editor.Handle);
		}

		// Token: 0x060002D9 RID: 729 RVA: 0x0000385A File Offset: 0x00001A5A
		public bool IsSelected(int byteIndex)
		{
			return this.SelectionStart <= byteIndex && byteIndex < this.SelectionStart + this.SelectionLength;
		}

		// Token: 0x060002DA RID: 730 RVA: 0x00016C74 File Offset: 0x00014E74
		private void DeSelect()
		{
			if (this._endIndex < this._startIndex)
			{
				this._startIndex = this._endIndex;
			}
			else
			{
				this._endIndex = this._startIndex;
			}
			if (this.SelectionStartChanged != null)
			{
				this.SelectionStartChanged(this, EventArgs.Empty);
			}
			if (this.SelectionLengthChanged != null)
			{
				this.SelectionLengthChanged(this, EventArgs.Empty);
			}
		}

		// Token: 0x060002DB RID: 731
		[DllImport("user32.dll", SetLastError = true)]
		private static extern bool CreateCaret(IntPtr hWnd, IntPtr hBitmap, int nWidth, int nHeight);

		// Token: 0x060002DC RID: 732
		[DllImport("user32.dll", SetLastError = true)]
		private static extern bool DestroyCaret();

		// Token: 0x060002DD RID: 733
		[DllImport("user32.dll", SetLastError = true)]
		private static extern bool SetCaretPos(int x, int y);

		// Token: 0x060002DE RID: 734
		[DllImport("user32.dll", SetLastError = true)]
		private static extern bool ShowCaret(IntPtr hWnd);

		// Token: 0x060002DF RID: 735
		[DllImport("user32.dll", SetLastError = true)]
		private static extern bool HideCaret(IntPtr hWnd);

		// Token: 0x040001E2 RID: 482
		private int _startIndex;

		// Token: 0x040001E3 RID: 483
		private int _endIndex;

		// Token: 0x040001E4 RID: 484
		private bool _isCaretActive;

		// Token: 0x040001E5 RID: 485
		private bool _isCaretHidden;

		// Token: 0x040001E6 RID: 486
		private Point _location;

		// Token: 0x040001E7 RID: 487
		private HexEditor _editor;
	}
}
