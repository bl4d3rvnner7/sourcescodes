﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Server.Helper.HexEditor
{
	// Token: 0x02000055 RID: 85
	public class EditView : IKeyMouseEventHandler
	{
		// Token: 0x060002E0 RID: 736 RVA: 0x00003877 File Offset: 0x00001A77
		public EditView(HexEditor editor)
		{
			this._editor = editor;
			this._hexView = new HexViewHandler(editor);
			this._stringView = new StringViewHandler(editor);
		}

		// Token: 0x060002E1 RID: 737 RVA: 0x0000389E File Offset: 0x00001A9E
		public void OnKeyPress(KeyPressEventArgs e)
		{
			if (this.InHexView(this._editor.CaretPosX))
			{
				this._hexView.OnKeyPress(e);
				return;
			}
			this._stringView.OnKeyPress(e);
		}

		// Token: 0x060002E2 RID: 738 RVA: 0x000038CC File Offset: 0x00001ACC
		public void OnKeyDown(KeyEventArgs e)
		{
			if (this.InHexView(this._editor.CaretPosX))
			{
				this._hexView.OnKeyDown(e);
				return;
			}
			this._stringView.OnKeyDown(e);
		}

		// Token: 0x060002E3 RID: 739 RVA: 0x00002239 File Offset: 0x00000439
		public void OnKeyUp(KeyEventArgs e)
		{
		}

		// Token: 0x060002E4 RID: 740 RVA: 0x00016CDC File Offset: 0x00014EDC
		public void OnMouseDown(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				if (this.InHexView(e.X))
				{
					this._hexView.OnMouseDown(e.X, e.Y);
					return;
				}
				this._stringView.OnMouseDown(e.X, e.Y);
			}
		}

		// Token: 0x060002E5 RID: 741 RVA: 0x00016D34 File Offset: 0x00014F34
		public void OnMouseDragged(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				if (this.InHexView(e.X))
				{
					this._hexView.OnMouseDragged(e.X, e.Y);
					return;
				}
				this._stringView.OnMouseDragged(e.X, e.Y);
			}
		}

		// Token: 0x060002E6 RID: 742 RVA: 0x00002239 File Offset: 0x00000439
		public void OnMouseUp(MouseEventArgs e)
		{
		}

		// Token: 0x060002E7 RID: 743 RVA: 0x000038FA File Offset: 0x00001AFA
		public void OnMouseDoubleClick(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				if (this.InHexView(e.X))
				{
					this._hexView.OnMouseDoubleClick();
					return;
				}
				this._stringView.OnMouseDoubleClick();
			}
		}

		// Token: 0x060002E8 RID: 744 RVA: 0x0000392E File Offset: 0x00001B2E
		public void OnGotFocus(EventArgs e)
		{
			if (this.InHexView(this._editor.CaretPosX))
			{
				this._hexView.Focus();
				return;
			}
			this._stringView.Focus();
		}

		// Token: 0x060002E9 RID: 745 RVA: 0x0000395A File Offset: 0x00001B5A
		public void SetLowerCase()
		{
			this._hexView.SetLowerCase();
		}

		// Token: 0x060002EA RID: 746 RVA: 0x00003967 File Offset: 0x00001B67
		public void SetUpperCase()
		{
			this._hexView.SetUpperCase();
		}

		// Token: 0x060002EB RID: 747 RVA: 0x00003974 File Offset: 0x00001B74
		public void Update(int startPositionX, Rectangle area)
		{
			this._hexView.Update(startPositionX, area);
			this._stringView.Update(this._hexView.MaxWidth, area);
		}

		// Token: 0x060002EC RID: 748 RVA: 0x00016D8C File Offset: 0x00014F8C
		public void Paint(Graphics g, int startIndex, int endIndex)
		{
			int num = 0;
			while (num + startIndex < endIndex)
			{
				this._hexView.Paint(g, num, startIndex);
				this._stringView.Paint(g, num, startIndex);
				num++;
			}
		}

		// Token: 0x060002ED RID: 749 RVA: 0x0000399A File Offset: 0x00001B9A
		private bool InHexView(int x)
		{
			return x < this._hexView.MaxWidth + this._editor.EntityMargin - 2;
		}

		// Token: 0x040001EA RID: 490
		private HexViewHandler _hexView;

		// Token: 0x040001EB RID: 491
		private StringViewHandler _stringView;

		// Token: 0x040001EC RID: 492
		private HexEditor _editor;
	}
}
