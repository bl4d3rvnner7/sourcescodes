﻿using System;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server.Helper
{
	// Token: 0x02000042 RID: 66
	public static class Methods
	{
		// Token: 0x0600025D RID: 605 RVA: 0x00015C30 File Offset: 0x00013E30
		public static string BytesToString(long byteCount)
		{
			string[] array = new string[]
			{
				"B",
				"KB",
				"MB",
				"GB",
				"TB",
				"PB",
				"EB"
			};
			if (byteCount == 0L)
			{
				return "0" + array[0];
			}
			long num = Math.Abs(byteCount);
			int num2 = Convert.ToInt32(Math.Floor(Math.Log((double)num, 1024.0)));
			double num3 = Math.Round((double)num / Math.Pow(1024.0, (double)num2), 1);
			return ((double)Math.Sign(byteCount) * num3).ToString() + array[num2];
		}

		// Token: 0x0600025E RID: 606 RVA: 0x00015CE0 File Offset: 0x00013EE0
		public static Task FadeIn(Form o, int interval = 80)
		{
			Methods.<FadeIn>d__2 <FadeIn>d__;
			<FadeIn>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<FadeIn>d__.o = o;
			<FadeIn>d__.interval = interval;
			<FadeIn>d__.<>1__state = -1;
			<FadeIn>d__.<>t__builder.Start<Methods.<FadeIn>d__2>(ref <FadeIn>d__);
			return <FadeIn>d__.<>t__builder.Task;
		}

		// Token: 0x0600025F RID: 607 RVA: 0x00015D2C File Offset: 0x00013F2C
		public static double DiffSeconds(DateTime startTime, DateTime endTime)
		{
			TimeSpan timeSpan = new TimeSpan(endTime.Ticks - startTime.Ticks);
			return Math.Abs(timeSpan.TotalSeconds);
		}

		// Token: 0x06000260 RID: 608 RVA: 0x00015D5C File Offset: 0x00013F5C
		public static string GetRandomString(int length)
		{
			StringBuilder stringBuilder = new StringBuilder(length);
			for (int i = 0; i < length; i++)
			{
				stringBuilder.Append("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"[Methods.Random.Next("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".Length)]);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06000261 RID: 609 RVA: 0x00003309 File Offset: 0x00001509
		public static int MakeWin32Long(short wLow, short wHigh)
		{
			return (int)wLow << 16 | (int)wHigh;
		}

		// Token: 0x06000262 RID: 610 RVA: 0x00015DA8 File Offset: 0x00013FA8
		public static void SetItemState(IntPtr handle, int itemIndex, int mask, int value)
		{
			NativeMethods.LVITEM lvitem = new NativeMethods.LVITEM
			{
				stateMask = mask,
				state = value
			};
			NativeMethods.SendMessageListViewItem(handle, 4139U, new IntPtr(itemIndex), ref lvitem);
		}

		// Token: 0x06000263 RID: 611 RVA: 0x00003322 File Offset: 0x00001522
		public static void ScrollToBottom(IntPtr handle)
		{
			NativeMethods.SendMessage(handle, 277U, Methods.SB_PAGEBOTTOM, IntPtr.Zero);
		}

		// Token: 0x040001B2 RID: 434
		private const string Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

		// Token: 0x040001B3 RID: 435
		public static Random Random = new Random();

		// Token: 0x040001B4 RID: 436
		private const int LVM_FIRST = 4096;

		// Token: 0x040001B5 RID: 437
		private const int LVM_SETITEMSTATE = 4139;

		// Token: 0x040001B6 RID: 438
		private const int WM_VSCROLL = 277;

		// Token: 0x040001B7 RID: 439
		private static readonly IntPtr SB_PAGEBOTTOM = new IntPtr(7);
	}
}
