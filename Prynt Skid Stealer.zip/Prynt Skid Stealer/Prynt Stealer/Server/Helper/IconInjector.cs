﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Security;

namespace Server.Helper
{
	// Token: 0x02000038 RID: 56
	public static class IconInjector
	{
		// Token: 0x06000245 RID: 581 RVA: 0x0000327F File Offset: 0x0000147F
		public static void InjectIcon(string exeFileName, string iconFileName)
		{
			IconInjector.InjectIcon(exeFileName, iconFileName, 1U, 1U);
		}

		// Token: 0x06000246 RID: 582 RVA: 0x0001572C File Offset: 0x0001392C
		public static void InjectIcon(string exeFileName, string iconFileName, uint iconGroupID, uint iconBaseID)
		{
			IconInjector.IconFile iconFile = IconInjector.IconFile.FromFile(iconFileName);
			IntPtr hUpdate = IconInjector.NativeMethods.BeginUpdateResource(exeFileName, false);
			byte[] array = iconFile.CreateIconGroupData(iconBaseID);
			IconInjector.NativeMethods.UpdateResource(hUpdate, new IntPtr(14L), new IntPtr((long)((ulong)iconGroupID)), 0, array, array.Length);
			for (int i = 0; i <= iconFile.ImageCount - 1; i++)
			{
				byte[] array2 = iconFile.ImageData(i);
				IconInjector.NativeMethods.UpdateResource(hUpdate, new IntPtr(3L), new IntPtr((long)((ulong)iconBaseID + (ulong)((long)i))), 0, array2, array2.Length);
			}
			IconInjector.NativeMethods.EndUpdateResource(hUpdate, false);
		}

		// Token: 0x02000039 RID: 57
		[SuppressUnmanagedCodeSecurity]
		private class NativeMethods
		{
			// Token: 0x06000247 RID: 583
			[DllImport("kernel32")]
			public static extern IntPtr BeginUpdateResource(string fileName, [MarshalAs(UnmanagedType.Bool)] bool deleteExistingResources);

			// Token: 0x06000248 RID: 584
			[DllImport("kernel32")]
			[return: MarshalAs(UnmanagedType.Bool)]
			public static extern bool UpdateResource(IntPtr hUpdate, IntPtr type, IntPtr name, short language, [MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 5)] byte[] data, int dataSize);

			// Token: 0x06000249 RID: 585
			[DllImport("kernel32")]
			[return: MarshalAs(UnmanagedType.Bool)]
			public static extern bool EndUpdateResource(IntPtr hUpdate, [MarshalAs(UnmanagedType.Bool)] bool discard);
		}

		// Token: 0x0200003A RID: 58
		private struct ICONDIR
		{
			// Token: 0x04000189 RID: 393
			public ushort Reserved;

			// Token: 0x0400018A RID: 394
			public ushort Type;

			// Token: 0x0400018B RID: 395
			public ushort Count;
		}

		// Token: 0x0200003B RID: 59
		private struct ICONDIRENTRY
		{
			// Token: 0x0400018C RID: 396
			public byte Width;

			// Token: 0x0400018D RID: 397
			public byte Height;

			// Token: 0x0400018E RID: 398
			public byte ColorCount;

			// Token: 0x0400018F RID: 399
			public byte Reserved;

			// Token: 0x04000190 RID: 400
			public ushort Planes;

			// Token: 0x04000191 RID: 401
			public ushort BitCount;

			// Token: 0x04000192 RID: 402
			public int BytesInRes;

			// Token: 0x04000193 RID: 403
			public int ImageOffset;
		}

		// Token: 0x0200003C RID: 60
		private struct BITMAPINFOHEADER
		{
			// Token: 0x04000194 RID: 404
			public uint Size;

			// Token: 0x04000195 RID: 405
			public int Width;

			// Token: 0x04000196 RID: 406
			public int Height;

			// Token: 0x04000197 RID: 407
			public ushort Planes;

			// Token: 0x04000198 RID: 408
			public ushort BitCount;

			// Token: 0x04000199 RID: 409
			public uint Compression;

			// Token: 0x0400019A RID: 410
			public uint SizeImage;

			// Token: 0x0400019B RID: 411
			public int XPelsPerMeter;

			// Token: 0x0400019C RID: 412
			public int YPelsPerMeter;

			// Token: 0x0400019D RID: 413
			public uint ClrUsed;

			// Token: 0x0400019E RID: 414
			public uint ClrImportant;
		}

		// Token: 0x0200003D RID: 61
		[StructLayout(LayoutKind.Sequential, Pack = 2)]
		private struct GRPICONDIRENTRY
		{
			// Token: 0x0400019F RID: 415
			public byte Width;

			// Token: 0x040001A0 RID: 416
			public byte Height;

			// Token: 0x040001A1 RID: 417
			public byte ColorCount;

			// Token: 0x040001A2 RID: 418
			public byte Reserved;

			// Token: 0x040001A3 RID: 419
			public ushort Planes;

			// Token: 0x040001A4 RID: 420
			public ushort BitCount;

			// Token: 0x040001A5 RID: 421
			public int BytesInRes;

			// Token: 0x040001A6 RID: 422
			public ushort ID;
		}

		// Token: 0x0200003E RID: 62
		private class IconFile
		{
			// Token: 0x1700008A RID: 138
			// (get) Token: 0x0600024B RID: 587 RVA: 0x0000328A File Offset: 0x0000148A
			public int ImageCount
			{
				get
				{
					return (int)this.iconDir.Count;
				}
			}

			// Token: 0x0600024C RID: 588 RVA: 0x00003297 File Offset: 0x00001497
			public byte[] ImageData(int index)
			{
				return this.iconImage[index];
			}

			// Token: 0x0600024D RID: 589 RVA: 0x000157B0 File Offset: 0x000139B0
			public static IconInjector.IconFile FromFile(string filename)
			{
				IconInjector.IconFile iconFile = new IconInjector.IconFile();
				byte[] array = File.ReadAllBytes(filename);
				GCHandle gchandle = GCHandle.Alloc(array, GCHandleType.Pinned);
				iconFile.iconDir = (IconInjector.ICONDIR)Marshal.PtrToStructure(gchandle.AddrOfPinnedObject(), typeof(IconInjector.ICONDIR));
				iconFile.iconEntry = new IconInjector.ICONDIRENTRY[(int)iconFile.iconDir.Count];
				iconFile.iconImage = new byte[(int)iconFile.iconDir.Count][];
				int num = Marshal.SizeOf<IconInjector.ICONDIR>(iconFile.iconDir);
				Type typeFromHandle = typeof(IconInjector.ICONDIRENTRY);
				int num2 = Marshal.SizeOf(typeFromHandle);
				for (int i = 0; i <= (int)(iconFile.iconDir.Count - 1); i++)
				{
					IconInjector.ICONDIRENTRY icondirentry = (IconInjector.ICONDIRENTRY)Marshal.PtrToStructure(new IntPtr(gchandle.AddrOfPinnedObject().ToInt64() + (long)num), typeFromHandle);
					iconFile.iconEntry[i] = icondirentry;
					iconFile.iconImage[i] = new byte[icondirentry.BytesInRes];
					Buffer.BlockCopy(array, icondirentry.ImageOffset, iconFile.iconImage[i], 0, icondirentry.BytesInRes);
					num += num2;
				}
				gchandle.Free();
				return iconFile;
			}

			// Token: 0x0600024E RID: 590 RVA: 0x000158D4 File Offset: 0x00013AD4
			public byte[] CreateIconGroupData(uint iconBaseID)
			{
				byte[] array = new byte[Marshal.SizeOf(typeof(IconInjector.ICONDIR)) + Marshal.SizeOf(typeof(IconInjector.GRPICONDIRENTRY)) * this.ImageCount];
				GCHandle gchandle = GCHandle.Alloc(array, GCHandleType.Pinned);
				Marshal.StructureToPtr<IconInjector.ICONDIR>(this.iconDir, gchandle.AddrOfPinnedObject(), false);
				int num = Marshal.SizeOf<IconInjector.ICONDIR>(this.iconDir);
				for (int i = 0; i <= this.ImageCount - 1; i++)
				{
					IconInjector.GRPICONDIRENTRY structure = default(IconInjector.GRPICONDIRENTRY);
					IconInjector.BITMAPINFOHEADER bitmapinfoheader = default(IconInjector.BITMAPINFOHEADER);
					GCHandle gchandle2 = GCHandle.Alloc(bitmapinfoheader, GCHandleType.Pinned);
					Marshal.Copy(this.ImageData(i), 0, gchandle2.AddrOfPinnedObject(), Marshal.SizeOf(typeof(IconInjector.BITMAPINFOHEADER)));
					gchandle2.Free();
					structure.Width = this.iconEntry[i].Width;
					structure.Height = this.iconEntry[i].Height;
					structure.ColorCount = this.iconEntry[i].ColorCount;
					structure.Reserved = this.iconEntry[i].Reserved;
					structure.Planes = bitmapinfoheader.Planes;
					structure.BitCount = bitmapinfoheader.BitCount;
					structure.BytesInRes = this.iconEntry[i].BytesInRes;
					structure.ID = Convert.ToUInt16((long)((ulong)iconBaseID + (ulong)((long)i)));
					Marshal.StructureToPtr<IconInjector.GRPICONDIRENTRY>(structure, new IntPtr(gchandle.AddrOfPinnedObject().ToInt64() + (long)num), false);
					num += Marshal.SizeOf(typeof(IconInjector.GRPICONDIRENTRY));
				}
				gchandle.Free();
				return array;
			}

			// Token: 0x040001A7 RID: 423
			private IconInjector.ICONDIR iconDir;

			// Token: 0x040001A8 RID: 424
			private IconInjector.ICONDIRENTRY[] iconEntry;

			// Token: 0x040001A9 RID: 425
			private byte[][] iconImage;
		}
	}
}
