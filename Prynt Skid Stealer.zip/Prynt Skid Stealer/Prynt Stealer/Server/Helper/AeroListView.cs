﻿using System;
using System.Windows.Forms;

namespace Server.Helper
{
	// Token: 0x02000041 RID: 65
	internal class AeroListView : ListView
	{
		// Token: 0x06000257 RID: 599 RVA: 0x00003309 File Offset: 0x00001509
		public static int MakeWin32Long(short wLow, short wHigh)
		{
			return (int)wLow << 16 | (int)wHigh;
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x06000258 RID: 600 RVA: 0x00003311 File Offset: 0x00001511
		// (set) Token: 0x06000259 RID: 601 RVA: 0x00003319 File Offset: 0x00001519
		private ListViewColumnSorter LvwColumnSorter { get; set; }

		// Token: 0x0600025A RID: 602 RVA: 0x00015AE4 File Offset: 0x00013CE4
		public AeroListView()
		{
			base.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.LvwColumnSorter = new ListViewColumnSorter();
			base.ListViewItemSorter = this.LvwColumnSorter;
			base.View = View.Details;
			base.FullRowSelect = true;
		}

		// Token: 0x0600025B RID: 603 RVA: 0x00015B3C File Offset: 0x00013D3C
		protected override void OnHandleCreated(EventArgs e)
		{
			base.OnHandleCreated(e);
			if (Environment.OSVersion.Platform == PlatformID.Win32NT && Environment.OSVersion.Version.Major >= 6)
			{
				NativeMethods.SetWindowTheme(base.Handle, "explorer", null);
			}
			if (Environment.OSVersion.Platform == PlatformID.Win32NT && Environment.OSVersion.Version.Major >= 5)
			{
				NativeMethods.SendMessage(base.Handle, 295U, this._removeDots, IntPtr.Zero);
			}
		}

		// Token: 0x0600025C RID: 604 RVA: 0x00015BBC File Offset: 0x00013DBC
		protected override void OnColumnClick(ColumnClickEventArgs e)
		{
			base.OnColumnClick(e);
			if (e.Column == this.LvwColumnSorter.SortColumn)
			{
				this.LvwColumnSorter.Order = ((this.LvwColumnSorter.Order == SortOrder.Ascending) ? SortOrder.Descending : SortOrder.Ascending);
			}
			else
			{
				this.LvwColumnSorter.SortColumn = e.Column;
				this.LvwColumnSorter.Order = SortOrder.Ascending;
			}
			if (!base.VirtualMode)
			{
				base.Sort();
			}
		}

		// Token: 0x040001AD RID: 429
		private const uint WM_CHANGEUISTATE = 295U;

		// Token: 0x040001AE RID: 430
		private const short UIS_SET = 1;

		// Token: 0x040001AF RID: 431
		private const short UISF_HIDEFOCUS = 1;

		// Token: 0x040001B0 RID: 432
		private readonly IntPtr _removeDots = new IntPtr(AeroListView.MakeWin32Long(1, 1));
	}
}
