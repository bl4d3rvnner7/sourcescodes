﻿using System;
using System.Windows.Forms;

namespace Server.Helper
{
	// Token: 0x0200004A RID: 74
	public class RegistryValueLstItem : ListViewItem
	{
		// Token: 0x1700008E RID: 142
		// (get) Token: 0x06000278 RID: 632 RVA: 0x000033B4 File Offset: 0x000015B4
		// (set) Token: 0x06000279 RID: 633 RVA: 0x000033BC File Offset: 0x000015BC
		private string _type { get; set; }

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x0600027A RID: 634 RVA: 0x000033C5 File Offset: 0x000015C5
		// (set) Token: 0x0600027B RID: 635 RVA: 0x000033CD File Offset: 0x000015CD
		private string _data { get; set; }

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x0600027C RID: 636 RVA: 0x000033D6 File Offset: 0x000015D6
		// (set) Token: 0x0600027D RID: 637 RVA: 0x000033DE File Offset: 0x000015DE
		public string RegName
		{
			get
			{
				return base.Name;
			}
			set
			{
				base.Name = value;
				base.Text = RegValueHelper.GetName(value);
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x0600027E RID: 638 RVA: 0x000033F3 File Offset: 0x000015F3
		// (set) Token: 0x0600027F RID: 639 RVA: 0x000160BC File Offset: 0x000142BC
		public string Type
		{
			get
			{
				return this._type;
			}
			set
			{
				this._type = value;
				if (base.SubItems.Count < 2)
				{
					base.SubItems.Add(this._type);
				}
				else
				{
					base.SubItems[1].Text = this._type;
				}
				base.ImageIndex = this.GetRegistryValueImgIndex(this._type);
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06000280 RID: 640 RVA: 0x000033FB File Offset: 0x000015FB
		// (set) Token: 0x06000281 RID: 641 RVA: 0x0001611C File Offset: 0x0001431C
		public string Data
		{
			get
			{
				return this._data;
			}
			set
			{
				this._data = value;
				if (base.SubItems.Count < 3)
				{
					base.SubItems.Add(this._data);
					return;
				}
				base.SubItems[2].Text = this._data;
			}
		}

		// Token: 0x06000282 RID: 642 RVA: 0x00003403 File Offset: 0x00001603
		public RegistryValueLstItem(RegistrySeeker.RegValueData value)
		{
			this.RegName = value.Name;
			this.Type = value.Kind.RegistryTypeToString();
			this.Data = RegValueHelper.RegistryValueToString(value);
		}

		// Token: 0x06000283 RID: 643 RVA: 0x00016168 File Offset: 0x00014368
		private int GetRegistryValueImgIndex(string type)
		{
			if (!(type == "REG_MULTI_SZ") && !(type == "REG_SZ") && !(type == "REG_EXPAND_SZ"))
			{
				if (!(type == "REG_BINARY") && !(type == "REG_DWORD") && !(type == "REG_QWORD"))
				{
				}
				return 1;
			}
			return 0;
		}
	}
}
