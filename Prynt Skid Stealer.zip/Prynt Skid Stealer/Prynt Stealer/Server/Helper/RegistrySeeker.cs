﻿using System;
using System.Collections.Generic;
using Microsoft.Win32;
using ProtoBuf;

namespace Server.Helper
{
	// Token: 0x02000050 RID: 80
	public class RegistrySeeker
	{
		// Token: 0x17000098 RID: 152
		// (get) Token: 0x060002A4 RID: 676 RVA: 0x000035D1 File Offset: 0x000017D1
		public RegistrySeeker.RegSeekerMatch[] Matches
		{
			get
			{
				List<RegistrySeeker.RegSeekerMatch> matches = this._matches;
				if (matches == null)
				{
					return null;
				}
				return matches.ToArray();
			}
		}

		// Token: 0x060002A5 RID: 677 RVA: 0x000035E4 File Offset: 0x000017E4
		public RegistrySeeker()
		{
			this._matches = new List<RegistrySeeker.RegSeekerMatch>();
		}

		// Token: 0x060002A6 RID: 678 RVA: 0x0001672C File Offset: 0x0001492C
		public void BeginSeeking(string rootKeyName)
		{
			if (!string.IsNullOrEmpty(rootKeyName))
			{
				using (RegistryKey rootKey = RegistrySeeker.GetRootKey(rootKeyName))
				{
					if (rootKey != null && rootKey.Name != rootKeyName)
					{
						string name = rootKeyName.Substring(rootKey.Name.Length + 1);
						using (RegistryKey registryKey = rootKey.OpenReadonlySubKeySafe(name))
						{
							if (registryKey != null)
							{
								this.Seek(registryKey);
							}
							return;
						}
					}
					this.Seek(rootKey);
					return;
				}
			}
			this.Seek(null);
		}

		// Token: 0x060002A7 RID: 679 RVA: 0x000167C4 File Offset: 0x000149C4
		private void Seek(RegistryKey rootKey)
		{
			if (rootKey == null)
			{
				using (List<RegistryKey>.Enumerator enumerator = RegistrySeeker.GetRootKeys().GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						RegistryKey registryKey = enumerator.Current;
						this.ProcessKey(registryKey, registryKey.Name);
					}
					return;
				}
			}
			this.Search(rootKey);
		}

		// Token: 0x060002A8 RID: 680 RVA: 0x00016828 File Offset: 0x00014A28
		private void Search(RegistryKey rootKey)
		{
			foreach (string text in rootKey.GetSubKeyNames())
			{
				RegistryKey key = rootKey.OpenReadonlySubKeySafe(text);
				this.ProcessKey(key, text);
			}
		}

		// Token: 0x060002A9 RID: 681 RVA: 0x00016860 File Offset: 0x00014A60
		private void ProcessKey(RegistryKey key, string keyName)
		{
			if (key != null)
			{
				List<RegistrySeeker.RegValueData> list = new List<RegistrySeeker.RegValueData>();
				foreach (string name in key.GetValueNames())
				{
					RegistryValueKind valueKind = key.GetValueKind(name);
					object value = key.GetValue(name);
					list.Add(RegistryKeyHelper.CreateRegValueData(name, valueKind, value));
				}
				this.AddMatch(keyName, RegistryKeyHelper.AddDefaultValue(list), key.SubKeyCount);
				return;
			}
			this.AddMatch(keyName, RegistryKeyHelper.GetDefaultValues(), 0);
		}

		// Token: 0x060002AA RID: 682 RVA: 0x000168D4 File Offset: 0x00014AD4
		private void AddMatch(string key, RegistrySeeker.RegValueData[] values, int subkeycount)
		{
			RegistrySeeker.RegSeekerMatch item = new RegistrySeeker.RegSeekerMatch
			{
				Key = key,
				Data = values,
				HasSubKeys = (subkeycount > 0)
			};
			this._matches.Add(item);
		}

		// Token: 0x060002AB RID: 683 RVA: 0x0001690C File Offset: 0x00014B0C
		public static RegistryKey GetRootKey(string subkeyFullPath)
		{
			string[] array = subkeyFullPath.Split(new char[]
			{
				'\\'
			});
			RegistryKey result;
			try
			{
				string a = array[0];
				if (!(a == "HKEY_CLASSES_ROOT"))
				{
					if (!(a == "HKEY_CURRENT_USER"))
					{
						if (!(a == "HKEY_LOCAL_MACHINE"))
						{
							if (!(a == "HKEY_USERS"))
							{
								if (!(a == "HKEY_CURRENT_CONFIG"))
								{
									throw new Exception("Invalid rootkey, could not be found.");
								}
								result = RegistryKey.OpenBaseKey(RegistryHive.CurrentConfig, RegistryView.Registry64);
							}
							else
							{
								result = RegistryKey.OpenBaseKey(RegistryHive.Users, RegistryView.Registry64);
							}
						}
						else
						{
							result = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
						}
					}
					else
					{
						result = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64);
					}
				}
				else
				{
					result = RegistryKey.OpenBaseKey(RegistryHive.ClassesRoot, RegistryView.Registry64);
				}
			}
			catch (SystemException)
			{
				throw new Exception("Unable to open root registry key, you do not have the needed permissions.");
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return result;
		}

		// Token: 0x060002AC RID: 684 RVA: 0x00016A04 File Offset: 0x00014C04
		public static List<RegistryKey> GetRootKeys()
		{
			List<RegistryKey> list = new List<RegistryKey>();
			try
			{
				list.Add(RegistryKey.OpenBaseKey(RegistryHive.ClassesRoot, RegistryView.Registry64));
				list.Add(RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64));
				list.Add(RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64));
				list.Add(RegistryKey.OpenBaseKey(RegistryHive.Users, RegistryView.Registry64));
				list.Add(RegistryKey.OpenBaseKey(RegistryHive.CurrentConfig, RegistryView.Registry64));
			}
			catch (SystemException)
			{
				throw new Exception("Could not open root registry keys, you may not have the needed permission");
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return list;
		}

		// Token: 0x040001DA RID: 474
		private readonly List<RegistrySeeker.RegSeekerMatch> _matches;

		// Token: 0x02000051 RID: 81
		[ProtoContract]
		public class RegSeekerMatch
		{
			// Token: 0x17000099 RID: 153
			// (get) Token: 0x060002AD RID: 685 RVA: 0x000035F7 File Offset: 0x000017F7
			// (set) Token: 0x060002AE RID: 686 RVA: 0x000035FF File Offset: 0x000017FF
			[ProtoMember(1)]
			public string Key { get; set; }

			// Token: 0x1700009A RID: 154
			// (get) Token: 0x060002AF RID: 687 RVA: 0x00003608 File Offset: 0x00001808
			// (set) Token: 0x060002B0 RID: 688 RVA: 0x00003610 File Offset: 0x00001810
			[ProtoMember(2)]
			public RegistrySeeker.RegValueData[] Data { get; set; }

			// Token: 0x1700009B RID: 155
			// (get) Token: 0x060002B1 RID: 689 RVA: 0x00003619 File Offset: 0x00001819
			// (set) Token: 0x060002B2 RID: 690 RVA: 0x00003621 File Offset: 0x00001821
			[ProtoMember(3)]
			public bool HasSubKeys { get; set; }

			// Token: 0x060002B3 RID: 691 RVA: 0x0000362A File Offset: 0x0000182A
			public override string ToString()
			{
				return string.Format("({0}:{1})", this.Key, this.Data);
			}
		}

		// Token: 0x02000052 RID: 82
		[ProtoContract]
		public class RegValueData
		{
			// Token: 0x1700009C RID: 156
			// (get) Token: 0x060002B5 RID: 693 RVA: 0x00003642 File Offset: 0x00001842
			// (set) Token: 0x060002B6 RID: 694 RVA: 0x0000364A File Offset: 0x0000184A
			[ProtoMember(1)]
			public string Name { get; set; }

			// Token: 0x1700009D RID: 157
			// (get) Token: 0x060002B7 RID: 695 RVA: 0x00003653 File Offset: 0x00001853
			// (set) Token: 0x060002B8 RID: 696 RVA: 0x0000365B File Offset: 0x0000185B
			[ProtoMember(2)]
			public RegistryValueKind Kind { get; set; }

			// Token: 0x1700009E RID: 158
			// (get) Token: 0x060002B9 RID: 697 RVA: 0x00003664 File Offset: 0x00001864
			// (set) Token: 0x060002BA RID: 698 RVA: 0x0000366C File Offset: 0x0000186C
			[ProtoMember(3)]
			public byte[] Data { get; set; }
		}
	}
}
