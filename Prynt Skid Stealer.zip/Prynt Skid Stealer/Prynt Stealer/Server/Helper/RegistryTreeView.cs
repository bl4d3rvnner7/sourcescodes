﻿using System;
using System.Windows.Forms;

namespace Server.Helper
{
	// Token: 0x02000049 RID: 73
	public class RegistryTreeView : TreeView
	{
		// Token: 0x06000277 RID: 631 RVA: 0x000033A0 File Offset: 0x000015A0
		public RegistryTreeView()
		{
			base.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		}
	}
}
