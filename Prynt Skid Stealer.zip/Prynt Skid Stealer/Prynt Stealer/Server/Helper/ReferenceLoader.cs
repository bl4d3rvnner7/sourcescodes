﻿using System;
using System.Globalization;
using System.Linq;
using System.Reflection;

namespace Server.Helper
{
	// Token: 0x02000046 RID: 70
	public class ReferenceLoader : MarshalByRefObject
	{
		// Token: 0x0600026C RID: 620 RVA: 0x00015ED0 File Offset: 0x000140D0
		public string[] LoadReferences(string assemblyPath)
		{
			string[] result;
			try
			{
				result = (from x in Assembly.ReflectionOnlyLoadFrom(assemblyPath).GetReferencedAssemblies()
				select x.FullName).ToArray<string>();
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x0600026D RID: 621 RVA: 0x00015F2C File Offset: 0x0001412C
		public void AppDomainSetup(string assemblyPath)
		{
			try
			{
				AppDomainSetup info = new AppDomainSetup
				{
					ApplicationBase = AppDomain.CurrentDomain.BaseDirectory
				};
				AppDomain domain = AppDomain.CreateDomain(Guid.NewGuid().ToString(), null, info);
				((ReferenceLoader)Activator.CreateInstance(domain, typeof(ReferenceLoader).Assembly.FullName, typeof(ReferenceLoader).FullName, false, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, null, CultureInfo.CurrentCulture, new object[0]).Unwrap()).LoadReferences(assemblyPath);
				AppDomain.Unload(domain);
			}
			catch
			{
			}
		}
	}
}
