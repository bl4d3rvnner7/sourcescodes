﻿using System;
using System.Collections;
using System.Windows.Forms;

namespace Server.Helper
{
	// Token: 0x0200003F RID: 63
	public class ListViewColumnSorter : IComparer
	{
		// Token: 0x06000250 RID: 592 RVA: 0x000032A1 File Offset: 0x000014A1
		public ListViewColumnSorter()
		{
			this.ColumnToSort = 0;
			this.OrderOfSort = SortOrder.None;
			this.ObjectCompare = new CaseInsensitiveComparer();
		}

		// Token: 0x06000251 RID: 593 RVA: 0x00015A78 File Offset: 0x00013C78
		public int Compare(object x, object y)
		{
			ListViewItem listViewItem = (ListViewItem)x;
			ListViewItem listViewItem2 = (ListViewItem)y;
			int num = this.ObjectCompare.Compare(listViewItem.SubItems[this.ColumnToSort].Text, listViewItem2.SubItems[this.ColumnToSort].Text);
			if (this.OrderOfSort == SortOrder.Ascending)
			{
				return num;
			}
			if (this.OrderOfSort == SortOrder.Descending)
			{
				return -num;
			}
			return 0;
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06000253 RID: 595 RVA: 0x000032CB File Offset: 0x000014CB
		// (set) Token: 0x06000252 RID: 594 RVA: 0x000032C2 File Offset: 0x000014C2
		public int SortColumn
		{
			get
			{
				return this.ColumnToSort;
			}
			set
			{
				this.ColumnToSort = value;
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06000255 RID: 597 RVA: 0x000032DC File Offset: 0x000014DC
		// (set) Token: 0x06000254 RID: 596 RVA: 0x000032D3 File Offset: 0x000014D3
		public SortOrder Order
		{
			get
			{
				return this.OrderOfSort;
			}
			set
			{
				this.OrderOfSort = value;
			}
		}

		// Token: 0x040001AA RID: 426
		private int ColumnToSort;

		// Token: 0x040001AB RID: 427
		private SortOrder OrderOfSort;

		// Token: 0x040001AC RID: 428
		private CaseInsensitiveComparer ObjectCompare;
	}
}
