﻿using System;
using System.Collections.Generic;

namespace Server.Helper
{
	// Token: 0x02000034 RID: 52
	public class AsyncTask
	{
		// Token: 0x0600022F RID: 559 RVA: 0x000031DB File Offset: 0x000013DB
		public AsyncTask(byte[] _msgPack, string _id, bool _admin)
		{
			this.msgPack = _msgPack;
			this.id = _id;
			this.admin = _admin;
			this.doneClient = new List<string>();
		}

		// Token: 0x04000184 RID: 388
		public byte[] msgPack;

		// Token: 0x04000185 RID: 389
		public string id;

		// Token: 0x04000186 RID: 390
		public bool admin;

		// Token: 0x04000187 RID: 391
		public List<string> doneClient;
	}
}
