﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Win32;

namespace Server.Helper
{
	// Token: 0x0200004E RID: 78
	public static class RegistryKeyHelper
	{
		// Token: 0x06000298 RID: 664 RVA: 0x00016538 File Offset: 0x00014738
		public static bool AddRegistryKeyValue(RegistryHive hive, string path, string name, string value, bool addQuotes = false)
		{
			bool result;
			try
			{
				using (RegistryKey registryKey = RegistryKey.OpenBaseKey(hive, RegistryView.Registry64).OpenWritableSubKeySafe(path))
				{
					if (registryKey == null)
					{
						result = false;
					}
					else
					{
						if (addQuotes && !value.StartsWith("\"") && !value.EndsWith("\""))
						{
							value = "\"" + value + "\"";
						}
						registryKey.SetValue(name, value);
						result = true;
					}
				}
			}
			catch (Exception)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000299 RID: 665 RVA: 0x000165C8 File Offset: 0x000147C8
		public static RegistryKey OpenReadonlySubKey(RegistryHive hive, string path)
		{
			RegistryKey result;
			try
			{
				result = RegistryKey.OpenBaseKey(hive, RegistryView.Registry64).OpenSubKey(path, false);
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x0600029A RID: 666 RVA: 0x00016600 File Offset: 0x00014800
		public static bool DeleteRegistryKeyValue(RegistryHive hive, string path, string name)
		{
			bool result;
			try
			{
				using (RegistryKey registryKey = RegistryKey.OpenBaseKey(hive, RegistryView.Registry64).OpenWritableSubKeySafe(path))
				{
					if (registryKey == null)
					{
						result = false;
					}
					else
					{
						registryKey.DeleteValue(name, true);
						result = true;
					}
				}
			}
			catch (Exception)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x0600029B RID: 667 RVA: 0x0000337B File Offset: 0x0000157B
		public static bool IsDefaultValue(string valueName)
		{
			return string.IsNullOrEmpty(valueName);
		}

		// Token: 0x0600029C RID: 668 RVA: 0x00003554 File Offset: 0x00001754
		public static RegistrySeeker.RegValueData[] AddDefaultValue(List<RegistrySeeker.RegValueData> values)
		{
			if (!values.Any((RegistrySeeker.RegValueData value) => RegistryKeyHelper.IsDefaultValue(value.Name)))
			{
				values.Add(RegistryKeyHelper.GetDefaultValue());
			}
			return values.ToArray();
		}

		// Token: 0x0600029D RID: 669 RVA: 0x0000358E File Offset: 0x0000178E
		public static RegistrySeeker.RegValueData[] GetDefaultValues()
		{
			return new RegistrySeeker.RegValueData[]
			{
				RegistryKeyHelper.GetDefaultValue()
			};
		}

		// Token: 0x0600029E RID: 670 RVA: 0x00016660 File Offset: 0x00014860
		public static RegistrySeeker.RegValueData CreateRegValueData(string name, RegistryValueKind kind, object value = null)
		{
			RegistrySeeker.RegValueData regValueData = new RegistrySeeker.RegValueData
			{
				Name = name,
				Kind = kind
			};
			if (value == null)
			{
				regValueData.Data = new byte[0];
			}
			else
			{
				switch (regValueData.Kind)
				{
				case RegistryValueKind.String:
				case RegistryValueKind.ExpandString:
					regValueData.Data = ByteConverter.GetBytes((string)value);
					break;
				case RegistryValueKind.Binary:
					regValueData.Data = (byte[])value;
					break;
				case RegistryValueKind.DWord:
					regValueData.Data = ByteConverter.GetBytes((uint)((int)value));
					break;
				case RegistryValueKind.MultiString:
					regValueData.Data = ByteConverter.GetBytes((string[])value);
					break;
				case RegistryValueKind.QWord:
					regValueData.Data = ByteConverter.GetBytes((ulong)((long)value));
					break;
				}
			}
			return regValueData;
		}

		// Token: 0x0600029F RID: 671 RVA: 0x0000359E File Offset: 0x0000179E
		private static RegistrySeeker.RegValueData GetDefaultValue()
		{
			return RegistryKeyHelper.CreateRegValueData(RegistryKeyHelper.DEFAULT_VALUE, RegistryValueKind.String, null);
		}

		// Token: 0x040001D7 RID: 471
		private static string DEFAULT_VALUE = string.Empty;
	}
}
