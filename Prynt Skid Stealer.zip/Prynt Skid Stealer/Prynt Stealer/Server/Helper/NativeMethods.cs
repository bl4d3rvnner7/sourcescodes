﻿using System;
using System.Runtime.InteropServices;

namespace Server.Helper
{
	// Token: 0x02000044 RID: 68
	public static class NativeMethods
	{
		// Token: 0x06000267 RID: 615
		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		internal static extern IntPtr SendMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

		// Token: 0x06000268 RID: 616
		[DllImport("user32.dll", CharSet = CharSet.Auto, EntryPoint = "SendMessage")]
		internal static extern IntPtr SendMessageListViewItem(IntPtr hWnd, uint msg, IntPtr wParam, ref NativeMethods.LVITEM lParam);

		// Token: 0x06000269 RID: 617
		[DllImport("user32.dll")]
		internal static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, int vk);

		// Token: 0x0600026A RID: 618
		[DllImport("user32.dll")]
		internal static extern bool UnregisterHotKey(IntPtr hWnd, int id);

		// Token: 0x0600026B RID: 619
		[DllImport("uxtheme.dll", CharSet = CharSet.Unicode)]
		internal static extern int SetWindowTheme(IntPtr hWnd, string pszSubAppName, string pszSubIdList);

		// Token: 0x02000045 RID: 69
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
		internal struct LVITEM
		{
			// Token: 0x040001BD RID: 445
			public uint mask;

			// Token: 0x040001BE RID: 446
			public int iItem;

			// Token: 0x040001BF RID: 447
			public int iSubItem;

			// Token: 0x040001C0 RID: 448
			public int state;

			// Token: 0x040001C1 RID: 449
			public int stateMask;

			// Token: 0x040001C2 RID: 450
			[MarshalAs(UnmanagedType.LPTStr)]
			public string pszText;

			// Token: 0x040001C3 RID: 451
			public int cchTextMax;

			// Token: 0x040001C4 RID: 452
			public int iImage;

			// Token: 0x040001C5 RID: 453
			public IntPtr lParam;

			// Token: 0x040001C6 RID: 454
			public int iIndent;

			// Token: 0x040001C7 RID: 455
			public int iGroupId;

			// Token: 0x040001C8 RID: 456
			public uint cColumns;

			// Token: 0x040001C9 RID: 457
			public IntPtr puColumns;

			// Token: 0x040001CA RID: 458
			public IntPtr piColFmt;

			// Token: 0x040001CB RID: 459
			public int iGroup;
		}
	}
}
