﻿using System;
using System.Reflection;
using System.Windows.Forms;

namespace Server.Helper
{
	// Token: 0x02000040 RID: 64
	public static class ListviewDoubleBuffer
	{
		// Token: 0x06000256 RID: 598 RVA: 0x000032E4 File Offset: 0x000014E4
		public static void Enable(ListView listView)
		{
			typeof(Control).GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(listView, true, null);
		}
	}
}
