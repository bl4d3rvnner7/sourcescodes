﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helper
{
	// Token: 0x02000035 RID: 53
	public class ByteConverter
	{
		// Token: 0x06000230 RID: 560 RVA: 0x00003203 File Offset: 0x00001403
		public static byte[] GetBytes(int value)
		{
			return BitConverter.GetBytes(value);
		}

		// Token: 0x06000231 RID: 561 RVA: 0x0000320B File Offset: 0x0000140B
		public static byte[] GetBytes(long value)
		{
			return BitConverter.GetBytes(value);
		}

		// Token: 0x06000232 RID: 562 RVA: 0x00003213 File Offset: 0x00001413
		public static byte[] GetBytes(uint value)
		{
			return BitConverter.GetBytes(value);
		}

		// Token: 0x06000233 RID: 563 RVA: 0x0000321B File Offset: 0x0000141B
		public static byte[] GetBytes(ulong value)
		{
			return BitConverter.GetBytes(value);
		}

		// Token: 0x06000234 RID: 564 RVA: 0x00003223 File Offset: 0x00001423
		public static byte[] GetBytes(string value)
		{
			return ByteConverter.StringToBytes(value);
		}

		// Token: 0x06000235 RID: 565 RVA: 0x0000322B File Offset: 0x0000142B
		public static byte[] GetBytes(string[] value)
		{
			return ByteConverter.StringArrayToBytes(value);
		}

		// Token: 0x06000236 RID: 566 RVA: 0x00003233 File Offset: 0x00001433
		public static int ToInt32(byte[] bytes)
		{
			return BitConverter.ToInt32(bytes, 0);
		}

		// Token: 0x06000237 RID: 567 RVA: 0x0000323C File Offset: 0x0000143C
		public static long ToInt64(byte[] bytes)
		{
			return BitConverter.ToInt64(bytes, 0);
		}

		// Token: 0x06000238 RID: 568 RVA: 0x00003245 File Offset: 0x00001445
		public static uint ToUInt32(byte[] bytes)
		{
			return BitConverter.ToUInt32(bytes, 0);
		}

		// Token: 0x06000239 RID: 569 RVA: 0x0000324E File Offset: 0x0000144E
		public static ulong ToUInt64(byte[] bytes)
		{
			return BitConverter.ToUInt64(bytes, 0);
		}

		// Token: 0x0600023A RID: 570 RVA: 0x00003257 File Offset: 0x00001457
		public static string ToString(byte[] bytes)
		{
			return ByteConverter.BytesToString(bytes);
		}

		// Token: 0x0600023B RID: 571 RVA: 0x0000325F File Offset: 0x0000145F
		public static string[] ToStringArray(byte[] bytes)
		{
			return ByteConverter.BytesToStringArray(bytes);
		}

		// Token: 0x0600023C RID: 572 RVA: 0x00003267 File Offset: 0x00001467
		private static byte[] GetNullBytes()
		{
			return new byte[]
			{
				ByteConverter.NULL_BYTE,
				ByteConverter.NULL_BYTE
			};
		}

		// Token: 0x0600023D RID: 573 RVA: 0x00015330 File Offset: 0x00013530
		private static byte[] StringToBytes(string value)
		{
			byte[] array = new byte[value.Length * 2];
			Buffer.BlockCopy(value.ToCharArray(), 0, array, 0, array.Length);
			return array;
		}

		// Token: 0x0600023E RID: 574 RVA: 0x00015360 File Offset: 0x00013560
		private static byte[] StringArrayToBytes(string[] strings)
		{
			List<byte> list = new List<byte>();
			foreach (string value in strings)
			{
				list.AddRange(ByteConverter.StringToBytes(value));
				list.AddRange(ByteConverter.GetNullBytes());
			}
			return list.ToArray();
		}

		// Token: 0x0600023F RID: 575 RVA: 0x000153A4 File Offset: 0x000135A4
		private static string BytesToString(byte[] bytes)
		{
			char[] array = new char[(int)Math.Ceiling((double)((float)bytes.Length / 2f))];
			Buffer.BlockCopy(bytes, 0, array, 0, bytes.Length);
			return new string(array);
		}

		// Token: 0x06000240 RID: 576 RVA: 0x000153DC File Offset: 0x000135DC
		private static string[] BytesToStringArray(byte[] bytes)
		{
			List<string> list = new List<string>();
			int i = 0;
			StringBuilder stringBuilder = new StringBuilder(bytes.Length);
			while (i < bytes.Length)
			{
				int num = 0;
				while (i < bytes.Length && num < 3)
				{
					if (bytes[i] == ByteConverter.NULL_BYTE)
					{
						num++;
					}
					else
					{
						stringBuilder.Append(Convert.ToChar(bytes[i]));
						num = 0;
					}
					i++;
				}
				list.Add(stringBuilder.ToString());
				stringBuilder.Clear();
			}
			return list.ToArray();
		}

		// Token: 0x04000188 RID: 392
		private static byte NULL_BYTE;
	}
}
