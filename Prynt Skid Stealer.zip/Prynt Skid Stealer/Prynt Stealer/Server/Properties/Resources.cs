﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Server.Properties
{
	// Token: 0x02000029 RID: 41
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	public class Resources
	{
		// Token: 0x06000191 RID: 401 RVA: 0x000021E7 File Offset: 0x000003E7
		internal Resources()
		{
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06000192 RID: 402 RVA: 0x00002865 File Offset: 0x00000A65
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static ResourceManager ResourceManager
		{
			get
			{
				if (Resources.resourceMan == null)
				{
					Resources.resourceMan = new ResourceManager("Server.Properties.Resources", typeof(Resources).Assembly);
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06000193 RID: 403 RVA: 0x00002891 File Offset: 0x00000A91
		// (set) Token: 0x06000194 RID: 404 RVA: 0x00002898 File Offset: 0x00000A98
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x06000195 RID: 405 RVA: 0x000028A0 File Offset: 0x00000AA0
		public static byte[] _7z
		{
			get
			{
				return (byte[])Resources.ResourceManager.GetObject("_7z", Resources.resourceCulture);
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x06000196 RID: 406 RVA: 0x000028BB File Offset: 0x00000ABB
		public static byte[] _7z1
		{
			get
			{
				return (byte[])Resources.ResourceManager.GetObject("_7z1", Resources.resourceCulture);
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x06000197 RID: 407 RVA: 0x000028D6 File Offset: 0x00000AD6
		public static PointF animation3_BlindCoeff
		{
			get
			{
				return (PointF)Resources.ResourceManager.GetObject("animation3.BlindCoeff", Resources.resourceCulture);
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x06000198 RID: 408 RVA: 0x000028F1 File Offset: 0x00000AF1
		public static PointF animation3_MosaicCoeff
		{
			get
			{
				return (PointF)Resources.ResourceManager.GetObject("animation3.MosaicCoeff", Resources.resourceCulture);
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06000199 RID: 409 RVA: 0x0000290C File Offset: 0x00000B0C
		public static PointF animation3_MosaicShift
		{
			get
			{
				return (PointF)Resources.ResourceManager.GetObject("animation3.MosaicShift", Resources.resourceCulture);
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x0600019A RID: 410 RVA: 0x00002927 File Offset: 0x00000B27
		public static PointF animation3_ScaleCoeff
		{
			get
			{
				return (PointF)Resources.ResourceManager.GetObject("animation3.ScaleCoeff", Resources.resourceCulture);
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x0600019B RID: 411 RVA: 0x00002942 File Offset: 0x00000B42
		public static PointF animation3_SlideCoeff
		{
			get
			{
				return (PointF)Resources.ResourceManager.GetObject("animation3.SlideCoeff", Resources.resourceCulture);
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x0600019C RID: 412 RVA: 0x0000295D File Offset: 0x00000B5D
		public static Bitmap arrow_down
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("arrow_down", Resources.resourceCulture);
			}
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x0600019D RID: 413 RVA: 0x00002978 File Offset: 0x00000B78
		public static Bitmap arrow_up
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("arrow_up", Resources.resourceCulture);
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x0600019E RID: 414 RVA: 0x00002993 File Offset: 0x00000B93
		public static Bitmap avatar
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("avatar", Resources.resourceCulture);
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x0600019F RID: 415 RVA: 0x000029AE File Offset: 0x00000BAE
		public static Icon DcRat
		{
			get
			{
				return (Icon)Resources.ResourceManager.GetObject("DcRat", Resources.resourceCulture);
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x060001A0 RID: 416 RVA: 0x000029C9 File Offset: 0x00000BC9
		public static Bitmap DcRat_png
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("DcRat_png", Resources.resourceCulture);
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x060001A1 RID: 417 RVA: 0x000029E4 File Offset: 0x00000BE4
		public static Bitmap keyboard
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("keyboard", Resources.resourceCulture);
			}
		}

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x060001A2 RID: 418 RVA: 0x000029FF File Offset: 0x00000BFF
		public static Bitmap keyboard_on
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("keyboard-on", Resources.resourceCulture);
			}
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x060001A3 RID: 419 RVA: 0x00002A1A File Offset: 0x00000C1A
		public static byte[] Keylogger
		{
			get
			{
				return (byte[])Resources.ResourceManager.GetObject("Keylogger", Resources.resourceCulture);
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x060001A4 RID: 420 RVA: 0x00002A35 File Offset: 0x00000C35
		public static Bitmap mouse
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("mouse", Resources.resourceCulture);
			}
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x060001A5 RID: 421 RVA: 0x00002A50 File Offset: 0x00000C50
		public static Bitmap mouse_enable
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("mouse_enable", Resources.resourceCulture);
			}
		}

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x060001A6 RID: 422 RVA: 0x00002A6B File Offset: 0x00000C6B
		public static UnmanagedMemoryStream offline
		{
			get
			{
				return Resources.ResourceManager.GetStream("offline", Resources.resourceCulture);
			}
		}

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x060001A7 RID: 423 RVA: 0x00002A81 File Offset: 0x00000C81
		public static UnmanagedMemoryStream online
		{
			get
			{
				return Resources.ResourceManager.GetStream("online", Resources.resourceCulture);
			}
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x060001A8 RID: 424 RVA: 0x00002A97 File Offset: 0x00000C97
		public static Bitmap play_button
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("play-button", Resources.resourceCulture);
			}
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x060001A9 RID: 425 RVA: 0x00002AB2 File Offset: 0x00000CB2
		public static Bitmap save_image
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("save-image", Resources.resourceCulture);
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x060001AA RID: 426 RVA: 0x00002ACD File Offset: 0x00000CCD
		public static Bitmap save_image2
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("save-image2", Resources.resourceCulture);
			}
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x060001AB RID: 427 RVA: 0x00002AE8 File Offset: 0x00000CE8
		public static Bitmap settings
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings", Resources.resourceCulture);
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x060001AC RID: 428 RVA: 0x00002B03 File Offset: 0x00000D03
		public static Point siticoneDragControl1_TrayLocation
		{
			get
			{
				return (Point)Resources.ResourceManager.GetObject("siticoneDragControl1.TrayLocation", Resources.resourceCulture);
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x060001AD RID: 429 RVA: 0x00002B1E File Offset: 0x00000D1E
		public static Point siticoneShadowForm_TrayLocation
		{
			get
			{
				return (Point)Resources.ResourceManager.GetObject("siticoneShadowForm.TrayLocation", Resources.resourceCulture);
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x060001AE RID: 430 RVA: 0x00002B39 File Offset: 0x00000D39
		public static Point siticoneTransition1_TrayLocation
		{
			get
			{
				return (Point)Resources.ResourceManager.GetObject("siticoneTransition1.TrayLocation", Resources.resourceCulture);
			}
		}

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x060001AF RID: 431 RVA: 0x00002B54 File Offset: 0x00000D54
		public static Bitmap stop__1_
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("stop (1)", Resources.resourceCulture);
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x060001B0 RID: 432 RVA: 0x00002B6F File Offset: 0x00000D6F
		public static string String1
		{
			get
			{
				return Resources.ResourceManager.GetString("String1", Resources.resourceCulture);
			}
		}

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x060001B1 RID: 433 RVA: 0x00002B85 File Offset: 0x00000D85
		public static Bitmap tomem
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("tomem", Resources.resourceCulture);
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x060001B2 RID: 434 RVA: 0x00002BA0 File Offset: 0x00000DA0
		public static Bitmap tomem1
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("tomem1", Resources.resourceCulture);
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x060001B3 RID: 435 RVA: 0x00002BBB File Offset: 0x00000DBB
		public static Bitmap uac
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("uac", Resources.resourceCulture);
			}
		}

		// Token: 0x0400015A RID: 346
		private static ResourceManager resourceMan;

		// Token: 0x0400015B RID: 347
		private static CultureInfo resourceCulture;
	}
}
