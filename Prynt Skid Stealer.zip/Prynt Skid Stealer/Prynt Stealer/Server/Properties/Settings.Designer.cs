﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Server.Properties
{
	// Token: 0x0200002A RID: 42
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.10.0.0")]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x1700006E RID: 110
		// (get) Token: 0x060001B4 RID: 436 RVA: 0x00002BD6 File Offset: 0x00000DD6
		public static Settings Default
		{
			get
			{
				return Settings.defaultInstance;
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x060001B5 RID: 437 RVA: 0x00002BDD File Offset: 0x00000DDD
		// (set) Token: 0x060001B6 RID: 438 RVA: 0x00002BEF File Offset: 0x00000DEF
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string Ports
		{
			get
			{
				return (string)this["Ports"];
			}
			set
			{
				this["Ports"] = value;
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x060001B7 RID: 439 RVA: 0x00002BFD File Offset: 0x00000DFD
		// (set) Token: 0x060001B8 RID: 440 RVA: 0x00002C0F File Offset: 0x00000E0F
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string Filename
		{
			get
			{
				return (string)this["Filename"];
			}
			set
			{
				this["Filename"] = value;
			}
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x060001B9 RID: 441 RVA: 0x00002C1D File Offset: 0x00000E1D
		// (set) Token: 0x060001BA RID: 442 RVA: 0x00002C2F File Offset: 0x00000E2F
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("True")]
		public bool Notification
		{
			get
			{
				return (bool)this["Notification"];
			}
			set
			{
				this["Notification"] = value;
			}
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x060001BB RID: 443 RVA: 0x00002C42 File Offset: 0x00000E42
		// (set) Token: 0x060001BC RID: 444 RVA: 0x00002C54 File Offset: 0x00000E54
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string Paste_bin
		{
			get
			{
				return (string)this["Paste_bin"];
			}
			set
			{
				this["Paste_bin"] = value;
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x060001BD RID: 445 RVA: 0x00002C62 File Offset: 0x00000E62
		// (set) Token: 0x060001BE RID: 446 RVA: 0x00002C74 File Offset: 0x00000E74
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string IP
		{
			get
			{
				return (string)this["IP"];
			}
			set
			{
				this["IP"] = value;
			}
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x060001BF RID: 447 RVA: 0x00002C82 File Offset: 0x00000E82
		// (set) Token: 0x060001C0 RID: 448 RVA: 0x00002C94 File Offset: 0x00000E94
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string ProductName
		{
			get
			{
				return (string)this["ProductName"];
			}
			set
			{
				this["ProductName"] = value;
			}
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x060001C1 RID: 449 RVA: 0x00002CA2 File Offset: 0x00000EA2
		// (set) Token: 0x060001C2 RID: 450 RVA: 0x00002CB4 File Offset: 0x00000EB4
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string txtDescription
		{
			get
			{
				return (string)this["txtDescription"];
			}
			set
			{
				this["txtDescription"] = value;
			}
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x060001C3 RID: 451 RVA: 0x00002CC2 File Offset: 0x00000EC2
		// (set) Token: 0x060001C4 RID: 452 RVA: 0x00002CD4 File Offset: 0x00000ED4
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string txtCompany
		{
			get
			{
				return (string)this["txtCompany"];
			}
			set
			{
				this["txtCompany"] = value;
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x060001C5 RID: 453 RVA: 0x00002CE2 File Offset: 0x00000EE2
		// (set) Token: 0x060001C6 RID: 454 RVA: 0x00002CF4 File Offset: 0x00000EF4
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string txtCopyright
		{
			get
			{
				return (string)this["txtCopyright"];
			}
			set
			{
				this["txtCopyright"] = value;
			}
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x060001C7 RID: 455 RVA: 0x00002D02 File Offset: 0x00000F02
		// (set) Token: 0x060001C8 RID: 456 RVA: 0x00002D14 File Offset: 0x00000F14
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string txtTrademarks
		{
			get
			{
				return (string)this["txtTrademarks"];
			}
			set
			{
				this["txtTrademarks"] = value;
			}
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x060001C9 RID: 457 RVA: 0x00002D22 File Offset: 0x00000F22
		// (set) Token: 0x060001CA RID: 458 RVA: 0x00002D34 File Offset: 0x00000F34
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string txtOriginalFilename
		{
			get
			{
				return (string)this["txtOriginalFilename"];
			}
			set
			{
				this["txtOriginalFilename"] = value;
			}
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x060001CB RID: 459 RVA: 0x00002D42 File Offset: 0x00000F42
		// (set) Token: 0x060001CC RID: 460 RVA: 0x00002D54 File Offset: 0x00000F54
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("0.0.0.0")]
		public string txtProductVersion
		{
			get
			{
				return (string)this["txtProductVersion"];
			}
			set
			{
				this["txtProductVersion"] = value;
			}
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x060001CD RID: 461 RVA: 0x00002D62 File Offset: 0x00000F62
		// (set) Token: 0x060001CE RID: 462 RVA: 0x00002D74 File Offset: 0x00000F74
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("0.0.0.0")]
		public string txtFileVersion
		{
			get
			{
				return (string)this["txtFileVersion"];
			}
			set
			{
				this["txtFileVersion"] = value;
			}
		}

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x060001CF RID: 463 RVA: 0x00002D82 File Offset: 0x00000F82
		// (set) Token: 0x060001D0 RID: 464 RVA: 0x00002D94 File Offset: 0x00000F94
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("listBlocked")]
		public string txtBlocked
		{
			get
			{
				return (string)this["txtBlocked"];
			}
			set
			{
				this["txtBlocked"] = value;
			}
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x060001D1 RID: 465 RVA: 0x00002DA2 File Offset: 0x00000FA2
		// (set) Token: 0x060001D2 RID: 466 RVA: 0x00002DB4 File Offset: 0x00000FB4
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("Default")]
		public string Group
		{
			get
			{
				return (string)this["Group"];
			}
			set
			{
				this["Group"] = value;
			}
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x060001D3 RID: 467 RVA: 0x00002DC2 File Offset: 0x00000FC2
		// (set) Token: 0x060001D4 RID: 468 RVA: 0x00002DD4 File Offset: 0x00000FD4
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("DcRatMutex_qwqdanchun")]
		public string Mutex
		{
			get
			{
				return (string)this["Mutex"];
			}
			set
			{
				this["Mutex"] = value;
			}
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x060001D5 RID: 469 RVA: 0x00002DE2 File Offset: 0x00000FE2
		// (set) Token: 0x060001D6 RID: 470 RVA: 0x00002DF4 File Offset: 0x00000FF4
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		public bool DingDing
		{
			get
			{
				return (bool)this["DingDing"];
			}
			set
			{
				this["DingDing"] = value;
			}
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x060001D7 RID: 471 RVA: 0x00002E07 File Offset: 0x00001007
		// (set) Token: 0x060001D8 RID: 472 RVA: 0x00002E19 File Offset: 0x00001019
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string WebHook
		{
			get
			{
				return (string)this["WebHook"];
			}
			set
			{
				this["WebHook"] = value;
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x060001D9 RID: 473 RVA: 0x00002E27 File Offset: 0x00001027
		// (set) Token: 0x060001DA RID: 474 RVA: 0x00002E39 File Offset: 0x00001039
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string Secret
		{
			get
			{
				return (string)this["Secret"];
			}
			set
			{
				this["Secret"] = value;
			}
		}

		// Token: 0x0400015C RID: 348
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());
	}
}
