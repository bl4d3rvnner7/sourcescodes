﻿using System;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using Server.Handle_Packet;

namespace Server.Connection
{
	// Token: 0x02000028 RID: 40
	internal class Listener
	{
		// Token: 0x1700004C RID: 76
		// (get) Token: 0x0600018C RID: 396 RVA: 0x00002854 File Offset: 0x00000A54
		// (set) Token: 0x0600018D RID: 397 RVA: 0x0000285C File Offset: 0x00000A5C
		private Socket Server { get; set; }

		// Token: 0x0600018E RID: 398 RVA: 0x00013CD8 File Offset: 0x00011ED8
		public void Connect(object port)
		{
			try
			{
				IPEndPoint localEP = new IPEndPoint(IPAddress.Any, Convert.ToInt32(port));
				this.Server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
				{
					SendBufferSize = 51200,
					ReceiveBufferSize = 51200
				};
				this.Server.Bind(localEP);
				this.Server.Listen(500);
				new HandleLogs().Addmsg(string.Format("Listenning to: {0}", port), Color.Green);
				this.Server.BeginAccept(new AsyncCallback(this.EndAccept), null);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
				Environment.Exit(0);
			}
		}

		// Token: 0x0600018F RID: 399 RVA: 0x00013D90 File Offset: 0x00011F90
		private void EndAccept(IAsyncResult ar)
		{
			try
			{
				new Clients(this.Server.EndAccept(ar));
			}
			catch
			{
			}
			finally
			{
				this.Server.BeginAccept(new AsyncCallback(this.EndAccept), null);
			}
		}
	}
}
