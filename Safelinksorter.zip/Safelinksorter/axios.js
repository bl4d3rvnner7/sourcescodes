const axios = require('axios');
const config = require('./config');

exports.axiosClient = axios.create({
    baseURL: config.apiUrl,
    headers: {
        Accept: 'application/json'
    }
});