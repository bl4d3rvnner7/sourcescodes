const dns = require('dns');
const fs = require('fs');
const path = require('path');
const colors = require('colors');
const { axiosClient } = require("./axios");
const config = require("./config");
const { getSystemInfo, activateLicense } = require("./licensing/activateLicense");

// Initialize colors
colors.enable();

const cyan = colors.cyan;
const reset = colors.reset;

function printHeader() {
    const logo = `\x1b[33m
    //////////////////////////////////////////////////////////////////////////////////////|
    //                                                                                  //
    //                            Report any problems to coder @tensmal on telegram     //
    //                                                                                  //
    //                      ██████  ██    ██ ██   ██ ███████                            //
    //                      ██   ██ ██    ██ ██  ██  ██                                 //
    //                      ██   ██ ██    ██ █████   █████                              //
    //                      ██   ██ ██    ██ ██  ██  ██                                 //
    //                      ██████   ██████  ██   ██ ███████                            //
    //                                                                                  //
    //                                           BY DUKE_ADMIN                          //
    //                          Safelink Sorter!!!                                      //
    //                                                                                  //
    //////////////////////////////////////////////////////////////////////////////////////|
    \x1b[0m\n
    `;
    console.log(logo);
}

async function checkLicense() {
    console.log(colors.yellow('Checking License Validity'));
    let license;
    let hardwareConfig;

    try {
        const licensePath = path.join(path.dirname(process.execPath), "licensing", "license.txt");
        license = await fs.promises.readFile(licensePath, "utf8");
        hardwareConfig = await getSystemInfo();

        if (license.length === 0) {
            license = await activateLicense(hardwareConfig);
            console.log(colors.green("Successfully activated your license\n"));
        }
    } catch (err) {
        console.log(colors.red("Could not activate/locate your license file, please contact us\n"));
        throw err;
    }
}

async function checkDmarcPolicy(domain) {
    return new Promise((resolve, reject) => {
        const resolver = new dns.Resolver();
        resolver.setServers(['8.8.8.8', '8.8.4.4']);  // Google's DNS servers
        const retries = 3;

        const attemptResolve = (retryCount) => {
            resolver.resolveTxt(`_dmarc.${domain}`, (err, addresses) => {
                if (err) {
                    if (retryCount < retries) {
                        setTimeout(() => attemptResolve(retryCount + 1), 1000); // Retry on error
                    } else {
                        resolve(false); // No DMARC record found after retries
                    }
                } else {
                    // Check if any record starts with v=DMARC1
                    const hasDmarc = addresses.some(record => record.join('').startsWith('v=DMARC1;'));
                    resolve(hasDmarc);
                }
            });
        };

        attemptResolve(0);
    });
}

async function processEmails(inputFile) {
    // Initialize counters instead of arrays
    let enabledCount = 0;
    let notEnabledCount = 0;
    let totalProcessed = 0; // Keep track of total processed for summary

    let emails;
    try {
        emails = fs.readFileSync(inputFile, 'utf8').split('\n').map(email => email.trim());
        // Clear output files at the start (optional, but good practice)
        await fs.promises.writeFile('Enabled.txt', '');
        await fs.promises.writeFile('NotEnabled.txt', '');
    } catch (err) {
        console.error(`Error reading file ${inputFile} or clearing output files:`, err);
        return;
    }

    for (const email of emails) {
        if (email) {
            totalProcessed++; // Increment total count
            const domain = email.split('@')[1];
            try {
                const hasSafeLinks = await checkDmarcPolicy(domain);
                if (hasSafeLinks) {
                    // Append directly to the file
                    await fs.promises.appendFile('Enabled.txt', email + '\n');
                    enabledCount++; // Increment counter
                    console.log(colors.red(`${email} has SafeLinks enabled`) + colors.reset);
                } else {
                    // Append directly to the file
                    await fs.promises.appendFile('NotEnabled.txt', email + '\n');
                    notEnabledCount++; // Increment counter
                    console.log(colors.green(`${email} has SafeLinks disabled`) + colors.reset);
                }
            } catch (err) {
                console.error(`Error checking DMARC policy for ${domain}:`, err);
                // Optionally, write errors to a separate file or the NotEnabled file
                try {
                    await fs.promises.appendFile('NotEnabled.txt', `${email} # ERROR: ${err.message}\n`);
                    notEnabledCount++; // Count errors towards NotEnabled
                } catch (appendErr) {
                    console.error(`Failed to append error for ${email} to NotEnabled.txt:`, appendErr);
                }
            }
        }
    }

    // Update the summary message
    console.log(`\n--- Processing Complete ---`);
    console.log(colors.cyan(`Total Emails Processed: ${totalProcessed}`));
    console.log(colors.green(`Enabled (Saved to Enabled.txt): ${enabledCount}`));
    console.log(colors.red(`Not Enabled / Error (Saved to NotEnabled.txt): ${notEnabledCount}`));
}

printHeader();

/*
checkLicense().then(() => {
    processEmails('emails.txt');
}).catch(err => {
    console.error('License check failed:', err);
});
*/
processEmails("emails.txt");