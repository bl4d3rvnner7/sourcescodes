module.exports = {
    apiUrl: "https://dudamosp.com/api/v1",
    licenseEndpoint: "/license"
};