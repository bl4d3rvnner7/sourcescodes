const sysInfo = require('systeminformation');
const fs = require('fs').promises;
const path = require('path');
const readline = require('readline');
const { axiosClient } = require('../axios');
const config = require('../config');

exports.getSystemInfo = async function () {
    const cpuSpecs = await sysInfo.cpu();
    const { brand: cpuBrand, cores: cpuCoreCount, model: cpuModel } = cpuSpecs;
    const system = await sysInfo.system();
    const { manufacturer: pcManufacturer, model: pcModel, version: pcVersion } = system;
    const mobo = await sysInfo.baseboard();
    const { manufacturer: mbManufacturer, model: mbModel, version: mbVersion } = mobo;
    const sysIds = await sysInfo.uuid();
    const { hardware, ...ids } = sysIds;
    const osInfo = await sysInfo.osInfo();
    const { platform, distro, release, arch } = osInfo;

    const nonEmpties = {};

    const allFields = {
        cpuBrand,
        cpuCoreCount,
        cpuModel,
        pcManufacturer,
        pcModel,
        pcVersion,
        mbManufacturer,
        mbModel,
        mbVersion,
        uuids: ids,
        platform,
        distro,
        release,
        arch,
    };

    Object.keys(allFields).forEach((field) => {
        if (allFields[field]) {
            nonEmpties[field] = allFields[field];
        }
    });

    return nonEmpties;
}

exports.activateLicense = async function (hwConfig) {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    return new Promise((resolve, reject) => {
        rl.question('Please input your license key here: \n', async (licenseKey) => {
            rl.close();
            try {
                const response = await axiosClient.patch(config.licenseEndpoint, { licenseKey, hardwareInfo: hwConfig });
                const licenseToken = response.data.token;
                await fs.writeFile(path.resolve(__dirname, 'license.txt'), licenseToken, 'utf8');
                resolve(licenseToken);
            } catch (err) {
                if (err.response && err.response.data) {
                    console.error(err.response.data.message);
                } else {
                    console.error(err);
                }
                reject(err);
            }
        });
    });
}