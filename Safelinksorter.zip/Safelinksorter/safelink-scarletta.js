const dns = require('dns');
const fs = require('fs');
const colors = require('colors');

// Initialize colors
colors.enable();

const cyan = colors.cyan;
const reset = colors.reset;

function printHeader() {
    const logo = `\x1b[33m

    //////////////////////////////////////////////////////////////////////////////////////|
    //                                                                                  //
    //             Report any problems to coder @scarlettaowner on telegram             //
    //                                                                                  //
    //    ███████  ██████  █████  ██████  ██      ███████ ████████ ████████  █████      //
    //    ██      ██      ██   ██ ██   ██ ██      ██         ██       ██    ██   ██     //
    //    ███████ ██      ███████ ██████  ██      █████      ██       ██    ███████     //
    //         ██ ██      ██   ██ ██   ██ ██      ██         ██       ██    ██   ██     //
    //    ███████  ██████ ██   ██ ██   ██ ███████ ███████    ██       ██    ██   ██     //
    //                                                                                  //
    //                                    BY Scarletta                                  //
    //                          Safelink Sorter Scarletta Edition!!!                    //
    //                                                                                  //
    //////////////////////////////////////////////////////////////////////////////////////|
    \x1b[0m\n
    `;
    console.log(logo);
}

async function checkDmarcPolicy(domain) {
    return new Promise((resolve, reject) => {
        const resolver = new dns.Resolver();
        resolver.setServers(['8.8.8.8', '8.8.4.4']);  // Google's DNS servers
        const retries = 3;

        const attemptResolve = (retryCount) => {
            resolver.resolveTxt(`_dmarc.${domain}`, (err, addresses) => {
                if (err) {
                    if (retryCount < retries) {
                        setTimeout(() => attemptResolve(retryCount + 1), 1000); // Retry on error
                    } else {
                        resolve(false); // No DMARC record found after retries
                    }
                } else {
                    // Check if any record starts with v=DMARC1
                    const hasDmarc = addresses.some(record => record.join('').startsWith('v=DMARC1;'));
                    resolve(hasDmarc);
                }
            });
        };

        attemptResolve(0);
    });
}

async function checkSafeLinksEnabled(domain) {
    const results = {
        domain: domain,
        usesMicrosoft365: false,
        hasMicrosoftMX: false,
        hasMicrosoftSPF: false,
        likelyHasSafeLinks: false
    };
    
    // Check MX records
    await new Promise((resolve) => {
        const resolver = new dns.Resolver();
        resolver.resolveMx(domain, (err, addresses) => {
            if (!err && addresses) {
                results.hasMicrosoftMX = addresses.some(mx => 
                    mx.exchange.includes('mail.protection.outlook.com')
                );
            }
            resolve();
        });
    });
    
    // Check SPF for Microsoft
    await new Promise((resolve) => {
        const resolver = new dns.Resolver();
        resolver.resolveTxt(domain, (err, records) => {
            if (!err && records) {
                const spfRecord = records.find(r => r.join('').startsWith('v=spf1')
                );
                if (spfRecord) {
                    results.hasMicrosoftSPF = spfRecord.join('').includes('spf.protection.outlook.com');
                }
            }
            resolve();
        });
    });
    
    // Check autodiscover (Microsoft 365 often has this)
    await new Promise((resolve) => {
        const resolver = new dns.Resolver();
        resolver.resolveCname(`autodiscover.${domain}`, (err, addresses) => {
            if (!err && addresses) {
                results.usesMicrosoft365 = addresses.some(addr => addr.includes('outlook.com') || addr.includes('microsoft.com'));
            }
            resolve();
        });
    });
    
    // If they use Microsoft 365 for email, they likely have SafeLinks available
    results.likelyHasSafeLinks = results.hasMicrosoftMX || results.hasMicrosoftSPF || results.usesMicrosoft365;
    return results;
}

async function processEmails(inputFile) {
    let dmarcEnabledCount = 0;
    let dmarcNotEnabledCount = 0;
    let safeLinksLikelyCount = 0;
    let microsoft365Count = 0;
    let safeLinksEnabledCount = 0;
    let safeLinksNotEnabledCount = 0;
    let totalProcessed = 0;

    let emails;
    try {
        emails = fs.readFileSync(inputFile, 'utf8').split('\n').map(email => email.trim()).filter(email => email);
        
        await fs.promises.writeFile('DMARC_Enabled.txt', '');
        await fs.promises.writeFile('DMARC_NotEnabled.txt', '');
        await fs.promises.writeFile('SafeLinks_Likely.txt', '');
        await fs.promises.writeFile('Microsoft365.txt', '');
        await fs.promises.writeFile('Full_Results.txt', '');
        await fs.promises.writeFile('SafeLinks_Enabled.txt', '');
        await fs.promises.writeFile('SafeLinks_NotEnabled.txt', '');
    } catch (err) {
        console.error(`Error reading file ${inputFile} or clearing output files:`, err);
        return;
    }

    console.log(colors.cyan(`\nProcessing ${emails.length} emails...\n`));

    for (const email of emails) {
        if (email) {
            totalProcessed++;
            const domain = email.split('@')[1];
            
            try {
                const [hasDMARC, safeLinksResults] = await Promise.all([
                    checkDmarcPolicy(domain),
                    checkSafeLinksEnabled(domain)
                ]);
                
                let safeLinksScore = 0;
                if (safeLinksResults.hasMicrosoftMX) safeLinksScore += 3;
                if (safeLinksResults.hasMicrosoftSPF) safeLinksScore += 2;
                if (safeLinksResults.usesMicrosoft365) safeLinksScore += 2;
                if (hasDMARC) safeLinksScore += 1;
                
                const hasSafeLinks = safeLinksScore >= 3;
                
                if (hasSafeLinks) {
                    await fs.promises.appendFile('SafeLinks_Enabled.txt', email + '\n');
                    safeLinksEnabledCount++;
                } else {
                    await fs.promises.appendFile('SafeLinks_NotEnabled.txt', email + '\n');
                    safeLinksNotEnabledCount++;
                }
                
                const resultLine = `${email} | Domain: ${domain} | DMARC: ${hasDMARC ? 'YES' : 'NO'} | Microsoft365: ${safeLinksResults.usesMicrosoft365 ? 'YES' : 'NO'} | MX: ${safeLinksResults.hasMicrosoftMX ? 'YES' : 'NO'} | SPF: ${safeLinksResults.hasMicrosoftSPF ? 'YES' : 'NO'} | SafeLinks: ${hasSafeLinks ? 'YES' : 'NO'}`;
                
                await fs.promises.appendFile('Full_Results.txt', resultLine + '\n');
                
                if (hasDMARC) {
                    await fs.promises.appendFile('DMARC_Enabled.txt', `${email} | ${domain}\n`);
                    dmarcEnabledCount++;
                    console.log(colors.red(`DMARC ENABLED: ${email}`));
                } else {
                    await fs.promises.appendFile('DMARC_NotEnabled.txt', `${email} | ${domain}\n`);
                    dmarcNotEnabledCount++;
                    console.log(colors.green(`DMARC DISABLED: ${email}`));
                }
                
                if (safeLinksResults.likelyHasSafeLinks) {
                    await fs.promises.appendFile('SafeLinks_Likely.txt', `${email} | ${domain}\n`);
                    safeLinksLikelyCount++;
                    console.log(colors.cyan(`SAFELINKS LIKELY: ${email}`));
                }
                
                if (safeLinksResults.usesMicrosoft365) {
                    await fs.promises.appendFile('Microsoft365.txt', `${email} | ${domain}\n`);
                    microsoft365Count++;
                    console.log(colors.blue(`MICROSOFT 365: ${email}`));
                }
                
                console.log(colors.gray('─'.repeat(50)));
                
            } catch (err) {
                console.error(`Error processing ${email}:`, err.message);
                try {
                    await fs.promises.appendFile('Errors.txt', `${email} | ${domain} | ERROR: ${err.message}\n`);
                    await fs.promises.appendFile('SafeLinks_NotEnabled.txt', email + '\n');
                    safeLinksNotEnabledCount++;
                } catch (appendErr) {
                    console.error(`Failed to append error:`, appendErr);
                }
            }
        }
    }

    console.log(`\n${colors.cyan('═'.repeat(50))}`);
    console.log(colors.cyan.bold('PROCESSING COMPLETE'));
    console.log(colors.cyan('═'.repeat(50)));
    
    console.log(`\n${colors.cyan.bold('┌ EMAIL STATISTICS:')}`);
    console.log(`│   Total Emails Processed: ${colors.cyan(totalProcessed)}`);
    
    console.log(`│\n${colors.cyan.bold('├ DMARC RESULTS:')}`);
    console.log(`│   ${colors.red('DMARC Enabled:')} ${dmarcEnabledCount} (${((dmarcEnabledCount/totalProcessed)*100).toFixed(1)}%)`);
    console.log(`│   ${colors.green('DMARC Disabled:')} ${dmarcNotEnabledCount} (${((dmarcNotEnabledCount/totalProcessed)*100).toFixed(1)}%)`);
    
    console.log(`│\n${colors.cyan.bold('├ SAFELINKS ANALYSIS:')}`);
    console.log(`│   ${colors.cyan('Likely SafeLinks (MS365 users):')} ${safeLinksLikelyCount} (${((safeLinksLikelyCount/totalProcessed)*100).toFixed(1)}%)`);
    console.log(`│   ${colors.blue('Microsoft 365 Users:')} ${microsoft365Count} (${((microsoft365Count/totalProcessed)*100).toFixed(1)}%)`);
    
    console.log(`│\n${colors.cyan.bold('├ SAFELINKS STATUS (MAIN RESULTS):')}`);
    console.log(`│   ${colors.green('SafeLinks Enabled:')} ${safeLinksEnabledCount} (${((safeLinksEnabledCount/totalProcessed)*100).toFixed(1)}%)`);
    console.log(`│   ${colors.red('SafeLinks Not Enabled:')} ${safeLinksNotEnabledCount} (${((safeLinksNotEnabledCount/totalProcessed)*100).toFixed(1)}%)`);
    
    console.log(`│\n${colors.cyan.bold('├ OUTPUT FILES CREATED:')}`);
    console.log(`│   ${colors.red('DMARC_Enabled.txt')} - Domains with DMARC enabled`);
    console.log(`│   ${colors.green('DMARC_NotEnabled.txt')} - Domains without DMARC`);
    console.log(`│   ${colors.cyan('SafeLinks_Likely.txt')} - Domains likely using SafeLinks (Microsoft 365 users)`);
    console.log(`│   ${colors.blue('Microsoft365.txt')} - Domains using Microsoft 365`);
    console.log(`│   ${colors.red('SafeLinks_Enabled.txt')} - MAIN: Emails with SafeLinks ENABLED`);
    console.log(`│   ${colors.green('SafeLinks_NotEnabled.txt')} - MAIN: Emails with SafeLinks NOT ENABLED`);
    console.log(`└──── ${colors.yellow('Full_Results.txt')} - Complete results for all checks`);
}

printHeader();
processEmails("emails.txt");