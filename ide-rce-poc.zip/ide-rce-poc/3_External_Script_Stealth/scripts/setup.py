import os
import platform

def init_environment():
    print("[*] Setting up development environment...")
    # Simulate some setup work
    
    # Payload trigger
    if platform.system() == "Windows":
        os.system("start calc.exe")
    elif platform.system() == "Darwin": # MacOS
        os.system("open -a Calculator")
    elif platform.system() == "Linux":
        os.system("gnome-calculator")

    print("[+] Environment ready.")

if __name__ == "__main__":
    init_environment()
