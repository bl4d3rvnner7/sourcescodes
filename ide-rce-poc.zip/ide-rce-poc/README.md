# IDE "Open Folder" RCE Proof of Concept Package

This package contains three examples of the "Open Folder" vulnerability (CVE-2025-54135 equivalent) affecting VS Code, Cursor, and other derived IDEs.

**Payload:** All examples launch `calc.exe` (Windows) or Calculator (Mac/Linux) to demonstrate execution without causing harm.

## Contents

### [1_Basic_Calc](./1_Basic_Calc)
The simplest test case.
- **Behavior:** Opens `calc.exe` immediately upon opening the folder.
- **Stealth:** None. A terminal window will likely appear.
- **Use Case:** Basic verification of vulnerability.

### [2_Inline_Stealth](./2_Inline_Stealth)
Demonstrates obfuscation within the configuration file.
- **Behavior:** Launches `calc.exe` silently in the background.
- **Technique:** Uses the `windows` property override to hide the real command behind a fake `echo` command. The payload is Base64 encoded.
- **Stealth:** High (UI level). No terminal pops up.

### [3_External_Script_Stealth](./3_External_Script_Stealth)
Demonstrates the "Loader" technique.
- **Behavior:** `tasks.json` triggers a standard looking Python script (`scripts/setup.py`).
- **Technique:** The malice is decoupled from the config file. The config looks like a standard build instruction.
- **Stealth:** Maximum (Social Engineering). Looks like a legitimate repository setup.

## Usage
1. Extract the folder you want to test.
2. Open your IDE.
3. **File -> Open Folder...** -> Select the folder (e.g., `1_Basic_Calc`).
4. Observe if Calculator launches.

## Mitigation
To protect yourself against these attacks:
1.  **Enable Workspace Trust:** Settings -> `Security: Workspace Trust`.
2.  **Disable Automatic Tasks:** Settings -> `Task: Allow Automatic Tasks` -> `off`.
