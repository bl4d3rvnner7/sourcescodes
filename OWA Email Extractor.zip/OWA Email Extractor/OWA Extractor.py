import os
import threading
import requests
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
import yaml
import platform
import re
import urllib3
import colorama

urllib3.disable_warnings()
colorama.init(autoreset=True)

class Utilities:
    @staticmethod
    def extract_mails(text):
        """Extract all email addresses from the given text."""
        email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        try:
            return re.findall(email_pattern, text)
        except Exception as e:
            print(f"\t\033[31m[-] Error during email extraction: {e}")
            return []
    @staticmethod
    def extraction():
        """Extract emails from specified files and save them to sorted output files."""
        file_paths = ['OtherEmails.txt', 'Web App.txt', 'Outlook.txt']
        for file_path in file_paths:
            emails = set()
            full_path = os.path.join("Result", file_path)
            if os.path.exists(full_path):
                with open(full_path, 'r', errors='ignore', encoding='utf-8') as file:
                    emails.update(Utilities.extract_mails(file.read()))
                output_file = os.path.join("Result", file_path.replace('.txt', '_sorted.txt'))
                with open(output_file, 'w', errors='ignore', encoding='utf-8') as sorted_file:
                    for email in sorted(emails):
                        sorted_file.write(email + "\n")
                
                print(f"\t\033[34m[-] Extracted {len(emails)} unique email(s) to '{output_file}'.\033[0m")
            else:
                print(f"\t\033[31m[!] File '{full_path}' not found.\033[0m")
    @staticmethod
    def banner():
        print("""\033[34m\n\t    ███████    █████   ███   █████   █████████  \n\t  ███░░░░░███ ░░███   ░███  ░░███   ███░░░░░███ \n\t ███     ░░███ ░███   ░███   ░███  ░███    ░███ \n\t░███      ░███ ░███   ░███   ░███  ░███████████ \n\t░███      ░███ ░░███  █████  ███   ░███░░░░░███ \n\t░░███     ███   ░░░█████░█████░    ░███    ░███ \n\t ░░░███████░      ░░███ ░░███      █████   █████\n\t   ░░░░░░░         ░░░   ░░░      ░░░░░   ░░░░░ \n\n\t           \033[37m[~] \033[34mExtractor & Validator \033[37m[~]           \n\n""")
        input('\t\033[37m[enter to start] ')
    @staticmethod
    def clean():
        if platform.system().lower() == 'windows':
            os.system('cls')
        else:
            os.system('clear')

class Config:
    Threads = 0
    Timeout = 0
    @staticmethod
    def load_config():
        if os.path.exists("Settings.yml"):
            with open("Settings.yml", "r") as settings_file:
                settings = yaml.safe_load(settings_file)
                Config.Threads = int(settings['settings']['Threads'])
                Config.Timeout = int(settings['settings']['Timeout'])
        else:
            print("\t\033[91m[!] Settings File Not Found!\nPress any key to exit...\033[0m")
            input()
            exit(0)

class OWAEmailExtractor:
    def __init__(self):
        self.emails = self.load_file("Emails.txt")
        self.websites = ['mail.[domain]', 'webmail.[domain]', 'autodiscover.[domain]']
        self.valid_titles = ['Outlook', 'Web App']
        self.checked = 0
        self.total = len(self.emails) * len(self.websites)
        self.is_completed = False
        self.lock = threading.Lock()
        if not os.path.exists("Result"):
            os.makedirs("Result")

    @staticmethod
    def load_file(filepath):
        if os.path.exists(filepath):
            with open(filepath, "r") as file:
                return set(file.read().splitlines())
        return set()

    def update_console(self, success, data):
        with self.lock:
            if success:
                print(f"\t\033[92m[+] {data}\033[0m")  # Green text for success
            else:
                print(f"\t\033[91m[-] {data}\033[0m")

    def save_file(self, path, data):
        with self.lock:
            try:
                with open(path, "a", encoding="ascii") as file:
                    file.write(data + "\n")
            except Exception as e:
                pass

    def get_title(self, url):
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
                "Accept-Language": "en-US,en;q=0.9"
            }
            if not url.startswith('https://'):
                url = "https://" + url
            response = requests.get(url, headers=headers, timeout=Config.Timeout / 1000, verify=False)
            response.raise_for_status()

            soup = BeautifulSoup(response.text, "html.parser")
            title = soup.title.string if soup.title else ""
            self.checked += 1
            return title.strip()
        except Exception:
            self.checked += 1
            return ""

    def check_email(self, email):
        if "@" not in email:
            self.update_console(False, email)
            self.checked += len(self.websites)
            return

        username, domain = email.split("@", 1)

        for website_template in self.websites:
            url = website_template.replace("[domain]", domain)
            title = self.get_title(url)

            if title:
                self.update_console(True, f"{title} - {email}, {url}")

                for valid_title in self.valid_titles:
                    if valid_title.lower() in title.lower():
                        self.save_file(f"Result/{valid_title}.txt", f"{title} , {email} , {url}")
                        break
                else:
                    self.save_file("Result/OtherEmails.txt", f"{title} , {email} , {url}")
            else:
                self.update_console(False, f"{email}, {url}")

    def worker(self):
        with ThreadPoolExecutor(max_workers=Config.Threads) as executor:
            executor.map(self.check_email, self.emails)

        self.is_completed = True

    def updater(self):
        is_windows = platform.system().lower() == "windows"
        while not self.is_completed:
            with self.lock:
                title = f"[~] OWA Email Extractor [{self.checked}/{self.total}] | SCARLETTA [~]"
                if is_windows:
                    os.system(f"title {title}")
                else:
                    print(f"\033]0;{title}\007", end="")
            threading.Event().wait(1)
        print("\n\t\t\033[95mTask Successfully Completed!\n")

if __name__ == "__main__":
    Config.load_config()

    utilties = Utilities()
    utilties.clean()
    utilties.banner()
    extractor = OWAEmailExtractor()

    updater_thread = threading.Thread(target=extractor.updater)
    updater_thread.start()

    extractor.worker()
    updater_thread.join()

    utilties.extraction()