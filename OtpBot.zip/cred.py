#Twilio Details

account_sid = 'ACad2b34187457fc32516ccb14472be4a4'
auth_token = '5fd3a96fddbd9cac889854480f00104a'
twilionumber = '+19016686799'
twiliosmsnumber = '+19016686799'

#FC Bot
API_TOKEN = "5694868946:AAFGxoBoGcAEpUq4L5cOwKPL-qqXn8_spf0"

#Host URL
callurl = 'https://d601-20-189-116-138.ap.ngrok.io'
twiliosmsurl = 'https://d601-20-189-116-138.ap.ngrok.io/sms'









