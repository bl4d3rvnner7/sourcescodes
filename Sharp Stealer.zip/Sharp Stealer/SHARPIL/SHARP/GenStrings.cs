﻿using System;

namespace SHARP
{
	// Token: 0x02000046 RID: 70
	internal class GenStrings
	{
		// Token: 0x06000148 RID: 328 RVA: 0x0000730C File Offset: 0x0000550C
		public static string Generate()
		{
			string text = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
			string text2 = "";
			Random random = new Random();
			int num = random.Next(0, text.Length);
			for (int i = 0; i < num; i++)
			{
				text2 += text[random.Next(10, text.Length)].ToString();
			}
			return text2;
		}

		// Token: 0x06000149 RID: 329 RVA: 0x0000736E File Offset: 0x0000556E
		public static int GenNumbersTo()
		{
			return new Random().Next(11, 99);
		}
	}
}
