﻿using System;

namespace SHARP
{
	// Token: 0x0200003B RID: 59
	internal struct GiftFormat
	{
		// Token: 0x06000115 RID: 277 RVA: 0x000067EA File Offset: 0x000049EA
		internal GiftFormat(string title, string code)
		{
			this.Title = title;
			this.Code = code;
		}

		// Token: 0x04000095 RID: 149
		internal readonly string Title;

		// Token: 0x04000096 RID: 150
		internal readonly string Code;
	}
}
