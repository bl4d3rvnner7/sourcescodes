﻿using System;
using System.Text.RegularExpressions;

namespace SHARP
{
	// Token: 0x02000014 RID: 20
	internal sealed class Json
	{
		// Token: 0x06000073 RID: 115 RVA: 0x000031E4 File Offset: 0x000013E4
		public Json(string data)
		{
			this.Data = data;
		}

		// Token: 0x06000074 RID: 116 RVA: 0x000031F4 File Offset: 0x000013F4
		public string GetValue(string value)
		{
			string empty = string.Empty;
			Match match = new Regex("\"" + value + "\":\"([^\"]+)\"").Match(this.Data);
			if (!match.Success)
			{
				return empty;
			}
			return Regex.Split(match.Value, "\"")[3];
		}

		// Token: 0x06000075 RID: 117 RVA: 0x00003248 File Offset: 0x00001448
		public void Remove(string[] values)
		{
			foreach (string oldValue in values)
			{
				this.Data = this.Data.Replace(oldValue, "");
			}
		}

		// Token: 0x06000076 RID: 118 RVA: 0x00003280 File Offset: 0x00001480
		public string[] SplitData(string delimiter = "},")
		{
			return Regex.Split(this.Data, delimiter);
		}

		// Token: 0x04000038 RID: 56
		public string Data;
	}
}
