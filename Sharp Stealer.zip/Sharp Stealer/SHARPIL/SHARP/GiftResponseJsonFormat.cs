﻿using System;

namespace SHARP
{
	// Token: 0x0200003D RID: 61
	internal struct GiftResponseJsonFormat
	{
		// Token: 0x17000021 RID: 33
		// (get) Token: 0x06000118 RID: 280 RVA: 0x0000680B File Offset: 0x00004A0B
		// (set) Token: 0x06000119 RID: 281 RVA: 0x00006813 File Offset: 0x00004A13
		internal Promotion promotion { get; set; }

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x0600011A RID: 282 RVA: 0x0000681C File Offset: 0x00004A1C
		// (set) Token: 0x0600011B RID: 283 RVA: 0x00006824 File Offset: 0x00004A24
		internal string code { get; set; }
	}
}
