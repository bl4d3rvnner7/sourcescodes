﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;

namespace SHARP
{
	// Token: 0x0200004E RID: 78
	[GeneratedCode("simple-json", "1.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public class JsonObject : IDictionary<string, object>, ICollection<KeyValuePair<string, object>>, IEnumerable<KeyValuePair<string, object>>, IEnumerable
	{
		// Token: 0x0600015F RID: 351 RVA: 0x00007D3A File Offset: 0x00005F3A
		public JsonObject()
		{
			this._members = new Dictionary<string, object>();
		}

		// Token: 0x06000160 RID: 352 RVA: 0x00007D4D File Offset: 0x00005F4D
		public JsonObject(IEqualityComparer<string> comparer)
		{
			this._members = new Dictionary<string, object>(comparer);
		}

		// Token: 0x1700002E RID: 46
		public object this[int index]
		{
			get
			{
				return JsonObject.GetAtIndex(this._members, index);
			}
		}

		// Token: 0x06000162 RID: 354 RVA: 0x00007D70 File Offset: 0x00005F70
		internal static object GetAtIndex(IDictionary<string, object> obj, int index)
		{
			if (obj == null)
			{
				throw new ArgumentNullException("obj");
			}
			if (index >= obj.Count)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			int num = 0;
			foreach (KeyValuePair<string, object> keyValuePair in obj)
			{
				if (num++ == index)
				{
					return keyValuePair.Value;
				}
			}
			return null;
		}

		// Token: 0x06000163 RID: 355 RVA: 0x00007DEC File Offset: 0x00005FEC
		public void Add(string key, object value)
		{
			this._members.Add(key, value);
		}

		// Token: 0x06000164 RID: 356 RVA: 0x00007DFB File Offset: 0x00005FFB
		public bool ContainsKey(string key)
		{
			return this._members.ContainsKey(key);
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x06000165 RID: 357 RVA: 0x00007E09 File Offset: 0x00006009
		public ICollection<string> Keys
		{
			get
			{
				return this._members.Keys;
			}
		}

		// Token: 0x06000166 RID: 358 RVA: 0x00007E16 File Offset: 0x00006016
		public bool Remove(string key)
		{
			return this._members.Remove(key);
		}

		// Token: 0x06000167 RID: 359 RVA: 0x00007E24 File Offset: 0x00006024
		public bool TryGetValue(string key, out object value)
		{
			return this._members.TryGetValue(key, out value);
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x06000168 RID: 360 RVA: 0x00007E33 File Offset: 0x00006033
		public ICollection<object> Values
		{
			get
			{
				return this._members.Values;
			}
		}

		// Token: 0x17000031 RID: 49
		public object this[string key]
		{
			get
			{
				return this._members[key];
			}
			set
			{
				this._members[key] = value;
			}
		}

		// Token: 0x0600016B RID: 363 RVA: 0x00007E5D File Offset: 0x0000605D
		public void Add(KeyValuePair<string, object> item)
		{
			this._members.Add(item.Key, item.Value);
		}

		// Token: 0x0600016C RID: 364 RVA: 0x00007E78 File Offset: 0x00006078
		public void Clear()
		{
			this._members.Clear();
		}

		// Token: 0x0600016D RID: 365 RVA: 0x00007E85 File Offset: 0x00006085
		public bool Contains(KeyValuePair<string, object> item)
		{
			return this._members.ContainsKey(item.Key) && this._members[item.Key] == item.Value;
		}

		// Token: 0x0600016E RID: 366 RVA: 0x00007EB8 File Offset: 0x000060B8
		public void CopyTo(KeyValuePair<string, object>[] array, int arrayIndex)
		{
			if (array == null)
			{
				throw new ArgumentNullException("array");
			}
			int num = this.Count;
			foreach (KeyValuePair<string, object> keyValuePair in this)
			{
				array[arrayIndex++] = keyValuePair;
				if (--num <= 0)
				{
					break;
				}
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x0600016F RID: 367 RVA: 0x00007F28 File Offset: 0x00006128
		public int Count
		{
			get
			{
				return this._members.Count;
			}
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x06000170 RID: 368 RVA: 0x00007F35 File Offset: 0x00006135
		public bool IsReadOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x06000171 RID: 369 RVA: 0x00007F38 File Offset: 0x00006138
		public bool Remove(KeyValuePair<string, object> item)
		{
			return this._members.Remove(item.Key);
		}

		// Token: 0x06000172 RID: 370 RVA: 0x00007F4C File Offset: 0x0000614C
		public IEnumerator<KeyValuePair<string, object>> GetEnumerator()
		{
			return this._members.GetEnumerator();
		}

		// Token: 0x06000173 RID: 371 RVA: 0x00007F5E File Offset: 0x0000615E
		IEnumerator IEnumerable.GetEnumerator()
		{
			return this._members.GetEnumerator();
		}

		// Token: 0x06000174 RID: 372 RVA: 0x00007F70 File Offset: 0x00006170
		public override string ToString()
		{
			return SimpleJson.SerializeObject(this);
		}

		// Token: 0x040000E6 RID: 230
		private readonly Dictionary<string, object> _members;
	}
}
