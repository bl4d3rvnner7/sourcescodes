﻿using System;

namespace SHARP
{
	// Token: 0x0200003E RID: 62
	internal struct TokenResponseJsonFormat
	{
		// Token: 0x17000023 RID: 35
		// (get) Token: 0x0600011C RID: 284 RVA: 0x0000682D File Offset: 0x00004A2D
		// (set) Token: 0x0600011D RID: 285 RVA: 0x00006835 File Offset: 0x00004A35
		internal string id { get; set; }

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x0600011E RID: 286 RVA: 0x0000683E File Offset: 0x00004A3E
		// (set) Token: 0x0600011F RID: 287 RVA: 0x00006846 File Offset: 0x00004A46
		internal string username { get; set; }

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x06000120 RID: 288 RVA: 0x0000684F File Offset: 0x00004A4F
		// (set) Token: 0x06000121 RID: 289 RVA: 0x00006857 File Offset: 0x00004A57
		internal string discriminator { get; set; }

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x06000122 RID: 290 RVA: 0x00006860 File Offset: 0x00004A60
		// (set) Token: 0x06000123 RID: 291 RVA: 0x00006868 File Offset: 0x00004A68
		internal bool mfa_enabled { get; set; }

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x06000124 RID: 292 RVA: 0x00006871 File Offset: 0x00004A71
		// (set) Token: 0x06000125 RID: 293 RVA: 0x00006879 File Offset: 0x00004A79
		internal int premium_type { get; set; }

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x06000126 RID: 294 RVA: 0x00006882 File Offset: 0x00004A82
		// (set) Token: 0x06000127 RID: 295 RVA: 0x0000688A File Offset: 0x00004A8A
		internal string email { get; set; }

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x06000128 RID: 296 RVA: 0x00006893 File Offset: 0x00004A93
		// (set) Token: 0x06000129 RID: 297 RVA: 0x0000689B File Offset: 0x00004A9B
		internal bool verified { get; set; }

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x0600012A RID: 298 RVA: 0x000068A4 File Offset: 0x00004AA4
		// (set) Token: 0x0600012B RID: 299 RVA: 0x000068AC File Offset: 0x00004AAC
		internal string phone { get; set; }
	}
}
