﻿using System;
using System.IO;
using System.Linq;

namespace SHARP
{
	// Token: 0x02000049 RID: 73
	internal sealed class Filemanager
	{
		// Token: 0x06000150 RID: 336 RVA: 0x000075F0 File Offset: 0x000057F0
		public static void RecursiveDelete(string path)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(path);
			if (!directoryInfo.Exists)
			{
				return;
			}
			DirectoryInfo[] directories = directoryInfo.GetDirectories();
			for (int i = 0; i < directories.Length; i++)
			{
				Filemanager.RecursiveDelete(directories[i].FullName);
			}
			directoryInfo.Delete(true);
		}

		// Token: 0x06000151 RID: 337 RVA: 0x00007638 File Offset: 0x00005838
		public static void CopyDirectory(string sourceFolder, string destFolder)
		{
			try
			{
				if (!Directory.Exists(destFolder))
				{
					Directory.CreateDirectory(destFolder);
				}
				foreach (string text in Directory.GetFiles(sourceFolder))
				{
					string fileName = Path.GetFileName(text);
					string destFileName = Path.Combine(destFolder, fileName);
					File.Copy(text, destFileName);
				}
				foreach (string text2 in Directory.GetDirectories(sourceFolder))
				{
					string fileName2 = Path.GetFileName(text2);
					string destFolder2 = Path.Combine(destFolder, fileName2);
					Filemanager.CopyDirectory(text2, destFolder2);
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}

		// Token: 0x06000152 RID: 338 RVA: 0x000076CC File Offset: 0x000058CC
		public static long DirectorySize(string path)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(path);
			return directoryInfo.GetFiles().Sum((FileInfo fi) => fi.Length) + directoryInfo.GetDirectories().Sum((DirectoryInfo di) => Filemanager.DirectorySize(di.FullName));
		}
	}
}
