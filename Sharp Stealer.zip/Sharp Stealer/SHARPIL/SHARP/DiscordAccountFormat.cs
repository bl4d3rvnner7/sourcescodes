﻿using System;

namespace SHARP
{
	// Token: 0x0200003A RID: 58
	internal struct DiscordAccountFormat
	{
		// Token: 0x06000114 RID: 276 RVA: 0x00006790 File Offset: 0x00004990
		internal DiscordAccountFormat(string username, string userId, bool mfa, string email, string phoneNumber, bool verified, string nitro, string[] billingType, string token, GiftFormat[] gifts)
		{
			this.Username = username;
			this.UserId = userId;
			this.Mfa = mfa;
			this.Email = email;
			this.PhoneNumber = phoneNumber;
			this.Verified = verified;
			this.Nitro = nitro;
			this.BillingType = billingType;
			this.Token = token;
			this.Gift = gifts;
		}

		// Token: 0x0400008B RID: 139
		internal readonly string Username;

		// Token: 0x0400008C RID: 140
		internal readonly string UserId;

		// Token: 0x0400008D RID: 141
		internal readonly bool Mfa;

		// Token: 0x0400008E RID: 142
		internal readonly string Email;

		// Token: 0x0400008F RID: 143
		internal readonly string PhoneNumber;

		// Token: 0x04000090 RID: 144
		internal readonly bool Verified;

		// Token: 0x04000091 RID: 145
		internal readonly string Nitro;

		// Token: 0x04000092 RID: 146
		internal readonly string[] BillingType;

		// Token: 0x04000093 RID: 147
		internal readonly string Token;

		// Token: 0x04000094 RID: 148
		internal readonly GiftFormat[] Gift;
	}
}
