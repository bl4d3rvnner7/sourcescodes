﻿using System;
using System.Runtime.InteropServices;

namespace SHARP
{
	// Token: 0x02000011 RID: 17
	internal sealed class WinApi
	{
		// Token: 0x06000069 RID: 105
		[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
		internal static extern IntPtr LoadLibrary(string sFileName);

		// Token: 0x0600006A RID: 106
		[DllImport("kernel32.dll", SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		internal static extern bool FreeLibrary(IntPtr hModule);

		// Token: 0x0600006B RID: 107
		[DllImport("kernel32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
		internal static extern IntPtr GetProcAddress(IntPtr hModule, string sProcName);
	}
}
