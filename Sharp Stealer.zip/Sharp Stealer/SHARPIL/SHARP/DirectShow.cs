﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Security;

namespace SHARP
{
	// Token: 0x02000054 RID: 84
	internal static class DirectShow
	{
		// Token: 0x060001CD RID: 461 RVA: 0x0000B635 File Offset: 0x00009835
		public static object CoCreateInstance(Guid clsid)
		{
			return Activator.CreateInstance(Type.GetTypeFromCLSID(clsid));
		}

		// Token: 0x060001CE RID: 462 RVA: 0x0000B642 File Offset: 0x00009842
		public static void ReleaseInstance<T>(ref T com) where T : class
		{
			if (com != null)
			{
				Marshal.ReleaseComObject(com);
				com = default(T);
			}
		}

		// Token: 0x060001CF RID: 463 RVA: 0x0000B669 File Offset: 0x00009869
		public static DirectShow.IGraphBuilder CreateGraph()
		{
			return DirectShow.CoCreateInstance(DirectShow.DsGuid.CLSID_FilterGraph) as DirectShow.IGraphBuilder;
		}

		// Token: 0x060001D0 RID: 464 RVA: 0x0000B67C File Offset: 0x0000987C
		public static void PlayGraph(DirectShow.IGraphBuilder graph, DirectShow.FILTER_STATE state)
		{
			DirectShow.IMediaControl mediaControl = graph as DirectShow.IMediaControl;
			if (mediaControl == null)
			{
				return;
			}
			if (state == DirectShow.FILTER_STATE.Stopped)
			{
				mediaControl.Stop();
				return;
			}
			if (state == DirectShow.FILTER_STATE.Paused)
			{
				mediaControl.Pause();
				return;
			}
			mediaControl.Run();
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x0000B6B4 File Offset: 0x000098B4
		public static List<string> GetFiltes(Guid category)
		{
			List<string> result = new List<string>();
			DirectShow.EnumMonikers(category, delegate(IMoniker moniker, DirectShow.IPropertyBag prop)
			{
				object obj = null;
				prop.Read("FriendlyName", ref obj, 0);
				string item = (string)obj;
				result.Add(item);
				return false;
			});
			return result;
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x0000B6EA File Offset: 0x000098EA
		public static DirectShow.IBaseFilter CreateFilter(Guid clsid)
		{
			return DirectShow.CoCreateInstance(clsid) as DirectShow.IBaseFilter;
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x0000B6F8 File Offset: 0x000098F8
		public static DirectShow.IBaseFilter CreateFilter(Guid category, int index)
		{
			DirectShow.IBaseFilter result = null;
			int curr_index = 0;
			DirectShow.EnumMonikers(category, delegate(IMoniker moniker, DirectShow.IPropertyBag prop)
			{
				int index2 = index;
				int curr_index = curr_index;
				curr_index++;
				if (index2 != curr_index)
				{
					return false;
				}
				object obj = null;
				Guid iid_IBaseFilter = DirectShow.DsGuid.IID_IBaseFilter;
				moniker.BindToObject(null, null, ref iid_IBaseFilter, out obj);
				result = (obj as DirectShow.IBaseFilter);
				return true;
			});
			if (result == null)
			{
				throw new ArgumentException("can't create filter.");
			}
			return result;
		}

		// Token: 0x060001D4 RID: 468 RVA: 0x0000B74C File Offset: 0x0000994C
		private static void EnumMonikers(Guid category, Func<IMoniker, DirectShow.IPropertyBag, bool> func)
		{
			IEnumMoniker enumMoniker = null;
			DirectShow.ICreateDevEnum createDevEnum = null;
			try
			{
				createDevEnum = (DirectShow.ICreateDevEnum)Activator.CreateInstance(Type.GetTypeFromCLSID(DirectShow.DsGuid.CLSID_SystemDeviceEnum));
				createDevEnum.CreateClassEnumerator(ref category, ref enumMoniker, 0);
				if (enumMoniker != null)
				{
					IMoniker[] array = new IMoniker[1];
					IntPtr zero = IntPtr.Zero;
					while (enumMoniker.Next(array.Length, array, zero) == 0)
					{
						IMoniker moniker = array[0];
						object obj = null;
						Guid iid_IPropertyBag = DirectShow.DsGuid.IID_IPropertyBag;
						moniker.BindToStorage(null, null, ref iid_IPropertyBag, out obj);
						DirectShow.IPropertyBag propertyBag = (DirectShow.IPropertyBag)obj;
						try
						{
							if (func(moniker, propertyBag))
							{
								break;
							}
						}
						finally
						{
							Marshal.ReleaseComObject(propertyBag);
							if (moniker != null)
							{
								Marshal.ReleaseComObject(moniker);
							}
						}
					}
				}
			}
			finally
			{
				if (enumMoniker != null)
				{
					Marshal.ReleaseComObject(enumMoniker);
				}
				if (createDevEnum != null)
				{
					Marshal.ReleaseComObject(createDevEnum);
				}
			}
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x0000B81C File Offset: 0x00009A1C
		public static DirectShow.IPin FindPin(DirectShow.IBaseFilter filter, string name)
		{
			DirectShow.IPin pin2 = DirectShow.EnumPins(filter, (DirectShow.IPin pin, DirectShow.PIN_INFO info) => info.achName == name);
			if (pin2 == null)
			{
				throw new ArgumentException("can't fild pin.");
			}
			return pin2;
		}

		// Token: 0x060001D6 RID: 470 RVA: 0x0000B858 File Offset: 0x00009A58
		public static DirectShow.IPin FindPin(DirectShow.IBaseFilter filter, int index, DirectShow.PIN_DIRECTION direction)
		{
			int curr_index = 0;
			DirectShow.IPin pin2 = DirectShow.EnumPins(filter, delegate(DirectShow.IPin pin, DirectShow.PIN_INFO info)
			{
				if (info.dir != direction)
				{
					return false;
				}
				int index2 = index;
				int curr_index = curr_index;
				curr_index++;
				return index2 == curr_index;
			});
			if (pin2 == null)
			{
				throw new ArgumentException("can't fild pin.");
			}
			return pin2;
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x0000B8A0 File Offset: 0x00009AA0
		public static DirectShow.IPin FindPin(DirectShow.IBaseFilter filter, int index, DirectShow.PIN_DIRECTION direction, Guid category)
		{
			int curr_index = 0;
			DirectShow.IPin pin2 = DirectShow.EnumPins(filter, delegate(DirectShow.IPin pin, DirectShow.PIN_INFO info)
			{
				if (info.dir != direction)
				{
					return false;
				}
				if (DirectShow.GetPinCategory(pin) != category)
				{
					return false;
				}
				int index2 = index;
				int curr_index = curr_index;
				curr_index++;
				return index2 == curr_index;
			});
			if (pin2 == null)
			{
				throw new ArgumentException("can't fild pin.");
			}
			return pin2;
		}

		// Token: 0x060001D8 RID: 472 RVA: 0x0000B8F0 File Offset: 0x00009AF0
		private static Guid GetPinCategory(DirectShow.IPin pPin)
		{
			DirectShow.IKsPropertySet ksPropertySet = pPin as DirectShow.IKsPropertySet;
			if (ksPropertySet == null)
			{
				return Guid.Empty;
			}
			int num = Marshal.SizeOf(typeof(Guid));
			IntPtr intPtr = Marshal.AllocCoTaskMem(num);
			Guid result;
			try
			{
				int num2;
				if (ksPropertySet.Get(DirectShow.DsGuid.AMPROPSETID_PIN, 0, IntPtr.Zero, 0, intPtr, num, out num2) < 0)
				{
					result = Guid.Empty;
				}
				else
				{
					result = (Guid)Marshal.PtrToStructure(intPtr, typeof(Guid));
				}
			}
			finally
			{
				Marshal.FreeCoTaskMem(intPtr);
			}
			return result;
		}

		// Token: 0x060001D9 RID: 473 RVA: 0x0000B978 File Offset: 0x00009B78
		private static DirectShow.IPin EnumPins(DirectShow.IBaseFilter filter, Func<DirectShow.IPin, DirectShow.PIN_INFO, bool> func)
		{
			DirectShow.IEnumPins enumPins = null;
			DirectShow.IPin pin = null;
			try
			{
				filter.EnumPins(ref enumPins);
				int num = 0;
				while (enumPins.Next(1, ref pin, ref num) == 0 && num != 0)
				{
					DirectShow.PIN_INFO pin_INFO = new DirectShow.PIN_INFO();
					try
					{
						pin.QueryPinInfo(pin_INFO);
						if (func(pin, pin_INFO))
						{
							return pin;
						}
					}
					finally
					{
						if (pin_INFO.pFilter != null)
						{
							Marshal.ReleaseComObject(pin_INFO.pFilter);
						}
					}
				}
			}
			catch
			{
				if (pin != null)
				{
					Marshal.ReleaseComObject(pin);
				}
				throw;
			}
			finally
			{
				if (enumPins != null)
				{
					Marshal.ReleaseComObject(enumPins);
				}
			}
			return null;
		}

		// Token: 0x060001DA RID: 474 RVA: 0x0000BA20 File Offset: 0x00009C20
		public static void ConnectFilter(DirectShow.IGraphBuilder graph, DirectShow.IBaseFilter out_flt, int out_no, DirectShow.IBaseFilter in_flt, int in_no)
		{
			DirectShow.IPin ppinOut = DirectShow.FindPin(out_flt, out_no, DirectShow.PIN_DIRECTION.PINDIR_OUTPUT);
			DirectShow.IPin ppinIn = DirectShow.FindPin(in_flt, in_no, DirectShow.PIN_DIRECTION.PINDIR_INPUT);
			graph.Connect(ppinOut, ppinIn);
		}

		// Token: 0x060001DB RID: 475 RVA: 0x0000BA49 File Offset: 0x00009C49
		public static void DeleteMediaType(ref DirectShow.AM_MEDIA_TYPE mt)
		{
			if (mt.lSampleSize != 0U)
			{
				Marshal.FreeCoTaskMem(mt.pbFormat);
			}
			if (mt.pUnk != IntPtr.Zero)
			{
				Marshal.FreeCoTaskMem(mt.pUnk);
			}
			mt = null;
		}

		// Token: 0x02000116 RID: 278
		[ComVisible(true)]
		[Guid("56a8689f-0ad4-11ce-b03a-0020af0ba770")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IFilterGraph
		{
			// Token: 0x060003FC RID: 1020
			int AddFilter([In] DirectShow.IBaseFilter pFilter, [MarshalAs(UnmanagedType.LPWStr)] [In] string pName);

			// Token: 0x060003FD RID: 1021
			int RemoveFilter([In] DirectShow.IBaseFilter pFilter);

			// Token: 0x060003FE RID: 1022
			int EnumFilters([In] [Out] ref DirectShow.IEnumFilters ppEnum);

			// Token: 0x060003FF RID: 1023
			int FindFilterByName([MarshalAs(UnmanagedType.LPWStr)] [In] string pName, [In] [Out] ref DirectShow.IBaseFilter ppFilter);

			// Token: 0x06000400 RID: 1024
			int ConnectDirect([In] DirectShow.IPin ppinOut, [In] DirectShow.IPin ppinIn, [MarshalAs(UnmanagedType.LPStruct)] [In] DirectShow.AM_MEDIA_TYPE pmt);

			// Token: 0x06000401 RID: 1025
			int Reconnect([In] DirectShow.IPin ppin);

			// Token: 0x06000402 RID: 1026
			int Disconnect([In] DirectShow.IPin ppin);

			// Token: 0x06000403 RID: 1027
			int SetDefaultSyncSource();
		}

		// Token: 0x02000117 RID: 279
		[ComVisible(true)]
		[Guid("56a868a9-0ad4-11ce-b03a-0020af0ba770")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IGraphBuilder : DirectShow.IFilterGraph
		{
			// Token: 0x06000404 RID: 1028
			int Connect([In] DirectShow.IPin ppinOut, [In] DirectShow.IPin ppinIn);

			// Token: 0x06000405 RID: 1029
			int Render([In] DirectShow.IPin ppinOut);

			// Token: 0x06000406 RID: 1030
			int RenderFile([MarshalAs(UnmanagedType.LPWStr)] [In] string lpcwstrFile, [MarshalAs(UnmanagedType.LPWStr)] [In] string lpcwstrPlayList);

			// Token: 0x06000407 RID: 1031
			int AddSourceFilter([MarshalAs(UnmanagedType.LPWStr)] [In] string lpcwstrFileName, [MarshalAs(UnmanagedType.LPWStr)] [In] string lpcwstrFilterName, [In] [Out] ref DirectShow.IBaseFilter ppFilter);

			// Token: 0x06000408 RID: 1032
			int SetLogFile(IntPtr hFile);

			// Token: 0x06000409 RID: 1033
			int Abort();

			// Token: 0x0600040A RID: 1034
			int ShouldOperationContinue();
		}

		// Token: 0x02000118 RID: 280
		[ComVisible(true)]
		[Guid("56a868b1-0ad4-11ce-b03a-0020af0ba770")]
		[InterfaceType(ComInterfaceType.InterfaceIsDual)]
		[ComImport]
		public interface IMediaControl
		{
			// Token: 0x0600040B RID: 1035
			int Run();

			// Token: 0x0600040C RID: 1036
			int Pause();

			// Token: 0x0600040D RID: 1037
			int Stop();

			// Token: 0x0600040E RID: 1038
			int GetState(int msTimeout, out int pfs);

			// Token: 0x0600040F RID: 1039
			int RenderFile(string strFilename);

			// Token: 0x06000410 RID: 1040
			int AddSourceFilter([In] string strFilename, [MarshalAs(UnmanagedType.IDispatch)] [In] [Out] ref object ppUnk);

			// Token: 0x06000411 RID: 1041
			int get_FilterCollection([MarshalAs(UnmanagedType.IDispatch)] [In] [Out] ref object ppUnk);

			// Token: 0x06000412 RID: 1042
			int get_RegFilterCollection([MarshalAs(UnmanagedType.IDispatch)] [In] [Out] ref object ppUnk);

			// Token: 0x06000413 RID: 1043
			int StopWhenReady();
		}

		// Token: 0x02000119 RID: 281
		[ComVisible(true)]
		[Guid("93E5A4E0-2D50-11d2-ABFA-00A0C9C6E38D")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface ICaptureGraphBuilder2
		{
			// Token: 0x06000414 RID: 1044
			int SetFiltergraph([In] DirectShow.IGraphBuilder pfg);

			// Token: 0x06000415 RID: 1045
			int GetFiltergraph([In] [Out] ref DirectShow.IGraphBuilder ppfg);

			// Token: 0x06000416 RID: 1046
			int SetOutputFileName([In] ref Guid pType, [MarshalAs(UnmanagedType.LPWStr)] [In] string lpstrFile, [In] [Out] ref DirectShow.IBaseFilter ppbf, [In] [Out] ref DirectShow.IFileSinkFilter ppSink);

			// Token: 0x06000417 RID: 1047
			int FindInterface([In] ref Guid pCategory, [In] ref Guid pType, [In] DirectShow.IBaseFilter pbf, [In] IntPtr riid, [MarshalAs(UnmanagedType.IUnknown)] [In] [Out] ref object ppint);

			// Token: 0x06000418 RID: 1048
			int RenderStream([In] ref Guid pCategory, [In] ref Guid pType, [MarshalAs(UnmanagedType.IUnknown)] [In] object pSource, [In] DirectShow.IBaseFilter pfCompressor, [In] DirectShow.IBaseFilter pfRenderer);

			// Token: 0x06000419 RID: 1049
			int ControlStream([In] ref Guid pCategory, [In] ref Guid pType, [In] DirectShow.IBaseFilter pFilter, [In] IntPtr pstart, [In] IntPtr pstop, [In] short wStartCookie, [In] short wStopCookie);

			// Token: 0x0600041A RID: 1050
			int AllocCapFile([MarshalAs(UnmanagedType.LPWStr)] [In] string lpstrFile, [In] long dwlSize);

			// Token: 0x0600041B RID: 1051
			int CopyCaptureFile([MarshalAs(UnmanagedType.LPWStr)] [In] string lpwstrOld, [MarshalAs(UnmanagedType.LPWStr)] [In] string lpwstrNew, [In] int fAllowEscAbort, [In] DirectShow.IAMCopyCaptureFileProgress pFilter);

			// Token: 0x0600041C RID: 1052
			int FindPin([In] object pSource, [In] int pindir, [In] ref Guid pCategory, [In] ref Guid pType, [MarshalAs(UnmanagedType.Bool)] [In] bool fUnconnected, [In] int num, out IntPtr ppPin);
		}

		// Token: 0x0200011A RID: 282
		[ComVisible(true)]
		[Guid("a2104830-7c70-11cf-8bce-00aa00a3f1a6")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IFileSinkFilter
		{
			// Token: 0x0600041D RID: 1053
			int SetFileName([MarshalAs(UnmanagedType.LPWStr)] [In] string pszFileName, [MarshalAs(UnmanagedType.LPStruct)] [In] DirectShow.AM_MEDIA_TYPE pmt);

			// Token: 0x0600041E RID: 1054
			int GetCurFile([MarshalAs(UnmanagedType.LPWStr)] [In] [Out] ref string pszFileName, [MarshalAs(UnmanagedType.LPStruct)] out DirectShow.AM_MEDIA_TYPE pmt);
		}

		// Token: 0x0200011B RID: 283
		[ComVisible(true)]
		[Guid("670d1d20-a068-11d0-b3f0-00aa003761c5")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IAMCopyCaptureFileProgress
		{
			// Token: 0x0600041F RID: 1055
			int Progress(int iProgress);
		}

		// Token: 0x0200011C RID: 284
		[ComVisible(true)]
		[Guid("C6E13370-30AC-11d0-A18C-00A0C9118956")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IAMCameraControl
		{
			// Token: 0x06000420 RID: 1056
			int GetRange([In] DirectShow.CameraControlProperty Property, [In] [Out] ref int pMin, [In] [Out] ref int pMax, [In] [Out] ref int pSteppingDelta, [In] [Out] ref int pDefault, [In] [Out] ref int pCapsFlag);

			// Token: 0x06000421 RID: 1057
			int Set([In] DirectShow.CameraControlProperty Property, [In] int lValue, [In] int Flags);

			// Token: 0x06000422 RID: 1058
			int Get([In] DirectShow.CameraControlProperty Property, [In] [Out] ref int lValue, [In] [Out] ref int Flags);
		}

		// Token: 0x0200011D RID: 285
		[ComVisible(true)]
		[Guid("C6E13360-30AC-11d0-A18C-00A0C9118956")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IAMVideoProcAmp
		{
			// Token: 0x06000423 RID: 1059
			int GetRange([In] DirectShow.VideoProcAmpProperty Property, [In] [Out] ref int pMin, [In] [Out] ref int pMax, [In] [Out] ref int pSteppingDelta, [In] [Out] ref int pDefault, [In] [Out] ref int pCapsFlag);

			// Token: 0x06000424 RID: 1060
			int Set([In] DirectShow.VideoProcAmpProperty Property, [In] int lValue, [In] int Flags);

			// Token: 0x06000425 RID: 1061
			int Get([In] DirectShow.VideoProcAmpProperty Property, [In] [Out] ref int lValue, [In] [Out] ref int Flags);
		}

		// Token: 0x0200011E RID: 286
		[ComVisible(true)]
		[Guid("6A2E0670-28E4-11D0-A18C-00A0C9118956")]
		[SuppressUnmanagedCodeSecurity]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IAMVideoControl
		{
			// Token: 0x06000426 RID: 1062
			int GetCaps([In] DirectShow.IPin pPin, out DirectShow.VideoControlFlags pCapsFlags);

			// Token: 0x06000427 RID: 1063
			int SetMode([In] DirectShow.IPin pPin, [In] DirectShow.VideoControlFlags Mode);

			// Token: 0x06000428 RID: 1064
			int GetMode([In] DirectShow.IPin pPin, out DirectShow.VideoControlFlags Mode);

			// Token: 0x06000429 RID: 1065
			int GetCurrentActualFrameRate([In] DirectShow.IPin pPin, out long ActualFrameRate);

			// Token: 0x0600042A RID: 1066
			int GetMaxAvailableFrameRate([In] DirectShow.IPin pPin, [In] int iIndex, [In] Size Dimensions, out long MaxAvailableFrameRate);

			// Token: 0x0600042B RID: 1067
			int GetFrameRateList([In] DirectShow.IPin pPin, [In] int iIndex, [In] Size Dimensions, out int ListSize, out IntPtr FrameRates);
		}

		// Token: 0x0200011F RID: 287
		[ComVisible(true)]
		[Guid("31EFAC30-515C-11d0-A9AA-00AA0061BE93")]
		[SuppressUnmanagedCodeSecurity]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IKsPropertySet
		{
			// Token: 0x0600042C RID: 1068
			[PreserveSig]
			int Set([MarshalAs(UnmanagedType.LPStruct)] [In] Guid guidPropSet, [In] int dwPropID, [In] IntPtr pInstanceData, [In] int cbInstanceData, [In] IntPtr pPropData, [In] int cbPropData);

			// Token: 0x0600042D RID: 1069
			[PreserveSig]
			int Get([MarshalAs(UnmanagedType.LPStruct)] [In] Guid guidPropSet, [In] int dwPropID, [In] IntPtr pInstanceData, [In] int cbInstanceData, [In] [Out] IntPtr pPropData, [In] int cbPropData, out int pcbReturned);

			// Token: 0x0600042E RID: 1070
			[PreserveSig]
			int QuerySupported([MarshalAs(UnmanagedType.LPStruct)] [In] Guid guidPropSet, [In] int dwPropID, out int pTypeSupport);
		}

		// Token: 0x02000120 RID: 288
		[ComVisible(true)]
		[Guid("56a86895-0ad4-11ce-b03a-0020af0ba770")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IBaseFilter
		{
			// Token: 0x0600042F RID: 1071
			int GetClassID(out Guid pClassID);

			// Token: 0x06000430 RID: 1072
			int Stop();

			// Token: 0x06000431 RID: 1073
			int Pause();

			// Token: 0x06000432 RID: 1074
			int Run(long tStart);

			// Token: 0x06000433 RID: 1075
			int GetState(int dwMilliSecsTimeout, [In] [Out] ref int filtState);

			// Token: 0x06000434 RID: 1076
			int SetSyncSource([In] DirectShow.IReferenceClock pClock);

			// Token: 0x06000435 RID: 1077
			int GetSyncSource([In] [Out] ref DirectShow.IReferenceClock pClock);

			// Token: 0x06000436 RID: 1078
			int EnumPins([In] [Out] ref DirectShow.IEnumPins ppEnum);

			// Token: 0x06000437 RID: 1079
			int FindPin([MarshalAs(UnmanagedType.LPWStr)] [In] string Id, [In] [Out] ref DirectShow.IPin ppPin);

			// Token: 0x06000438 RID: 1080
			int QueryFilterInfo([Out] DirectShow.FILTER_INFO pInfo);

			// Token: 0x06000439 RID: 1081
			int JoinFilterGraph([In] DirectShow.IFilterGraph pGraph, [MarshalAs(UnmanagedType.LPWStr)] [In] string pName);

			// Token: 0x0600043A RID: 1082
			int QueryVendorInfo([MarshalAs(UnmanagedType.LPWStr)] [In] [Out] ref string pVendorInfo);
		}

		// Token: 0x02000121 RID: 289
		[ComVisible(true)]
		[Guid("56a86893-0ad4-11ce-b03a-0020af0ba770")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IEnumFilters
		{
			// Token: 0x0600043B RID: 1083
			int Next([In] int cFilters, [In] [Out] ref DirectShow.IBaseFilter ppFilter, [In] [Out] ref int pcFetched);

			// Token: 0x0600043C RID: 1084
			int Skip([In] int cFilters);

			// Token: 0x0600043D RID: 1085
			void Reset();

			// Token: 0x0600043E RID: 1086
			void Clone([In] [Out] ref DirectShow.IEnumFilters ppEnum);
		}

		// Token: 0x02000122 RID: 290
		[ComVisible(true)]
		[Guid("C6E13340-30AC-11d0-A18C-00A0C9118956")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IAMStreamConfig
		{
			// Token: 0x0600043F RID: 1087
			int SetFormat([MarshalAs(UnmanagedType.LPStruct)] [In] DirectShow.AM_MEDIA_TYPE pmt);

			// Token: 0x06000440 RID: 1088
			int GetFormat([MarshalAs(UnmanagedType.LPStruct)] [In] [Out] ref DirectShow.AM_MEDIA_TYPE ppmt);

			// Token: 0x06000441 RID: 1089
			int GetNumberOfCapabilities(ref int piCount, ref int piSize);

			// Token: 0x06000442 RID: 1090
			int GetStreamCaps(int iIndex, [MarshalAs(UnmanagedType.LPStruct)] [In] [Out] ref DirectShow.AM_MEDIA_TYPE ppmt, IntPtr pSCC);
		}

		// Token: 0x02000123 RID: 291
		[ComVisible(true)]
		[Guid("56a8689a-0ad4-11ce-b03a-0020af0ba770")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IMediaSample
		{
			// Token: 0x06000443 RID: 1091
			int GetPointer(ref IntPtr ppBuffer);

			// Token: 0x06000444 RID: 1092
			int GetSize();

			// Token: 0x06000445 RID: 1093
			int GetTime(ref long pTimeStart, ref long pTimeEnd);

			// Token: 0x06000446 RID: 1094
			int SetTime([MarshalAs(UnmanagedType.LPStruct)] [In] ulong pTimeStart, [MarshalAs(UnmanagedType.LPStruct)] [In] ulong pTimeEnd);

			// Token: 0x06000447 RID: 1095
			int IsSyncPoint();

			// Token: 0x06000448 RID: 1096
			int SetSyncPoint([MarshalAs(UnmanagedType.Bool)] [In] bool bIsSyncPoint);

			// Token: 0x06000449 RID: 1097
			int IsPreroll();

			// Token: 0x0600044A RID: 1098
			int SetPreroll([MarshalAs(UnmanagedType.Bool)] [In] bool bIsPreroll);

			// Token: 0x0600044B RID: 1099
			int GetActualDataLength();

			// Token: 0x0600044C RID: 1100
			int SetActualDataLength(int len);

			// Token: 0x0600044D RID: 1101
			int GetMediaType([MarshalAs(UnmanagedType.LPStruct)] [In] [Out] ref DirectShow.AM_MEDIA_TYPE ppMediaType);

			// Token: 0x0600044E RID: 1102
			int SetMediaType([MarshalAs(UnmanagedType.LPStruct)] [In] DirectShow.AM_MEDIA_TYPE pMediaType);

			// Token: 0x0600044F RID: 1103
			int IsDiscontinuity();

			// Token: 0x06000450 RID: 1104
			int SetDiscontinuity([MarshalAs(UnmanagedType.Bool)] [In] bool bDiscontinuity);

			// Token: 0x06000451 RID: 1105
			int GetMediaTime(ref long pTimeStart, ref long pTimeEnd);

			// Token: 0x06000452 RID: 1106
			int SetMediaTime([MarshalAs(UnmanagedType.LPStruct)] [In] ulong pTimeStart, [MarshalAs(UnmanagedType.LPStruct)] [In] ulong pTimeEnd);
		}

		// Token: 0x02000124 RID: 292
		[ComVisible(true)]
		[Guid("89c31040-846b-11ce-97d3-00aa0055595a")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IEnumMediaTypes
		{
			// Token: 0x06000453 RID: 1107
			int Next([In] int cMediaTypes, [MarshalAs(UnmanagedType.LPStruct)] [In] [Out] ref DirectShow.AM_MEDIA_TYPE ppMediaTypes, [In] [Out] ref int pcFetched);

			// Token: 0x06000454 RID: 1108
			int Skip([In] int cMediaTypes);

			// Token: 0x06000455 RID: 1109
			int Reset();

			// Token: 0x06000456 RID: 1110
			int Clone([In] [Out] ref DirectShow.IEnumMediaTypes ppEnum);
		}

		// Token: 0x02000125 RID: 293
		[ComVisible(true)]
		[Guid("56a86891-0ad4-11ce-b03a-0020af0ba770")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IPin
		{
			// Token: 0x06000457 RID: 1111
			int Connect([In] DirectShow.IPin pReceivePin, [MarshalAs(UnmanagedType.LPStruct)] [In] DirectShow.AM_MEDIA_TYPE pmt);

			// Token: 0x06000458 RID: 1112
			int ReceiveConnection([In] DirectShow.IPin pReceivePin, [MarshalAs(UnmanagedType.LPStruct)] [In] DirectShow.AM_MEDIA_TYPE pmt);

			// Token: 0x06000459 RID: 1113
			int Disconnect();

			// Token: 0x0600045A RID: 1114
			int ConnectedTo([In] [Out] ref DirectShow.IPin ppPin);

			// Token: 0x0600045B RID: 1115
			int ConnectionMediaType([MarshalAs(UnmanagedType.LPStruct)] [Out] DirectShow.AM_MEDIA_TYPE pmt);

			// Token: 0x0600045C RID: 1116
			int QueryPinInfo([Out] DirectShow.PIN_INFO pInfo);

			// Token: 0x0600045D RID: 1117
			int QueryDirection(ref DirectShow.PIN_DIRECTION pPinDir);

			// Token: 0x0600045E RID: 1118
			int QueryId([MarshalAs(UnmanagedType.LPWStr)] [In] [Out] ref string Id);

			// Token: 0x0600045F RID: 1119
			int QueryAccept([MarshalAs(UnmanagedType.LPStruct)] [In] DirectShow.AM_MEDIA_TYPE pmt);

			// Token: 0x06000460 RID: 1120
			int EnumMediaTypes([In] [Out] ref DirectShow.IEnumMediaTypes ppEnum);

			// Token: 0x06000461 RID: 1121
			int QueryInternalConnections(IntPtr apPin, [In] [Out] ref int nPin);

			// Token: 0x06000462 RID: 1122
			int EndOfStream();

			// Token: 0x06000463 RID: 1123
			int BeginFlush();

			// Token: 0x06000464 RID: 1124
			int EndFlush();

			// Token: 0x06000465 RID: 1125
			int NewSegment(long tStart, long tStop, double dRate);
		}

		// Token: 0x02000126 RID: 294
		[ComVisible(true)]
		[Guid("56a86892-0ad4-11ce-b03a-0020af0ba770")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IEnumPins
		{
			// Token: 0x06000466 RID: 1126
			int Next([In] int cPins, [In] [Out] ref DirectShow.IPin ppPins, [In] [Out] ref int pcFetched);

			// Token: 0x06000467 RID: 1127
			int Skip([In] int cPins);

			// Token: 0x06000468 RID: 1128
			void Reset();

			// Token: 0x06000469 RID: 1129
			void Clone([In] [Out] ref DirectShow.IEnumPins ppEnum);
		}

		// Token: 0x02000127 RID: 295
		[ComVisible(true)]
		[Guid("56a86897-0ad4-11ce-b03a-0020af0ba770")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IReferenceClock
		{
			// Token: 0x0600046A RID: 1130
			int GetTime(ref long pTime);

			// Token: 0x0600046B RID: 1131
			int AdviseTime(long baseTime, long streamTime, IntPtr hEvent, ref int pdwAdviseCookie);

			// Token: 0x0600046C RID: 1132
			int AdvisePeriodic(long startTime, long periodTime, IntPtr hSemaphore, ref int pdwAdviseCookie);

			// Token: 0x0600046D RID: 1133
			int Unadvise(int dwAdviseCookie);
		}

		// Token: 0x02000128 RID: 296
		[ComVisible(true)]
		[Guid("29840822-5B84-11D0-BD3B-00A0C911CE86")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface ICreateDevEnum
		{
			// Token: 0x0600046E RID: 1134
			int CreateClassEnumerator([In] ref Guid pType, [In] [Out] ref IEnumMoniker ppEnumMoniker, [In] int dwFlags);
		}

		// Token: 0x02000129 RID: 297
		[ComVisible(true)]
		[Guid("55272A00-42CB-11CE-8135-00AA004BB851")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface IPropertyBag
		{
			// Token: 0x0600046F RID: 1135
			int Read([MarshalAs(UnmanagedType.LPWStr)] string PropName, ref object Var, int ErrorLog);

			// Token: 0x06000470 RID: 1136
			int Write(string PropName, ref object Var);
		}

		// Token: 0x0200012A RID: 298
		[ComVisible(true)]
		[Guid("6B652FFF-11FE-4fce-92AD-0266B5D7C78F")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface ISampleGrabber
		{
			// Token: 0x06000471 RID: 1137
			int SetOneShot([MarshalAs(UnmanagedType.Bool)] [In] bool OneShot);

			// Token: 0x06000472 RID: 1138
			int SetMediaType([MarshalAs(UnmanagedType.LPStruct)] [In] DirectShow.AM_MEDIA_TYPE pmt);

			// Token: 0x06000473 RID: 1139
			int GetConnectedMediaType([MarshalAs(UnmanagedType.LPStruct)] [Out] DirectShow.AM_MEDIA_TYPE pmt);

			// Token: 0x06000474 RID: 1140
			int SetBufferSamples([MarshalAs(UnmanagedType.Bool)] [In] bool BufferThem);

			// Token: 0x06000475 RID: 1141
			int GetCurrentBuffer(ref int pBufferSize, IntPtr pBuffer);

			// Token: 0x06000476 RID: 1142
			int GetCurrentSample(IntPtr ppSample);

			// Token: 0x06000477 RID: 1143
			int SetCallback(DirectShow.ISampleGrabberCB pCallback, int WhichMethodToCallback);
		}

		// Token: 0x0200012B RID: 299
		[ComVisible(true)]
		[Guid("0579154A-2B53-4994-B0D0-E773148EFF85")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		public interface ISampleGrabberCB
		{
			// Token: 0x06000478 RID: 1144
			[PreserveSig]
			int SampleCB(double SampleTime, DirectShow.IMediaSample pSample);

			// Token: 0x06000479 RID: 1145
			[PreserveSig]
			int BufferCB(double SampleTime, IntPtr pBuffer, int BufferLen);
		}

		// Token: 0x0200012C RID: 300
		[ComVisible(true)]
		[Guid("56a868b4-0ad4-11ce-b03a-0020af0ba770")]
		[InterfaceType(ComInterfaceType.InterfaceIsDual)]
		[ComImport]
		public interface IVideoWindow
		{
			// Token: 0x0600047A RID: 1146
			int put_Caption(string caption);

			// Token: 0x0600047B RID: 1147
			int get_Caption([In] [Out] ref string caption);

			// Token: 0x0600047C RID: 1148
			int put_WindowStyle(int windowStyle);

			// Token: 0x0600047D RID: 1149
			int get_WindowStyle(ref int windowStyle);

			// Token: 0x0600047E RID: 1150
			int put_WindowStyleEx(int windowStyleEx);

			// Token: 0x0600047F RID: 1151
			int get_WindowStyleEx(ref int windowStyleEx);

			// Token: 0x06000480 RID: 1152
			int put_AutoShow(int autoShow);

			// Token: 0x06000481 RID: 1153
			int get_AutoShow(ref int autoShow);

			// Token: 0x06000482 RID: 1154
			int put_WindowState(int windowState);

			// Token: 0x06000483 RID: 1155
			int get_WindowState(ref int windowState);

			// Token: 0x06000484 RID: 1156
			int put_BackgroundPalette(int backgroundPalette);

			// Token: 0x06000485 RID: 1157
			int get_BackgroundPalette(ref int backgroundPalette);

			// Token: 0x06000486 RID: 1158
			int put_Visible(int visible);

			// Token: 0x06000487 RID: 1159
			int get_Visible(ref int visible);

			// Token: 0x06000488 RID: 1160
			int put_Left(int left);

			// Token: 0x06000489 RID: 1161
			int get_Left(ref int left);

			// Token: 0x0600048A RID: 1162
			int put_Width(int width);

			// Token: 0x0600048B RID: 1163
			int get_Width(ref int width);

			// Token: 0x0600048C RID: 1164
			int put_Top(int top);

			// Token: 0x0600048D RID: 1165
			int get_Top(ref int top);

			// Token: 0x0600048E RID: 1166
			int put_Height(int height);

			// Token: 0x0600048F RID: 1167
			int get_Height(ref int height);

			// Token: 0x06000490 RID: 1168
			int put_Owner(IntPtr owner);

			// Token: 0x06000491 RID: 1169
			int get_Owner(ref IntPtr owner);

			// Token: 0x06000492 RID: 1170
			int put_MessageDrain(IntPtr drain);

			// Token: 0x06000493 RID: 1171
			int get_MessageDrain(ref IntPtr drain);

			// Token: 0x06000494 RID: 1172
			int get_BorderColor(ref int color);

			// Token: 0x06000495 RID: 1173
			int put_BorderColor(int color);

			// Token: 0x06000496 RID: 1174
			int get_FullScreenMode(ref int fullScreenMode);

			// Token: 0x06000497 RID: 1175
			int put_FullScreenMode(int fullScreenMode);

			// Token: 0x06000498 RID: 1176
			int SetWindowForeground(int focus);

			// Token: 0x06000499 RID: 1177
			int NotifyOwnerMessage(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam);

			// Token: 0x0600049A RID: 1178
			int SetWindowPosition(int left, int top, int width, int height);

			// Token: 0x0600049B RID: 1179
			int GetWindowPosition(ref int left, ref int top, ref int width, ref int height);

			// Token: 0x0600049C RID: 1180
			int GetMinIdealImageSize(ref int width, ref int height);

			// Token: 0x0600049D RID: 1181
			int GetMaxIdealImageSize(ref int width, ref int height);

			// Token: 0x0600049E RID: 1182
			int GetRestorePosition(ref int left, ref int top, ref int width, ref int height);

			// Token: 0x0600049F RID: 1183
			int HideCursor(int HideCursorValue);

			// Token: 0x060004A0 RID: 1184
			int IsCursorHidden(ref int hideCursor);
		}

		// Token: 0x0200012D RID: 301
		[ComVisible(false)]
		[Serializable]
		[StructLayout(LayoutKind.Sequential)]
		public class AM_MEDIA_TYPE
		{
			// Token: 0x04000505 RID: 1285
			public Guid MajorType;

			// Token: 0x04000506 RID: 1286
			public Guid SubType;

			// Token: 0x04000507 RID: 1287
			[MarshalAs(UnmanagedType.Bool)]
			public bool bFixedSizeSamples;

			// Token: 0x04000508 RID: 1288
			[MarshalAs(UnmanagedType.Bool)]
			public bool bTemporalCompression;

			// Token: 0x04000509 RID: 1289
			public uint lSampleSize;

			// Token: 0x0400050A RID: 1290
			public Guid FormatType;

			// Token: 0x0400050B RID: 1291
			public IntPtr pUnk;

			// Token: 0x0400050C RID: 1292
			public uint cbFormat;

			// Token: 0x0400050D RID: 1293
			public IntPtr pbFormat;
		}

		// Token: 0x0200012E RID: 302
		[ComVisible(false)]
		[Serializable]
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
		public class FILTER_INFO
		{
			// Token: 0x0400050E RID: 1294
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
			public string achName;

			// Token: 0x0400050F RID: 1295
			[MarshalAs(UnmanagedType.IUnknown)]
			public object pGraph;
		}

		// Token: 0x0200012F RID: 303
		[ComVisible(false)]
		[Serializable]
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
		public class PIN_INFO
		{
			// Token: 0x04000510 RID: 1296
			public DirectShow.IBaseFilter pFilter;

			// Token: 0x04000511 RID: 1297
			public DirectShow.PIN_DIRECTION dir;

			// Token: 0x04000512 RID: 1298
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
			public string achName;
		}

		// Token: 0x02000130 RID: 304
		[ComVisible(false)]
		[Serializable]
		[StructLayout(LayoutKind.Sequential, Pack = 8)]
		public struct VIDEO_STREAM_CONFIG_CAPS
		{
			// Token: 0x04000513 RID: 1299
			public Guid Guid;

			// Token: 0x04000514 RID: 1300
			public uint VideoStandard;

			// Token: 0x04000515 RID: 1301
			public DirectShow.SIZE InputSize;

			// Token: 0x04000516 RID: 1302
			public DirectShow.SIZE MinCroppingSize;

			// Token: 0x04000517 RID: 1303
			public DirectShow.SIZE MaxCroppingSize;

			// Token: 0x04000518 RID: 1304
			public int CropGranularityX;

			// Token: 0x04000519 RID: 1305
			public int CropGranularityY;

			// Token: 0x0400051A RID: 1306
			public int CropAlignX;

			// Token: 0x0400051B RID: 1307
			public int CropAlignY;

			// Token: 0x0400051C RID: 1308
			public DirectShow.SIZE MinOutputSize;

			// Token: 0x0400051D RID: 1309
			public DirectShow.SIZE MaxOutputSize;

			// Token: 0x0400051E RID: 1310
			public int OutputGranularityX;

			// Token: 0x0400051F RID: 1311
			public int OutputGranularityY;

			// Token: 0x04000520 RID: 1312
			public int StretchTapsX;

			// Token: 0x04000521 RID: 1313
			public int StretchTapsY;

			// Token: 0x04000522 RID: 1314
			public int ShrinkTapsX;

			// Token: 0x04000523 RID: 1315
			public int ShrinkTapsY;

			// Token: 0x04000524 RID: 1316
			public long MinFrameInterval;

			// Token: 0x04000525 RID: 1317
			public long MaxFrameInterval;

			// Token: 0x04000526 RID: 1318
			public int MinBitsPerSecond;

			// Token: 0x04000527 RID: 1319
			public int MaxBitsPerSecond;
		}

		// Token: 0x02000131 RID: 305
		[ComVisible(false)]
		[Serializable]
		public struct VIDEOINFOHEADER
		{
			// Token: 0x04000528 RID: 1320
			public DirectShow.RECT SrcRect;

			// Token: 0x04000529 RID: 1321
			public DirectShow.RECT TrgRect;

			// Token: 0x0400052A RID: 1322
			public int BitRate;

			// Token: 0x0400052B RID: 1323
			public int BitErrorRate;

			// Token: 0x0400052C RID: 1324
			public long AvgTimePerFrame;

			// Token: 0x0400052D RID: 1325
			public DirectShow.BITMAPINFOHEADER bmiHeader;
		}

		// Token: 0x02000132 RID: 306
		[ComVisible(false)]
		[Serializable]
		public struct VIDEOINFOHEADER2
		{
			// Token: 0x0400052E RID: 1326
			public DirectShow.RECT SrcRect;

			// Token: 0x0400052F RID: 1327
			public DirectShow.RECT TrgRect;

			// Token: 0x04000530 RID: 1328
			public int BitRate;

			// Token: 0x04000531 RID: 1329
			public int BitErrorRate;

			// Token: 0x04000532 RID: 1330
			public long AvgTimePerFrame;

			// Token: 0x04000533 RID: 1331
			public int InterlaceFlags;

			// Token: 0x04000534 RID: 1332
			public int CopyProtectFlags;

			// Token: 0x04000535 RID: 1333
			public int PictAspectRatioX;

			// Token: 0x04000536 RID: 1334
			public int PictAspectRatioY;

			// Token: 0x04000537 RID: 1335
			public int ControlFlags;

			// Token: 0x04000538 RID: 1336
			public int Reserved2;

			// Token: 0x04000539 RID: 1337
			public DirectShow.BITMAPINFOHEADER bmiHeader;
		}

		// Token: 0x02000133 RID: 307
		[ComVisible(false)]
		[Serializable]
		[StructLayout(LayoutKind.Sequential, Pack = 2)]
		public struct BITMAPINFOHEADER
		{
			// Token: 0x0400053A RID: 1338
			public int biSize;

			// Token: 0x0400053B RID: 1339
			public int biWidth;

			// Token: 0x0400053C RID: 1340
			public int biHeight;

			// Token: 0x0400053D RID: 1341
			public short biPlanes;

			// Token: 0x0400053E RID: 1342
			public short biBitCount;

			// Token: 0x0400053F RID: 1343
			public int biCompression;

			// Token: 0x04000540 RID: 1344
			public int biSizeImage;

			// Token: 0x04000541 RID: 1345
			public int biXPelsPerMeter;

			// Token: 0x04000542 RID: 1346
			public int biYPelsPerMeter;

			// Token: 0x04000543 RID: 1347
			public int biClrUsed;

			// Token: 0x04000544 RID: 1348
			public int biClrImportant;
		}

		// Token: 0x02000134 RID: 308
		[ComVisible(false)]
		[Serializable]
		public struct WAVEFORMATEX
		{
			// Token: 0x04000545 RID: 1349
			public ushort wFormatTag;

			// Token: 0x04000546 RID: 1350
			public ushort nChannels;

			// Token: 0x04000547 RID: 1351
			public uint nSamplesPerSec;

			// Token: 0x04000548 RID: 1352
			public uint nAvgBytesPerSec;

			// Token: 0x04000549 RID: 1353
			public short nBlockAlign;

			// Token: 0x0400054A RID: 1354
			public short wBitsPerSample;

			// Token: 0x0400054B RID: 1355
			public short cbSize;
		}

		// Token: 0x02000135 RID: 309
		[ComVisible(false)]
		[Serializable]
		[StructLayout(LayoutKind.Sequential, Pack = 8)]
		public struct SIZE
		{
			// Token: 0x060004A4 RID: 1188 RVA: 0x00023870 File Offset: 0x00021A70
			public override string ToString()
			{
				return string.Format("{{{0}, {1}}}", this.cx, this.cy);
			}

			// Token: 0x0400054C RID: 1356
			public int cx;

			// Token: 0x0400054D RID: 1357
			public int cy;
		}

		// Token: 0x02000136 RID: 310
		[ComVisible(false)]
		[Serializable]
		public struct RECT
		{
			// Token: 0x060004A5 RID: 1189 RVA: 0x00023894 File Offset: 0x00021A94
			public override string ToString()
			{
				return string.Format("{{{0}, {1}, {2}, {3}}}", new object[]
				{
					this.Left,
					this.Top,
					this.Right,
					this.Bottom
				});
			}

			// Token: 0x0400054E RID: 1358
			public int Left;

			// Token: 0x0400054F RID: 1359
			public int Top;

			// Token: 0x04000550 RID: 1360
			public int Right;

			// Token: 0x04000551 RID: 1361
			public int Bottom;
		}

		// Token: 0x02000137 RID: 311
		[ComVisible(false)]
		public enum PIN_DIRECTION
		{
			// Token: 0x04000553 RID: 1363
			PINDIR_INPUT,
			// Token: 0x04000554 RID: 1364
			PINDIR_OUTPUT
		}

		// Token: 0x02000138 RID: 312
		[ComVisible(false)]
		public enum FILTER_STATE
		{
			// Token: 0x04000556 RID: 1366
			Stopped,
			// Token: 0x04000557 RID: 1367
			Paused,
			// Token: 0x04000558 RID: 1368
			Running
		}

		// Token: 0x02000139 RID: 313
		[ComVisible(false)]
		public enum CameraControlProperty
		{
			// Token: 0x0400055A RID: 1370
			Pan,
			// Token: 0x0400055B RID: 1371
			Tilt,
			// Token: 0x0400055C RID: 1372
			Roll,
			// Token: 0x0400055D RID: 1373
			Zoom,
			// Token: 0x0400055E RID: 1374
			Exposure,
			// Token: 0x0400055F RID: 1375
			Iris,
			// Token: 0x04000560 RID: 1376
			Focus
		}

		// Token: 0x0200013A RID: 314
		[ComVisible(false)]
		[Flags]
		public enum CameraControlFlags
		{
			// Token: 0x04000562 RID: 1378
			Auto = 1,
			// Token: 0x04000563 RID: 1379
			Manual = 2
		}

		// Token: 0x0200013B RID: 315
		[ComVisible(false)]
		public enum VideoProcAmpProperty
		{
			// Token: 0x04000565 RID: 1381
			Brightness,
			// Token: 0x04000566 RID: 1382
			Contrast,
			// Token: 0x04000567 RID: 1383
			Hue,
			// Token: 0x04000568 RID: 1384
			Saturation,
			// Token: 0x04000569 RID: 1385
			Sharpness,
			// Token: 0x0400056A RID: 1386
			Gamma,
			// Token: 0x0400056B RID: 1387
			ColorEnable,
			// Token: 0x0400056C RID: 1388
			WhiteBalance,
			// Token: 0x0400056D RID: 1389
			BacklightCompensation,
			// Token: 0x0400056E RID: 1390
			Gain
		}

		// Token: 0x0200013C RID: 316
		[ComVisible(false)]
		public enum AMPropertyPin
		{
			// Token: 0x04000570 RID: 1392
			Category,
			// Token: 0x04000571 RID: 1393
			Medium
		}

		// Token: 0x0200013D RID: 317
		[ComVisible(false)]
		[Flags]
		public enum VideoControlFlags
		{
			// Token: 0x04000573 RID: 1395
			FlipHorizontal = 1,
			// Token: 0x04000574 RID: 1396
			FlipVertical = 2,
			// Token: 0x04000575 RID: 1397
			ExternalTriggerEnable = 4,
			// Token: 0x04000576 RID: 1398
			Trigger = 8
		}

		// Token: 0x0200013E RID: 318
		public static class DsGuid
		{
			// Token: 0x060004A6 RID: 1190 RVA: 0x000238EC File Offset: 0x00021AEC
			public static string GetNickname(Guid guid)
			{
				if (DirectShow.DsGuid.NicknameCache == null)
				{
					DirectShow.DsGuid.NicknameCache = (from x in typeof(DirectShow.DsGuid).GetFields(BindingFlags.Static | BindingFlags.Public)
					where x.FieldType == typeof(Guid)
					select x).ToDictionary((FieldInfo x) => (Guid)x.GetValue(null), (FieldInfo x) => x.Name);
				}
				if (!DirectShow.DsGuid.NicknameCache.ContainsKey(guid))
				{
					return guid.ToString();
				}
				string text = DirectShow.DsGuid.NicknameCache[guid];
				string[] array = text.Split(new char[]
				{
					'_'
				});
				if (array.Length >= 2)
				{
					string arg = string.Join("_", array.Skip(1).ToArray<string>());
					return string.Format("[{0}]", arg);
				}
				return text;
			}

			// Token: 0x04000577 RID: 1399
			public static readonly Guid MEDIATYPE_Video = new Guid("{73646976-0000-0010-8000-00AA00389B71}");

			// Token: 0x04000578 RID: 1400
			public static readonly Guid MEDIATYPE_Audio = new Guid("{73647561-0000-0010-8000-00AA00389B71}");

			// Token: 0x04000579 RID: 1401
			public static readonly Guid MEDIASUBTYPE_None = new Guid("{E436EB8E-524F-11CE-9F53-0020AF0BA770}");

			// Token: 0x0400057A RID: 1402
			public static readonly Guid MEDIASUBTYPE_YUYV = new Guid("{56595559-0000-0010-8000-00AA00389B71}");

			// Token: 0x0400057B RID: 1403
			public static readonly Guid MEDIASUBTYPE_IYUV = new Guid("{56555949-0000-0010-8000-00AA00389B71}");

			// Token: 0x0400057C RID: 1404
			public static readonly Guid MEDIASUBTYPE_YVU9 = new Guid("{39555659-0000-0010-8000-00AA00389B71}");

			// Token: 0x0400057D RID: 1405
			public static readonly Guid MEDIASUBTYPE_YUY2 = new Guid("{32595559-0000-0010-8000-00AA00389B71}");

			// Token: 0x0400057E RID: 1406
			public static readonly Guid MEDIASUBTYPE_YVYU = new Guid("{55595659-0000-0010-8000-00AA00389B71}");

			// Token: 0x0400057F RID: 1407
			public static readonly Guid MEDIASUBTYPE_UYVY = new Guid("{59565955-0000-0010-8000-00AA00389B71}");

			// Token: 0x04000580 RID: 1408
			public static readonly Guid MEDIASUBTYPE_MJPG = new Guid("{47504A4D-0000-0010-8000-00AA00389B71}");

			// Token: 0x04000581 RID: 1409
			public static readonly Guid MEDIASUBTYPE_RGB565 = new Guid("{E436EB7B-524F-11CE-9F53-0020AF0BA770}");

			// Token: 0x04000582 RID: 1410
			public static readonly Guid MEDIASUBTYPE_RGB555 = new Guid("{E436EB7C-524F-11CE-9F53-0020AF0BA770}");

			// Token: 0x04000583 RID: 1411
			public static readonly Guid MEDIASUBTYPE_RGB24 = new Guid("{E436EB7D-524F-11CE-9F53-0020AF0BA770}");

			// Token: 0x04000584 RID: 1412
			public static readonly Guid MEDIASUBTYPE_RGB32 = new Guid("{E436EB7E-524F-11CE-9F53-0020AF0BA770}");

			// Token: 0x04000585 RID: 1413
			public static readonly Guid MEDIASUBTYPE_ARGB32 = new Guid("{773C9AC0-3274-11D0-B724-00AA006C1A01}");

			// Token: 0x04000586 RID: 1414
			public static readonly Guid MEDIASUBTYPE_PCM = new Guid("{00000001-0000-0010-8000-00AA00389B71}");

			// Token: 0x04000587 RID: 1415
			public static readonly Guid MEDIASUBTYPE_WAVE = new Guid("{E436EB8B-524F-11CE-9F53-0020AF0BA770}");

			// Token: 0x04000588 RID: 1416
			public static readonly Guid FORMAT_None = new Guid("{0F6417D6-C318-11D0-A43F-00A0C9223196}");

			// Token: 0x04000589 RID: 1417
			public static readonly Guid FORMAT_VideoInfo = new Guid("{05589F80-C356-11CE-BF01-00AA0055595A}");

			// Token: 0x0400058A RID: 1418
			public static readonly Guid FORMAT_VideoInfo2 = new Guid("{F72A76A0-EB0A-11d0-ACE4-0000C0CC16BA}");

			// Token: 0x0400058B RID: 1419
			public static readonly Guid FORMAT_WaveFormatEx = new Guid("{05589F81-C356-11CE-BF01-00AA0055595A}");

			// Token: 0x0400058C RID: 1420
			public static readonly Guid CLSID_AudioInputDeviceCategory = new Guid("{33D9A762-90C8-11d0-BD43-00A0C911CE86}");

			// Token: 0x0400058D RID: 1421
			public static readonly Guid CLSID_AudioRendererCategory = new Guid("{E0F158E1-CB04-11d0-BD4E-00A0C911CE86}");

			// Token: 0x0400058E RID: 1422
			public static readonly Guid CLSID_VideoInputDeviceCategory = new Guid("{860BB310-5D01-11d0-BD3B-00A0C911CE86}");

			// Token: 0x0400058F RID: 1423
			public static readonly Guid CLSID_VideoCompressorCategory = new Guid("{33D9A760-90C8-11d0-BD43-00A0C911CE86}");

			// Token: 0x04000590 RID: 1424
			public static readonly Guid CLSID_NullRenderer = new Guid("{C1F400A4-3F08-11D3-9F0B-006008039E37}");

			// Token: 0x04000591 RID: 1425
			public static readonly Guid CLSID_SampleGrabber = new Guid("{C1F400A0-3F08-11D3-9F0B-006008039E37}");

			// Token: 0x04000592 RID: 1426
			public static readonly Guid CLSID_FilterGraph = new Guid("{E436EBB3-524F-11CE-9F53-0020AF0BA770}");

			// Token: 0x04000593 RID: 1427
			public static readonly Guid CLSID_SystemDeviceEnum = new Guid("{62BE5D10-60EB-11d0-BD3B-00A0C911CE86}");

			// Token: 0x04000594 RID: 1428
			public static readonly Guid CLSID_CaptureGraphBuilder2 = new Guid("{BF87B6E1-8C27-11d0-B3F0-00AA003761C5}");

			// Token: 0x04000595 RID: 1429
			public static readonly Guid IID_IPropertyBag = new Guid("{55272A00-42CB-11CE-8135-00AA004BB851}");

			// Token: 0x04000596 RID: 1430
			public static readonly Guid IID_IBaseFilter = new Guid("{56a86895-0ad4-11ce-b03a-0020af0ba770}");

			// Token: 0x04000597 RID: 1431
			public static readonly Guid IID_IAMStreamConfig = new Guid("{C6E13340-30AC-11d0-A18C-00A0C9118956}");

			// Token: 0x04000598 RID: 1432
			public static readonly Guid PIN_CATEGORY_CAPTURE = new Guid("{fb6c4281-0353-11d1-905f-0000c0cc16ba}");

			// Token: 0x04000599 RID: 1433
			public static readonly Guid PIN_CATEGORY_PREVIEW = new Guid("{fb6c4282-0353-11d1-905f-0000c0cc16ba}");

			// Token: 0x0400059A RID: 1434
			public static readonly Guid PIN_CATEGORY_STILL = new Guid("{fb6c428a-0353-11d1-905f-0000c0cc16ba}");

			// Token: 0x0400059B RID: 1435
			public static readonly Guid AMPROPSETID_PIN = new Guid("9b00f101-1567-11d1-b3f1-00aa003761c5");

			// Token: 0x0400059C RID: 1436
			private static Dictionary<Guid, string> NicknameCache = null;
		}
	}
}
