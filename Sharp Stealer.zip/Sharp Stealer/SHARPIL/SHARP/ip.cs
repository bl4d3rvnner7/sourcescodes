﻿using System;
using System.IO;
using System.Net;

namespace SHARP
{
	// Token: 0x0200005A RID: 90
	internal class ip
	{
		// Token: 0x060001FE RID: 510 RVA: 0x0000C77E File Offset: 0x0000A97E
		public static void ipishnik()
		{
			LocationInfo locationInfo = ip.GetLocationInfo(Prog.IP);
			Counting.country = locationInfo.Country;
			Counting.reg = locationInfo.Region;
			Counting.city = locationInfo.City;
		}

		// Token: 0x060001FF RID: 511 RVA: 0x0000C7AC File Offset: 0x0000A9AC
		private static LocationInfo GetLocationInfo(string ipAddress)
		{
			try
			{
				WebRequest webRequest = WebRequest.Create("http://ip-api.com/json/" + ipAddress);
				webRequest.Method = "GET";
				using (WebResponse response = webRequest.GetResponse())
				{
					using (Stream responseStream = response.GetResponseStream())
					{
						using (StreamReader streamReader = new StreamReader(responseStream))
						{
							string[] array = streamReader.ReadToEnd().Split(new char[]
							{
								','
							});
							LocationInfo locationInfo = new LocationInfo();
							string[] array2 = array;
							for (int i = 0; i < array2.Length; i++)
							{
								string[] array3 = array2[i].Split(new char[]
								{
									':'
								});
								string a = array3[0].Trim().TrimStart(new char[]
								{
									'"'
								}).TrimEnd(new char[]
								{
									'"'
								});
								string text = array3[1].Trim().TrimStart(new char[]
								{
									'"'
								}).TrimEnd(new char[]
								{
									'"'
								});
								if (!(a == "country"))
								{
									if (!(a == "regionName"))
									{
										if (!(a == "city"))
										{
											if (!(a == "lat"))
											{
												if (a == "lon")
												{
													locationInfo.Longitude = text;
												}
											}
											else
											{
												locationInfo.Latitude = text;
											}
										}
										else
										{
											locationInfo.City = text;
										}
									}
									else
									{
										locationInfo.Region = text;
									}
								}
								else
								{
									locationInfo.Country = text;
								}
							}
							return locationInfo;
						}
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Ошибка при получении данных: " + ex.Message);
			}
			return null;
		}
	}
}
