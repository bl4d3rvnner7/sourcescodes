﻿using System;

namespace SHARP
{
	// Token: 0x0200005B RID: 91
	internal class LocationInfo
	{
		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000201 RID: 513 RVA: 0x0000C9B4 File Offset: 0x0000ABB4
		// (set) Token: 0x06000202 RID: 514 RVA: 0x0000C9BC File Offset: 0x0000ABBC
		public string Country { get; set; }

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x06000203 RID: 515 RVA: 0x0000C9C5 File Offset: 0x0000ABC5
		// (set) Token: 0x06000204 RID: 516 RVA: 0x0000C9CD File Offset: 0x0000ABCD
		public string Region { get; set; }

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06000205 RID: 517 RVA: 0x0000C9D6 File Offset: 0x0000ABD6
		// (set) Token: 0x06000206 RID: 518 RVA: 0x0000C9DE File Offset: 0x0000ABDE
		public string City { get; set; }

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000207 RID: 519 RVA: 0x0000C9E7 File Offset: 0x0000ABE7
		// (set) Token: 0x06000208 RID: 520 RVA: 0x0000C9EF File Offset: 0x0000ABEF
		public string Latitude { get; set; }

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000209 RID: 521 RVA: 0x0000C9F8 File Offset: 0x0000ABF8
		// (set) Token: 0x0600020A RID: 522 RVA: 0x0000CA00 File Offset: 0x0000AC00
		public string Longitude { get; set; }
	}
}
