﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace SHARP
{
	// Token: 0x02000053 RID: 83
	internal class UsbCamera
	{
		// Token: 0x17000036 RID: 54
		// (get) Token: 0x060001AB RID: 427 RVA: 0x0000AAF5 File Offset: 0x00008CF5
		// (set) Token: 0x060001AC RID: 428 RVA: 0x0000AAFD File Offset: 0x00008CFD
		public Size Size { get; private set; }

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x060001AD RID: 429 RVA: 0x0000AB06 File Offset: 0x00008D06
		// (set) Token: 0x060001AE RID: 430 RVA: 0x0000AB0E File Offset: 0x00008D0E
		public Action Start { get; private set; }

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x060001AF RID: 431 RVA: 0x0000AB17 File Offset: 0x00008D17
		// (set) Token: 0x060001B0 RID: 432 RVA: 0x0000AB1F File Offset: 0x00008D1F
		public Action Stop { get; private set; }

		// Token: 0x060001B1 RID: 433 RVA: 0x0000AB28 File Offset: 0x00008D28
		public void Release()
		{
			this.Releasing();
			this.Released();
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x060001B2 RID: 434 RVA: 0x0000AB40 File Offset: 0x00008D40
		// (set) Token: 0x060001B3 RID: 435 RVA: 0x0000AB48 File Offset: 0x00008D48
		public Func<Bitmap> GetBitmap { get; private set; }

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x060001B4 RID: 436 RVA: 0x0000AB51 File Offset: 0x00008D51
		// (set) Token: 0x060001B5 RID: 437 RVA: 0x0000AB59 File Offset: 0x00008D59
		public bool StillImageAvailable { get; private set; }

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x060001B6 RID: 438 RVA: 0x0000AB62 File Offset: 0x00008D62
		// (set) Token: 0x060001B7 RID: 439 RVA: 0x0000AB6A File Offset: 0x00008D6A
		public Action StillImageTrigger { get; private set; } = delegate()
		{
		};

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x060001B8 RID: 440 RVA: 0x0000AB73 File Offset: 0x00008D73
		// (set) Token: 0x060001B9 RID: 441 RVA: 0x0000AB86 File Offset: 0x00008D86
		public Action<Bitmap> StillImageCaptured
		{
			get
			{
				return this.Streams[UsbCamera.StreamType.Still].Buffered;
			}
			set
			{
				this.Streams[UsbCamera.StreamType.Still].Buffered = value;
			}
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x060001BA RID: 442 RVA: 0x0000AB9A File Offset: 0x00008D9A
		// (set) Token: 0x060001BB RID: 443 RVA: 0x0000ABC6 File Offset: 0x00008DC6
		public Action<Bitmap> PreviewCaptured
		{
			get
			{
				if (!this.Streams.ContainsKey(UsbCamera.StreamType.Preview))
				{
					this.SetPreviewCallbackMain();
				}
				return this.Streams[UsbCamera.StreamType.Preview].Buffered;
			}
			set
			{
				if (!this.Streams.ContainsKey(UsbCamera.StreamType.Preview))
				{
					this.SetPreviewCallbackMain();
				}
				this.Streams[UsbCamera.StreamType.Preview].Buffered = value;
			}
		}

		// Token: 0x060001BC RID: 444 RVA: 0x0000ABF3 File Offset: 0x00008DF3
		public void SetPreviewControl(IntPtr handle, Size size)
		{
			this.SetPreviewControlMain(handle);
			this.SetPreviewSizeMain(size);
		}

		// Token: 0x060001BD RID: 445 RVA: 0x0000AC0D File Offset: 0x00008E0D
		public void SetPreviewSize(Size size)
		{
			this.SetPreviewSizeMain(size);
		}

		// Token: 0x060001BE RID: 446 RVA: 0x0000AC1B File Offset: 0x00008E1B
		public static string[] FindDevices()
		{
			return DirectShow.GetFiltes(DirectShow.DsGuid.CLSID_VideoInputDeviceCategory).ToArray();
		}

		// Token: 0x060001BF RID: 447 RVA: 0x0000AC2C File Offset: 0x00008E2C
		public static UsbCamera.VideoFormat[] GetVideoFormat(int cameraIndex)
		{
			return UsbCamera.GetVideoOutputFormat(DirectShow.FindPin(DirectShow.CreateFilter(DirectShow.DsGuid.CLSID_VideoInputDeviceCategory, cameraIndex), 0, DirectShow.PIN_DIRECTION.PINDIR_OUTPUT));
		}

		// Token: 0x060001C0 RID: 448 RVA: 0x0000AC45 File Offset: 0x00008E45
		public UsbCamera(int cameraIndex, Size size) : this(cameraIndex, new UsbCamera.VideoFormat
		{
			Size = size
		})
		{
		}

		// Token: 0x060001C1 RID: 449 RVA: 0x0000AC5C File Offset: 0x00008E5C
		public UsbCamera(int cameraIndex, UsbCamera.VideoFormat format)
		{
			string[] array = UsbCamera.FindDevices();
			if (cameraIndex >= array.Length)
			{
				throw new ArgumentException("USB camera is not available.", "cameraIndex");
			}
			this.Init(cameraIndex, format);
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x0000ACC4 File Offset: 0x00008EC4
		private void Init(int index, UsbCamera.VideoFormat format)
		{
			DirectShow.IGraphBuilder graph = DirectShow.CreateGraph();
			DirectShow.ICaptureGraphBuilder2 builder = DirectShow.CoCreateInstance(DirectShow.DsGuid.CLSID_CaptureGraphBuilder2) as DirectShow.ICaptureGraphBuilder2;
			builder.SetFiltergraph(graph);
			DirectShow.IBaseFilter vcap_source = this.CreateVideoCaptureSource(index, format);
			graph.AddFilter(vcap_source, "VideoCapture");
			UsbCamera.SampleGrabberInfo sample2 = this.ConnectSampleGrabberAndRenderer(graph, builder, vcap_source, DirectShow.DsGuid.PIN_CATEGORY_CAPTURE);
			if (sample2 != null)
			{
				this.Released = (Action)Delegate.Combine(this.Released, new Action(delegate()
				{
					DirectShow.ISampleGrabber grabber = sample2.Grabber;
					DirectShow.ReleaseInstance<DirectShow.ISampleGrabber>(ref grabber);
				}));
				this.Size = new Size(sample2.Width, sample2.Height);
				this.GetBitmap = UsbCamera.<Init>g__GetBitmapFromSampleGrabberCallback|44_8(sample2.Grabber, sample2.Width, sample2.Height, sample2.Stride);
			}
			UsbCamera.SampleGrabberInfo sample = this.ConnectSampleGrabberAndRenderer(graph, builder, vcap_source, DirectShow.DsGuid.PIN_CATEGORY_STILL);
			if (sample != null)
			{
				this.Released = (Action)Delegate.Combine(this.Released, new Action(delegate()
				{
					DirectShow.ISampleGrabber grabber = sample.Grabber;
					DirectShow.ReleaseInstance<DirectShow.ISampleGrabber>(ref grabber);
				}));
				DirectShow.IPin still_pin = DirectShow.FindPin(vcap_source, 0, DirectShow.PIN_DIRECTION.PINDIR_OUTPUT, DirectShow.DsGuid.PIN_CATEGORY_STILL);
				DirectShow.IAMVideoControl video_con = vcap_source as DirectShow.IAMVideoControl;
				if (video_con != null)
				{
					this.StillImageAvailable = true;
					this.Streams[UsbCamera.StreamType.Still] = new UsbCamera.SampleGrabberCallback(sample.Grabber, sample.Width, sample.Height, sample.Stride, false);
					this.StillImageTrigger = delegate()
					{
						video_con.SetMode(still_pin, DirectShow.VideoControlFlags.ExternalTriggerEnable | DirectShow.VideoControlFlags.Trigger);
					};
				}
			}
			bool makePreviewRender = false;
			this.SetPreviewControlMain = delegate(IntPtr controlHandle)
			{
				DirectShow.IVideoWindow videoWindow = graph as DirectShow.IVideoWindow;
				if (videoWindow == null)
				{
					return;
				}
				if (!makePreviewRender)
				{
					makePreviewRender = true;
					Guid pin_CATEGORY_PREVIEW = DirectShow.DsGuid.PIN_CATEGORY_PREVIEW;
					Guid mediatype_Video = DirectShow.DsGuid.MEDIATYPE_Video;
					builder.RenderStream(ref pin_CATEGORY_PREVIEW, ref mediatype_Video, vcap_source, null, null);
				}
				videoWindow.put_Owner(controlHandle);
				videoWindow.put_MessageDrain(controlHandle);
			};
			this.SetPreviewSizeMain = delegate(Size clientSize)
			{
				DirectShow.IVideoWindow videoWindow = graph as DirectShow.IVideoWindow;
				if (videoWindow == null)
				{
					return;
				}
				int num = clientSize.Width;
				int num2 = this.Size.Height * num / this.Size.Width;
				if (num2 > clientSize.Height)
				{
					num2 = clientSize.Height;
					num = this.Size.Width * num2 / this.Size.Height;
				}
				int left = (clientSize.Width - num) / 2;
				int top = (clientSize.Height - num2) / 2;
				videoWindow.put_WindowStyle(1140850688);
				videoWindow.SetWindowPosition(left, top, num, num2);
			};
			this.SetPreviewCallbackMain = delegate()
			{
				UsbCamera.SampleGrabberInfo sample2 = this.ConnectSampleGrabberAndRenderer(graph, builder, vcap_source, DirectShow.DsGuid.PIN_CATEGORY_PREVIEW);
				if (sample2 != null)
				{
					this.Released = (Action)Delegate.Combine(this.Released, new Action(delegate()
					{
						DirectShow.ISampleGrabber grabber = sample2.Grabber;
						DirectShow.ReleaseInstance<DirectShow.ISampleGrabber>(ref grabber);
					}));
					this.Streams[UsbCamera.StreamType.Preview] = new UsbCamera.SampleGrabberCallback(sample2.Grabber, sample2.Width, sample2.Height, sample2.Stride, true);
				}
			};
			this.Start = delegate()
			{
				DirectShow.PlayGraph(graph, DirectShow.FILTER_STATE.Running);
			};
			this.Stop = delegate()
			{
				DirectShow.PlayGraph(graph, DirectShow.FILTER_STATE.Stopped);
			};
			this.Releasing = (Action)Delegate.Combine(this.Releasing, new Action(delegate()
			{
				this.Stop();
			}));
			this.Released = (Action)Delegate.Combine(this.Released, new Action(delegate()
			{
				DirectShow.ReleaseInstance<DirectShow.ICaptureGraphBuilder2>(ref builder);
				DirectShow.ReleaseInstance<DirectShow.IGraphBuilder>(ref graph);
			}));
			this.Properties = new UsbCamera.PropertyItems(vcap_source);
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x0000AF7C File Offset: 0x0000917C
		private UsbCamera.SampleGrabberInfo ConnectSampleGrabberAndRenderer(DirectShow.IFilterGraph graph, DirectShow.ICaptureGraphBuilder2 builder, DirectShow.IBaseFilter vcap_source, Guid pinCategory)
		{
			DirectShow.IBaseFilter baseFilter = this.CreateSampleGrabber();
			graph.AddFilter(baseFilter, "SampleGrabber");
			DirectShow.ISampleGrabber sampleGrabber = (DirectShow.ISampleGrabber)baseFilter;
			sampleGrabber.SetBufferSamples(true);
			DirectShow.IBaseFilter baseFilter2 = DirectShow.CoCreateInstance(DirectShow.DsGuid.CLSID_NullRenderer) as DirectShow.IBaseFilter;
			graph.AddFilter(baseFilter2, "NullRenderer");
			try
			{
				Guid mediatype_Video = DirectShow.DsGuid.MEDIATYPE_Video;
				builder.RenderStream(ref pinCategory, ref mediatype_Video, vcap_source, baseFilter, baseFilter2);
			}
			catch (Exception)
			{
				return null;
			}
			DirectShow.AM_MEDIA_TYPE am_MEDIA_TYPE = new DirectShow.AM_MEDIA_TYPE();
			sampleGrabber.GetConnectedMediaType(am_MEDIA_TYPE);
			DirectShow.VIDEOINFOHEADER videoinfoheader = (DirectShow.VIDEOINFOHEADER)Marshal.PtrToStructure(am_MEDIA_TYPE.pbFormat, typeof(DirectShow.VIDEOINFOHEADER));
			int biWidth = videoinfoheader.bmiHeader.biWidth;
			int biHeight = videoinfoheader.bmiHeader.biHeight;
			int stride = biWidth * (int)(videoinfoheader.bmiHeader.biBitCount / 8);
			DirectShow.DeleteMediaType(ref am_MEDIA_TYPE);
			return new UsbCamera.SampleGrabberInfo
			{
				Grabber = sampleGrabber,
				Width = biWidth,
				Height = biHeight,
				Stride = stride
			};
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x060001C4 RID: 452 RVA: 0x0000B084 File Offset: 0x00009284
		// (set) Token: 0x060001C5 RID: 453 RVA: 0x0000B08C File Offset: 0x0000928C
		public UsbCamera.PropertyItems Properties { get; private set; }

		// Token: 0x060001C6 RID: 454 RVA: 0x0000B098 File Offset: 0x00009298
		private DirectShow.IBaseFilter CreateSampleGrabber()
		{
			DirectShow.IBaseFilter baseFilter = DirectShow.CreateFilter(DirectShow.DsGuid.CLSID_SampleGrabber);
			(baseFilter as DirectShow.ISampleGrabber).SetMediaType(new DirectShow.AM_MEDIA_TYPE
			{
				MajorType = DirectShow.DsGuid.MEDIATYPE_Video,
				SubType = DirectShow.DsGuid.MEDIASUBTYPE_RGB24
			});
			return baseFilter;
		}

		// Token: 0x060001C7 RID: 455 RVA: 0x0000B0D8 File Offset: 0x000092D8
		private DirectShow.IBaseFilter CreateVideoCaptureSource(int index, UsbCamera.VideoFormat format)
		{
			DirectShow.IBaseFilter baseFilter = DirectShow.CreateFilter(DirectShow.DsGuid.CLSID_VideoInputDeviceCategory, index);
			UsbCamera.SetVideoOutputFormat(DirectShow.FindPin(baseFilter, 0, DirectShow.PIN_DIRECTION.PINDIR_OUTPUT), format);
			return baseFilter;
		}

		// Token: 0x060001C8 RID: 456 RVA: 0x0000B0F4 File Offset: 0x000092F4
		private static void SetVideoOutputFormat(DirectShow.IPin pin, UsbCamera.VideoFormat format)
		{
			UsbCamera.VideoFormat[] videoOutputFormat = UsbCamera.GetVideoOutputFormat(pin);
			for (int i = 0; i < videoOutputFormat.Length; i++)
			{
				UsbCamera.VideoFormat videoFormat = videoOutputFormat[i];
				if (!(videoFormat.MajorType != DirectShow.DsGuid.GetNickname(DirectShow.DsGuid.MEDIATYPE_Video)) && (string.IsNullOrEmpty(format.SubType) || !(format.SubType != videoFormat.SubType)) && !(videoFormat.Caps.Guid != DirectShow.DsGuid.FORMAT_VideoInfo) && videoFormat.Size.Width == format.Size.Width && videoFormat.Size.Height == format.Size.Height)
				{
					UsbCamera.SetVideoOutputFormat(pin, i, format.Size, format.TimePerFrame);
					return;
				}
			}
			for (int j = 0; j < videoOutputFormat.Length; j++)
			{
				UsbCamera.VideoFormat videoFormat2 = videoOutputFormat[j];
				if (!(videoFormat2.MajorType != DirectShow.DsGuid.GetNickname(DirectShow.DsGuid.MEDIATYPE_Video)) && (string.IsNullOrEmpty(format.SubType) || !(format.SubType != videoFormat2.SubType)) && !(videoFormat2.Caps.Guid != DirectShow.DsGuid.FORMAT_VideoInfo) && videoFormat2.Caps.OutputGranularityX != 0 && videoFormat2.Caps.OutputGranularityY != 0)
				{
					for (int k = videoFormat2.Caps.MinOutputSize.cx; k < videoFormat2.Caps.MaxOutputSize.cx; k += videoFormat2.Caps.OutputGranularityX)
					{
						for (int l = videoFormat2.Caps.MinOutputSize.cy; l < videoFormat2.Caps.MaxOutputSize.cy; l += videoFormat2.Caps.OutputGranularityY)
						{
							if (k == format.Size.Width && l == format.Size.Height)
							{
								UsbCamera.SetVideoOutputFormat(pin, j, format.Size, format.TimePerFrame);
								return;
							}
						}
					}
				}
			}
			UsbCamera.SetVideoOutputFormat(pin, 0, Size.Empty, 0L);
		}

		// Token: 0x060001C9 RID: 457 RVA: 0x0000B320 File Offset: 0x00009520
		private static UsbCamera.VideoFormat[] GetVideoOutputFormat(DirectShow.IPin pin)
		{
			DirectShow.IAMStreamConfig iamstreamConfig = pin as DirectShow.IAMStreamConfig;
			if (iamstreamConfig == null)
			{
				throw new InvalidOperationException("no IAMStreamConfig interface.");
			}
			int num = 0;
			int num2 = 0;
			iamstreamConfig.GetNumberOfCapabilities(ref num, ref num2);
			if (num2 != Marshal.SizeOf(typeof(DirectShow.VIDEO_STREAM_CONFIG_CAPS)))
			{
				throw new InvalidOperationException("no VIDEO_STREAM_CONFIG_CAPS.");
			}
			UsbCamera.VideoFormat[] array = new UsbCamera.VideoFormat[num];
			IntPtr intPtr = Marshal.AllocHGlobal(num2);
			for (int i = 0; i < num; i++)
			{
				UsbCamera.VideoFormat videoFormat = new UsbCamera.VideoFormat();
				DirectShow.AM_MEDIA_TYPE am_MEDIA_TYPE = null;
				iamstreamConfig.GetStreamCaps(i, ref am_MEDIA_TYPE, intPtr);
				videoFormat.Caps = UsbCamera.PtrToStructure<DirectShow.VIDEO_STREAM_CONFIG_CAPS>(intPtr);
				videoFormat.MajorType = DirectShow.DsGuid.GetNickname(am_MEDIA_TYPE.MajorType);
				videoFormat.SubType = DirectShow.DsGuid.GetNickname(am_MEDIA_TYPE.SubType);
				if (am_MEDIA_TYPE.FormatType == DirectShow.DsGuid.FORMAT_VideoInfo)
				{
					DirectShow.VIDEOINFOHEADER videoinfoheader = UsbCamera.PtrToStructure<DirectShow.VIDEOINFOHEADER>(am_MEDIA_TYPE.pbFormat);
					videoFormat.Size = new Size(videoinfoheader.bmiHeader.biWidth, videoinfoheader.bmiHeader.biHeight);
					videoFormat.TimePerFrame = videoinfoheader.AvgTimePerFrame;
				}
				else if (am_MEDIA_TYPE.FormatType == DirectShow.DsGuid.FORMAT_VideoInfo2)
				{
					DirectShow.VIDEOINFOHEADER2 videoinfoheader2 = UsbCamera.PtrToStructure<DirectShow.VIDEOINFOHEADER2>(am_MEDIA_TYPE.pbFormat);
					videoFormat.Size = new Size(videoinfoheader2.bmiHeader.biWidth, videoinfoheader2.bmiHeader.biHeight);
					videoFormat.TimePerFrame = videoinfoheader2.AvgTimePerFrame;
				}
				DirectShow.DeleteMediaType(ref am_MEDIA_TYPE);
				array[i] = videoFormat;
			}
			Marshal.FreeHGlobal(intPtr);
			return array;
		}

		// Token: 0x060001CA RID: 458 RVA: 0x0000B49C File Offset: 0x0000969C
		private static void SetVideoOutputFormat(DirectShow.IPin pin, int index, Size size, long timePerFrame)
		{
			DirectShow.IAMStreamConfig iamstreamConfig = pin as DirectShow.IAMStreamConfig;
			if (iamstreamConfig == null)
			{
				throw new InvalidOperationException("no IAMStreamConfig interface.");
			}
			int num = 0;
			int num2 = 0;
			iamstreamConfig.GetNumberOfCapabilities(ref num, ref num2);
			if (num2 != Marshal.SizeOf(typeof(DirectShow.VIDEO_STREAM_CONFIG_CAPS)))
			{
				throw new InvalidOperationException("no VIDEO_STREAM_CONFIG_CAPS.");
			}
			IntPtr intPtr = Marshal.AllocHGlobal(num2);
			DirectShow.AM_MEDIA_TYPE am_MEDIA_TYPE = null;
			iamstreamConfig.GetStreamCaps(index, ref am_MEDIA_TYPE, intPtr);
			UsbCamera.PtrToStructure<DirectShow.VIDEO_STREAM_CONFIG_CAPS>(intPtr);
			if (am_MEDIA_TYPE.FormatType == DirectShow.DsGuid.FORMAT_VideoInfo)
			{
				DirectShow.VIDEOINFOHEADER structure = UsbCamera.PtrToStructure<DirectShow.VIDEOINFOHEADER>(am_MEDIA_TYPE.pbFormat);
				if (!size.IsEmpty)
				{
					structure.bmiHeader.biWidth = size.Width;
					structure.bmiHeader.biHeight = size.Height;
				}
				if (timePerFrame > 0L)
				{
					structure.AvgTimePerFrame = timePerFrame;
				}
				Marshal.StructureToPtr<DirectShow.VIDEOINFOHEADER>(structure, am_MEDIA_TYPE.pbFormat, true);
			}
			else if (am_MEDIA_TYPE.FormatType == DirectShow.DsGuid.FORMAT_VideoInfo2)
			{
				DirectShow.VIDEOINFOHEADER2 structure2 = UsbCamera.PtrToStructure<DirectShow.VIDEOINFOHEADER2>(am_MEDIA_TYPE.pbFormat);
				if (!size.IsEmpty)
				{
					structure2.bmiHeader.biWidth = size.Width;
					structure2.bmiHeader.biHeight = size.Height;
				}
				if (timePerFrame > 0L)
				{
					structure2.AvgTimePerFrame = timePerFrame;
				}
				Marshal.StructureToPtr<DirectShow.VIDEOINFOHEADER2>(structure2, am_MEDIA_TYPE.pbFormat, true);
			}
			iamstreamConfig.SetFormat(am_MEDIA_TYPE);
			if (intPtr != IntPtr.Zero)
			{
				Marshal.FreeHGlobal(intPtr);
			}
			if (am_MEDIA_TYPE != null)
			{
				DirectShow.DeleteMediaType(ref am_MEDIA_TYPE);
			}
		}

		// Token: 0x060001CB RID: 459 RVA: 0x0000B5FC File Offset: 0x000097FC
		private static T PtrToStructure<T>(IntPtr ptr)
		{
			return (T)((object)Marshal.PtrToStructure(ptr, typeof(T)));
		}

		// Token: 0x060001CC RID: 460 RVA: 0x0000B613 File Offset: 0x00009813
		[CompilerGenerated]
		internal static Func<Bitmap> <Init>g__GetBitmapFromSampleGrabberCallback|44_8(DirectShow.ISampleGrabber grabber, int width, int height, int stride)
		{
			UsbCamera.SampleGrabberCallback sampler = new UsbCamera.SampleGrabberCallback(grabber, width, height, stride, false);
			return () => sampler.GetBitmap();
		}

		// Token: 0x04000109 RID: 265
		private Action Releasing;

		// Token: 0x0400010A RID: 266
		private Action Released;

		// Token: 0x0400010C RID: 268
		private Dictionary<UsbCamera.StreamType, UsbCamera.SampleGrabberCallback> Streams = new Dictionary<UsbCamera.StreamType, UsbCamera.SampleGrabberCallback>();

		// Token: 0x0400010F RID: 271
		private Action SetPreviewCallbackMain;

		// Token: 0x04000110 RID: 272
		private Action<IntPtr> SetPreviewControlMain;

		// Token: 0x04000111 RID: 273
		private Action<Size> SetPreviewSizeMain;

		// Token: 0x02000108 RID: 264
		public enum StreamType
		{
			// Token: 0x040004DD RID: 1245
			Capture,
			// Token: 0x040004DE RID: 1246
			Preview,
			// Token: 0x040004DF RID: 1247
			Still
		}

		// Token: 0x02000109 RID: 265
		private class SampleGrabberInfo
		{
			// Token: 0x17000046 RID: 70
			// (get) Token: 0x060003C0 RID: 960 RVA: 0x00022F93 File Offset: 0x00021193
			// (set) Token: 0x060003C1 RID: 961 RVA: 0x00022F9B File Offset: 0x0002119B
			public DirectShow.ISampleGrabber Grabber { get; set; }

			// Token: 0x17000047 RID: 71
			// (get) Token: 0x060003C2 RID: 962 RVA: 0x00022FA4 File Offset: 0x000211A4
			// (set) Token: 0x060003C3 RID: 963 RVA: 0x00022FAC File Offset: 0x000211AC
			public int Width { get; set; }

			// Token: 0x17000048 RID: 72
			// (get) Token: 0x060003C4 RID: 964 RVA: 0x00022FB5 File Offset: 0x000211B5
			// (set) Token: 0x060003C5 RID: 965 RVA: 0x00022FBD File Offset: 0x000211BD
			public int Height { get; set; }

			// Token: 0x17000049 RID: 73
			// (get) Token: 0x060003C6 RID: 966 RVA: 0x00022FC6 File Offset: 0x000211C6
			// (set) Token: 0x060003C7 RID: 967 RVA: 0x00022FCE File Offset: 0x000211CE
			public int Stride { get; set; }
		}

		// Token: 0x0200010A RID: 266
		public class PropertyItems
		{
			// Token: 0x060003C9 RID: 969 RVA: 0x00022FE0 File Offset: 0x000211E0
			public PropertyItems(DirectShow.IBaseFilter vcap_source)
			{
				this.CameraControl = Enum.GetValues(typeof(DirectShow.CameraControlProperty)).Cast<DirectShow.CameraControlProperty>().Select(delegate(DirectShow.CameraControlProperty item)
				{
					UsbCamera.PropertyItems.Property value2 = null;
					try
					{
						DirectShow.IAMCameraControl cam_ctrl = vcap_source as DirectShow.IAMCameraControl;
						if (cam_ctrl == null)
						{
							throw new NotSupportedException("no IAMCameraControl Interface.");
						}
						int min = 0;
						int max = 0;
						int step = 0;
						int @default = 0;
						int flags = 0;
						cam_ctrl.GetRange(item, ref min, ref max, ref step, ref @default, ref flags);
						Action<DirectShow.CameraControlFlags, int> set = delegate(DirectShow.CameraControlFlags flag, int value)
						{
							cam_ctrl.Set(item, value, (int)flag);
						};
						Func<int> get = delegate()
						{
							int result = 0;
							cam_ctrl.Get(item, ref result, ref flags);
							return result;
						};
						value2 = new UsbCamera.PropertyItems.Property(min, max, step, @default, flags, set, get);
					}
					catch (Exception)
					{
						value2 = new UsbCamera.PropertyItems.Property();
					}
					return new
					{
						Key = item,
						Value = value2
					};
				}).ToDictionary(x => x.Key, x => x.Value);
				this.VideoProcAmp = Enum.GetValues(typeof(DirectShow.VideoProcAmpProperty)).Cast<DirectShow.VideoProcAmpProperty>().Select(delegate(DirectShow.VideoProcAmpProperty item)
				{
					UsbCamera.PropertyItems.Property value2 = null;
					try
					{
						DirectShow.IAMVideoProcAmp vid_ctrl = vcap_source as DirectShow.IAMVideoProcAmp;
						if (vid_ctrl == null)
						{
							throw new NotSupportedException("no IAMVideoProcAmp Interface.");
						}
						int min = 0;
						int max = 0;
						int step = 0;
						int @default = 0;
						int flags = 0;
						vid_ctrl.GetRange(item, ref min, ref max, ref step, ref @default, ref flags);
						Action<DirectShow.CameraControlFlags, int> set = delegate(DirectShow.CameraControlFlags flag, int value)
						{
							vid_ctrl.Set(item, value, (int)flag);
						};
						Func<int> get = delegate()
						{
							int result = 0;
							vid_ctrl.Get(item, ref result, ref flags);
							return result;
						};
						value2 = new UsbCamera.PropertyItems.Property(min, max, step, @default, flags, set, get);
					}
					catch (Exception)
					{
						value2 = new UsbCamera.PropertyItems.Property();
					}
					return new
					{
						Key = item,
						Value = value2
					};
				}).ToDictionary(x => x.Key, x => x.Value);
			}

			// Token: 0x1700004A RID: 74
			public UsbCamera.PropertyItems.Property this[DirectShow.CameraControlProperty item]
			{
				get
				{
					return this.CameraControl[item];
				}
			}

			// Token: 0x1700004B RID: 75
			public UsbCamera.PropertyItems.Property this[DirectShow.VideoProcAmpProperty item]
			{
				get
				{
					return this.VideoProcAmp[item];
				}
			}

			// Token: 0x040004E4 RID: 1252
			private Dictionary<DirectShow.CameraControlProperty, UsbCamera.PropertyItems.Property> CameraControl;

			// Token: 0x040004E5 RID: 1253
			private Dictionary<DirectShow.VideoProcAmpProperty, UsbCamera.PropertyItems.Property> VideoProcAmp;

			// Token: 0x0200016B RID: 363
			public class Property
			{
				// Token: 0x17000058 RID: 88
				// (get) Token: 0x06000511 RID: 1297 RVA: 0x00025A7E File Offset: 0x00023C7E
				// (set) Token: 0x06000512 RID: 1298 RVA: 0x00025A86 File Offset: 0x00023C86
				public int Min { get; private set; }

				// Token: 0x17000059 RID: 89
				// (get) Token: 0x06000513 RID: 1299 RVA: 0x00025A8F File Offset: 0x00023C8F
				// (set) Token: 0x06000514 RID: 1300 RVA: 0x00025A97 File Offset: 0x00023C97
				public int Max { get; private set; }

				// Token: 0x1700005A RID: 90
				// (get) Token: 0x06000515 RID: 1301 RVA: 0x00025AA0 File Offset: 0x00023CA0
				// (set) Token: 0x06000516 RID: 1302 RVA: 0x00025AA8 File Offset: 0x00023CA8
				public int Step { get; private set; }

				// Token: 0x1700005B RID: 91
				// (get) Token: 0x06000517 RID: 1303 RVA: 0x00025AB1 File Offset: 0x00023CB1
				// (set) Token: 0x06000518 RID: 1304 RVA: 0x00025AB9 File Offset: 0x00023CB9
				public int Default { get; private set; }

				// Token: 0x1700005C RID: 92
				// (get) Token: 0x06000519 RID: 1305 RVA: 0x00025AC2 File Offset: 0x00023CC2
				// (set) Token: 0x0600051A RID: 1306 RVA: 0x00025ACA File Offset: 0x00023CCA
				public DirectShow.CameraControlFlags Flags { get; private set; }

				// Token: 0x1700005D RID: 93
				// (get) Token: 0x0600051B RID: 1307 RVA: 0x00025AD3 File Offset: 0x00023CD3
				// (set) Token: 0x0600051C RID: 1308 RVA: 0x00025ADB File Offset: 0x00023CDB
				public Action<DirectShow.CameraControlFlags, int> SetValue { get; private set; }

				// Token: 0x1700005E RID: 94
				// (get) Token: 0x0600051D RID: 1309 RVA: 0x00025AE4 File Offset: 0x00023CE4
				// (set) Token: 0x0600051E RID: 1310 RVA: 0x00025AEC File Offset: 0x00023CEC
				public Func<int> GetValue { get; private set; }

				// Token: 0x1700005F RID: 95
				// (get) Token: 0x0600051F RID: 1311 RVA: 0x00025AF5 File Offset: 0x00023CF5
				// (set) Token: 0x06000520 RID: 1312 RVA: 0x00025AFD File Offset: 0x00023CFD
				public bool Available { get; private set; }

				// Token: 0x17000060 RID: 96
				// (get) Token: 0x06000521 RID: 1313 RVA: 0x00025B06 File Offset: 0x00023D06
				// (set) Token: 0x06000522 RID: 1314 RVA: 0x00025B0E File Offset: 0x00023D0E
				public bool CanAuto { get; private set; }

				// Token: 0x06000523 RID: 1315 RVA: 0x00025B17 File Offset: 0x00023D17
				public Property()
				{
					this.SetValue = delegate(DirectShow.CameraControlFlags flag, int value)
					{
					};
					this.Available = false;
				}

				// Token: 0x06000524 RID: 1316 RVA: 0x00025B4C File Offset: 0x00023D4C
				public Property(int min, int max, int step, int @default, int flags, Action<DirectShow.CameraControlFlags, int> set, Func<int> get)
				{
					this.Min = min;
					this.Max = max;
					this.Step = step;
					this.Default = @default;
					this.Flags = (DirectShow.CameraControlFlags)flags;
					this.CanAuto = ((this.Flags & DirectShow.CameraControlFlags.Auto) == DirectShow.CameraControlFlags.Auto);
					this.SetValue = set;
					this.GetValue = get;
					this.Available = true;
				}

				// Token: 0x06000525 RID: 1317 RVA: 0x00025BAC File Offset: 0x00023DAC
				public override string ToString()
				{
					return string.Format("Available={0}, Min={1}, Max={2}, Step={3}, Default={4}, Flags={5}", new object[]
					{
						this.Available,
						this.Min,
						this.Max,
						this.Step,
						this.Default,
						this.Flags
					});
				}
			}
		}

		// Token: 0x0200010B RID: 267
		private class SampleGrabberCallback : DirectShow.ISampleGrabberCB
		{
			// Token: 0x1700004C RID: 76
			// (get) Token: 0x060003CC RID: 972 RVA: 0x000230F8 File Offset: 0x000212F8
			// (set) Token: 0x060003CD RID: 973 RVA: 0x00023100 File Offset: 0x00021300
			public Action<Bitmap> Buffered { get; set; }

			// Token: 0x060003CE RID: 974 RVA: 0x0002310C File Offset: 0x0002130C
			public SampleGrabberCallback(DirectShow.ISampleGrabber grabber, int width, int height, int stride, bool useCache)
			{
				this.BmpBuilder = new UsbCamera.BitmapBuilder(width, height, stride, useCache);
				this.BufferedEvent = new AutoResetEvent(false);
				ThreadPool.QueueUserWorkItem(delegate(object x)
				{
					for (;;)
					{
						this.BufferedEvent.WaitOne();
						Action<Bitmap> buffered = this.Buffered;
						if (buffered != null)
						{
							buffered(this.GetBitmap());
						}
					}
				});
				grabber.SetCallback(this, 1);
			}

			// Token: 0x060003CF RID: 975 RVA: 0x00023164 File Offset: 0x00021364
			public Bitmap GetBitmap()
			{
				if (this.Buffer == null)
				{
					return UsbCamera.BitmapBuilder.EmptyBitmap;
				}
				object bufferLock = this.BufferLock;
				Bitmap result;
				lock (bufferLock)
				{
					result = this.BmpBuilder.BufferToBitmap(this.Buffer);
				}
				return result;
			}

			// Token: 0x060003D0 RID: 976 RVA: 0x000231C0 File Offset: 0x000213C0
			public int BufferCB(double SampleTime, IntPtr pBuffer, int BufferLen)
			{
				if (this.Buffer == null || this.Buffer.Length != BufferLen)
				{
					this.Buffer = new byte[BufferLen];
				}
				bool flag = false;
				try
				{
					Monitor.TryEnter(this.BufferLock, 0, ref flag);
					if (flag)
					{
						Marshal.Copy(pBuffer, this.Buffer, 0, BufferLen);
					}
				}
				finally
				{
					if (flag)
					{
						Monitor.Exit(this.BufferLock);
					}
				}
				if (this.Buffered != null)
				{
					this.BufferedEvent.Set();
				}
				return 0;
			}

			// Token: 0x060003D1 RID: 977 RVA: 0x00023244 File Offset: 0x00021444
			public int SampleCB(double SampleTime, DirectShow.IMediaSample pSample)
			{
				throw new NotImplementedException();
			}

			// Token: 0x040004E6 RID: 1254
			private byte[] Buffer;

			// Token: 0x040004E7 RID: 1255
			private object BufferLock = new object();

			// Token: 0x040004E9 RID: 1257
			private AutoResetEvent BufferedEvent;

			// Token: 0x040004EA RID: 1258
			private UsbCamera.BitmapBuilder BmpBuilder;
		}

		// Token: 0x0200010C RID: 268
		private class SampleGrabberBuffer
		{
			// Token: 0x060003D3 RID: 979 RVA: 0x00023271 File Offset: 0x00021471
			public SampleGrabberBuffer(DirectShow.ISampleGrabber grabber, int width, int height, int stride)
			{
				this.Grabber = grabber;
				this.BmpBuilder = new UsbCamera.BitmapBuilder(width, height, stride, false);
			}

			// Token: 0x060003D4 RID: 980 RVA: 0x00023290 File Offset: 0x00021490
			public Bitmap GetBitmap()
			{
				Bitmap result;
				try
				{
					result = this.GetBitmapMain();
				}
				catch (COMException ex)
				{
					if (ex.ErrorCode != -2147220953)
					{
						throw;
					}
					result = UsbCamera.BitmapBuilder.EmptyBitmap;
				}
				return result;
			}

			// Token: 0x060003D5 RID: 981 RVA: 0x000232D0 File Offset: 0x000214D0
			private Bitmap GetBitmapMain()
			{
				int num = 0;
				this.Grabber.GetCurrentBuffer(ref num, IntPtr.Zero);
				if (num == 0)
				{
					return null;
				}
				if (this.Buffer == null || num != this.Buffer.Length)
				{
					if (this.BufPtr != IntPtr.Zero)
					{
						Marshal.FreeCoTaskMem(this.BufPtr);
					}
					this.BufPtr = Marshal.AllocCoTaskMem(num);
					this.Buffer = new byte[num];
				}
				this.Grabber.GetCurrentBuffer(ref num, this.BufPtr);
				Marshal.Copy(this.BufPtr, this.Buffer, 0, num);
				return this.BmpBuilder.BufferToBitmap(this.Buffer);
			}

			// Token: 0x040004EB RID: 1259
			private DirectShow.ISampleGrabber Grabber;

			// Token: 0x040004EC RID: 1260
			private IntPtr BufPtr;

			// Token: 0x040004ED RID: 1261
			private byte[] Buffer;

			// Token: 0x040004EE RID: 1262
			private UsbCamera.BitmapBuilder BmpBuilder;
		}

		// Token: 0x0200010D RID: 269
		private class BitmapBuilder
		{
			// Token: 0x060003D6 RID: 982 RVA: 0x00023377 File Offset: 0x00021577
			public BitmapBuilder(int width, int height, int stride, bool dummy)
			{
				this.Width = width;
				this.Height = height;
				this.Stride = stride;
				UsbCamera.BitmapBuilder.EmptyBitmap = new Bitmap(width, height);
			}

			// Token: 0x060003D7 RID: 983 RVA: 0x000233A0 File Offset: 0x000215A0
			public Bitmap BufferToBitmap(byte[] buffer)
			{
				Bitmap bitmap = new Bitmap(this.Width, this.Height, PixelFormat.Format24bppRgb);
				BitmapData bitmapData = bitmap.LockBits(new Rectangle(Point.Empty, bitmap.Size), ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);
				for (int i = 0; i < this.Height; i++)
				{
					int startIndex = buffer.Length - this.Stride * (i + 1);
					IntPtr destination = IntPtr.Add(bitmapData.Scan0, this.Stride * i);
					Marshal.Copy(buffer, startIndex, destination, this.Stride);
				}
				bitmap.UnlockBits(bitmapData);
				return bitmap;
			}

			// Token: 0x1700004D RID: 77
			// (get) Token: 0x060003D8 RID: 984 RVA: 0x0002342D File Offset: 0x0002162D
			// (set) Token: 0x060003D9 RID: 985 RVA: 0x00023434 File Offset: 0x00021634
			public static Bitmap EmptyBitmap { get; private set; }

			// Token: 0x040004EF RID: 1263
			private int Width;

			// Token: 0x040004F0 RID: 1264
			private int Height;

			// Token: 0x040004F1 RID: 1265
			private int Stride;
		}

		// Token: 0x0200010E RID: 270
		public class VideoFormat
		{
			// Token: 0x1700004E RID: 78
			// (get) Token: 0x060003DA RID: 986 RVA: 0x0002343C File Offset: 0x0002163C
			// (set) Token: 0x060003DB RID: 987 RVA: 0x00023444 File Offset: 0x00021644
			public string MajorType { get; set; }

			// Token: 0x1700004F RID: 79
			// (get) Token: 0x060003DC RID: 988 RVA: 0x0002344D File Offset: 0x0002164D
			// (set) Token: 0x060003DD RID: 989 RVA: 0x00023455 File Offset: 0x00021655
			public string SubType { get; set; }

			// Token: 0x17000050 RID: 80
			// (get) Token: 0x060003DE RID: 990 RVA: 0x0002345E File Offset: 0x0002165E
			// (set) Token: 0x060003DF RID: 991 RVA: 0x00023466 File Offset: 0x00021666
			public Size Size { get; set; }

			// Token: 0x17000051 RID: 81
			// (get) Token: 0x060003E0 RID: 992 RVA: 0x0002346F File Offset: 0x0002166F
			// (set) Token: 0x060003E1 RID: 993 RVA: 0x00023477 File Offset: 0x00021677
			public long TimePerFrame { get; set; }

			// Token: 0x17000052 RID: 82
			// (get) Token: 0x060003E2 RID: 994 RVA: 0x00023480 File Offset: 0x00021680
			// (set) Token: 0x060003E3 RID: 995 RVA: 0x00023488 File Offset: 0x00021688
			public DirectShow.VIDEO_STREAM_CONFIG_CAPS Caps { get; set; }

			// Token: 0x060003E4 RID: 996 RVA: 0x00023494 File Offset: 0x00021694
			public override string ToString()
			{
				return string.Format("{0}, {1}, {2}, {3}, {4}", new object[]
				{
					this.MajorType,
					this.SubType,
					this.Size,
					this.TimePerFrame,
					this.CapsString()
				});
			}

			// Token: 0x060003E5 RID: 997 RVA: 0x000234E8 File Offset: 0x000216E8
			private string CapsString()
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.AppendFormat("{0}, ", DirectShow.DsGuid.GetNickname(this.Caps.Guid));
				foreach (FieldInfo fieldInfo in this.Caps.GetType().GetFields())
				{
					stringBuilder.AppendFormat("{0}={1}, ", fieldInfo.Name, fieldInfo.GetValue(this.Caps));
				}
				return stringBuilder.ToString();
			}
		}
	}
}
