﻿using System;

namespace SHARP
{
	// Token: 0x0200000B RID: 11
	internal struct CookieSteam
	{
		// Token: 0x1700000A RID: 10
		// (get) Token: 0x0600003D RID: 61 RVA: 0x00002E1A File Offset: 0x0000101A
		// (set) Token: 0x0600003E RID: 62 RVA: 0x00002E22 File Offset: 0x00001022
		public string Host { get; set; }

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x0600003F RID: 63 RVA: 0x00002E2B File Offset: 0x0000102B
		// (set) Token: 0x06000040 RID: 64 RVA: 0x00002E33 File Offset: 0x00001033
		public string Name { get; set; }

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000041 RID: 65 RVA: 0x00002E3C File Offset: 0x0000103C
		// (set) Token: 0x06000042 RID: 66 RVA: 0x00002E44 File Offset: 0x00001044
		public string Path { get; set; }

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000043 RID: 67 RVA: 0x00002E4D File Offset: 0x0000104D
		// (set) Token: 0x06000044 RID: 68 RVA: 0x00002E55 File Offset: 0x00001055
		public string ExpiresUtc { get; set; }

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000045 RID: 69 RVA: 0x00002E5E File Offset: 0x0000105E
		// (set) Token: 0x06000046 RID: 70 RVA: 0x00002E66 File Offset: 0x00001066
		public string Key { get; set; }
	}
}
