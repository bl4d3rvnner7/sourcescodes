﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace SHARP
{
	// Token: 0x02000047 RID: 71
	internal class AES
	{
		// Token: 0x0600014B RID: 331 RVA: 0x00007388 File Offset: 0x00005588
		public static string EncryptStringAES(string plainText, string sharedSecret)
		{
			if (string.IsNullOrEmpty(plainText))
			{
				throw new ArgumentNullException("plainText");
			}
			if (string.IsNullOrEmpty(sharedSecret))
			{
				throw new ArgumentNullException("sharedSecret");
			}
			string result = "";
			RijndaelManaged rijndaelManaged = null;
			try
			{
				Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(sharedSecret, AES.Salt);
				rijndaelManaged = new RijndaelManaged();
				rijndaelManaged.Key = rfc2898DeriveBytes.GetBytes(rijndaelManaged.KeySize / 8);
				ICryptoTransform transform = rijndaelManaged.CreateEncryptor(rijndaelManaged.Key, rijndaelManaged.IV);
				using (MemoryStream memoryStream = new MemoryStream())
				{
					memoryStream.Write(BitConverter.GetBytes(rijndaelManaged.IV.Length), 0, 4);
					memoryStream.Write(rijndaelManaged.IV, 0, rijndaelManaged.IV.Length);
					using (CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write))
					{
						using (StreamWriter streamWriter = new StreamWriter(cryptoStream))
						{
							streamWriter.Write(plainText);
						}
					}
					result = Convert.ToBase64String(memoryStream.ToArray());
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
				return result;
			}
			finally
			{
				if (rijndaelManaged != null)
				{
					rijndaelManaged.Clear();
				}
			}
			return result;
		}

		// Token: 0x040000AC RID: 172
		private static readonly byte[] Salt = Encoding.ASCII.GetBytes("o6806642kbM7c5");
	}
}
