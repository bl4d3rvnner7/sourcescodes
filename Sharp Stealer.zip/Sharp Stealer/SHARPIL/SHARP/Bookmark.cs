﻿using System;

namespace SHARP
{
	// Token: 0x02000010 RID: 16
	internal struct Bookmark
	{
		// Token: 0x1700001E RID: 30
		// (get) Token: 0x06000065 RID: 101 RVA: 0x00002F6E File Offset: 0x0000116E
		// (set) Token: 0x06000066 RID: 102 RVA: 0x00002F76 File Offset: 0x00001176
		public string sUrl { get; set; }

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x06000067 RID: 103 RVA: 0x00002F7F File Offset: 0x0000117F
		// (set) Token: 0x06000068 RID: 104 RVA: 0x00002F87 File Offset: 0x00001187
		public string sTitle { get; set; }
	}
}
