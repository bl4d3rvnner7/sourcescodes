﻿using System;
using System.Text.RegularExpressions;

namespace SHARP.Chromium
{
	// Token: 0x0200007D RID: 125
	internal sealed class Parser
	{
		// Token: 0x060002A2 RID: 674 RVA: 0x000101F0 File Offset: 0x0000E3F0
		public static string RemoveLatest(string data)
		{
			return Regex.Split(Regex.Split(data, "\",")[0], "\"")[0];
		}

		// Token: 0x060002A3 RID: 675 RVA: 0x0001020B File Offset: 0x0000E40B
		public static bool DetectTitle(string data)
		{
			return data.Contains("\"name");
		}

		// Token: 0x060002A4 RID: 676 RVA: 0x00010218 File Offset: 0x0000E418
		public static string Get(string data, int index)
		{
			string result;
			try
			{
				result = Parser.RemoveLatest(Regex.Split(data, Parser.separator)[index]);
			}
			catch (IndexOutOfRangeException)
			{
				result = "Failed to parse url";
			}
			return result;
		}

		// Token: 0x0400014A RID: 330
		public static string separator = "\": \"";
	}
}
