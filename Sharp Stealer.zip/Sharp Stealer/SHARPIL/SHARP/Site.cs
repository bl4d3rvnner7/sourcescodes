﻿using System;

namespace SHARP
{
	// Token: 0x0200000F RID: 15
	internal struct Site
	{
		// Token: 0x1700001B RID: 27
		// (get) Token: 0x0600005F RID: 95 RVA: 0x00002F3B File Offset: 0x0000113B
		// (set) Token: 0x06000060 RID: 96 RVA: 0x00002F43 File Offset: 0x00001143
		public string sUrl { get; set; }

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x06000061 RID: 97 RVA: 0x00002F4C File Offset: 0x0000114C
		// (set) Token: 0x06000062 RID: 98 RVA: 0x00002F54 File Offset: 0x00001154
		public string sTitle { get; set; }

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x06000063 RID: 99 RVA: 0x00002F5D File Offset: 0x0000115D
		// (set) Token: 0x06000064 RID: 100 RVA: 0x00002F65 File Offset: 0x00001165
		public int iCount { get; set; }
	}
}
