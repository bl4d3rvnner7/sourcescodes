﻿using System;

namespace SHARP
{
	// Token: 0x0200003C RID: 60
	internal struct Promotion
	{
		// Token: 0x17000020 RID: 32
		// (get) Token: 0x06000116 RID: 278 RVA: 0x000067FA File Offset: 0x000049FA
		// (set) Token: 0x06000117 RID: 279 RVA: 0x00006802 File Offset: 0x00004A02
		internal string outbound_title { get; set; }
	}
}
