﻿using System;

namespace SHARP
{
	// Token: 0x02000023 RID: 35
	internal struct CookieFormat
	{
		// Token: 0x060000C7 RID: 199 RVA: 0x000053B6 File Offset: 0x000035B6
		internal CookieFormat(string host, string name, string path, string cookie, ulong expiry)
		{
			this.Host = host;
			this.Name = name;
			this.Path = path;
			this.Cookie = cookie;
			this.Expiry = expiry;
		}

		// Token: 0x04000054 RID: 84
		internal string Host;

		// Token: 0x04000055 RID: 85
		internal string Name;

		// Token: 0x04000056 RID: 86
		internal string Path;

		// Token: 0x04000057 RID: 87
		internal string Cookie;

		// Token: 0x04000058 RID: 88
		internal ulong Expiry;
	}
}
