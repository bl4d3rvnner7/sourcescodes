﻿using System;

namespace SHARP
{
	// Token: 0x0200003F RID: 63
	internal struct BillingResponseJsonFormat
	{
		// Token: 0x1700002B RID: 43
		// (get) Token: 0x0600012C RID: 300 RVA: 0x000068B5 File Offset: 0x00004AB5
		// (set) Token: 0x0600012D RID: 301 RVA: 0x000068BD File Offset: 0x00004ABD
		internal int type { get; set; }
	}
}
