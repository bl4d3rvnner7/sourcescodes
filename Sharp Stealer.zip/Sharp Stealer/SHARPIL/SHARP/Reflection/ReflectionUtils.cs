﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq.Expressions;
using System.Reflection;

namespace SHARP.Reflection
{
	// Token: 0x02000070 RID: 112
	[GeneratedCode("reflection-utils", "1.0.0")]
	internal class ReflectionUtils
	{
		// Token: 0x06000255 RID: 597 RVA: 0x0000EE20 File Offset: 0x0000D020
		public static Type GetTypeInfo(Type type)
		{
			return type;
		}

		// Token: 0x06000256 RID: 598 RVA: 0x0000EE23 File Offset: 0x0000D023
		public static Attribute GetAttribute(MemberInfo info, Type type)
		{
			if (info == null || type == null || !Attribute.IsDefined(info, type))
			{
				return null;
			}
			return Attribute.GetCustomAttribute(info, type);
		}

		// Token: 0x06000257 RID: 599 RVA: 0x0000EE4C File Offset: 0x0000D04C
		public static Type GetGenericListElementType(Type type)
		{
			foreach (Type type2 in ((IEnumerable<Type>)type.GetInterfaces()))
			{
				if (ReflectionUtils.IsTypeGeneric(type2) && type2.GetGenericTypeDefinition() == typeof(IList<>))
				{
					return ReflectionUtils.GetGenericTypeArguments(type2)[0];
				}
			}
			return ReflectionUtils.GetGenericTypeArguments(type)[0];
		}

		// Token: 0x06000258 RID: 600 RVA: 0x0000EEC8 File Offset: 0x0000D0C8
		public static Attribute GetAttribute(Type objectType, Type attributeType)
		{
			if (objectType == null || attributeType == null || !Attribute.IsDefined(objectType, attributeType))
			{
				return null;
			}
			return Attribute.GetCustomAttribute(objectType, attributeType);
		}

		// Token: 0x06000259 RID: 601 RVA: 0x0000EEEE File Offset: 0x0000D0EE
		public static Type[] GetGenericTypeArguments(Type type)
		{
			return type.GetGenericArguments();
		}

		// Token: 0x0600025A RID: 602 RVA: 0x0000EEF6 File Offset: 0x0000D0F6
		public static bool IsTypeGeneric(Type type)
		{
			return ReflectionUtils.GetTypeInfo(type).IsGenericType;
		}

		// Token: 0x0600025B RID: 603 RVA: 0x0000EF04 File Offset: 0x0000D104
		public static bool IsTypeGenericeCollectionInterface(Type type)
		{
			if (!ReflectionUtils.IsTypeGeneric(type))
			{
				return false;
			}
			Type genericTypeDefinition = type.GetGenericTypeDefinition();
			return genericTypeDefinition == typeof(IList<>) || genericTypeDefinition == typeof(ICollection<>) || genericTypeDefinition == typeof(IEnumerable<>);
		}

		// Token: 0x0600025C RID: 604 RVA: 0x0000EF58 File Offset: 0x0000D158
		public static bool IsAssignableFrom(Type type1, Type type2)
		{
			return ReflectionUtils.GetTypeInfo(type1).IsAssignableFrom(ReflectionUtils.GetTypeInfo(type2));
		}

		// Token: 0x0600025D RID: 605 RVA: 0x0000EF6B File Offset: 0x0000D16B
		public static bool IsTypeDictionary(Type type)
		{
			return typeof(IDictionary).IsAssignableFrom(type) || (ReflectionUtils.GetTypeInfo(type).IsGenericType && type.GetGenericTypeDefinition() == typeof(IDictionary<, >));
		}

		// Token: 0x0600025E RID: 606 RVA: 0x0000EFA5 File Offset: 0x0000D1A5
		public static bool IsNullableType(Type type)
		{
			return ReflectionUtils.GetTypeInfo(type).IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>);
		}

		// Token: 0x0600025F RID: 607 RVA: 0x0000EFCB File Offset: 0x0000D1CB
		public static object ToNullableType(object obj, Type nullableType)
		{
			if (obj != null)
			{
				return Convert.ChangeType(obj, Nullable.GetUnderlyingType(nullableType), CultureInfo.InvariantCulture);
			}
			return null;
		}

		// Token: 0x06000260 RID: 608 RVA: 0x0000EFE3 File Offset: 0x0000D1E3
		public static bool IsValueType(Type type)
		{
			return ReflectionUtils.GetTypeInfo(type).IsValueType;
		}

		// Token: 0x06000261 RID: 609 RVA: 0x0000EFF0 File Offset: 0x0000D1F0
		public static IEnumerable<ConstructorInfo> GetConstructors(Type type)
		{
			return type.GetConstructors();
		}

		// Token: 0x06000262 RID: 610 RVA: 0x0000EFF8 File Offset: 0x0000D1F8
		public static ConstructorInfo GetConstructorInfo(Type type, params Type[] argsType)
		{
			foreach (ConstructorInfo constructorInfo in ReflectionUtils.GetConstructors(type))
			{
				ParameterInfo[] parameters = constructorInfo.GetParameters();
				if (argsType.Length == parameters.Length)
				{
					int num = 0;
					bool flag = true;
					ParameterInfo[] parameters2 = constructorInfo.GetParameters();
					for (int i = 0; i < parameters2.Length; i++)
					{
						if (parameters2[i].ParameterType != argsType[num])
						{
							flag = false;
							break;
						}
					}
					if (flag)
					{
						return constructorInfo;
					}
				}
			}
			return null;
		}

		// Token: 0x06000263 RID: 611 RVA: 0x0000F094 File Offset: 0x0000D294
		public static IEnumerable<PropertyInfo> GetProperties(Type type)
		{
			return type.GetProperties(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
		}

		// Token: 0x06000264 RID: 612 RVA: 0x0000F09E File Offset: 0x0000D29E
		public static IEnumerable<FieldInfo> GetFields(Type type)
		{
			return type.GetFields(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
		}

		// Token: 0x06000265 RID: 613 RVA: 0x0000F0A8 File Offset: 0x0000D2A8
		public static MethodInfo GetGetterMethodInfo(PropertyInfo propertyInfo)
		{
			return propertyInfo.GetGetMethod(true);
		}

		// Token: 0x06000266 RID: 614 RVA: 0x0000F0B1 File Offset: 0x0000D2B1
		public static MethodInfo GetSetterMethodInfo(PropertyInfo propertyInfo)
		{
			return propertyInfo.GetSetMethod(true);
		}

		// Token: 0x06000267 RID: 615 RVA: 0x0000F0BA File Offset: 0x0000D2BA
		public static ReflectionUtils.ConstructorDelegate GetContructor(ConstructorInfo constructorInfo)
		{
			return ReflectionUtils.GetConstructorByExpression(constructorInfo);
		}

		// Token: 0x06000268 RID: 616 RVA: 0x0000F0C2 File Offset: 0x0000D2C2
		public static ReflectionUtils.ConstructorDelegate GetContructor(Type type, params Type[] argsType)
		{
			return ReflectionUtils.GetConstructorByExpression(type, argsType);
		}

		// Token: 0x06000269 RID: 617 RVA: 0x0000F0CB File Offset: 0x0000D2CB
		public static ReflectionUtils.ConstructorDelegate GetConstructorByReflection(ConstructorInfo constructorInfo)
		{
			return (object[] args) => constructorInfo.Invoke(args);
		}

		// Token: 0x0600026A RID: 618 RVA: 0x0000F0E4 File Offset: 0x0000D2E4
		public static ReflectionUtils.ConstructorDelegate GetConstructorByReflection(Type type, params Type[] argsType)
		{
			ConstructorInfo constructorInfo = ReflectionUtils.GetConstructorInfo(type, argsType);
			if (!(constructorInfo == null))
			{
				return ReflectionUtils.GetConstructorByReflection(constructorInfo);
			}
			return null;
		}

		// Token: 0x0600026B RID: 619 RVA: 0x0000F10C File Offset: 0x0000D30C
		public static ReflectionUtils.ConstructorDelegate GetConstructorByExpression(ConstructorInfo constructorInfo)
		{
			ParameterInfo[] parameters = constructorInfo.GetParameters();
			ParameterExpression parameterExpression = Expression.Parameter(typeof(object[]), "args");
			Expression[] array = new Expression[parameters.Length];
			for (int i = 0; i < parameters.Length; i++)
			{
				Expression index = Expression.Constant(i);
				Type parameterType = parameters[i].ParameterType;
				Expression expression = Expression.Convert(Expression.ArrayIndex(parameterExpression, index), parameterType);
				array[i] = expression;
			}
			Expression<Func<object[], object>> expression2 = Expression.Lambda<Func<object[], object>>(Expression.New(constructorInfo, array), new ParameterExpression[]
			{
				parameterExpression
			});
			Func<object[], object> compiledLambda = expression2.Compile();
			return (object[] args) => compiledLambda(args);
		}

		// Token: 0x0600026C RID: 620 RVA: 0x0000F1B8 File Offset: 0x0000D3B8
		public static ReflectionUtils.ConstructorDelegate GetConstructorByExpression(Type type, params Type[] argsType)
		{
			ConstructorInfo constructorInfo = ReflectionUtils.GetConstructorInfo(type, argsType);
			if (!(constructorInfo == null))
			{
				return ReflectionUtils.GetConstructorByExpression(constructorInfo);
			}
			return null;
		}

		// Token: 0x0600026D RID: 621 RVA: 0x0000F1DE File Offset: 0x0000D3DE
		public static ReflectionUtils.GetDelegate GetGetMethod(PropertyInfo propertyInfo)
		{
			return ReflectionUtils.GetGetMethodByExpression(propertyInfo);
		}

		// Token: 0x0600026E RID: 622 RVA: 0x0000F1E6 File Offset: 0x0000D3E6
		public static ReflectionUtils.GetDelegate GetGetMethod(FieldInfo fieldInfo)
		{
			return ReflectionUtils.GetGetMethodByExpression(fieldInfo);
		}

		// Token: 0x0600026F RID: 623 RVA: 0x0000F1EE File Offset: 0x0000D3EE
		public static ReflectionUtils.GetDelegate GetGetMethodByReflection(PropertyInfo propertyInfo)
		{
			MethodInfo methodInfo = ReflectionUtils.GetGetterMethodInfo(propertyInfo);
			return (object source) => methodInfo.Invoke(source, ReflectionUtils.EmptyObjects);
		}

		// Token: 0x06000270 RID: 624 RVA: 0x0000F20C File Offset: 0x0000D40C
		public static ReflectionUtils.GetDelegate GetGetMethodByReflection(FieldInfo fieldInfo)
		{
			return (object source) => fieldInfo.GetValue(source);
		}

		// Token: 0x06000271 RID: 625 RVA: 0x0000F228 File Offset: 0x0000D428
		public static ReflectionUtils.GetDelegate GetGetMethodByExpression(PropertyInfo propertyInfo)
		{
			MethodInfo getterMethodInfo = ReflectionUtils.GetGetterMethodInfo(propertyInfo);
			ParameterExpression parameterExpression = Expression.Parameter(typeof(object), "instance");
			UnaryExpression instance = (!ReflectionUtils.IsValueType(propertyInfo.DeclaringType)) ? Expression.TypeAs(parameterExpression, propertyInfo.DeclaringType) : Expression.Convert(parameterExpression, propertyInfo.DeclaringType);
			Func<object, object> compiled = Expression.Lambda<Func<object, object>>(Expression.TypeAs(Expression.Call(instance, getterMethodInfo), typeof(object)), new ParameterExpression[]
			{
				parameterExpression
			}).Compile();
			return (object source) => compiled(source);
		}

		// Token: 0x06000272 RID: 626 RVA: 0x0000F2BC File Offset: 0x0000D4BC
		public static ReflectionUtils.GetDelegate GetGetMethodByExpression(FieldInfo fieldInfo)
		{
			ParameterExpression parameterExpression = Expression.Parameter(typeof(object), "instance");
			MemberExpression expression = Expression.Field(Expression.Convert(parameterExpression, fieldInfo.DeclaringType), fieldInfo);
			ReflectionUtils.GetDelegate compiled = Expression.Lambda<ReflectionUtils.GetDelegate>(Expression.Convert(expression, typeof(object)), new ParameterExpression[]
			{
				parameterExpression
			}).Compile();
			return (object source) => compiled(source);
		}

		// Token: 0x06000273 RID: 627 RVA: 0x0000F32D File Offset: 0x0000D52D
		public static ReflectionUtils.SetDelegate GetSetMethod(PropertyInfo propertyInfo)
		{
			return ReflectionUtils.GetSetMethodByExpression(propertyInfo);
		}

		// Token: 0x06000274 RID: 628 RVA: 0x0000F335 File Offset: 0x0000D535
		public static ReflectionUtils.SetDelegate GetSetMethod(FieldInfo fieldInfo)
		{
			return ReflectionUtils.GetSetMethodByExpression(fieldInfo);
		}

		// Token: 0x06000275 RID: 629 RVA: 0x0000F33D File Offset: 0x0000D53D
		public static ReflectionUtils.SetDelegate GetSetMethodByReflection(PropertyInfo propertyInfo)
		{
			MethodInfo methodInfo = ReflectionUtils.GetSetterMethodInfo(propertyInfo);
			return delegate(object source, object value)
			{
				methodInfo.Invoke(source, new object[]
				{
					value
				});
			};
		}

		// Token: 0x06000276 RID: 630 RVA: 0x0000F35B File Offset: 0x0000D55B
		public static ReflectionUtils.SetDelegate GetSetMethodByReflection(FieldInfo fieldInfo)
		{
			return delegate(object source, object value)
			{
				fieldInfo.SetValue(source, value);
			};
		}

		// Token: 0x06000277 RID: 631 RVA: 0x0000F374 File Offset: 0x0000D574
		public static ReflectionUtils.SetDelegate GetSetMethodByExpression(PropertyInfo propertyInfo)
		{
			MethodInfo setterMethodInfo = ReflectionUtils.GetSetterMethodInfo(propertyInfo);
			ParameterExpression parameterExpression = Expression.Parameter(typeof(object), "instance");
			ParameterExpression parameterExpression2 = Expression.Parameter(typeof(object), "value");
			UnaryExpression instance = (!ReflectionUtils.IsValueType(propertyInfo.DeclaringType)) ? Expression.TypeAs(parameterExpression, propertyInfo.DeclaringType) : Expression.Convert(parameterExpression, propertyInfo.DeclaringType);
			UnaryExpression unaryExpression = (!ReflectionUtils.IsValueType(propertyInfo.PropertyType)) ? Expression.TypeAs(parameterExpression2, propertyInfo.PropertyType) : Expression.Convert(parameterExpression2, propertyInfo.PropertyType);
			Action<object, object> compiled = Expression.Lambda<Action<object, object>>(Expression.Call(instance, setterMethodInfo, new Expression[]
			{
				unaryExpression
			}), new ParameterExpression[]
			{
				parameterExpression,
				parameterExpression2
			}).Compile();
			return delegate(object source, object val)
			{
				compiled(source, val);
			};
		}

		// Token: 0x06000278 RID: 632 RVA: 0x0000F448 File Offset: 0x0000D648
		public static ReflectionUtils.SetDelegate GetSetMethodByExpression(FieldInfo fieldInfo)
		{
			ParameterExpression parameterExpression;
			ParameterExpression parameterExpression2;
			Action<object, object> compiled = Expression.Lambda<Action<object, object>>(ReflectionUtils.Assign(Expression.Field(Expression.Convert(parameterExpression, fieldInfo.DeclaringType), fieldInfo), Expression.Convert(parameterExpression2, fieldInfo.FieldType)), new ParameterExpression[]
			{
				parameterExpression,
				parameterExpression2
			}).Compile();
			return delegate(object source, object val)
			{
				compiled(source, val);
			};
		}

		// Token: 0x06000279 RID: 633 RVA: 0x0000F4D4 File Offset: 0x0000D6D4
		public static BinaryExpression Assign(Expression left, Expression right)
		{
			MethodInfo method = typeof(ReflectionUtils.Assigner<>).MakeGenericType(new Type[]
			{
				left.Type
			}).GetMethod("Assign");
			return Expression.Add(left, right, method);
		}

		// Token: 0x04000138 RID: 312
		private static readonly object[] EmptyObjects = new object[0];

		// Token: 0x0200014D RID: 333
		// (Invoke) Token: 0x060004CB RID: 1227
		public delegate object GetDelegate(object source);

		// Token: 0x0200014E RID: 334
		// (Invoke) Token: 0x060004CF RID: 1231
		public delegate void SetDelegate(object source, object value);

		// Token: 0x0200014F RID: 335
		// (Invoke) Token: 0x060004D3 RID: 1235
		public delegate object ConstructorDelegate(params object[] args);

		// Token: 0x02000150 RID: 336
		// (Invoke) Token: 0x060004D7 RID: 1239
		public delegate TValue ThreadSafeDictionaryValueFactory<TKey, TValue>(TKey key);

		// Token: 0x02000151 RID: 337
		private static class Assigner<T>
		{
			// Token: 0x060004DA RID: 1242 RVA: 0x00024A38 File Offset: 0x00022C38
			public static T Assign(ref T left, T right)
			{
				left = right;
				return right;
			}
		}

		// Token: 0x02000152 RID: 338
		public sealed class ThreadSafeDictionary<TKey, TValue> : IDictionary<TKey, TValue>, ICollection<KeyValuePair<TKey, TValue>>, IEnumerable<KeyValuePair<TKey, TValue>>, IEnumerable
		{
			// Token: 0x060004DB RID: 1243 RVA: 0x00024A4F File Offset: 0x00022C4F
			public ThreadSafeDictionary(ReflectionUtils.ThreadSafeDictionaryValueFactory<TKey, TValue> valueFactory)
			{
				this._valueFactory = valueFactory;
			}

			// Token: 0x060004DC RID: 1244 RVA: 0x00024A69 File Offset: 0x00022C69
			public void Add(TKey key, TValue value)
			{
				throw new NotImplementedException();
			}

			// Token: 0x060004DD RID: 1245 RVA: 0x00024A70 File Offset: 0x00022C70
			public bool ContainsKey(TKey key)
			{
				return this._dictionary.ContainsKey(key);
			}

			// Token: 0x17000053 RID: 83
			// (get) Token: 0x060004DE RID: 1246 RVA: 0x00024A7E File Offset: 0x00022C7E
			public ICollection<TKey> Keys
			{
				get
				{
					return this._dictionary.Keys;
				}
			}

			// Token: 0x060004DF RID: 1247 RVA: 0x00024A8B File Offset: 0x00022C8B
			public bool Remove(TKey key)
			{
				throw new NotImplementedException();
			}

			// Token: 0x060004E0 RID: 1248 RVA: 0x00024A92 File Offset: 0x00022C92
			public bool TryGetValue(TKey key, out TValue value)
			{
				value = this[key];
				return true;
			}

			// Token: 0x17000054 RID: 84
			// (get) Token: 0x060004E1 RID: 1249 RVA: 0x00024AA2 File Offset: 0x00022CA2
			public ICollection<TValue> Values
			{
				get
				{
					return this._dictionary.Values;
				}
			}

			// Token: 0x17000055 RID: 85
			public TValue this[TKey key]
			{
				get
				{
					return this.Get(key);
				}
				set
				{
					throw new NotImplementedException();
				}
			}

			// Token: 0x060004E4 RID: 1252 RVA: 0x00024ABF File Offset: 0x00022CBF
			public void Add(KeyValuePair<TKey, TValue> item)
			{
				throw new NotImplementedException();
			}

			// Token: 0x060004E5 RID: 1253 RVA: 0x00024AC6 File Offset: 0x00022CC6
			public void Clear()
			{
				throw new NotImplementedException();
			}

			// Token: 0x060004E6 RID: 1254 RVA: 0x00024ACD File Offset: 0x00022CCD
			public bool Contains(KeyValuePair<TKey, TValue> item)
			{
				throw new NotImplementedException();
			}

			// Token: 0x060004E7 RID: 1255 RVA: 0x00024AD4 File Offset: 0x00022CD4
			public void CopyTo(KeyValuePair<TKey, TValue>[] array, int arrayIndex)
			{
				throw new NotImplementedException();
			}

			// Token: 0x17000056 RID: 86
			// (get) Token: 0x060004E8 RID: 1256 RVA: 0x00024ADB File Offset: 0x00022CDB
			public int Count
			{
				get
				{
					return this._dictionary.Count;
				}
			}

			// Token: 0x17000057 RID: 87
			// (get) Token: 0x060004E9 RID: 1257 RVA: 0x00024AE8 File Offset: 0x00022CE8
			public bool IsReadOnly
			{
				get
				{
					throw new NotImplementedException();
				}
			}

			// Token: 0x060004EA RID: 1258 RVA: 0x00024AEF File Offset: 0x00022CEF
			public bool Remove(KeyValuePair<TKey, TValue> item)
			{
				throw new NotImplementedException();
			}

			// Token: 0x060004EB RID: 1259 RVA: 0x00024AF6 File Offset: 0x00022CF6
			public IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator()
			{
				return this._dictionary.GetEnumerator();
			}

			// Token: 0x060004EC RID: 1260 RVA: 0x00024B08 File Offset: 0x00022D08
			IEnumerator IEnumerable.GetEnumerator()
			{
				return this._dictionary.GetEnumerator();
			}

			// Token: 0x060004ED RID: 1261 RVA: 0x00024B1C File Offset: 0x00022D1C
			private TValue Get(TKey key)
			{
				if (this._dictionary == null)
				{
					return this.AddValue(key);
				}
				TValue result;
				if (!this._dictionary.TryGetValue(key, out result))
				{
					return this.AddValue(key);
				}
				return result;
			}

			// Token: 0x060004EE RID: 1262 RVA: 0x00024B54 File Offset: 0x00022D54
			private TValue AddValue(TKey key)
			{
				TValue tvalue = this._valueFactory(key);
				object @lock = this._lock;
				lock (@lock)
				{
					if (this._dictionary == null)
					{
						this._dictionary = new Dictionary<TKey, TValue>();
						this._dictionary[key] = tvalue;
					}
					else
					{
						TValue result;
						if (this._dictionary.TryGetValue(key, out result))
						{
							return result;
						}
						Dictionary<TKey, TValue> dictionary = new Dictionary<TKey, TValue>(this._dictionary);
						dictionary[key] = tvalue;
						this._dictionary = dictionary;
					}
				}
				return tvalue;
			}

			// Token: 0x040005DE RID: 1502
			private readonly object _lock = new object();

			// Token: 0x040005DF RID: 1503
			private readonly ReflectionUtils.ThreadSafeDictionaryValueFactory<TKey, TValue> _valueFactory;

			// Token: 0x040005E0 RID: 1504
			private Dictionary<TKey, TValue> _dictionary;
		}
	}
}
