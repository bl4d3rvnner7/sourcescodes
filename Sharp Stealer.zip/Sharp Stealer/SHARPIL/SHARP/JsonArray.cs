﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;

namespace SHARP
{
	// Token: 0x0200004D RID: 77
	[GeneratedCode("simple-json", "1.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public class JsonArray : List<object>
	{
		// Token: 0x0600015C RID: 348 RVA: 0x00007D18 File Offset: 0x00005F18
		public JsonArray()
		{
		}

		// Token: 0x0600015D RID: 349 RVA: 0x00007D20 File Offset: 0x00005F20
		public JsonArray(int capacity) : base(capacity)
		{
		}

		// Token: 0x0600015E RID: 350 RVA: 0x00007D29 File Offset: 0x00005F29
		public override string ToString()
		{
			return SimpleJson.SerializeObject(this) ?? string.Empty;
		}
	}
}
