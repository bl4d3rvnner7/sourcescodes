﻿using System;

namespace SHARP
{
	// Token: 0x0200000C RID: 12
	internal struct Cookie
	{
		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000047 RID: 71 RVA: 0x00002E6F File Offset: 0x0000106F
		// (set) Token: 0x06000048 RID: 72 RVA: 0x00002E77 File Offset: 0x00001077
		public string sHostKey { get; set; }

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000049 RID: 73 RVA: 0x00002E80 File Offset: 0x00001080
		// (set) Token: 0x0600004A RID: 74 RVA: 0x00002E88 File Offset: 0x00001088
		public string sName { get; set; }

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x0600004B RID: 75 RVA: 0x00002E91 File Offset: 0x00001091
		// (set) Token: 0x0600004C RID: 76 RVA: 0x00002E99 File Offset: 0x00001099
		public string sPath { get; set; }

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x0600004D RID: 77 RVA: 0x00002EA2 File Offset: 0x000010A2
		// (set) Token: 0x0600004E RID: 78 RVA: 0x00002EAA File Offset: 0x000010AA
		public string sKey { get; set; }

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x0600004F RID: 79 RVA: 0x00002EB3 File Offset: 0x000010B3
		// (set) Token: 0x06000050 RID: 80 RVA: 0x00002EBB File Offset: 0x000010BB
		public string sValue { get; set; }

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x06000051 RID: 81 RVA: 0x00002EC4 File Offset: 0x000010C4
		// (set) Token: 0x06000052 RID: 82 RVA: 0x00002ECC File Offset: 0x000010CC
		public string sIsSecure { get; set; }

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x06000053 RID: 83 RVA: 0x00002ED5 File Offset: 0x000010D5
		// (set) Token: 0x06000054 RID: 84 RVA: 0x00002EDD File Offset: 0x000010DD
		public string sData { get; set; }

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x06000055 RID: 85 RVA: 0x00002EE6 File Offset: 0x000010E6
		// (set) Token: 0x06000056 RID: 86 RVA: 0x00002EEE File Offset: 0x000010EE
		public string sHost { get; set; }

		// Token: 0x04000022 RID: 34
		public string sExpiresUtc;
	}
}
