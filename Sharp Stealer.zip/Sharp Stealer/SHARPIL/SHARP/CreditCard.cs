﻿using System;

namespace SHARP
{
	// Token: 0x0200000D RID: 13
	internal struct CreditCard
	{
		// Token: 0x17000017 RID: 23
		// (get) Token: 0x06000057 RID: 87 RVA: 0x00002EF7 File Offset: 0x000010F7
		// (set) Token: 0x06000058 RID: 88 RVA: 0x00002EFF File Offset: 0x000010FF
		public string sNumber { get; set; }

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x06000059 RID: 89 RVA: 0x00002F08 File Offset: 0x00001108
		// (set) Token: 0x0600005A RID: 90 RVA: 0x00002F10 File Offset: 0x00001110
		public string sExpYear { get; set; }

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x0600005B RID: 91 RVA: 0x00002F19 File Offset: 0x00001119
		// (set) Token: 0x0600005C RID: 92 RVA: 0x00002F21 File Offset: 0x00001121
		public string sExpMonth { get; set; }

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x0600005D RID: 93 RVA: 0x00002F2A File Offset: 0x0000112A
		// (set) Token: 0x0600005E RID: 94 RVA: 0x00002F32 File Offset: 0x00001132
		public string sName { get; set; }
	}
}
