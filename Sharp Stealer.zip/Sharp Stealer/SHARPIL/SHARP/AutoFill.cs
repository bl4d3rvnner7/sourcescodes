﻿using System;

namespace SHARP
{
	// Token: 0x0200000E RID: 14
	internal struct AutoFill
	{
		// Token: 0x0400002C RID: 44
		public string sName;

		// Token: 0x0400002D RID: 45
		public string sValue;
	}
}
