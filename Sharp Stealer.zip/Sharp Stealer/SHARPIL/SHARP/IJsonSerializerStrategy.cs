﻿using System;
using System.CodeDom.Compiler;

namespace SHARP
{
	// Token: 0x02000050 RID: 80
	[GeneratedCode("simple-json", "1.0.0")]
	public interface IJsonSerializerStrategy
	{
		// Token: 0x06000192 RID: 402
		bool TrySerializeNonPrimitiveObject(object input, out object output);

		// Token: 0x06000193 RID: 403
		object DeserializeObject(object value, Type type);
	}
}
