﻿using System;

namespace SHARP
{
	// Token: 0x02000043 RID: 67
	public interface IFolders
	{
		// Token: 0x1700002C RID: 44
		// (get) Token: 0x06000140 RID: 320
		string Source { get; }

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x06000141 RID: 321
		string Target { get; }
	}
}
