﻿using System;
using System.Runtime.InteropServices;

namespace SHARP
{
	// Token: 0x02000059 RID: 89
	internal class WinAPI
	{
		// Token: 0x060001F7 RID: 503
		[DllImport("user32.dll")]
		internal static extern IntPtr GetClipboardData(uint uFormat);

		// Token: 0x060001F8 RID: 504
		[DllImport("user32.dll")]
		public static extern bool IsClipboardFormatAvailable(uint format);

		// Token: 0x060001F9 RID: 505
		[DllImport("user32.dll", SetLastError = true)]
		internal static extern bool OpenClipboard(IntPtr hWndNewOwner);

		// Token: 0x060001FA RID: 506
		[DllImport("user32.dll", SetLastError = true)]
		internal static extern bool CloseClipboard();

		// Token: 0x060001FB RID: 507
		[DllImport("kernel32.dll")]
		internal static extern IntPtr GlobalLock(IntPtr hMem);

		// Token: 0x060001FC RID: 508
		[DllImport("kernel32.dll")]
		internal static extern bool GlobalUnlock(IntPtr hMem);
	}
}
