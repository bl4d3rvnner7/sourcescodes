﻿using System;

namespace SHARP
{
	// Token: 0x02000022 RID: 34
	internal struct PasswordFormat
	{
		// Token: 0x060000C6 RID: 198 RVA: 0x0000539F File Offset: 0x0000359F
		internal PasswordFormat(string username, string password, string url)
		{
			this.Username = username;
			this.Password = password;
			this.Url = url;
		}

		// Token: 0x04000051 RID: 81
		internal readonly string Username;

		// Token: 0x04000052 RID: 82
		internal readonly string Password;

		// Token: 0x04000053 RID: 83
		internal readonly string Url;
	}
}
