﻿using System;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;

namespace SHARP
{
	// Token: 0x02000055 RID: 85
	internal class BSSID
	{
		// Token: 0x060001DC RID: 476
		[DllImport("iphlpapi.dll", ExactSpelling = true)]
		private static extern int SendARP(int destIp, int srcIP, byte[] macAddr, ref uint physicalAddrLen);

		// Token: 0x060001DD RID: 477 RVA: 0x0000BA84 File Offset: 0x00009C84
		public static string GetBSSID()
		{
			byte[] array = new byte[6];
			uint num = (uint)array.Length;
			try
			{
				if (BSSID.SendARP(BitConverter.ToInt32(IPAddress.Parse(BSSID.GetDefaultGateway()).GetAddressBytes(), 0), 0, array, ref num) != 0)
				{
					return "unknown";
				}
				string[] array2 = new string[num];
				int num2 = 0;
				while ((long)num2 < (long)((ulong)num))
				{
					array2[num2] = array[num2].ToString("x2");
					num2++;
				}
				return string.Join(":", array2);
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return "Failed";
		}

		// Token: 0x060001DE RID: 478 RVA: 0x0000BB20 File Offset: 0x00009D20
		public static string GetDefaultGateway()
		{
			try
			{
				return (from a in (from n in NetworkInterface.GetAllNetworkInterfaces()
				where n.OperationalStatus == OperationalStatus.Up
				where n.NetworkInterfaceType != NetworkInterfaceType.Loopback
				select n).SelectMany(delegate(NetworkInterface n)
				{
					IPInterfaceProperties ipproperties = n.GetIPProperties();
					if (ipproperties == null)
					{
						return null;
					}
					return ipproperties.GatewayAddresses;
				}).Select(delegate(GatewayIPAddressInformation g)
				{
					if (g == null)
					{
						return null;
					}
					return g.Address;
				})
				where a != null
				select a).FirstOrDefault<IPAddress>().ToString();
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return "Unknown";
		}
	}
}
