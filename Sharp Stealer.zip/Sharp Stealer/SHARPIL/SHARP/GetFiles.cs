﻿using System;

namespace SHARP
{
	// Token: 0x02000042 RID: 66
	public class GetFiles
	{
		// Token: 0x02000103 RID: 259
		public class Folders : IFolders
		{
			// Token: 0x17000044 RID: 68
			// (get) Token: 0x060003B7 RID: 951 RVA: 0x00022F32 File Offset: 0x00021132
			// (set) Token: 0x060003B8 RID: 952 RVA: 0x00022F3A File Offset: 0x0002113A
			public string Source { get; private set; }

			// Token: 0x17000045 RID: 69
			// (get) Token: 0x060003B9 RID: 953 RVA: 0x00022F43 File Offset: 0x00021143
			// (set) Token: 0x060003BA RID: 954 RVA: 0x00022F4B File Offset: 0x0002114B
			public string Target { get; private set; }

			// Token: 0x060003BB RID: 955 RVA: 0x00022F54 File Offset: 0x00021154
			public Folders(string source, string target)
			{
				this.Source = source;
				this.Target = target;
			}
		}
	}
}
