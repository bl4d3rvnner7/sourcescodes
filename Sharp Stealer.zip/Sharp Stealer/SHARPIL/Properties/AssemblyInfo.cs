﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.5.6.7")]
[assembly: AssemblyTitle("WindowsSharp")]
[assembly: AssemblyDescription("i")]
[assembly: AssemblyConfiguration("i")]
[assembly: AssemblyCompany("i")]
[assembly: AssemblyProduct("1")]
[assembly: AssemblyCopyright("Copyright © 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("e6dde6bb-ca9e-4635-8f7f-3b85e1012735")]
[assembly: AssemblyFileVersion("1.09.9879.0")]
