﻿using System;
using System.IO;
using System.Linq;

namespace youknowcaliber
{
	internal sealed class Filemanager
	{
		public static void RecursiveDelete(string path)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(path);
			bool flag = !directoryInfo.Exists;
			if (!flag)
			{
				foreach (DirectoryInfo directoryInfo2 in directoryInfo.GetDirectories())
				{
					Filemanager.RecursiveDelete(directoryInfo2.FullName);
				}
				directoryInfo.Delete(true);
			}
		}

		public static void CopyDirectory(string sourceFolder, string destFolder)
		{
			try
			{
				bool flag = !Directory.Exists(destFolder);
				if (flag)
				{
					Directory.CreateDirectory(destFolder);
				}
				string[] files = Directory.GetFiles(sourceFolder);
				foreach (string text in files)
				{
					string fileName = Path.GetFileName(text);
					string destFileName = Path.Combine(destFolder, fileName);
					File.Copy(text, destFileName);
				}
				string[] directories = Directory.GetDirectories(sourceFolder);
				foreach (string text2 in directories)
				{
					string fileName2 = Path.GetFileName(text2);
					string destFolder2 = Path.Combine(destFolder, fileName2);
					Filemanager.CopyDirectory(text2, destFolder2);
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}

		public static long DirectorySize(string path)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(path);
			return directoryInfo.GetFiles().Sum((FileInfo fi) => fi.Length) + directoryInfo.GetDirectories().Sum((DirectoryInfo di) => Filemanager.DirectorySize(di.FullName));
		}
	}
}
