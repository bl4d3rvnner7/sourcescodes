﻿using System;

namespace youknowcaliber
{
	internal sealed class Flags
	{
		public static string GetFlag(string c)
		{
			bool flag = c == "AD";
			string result;
			if (flag)
			{
				result = "\ud83c\udde6\ud83c\udde9";
			}
			else
			{
				bool flag2 = c == "AE";
				if (flag2)
				{
					result = "\ud83c\udde6\ud83c\uddea";
				}
				else
				{
					bool flag3 = c == "AF";
					if (flag3)
					{
						result = "\ud83c\udde6\ud83c\uddeb";
					}
					else
					{
						bool flag4 = c == "AG";
						if (flag4)
						{
							result = "\ud83c\udde6\ud83c\uddec";
						}
						else
						{
							bool flag5 = c == "AI";
							if (flag5)
							{
								result = "\ud83c\udde6\ud83c\uddee";
							}
							else
							{
								bool flag6 = c == "AL";
								if (flag6)
								{
									result = "\ud83c\udde6\ud83c\uddf1";
								}
								else
								{
									bool flag7 = c == "AM";
									if (flag7)
									{
										result = "\ud83c\udde6\ud83c\uddf2";
									}
									else
									{
										bool flag8 = c == "AO";
										if (flag8)
										{
											result = "\ud83c\udde6\ud83c\uddf4";
										}
										else
										{
											bool flag9 = c == "AQ";
											if (flag9)
											{
												result = "\ud83c\udde6\ud83c\uddf6";
											}
											else
											{
												bool flag10 = c == "AR";
												if (flag10)
												{
													result = "\ud83c\udde6\ud83c\uddf7";
												}
												else
												{
													bool flag11 = c == "AS";
													if (flag11)
													{
														result = "\ud83c\udde6\ud83c\uddf8";
													}
													else
													{
														bool flag12 = c == "AT";
														if (flag12)
														{
															result = "\ud83c\udde6\ud83c\uddf9";
														}
														else
														{
															bool flag13 = c == "AU";
															if (flag13)
															{
																result = "\ud83c\udde6\ud83c\uddfa";
															}
															else
															{
																bool flag14 = c == "AW";
																if (flag14)
																{
																	result = "\ud83c\udde6\ud83c\uddfc";
																}
																else
																{
																	bool flag15 = c == "AX";
																	if (flag15)
																	{
																		result = "\ud83c\udde6\ud83c\uddfd";
																	}
																	else
																	{
																		bool flag16 = c == "AZ";
																		if (flag16)
																		{
																			result = "\ud83c\udde6\ud83c\uddff";
																		}
																		else
																		{
																			bool flag17 = c == "BA";
																			if (flag17)
																			{
																				result = "\ud83c\udde7\ud83c\udde6";
																			}
																			else
																			{
																				bool flag18 = c == "BB";
																				if (flag18)
																				{
																					result = "\ud83c\udde7\ud83c\udde7";
																				}
																				else
																				{
																					bool flag19 = c == "BD";
																					if (flag19)
																					{
																						result = "\ud83c\udde7\ud83c\udde9";
																					}
																					else
																					{
																						bool flag20 = c == "BE";
																						if (flag20)
																						{
																							result = "\ud83c\udde7\ud83c\uddea";
																						}
																						else
																						{
																							bool flag21 = c == "BF";
																							if (flag21)
																							{
																								result = "\ud83c\udde7\ud83c\uddeb";
																							}
																							else
																							{
																								bool flag22 = c == "BG";
																								if (flag22)
																								{
																									result = "\ud83c\udde7\ud83c\uddec";
																								}
																								else
																								{
																									bool flag23 = c == "BH";
																									if (flag23)
																									{
																										result = "\ud83c\udde7\ud83c\udded";
																									}
																									else
																									{
																										bool flag24 = c == "BI";
																										if (flag24)
																										{
																											result = "\ud83c\udde7\ud83c\uddee";
																										}
																										else
																										{
																											bool flag25 = c == "BJ";
																											if (flag25)
																											{
																												result = "\ud83c\udde7\ud83c\uddef";
																											}
																											else
																											{
																												bool flag26 = c == "BL";
																												if (flag26)
																												{
																													result = "\ud83c\udde7\ud83c\uddf1";
																												}
																												else
																												{
																													bool flag27 = c == "BM";
																													if (flag27)
																													{
																														result = "\ud83c\udde7\ud83c\uddf2";
																													}
																													else
																													{
																														bool flag28 = c == "BN";
																														if (flag28)
																														{
																															result = "\ud83c\udde7\ud83c\uddf3";
																														}
																														else
																														{
																															bool flag29 = c == "BO";
																															if (flag29)
																															{
																																result = "\ud83c\udde7\ud83c\uddf4";
																															}
																															else
																															{
																																bool flag30 = c == "BQ";
																																if (flag30)
																																{
																																	result = "\ud83c\udde7\ud83c\uddf6";
																																}
																																else
																																{
																																	bool flag31 = c == "BR";
																																	if (flag31)
																																	{
																																		result = "\ud83c\udde7\ud83c\uddf7";
																																	}
																																	else
																																	{
																																		bool flag32 = c == "BS";
																																		if (flag32)
																																		{
																																			result = "\ud83c\udde7\ud83c\uddf8";
																																		}
																																		else
																																		{
																																			bool flag33 = c == "BT";
																																			if (flag33)
																																			{
																																				result = "\ud83c\udde7\ud83c\uddf9";
																																			}
																																			else
																																			{
																																				bool flag34 = c == "BV";
																																				if (flag34)
																																				{
																																					result = "\ud83c\udde7\ud83c\uddfb";
																																				}
																																				else
																																				{
																																					bool flag35 = c == "BW";
																																					if (flag35)
																																					{
																																						result = "\ud83c\udde7\ud83c\uddfc";
																																					}
																																					else
																																					{
																																						bool flag36 = c == "BY";
																																						if (flag36)
																																						{
																																							result = "\ud83c\udde7\ud83c\uddfe";
																																						}
																																						else
																																						{
																																							bool flag37 = c == "BZ";
																																							if (flag37)
																																							{
																																								result = "\ud83c\udde7\ud83c\uddff";
																																							}
																																							else
																																							{
																																								bool flag38 = c == "CA";
																																								if (flag38)
																																								{
																																									result = "\ud83c\udde8\ud83c\udde6";
																																								}
																																								else
																																								{
																																									bool flag39 = c == "CC";
																																									if (flag39)
																																									{
																																										result = "\ud83c\udde8\ud83c\udde8";
																																									}
																																									else
																																									{
																																										bool flag40 = c == "CD";
																																										if (flag40)
																																										{
																																											result = "\ud83c\udde8\ud83c\udde9";
																																										}
																																										else
																																										{
																																											bool flag41 = c == "CF";
																																											if (flag41)
																																											{
																																												result = "\ud83c\udde8\ud83c\uddeb";
																																											}
																																											else
																																											{
																																												bool flag42 = c == "CG";
																																												if (flag42)
																																												{
																																													result = "\ud83c\udde8\ud83c\uddec";
																																												}
																																												else
																																												{
																																													bool flag43 = c == "CH";
																																													if (flag43)
																																													{
																																														result = "\ud83c\udde8\ud83c\udded";
																																													}
																																													else
																																													{
																																														bool flag44 = c == "CI";
																																														if (flag44)
																																														{
																																															result = "\ud83c\udde8\ud83c\uddee";
																																														}
																																														else
																																														{
																																															bool flag45 = c == "CK";
																																															if (flag45)
																																															{
																																																result = "\ud83c\udde8\ud83c\uddf0";
																																															}
																																															else
																																															{
																																																bool flag46 = c == "CL";
																																																if (flag46)
																																																{
																																																	result = "\ud83c\udde8\ud83c\uddf1";
																																																}
																																																else
																																																{
																																																	bool flag47 = c == "CM";
																																																	if (flag47)
																																																	{
																																																		result = "\ud83c\udde8\ud83c\uddf2";
																																																	}
																																																	else
																																																	{
																																																		bool flag48 = c == "CN";
																																																		if (flag48)
																																																		{
																																																			result = "\ud83c\udde8\ud83c\uddf3";
																																																		}
																																																		else
																																																		{
																																																			bool flag49 = c == "CO";
																																																			if (flag49)
																																																			{
																																																				result = "\ud83c\udde8\ud83c\uddf4";
																																																			}
																																																			else
																																																			{
																																																				bool flag50 = c == "CR";
																																																				if (flag50)
																																																				{
																																																					result = "\ud83c\udde8\ud83c\uddf7";
																																																				}
																																																				else
																																																				{
																																																					bool flag51 = c == "CU";
																																																					if (flag51)
																																																					{
																																																						result = "\ud83c\udde8\ud83c\uddfa";
																																																					}
																																																					else
																																																					{
																																																						bool flag52 = c == "CV";
																																																						if (flag52)
																																																						{
																																																							result = "\ud83c\udde8\ud83c\uddfb";
																																																						}
																																																						else
																																																						{
																																																							bool flag53 = c == "CW";
																																																							if (flag53)
																																																							{
																																																								result = "\ud83c\udde8\ud83c\uddfc";
																																																							}
																																																							else
																																																							{
																																																								bool flag54 = c == "CX";
																																																								if (flag54)
																																																								{
																																																									result = "\ud83c\udde8\ud83c\uddfd";
																																																								}
																																																								else
																																																								{
																																																									bool flag55 = c == "CY";
																																																									if (flag55)
																																																									{
																																																										result = "\ud83c\udde8\ud83c\uddfe";
																																																									}
																																																									else
																																																									{
																																																										bool flag56 = c == "CZ";
																																																										if (flag56)
																																																										{
																																																											result = "\ud83c\udde8\ud83c\uddff";
																																																										}
																																																										else
																																																										{
																																																											bool flag57 = c == "DE";
																																																											if (flag57)
																																																											{
																																																												result = "\ud83c\udde9\ud83c\uddea";
																																																											}
																																																											else
																																																											{
																																																												bool flag58 = c == "DJ";
																																																												if (flag58)
																																																												{
																																																													result = "\ud83c\udde9\ud83c\uddef";
																																																												}
																																																												else
																																																												{
																																																													bool flag59 = c == "DK";
																																																													if (flag59)
																																																													{
																																																														result = "\ud83c\udde9\ud83c\uddf0";
																																																													}
																																																													else
																																																													{
																																																														bool flag60 = c == "DM";
																																																														if (flag60)
																																																														{
																																																															result = "\ud83c\udde9\ud83c\uddf2";
																																																														}
																																																														else
																																																														{
																																																															bool flag61 = c == "DO";
																																																															if (flag61)
																																																															{
																																																																result = "\ud83c\udde9\ud83c\uddf4";
																																																															}
																																																															else
																																																															{
																																																																bool flag62 = c == "DZ";
																																																																if (flag62)
																																																																{
																																																																	result = "\ud83c\udde9\ud83c\uddff";
																																																																}
																																																																else
																																																																{
																																																																	bool flag63 = c == "EC";
																																																																	if (flag63)
																																																																	{
																																																																		result = "\ud83c\uddea\ud83c\udde8";
																																																																	}
																																																																	else
																																																																	{
																																																																		bool flag64 = c == "EE";
																																																																		if (flag64)
																																																																		{
																																																																			result = "\ud83c\uddea\ud83c\uddea";
																																																																		}
																																																																		else
																																																																		{
																																																																			bool flag65 = c == "EG";
																																																																			if (flag65)
																																																																			{
																																																																				result = "\ud83c\uddea\ud83c\uddec";
																																																																			}
																																																																			else
																																																																			{
																																																																				bool flag66 = c == "EH";
																																																																				if (flag66)
																																																																				{
																																																																					result = "\ud83c\uddea\ud83c\udded";
																																																																				}
																																																																				else
																																																																				{
																																																																					bool flag67 = c == "ER";
																																																																					if (flag67)
																																																																					{
																																																																						result = "\ud83c\uddea\ud83c\uddf7";
																																																																					}
																																																																					else
																																																																					{
																																																																						bool flag68 = c == "ES";
																																																																						if (flag68)
																																																																						{
																																																																							result = "\ud83c\uddea\ud83c\uddf8";
																																																																						}
																																																																						else
																																																																						{
																																																																							bool flag69 = c == "ET";
																																																																							if (flag69)
																																																																							{
																																																																								result = "\ud83c\uddea\ud83c\uddf9";
																																																																							}
																																																																							else
																																																																							{
																																																																								bool flag70 = c == "FI";
																																																																								if (flag70)
																																																																								{
																																																																									result = "\ud83c\uddeb\ud83c\uddee";
																																																																								}
																																																																								else
																																																																								{
																																																																									bool flag71 = c == "FJ";
																																																																									if (flag71)
																																																																									{
																																																																										result = "\ud83c\uddeb\ud83c\uddef";
																																																																									}
																																																																									else
																																																																									{
																																																																										bool flag72 = c == "FK";
																																																																										if (flag72)
																																																																										{
																																																																											result = "\ud83c\uddeb\ud83c\uddf0";
																																																																										}
																																																																										else
																																																																										{
																																																																											bool flag73 = c == "FM";
																																																																											if (flag73)
																																																																											{
																																																																												result = "\ud83c\uddeb\ud83c\uddf2";
																																																																											}
																																																																											else
																																																																											{
																																																																												bool flag74 = c == "FO";
																																																																												if (flag74)
																																																																												{
																																																																													result = "\ud83c\uddeb\ud83c\uddf4";
																																																																												}
																																																																												else
																																																																												{
																																																																													bool flag75 = c == "FR";
																																																																													if (flag75)
																																																																													{
																																																																														result = "\ud83c\uddeb\ud83c\uddf7";
																																																																													}
																																																																													else
																																																																													{
																																																																														bool flag76 = c == "GA";
																																																																														if (flag76)
																																																																														{
																																																																															result = "\ud83c\uddec\ud83c\udde6";
																																																																														}
																																																																														else
																																																																														{
																																																																															bool flag77 = c == "GB";
																																																																															if (flag77)
																																																																															{
																																																																																result = "\ud83c\uddec\ud83c\udde7";
																																																																															}
																																																																															else
																																																																															{
																																																																																bool flag78 = c == "GD";
																																																																																if (flag78)
																																																																																{
																																																																																	result = "\ud83c\uddec\ud83c\udde9";
																																																																																}
																																																																																else
																																																																																{
																																																																																	bool flag79 = c == "GE";
																																																																																	if (flag79)
																																																																																	{
																																																																																		result = "\ud83c\uddec\ud83c\uddea";
																																																																																	}
																																																																																	else
																																																																																	{
																																																																																		bool flag80 = c == "GF";
																																																																																		if (flag80)
																																																																																		{
																																																																																			result = "\ud83c\uddec\ud83c\uddeb";
																																																																																		}
																																																																																		else
																																																																																		{
																																																																																			bool flag81 = c == "GG";
																																																																																			if (flag81)
																																																																																			{
																																																																																				result = "\ud83c\uddec\ud83c\uddec";
																																																																																			}
																																																																																			else
																																																																																			{
																																																																																				bool flag82 = c == "GH";
																																																																																				if (flag82)
																																																																																				{
																																																																																					result = "\ud83c\uddec\ud83c\udded";
																																																																																				}
																																																																																				else
																																																																																				{
																																																																																					bool flag83 = c == "GI";
																																																																																					if (flag83)
																																																																																					{
																																																																																						result = "\ud83c\uddec\ud83c\uddee";
																																																																																					}
																																																																																					else
																																																																																					{
																																																																																						bool flag84 = c == "GL";
																																																																																						if (flag84)
																																																																																						{
																																																																																							result = "\ud83c\uddec\ud83c\uddf1";
																																																																																						}
																																																																																						else
																																																																																						{
																																																																																							bool flag85 = c == "GM";
																																																																																							if (flag85)
																																																																																							{
																																																																																								result = "\ud83c\uddec\ud83c\uddf2";
																																																																																							}
																																																																																							else
																																																																																							{
																																																																																								bool flag86 = c == "GN";
																																																																																								if (flag86)
																																																																																								{
																																																																																									result = "\ud83c\uddec\ud83c\uddf3";
																																																																																								}
																																																																																								else
																																																																																								{
																																																																																									bool flag87 = c == "GP";
																																																																																									if (flag87)
																																																																																									{
																																																																																										result = "\ud83c\uddec\ud83c\uddf5";
																																																																																									}
																																																																																									else
																																																																																									{
																																																																																										bool flag88 = c == "GQ";
																																																																																										if (flag88)
																																																																																										{
																																																																																											result = "\ud83c\uddec\ud83c\uddf6";
																																																																																										}
																																																																																										else
																																																																																										{
																																																																																											bool flag89 = c == "GR";
																																																																																											if (flag89)
																																																																																											{
																																																																																												result = "\ud83c\uddec\ud83c\uddf7";
																																																																																											}
																																																																																											else
																																																																																											{
																																																																																												bool flag90 = c == "GS";
																																																																																												if (flag90)
																																																																																												{
																																																																																													result = "\ud83c\uddec\ud83c\uddf8";
																																																																																												}
																																																																																												else
																																																																																												{
																																																																																													bool flag91 = c == "GT";
																																																																																													if (flag91)
																																																																																													{
																																																																																														result = "\ud83c\uddec\ud83c\uddf9";
																																																																																													}
																																																																																													else
																																																																																													{
																																																																																														bool flag92 = c == "GU";
																																																																																														if (flag92)
																																																																																														{
																																																																																															result = "\ud83c\uddec\ud83c\uddfa";
																																																																																														}
																																																																																														else
																																																																																														{
																																																																																															bool flag93 = c == "GW";
																																																																																															if (flag93)
																																																																																															{
																																																																																																result = "\ud83c\uddec\ud83c\uddfc";
																																																																																															}
																																																																																															else
																																																																																															{
																																																																																																bool flag94 = c == "GY";
																																																																																																if (flag94)
																																																																																																{
																																																																																																	result = "\ud83c\uddec\ud83c\uddfe";
																																																																																																}
																																																																																																else
																																																																																																{
																																																																																																	bool flag95 = c == "HK";
																																																																																																	if (flag95)
																																																																																																	{
																																																																																																		result = "\ud83c\udded\ud83c\uddf0";
																																																																																																	}
																																																																																																	else
																																																																																																	{
																																																																																																		bool flag96 = c == "HM";
																																																																																																		if (flag96)
																																																																																																		{
																																																																																																			result = "\ud83c\udded\ud83c\uddf2";
																																																																																																		}
																																																																																																		else
																																																																																																		{
																																																																																																			bool flag97 = c == "HN";
																																																																																																			if (flag97)
																																																																																																			{
																																																																																																				result = "\ud83c\udded\ud83c\uddf3";
																																																																																																			}
																																																																																																			else
																																																																																																			{
																																																																																																				bool flag98 = c == "HR";
																																																																																																				if (flag98)
																																																																																																				{
																																																																																																					result = "\ud83c\udded\ud83c\uddf7";
																																																																																																				}
																																																																																																				else
																																																																																																				{
																																																																																																					bool flag99 = c == "HT";
																																																																																																					if (flag99)
																																																																																																					{
																																																																																																						result = "\ud83c\udded\ud83c\uddf9";
																																																																																																					}
																																																																																																					else
																																																																																																					{
																																																																																																						bool flag100 = c == "HU";
																																																																																																						if (flag100)
																																																																																																						{
																																																																																																							result = "\ud83c\udded\ud83c\uddfa";
																																																																																																						}
																																																																																																						else
																																																																																																						{
																																																																																																							bool flag101 = c == "ID";
																																																																																																							if (flag101)
																																																																																																							{
																																																																																																								result = "\ud83c\uddee\ud83c\udde9";
																																																																																																							}
																																																																																																							else
																																																																																																							{
																																																																																																								bool flag102 = c == "IE";
																																																																																																								if (flag102)
																																																																																																								{
																																																																																																									result = "\ud83c\uddee\ud83c\uddea";
																																																																																																								}
																																																																																																								else
																																																																																																								{
																																																																																																									bool flag103 = c == "IL";
																																																																																																									if (flag103)
																																																																																																									{
																																																																																																										result = "\ud83c\uddee\ud83c\uddf1";
																																																																																																									}
																																																																																																									else
																																																																																																									{
																																																																																																										bool flag104 = c == "IM";
																																																																																																										if (flag104)
																																																																																																										{
																																																																																																											result = "\ud83c\uddee\ud83c\uddf2";
																																																																																																										}
																																																																																																										else
																																																																																																										{
																																																																																																											bool flag105 = c == "IN";
																																																																																																											if (flag105)
																																																																																																											{
																																																																																																												result = "\ud83c\uddee\ud83c\uddf3";
																																																																																																											}
																																																																																																											else
																																																																																																											{
																																																																																																												bool flag106 = c == "IO";
																																																																																																												if (flag106)
																																																																																																												{
																																																																																																													result = "\ud83c\uddee\ud83c\uddf4";
																																																																																																												}
																																																																																																												else
																																																																																																												{
																																																																																																													bool flag107 = c == "IQ";
																																																																																																													if (flag107)
																																																																																																													{
																																																																																																														result = "\ud83c\uddee\ud83c\uddf6";
																																																																																																													}
																																																																																																													else
																																																																																																													{
																																																																																																														bool flag108 = c == "IR";
																																																																																																														if (flag108)
																																																																																																														{
																																																																																																															result = "\ud83c\uddee\ud83c\uddf7";
																																																																																																														}
																																																																																																														else
																																																																																																														{
																																																																																																															bool flag109 = c == "IS";
																																																																																																															if (flag109)
																																																																																																															{
																																																																																																																result = "\ud83c\uddee\ud83c\uddf8";
																																																																																																															}
																																																																																																															else
																																																																																																															{
																																																																																																																bool flag110 = c == "IT";
																																																																																																																if (flag110)
																																																																																																																{
																																																																																																																	result = "\ud83c\uddee\ud83c\uddf9";
																																																																																																																}
																																																																																																																else
																																																																																																																{
																																																																																																																	bool flag111 = c == "JE";
																																																																																																																	if (flag111)
																																																																																																																	{
																																																																																																																		result = "\ud83c\uddef\ud83c\uddea";
																																																																																																																	}
																																																																																																																	else
																																																																																																																	{
																																																																																																																		bool flag112 = c == "JM";
																																																																																																																		if (flag112)
																																																																																																																		{
																																																																																																																			result = "\ud83c\uddef\ud83c\uddf2";
																																																																																																																		}
																																																																																																																		else
																																																																																																																		{
																																																																																																																			bool flag113 = c == "JO";
																																																																																																																			if (flag113)
																																																																																																																			{
																																																																																																																				result = "\ud83c\uddef\ud83c\uddf4";
																																																																																																																			}
																																																																																																																			else
																																																																																																																			{
																																																																																																																				bool flag114 = c == "JP";
																																																																																																																				if (flag114)
																																																																																																																				{
																																																																																																																					result = "\ud83c\uddef\ud83c\uddf5";
																																																																																																																				}
																																																																																																																				else
																																																																																																																				{
																																																																																																																					bool flag115 = c == "KE";
																																																																																																																					if (flag115)
																																																																																																																					{
																																																																																																																						result = "\ud83c\uddf0\ud83c\uddea";
																																																																																																																					}
																																																																																																																					else
																																																																																																																					{
																																																																																																																						bool flag116 = c == "KG";
																																																																																																																						if (flag116)
																																																																																																																						{
																																																																																																																							result = "\ud83c\uddf0\ud83c\uddec";
																																																																																																																						}
																																																																																																																						else
																																																																																																																						{
																																																																																																																							bool flag117 = c == "KH";
																																																																																																																							if (flag117)
																																																																																																																							{
																																																																																																																								result = "\ud83c\uddf0\ud83c\udded";
																																																																																																																							}
																																																																																																																							else
																																																																																																																							{
																																																																																																																								bool flag118 = c == "KI";
																																																																																																																								if (flag118)
																																																																																																																								{
																																																																																																																									result = "\ud83c\uddf0\ud83c\uddee";
																																																																																																																								}
																																																																																																																								else
																																																																																																																								{
																																																																																																																									bool flag119 = c == "KM";
																																																																																																																									if (flag119)
																																																																																																																									{
																																																																																																																										result = "\ud83c\uddf0\ud83c\uddf2";
																																																																																																																									}
																																																																																																																									else
																																																																																																																									{
																																																																																																																										bool flag120 = c == "KN";
																																																																																																																										if (flag120)
																																																																																																																										{
																																																																																																																											result = "\ud83c\uddf0\ud83c\uddf3";
																																																																																																																										}
																																																																																																																										else
																																																																																																																										{
																																																																																																																											bool flag121 = c == "KP";
																																																																																																																											if (flag121)
																																																																																																																											{
																																																																																																																												result = "\ud83c\uddf0\ud83c\uddf5";
																																																																																																																											}
																																																																																																																											else
																																																																																																																											{
																																																																																																																												bool flag122 = c == "KR";
																																																																																																																												if (flag122)
																																																																																																																												{
																																																																																																																													result = "\ud83c\uddf0\ud83c\uddf7";
																																																																																																																												}
																																																																																																																												else
																																																																																																																												{
																																																																																																																													bool flag123 = c == "KW";
																																																																																																																													if (flag123)
																																																																																																																													{
																																																																																																																														result = "\ud83c\uddf0\ud83c\uddfc";
																																																																																																																													}
																																																																																																																													else
																																																																																																																													{
																																																																																																																														bool flag124 = c == "KY";
																																																																																																																														if (flag124)
																																																																																																																														{
																																																																																																																															result = "\ud83c\uddf0\ud83c\uddfe";
																																																																																																																														}
																																																																																																																														else
																																																																																																																														{
																																																																																																																															bool flag125 = c == "KZ";
																																																																																																																															if (flag125)
																																																																																																																															{
																																																																																																																																result = "\ud83c\uddf0\ud83c\uddff";
																																																																																																																															}
																																																																																																																															else
																																																																																																																															{
																																																																																																																																bool flag126 = c == "LA";
																																																																																																																																if (flag126)
																																																																																																																																{
																																																																																																																																	result = "\ud83c\uddf1\ud83c\udde6";
																																																																																																																																}
																																																																																																																																else
																																																																																																																																{
																																																																																																																																	bool flag127 = c == "LB";
																																																																																																																																	if (flag127)
																																																																																																																																	{
																																																																																																																																		result = "\ud83c\uddf1\ud83c\udde7";
																																																																																																																																	}
																																																																																																																																	else
																																																																																																																																	{
																																																																																																																																		bool flag128 = c == "LC";
																																																																																																																																		if (flag128)
																																																																																																																																		{
																																																																																																																																			result = "\ud83c\uddf1\ud83c\udde8";
																																																																																																																																		}
																																																																																																																																		else
																																																																																																																																		{
																																																																																																																																			bool flag129 = c == "LI";
																																																																																																																																			if (flag129)
																																																																																																																																			{
																																																																																																																																				result = "\ud83c\uddf1\ud83c\uddee";
																																																																																																																																			}
																																																																																																																																			else
																																																																																																																																			{
																																																																																																																																				bool flag130 = c == "LK";
																																																																																																																																				if (flag130)
																																																																																																																																				{
																																																																																																																																					result = "\ud83c\uddf1\ud83c\uddf0";
																																																																																																																																				}
																																																																																																																																				else
																																																																																																																																				{
																																																																																																																																					bool flag131 = c == "LR";
																																																																																																																																					if (flag131)
																																																																																																																																					{
																																																																																																																																						result = "\ud83c\uddf1\ud83c\uddf7";
																																																																																																																																					}
																																																																																																																																					else
																																																																																																																																					{
																																																																																																																																						bool flag132 = c == "LS";
																																																																																																																																						if (flag132)
																																																																																																																																						{
																																																																																																																																							result = "\ud83c\uddf1\ud83c\uddf8";
																																																																																																																																						}
																																																																																																																																						else
																																																																																																																																						{
																																																																																																																																							bool flag133 = c == "LT";
																																																																																																																																							if (flag133)
																																																																																																																																							{
																																																																																																																																								result = "\ud83c\uddf1\ud83c\uddf9";
																																																																																																																																							}
																																																																																																																																							else
																																																																																																																																							{
																																																																																																																																								bool flag134 = c == "LU";
																																																																																																																																								if (flag134)
																																																																																																																																								{
																																																																																																																																									result = "\ud83c\uddf1\ud83c\uddfa";
																																																																																																																																								}
																																																																																																																																								else
																																																																																																																																								{
																																																																																																																																									bool flag135 = c == "LV";
																																																																																																																																									if (flag135)
																																																																																																																																									{
																																																																																																																																										result = "\ud83c\uddf1\ud83c\uddfb";
																																																																																																																																									}
																																																																																																																																									else
																																																																																																																																									{
																																																																																																																																										bool flag136 = c == "LY";
																																																																																																																																										if (flag136)
																																																																																																																																										{
																																																																																																																																											result = "\ud83c\uddf1\ud83c\uddfe";
																																																																																																																																										}
																																																																																																																																										else
																																																																																																																																										{
																																																																																																																																											bool flag137 = c == "MA";
																																																																																																																																											if (flag137)
																																																																																																																																											{
																																																																																																																																												result = "\ud83c\uddf2\ud83c\udde6";
																																																																																																																																											}
																																																																																																																																											else
																																																																																																																																											{
																																																																																																																																												bool flag138 = c == "MC";
																																																																																																																																												if (flag138)
																																																																																																																																												{
																																																																																																																																													result = "\ud83c\uddf2\ud83c\udde8";
																																																																																																																																												}
																																																																																																																																												else
																																																																																																																																												{
																																																																																																																																													bool flag139 = c == "MD";
																																																																																																																																													if (flag139)
																																																																																																																																													{
																																																																																																																																														result = "\ud83c\uddf2\ud83c\udde9";
																																																																																																																																													}
																																																																																																																																													else
																																																																																																																																													{
																																																																																																																																														bool flag140 = c == "ME";
																																																																																																																																														if (flag140)
																																																																																																																																														{
																																																																																																																																															result = "\ud83c\uddf2\ud83c\uddea";
																																																																																																																																														}
																																																																																																																																														else
																																																																																																																																														{
																																																																																																																																															bool flag141 = c == "MF";
																																																																																																																																															if (flag141)
																																																																																																																																															{
																																																																																																																																																result = "\ud83c\uddf2\ud83c\uddeb";
																																																																																																																																															}
																																																																																																																																															else
																																																																																																																																															{
																																																																																																																																																bool flag142 = c == "MG";
																																																																																																																																																if (flag142)
																																																																																																																																																{
																																																																																																																																																	result = "\ud83c\uddf2\ud83c\uddec";
																																																																																																																																																}
																																																																																																																																																else
																																																																																																																																																{
																																																																																																																																																	bool flag143 = c == "MH";
																																																																																																																																																	if (flag143)
																																																																																																																																																	{
																																																																																																																																																		result = "\ud83c\uddf2\ud83c\udded";
																																																																																																																																																	}
																																																																																																																																																	else
																																																																																																																																																	{
																																																																																																																																																		bool flag144 = c == "MK";
																																																																																																																																																		if (flag144)
																																																																																																																																																		{
																																																																																																																																																			result = "\ud83c\uddf2\ud83c\uddf0";
																																																																																																																																																		}
																																																																																																																																																		else
																																																																																																																																																		{
																																																																																																																																																			bool flag145 = c == "ML";
																																																																																																																																																			if (flag145)
																																																																																																																																																			{
																																																																																																																																																				result = "\ud83c\uddf2\ud83c\uddf1";
																																																																																																																																																			}
																																																																																																																																																			else
																																																																																																																																																			{
																																																																																																																																																				bool flag146 = c == "MM";
																																																																																																																																																				if (flag146)
																																																																																																																																																				{
																																																																																																																																																					result = "\ud83c\uddf2\ud83c\uddf2";
																																																																																																																																																				}
																																																																																																																																																				else
																																																																																																																																																				{
																																																																																																																																																					bool flag147 = c == "MN";
																																																																																																																																																					if (flag147)
																																																																																																																																																					{
																																																																																																																																																						result = "\ud83c\uddf2\ud83c\uddf3";
																																																																																																																																																					}
																																																																																																																																																					else
																																																																																																																																																					{
																																																																																																																																																						bool flag148 = c == "MO";
																																																																																																																																																						if (flag148)
																																																																																																																																																						{
																																																																																																																																																							result = "\ud83c\uddf2\ud83c\uddf4";
																																																																																																																																																						}
																																																																																																																																																						else
																																																																																																																																																						{
																																																																																																																																																							bool flag149 = c == "MP";
																																																																																																																																																							if (flag149)
																																																																																																																																																							{
																																																																																																																																																								result = "\ud83c\uddf2\ud83c\uddf5";
																																																																																																																																																							}
																																																																																																																																																							else
																																																																																																																																																							{
																																																																																																																																																								bool flag150 = c == "MQ";
																																																																																																																																																								if (flag150)
																																																																																																																																																								{
																																																																																																																																																									result = "\ud83c\uddf2\ud83c\uddf6";
																																																																																																																																																								}
																																																																																																																																																								else
																																																																																																																																																								{
																																																																																																																																																									bool flag151 = c == "MR";
																																																																																																																																																									if (flag151)
																																																																																																																																																									{
																																																																																																																																																										result = "\ud83c\uddf2\ud83c\uddf7";
																																																																																																																																																									}
																																																																																																																																																									else
																																																																																																																																																									{
																																																																																																																																																										bool flag152 = c == "MS";
																																																																																																																																																										if (flag152)
																																																																																																																																																										{
																																																																																																																																																											result = "\ud83c\uddf2\ud83c\uddf8";
																																																																																																																																																										}
																																																																																																																																																										else
																																																																																																																																																										{
																																																																																																																																																											bool flag153 = c == "MT";
																																																																																																																																																											if (flag153)
																																																																																																																																																											{
																																																																																																																																																												result = "\ud83c\uddf2\ud83c\uddf9";
																																																																																																																																																											}
																																																																																																																																																											else
																																																																																																																																																											{
																																																																																																																																																												bool flag154 = c == "MU";
																																																																																																																																																												if (flag154)
																																																																																																																																																												{
																																																																																																																																																													result = "\ud83c\uddf2\ud83c\uddfa";
																																																																																																																																																												}
																																																																																																																																																												else
																																																																																																																																																												{
																																																																																																																																																													bool flag155 = c == "MV";
																																																																																																																																																													if (flag155)
																																																																																																																																																													{
																																																																																																																																																														result = "\ud83c\uddf2\ud83c\uddfb";
																																																																																																																																																													}
																																																																																																																																																													else
																																																																																																																																																													{
																																																																																																																																																														bool flag156 = c == "MW";
																																																																																																																																																														if (flag156)
																																																																																																																																																														{
																																																																																																																																																															result = "\ud83c\uddf2\ud83c\uddfc";
																																																																																																																																																														}
																																																																																																																																																														else
																																																																																																																																																														{
																																																																																																																																																															bool flag157 = c == "MX";
																																																																																																																																																															if (flag157)
																																																																																																																																																															{
																																																																																																																																																																result = "\ud83c\uddf2\ud83c\uddfd";
																																																																																																																																																															}
																																																																																																																																																															else
																																																																																																																																																															{
																																																																																																																																																																bool flag158 = c == "MY";
																																																																																																																																																																if (flag158)
																																																																																																																																																																{
																																																																																																																																																																	result = "\ud83c\uddf2\ud83c\uddfe";
																																																																																																																																																																}
																																																																																																																																																																else
																																																																																																																																																																{
																																																																																																																																																																	bool flag159 = c == "MZ";
																																																																																																																																																																	if (flag159)
																																																																																																																																																																	{
																																																																																																																																																																		result = "\ud83c\uddf2\ud83c\uddff";
																																																																																																																																																																	}
																																																																																																																																																																	else
																																																																																																																																																																	{
																																																																																																																																																																		bool flag160 = c == "NA";
																																																																																																																																																																		if (flag160)
																																																																																																																																																																		{
																																																																																																																																																																			result = "\ud83c\uddf3\ud83c\udde6";
																																																																																																																																																																		}
																																																																																																																																																																		else
																																																																																																																																																																		{
																																																																																																																																																																			bool flag161 = c == "NC";
																																																																																																																																																																			if (flag161)
																																																																																																																																																																			{
																																																																																																																																																																				result = "\ud83c\uddf3\ud83c\udde8";
																																																																																																																																																																			}
																																																																																																																																																																			else
																																																																																																																																																																			{
																																																																																																																																																																				bool flag162 = c == "NE";
																																																																																																																																																																				if (flag162)
																																																																																																																																																																				{
																																																																																																																																																																					result = "\ud83c\uddf3\ud83c\uddea";
																																																																																																																																																																				}
																																																																																																																																																																				else
																																																																																																																																																																				{
																																																																																																																																																																					bool flag163 = c == "NF";
																																																																																																																																																																					if (flag163)
																																																																																																																																																																					{
																																																																																																																																																																						result = "\ud83c\uddf3\ud83c\uddeb";
																																																																																																																																																																					}
																																																																																																																																																																					else
																																																																																																																																																																					{
																																																																																																																																																																						bool flag164 = c == "NG";
																																																																																																																																																																						if (flag164)
																																																																																																																																																																						{
																																																																																																																																																																							result = "\ud83c\uddf3\ud83c\uddec";
																																																																																																																																																																						}
																																																																																																																																																																						else
																																																																																																																																																																						{
																																																																																																																																																																							bool flag165 = c == "NI";
																																																																																																																																																																							if (flag165)
																																																																																																																																																																							{
																																																																																																																																																																								result = "\ud83c\uddf3\ud83c\uddee";
																																																																																																																																																																							}
																																																																																																																																																																							else
																																																																																																																																																																							{
																																																																																																																																																																								bool flag166 = c == "NL";
																																																																																																																																																																								if (flag166)
																																																																																																																																																																								{
																																																																																																																																																																									result = "\ud83c\uddf3\ud83c\uddf1";
																																																																																																																																																																								}
																																																																																																																																																																								else
																																																																																																																																																																								{
																																																																																																																																																																									bool flag167 = c == "NO";
																																																																																																																																																																									if (flag167)
																																																																																																																																																																									{
																																																																																																																																																																										result = "\ud83c\uddf3\ud83c\uddf4";
																																																																																																																																																																									}
																																																																																																																																																																									else
																																																																																																																																																																									{
																																																																																																																																																																										bool flag168 = c == "NP";
																																																																																																																																																																										if (flag168)
																																																																																																																																																																										{
																																																																																																																																																																											result = "\ud83c\uddf3\ud83c\uddf5";
																																																																																																																																																																										}
																																																																																																																																																																										else
																																																																																																																																																																										{
																																																																																																																																																																											bool flag169 = c == "NR";
																																																																																																																																																																											if (flag169)
																																																																																																																																																																											{
																																																																																																																																																																												result = "\ud83c\uddf3\ud83c\uddf7";
																																																																																																																																																																											}
																																																																																																																																																																											else
																																																																																																																																																																											{
																																																																																																																																																																												bool flag170 = c == "NU";
																																																																																																																																																																												if (flag170)
																																																																																																																																																																												{
																																																																																																																																																																													result = "\ud83c\uddf3\ud83c\uddfa";
																																																																																																																																																																												}
																																																																																																																																																																												else
																																																																																																																																																																												{
																																																																																																																																																																													bool flag171 = c == "NZ";
																																																																																																																																																																													if (flag171)
																																																																																																																																																																													{
																																																																																																																																																																														result = "\ud83c\uddf3\ud83c\uddff";
																																																																																																																																																																													}
																																																																																																																																																																													else
																																																																																																																																																																													{
																																																																																																																																																																														bool flag172 = c == "OM";
																																																																																																																																																																														if (flag172)
																																																																																																																																																																														{
																																																																																																																																																																															result = "\ud83c\uddf4\ud83c\uddf2";
																																																																																																																																																																														}
																																																																																																																																																																														else
																																																																																																																																																																														{
																																																																																																																																																																															bool flag173 = c == "PA";
																																																																																																																																																																															if (flag173)
																																																																																																																																																																															{
																																																																																																																																																																																result = "\ud83c\uddf5\ud83c\udde6";
																																																																																																																																																																															}
																																																																																																																																																																															else
																																																																																																																																																																															{
																																																																																																																																																																																bool flag174 = c == "PE";
																																																																																																																																																																																if (flag174)
																																																																																																																																																																																{
																																																																																																																																																																																	result = "\ud83c\uddf5\ud83c\uddea";
																																																																																																																																																																																}
																																																																																																																																																																																else
																																																																																																																																																																																{
																																																																																																																																																																																	bool flag175 = c == "PF";
																																																																																																																																																																																	if (flag175)
																																																																																																																																																																																	{
																																																																																																																																																																																		result = "\ud83c\uddf5\ud83c\uddeb";
																																																																																																																																																																																	}
																																																																																																																																																																																	else
																																																																																																																																																																																	{
																																																																																																																																																																																		bool flag176 = c == "PG";
																																																																																																																																																																																		if (flag176)
																																																																																																																																																																																		{
																																																																																																																																																																																			result = "\ud83c\uddf5\ud83c\uddec";
																																																																																																																																																																																		}
																																																																																																																																																																																		else
																																																																																																																																																																																		{
																																																																																																																																																																																			bool flag177 = c == "PH";
																																																																																																																																																																																			if (flag177)
																																																																																																																																																																																			{
																																																																																																																																																																																				result = "\ud83c\uddf5\ud83c\udded";
																																																																																																																																																																																			}
																																																																																																																																																																																			else
																																																																																																																																																																																			{
																																																																																																																																																																																				bool flag178 = c == "PK";
																																																																																																																																																																																				if (flag178)
																																																																																																																																																																																				{
																																																																																																																																																																																					result = "\ud83c\uddf5\ud83c\uddf0";
																																																																																																																																																																																				}
																																																																																																																																																																																				else
																																																																																																																																																																																				{
																																																																																																																																																																																					bool flag179 = c == "PL";
																																																																																																																																																																																					if (flag179)
																																																																																																																																																																																					{
																																																																																																																																																																																						result = "\ud83c\uddf5\ud83c\uddf1";
																																																																																																																																																																																					}
																																																																																																																																																																																					else
																																																																																																																																																																																					{
																																																																																																																																																																																						bool flag180 = c == "PM";
																																																																																																																																																																																						if (flag180)
																																																																																																																																																																																						{
																																																																																																																																																																																							result = "\ud83c\uddf5\ud83c\uddf2";
																																																																																																																																																																																						}
																																																																																																																																																																																						else
																																																																																																																																																																																						{
																																																																																																																																																																																							bool flag181 = c == "PN";
																																																																																																																																																																																							if (flag181)
																																																																																																																																																																																							{
																																																																																																																																																																																								result = "\ud83c\uddf5\ud83c\uddf3";
																																																																																																																																																																																							}
																																																																																																																																																																																							else
																																																																																																																																																																																							{
																																																																																																																																																																																								bool flag182 = c == "PR";
																																																																																																																																																																																								if (flag182)
																																																																																																																																																																																								{
																																																																																																																																																																																									result = "\ud83c\uddf5\ud83c\uddf7";
																																																																																																																																																																																								}
																																																																																																																																																																																								else
																																																																																																																																																																																								{
																																																																																																																																																																																									bool flag183 = c == "PS";
																																																																																																																																																																																									if (flag183)
																																																																																																																																																																																									{
																																																																																																																																																																																										result = "\ud83c\uddf5\ud83c\uddf8";
																																																																																																																																																																																									}
																																																																																																																																																																																									else
																																																																																																																																																																																									{
																																																																																																																																																																																										bool flag184 = c == "PT";
																																																																																																																																																																																										if (flag184)
																																																																																																																																																																																										{
																																																																																																																																																																																											result = "\ud83c\uddf5\ud83c\uddf9";
																																																																																																																																																																																										}
																																																																																																																																																																																										else
																																																																																																																																																																																										{
																																																																																																																																																																																											bool flag185 = c == "PW";
																																																																																																																																																																																											if (flag185)
																																																																																																																																																																																											{
																																																																																																																																																																																												result = "\ud83c\uddf5\ud83c\uddfc";
																																																																																																																																																																																											}
																																																																																																																																																																																											else
																																																																																																																																																																																											{
																																																																																																																																																																																												bool flag186 = c == "PY";
																																																																																																																																																																																												if (flag186)
																																																																																																																																																																																												{
																																																																																																																																																																																													result = "\ud83c\uddf5\ud83c\uddfe";
																																																																																																																																																																																												}
																																																																																																																																																																																												else
																																																																																																																																																																																												{
																																																																																																																																																																																													bool flag187 = c == "QA";
																																																																																																																																																																																													if (flag187)
																																																																																																																																																																																													{
																																																																																																																																																																																														result = "\ud83c\uddf6\ud83c\udde6";
																																																																																																																																																																																													}
																																																																																																																																																																																													else
																																																																																																																																																																																													{
																																																																																																																																																																																														bool flag188 = c == "RE";
																																																																																																																																																																																														if (flag188)
																																																																																																																																																																																														{
																																																																																																																																																																																															result = "\ud83c\uddf7\ud83c\uddea";
																																																																																																																																																																																														}
																																																																																																																																																																																														else
																																																																																																																																																																																														{
																																																																																																																																																																																															bool flag189 = c == "RO";
																																																																																																																																																																																															if (flag189)
																																																																																																																																																																																															{
																																																																																																																																																																																																result = "\ud83c\uddf7\ud83c\uddf4";
																																																																																																																																																																																															}
																																																																																																																																																																																															else
																																																																																																																																																																																															{
																																																																																																																																																																																																bool flag190 = c == "RS";
																																																																																																																																																																																																if (flag190)
																																																																																																																																																																																																{
																																																																																																																																																																																																	result = "\ud83c\uddf7\ud83c\uddf8";
																																																																																																																																																																																																}
																																																																																																																																																																																																else
																																																																																																																																																																																																{
																																																																																																																																																																																																	bool flag191 = c == "RU";
																																																																																																																																																																																																	if (flag191)
																																																																																																																																																																																																	{
																																																																																																																																																																																																		result = "\ud83c\uddf7\ud83c\uddfa";
																																																																																																																																																																																																	}
																																																																																																																																																																																																	else
																																																																																																																																																																																																	{
																																																																																																																																																																																																		bool flag192 = c == "RW";
																																																																																																																																																																																																		if (flag192)
																																																																																																																																																																																																		{
																																																																																																																																																																																																			result = "\ud83c\uddf7\ud83c\uddfc";
																																																																																																																																																																																																		}
																																																																																																																																																																																																		else
																																																																																																																																																																																																		{
																																																																																																																																																																																																			bool flag193 = c == "SA";
																																																																																																																																																																																																			if (flag193)
																																																																																																																																																																																																			{
																																																																																																																																																																																																				result = "\ud83c\uddf8\ud83c\udde6";
																																																																																																																																																																																																			}
																																																																																																																																																																																																			else
																																																																																																																																																																																																			{
																																																																																																																																																																																																				bool flag194 = c == "SB";
																																																																																																																																																																																																				if (flag194)
																																																																																																																																																																																																				{
																																																																																																																																																																																																					result = "\ud83c\uddf8\ud83c\udde7";
																																																																																																																																																																																																				}
																																																																																																																																																																																																				else
																																																																																																																																																																																																				{
																																																																																																																																																																																																					bool flag195 = c == "SC";
																																																																																																																																																																																																					if (flag195)
																																																																																																																																																																																																					{
																																																																																																																																																																																																						result = "\ud83c\uddf8\ud83c\udde8";
																																																																																																																																																																																																					}
																																																																																																																																																																																																					else
																																																																																																																																																																																																					{
																																																																																																																																																																																																						bool flag196 = c == "SD";
																																																																																																																																																																																																						if (flag196)
																																																																																																																																																																																																						{
																																																																																																																																																																																																							result = "\ud83c\uddf8\ud83c\udde9";
																																																																																																																																																																																																						}
																																																																																																																																																																																																						else
																																																																																																																																																																																																						{
																																																																																																																																																																																																							bool flag197 = c == "SE";
																																																																																																																																																																																																							if (flag197)
																																																																																																																																																																																																							{
																																																																																																																																																																																																								result = "\ud83c\uddf8\ud83c\uddea";
																																																																																																																																																																																																							}
																																																																																																																																																																																																							else
																																																																																																																																																																																																							{
																																																																																																																																																																																																								bool flag198 = c == "SG";
																																																																																																																																																																																																								if (flag198)
																																																																																																																																																																																																								{
																																																																																																																																																																																																									result = "\ud83c\uddf8\ud83c\uddec";
																																																																																																																																																																																																								}
																																																																																																																																																																																																								else
																																																																																																																																																																																																								{
																																																																																																																																																																																																									bool flag199 = c == "SH";
																																																																																																																																																																																																									if (flag199)
																																																																																																																																																																																																									{
																																																																																																																																																																																																										result = "\ud83c\uddf8\ud83c\udded";
																																																																																																																																																																																																									}
																																																																																																																																																																																																									else
																																																																																																																																																																																																									{
																																																																																																																																																																																																										bool flag200 = c == "SI";
																																																																																																																																																																																																										if (flag200)
																																																																																																																																																																																																										{
																																																																																																																																																																																																											result = "\ud83c\uddf8\ud83c\uddee";
																																																																																																																																																																																																										}
																																																																																																																																																																																																										else
																																																																																																																																																																																																										{
																																																																																																																																																																																																											bool flag201 = c == "SJ";
																																																																																																																																																																																																											if (flag201)
																																																																																																																																																																																																											{
																																																																																																																																																																																																												result = "\ud83c\uddf8\ud83c\uddef";
																																																																																																																																																																																																											}
																																																																																																																																																																																																											else
																																																																																																																																																																																																											{
																																																																																																																																																																																																												bool flag202 = c == "SK";
																																																																																																																																																																																																												if (flag202)
																																																																																																																																																																																																												{
																																																																																																																																																																																																													result = "\ud83c\uddf8\ud83c\uddf0";
																																																																																																																																																																																																												}
																																																																																																																																																																																																												else
																																																																																																																																																																																																												{
																																																																																																																																																																																																													bool flag203 = c == "SL";
																																																																																																																																																																																																													if (flag203)
																																																																																																																																																																																																													{
																																																																																																																																																																																																														result = "\ud83c\uddf8\ud83c\uddf1";
																																																																																																																																																																																																													}
																																																																																																																																																																																																													else
																																																																																																																																																																																																													{
																																																																																																																																																																																																														bool flag204 = c == "SM";
																																																																																																																																																																																																														if (flag204)
																																																																																																																																																																																																														{
																																																																																																																																																																																																															result = "\ud83c\uddf8\ud83c\uddf2";
																																																																																																																																																																																																														}
																																																																																																																																																																																																														else
																																																																																																																																																																																																														{
																																																																																																																																																																																																															bool flag205 = c == "SN";
																																																																																																																																																																																																															if (flag205)
																																																																																																																																																																																																															{
																																																																																																																																																																																																																result = "\ud83c\uddf8\ud83c\uddf3";
																																																																																																																																																																																																															}
																																																																																																																																																																																																															else
																																																																																																																																																																																																															{
																																																																																																																																																																																																																bool flag206 = c == "SO";
																																																																																																																																																																																																																if (flag206)
																																																																																																																																																																																																																{
																																																																																																																																																																																																																	result = "\ud83c\uddf8\ud83c\uddf4";
																																																																																																																																																																																																																}
																																																																																																																																																																																																																else
																																																																																																																																																																																																																{
																																																																																																																																																																																																																	bool flag207 = c == "SR";
																																																																																																																																																																																																																	if (flag207)
																																																																																																																																																																																																																	{
																																																																																																																																																																																																																		result = "\ud83c\uddf8\ud83c\uddf7";
																																																																																																																																																																																																																	}
																																																																																																																																																																																																																	else
																																																																																																																																																																																																																	{
																																																																																																																																																																																																																		bool flag208 = c == "SS";
																																																																																																																																																																																																																		if (flag208)
																																																																																																																																																																																																																		{
																																																																																																																																																																																																																			result = "\ud83c\uddf8\ud83c\uddf8";
																																																																																																																																																																																																																		}
																																																																																																																																																																																																																		else
																																																																																																																																																																																																																		{
																																																																																																																																																																																																																			bool flag209 = c == "ST";
																																																																																																																																																																																																																			if (flag209)
																																																																																																																																																																																																																			{
																																																																																																																																																																																																																				result = "\ud83c\uddf8\ud83c\uddf9";
																																																																																																																																																																																																																			}
																																																																																																																																																																																																																			else
																																																																																																																																																																																																																			{
																																																																																																																																																																																																																				bool flag210 = c == "SV";
																																																																																																																																																																																																																				if (flag210)
																																																																																																																																																																																																																				{
																																																																																																																																																																																																																					result = "\ud83c\uddf8\ud83c\uddfb";
																																																																																																																																																																																																																				}
																																																																																																																																																																																																																				else
																																																																																																																																																																																																																				{
																																																																																																																																																																																																																					bool flag211 = c == "SX";
																																																																																																																																																																																																																					if (flag211)
																																																																																																																																																																																																																					{
																																																																																																																																																																																																																						result = "\ud83c\uddf8\ud83c\uddfd";
																																																																																																																																																																																																																					}
																																																																																																																																																																																																																					else
																																																																																																																																																																																																																					{
																																																																																																																																																																																																																						bool flag212 = c == "SY";
																																																																																																																																																																																																																						if (flag212)
																																																																																																																																																																																																																						{
																																																																																																																																																																																																																							result = "\ud83c\uddf8\ud83c\uddfe";
																																																																																																																																																																																																																						}
																																																																																																																																																																																																																						else
																																																																																																																																																																																																																						{
																																																																																																																																																																																																																							bool flag213 = c == "SZ";
																																																																																																																																																																																																																							if (flag213)
																																																																																																																																																																																																																							{
																																																																																																																																																																																																																								result = "\ud83c\uddf8\ud83c\uddff";
																																																																																																																																																																																																																							}
																																																																																																																																																																																																																							else
																																																																																																																																																																																																																							{
																																																																																																																																																																																																																								bool flag214 = c == "TC";
																																																																																																																																																																																																																								if (flag214)
																																																																																																																																																																																																																								{
																																																																																																																																																																																																																									result = "\ud83c\uddf9\ud83c\udde8";
																																																																																																																																																																																																																								}
																																																																																																																																																																																																																								else
																																																																																																																																																																																																																								{
																																																																																																																																																																																																																									bool flag215 = c == "TD";
																																																																																																																																																																																																																									if (flag215)
																																																																																																																																																																																																																									{
																																																																																																																																																																																																																										result = "\ud83c\uddf9\ud83c\udde9";
																																																																																																																																																																																																																									}
																																																																																																																																																																																																																									else
																																																																																																																																																																																																																									{
																																																																																																																																																																																																																										bool flag216 = c == "TF";
																																																																																																																																																																																																																										if (flag216)
																																																																																																																																																																																																																										{
																																																																																																																																																																																																																											result = "\ud83c\uddf9\ud83c\uddeb";
																																																																																																																																																																																																																										}
																																																																																																																																																																																																																										else
																																																																																																																																																																																																																										{
																																																																																																																																																																																																																											bool flag217 = c == "TG";
																																																																																																																																																																																																																											if (flag217)
																																																																																																																																																																																																																											{
																																																																																																																																																																																																																												result = "\ud83c\uddf9\ud83c\uddec";
																																																																																																																																																																																																																											}
																																																																																																																																																																																																																											else
																																																																																																																																																																																																																											{
																																																																																																																																																																																																																												bool flag218 = c == "TH";
																																																																																																																																																																																																																												if (flag218)
																																																																																																																																																																																																																												{
																																																																																																																																																																																																																													result = "\ud83c\uddf9\ud83c\udded";
																																																																																																																																																																																																																												}
																																																																																																																																																																																																																												else
																																																																																																																																																																																																																												{
																																																																																																																																																																																																																													bool flag219 = c == "TJ";
																																																																																																																																																																																																																													if (flag219)
																																																																																																																																																																																																																													{
																																																																																																																																																																																																																														result = "\ud83c\uddf9\ud83c\uddef";
																																																																																																																																																																																																																													}
																																																																																																																																																																																																																													else
																																																																																																																																																																																																																													{
																																																																																																																																																																																																																														bool flag220 = c == "TK";
																																																																																																																																																																																																																														if (flag220)
																																																																																																																																																																																																																														{
																																																																																																																																																																																																																															result = "\ud83c\uddf9\ud83c\uddf0";
																																																																																																																																																																																																																														}
																																																																																																																																																																																																																														else
																																																																																																																																																																																																																														{
																																																																																																																																																																																																																															bool flag221 = c == "TL";
																																																																																																																																																																																																																															if (flag221)
																																																																																																																																																																																																																															{
																																																																																																																																																																																																																																result = "\ud83c\uddf9\ud83c\uddf1";
																																																																																																																																																																																																																															}
																																																																																																																																																																																																																															else
																																																																																																																																																																																																																															{
																																																																																																																																																																																																																																bool flag222 = c == "TM";
																																																																																																																																																																																																																																if (flag222)
																																																																																																																																																																																																																																{
																																																																																																																																																																																																																																	result = "\ud83c\uddf9\ud83c\uddf2";
																																																																																																																																																																																																																																}
																																																																																																																																																																																																																																else
																																																																																																																																																																																																																																{
																																																																																																																																																																																																																																	bool flag223 = c == "TN";
																																																																																																																																																																																																																																	if (flag223)
																																																																																																																																																																																																																																	{
																																																																																																																																																																																																																																		result = "\ud83c\uddf9\ud83c\uddf3";
																																																																																																																																																																																																																																	}
																																																																																																																																																																																																																																	else
																																																																																																																																																																																																																																	{
																																																																																																																																																																																																																																		bool flag224 = c == "TO";
																																																																																																																																																																																																																																		if (flag224)
																																																																																																																																																																																																																																		{
																																																																																																																																																																																																																																			result = "\ud83c\uddf9\ud83c\uddf4";
																																																																																																																																																																																																																																		}
																																																																																																																																																																																																																																		else
																																																																																																																																																																																																																																		{
																																																																																																																																																																																																																																			bool flag225 = c == "TR";
																																																																																																																																																																																																																																			if (flag225)
																																																																																																																																																																																																																																			{
																																																																																																																																																																																																																																				result = "\ud83c\uddf9\ud83c\uddf7";
																																																																																																																																																																																																																																			}
																																																																																																																																																																																																																																			else
																																																																																																																																																																																																																																			{
																																																																																																																																																																																																																																				bool flag226 = c == "TT";
																																																																																																																																																																																																																																				if (flag226)
																																																																																																																																																																																																																																				{
																																																																																																																																																																																																																																					result = "\ud83c\uddf9\ud83c\uddf9";
																																																																																																																																																																																																																																				}
																																																																																																																																																																																																																																				else
																																																																																																																																																																																																																																				{
																																																																																																																																																																																																																																					bool flag227 = c == "TV";
																																																																																																																																																																																																																																					if (flag227)
																																																																																																																																																																																																																																					{
																																																																																																																																																																																																																																						result = "\ud83c\uddf9\ud83c\uddfb";
																																																																																																																																																																																																																																					}
																																																																																																																																																																																																																																					else
																																																																																																																																																																																																																																					{
																																																																																																																																																																																																																																						bool flag228 = c == "TW";
																																																																																																																																																																																																																																						if (flag228)
																																																																																																																																																																																																																																						{
																																																																																																																																																																																																																																							result = "\ud83c\uddf9\ud83c\uddfc";
																																																																																																																																																																																																																																						}
																																																																																																																																																																																																																																						else
																																																																																																																																																																																																																																						{
																																																																																																																																																																																																																																							bool flag229 = c == "TZ";
																																																																																																																																																																																																																																							if (flag229)
																																																																																																																																																																																																																																							{
																																																																																																																																																																																																																																								result = "\ud83c\uddf9\ud83c\uddff";
																																																																																																																																																																																																																																							}
																																																																																																																																																																																																																																							else
																																																																																																																																																																																																																																							{
																																																																																																																																																																																																																																								bool flag230 = c == "UA";
																																																																																																																																																																																																																																								if (flag230)
																																																																																																																																																																																																																																								{
																																																																																																																																																																																																																																									result = "\ud83c\uddfa\ud83c\udde6";
																																																																																																																																																																																																																																								}
																																																																																																																																																																																																																																								else
																																																																																																																																																																																																																																								{
																																																																																																																																																																																																																																									bool flag231 = c == "UG";
																																																																																																																																																																																																																																									if (flag231)
																																																																																																																																																																																																																																									{
																																																																																																																																																																																																																																										result = "\ud83c\uddfa\ud83c\uddec";
																																																																																																																																																																																																																																									}
																																																																																																																																																																																																																																									else
																																																																																																																																																																																																																																									{
																																																																																																																																																																																																																																										bool flag232 = c == "UM";
																																																																																																																																																																																																																																										if (flag232)
																																																																																																																																																																																																																																										{
																																																																																																																																																																																																																																											result = "\ud83c\uddfa\ud83c\uddf2";
																																																																																																																																																																																																																																										}
																																																																																																																																																																																																																																										else
																																																																																																																																																																																																																																										{
																																																																																																																																																																																																																																											bool flag233 = c == "US";
																																																																																																																																																																																																																																											if (flag233)
																																																																																																																																																																																																																																											{
																																																																																																																																																																																																																																												result = "\ud83c\uddfa\ud83c\uddf8";
																																																																																																																																																																																																																																											}
																																																																																																																																																																																																																																											else
																																																																																																																																																																																																																																											{
																																																																																																																																																																																																																																												bool flag234 = c == "UY";
																																																																																																																																																																																																																																												if (flag234)
																																																																																																																																																																																																																																												{
																																																																																																																																																																																																																																													result = "\ud83c\uddfa\ud83c\uddfe";
																																																																																																																																																																																																																																												}
																																																																																																																																																																																																																																												else
																																																																																																																																																																																																																																												{
																																																																																																																																																																																																																																													bool flag235 = c == "UZ";
																																																																																																																																																																																																																																													if (flag235)
																																																																																																																																																																																																																																													{
																																																																																																																																																																																																																																														result = "\ud83c\uddfa\ud83c\uddff";
																																																																																																																																																																																																																																													}
																																																																																																																																																																																																																																													else
																																																																																																																																																																																																																																													{
																																																																																																																																																																																																																																														bool flag236 = c == "VA";
																																																																																																																																																																																																																																														if (flag236)
																																																																																																																																																																																																																																														{
																																																																																																																																																																																																																																															result = "\ud83c\uddfb\ud83c\udde6";
																																																																																																																																																																																																																																														}
																																																																																																																																																																																																																																														else
																																																																																																																																																																																																																																														{
																																																																																																																																																																																																																																															bool flag237 = c == "VC";
																																																																																																																																																																																																																																															if (flag237)
																																																																																																																																																																																																																																															{
																																																																																																																																																																																																																																																result = "\ud83c\uddfb\ud83c\udde8";
																																																																																																																																																																																																																																															}
																																																																																																																																																																																																																																															else
																																																																																																																																																																																																																																															{
																																																																																																																																																																																																																																																bool flag238 = c == "VE";
																																																																																																																																																																																																																																																if (flag238)
																																																																																																																																																																																																																																																{
																																																																																																																																																																																																																																																	result = "\ud83c\uddfb\ud83c\uddea";
																																																																																																																																																																																																																																																}
																																																																																																																																																																																																																																																else
																																																																																																																																																																																																																																																{
																																																																																																																																																																																																																																																	bool flag239 = c == "VG";
																																																																																																																																																																																																																																																	if (flag239)
																																																																																																																																																																																																																																																	{
																																																																																																																																																																																																																																																		result = "\ud83c\uddfb\ud83c\uddec";
																																																																																																																																																																																																																																																	}
																																																																																																																																																																																																																																																	else
																																																																																																																																																																																																																																																	{
																																																																																																																																																																																																																																																		bool flag240 = c == "VI";
																																																																																																																																																																																																																																																		if (flag240)
																																																																																																																																																																																																																																																		{
																																																																																																																																																																																																																																																			result = "\ud83c\uddfb\ud83c\uddee";
																																																																																																																																																																																																																																																		}
																																																																																																																																																																																																																																																		else
																																																																																																																																																																																																																																																		{
																																																																																																																																																																																																																																																			bool flag241 = c == "VN";
																																																																																																																																																																																																																																																			if (flag241)
																																																																																																																																																																																																																																																			{
																																																																																																																																																																																																																																																				result = "\ud83c\uddfb\ud83c\uddf3";
																																																																																																																																																																																																																																																			}
																																																																																																																																																																																																																																																			else
																																																																																																																																																																																																																																																			{
																																																																																																																																																																																																																																																				bool flag242 = c == "VU";
																																																																																																																																																																																																																																																				if (flag242)
																																																																																																																																																																																																																																																				{
																																																																																																																																																																																																																																																					result = "\ud83c\uddfb\ud83c\uddfa";
																																																																																																																																																																																																																																																				}
																																																																																																																																																																																																																																																				else
																																																																																																																																																																																																																																																				{
																																																																																																																																																																																																																																																					bool flag243 = c == "WF";
																																																																																																																																																																																																																																																					if (flag243)
																																																																																																																																																																																																																																																					{
																																																																																																																																																																																																																																																						result = "\ud83c\uddfc\ud83c\uddeb";
																																																																																																																																																																																																																																																					}
																																																																																																																																																																																																																																																					else
																																																																																																																																																																																																																																																					{
																																																																																																																																																																																																																																																						bool flag244 = c == "WS";
																																																																																																																																																																																																																																																						if (flag244)
																																																																																																																																																																																																																																																						{
																																																																																																																																																																																																																																																							result = "\ud83c\uddfc\ud83c\uddf8";
																																																																																																																																																																																																																																																						}
																																																																																																																																																																																																																																																						else
																																																																																																																																																																																																																																																						{
																																																																																																																																																																																																																																																							bool flag245 = c == "XK";
																																																																																																																																																																																																																																																							if (flag245)
																																																																																																																																																																																																																																																							{
																																																																																																																																																																																																																																																								result = "\ud83c\uddfd\ud83c\uddf0";
																																																																																																																																																																																																																																																							}
																																																																																																																																																																																																																																																							else
																																																																																																																																																																																																																																																							{
																																																																																																																																																																																																																																																								bool flag246 = c == "YE";
																																																																																																																																																																																																																																																								if (flag246)
																																																																																																																																																																																																																																																								{
																																																																																																																																																																																																																																																									result = "\ud83c\uddfe\ud83c\uddea";
																																																																																																																																																																																																																																																								}
																																																																																																																																																																																																																																																								else
																																																																																																																																																																																																																																																								{
																																																																																																																																																																																																																																																									bool flag247 = c == "YT";
																																																																																																																																																																																																																																																									if (flag247)
																																																																																																																																																																																																																																																									{
																																																																																																																																																																																																																																																										result = "\ud83c\uddfe\ud83c\uddf9";
																																																																																																																																																																																																																																																									}
																																																																																																																																																																																																																																																									else
																																																																																																																																																																																																																																																									{
																																																																																																																																																																																																																																																										bool flag248 = c == "ZA";
																																																																																																																																																																																																																																																										if (flag248)
																																																																																																																																																																																																																																																										{
																																																																																																																																																																																																																																																											result = "\ud83c\uddff\ud83c\udde6";
																																																																																																																																																																																																																																																										}
																																																																																																																																																																																																																																																										else
																																																																																																																																																																																																																																																										{
																																																																																																																																																																																																																																																											bool flag249 = c == "ZM";
																																																																																																																																																																																																																																																											if (flag249)
																																																																																																																																																																																																																																																											{
																																																																																																																																																																																																																																																												result = "\ud83c\uddff\ud83c\uddf2";
																																																																																																																																																																																																																																																											}
																																																																																																																																																																																																																																																											else
																																																																																																																																																																																																																																																											{
																																																																																																																																																																																																																																																												result = "\ud83c\udff3";
																																																																																																																																																																																																																																																											}
																																																																																																																																																																																																																																																										}
																																																																																																																																																																																																																																																									}
																																																																																																																																																																																																																																																								}
																																																																																																																																																																																																																																																							}
																																																																																																																																																																																																																																																						}
																																																																																																																																																																																																																																																					}
																																																																																																																																																																																																																																																				}
																																																																																																																																																																																																																																																			}
																																																																																																																																																																																																																																																		}
																																																																																																																																																																																																																																																	}
																																																																																																																																																																																																																																																}
																																																																																																																																																																																																																																															}
																																																																																																																																																																																																																																														}
																																																																																																																																																																																																																																													}
																																																																																																																																																																																																																																												}
																																																																																																																																																																																																																																											}
																																																																																																																																																																																																																																										}
																																																																																																																																																																																																																																									}
																																																																																																																																																																																																																																								}
																																																																																																																																																																																																																																							}
																																																																																																																																																																																																																																						}
																																																																																																																																																																																																																																					}
																																																																																																																																																																																																																																				}
																																																																																																																																																																																																																																			}
																																																																																																																																																																																																																																		}
																																																																																																																																																																																																																																	}
																																																																																																																																																																																																																																}
																																																																																																																																																																																																																															}
																																																																																																																																																																																																																														}
																																																																																																																																																																																																																													}
																																																																																																																																																																																																																												}
																																																																																																																																																																																																																											}
																																																																																																																																																																																																																										}
																																																																																																																																																																																																																									}
																																																																																																																																																																																																																								}
																																																																																																																																																																																																																							}
																																																																																																																																																																																																																						}
																																																																																																																																																																																																																					}
																																																																																																																																																																																																																				}
																																																																																																																																																																																																																			}
																																																																																																																																																																																																																		}
																																																																																																																																																																																																																	}
																																																																																																																																																																																																																}
																																																																																																																																																																																																															}
																																																																																																																																																																																																														}
																																																																																																																																																																																																													}
																																																																																																																																																																																																												}
																																																																																																																																																																																																											}
																																																																																																																																																																																																										}
																																																																																																																																																																																																									}
																																																																																																																																																																																																								}
																																																																																																																																																																																																							}
																																																																																																																																																																																																						}
																																																																																																																																																																																																					}
																																																																																																																																																																																																				}
																																																																																																																																																																																																			}
																																																																																																																																																																																																		}
																																																																																																																																																																																																	}
																																																																																																																																																																																																}
																																																																																																																																																																																															}
																																																																																																																																																																																														}
																																																																																																																																																																																													}
																																																																																																																																																																																												}
																																																																																																																																																																																											}
																																																																																																																																																																																										}
																																																																																																																																																																																									}
																																																																																																																																																																																								}
																																																																																																																																																																																							}
																																																																																																																																																																																						}
																																																																																																																																																																																					}
																																																																																																																																																																																				}
																																																																																																																																																																																			}
																																																																																																																																																																																		}
																																																																																																																																																																																	}
																																																																																																																																																																																}
																																																																																																																																																																															}
																																																																																																																																																																														}
																																																																																																																																																																													}
																																																																																																																																																																												}
																																																																																																																																																																											}
																																																																																																																																																																										}
																																																																																																																																																																									}
																																																																																																																																																																								}
																																																																																																																																																																							}
																																																																																																																																																																						}
																																																																																																																																																																					}
																																																																																																																																																																				}
																																																																																																																																																																			}
																																																																																																																																																																		}
																																																																																																																																																																	}
																																																																																																																																																																}
																																																																																																																																																															}
																																																																																																																																																														}
																																																																																																																																																													}
																																																																																																																																																												}
																																																																																																																																																											}
																																																																																																																																																										}
																																																																																																																																																									}
																																																																																																																																																								}
																																																																																																																																																							}
																																																																																																																																																						}
																																																																																																																																																					}
																																																																																																																																																				}
																																																																																																																																																			}
																																																																																																																																																		}
																																																																																																																																																	}
																																																																																																																																																}
																																																																																																																																															}
																																																																																																																																														}
																																																																																																																																													}
																																																																																																																																												}
																																																																																																																																											}
																																																																																																																																										}
																																																																																																																																									}
																																																																																																																																								}
																																																																																																																																							}
																																																																																																																																						}
																																																																																																																																					}
																																																																																																																																				}
																																																																																																																																			}
																																																																																																																																		}
																																																																																																																																	}
																																																																																																																																}
																																																																																																																															}
																																																																																																																														}
																																																																																																																													}
																																																																																																																												}
																																																																																																																											}
																																																																																																																										}
																																																																																																																									}
																																																																																																																								}
																																																																																																																							}
																																																																																																																						}
																																																																																																																					}
																																																																																																																				}
																																																																																																																			}
																																																																																																																		}
																																																																																																																	}
																																																																																																																}
																																																																																																															}
																																																																																																														}
																																																																																																													}
																																																																																																												}
																																																																																																											}
																																																																																																										}
																																																																																																									}
																																																																																																								}
																																																																																																							}
																																																																																																						}
																																																																																																					}
																																																																																																				}
																																																																																																			}
																																																																																																		}
																																																																																																	}
																																																																																																}
																																																																																															}
																																																																																														}
																																																																																													}
																																																																																												}
																																																																																											}
																																																																																										}
																																																																																									}
																																																																																								}
																																																																																							}
																																																																																						}
																																																																																					}
																																																																																				}
																																																																																			}
																																																																																		}
																																																																																	}
																																																																																}
																																																																															}
																																																																														}
																																																																													}
																																																																												}
																																																																											}
																																																																										}
																																																																									}
																																																																								}
																																																																							}
																																																																						}
																																																																					}
																																																																				}
																																																																			}
																																																																		}
																																																																	}
																																																																}
																																																															}
																																																														}
																																																													}
																																																												}
																																																											}
																																																										}
																																																									}
																																																								}
																																																							}
																																																						}
																																																					}
																																																				}
																																																			}
																																																		}
																																																	}
																																																}
																																															}
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			return result;
		}
	}
}
