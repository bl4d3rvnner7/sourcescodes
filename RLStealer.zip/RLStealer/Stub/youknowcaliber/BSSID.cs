﻿using System;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;

namespace youknowcaliber
{
	internal class BSSID
	{
		[DllImport("iphlpapi.dll", ExactSpelling = true)]
		private static extern int SendARP(int destIp, int srcIP, byte[] macAddr, ref uint physicalAddrLen);

		public static string GetBSSID()
		{
			byte[] array = new byte[6];
			uint num = (uint)array.Length;
			try
			{
				string defaultGateway = BSSID.GetDefaultGateway();
				bool flag = BSSID.SendARP(BitConverter.ToInt32(IPAddress.Parse(defaultGateway).GetAddressBytes(), 0), 0, array, ref num) != 0;
				if (flag)
				{
					return "unknown";
				}
				string[] array2 = new string[num];
				int num2 = 0;
				while ((long)num2 < (long)((ulong)num))
				{
					array2[num2] = array[num2].ToString("x2");
					num2++;
				}
				return string.Join(":", array2);
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return "Failed";
		}

		public static string GetDefaultGateway()
		{
			try
			{
				return (from g in (from n in NetworkInterface.GetAllNetworkInterfaces()
				where n.OperationalStatus == OperationalStatus.Up
				where n.NetworkInterfaceType != NetworkInterfaceType.Loopback
				select n).SelectMany(delegate(NetworkInterface n)
				{
					IPInterfaceProperties ipproperties = n.GetIPProperties();
					return (ipproperties != null) ? ipproperties.GatewayAddresses : null;
				})
				select (g != null) ? g.Address : null into a
				where a != null
				select a).FirstOrDefault<IPAddress>().ToString();
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return "Unknown";
		}
	}
}
