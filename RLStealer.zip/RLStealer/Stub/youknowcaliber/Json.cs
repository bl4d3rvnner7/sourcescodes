﻿using System;
using System.Text.RegularExpressions;

namespace youknowcaliber
{
	internal sealed class Json
	{
		public Json(string data)
		{
			this.Data = data;
		}

		public string GetValue(string value)
		{
			string text = string.Empty;
			Regex regex = new Regex("\"{value}\":\"([^\"]+)\"");
			Match match = regex.Match(this.Data);
			bool flag = !match.Success;
			string result;
			if (flag)
			{
				result = text;
			}
			else
			{
				text = Regex.Split(match.Value, "\"")[3];
				result = text;
			}
			return result;
		}

		public void Remove(string[] values)
		{
			foreach (string oldValue in values)
			{
				this.Data = this.Data.Replace(oldValue, "");
			}
		}

		public string[] SplitData(string delimiter = "},")
		{
			return Regex.Split(this.Data, delimiter);
		}

		public string Data;
	}
}
