﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace youknowcaliber
{
	internal class AES
	{
		public static string EncryptStringAES(string plainText, string sharedSecret)
		{
			bool flag = string.IsNullOrEmpty(plainText);
			if (flag)
			{
				throw new ArgumentNullException("plainText");
			}
			bool flag2 = string.IsNullOrEmpty(sharedSecret);
			if (flag2)
			{
				throw new ArgumentNullException("sharedSecret");
			}
			string result = "";
			RijndaelManaged rijndaelManaged = null;
			try
			{
				Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(sharedSecret, AES.Salt);
				rijndaelManaged = new RijndaelManaged();
				rijndaelManaged.Key = rfc2898DeriveBytes.GetBytes(rijndaelManaged.KeySize / 8);
				ICryptoTransform transform = rijndaelManaged.CreateEncryptor(rijndaelManaged.Key, rijndaelManaged.IV);
				using (MemoryStream memoryStream = new MemoryStream())
				{
					memoryStream.Write(BitConverter.GetBytes(rijndaelManaged.IV.Length), 0, 4);
					memoryStream.Write(rijndaelManaged.IV, 0, rijndaelManaged.IV.Length);
					using (CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write))
					{
						using (StreamWriter streamWriter = new StreamWriter(cryptoStream))
						{
							streamWriter.Write(plainText);
						}
					}
					result = Convert.ToBase64String(memoryStream.ToArray());
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
				return result;
			}
			finally
			{
				bool flag3 = rijndaelManaged != null;
				if (flag3)
				{
					rijndaelManaged.Clear();
				}
			}
			return result;
		}

		private static readonly byte[] Salt = Encoding.ASCII.GetBytes("o6806642kbM7c5");
	}
}
