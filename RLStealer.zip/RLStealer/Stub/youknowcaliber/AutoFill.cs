﻿using System;

namespace youknowcaliber
{
	internal struct AutoFill
	{
		public string sName;

		public string sValue;
	}
}
