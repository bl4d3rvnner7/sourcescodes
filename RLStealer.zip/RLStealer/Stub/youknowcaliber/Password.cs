﻿using System;

namespace youknowcaliber
{
	public struct Password
	{
		public string sUrl { get; set; }

		public string sUsername { get; set; }

		public string sPassword { get; set; }
	}
}
