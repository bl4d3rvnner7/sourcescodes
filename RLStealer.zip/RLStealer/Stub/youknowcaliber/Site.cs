﻿using System;

namespace youknowcaliber
{
	internal struct Site
	{
		public string sUrl { get; set; }

		public string sTitle { get; set; }

		public int iCount { get; set; }
	}
}
