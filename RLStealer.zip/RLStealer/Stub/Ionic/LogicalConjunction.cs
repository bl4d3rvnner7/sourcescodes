﻿using System;

namespace Ionic
{
	internal enum LogicalConjunction
	{
		NONE,
		AND,
		OR,
		XOR
	}
}
