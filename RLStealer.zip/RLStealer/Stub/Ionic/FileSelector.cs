﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using Ionic.Zip;

namespace Ionic
{
	public class FileSelector
	{
		public FileSelector(string selectionCriteria) : this(selectionCriteria, true)
		{
		}

		public FileSelector(string selectionCriteria, bool traverseDirectoryReparsePoints)
		{
			bool flag = !string.IsNullOrEmpty(selectionCriteria);
			if (flag)
			{
				this._Criterion = FileSelector._ParseCriterion(selectionCriteria);
			}
			this.TraverseReparsePoints = traverseDirectoryReparsePoints;
		}

		public string SelectionCriteria
		{
			get
			{
				bool flag = this._Criterion == null;
				string result;
				if (flag)
				{
					result = null;
				}
				else
				{
					result = this._Criterion.ToString();
				}
				return result;
			}
			set
			{
				bool flag = value == null;
				if (flag)
				{
					this._Criterion = null;
				}
				else
				{
					bool flag2 = value.Trim() == "";
					if (flag2)
					{
						this._Criterion = null;
					}
					else
					{
						this._Criterion = FileSelector._ParseCriterion(value);
					}
				}
			}
		}

		public bool TraverseReparsePoints { get; set; }

		private static string NormalizeCriteriaExpression(string source)
		{
			string[][] array = new string[][]
			{
				new string[]
				{
					"([^']*)\\(\\(([^']+)",
					"$1( ($2"
				},
				new string[]
				{
					"(.)\\)\\)",
					"$1) )"
				},
				new string[]
				{
					"\\((\\S)",
					"( $1"
				},
				new string[]
				{
					"(\\S)\\)",
					"$1 )"
				},
				new string[]
				{
					"^\\)",
					" )"
				},
				new string[]
				{
					"(\\S)\\(",
					"$1 ("
				},
				new string[]
				{
					"\\)(\\S)",
					") $1"
				},
				new string[]
				{
					"(=)('[^']*')",
					"$1 $2"
				},
				new string[]
				{
					"([^ !><])(>|<|!=|=)",
					"$1 $2"
				},
				new string[]
				{
					"(>|<|!=|=)([^ =])",
					"$1 $2"
				},
				new string[]
				{
					"/",
					"\\"
				}
			};
			string input = source;
			for (int i = 0; i < array.Length; i++)
			{
				string pattern = FileSelector.RegexAssertions.PrecededByEvenNumberOfSingleQuotes + array[i][0] + FileSelector.RegexAssertions.FollowedByEvenNumberOfSingleQuotesAndLineEnd;
				input = Regex.Replace(input, pattern, array[i][1]);
			}
			string pattern2 = "/" + FileSelector.RegexAssertions.FollowedByOddNumberOfSingleQuotesAndLineEnd;
			input = Regex.Replace(input, pattern2, "\\");
			pattern2 = " " + FileSelector.RegexAssertions.FollowedByOddNumberOfSingleQuotesAndLineEnd;
			return Regex.Replace(input, pattern2, "\u0006");
		}

		private static SelectionCriterion _ParseCriterion(string s)
		{
			bool flag = s == null;
			SelectionCriterion result;
			if (flag)
			{
				result = null;
			}
			else
			{
				s = FileSelector.NormalizeCriteriaExpression(s);
				bool flag2 = s.IndexOf(" ") == -1;
				if (flag2)
				{
					s = "name = " + s;
				}
				string[] array = s.Trim().Split(new char[]
				{
					' ',
					'\t'
				});
				bool flag3 = array.Length < 3;
				if (flag3)
				{
					throw new ArgumentException(s);
				}
				SelectionCriterion selectionCriterion = null;
				Stack<FileSelector.ParseState> stack = new Stack<FileSelector.ParseState>();
				Stack<SelectionCriterion> stack2 = new Stack<SelectionCriterion>();
				stack.Push(FileSelector.ParseState.Start);
				int i = 0;
				while (i < array.Length)
				{
					string text = array[i].ToLower();
					string text2 = text;
					uint num = <PrivateImplementationDetails>.ComputeStringHash(text2);
					FileSelector.ParseState parseState;
					if (num <= 1563699588U)
					{
						if (num <= 739023492U)
						{
							if (num <= 329706515U)
							{
								if (num != 254395046U)
								{
									if (num != 329706515U)
									{
										goto IL_9B3;
									}
									if (!(text2 == "ctime"))
									{
										goto IL_9B3;
									}
									goto IL_4AC;
								}
								else
								{
									if (!(text2 == "and"))
									{
										goto IL_9B3;
									}
									goto IL_33D;
								}
							}
							else if (num != 597743964U)
							{
								if (num != 739023492U)
								{
									goto IL_9B3;
								}
								if (!(text2 == ")"))
								{
									goto IL_9B3;
								}
								parseState = stack.Pop();
								bool flag4 = stack.Peek() != FileSelector.ParseState.OpenParen;
								if (flag4)
								{
									throw new ArgumentException(string.Join(" ", array, i, array.Length - i));
								}
								stack.Pop();
								stack.Push(FileSelector.ParseState.CriterionDone);
							}
							else
							{
								if (!(text2 == "size"))
								{
									goto IL_9B3;
								}
								goto IL_5D6;
							}
						}
						else if (num <= 1058081160U)
						{
							if (num != 755801111U)
							{
								if (num != 1058081160U)
								{
									goto IL_9B3;
								}
								if (!(text2 == "filename"))
								{
									goto IL_9B3;
								}
								goto IL_7E8;
							}
							else
							{
								if (!(text2 == "("))
								{
									goto IL_9B3;
								}
								parseState = stack.Peek();
								bool flag5 = parseState != FileSelector.ParseState.Start && parseState != FileSelector.ParseState.ConjunctionPending && parseState != FileSelector.ParseState.OpenParen;
								if (flag5)
								{
									throw new ArgumentException(string.Join(" ", array, i, array.Length - i));
								}
								bool flag6 = array.Length <= i + 4;
								if (flag6)
								{
									throw new ArgumentException(string.Join(" ", array, i, array.Length - i));
								}
								stack.Push(FileSelector.ParseState.OpenParen);
							}
						}
						else if (num != 1361572173U)
						{
							if (num != 1563699588U)
							{
								goto IL_9B3;
							}
							if (!(text2 == "or"))
							{
								goto IL_9B3;
							}
							goto IL_33D;
						}
						else
						{
							if (!(text2 == "type"))
							{
								goto IL_9B3;
							}
							goto IL_8DA;
						}
					}
					else if (num <= 2746858573U)
					{
						if (num <= 2211460629U)
						{
							if (num != 2166136261U)
							{
								if (num != 2211460629U)
								{
									goto IL_9B3;
								}
								if (!(text2 == "length"))
								{
									goto IL_9B3;
								}
								goto IL_5D6;
							}
							else
							{
								if (text2 == null || text2.Length != 0)
								{
									goto IL_9B3;
								}
								stack.Push(FileSelector.ParseState.Whitespace);
							}
						}
						else if (num != 2369371622U)
						{
							if (num != 2746858573U)
							{
								goto IL_9B3;
							}
							if (!(text2 == "atime"))
							{
								goto IL_9B3;
							}
							goto IL_4AC;
						}
						else
						{
							if (!(text2 == "name"))
							{
								goto IL_9B3;
							}
							goto IL_7E8;
						}
					}
					else if (num <= 3429620606U)
					{
						if (num != 2888110417U)
						{
							if (num != 3429620606U)
							{
								goto IL_9B3;
							}
							if (!(text2 == "xor"))
							{
								goto IL_9B3;
							}
							goto IL_33D;
						}
						else
						{
							if (!(text2 == "mtime"))
							{
								goto IL_9B3;
							}
							goto IL_4AC;
						}
					}
					else if (num != 3791641492U)
					{
						if (num != 4191246291U)
						{
							goto IL_9B3;
						}
						if (!(text2 == "attrs"))
						{
							goto IL_9B3;
						}
						goto IL_8DA;
					}
					else
					{
						if (!(text2 == "attributes"))
						{
							goto IL_9B3;
						}
						goto IL_8DA;
					}
					IL_9CC:
					parseState = stack.Peek();
					bool flag7 = parseState == FileSelector.ParseState.CriterionDone;
					if (flag7)
					{
						stack.Pop();
						bool flag8 = stack.Peek() == FileSelector.ParseState.ConjunctionPending;
						if (flag8)
						{
							while (stack.Peek() == FileSelector.ParseState.ConjunctionPending)
							{
								CompoundCriterion compoundCriterion = stack2.Pop() as CompoundCriterion;
								compoundCriterion.Right = selectionCriterion;
								selectionCriterion = compoundCriterion;
								stack.Pop();
								parseState = stack.Pop();
								bool flag9 = parseState != FileSelector.ParseState.CriterionDone;
								if (flag9)
								{
									throw new ArgumentException("??");
								}
							}
						}
						else
						{
							stack.Push(FileSelector.ParseState.CriterionDone);
						}
					}
					bool flag10 = parseState == FileSelector.ParseState.Whitespace;
					if (flag10)
					{
						stack.Pop();
					}
					i++;
					continue;
					IL_33D:
					parseState = stack.Peek();
					bool flag11 = parseState != FileSelector.ParseState.CriterionDone;
					if (flag11)
					{
						throw new ArgumentException(string.Join(" ", array, i, array.Length - i));
					}
					bool flag12 = array.Length <= i + 3;
					if (flag12)
					{
						throw new ArgumentException(string.Join(" ", array, i, array.Length - i));
					}
					LogicalConjunction conjunction = (LogicalConjunction)Enum.Parse(typeof(LogicalConjunction), array[i].ToUpper(), true);
					selectionCriterion = new CompoundCriterion
					{
						Left = selectionCriterion,
						Right = null,
						Conjunction = conjunction
					};
					stack.Push(parseState);
					stack.Push(FileSelector.ParseState.ConjunctionPending);
					stack2.Push(selectionCriterion);
					goto IL_9CC;
					IL_4AC:
					bool flag13 = array.Length <= i + 2;
					if (flag13)
					{
						throw new ArgumentException(string.Join(" ", array, i, array.Length - i));
					}
					DateTime dateTime;
					try
					{
						dateTime = DateTime.ParseExact(array[i + 2], "yyyy-MM-dd-HH:mm:ss", null);
					}
					catch (FormatException)
					{
						try
						{
							dateTime = DateTime.ParseExact(array[i + 2], "yyyy/MM/dd-HH:mm:ss", null);
						}
						catch (FormatException)
						{
							try
							{
								dateTime = DateTime.ParseExact(array[i + 2], "yyyy/MM/dd", null);
							}
							catch (FormatException)
							{
								try
								{
									dateTime = DateTime.ParseExact(array[i + 2], "MM/dd/yyyy", null);
								}
								catch (FormatException)
								{
									dateTime = DateTime.ParseExact(array[i + 2], "yyyy-MM-dd", null);
								}
							}
						}
					}
					dateTime = DateTime.SpecifyKind(dateTime, DateTimeKind.Local).ToUniversalTime();
					selectionCriterion = new TimeCriterion
					{
						Which = (WhichTime)Enum.Parse(typeof(WhichTime), array[i], true),
						Operator = (ComparisonOperator)EnumUtil.Parse(typeof(ComparisonOperator), array[i + 1]),
						Time = dateTime
					};
					i += 2;
					stack.Push(FileSelector.ParseState.CriterionDone);
					goto IL_9CC;
					IL_5D6:
					bool flag14 = array.Length <= i + 2;
					if (flag14)
					{
						throw new ArgumentException(string.Join(" ", array, i, array.Length - i));
					}
					string text3 = array[i + 2];
					bool flag15 = text3.ToUpper().EndsWith("K");
					long size;
					if (flag15)
					{
						size = long.Parse(text3.Substring(0, text3.Length - 1)) * 1024L;
					}
					else
					{
						bool flag16 = text3.ToUpper().EndsWith("KB");
						if (flag16)
						{
							size = long.Parse(text3.Substring(0, text3.Length - 2)) * 1024L;
						}
						else
						{
							bool flag17 = text3.ToUpper().EndsWith("M");
							if (flag17)
							{
								size = long.Parse(text3.Substring(0, text3.Length - 1)) * 1024L * 1024L;
							}
							else
							{
								bool flag18 = text3.ToUpper().EndsWith("MB");
								if (flag18)
								{
									size = long.Parse(text3.Substring(0, text3.Length - 2)) * 1024L * 1024L;
								}
								else
								{
									bool flag19 = text3.ToUpper().EndsWith("G");
									if (flag19)
									{
										size = long.Parse(text3.Substring(0, text3.Length - 1)) * 1024L * 1024L * 1024L;
									}
									else
									{
										bool flag20 = text3.ToUpper().EndsWith("GB");
										if (flag20)
										{
											size = long.Parse(text3.Substring(0, text3.Length - 2)) * 1024L * 1024L * 1024L;
										}
										else
										{
											size = long.Parse(array[i + 2]);
										}
									}
								}
							}
						}
					}
					selectionCriterion = new SizeCriterion
					{
						Size = size,
						Operator = (ComparisonOperator)EnumUtil.Parse(typeof(ComparisonOperator), array[i + 1])
					};
					i += 2;
					stack.Push(FileSelector.ParseState.CriterionDone);
					goto IL_9CC;
					IL_7E8:
					bool flag21 = array.Length <= i + 2;
					if (flag21)
					{
						throw new ArgumentException(string.Join(" ", array, i, array.Length - i));
					}
					ComparisonOperator comparisonOperator = (ComparisonOperator)EnumUtil.Parse(typeof(ComparisonOperator), array[i + 1]);
					bool flag22 = comparisonOperator != ComparisonOperator.NotEqualTo && comparisonOperator != ComparisonOperator.EqualTo;
					if (flag22)
					{
						throw new ArgumentException(string.Join(" ", array, i, array.Length - i));
					}
					string text4 = array[i + 2];
					bool flag23 = text4.StartsWith("'") && text4.EndsWith("'");
					if (flag23)
					{
						text4 = text4.Substring(1, text4.Length - 2).Replace("\u0006", " ");
					}
					selectionCriterion = new NameCriterion
					{
						MatchingFileSpec = text4,
						Operator = comparisonOperator
					};
					i += 2;
					stack.Push(FileSelector.ParseState.CriterionDone);
					goto IL_9CC;
					IL_8DA:
					bool flag24 = array.Length <= i + 2;
					if (flag24)
					{
						throw new ArgumentException(string.Join(" ", array, i, array.Length - i));
					}
					ComparisonOperator comparisonOperator2 = (ComparisonOperator)EnumUtil.Parse(typeof(ComparisonOperator), array[i + 1]);
					bool flag25 = comparisonOperator2 != ComparisonOperator.NotEqualTo && comparisonOperator2 != ComparisonOperator.EqualTo;
					if (flag25)
					{
						throw new ArgumentException(string.Join(" ", array, i, array.Length - i));
					}
					SelectionCriterion selectionCriterion2;
					if (!(text == "type"))
					{
						AttributesCriterion attributesCriterion = new AttributesCriterion();
						attributesCriterion.AttributeString = array[i + 2];
						selectionCriterion2 = attributesCriterion;
						attributesCriterion.Operator = comparisonOperator2;
					}
					else
					{
						TypeCriterion typeCriterion = new TypeCriterion();
						typeCriterion.AttributeString = array[i + 2];
						selectionCriterion2 = typeCriterion;
						typeCriterion.Operator = comparisonOperator2;
					}
					selectionCriterion = selectionCriterion2;
					i += 2;
					stack.Push(FileSelector.ParseState.CriterionDone);
					goto IL_9CC;
					IL_9B3:
					throw new ArgumentException("'" + array[i] + "'");
				}
				result = selectionCriterion;
			}
			return result;
		}

		public override string ToString()
		{
			return "FileSelector(" + this._Criterion.ToString() + ")";
		}

		private bool Evaluate(string filename)
		{
			return this._Criterion.Evaluate(filename);
		}

		[Conditional("SelectorTrace")]
		private void SelectorTrace(string format, params object[] args)
		{
			bool flag = this._Criterion != null && this._Criterion.Verbose;
			if (flag)
			{
				Console.WriteLine(format, args);
			}
		}

		public ICollection<string> SelectFiles(string directory)
		{
			return this.SelectFiles(directory, false);
		}

		public ReadOnlyCollection<string> SelectFiles(string directory, bool recurseDirectories)
		{
			bool flag = this._Criterion == null;
			if (flag)
			{
				throw new ArgumentException("SelectionCriteria has not been set");
			}
			List<string> list = new List<string>();
			try
			{
				bool flag2 = Directory.Exists(directory);
				if (flag2)
				{
					string[] files = Directory.GetFiles(directory);
					foreach (string text in files)
					{
						bool flag3 = this.Evaluate(text);
						if (flag3)
						{
							list.Add(text);
						}
					}
					if (recurseDirectories)
					{
						string[] directories = Directory.GetDirectories(directory);
						foreach (string text2 in directories)
						{
							bool flag4 = this.TraverseReparsePoints || (File.GetAttributes(text2) & FileAttributes.ReparsePoint) == (FileAttributes)0;
							if (flag4)
							{
								bool flag5 = this.Evaluate(text2);
								if (flag5)
								{
									list.Add(text2);
								}
								list.AddRange(this.SelectFiles(text2, recurseDirectories));
							}
						}
					}
				}
			}
			catch (UnauthorizedAccessException)
			{
			}
			catch (IOException)
			{
			}
			return list.AsReadOnly();
		}

		private bool Evaluate(ZipEntry entry)
		{
			return this._Criterion.Evaluate(entry);
		}

		public ICollection<ZipEntry> SelectEntries(ZipFile zip)
		{
			bool flag = zip == null;
			if (flag)
			{
				throw new ArgumentNullException("zip");
			}
			List<ZipEntry> list = new List<ZipEntry>();
			foreach (ZipEntry zipEntry in zip)
			{
				bool flag2 = this.Evaluate(zipEntry);
				if (flag2)
				{
					list.Add(zipEntry);
				}
			}
			return list;
		}

		public ICollection<ZipEntry> SelectEntries(ZipFile zip, string directoryPathInArchive)
		{
			bool flag = zip == null;
			if (flag)
			{
				throw new ArgumentNullException("zip");
			}
			List<ZipEntry> list = new List<ZipEntry>();
			string text = (directoryPathInArchive == null) ? null : directoryPathInArchive.Replace("/", "\\");
			bool flag2 = text != null;
			if (flag2)
			{
				while (text.EndsWith("\\"))
				{
					text = text.Substring(0, text.Length - 1);
				}
			}
			foreach (ZipEntry zipEntry in zip)
			{
				bool flag3 = directoryPathInArchive == null || Path.GetDirectoryName(zipEntry.FileName) == directoryPathInArchive || Path.GetDirectoryName(zipEntry.FileName) == text;
				if (flag3)
				{
					bool flag4 = this.Evaluate(zipEntry);
					if (flag4)
					{
						list.Add(zipEntry);
					}
				}
			}
			return list;
		}

		internal SelectionCriterion _Criterion;

		private enum ParseState
		{
			Start,
			OpenParen,
			CriterionDone,
			ConjunctionPending,
			Whitespace
		}

		private static class RegexAssertions
		{
			public static readonly string PrecededByOddNumberOfSingleQuotes = "(?<=(?:[^']*'[^']*')*'[^']*)";

			public static readonly string FollowedByOddNumberOfSingleQuotesAndLineEnd = "(?=[^']*'(?:[^']*'[^']*')*[^']*$)";

			public static readonly string PrecededByEvenNumberOfSingleQuotes = "(?<=(?:[^']*'[^']*')*[^']*)";

			public static readonly string FollowedByEvenNumberOfSingleQuotesAndLineEnd = "(?=(?:[^']*'[^']*')*[^']*$)";
		}
	}
}
