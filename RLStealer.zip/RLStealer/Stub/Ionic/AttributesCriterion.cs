﻿using System;
using System.IO;
using System.Text;
using Ionic.Zip;

namespace Ionic
{
	internal class AttributesCriterion : SelectionCriterion
	{
		internal string AttributeString
		{
			get
			{
				string text = "";
				bool flag = (this._Attributes & FileAttributes.Hidden) > (FileAttributes)0;
				if (flag)
				{
					text += "H";
				}
				bool flag2 = (this._Attributes & FileAttributes.System) > (FileAttributes)0;
				if (flag2)
				{
					text += "S";
				}
				bool flag3 = (this._Attributes & FileAttributes.ReadOnly) > (FileAttributes)0;
				if (flag3)
				{
					text += "R";
				}
				bool flag4 = (this._Attributes & FileAttributes.Archive) > (FileAttributes)0;
				if (flag4)
				{
					text += "A";
				}
				bool flag5 = (this._Attributes & FileAttributes.ReparsePoint) > (FileAttributes)0;
				if (flag5)
				{
					text += "L";
				}
				bool flag6 = (this._Attributes & FileAttributes.NotContentIndexed) > (FileAttributes)0;
				if (flag6)
				{
					text += "I";
				}
				return text;
			}
			set
			{
				this._Attributes = FileAttributes.Normal;
				string text = value.ToUpper();
				int i = 0;
				while (i < text.Length)
				{
					char c = text[i];
					char c2 = c;
					if (c2 <= 'L')
					{
						if (c2 != 'A')
						{
							switch (c2)
							{
							case 'H':
							{
								bool flag = (this._Attributes & FileAttributes.Hidden) > (FileAttributes)0;
								if (flag)
								{
									throw new ArgumentException(string.Format("Repeated flag. ({0})", c), "value");
								}
								this._Attributes |= FileAttributes.Hidden;
								break;
							}
							case 'I':
							{
								bool flag2 = (this._Attributes & FileAttributes.NotContentIndexed) > (FileAttributes)0;
								if (flag2)
								{
									throw new ArgumentException(string.Format("Repeated flag. ({0})", c), "value");
								}
								this._Attributes |= FileAttributes.NotContentIndexed;
								break;
							}
							case 'J':
							case 'K':
								throw new ArgumentException(string.Format("Repeated flag. ({0})", c), "value");
							case 'L':
							{
								bool flag3 = (this._Attributes & FileAttributes.ReparsePoint) > (FileAttributes)0;
								if (flag3)
								{
									throw new ArgumentException(string.Format("Repeated flag. ({0})", c), "value");
								}
								this._Attributes |= FileAttributes.ReparsePoint;
								break;
							}
							default:
								throw new ArgumentException(string.Format("Repeated flag. ({0})", c), "value");
							}
						}
						else
						{
							bool flag4 = (this._Attributes & FileAttributes.Archive) > (FileAttributes)0;
							if (flag4)
							{
								throw new ArgumentException(string.Format("Repeated flag. ({0})", c), "value");
							}
							this._Attributes |= FileAttributes.Archive;
						}
					}
					else if (c2 != 'R')
					{
						if (c2 != 'S')
						{
							throw new ArgumentException(value);
						}
						bool flag5 = (this._Attributes & FileAttributes.System) > (FileAttributes)0;
						if (flag5)
						{
							throw new ArgumentException(string.Format("Repeated flag. ({0})", c), "value");
						}
						this._Attributes |= FileAttributes.System;
					}
					else
					{
						bool flag6 = (this._Attributes & FileAttributes.ReadOnly) > (FileAttributes)0;
						if (flag6)
						{
							throw new ArgumentException(string.Format("Repeated flag. ({0})", c), "value");
						}
						this._Attributes |= FileAttributes.ReadOnly;
					}
					i++;
					continue;
				}
			}
		}
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("attributes ").Append(EnumUtil.GetDescription(this.Operator)).Append(" ").Append(this.AttributeString);
			return stringBuilder.ToString();
		}

		private bool _EvaluateOne(FileAttributes fileAttrs, FileAttributes criterionAttrs)
		{
			bool flag = (this._Attributes & criterionAttrs) == criterionAttrs;
			return !flag || (fileAttrs & criterionAttrs) == criterionAttrs;
		}

		internal override bool Evaluate(string filename)
		{
			bool flag = Directory.Exists(filename);
			bool result;
			if (flag)
			{
				result = (this.Operator != ComparisonOperator.EqualTo);
			}
			else
			{
				FileAttributes attributes = File.GetAttributes(filename);
				result = this._Evaluate(attributes);
			}
			return result;
		}

		private bool _Evaluate(FileAttributes fileAttrs)
		{
			bool flag = this._EvaluateOne(fileAttrs, FileAttributes.Hidden);
			bool flag2 = flag;
			if (flag2)
			{
				flag = this._EvaluateOne(fileAttrs, FileAttributes.System);
			}
			bool flag3 = flag;
			if (flag3)
			{
				flag = this._EvaluateOne(fileAttrs, FileAttributes.ReadOnly);
			}
			bool flag4 = flag;
			if (flag4)
			{
				flag = this._EvaluateOne(fileAttrs, FileAttributes.Archive);
			}
			bool flag5 = flag;
			if (flag5)
			{
				flag = this._EvaluateOne(fileAttrs, FileAttributes.NotContentIndexed);
			}
			bool flag6 = flag;
			if (flag6)
			{
				flag = this._EvaluateOne(fileAttrs, FileAttributes.ReparsePoint);
			}
			bool flag7 = this.Operator != ComparisonOperator.EqualTo;
			if (flag7)
			{
				flag = !flag;
			}
			return flag;
		}
		internal override bool Evaluate(ZipEntry entry)
		{
			FileAttributes attributes = entry.Attributes;
			return this._Evaluate(attributes);
		}

		private FileAttributes _Attributes;
		internal ComparisonOperator Operator;
	}
}
