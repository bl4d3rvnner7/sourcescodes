﻿using System;
using System.Text;
using Ionic.Zip;

namespace Ionic
{
	internal class CompoundCriterion : SelectionCriterion
	{
		internal SelectionCriterion Right
		{
			get
			{
				return this._Right;
			}
			set
			{
				this._Right = value;
				bool flag = value == null;
				if (flag)
				{
					this.Conjunction = LogicalConjunction.NONE;
				}
				else
				{
					bool flag2 = this.Conjunction == LogicalConjunction.NONE;
					if (flag2)
					{
						this.Conjunction = LogicalConjunction.AND;
					}
				}
			}
		}

		internal override bool Evaluate(string filename)
		{
			bool flag = this.Left.Evaluate(filename);
			switch (this.Conjunction)
			{
			case LogicalConjunction.AND:
			{
				bool flag2 = flag;
				if (flag2)
				{
					flag = this.Right.Evaluate(filename);
				}
				break;
			}
			case LogicalConjunction.OR:
			{
				bool flag3 = !flag;
				if (flag3)
				{
					flag = this.Right.Evaluate(filename);
				}
				break;
			}
			case LogicalConjunction.XOR:
				flag ^= this.Right.Evaluate(filename);
				break;
			default:
				throw new ArgumentException("Conjunction");
			}
			return flag;
		}

		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("(").Append((this.Left != null) ? this.Left.ToString() : "null").Append(" ").Append(this.Conjunction.ToString()).Append(" ").Append((this.Right != null) ? this.Right.ToString() : "null").Append(")");
			return stringBuilder.ToString();
		}

		internal override bool Evaluate(ZipEntry entry)
		{
			bool flag = this.Left.Evaluate(entry);
			switch (this.Conjunction)
			{
			case LogicalConjunction.AND:
			{
				bool flag2 = flag;
				if (flag2)
				{
					flag = this.Right.Evaluate(entry);
				}
				break;
			}
			case LogicalConjunction.OR:
			{
				bool flag3 = !flag;
				if (flag3)
				{
					flag = this.Right.Evaluate(entry);
				}
				break;
			}
			case LogicalConjunction.XOR:
				flag ^= this.Right.Evaluate(entry);
				break;
			}
			return flag;
		}

		internal LogicalConjunction Conjunction;

		internal SelectionCriterion Left;

		private SelectionCriterion _Right;
	}
}
