﻿using System;

namespace Ionic.Zlib
{
	public enum FlushType
	{
		None,
		Partial,
		Sync,
		Full,
		Finish
	}
}
