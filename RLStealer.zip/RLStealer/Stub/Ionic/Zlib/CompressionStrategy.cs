﻿using System;

namespace Ionic.Zlib
{
	public enum CompressionStrategy
	{
		Default,
		Filtered,
		HuffmanOnly
	}
}
