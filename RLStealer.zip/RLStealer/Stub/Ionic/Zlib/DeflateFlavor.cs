﻿using System;

namespace Ionic.Zlib
{
	internal enum DeflateFlavor
	{
		Store,
		Fast,
		Slow
	}
}
