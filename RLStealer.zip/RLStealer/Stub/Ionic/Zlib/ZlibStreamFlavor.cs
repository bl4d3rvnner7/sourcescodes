﻿using System;

namespace Ionic.Zlib
{
	internal enum ZlibStreamFlavor
	{
		ZLIB = 1950,
		DEFLATE,
		GZIP
	}
}
