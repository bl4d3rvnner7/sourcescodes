﻿using System;

namespace Ionic.Zlib
{
	public enum CompressionMode
	{
		Compress,
		Decompress
	}
}
