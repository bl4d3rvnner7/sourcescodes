﻿using System;

namespace Ionic
{
	internal enum WhichTime
	{
		atime,
		mtime,
		ctime
	}
}
