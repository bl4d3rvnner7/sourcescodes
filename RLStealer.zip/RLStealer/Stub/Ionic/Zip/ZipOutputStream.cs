﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Ionic.Crc;
using Ionic.Zlib;

namespace Ionic.Zip
{
	public class ZipOutputStream : Stream
	{
		public ZipOutputStream(Stream stream) : this(stream, false)
		{
		}

		public ZipOutputStream(string fileName)
		{
			this._alternateEncodingUsage = ZipOption.Default;
			this._alternateEncoding = Encoding.GetEncoding("IBM437");
			this._maxBufferPairs = 16;
			base..ctor();
			Stream stream = File.Open(fileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None);
			this._Init(stream, false, fileName);
		}

		public ZipOutputStream(Stream stream, bool leaveOpen)
		{
			this._alternateEncodingUsage = ZipOption.Default;
			this._alternateEncoding = Encoding.GetEncoding("IBM437");
			this._maxBufferPairs = 16;
			base..ctor();
			this._Init(stream, leaveOpen, null);
		}

		private void _Init(Stream stream, bool leaveOpen, string name)
		{
			this._outputStream = (stream.CanRead ? stream : new CountingStream(stream));
			this.CompressionLevel = CompressionLevel.Default;
			this.CompressionMethod = CompressionMethod.Deflate;
			this._encryption = EncryptionAlgorithm.None;
			this._entriesWritten = new Dictionary<string, ZipEntry>(StringComparer.Ordinal);
			this._zip64 = Zip64Option.Default;
			this._leaveUnderlyingStreamOpen = leaveOpen;
			this.Strategy = CompressionStrategy.Default;
			this._name = (name ?? "(stream)");
			this.ParallelDeflateThreshold = -1L;
		}

		public override string ToString()
		{
			return string.Format("ZipOutputStream::{0}(leaveOpen({1})))", this._name, this._leaveUnderlyingStreamOpen);
		}

		public string Password
		{
			set
			{
				bool disposed = this._disposed;
				if (disposed)
				{
					this._exceptionPending = true;
					throw new InvalidOperationException("The stream has been closed.");
				}
				this._password = value;
				bool flag = this._password == null;
				if (flag)
				{
					this._encryption = EncryptionAlgorithm.None;
				}
				else
				{
					bool flag2 = this._encryption == EncryptionAlgorithm.None;
					if (flag2)
					{
						this._encryption = EncryptionAlgorithm.PkzipWeak;
					}
				}
			}
		}

		public EncryptionAlgorithm Encryption
		{
			get
			{
				return this._encryption;
			}
			set
			{
				bool disposed = this._disposed;
				if (disposed)
				{
					this._exceptionPending = true;
					throw new InvalidOperationException("The stream has been closed.");
				}
				bool flag = value == EncryptionAlgorithm.Unsupported;
				if (flag)
				{
					this._exceptionPending = true;
					throw new InvalidOperationException("You may not set Encryption to that value.");
				}
				this._encryption = value;
			}
		}

		public int CodecBufferSize { get; set; }

		public CompressionStrategy Strategy { get; set; }

		public ZipEntryTimestamp Timestamp
		{
			get
			{
				return this._timestamp;
			}
			set
			{
				bool disposed = this._disposed;
				if (disposed)
				{
					this._exceptionPending = true;
					throw new InvalidOperationException("The stream has been closed.");
				}
				this._timestamp = value;
			}
		}

		public CompressionLevel CompressionLevel { get; set; }

		public CompressionMethod CompressionMethod { get; set; }

		public string Comment
		{
			get
			{
				return this._comment;
			}
			set
			{
				bool disposed = this._disposed;
				if (disposed)
				{
					this._exceptionPending = true;
					throw new InvalidOperationException("The stream has been closed.");
				}
				this._comment = value;
			}
		}

		public Zip64Option EnableZip64
		{
			get
			{
				return this._zip64;
			}
			set
			{
				bool disposed = this._disposed;
				if (disposed)
				{
					this._exceptionPending = true;
					throw new InvalidOperationException("The stream has been closed.");
				}
				this._zip64 = value;
			}
		}

		public bool OutputUsedZip64
		{
			get
			{
				return this._anyEntriesUsedZip64 || this._directoryNeededZip64;
			}
		}

		public bool IgnoreCase
		{
			get
			{
				return !this._DontIgnoreCase;
			}
			set
			{
				this._DontIgnoreCase = !value;
			}
		}

		[Obsolete("Beginning with v1.9.1.6 of DotNetZip, this property is obsolete. It will be removed in a future version of the library. Use AlternateEncoding and AlternateEncodingUsage instead.")]
		public bool UseUnicodeAsNecessary
		{
			get
			{
				return this._alternateEncoding == Encoding.UTF8 && this.AlternateEncodingUsage == ZipOption.AsNecessary;
			}
			set
			{
				if (value)
				{
					this._alternateEncoding = Encoding.UTF8;
					this._alternateEncodingUsage = ZipOption.AsNecessary;
				}
				else
				{
					this._alternateEncoding = ZipOutputStream.DefaultEncoding;
					this._alternateEncodingUsage = ZipOption.Default;
				}
			}
		}

		[Obsolete("use AlternateEncoding and AlternateEncodingUsage instead.")]
		public Encoding ProvisionalAlternateEncoding
		{
			get
			{
				bool flag = this._alternateEncodingUsage == ZipOption.AsNecessary;
				Encoding result;
				if (flag)
				{
					result = this._alternateEncoding;
				}
				else
				{
					result = null;
				}
				return result;
			}
			set
			{
				this._alternateEncoding = value;
				this._alternateEncodingUsage = ZipOption.AsNecessary;
			}
		}

		public Encoding AlternateEncoding
		{
			get
			{
				return this._alternateEncoding;
			}
			set
			{
				this._alternateEncoding = value;
			}
		}

		public ZipOption AlternateEncodingUsage
		{
			get
			{
				return this._alternateEncodingUsage;
			}
			set
			{
				this._alternateEncodingUsage = value;
			}
		}

		public static Encoding DefaultEncoding
		{
			get
			{
				return Encoding.GetEncoding("IBM437");
			}
		}

		public long ParallelDeflateThreshold
		{
			get
			{
				return this._ParallelDeflateThreshold;
			}
			set
			{
				bool flag = value != 0L && value != -1L && value < 65536L;
				if (flag)
				{
					throw new ArgumentOutOfRangeException("value must be greater than 64k, or 0, or -1");
				}
				this._ParallelDeflateThreshold = value;
			}
		}

		public int ParallelDeflateMaxBufferPairs
		{
			get
			{
				return this._maxBufferPairs;
			}
			set
			{
				bool flag = value < 4;
				if (flag)
				{
					throw new ArgumentOutOfRangeException("ParallelDeflateMaxBufferPairs", "Value must be 4 or greater.");
				}
				this._maxBufferPairs = value;
			}
		}

		private void InsureUniqueEntry(ZipEntry ze1)
		{
			bool flag = this._entriesWritten.ContainsKey(ze1.FileName);
			if (flag)
			{
				this._exceptionPending = true;
				throw new ArgumentException(string.Format("The entry '{0}' already exists in the zip archive.", ze1.FileName));
			}
		}

		internal Stream OutputStream
		{
			get
			{
				return this._outputStream;
			}
		}

		internal string Name
		{
			get
			{
				return this._name;
			}
		}

		public bool ContainsEntry(string name)
		{
			return this._entriesWritten.ContainsKey(SharedUtilities.NormalizePathForUseInZipFile(name));
		}

		public override void Write(byte[] buffer, int offset, int count)
		{
			bool disposed = this._disposed;
			if (disposed)
			{
				this._exceptionPending = true;
				throw new InvalidOperationException("The stream has been closed.");
			}
			bool flag = buffer == null;
			if (flag)
			{
				this._exceptionPending = true;
				throw new ArgumentNullException("buffer");
			}
			bool flag2 = this._currentEntry == null;
			if (flag2)
			{
				this._exceptionPending = true;
				throw new InvalidOperationException("You must call PutNextEntry() before calling Write().");
			}
			bool isDirectory = this._currentEntry.IsDirectory;
			if (isDirectory)
			{
				this._exceptionPending = true;
				throw new InvalidOperationException("You cannot Write() data for an entry that is a directory.");
			}
			bool needToWriteEntryHeader = this._needToWriteEntryHeader;
			if (needToWriteEntryHeader)
			{
				this._InitiateCurrentEntry(false);
			}
			bool flag3 = count != 0;
			if (flag3)
			{
				this._entryOutputStream.Write(buffer, offset, count);
			}
		}

		public ZipEntry PutNextEntry(string entryName)
		{
			bool flag = string.IsNullOrEmpty(entryName);
			if (flag)
			{
				throw new ArgumentNullException("entryName");
			}
			bool disposed = this._disposed;
			if (disposed)
			{
				this._exceptionPending = true;
				throw new InvalidOperationException("The stream has been closed.");
			}
			this._FinishCurrentEntry();
			this._currentEntry = ZipEntry.CreateForZipOutputStream(entryName);
			this._currentEntry._container = new ZipContainer(this);
			ZipEntry currentEntry = this._currentEntry;
			currentEntry._BitField |= 8;
			this._currentEntry.SetEntryTimes(DateTime.Now, DateTime.Now, DateTime.Now);
			this._currentEntry.CompressionLevel = this.CompressionLevel;
			this._currentEntry.CompressionMethod = this.CompressionMethod;
			this._currentEntry.Password = this._password;
			this._currentEntry.Encryption = this.Encryption;
			this._currentEntry.AlternateEncoding = this.AlternateEncoding;
			this._currentEntry.AlternateEncodingUsage = this.AlternateEncodingUsage;
			bool flag2 = entryName.EndsWith("/");
			if (flag2)
			{
				this._currentEntry.MarkAsDirectory();
			}
			this._currentEntry.EmitTimesInWindowsFormatWhenSaving = ((this._timestamp & ZipEntryTimestamp.Windows) > ZipEntryTimestamp.None);
			this._currentEntry.EmitTimesInUnixFormatWhenSaving = ((this._timestamp & ZipEntryTimestamp.Unix) > ZipEntryTimestamp.None);
			this.InsureUniqueEntry(this._currentEntry);
			this._needToWriteEntryHeader = true;
			return this._currentEntry;
		}

		private void _InitiateCurrentEntry(bool finishing)
		{
			this._entriesWritten.Add(this._currentEntry.FileName, this._currentEntry);
			this._entryCount++;
			bool flag = this._entryCount > 65534 && this._zip64 == Zip64Option.Default;
			if (flag)
			{
				this._exceptionPending = true;
				throw new InvalidOperationException("Too many entries. Consider setting ZipOutputStream.EnableZip64.");
			}
			this._currentEntry.WriteHeader(this._outputStream, finishing ? 99 : 0);
			this._currentEntry.StoreRelativeOffset();
			bool flag2 = !this._currentEntry.IsDirectory;
			if (flag2)
			{
				this._currentEntry.WriteSecurityMetadata(this._outputStream);
				this._currentEntry.PrepOutputStream(this._outputStream, finishing ? 0L : -1L, out this._outputCounter, out this._encryptor, out this._deflater, out this._entryOutputStream);
			}
			this._needToWriteEntryHeader = false;
		}

		private void _FinishCurrentEntry()
		{
			bool flag = this._currentEntry != null;
			if (flag)
			{
				bool needToWriteEntryHeader = this._needToWriteEntryHeader;
				if (needToWriteEntryHeader)
				{
					this._InitiateCurrentEntry(true);
				}
				this._currentEntry.FinishOutputStream(this._outputStream, this._outputCounter, this._encryptor, this._deflater, this._entryOutputStream);
				this._currentEntry.PostProcessOutput(this._outputStream);
				bool flag2 = this._currentEntry.OutputUsedZip64 != null;
				if (flag2)
				{
					this._anyEntriesUsedZip64 |= this._currentEntry.OutputUsedZip64.Value;
				}
				this._outputCounter = null;
				this._encryptor = (this._deflater = null);
				this._entryOutputStream = null;
			}
		}

		protected override void Dispose(bool disposing)
		{
			bool disposed = this._disposed;
			if (!disposed)
			{
				if (disposing)
				{
					bool flag = !this._exceptionPending;
					if (flag)
					{
						this._FinishCurrentEntry();
						this._directoryNeededZip64 = ZipOutput.WriteCentralDirectoryStructure(this._outputStream, this._entriesWritten.Values, 1U, this._zip64, this.Comment, new ZipContainer(this));
						CountingStream countingStream = this._outputStream as CountingStream;
						bool flag2 = countingStream != null;
						Stream stream;
						if (flag2)
						{
							stream = countingStream.WrappedStream;
							countingStream.Dispose();
						}
						else
						{
							stream = this._outputStream;
						}
						bool flag3 = !this._leaveUnderlyingStreamOpen;
						if (flag3)
						{
							stream.Dispose();
						}
						this._outputStream = null;
					}
				}
				this._disposed = true;
			}
		}

		public override bool CanRead
		{
			get
			{
				return false;
			}
		}

		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		public override bool CanWrite
		{
			get
			{
				return true;
			}
		}

		public override long Length
		{
			get
			{
				throw new NotSupportedException();
			}
		}

		public override long Position
		{
			get
			{
				return this._outputStream.Position;
			}
			set
			{
				throw new NotSupportedException();
			}
		}

		public override void Flush()
		{
		}

		public override int Read(byte[] buffer, int offset, int count)
		{
			throw new NotSupportedException("Read");
		}

		public override long Seek(long offset, SeekOrigin origin)
		{
			throw new NotSupportedException("Seek");
		}

		public override void SetLength(long value)
		{
			throw new NotSupportedException();
		}

		private EncryptionAlgorithm _encryption;

		private ZipEntryTimestamp _timestamp;

		internal string _password;

		private string _comment;

		private Stream _outputStream;

		private ZipEntry _currentEntry;

		internal Zip64Option _zip64;

		private Dictionary<string, ZipEntry> _entriesWritten;

		private int _entryCount;

		private ZipOption _alternateEncodingUsage;

		private Encoding _alternateEncoding;

		private bool _leaveUnderlyingStreamOpen;

		private bool _disposed;

		private bool _exceptionPending;

		private bool _anyEntriesUsedZip64;

		private bool _directoryNeededZip64;

		private CountingStream _outputCounter;

		private Stream _encryptor;

		private Stream _deflater;

		private CrcCalculatorStream _entryOutputStream;

		private bool _needToWriteEntryHeader;

		private string _name;

		private bool _DontIgnoreCase;

		internal ParallelDeflateOutputStream ParallelDeflater;

		private long _ParallelDeflateThreshold;

		private int _maxBufferPairs;
	}
}
