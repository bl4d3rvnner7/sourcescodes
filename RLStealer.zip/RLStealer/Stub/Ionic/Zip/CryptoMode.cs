﻿using System;

namespace Ionic.Zip
{
	internal enum CryptoMode
	{
		Encrypt,
		Decrypt
	}
}
