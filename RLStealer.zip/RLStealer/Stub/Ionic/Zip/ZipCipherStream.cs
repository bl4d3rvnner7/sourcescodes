﻿using System;
using System.IO;

namespace Ionic.Zip
{
	internal class ZipCipherStream : Stream
	{
		public ZipCipherStream(Stream s, ZipCrypto cipher, CryptoMode mode)
		{
			this._cipher = cipher;
			this._s = s;
			this._mode = mode;
		}

		public override int Read(byte[] buffer, int offset, int count)
		{
			bool flag = this._mode == CryptoMode.Encrypt;
			if (flag)
			{
				throw new NotSupportedException("This stream does not encrypt via Read()");
			}
			bool flag2 = buffer == null;
			if (flag2)
			{
				throw new ArgumentNullException("buffer");
			}
			byte[] array = new byte[count];
			int num = this._s.Read(array, 0, count);
			byte[] array2 = this._cipher.DecryptMessage(array, num);
			for (int i = 0; i < num; i++)
			{
				buffer[offset + i] = array2[i];
			}
			return num;
		}

		public override void Write(byte[] buffer, int offset, int count)
		{
			bool flag = this._mode == CryptoMode.Decrypt;
			if (flag)
			{
				throw new NotSupportedException("This stream does not Decrypt via Write()");
			}
			bool flag2 = buffer == null;
			if (flag2)
			{
				throw new ArgumentNullException("buffer");
			}
			bool flag3 = count == 0;
			if (!flag3)
			{
				bool flag4 = offset != 0;
				byte[] array;
				if (flag4)
				{
					array = new byte[count];
					for (int i = 0; i < count; i++)
					{
						array[i] = buffer[offset + i];
					}
				}
				else
				{
					array = buffer;
				}
				byte[] array2 = this._cipher.EncryptMessage(array, count);
				this._s.Write(array2, 0, array2.Length);
			}
		}

		public override bool CanRead
		{
			get
			{
				return this._mode == CryptoMode.Decrypt;
			}
		}

		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		public override bool CanWrite
		{
			get
			{
				return this._mode == CryptoMode.Encrypt;
			}
		}

		public override void Flush()
		{
		}

		public override long Length
		{
			get
			{
				throw new NotSupportedException();
			}
		}

		public override long Position
		{
			get
			{
				throw new NotSupportedException();
			}
			set
			{
				throw new NotSupportedException();
			}
		}

		public override long Seek(long offset, SeekOrigin origin)
		{
			throw new NotSupportedException();
		}

		public override void SetLength(long value)
		{
			throw new NotSupportedException();
		}

		private ZipCrypto _cipher;

		private Stream _s;

		private CryptoMode _mode;
	}
}
