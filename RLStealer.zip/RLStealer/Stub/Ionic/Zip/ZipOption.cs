﻿using System;

namespace Ionic.Zip
{
	public enum ZipOption
	{
		Default,
		Never = 0,
		AsNecessary,
		Always
	}
}
