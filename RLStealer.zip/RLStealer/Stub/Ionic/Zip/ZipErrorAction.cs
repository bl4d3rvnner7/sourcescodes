﻿using System;

namespace Ionic.Zip
{
	public enum ZipErrorAction
	{
		Throw,
		Skip,
		Retry,
		InvokeErrorEvent
	}
}
