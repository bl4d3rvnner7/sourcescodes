﻿using System;

namespace Ionic.Zip
{
	internal enum AddOrUpdateAction
	{
		AddOnly,
		AddOrUpdate
	}
}
