﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Ionic.Crc;
using Ionic.Zlib;

namespace Ionic.Zip
{
	[Guid("ebc25cf6-9120-4283-b972-0e5520d00004")]
	[ComVisible(true)]
	[ClassInterface(ClassInterfaceType.AutoDispatch)]
	public class ZipEntry
	{
		internal bool AttributesIndicateDirectory
		{
			get
			{
				return this._InternalFileAttrs == 0 && (this._ExternalFileAttrs & 16) == 16;
			}
		}

		internal void ResetDirEntry()
		{
			this.__FileDataPosition = -1L;
			this._LengthOfHeader = 0;
		}

		public string Info
		{
			get
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(string.Format("          ZipEntry: {0}\n", this.FileName)).Append(string.Format("   Version Made By: {0}\n", this._VersionMadeBy)).Append(string.Format(" Needed to extract: {0}\n", this.VersionNeeded));
				bool isDirectory = this._IsDirectory;
				if (isDirectory)
				{
					stringBuilder.Append("        Entry type: directory\n");
				}
				else
				{
					stringBuilder.Append(string.Format("         File type: {0}\n", this._IsText ? "text" : "binary")).Append(string.Format("       Compression: {0}\n", this.CompressionMethod)).Append(string.Format("        Compressed: 0x{0:X}\n", this.CompressedSize)).Append(string.Format("      Uncompressed: 0x{0:X}\n", this.UncompressedSize)).Append(string.Format("             CRC32: 0x{0:X8}\n", this._Crc32));
				}
				stringBuilder.Append(string.Format("       Disk Number: {0}\n", this._diskNumber));
				bool flag = this._RelativeOffsetOfLocalHeader > (long)((ulong)-1);
				if (flag)
				{
					stringBuilder.Append(string.Format("   Relative Offset: 0x{0:X16}\n", this._RelativeOffsetOfLocalHeader));
				}
				else
				{
					stringBuilder.Append(string.Format("   Relative Offset: 0x{0:X8}\n", this._RelativeOffsetOfLocalHeader));
				}
				stringBuilder.Append(string.Format("         Bit Field: 0x{0:X4}\n", this._BitField)).Append(string.Format("        Encrypted?: {0}\n", this._sourceIsEncrypted)).Append(string.Format("          Timeblob: 0x{0:X8}\n", this._TimeBlob)).Append(string.Format("              Time: {0}\n", SharedUtilities.PackedToDateTime(this._TimeBlob)));
				stringBuilder.Append(string.Format("         Is Zip64?: {0}\n", this._InputUsesZip64));
				bool flag2 = !string.IsNullOrEmpty(this._Comment);
				if (flag2)
				{
					stringBuilder.Append(string.Format("           Comment: {0}\n", this._Comment));
				}
				stringBuilder.Append("\n");
				return stringBuilder.ToString();
			}
		}

		internal static ZipEntry ReadDirEntry(ZipFile zf, Dictionary<string, object> previouslySeen)
		{
			Stream readStream = zf.ReadStream;
			Encoding encoding = (zf.AlternateEncodingUsage == ZipOption.Always) ? zf.AlternateEncoding : ZipFile.DefaultEncoding;
			int num = SharedUtilities.ReadSignature(readStream);
			bool flag = ZipEntry.IsNotValidZipDirEntrySig(num);
			ZipEntry result;
			if (flag)
			{
				readStream.Seek(-4L, SeekOrigin.Current);
				bool flag2 = (long)num != 101010256L && (long)num != 101075792L && num != 67324752;
				if (flag2)
				{
					throw new BadReadException(string.Format("  Bad signature (0x{0:X8}) at position 0x{1:X8}", num, readStream.Position));
				}
				result = null;
			}
			else
			{
				int num2 = 46;
				byte[] array = new byte[42];
				int num3 = readStream.Read(array, 0, array.Length);
				bool flag3 = num3 != array.Length;
				if (flag3)
				{
					result = null;
				}
				else
				{
					int num4 = 0;
					ZipEntry zipEntry = new ZipEntry();
					zipEntry.AlternateEncoding = encoding;
					zipEntry._Source = ZipEntrySource.ZipFile;
					zipEntry._container = new ZipContainer(zf);
					zipEntry._VersionMadeBy = (short)((int)array[num4++] + (int)array[num4++] * 256);
					zipEntry._VersionNeeded = (short)((int)array[num4++] + (int)array[num4++] * 256);
					zipEntry._BitField = (short)((int)array[num4++] + (int)array[num4++] * 256);
					zipEntry._CompressionMethod = (short)((int)array[num4++] + (int)array[num4++] * 256);
					zipEntry._TimeBlob = (int)array[num4++] + (int)array[num4++] * 256 + (int)array[num4++] * 256 * 256 + (int)array[num4++] * 256 * 256 * 256;
					zipEntry._LastModified = SharedUtilities.PackedToDateTime(zipEntry._TimeBlob);
					zipEntry._timestamp |= ZipEntryTimestamp.DOS;
					zipEntry._Crc32 = (int)array[num4++] + (int)array[num4++] * 256 + (int)array[num4++] * 256 * 256 + (int)array[num4++] * 256 * 256 * 256;
					zipEntry._CompressedSize = (long)((ulong)((int)array[num4++] + (int)array[num4++] * 256 + (int)array[num4++] * 256 * 256 + (int)array[num4++] * 256 * 256 * 256));
					zipEntry._UncompressedSize = (long)((ulong)((int)array[num4++] + (int)array[num4++] * 256 + (int)array[num4++] * 256 * 256 + (int)array[num4++] * 256 * 256 * 256));
					zipEntry._CompressionMethod_FromZipFile = zipEntry._CompressionMethod;
					zipEntry._filenameLength = (short)((int)array[num4++] + (int)array[num4++] * 256);
					zipEntry._extraFieldLength = (short)((int)array[num4++] + (int)array[num4++] * 256);
					zipEntry._commentLength = (short)((int)array[num4++] + (int)array[num4++] * 256);
					zipEntry._diskNumber = (uint)array[num4++] + (uint)array[num4++] * 256U;
					zipEntry._InternalFileAttrs = (short)((int)array[num4++] + (int)array[num4++] * 256);
					zipEntry._ExternalFileAttrs = (int)array[num4++] + (int)array[num4++] * 256 + (int)array[num4++] * 256 * 256 + (int)array[num4++] * 256 * 256 * 256;
					zipEntry._RelativeOffsetOfLocalHeader = (long)((ulong)((int)array[num4++] + (int)array[num4++] * 256 + (int)array[num4++] * 256 * 256 + (int)array[num4++] * 256 * 256 * 256));
					zipEntry.IsText = ((zipEntry._InternalFileAttrs & 1) == 1);
					array = new byte[(int)zipEntry._filenameLength];
					num3 = readStream.Read(array, 0, array.Length);
					num2 += num3;
					bool flag4 = (zipEntry._BitField & 2048) == 2048;
					if (flag4)
					{
						zipEntry._FileNameInArchive = SharedUtilities.Utf8StringFromBuffer(array);
					}
					else
					{
						zipEntry._FileNameInArchive = SharedUtilities.StringFromBuffer(array, encoding);
					}
					while (previouslySeen.ContainsKey(zipEntry._FileNameInArchive))
					{
						zipEntry._FileNameInArchive = ZipEntry.CopyHelper.AppendCopyToFileName(zipEntry._FileNameInArchive);
						zipEntry._metadataChanged = true;
					}
					bool attributesIndicateDirectory = zipEntry.AttributesIndicateDirectory;
					if (attributesIndicateDirectory)
					{
						zipEntry.MarkAsDirectory();
					}
					else
					{
						bool flag5 = zipEntry._FileNameInArchive.EndsWith("/");
						if (flag5)
						{
							zipEntry.MarkAsDirectory();
						}
					}
					zipEntry._CompressedFileDataSize = zipEntry._CompressedSize;
					bool flag6 = (zipEntry._BitField & 1) == 1;
					if (flag6)
					{
						zipEntry._Encryption_FromZipFile = (zipEntry._Encryption = EncryptionAlgorithm.PkzipWeak);
						zipEntry._sourceIsEncrypted = true;
					}
					bool flag7 = zipEntry._extraFieldLength > 0;
					if (flag7)
					{
						zipEntry._InputUsesZip64 = (zipEntry._CompressedSize == (long)((ulong)-1) || zipEntry._UncompressedSize == (long)((ulong)-1) || zipEntry._RelativeOffsetOfLocalHeader == (long)((ulong)-1));
						num2 += zipEntry.ProcessExtraField(readStream, zipEntry._extraFieldLength);
						zipEntry._CompressedFileDataSize = zipEntry._CompressedSize;
					}
					bool flag8 = zipEntry._Encryption == EncryptionAlgorithm.PkzipWeak;
					if (flag8)
					{
						zipEntry._CompressedFileDataSize -= 12L;
					}
					bool flag9 = (zipEntry._BitField & 8) == 8;
					if (flag9)
					{
						bool inputUsesZip = zipEntry._InputUsesZip64;
						if (inputUsesZip)
						{
							zipEntry._LengthOfTrailer += 24;
						}
						else
						{
							zipEntry._LengthOfTrailer += 16;
						}
					}
					zipEntry.AlternateEncoding = (((zipEntry._BitField & 2048) == 2048) ? Encoding.UTF8 : encoding);
					zipEntry.AlternateEncodingUsage = ZipOption.Always;
					bool flag10 = zipEntry._commentLength > 0;
					if (flag10)
					{
						array = new byte[(int)zipEntry._commentLength];
						num3 = readStream.Read(array, 0, array.Length);
						num2 += num3;
						bool flag11 = (zipEntry._BitField & 2048) == 2048;
						if (flag11)
						{
							zipEntry._Comment = SharedUtilities.Utf8StringFromBuffer(array);
						}
						else
						{
							zipEntry._Comment = SharedUtilities.StringFromBuffer(array, encoding);
						}
					}
					result = zipEntry;
				}
			}
			return result;
		}

		internal static bool IsNotValidZipDirEntrySig(int signature)
		{
			return signature != 33639248;
		}

		public ZipEntry()
		{
			this._CompressionMethod = 8;
			this._CompressionLevel = CompressionLevel.Default;
			this._Encryption = EncryptionAlgorithm.None;
			this._Source = ZipEntrySource.None;
			this.AlternateEncoding = Encoding.GetEncoding("IBM437");
			this.AlternateEncodingUsage = ZipOption.Default;
		}

		public DateTime LastModified
		{
			get
			{
				return this._LastModified.ToLocalTime();
			}
			set
			{
				this._LastModified = ((value.Kind == DateTimeKind.Unspecified) ? DateTime.SpecifyKind(value, DateTimeKind.Local) : value.ToLocalTime());
				this._Mtime = SharedUtilities.AdjustTime_Reverse(this._LastModified).ToUniversalTime();
				this._metadataChanged = true;
			}
		}

		private int BufferSize
		{
			get
			{
				return this._container.BufferSize;
			}
		}

		public DateTime ModifiedTime
		{
			get
			{
				return this._Mtime;
			}
			set
			{
				this.SetEntryTimes(this._Ctime, this._Atime, value);
			}
		}

		public DateTime AccessedTime
		{
			get
			{
				return this._Atime;
			}
			set
			{
				this.SetEntryTimes(this._Ctime, value, this._Mtime);
			}
		}

		public DateTime CreationTime
		{
			get
			{
				return this._Ctime;
			}
			set
			{
				this.SetEntryTimes(value, this._Atime, this._Mtime);
			}
		}

		public void SetEntryTimes(DateTime created, DateTime accessed, DateTime modified)
		{
			this._ntfsTimesAreSet = true;
			bool flag = created == ZipEntry._zeroHour && created.Kind == ZipEntry._zeroHour.Kind;
			if (flag)
			{
				created = ZipEntry._win32Epoch;
			}
			bool flag2 = accessed == ZipEntry._zeroHour && accessed.Kind == ZipEntry._zeroHour.Kind;
			if (flag2)
			{
				accessed = ZipEntry._win32Epoch;
			}
			bool flag3 = modified == ZipEntry._zeroHour && modified.Kind == ZipEntry._zeroHour.Kind;
			if (flag3)
			{
				modified = ZipEntry._win32Epoch;
			}
			this._Ctime = created.ToUniversalTime();
			this._Atime = accessed.ToUniversalTime();
			this._Mtime = modified.ToUniversalTime();
			this._LastModified = this._Mtime;
			bool flag4 = !this._emitUnixTimes && !this._emitNtfsTimes;
			if (flag4)
			{
				this._emitNtfsTimes = true;
			}
			this._metadataChanged = true;
		}

		public bool EmitTimesInWindowsFormatWhenSaving
		{
			get
			{
				return this._emitNtfsTimes;
			}
			set
			{
				this._emitNtfsTimes = value;
				this._metadataChanged = true;
			}
		}

		public bool EmitTimesInUnixFormatWhenSaving
		{
			get
			{
				return this._emitUnixTimes;
			}
			set
			{
				this._emitUnixTimes = value;
				this._metadataChanged = true;
			}
		}

		public ZipEntryTimestamp Timestamp
		{
			get
			{
				return this._timestamp;
			}
		}

		public FileAttributes Attributes
		{
			get
			{
				return (FileAttributes)this._ExternalFileAttrs;
			}
			set
			{
				this._ExternalFileAttrs = (int)value;
				this._VersionMadeBy = 45;
				this._metadataChanged = true;
			}
		}

		internal string LocalFileName
		{
			get
			{
				return this._LocalFileName;
			}
		}

		public string FileName
		{
			get
			{
				return this._FileNameInArchive;
			}
			set
			{
				bool flag = this._container.ZipFile == null;
				if (flag)
				{
					throw new ZipException("Cannot rename; this is not supported in ZipOutputStream/ZipInputStream.");
				}
				bool flag2 = string.IsNullOrEmpty(value);
				if (flag2)
				{
					throw new ZipException("The FileName must be non empty and non-null.");
				}
				string text = ZipEntry.NameInArchive(value, null);
				bool flag3 = this._FileNameInArchive == text;
				if (!flag3)
				{
					this._container.ZipFile.RemoveEntry(this);
					this._container.ZipFile.InternalAddEntry(text, this);
					this._FileNameInArchive = text;
					this._container.ZipFile.NotifyEntryChanged();
					this._metadataChanged = true;
				}
			}
		}

		public Stream InputStream
		{
			get
			{
				return this._sourceStream;
			}
			set
			{
				bool flag = this._Source != ZipEntrySource.Stream;
				if (flag)
				{
					throw new ZipException("You must not set the input stream for this entry.");
				}
				this._sourceWasJitProvided = true;
				this._sourceStream = value;
			}
		}

		public bool InputStreamWasJitProvided
		{
			get
			{
				return this._sourceWasJitProvided;
			}
		}

		public ZipEntrySource Source
		{
			get
			{
				return this._Source;
			}
		}

		public short VersionNeeded
		{
			get
			{
				return this._VersionNeeded;
			}
		}

		public string Comment
		{
			get
			{
				return this._Comment;
			}
			set
			{
				this._Comment = value;
				this._metadataChanged = true;
			}
		}

		public bool? RequiresZip64
		{
			get
			{
				return this._entryRequiresZip64;
			}
		}

		public bool? OutputUsedZip64
		{
			get
			{
				return this._OutputUsesZip64;
			}
		}

		public short BitField
		{
			get
			{
				return this._BitField;
			}
		}

		public CompressionMethod CompressionMethod
		{
			get
			{
				return (CompressionMethod)this._CompressionMethod;
			}
			set
			{
				bool flag = value == (CompressionMethod)this._CompressionMethod;
				if (!flag)
				{
					bool flag2 = value != CompressionMethod.None && value != CompressionMethod.Deflate;
					if (flag2)
					{
						throw new InvalidOperationException("Unsupported compression method.");
					}
					this._CompressionMethod = (short)value;
					bool flag3 = this._CompressionMethod == 0;
					if (flag3)
					{
						this._CompressionLevel = CompressionLevel.None;
					}
					else
					{
						bool flag4 = this.CompressionLevel == CompressionLevel.None;
						if (flag4)
						{
							this._CompressionLevel = CompressionLevel.Default;
						}
					}
					bool flag5 = this._container.ZipFile != null;
					if (flag5)
					{
						this._container.ZipFile.NotifyEntryChanged();
					}
					this._restreamRequiredOnSave = true;
				}
			}
		}

		public CompressionLevel CompressionLevel
		{
			get
			{
				return this._CompressionLevel;
			}
			set
			{
				bool flag = this._CompressionMethod != 8 && this._CompressionMethod != 0;
				if (!flag)
				{
					bool flag2 = value == CompressionLevel.Default && this._CompressionMethod == 8;
					if (!flag2)
					{
						this._CompressionLevel = value;
						bool flag3 = value == CompressionLevel.None && this._CompressionMethod == 0;
						if (!flag3)
						{
							bool flag4 = this._CompressionLevel == CompressionLevel.None;
							if (flag4)
							{
								this._CompressionMethod = 0;
							}
							else
							{
								this._CompressionMethod = 8;
							}
							bool flag5 = this._container.ZipFile != null;
							if (flag5)
							{
								this._container.ZipFile.NotifyEntryChanged();
							}
							this._restreamRequiredOnSave = true;
						}
					}
				}
			}
		}

		public long CompressedSize
		{
			get
			{
				return this._CompressedSize;
			}
		}

		public long UncompressedSize
		{
			get
			{
				return this._UncompressedSize;
			}
		}

		public double CompressionRatio
		{
			get
			{
				bool flag = this.UncompressedSize == 0L;
				double result;
				if (flag)
				{
					result = 0.0;
				}
				else
				{
					result = 100.0 * (1.0 - 1.0 * (double)this.CompressedSize / (1.0 * (double)this.UncompressedSize));
				}
				return result;
			}
		}

		public int Crc
		{
			get
			{
				return this._Crc32;
			}
		}

		public bool IsDirectory
		{
			get
			{
				return this._IsDirectory;
			}
		}

		public bool UsesEncryption
		{
			get
			{
				return this._Encryption_FromZipFile > EncryptionAlgorithm.None;
			}
		}

		public EncryptionAlgorithm Encryption
		{
			get
			{
				return this._Encryption;
			}
			set
			{
				bool flag = value == this._Encryption;
				if (!flag)
				{
					bool flag2 = value == EncryptionAlgorithm.Unsupported;
					if (flag2)
					{
						throw new InvalidOperationException("You may not set Encryption to that value.");
					}
					this._Encryption = value;
					this._restreamRequiredOnSave = true;
					bool flag3 = this._container.ZipFile != null;
					if (flag3)
					{
						this._container.ZipFile.NotifyEntryChanged();
					}
				}
			}
		}

		public string Password
		{
			private get
			{
				return this._Password;
			}
			set
			{
				this._Password = value;
				bool flag = this._Password == null;
				if (flag)
				{
					this._Encryption = EncryptionAlgorithm.None;
				}
				else
				{
					bool flag2 = this._Source == ZipEntrySource.ZipFile && !this._sourceIsEncrypted;
					if (flag2)
					{
						this._restreamRequiredOnSave = true;
					}
					bool flag3 = this.Encryption == EncryptionAlgorithm.None;
					if (flag3)
					{
						this._Encryption = EncryptionAlgorithm.PkzipWeak;
					}
				}
			}
		}

		internal bool IsChanged
		{
			get
			{
				return this._restreamRequiredOnSave | this._metadataChanged;
			}
		}

		public ExtractExistingFileAction ExtractExistingFile { get; set; }

		public ZipErrorAction ZipErrorAction { get; set; }

		public bool IncludedInMostRecentSave
		{
			get
			{
				return !this._skippedDuringSave;
			}
		}

		public SetCompressionCallback SetCompression { get; set; }

		[Obsolete("Beginning with v1.9.1.6 of DotNetZip, this property is obsolete.  It will be removed in a future version of the library. Your applications should  use AlternateEncoding and AlternateEncodingUsage instead.")]
		public bool UseUnicodeAsNecessary
		{
			get
			{
				return this.AlternateEncoding == Encoding.GetEncoding("UTF-8") && this.AlternateEncodingUsage == ZipOption.AsNecessary;
			}
			set
			{
				if (value)
				{
					this.AlternateEncoding = Encoding.GetEncoding("UTF-8");
					this.AlternateEncodingUsage = ZipOption.AsNecessary;
				}
				else
				{
					this.AlternateEncoding = ZipFile.DefaultEncoding;
					this.AlternateEncodingUsage = ZipOption.Default;
				}
			}
		}

		[Obsolete("This property is obsolete since v1.9.1.6. Use AlternateEncoding and AlternateEncodingUsage instead.", true)]
		public Encoding ProvisionalAlternateEncoding { get; set; }

		public Encoding AlternateEncoding { get; set; }

		public ZipOption AlternateEncodingUsage { get; set; }

		internal static string NameInArchive(string filename, string directoryPathInArchive)
		{
			bool flag = directoryPathInArchive == null;
			string pathName;
			if (flag)
			{
				pathName = filename;
			}
			else
			{
				bool flag2 = string.IsNullOrEmpty(directoryPathInArchive);
				if (flag2)
				{
					pathName = Path.GetFileName(filename);
				}
				else
				{
					pathName = Path.Combine(directoryPathInArchive, Path.GetFileName(filename));
				}
			}
			return SharedUtilities.NormalizePathForUseInZipFile(pathName);
		}

		internal static ZipEntry CreateFromNothing(string nameInArchive)
		{
			return ZipEntry.Create(nameInArchive, ZipEntrySource.None, null, null);
		}

		internal static ZipEntry CreateFromFile(string filename, string nameInArchive)
		{
			return ZipEntry.Create(nameInArchive, ZipEntrySource.FileSystem, filename, null);
		}

		internal static ZipEntry CreateForStream(string entryName, Stream s)
		{
			return ZipEntry.Create(entryName, ZipEntrySource.Stream, s, null);
		}

		internal static ZipEntry CreateForWriter(string entryName, WriteDelegate d)
		{
			return ZipEntry.Create(entryName, ZipEntrySource.WriteDelegate, d, null);
		}

		internal static ZipEntry CreateForJitStreamProvider(string nameInArchive, OpenDelegate opener, CloseDelegate closer)
		{
			return ZipEntry.Create(nameInArchive, ZipEntrySource.JitStream, opener, closer);
		}

		internal static ZipEntry CreateForZipOutputStream(string nameInArchive)
		{
			return ZipEntry.Create(nameInArchive, ZipEntrySource.ZipOutputStream, null, null);
		}

		private static ZipEntry Create(string nameInArchive, ZipEntrySource source, object arg1, object arg2)
		{
			bool flag = string.IsNullOrEmpty(nameInArchive);
			if (flag)
			{
				throw new ZipException("The entry name must be non-null and non-empty.");
			}
			ZipEntry zipEntry = new ZipEntry();
			zipEntry._VersionMadeBy = 45;
			zipEntry._Source = source;
			zipEntry._Mtime = (zipEntry._Atime = (zipEntry._Ctime = DateTime.UtcNow));
			bool flag2 = source == ZipEntrySource.Stream;
			if (flag2)
			{
				zipEntry._sourceStream = (arg1 as Stream);
			}
			else
			{
				bool flag3 = source == ZipEntrySource.WriteDelegate;
				if (flag3)
				{
					zipEntry._WriteDelegate = (arg1 as WriteDelegate);
				}
				else
				{
					bool flag4 = source == ZipEntrySource.JitStream;
					if (flag4)
					{
						zipEntry._OpenDelegate = (arg1 as OpenDelegate);
						zipEntry._CloseDelegate = (arg2 as CloseDelegate);
					}
					else
					{
						bool flag5 = source == ZipEntrySource.ZipOutputStream;
						if (!flag5)
						{
							bool flag6 = source == ZipEntrySource.None;
							if (flag6)
							{
								zipEntry._Source = ZipEntrySource.FileSystem;
							}
							else
							{
								string text = arg1 as string;
								bool flag7 = string.IsNullOrEmpty(text);
								if (flag7)
								{
									throw new ZipException("The filename must be non-null and non-empty.");
								}
								try
								{
									zipEntry._Mtime = File.GetLastWriteTime(text).ToUniversalTime();
									zipEntry._Ctime = File.GetCreationTime(text).ToUniversalTime();
									zipEntry._Atime = File.GetLastAccessTime(text).ToUniversalTime();
									bool flag8 = File.Exists(text) || Directory.Exists(text);
									if (flag8)
									{
										zipEntry._ExternalFileAttrs = (int)File.GetAttributes(text);
									}
									zipEntry._ntfsTimesAreSet = true;
									zipEntry._LocalFileName = Path.GetFullPath(text);
								}
								catch (PathTooLongException innerException)
								{
									string message = string.Format("The path is too long, filename={0}", text);
									throw new ZipException(message, innerException);
								}
							}
						}
					}
				}
			}
			zipEntry._LastModified = zipEntry._Mtime;
			zipEntry._FileNameInArchive = SharedUtilities.NormalizePathForUseInZipFile(nameInArchive);
			return zipEntry;
		}

		internal void MarkAsDirectory()
		{
			this._IsDirectory = true;
			bool flag = !this._FileNameInArchive.EndsWith("/");
			if (flag)
			{
				this._FileNameInArchive += "/";
			}
		}

		public bool IsText
		{
			get
			{
				return this._IsText;
			}
			set
			{
				this._IsText = value;
			}
		}

		public override string ToString()
		{
			return string.Format("ZipEntry::{0}", this.FileName);
		}

		internal Stream ArchiveStream
		{
			get
			{
				bool flag = this._archiveStream == null;
				if (flag)
				{
					bool flag2 = this._container.ZipFile != null;
					if (flag2)
					{
						ZipFile zipFile = this._container.ZipFile;
						zipFile.Reset(false);
						this._archiveStream = zipFile.StreamForDiskNumber(this._diskNumber);
					}
					else
					{
						this._archiveStream = this._container.ZipOutputStream.OutputStream;
					}
				}
				return this._archiveStream;
			}
		}

		private void SetFdpLoh()
		{
			long position = this.ArchiveStream.Position;
			try
			{
				this.ArchiveStream.Seek(this._RelativeOffsetOfLocalHeader, SeekOrigin.Begin);
			}
			catch (IOException innerException)
			{
				string message = string.Format("Exception seeking  entry({0}) offset(0x{1:X8}) len(0x{2:X8})", this.FileName, this._RelativeOffsetOfLocalHeader, this.ArchiveStream.Length);
				throw new BadStateException(message, innerException);
			}
			byte[] array = new byte[30];
			this.ArchiveStream.Read(array, 0, array.Length);
			short num = (short)((int)array[26] + (int)array[27] * 256);
			short num2 = (short)((int)array[28] + (int)array[29] * 256);
			this.ArchiveStream.Seek((long)(num + num2), SeekOrigin.Current);
			this._LengthOfHeader = (int)(30 + num2 + num) + ZipEntry.GetLengthOfCryptoHeaderBytes(this._Encryption_FromZipFile);
			this.__FileDataPosition = this._RelativeOffsetOfLocalHeader + (long)this._LengthOfHeader;
			this.ArchiveStream.Seek(position, SeekOrigin.Begin);
		}

		internal static int GetLengthOfCryptoHeaderBytes(EncryptionAlgorithm a)
		{
			bool flag = a == EncryptionAlgorithm.None;
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				bool flag2 = a == EncryptionAlgorithm.PkzipWeak;
				if (!flag2)
				{
					throw new ZipException("internal error");
				}
				result = 12;
			}
			return result;
		}

		internal long FileDataPosition
		{
			get
			{
				bool flag = this.__FileDataPosition == -1L;
				if (flag)
				{
					this.SetFdpLoh();
				}
				return this.__FileDataPosition;
			}
		}

		private int LengthOfHeader
		{
			get
			{
				bool flag = this._LengthOfHeader == 0;
				if (flag)
				{
					this.SetFdpLoh();
				}
				return this._LengthOfHeader;
			}
		}

		public void Extract()
		{
			this.InternalExtract(".", null, null);
		}

		public void Extract(ExtractExistingFileAction extractExistingFile)
		{
			this.ExtractExistingFile = extractExistingFile;
			this.InternalExtract(".", null, null);
		}

		public void Extract(Stream stream)
		{
			this.InternalExtract(null, stream, null);
		}

		public void Extract(string baseDirectory)
		{
			this.InternalExtract(baseDirectory, null, null);
		}

		public void Extract(string baseDirectory, ExtractExistingFileAction extractExistingFile)
		{
			this.ExtractExistingFile = extractExistingFile;
			this.InternalExtract(baseDirectory, null, null);
		}

		public void ExtractWithPassword(string password)
		{
			this.InternalExtract(".", null, password);
		}

		public void ExtractWithPassword(string baseDirectory, string password)
		{
			this.InternalExtract(baseDirectory, null, password);
		}

		public void ExtractWithPassword(ExtractExistingFileAction extractExistingFile, string password)
		{
			this.ExtractExistingFile = extractExistingFile;
			this.InternalExtract(".", null, password);
		}

		public void ExtractWithPassword(string baseDirectory, ExtractExistingFileAction extractExistingFile, string password)
		{
			this.ExtractExistingFile = extractExistingFile;
			this.InternalExtract(baseDirectory, null, password);
		}

		public void ExtractWithPassword(Stream stream, string password)
		{
			this.InternalExtract(null, stream, password);
		}

		public CrcCalculatorStream OpenReader()
		{
			bool flag = this._container.ZipFile == null;
			if (flag)
			{
				throw new InvalidOperationException("Use OpenReader() only with ZipFile.");
			}
			return this.InternalOpenReader(this._Password ?? this._container.Password);
		}

		public CrcCalculatorStream OpenReader(string password)
		{
			bool flag = this._container.ZipFile == null;
			if (flag)
			{
				throw new InvalidOperationException("Use OpenReader() only with ZipFile.");
			}
			return this.InternalOpenReader(password);
		}

		internal CrcCalculatorStream InternalOpenReader(string password)
		{
			this.ValidateCompression();
			this.ValidateEncryption();
			this.SetupCryptoForExtract(password);
			bool flag = this._Source != ZipEntrySource.ZipFile;
			if (flag)
			{
				throw new BadStateException("You must call ZipFile.Save before calling OpenReader");
			}
			long length = (this._CompressionMethod_FromZipFile == 0) ? this._CompressedFileDataSize : this.UncompressedSize;
			Stream archiveStream = this.ArchiveStream;
			this.ArchiveStream.Seek(this.FileDataPosition, SeekOrigin.Begin);
			this._inputDecryptorStream = this.GetExtractDecryptor(archiveStream);
			Stream extractDecompressor = this.GetExtractDecompressor(this._inputDecryptorStream);
			return new CrcCalculatorStream(extractDecompressor, length);
		}

		private void OnExtractProgress(long bytesWritten, long totalBytesToWrite)
		{
			bool flag = this._container.ZipFile != null;
			if (flag)
			{
				this._ioOperationCanceled = this._container.ZipFile.OnExtractBlock(this, bytesWritten, totalBytesToWrite);
			}
		}

		private void OnBeforeExtract(string path)
		{
			bool flag = this._container.ZipFile != null;
			if (flag)
			{
				bool flag2 = !this._container.ZipFile._inExtractAll;
				if (flag2)
				{
					this._ioOperationCanceled = this._container.ZipFile.OnSingleEntryExtract(this, path, true);
				}
			}
		}

		private void OnAfterExtract(string path)
		{
			bool flag = this._container.ZipFile != null;
			if (flag)
			{
				bool flag2 = !this._container.ZipFile._inExtractAll;
				if (flag2)
				{
					this._container.ZipFile.OnSingleEntryExtract(this, path, false);
				}
			}
		}

		private void OnExtractExisting(string path)
		{
			bool flag = this._container.ZipFile != null;
			if (flag)
			{
				this._ioOperationCanceled = this._container.ZipFile.OnExtractExisting(this, path);
			}
		}

		private static void ReallyDelete(string fileName)
		{
			bool flag = (File.GetAttributes(fileName) & FileAttributes.ReadOnly) == FileAttributes.ReadOnly;
			if (flag)
			{
				File.SetAttributes(fileName, FileAttributes.Normal);
			}
			File.Delete(fileName);
		}

		private void WriteStatus(string format, params object[] args)
		{
			bool flag = this._container.ZipFile != null && this._container.ZipFile.Verbose;
			if (flag)
			{
				this._container.ZipFile.StatusMessageTextWriter.WriteLine(format, args);
			}
		}

		private void InternalExtract(string baseDir, Stream outstream, string password)
		{
			bool flag = this._container == null;
			if (flag)
			{
				throw new BadStateException("This entry is an orphan");
			}
			bool flag2 = this._container.ZipFile == null;
			if (flag2)
			{
				throw new InvalidOperationException("Use Extract() only with ZipFile.");
			}
			this._container.ZipFile.Reset(false);
			bool flag3 = this._Source != ZipEntrySource.ZipFile;
			if (flag3)
			{
				throw new BadStateException("You must call ZipFile.Save before calling any Extract method");
			}
			this.OnBeforeExtract(baseDir);
			this._ioOperationCanceled = false;
			string text = null;
			Stream stream = null;
			bool flag4 = false;
			bool flag5 = false;
			try
			{
				this.ValidateCompression();
				this.ValidateEncryption();
				bool flag6 = this.ValidateOutput(baseDir, outstream, out text);
				if (flag6)
				{
					this.WriteStatus("extract dir {0}...", new object[]
					{
						text
					});
					this.OnAfterExtract(baseDir);
				}
				else
				{
					bool flag7 = text != null;
					if (flag7)
					{
						bool flag8 = File.Exists(text);
						if (flag8)
						{
							flag4 = true;
							int num = this.CheckExtractExistingFile(baseDir, text);
							bool flag9 = num == 2;
							if (flag9)
							{
								goto IL_33F;
							}
							bool flag10 = num == 1;
							if (flag10)
							{
								return;
							}
						}
					}
					string text2 = password ?? (this._Password ?? this._container.Password);
					bool flag11 = this._Encryption_FromZipFile > EncryptionAlgorithm.None;
					if (flag11)
					{
						bool flag12 = text2 == null;
						if (flag12)
						{
							throw new BadPasswordException();
						}
						this.SetupCryptoForExtract(text2);
					}
					bool flag13 = text != null;
					if (flag13)
					{
						this.WriteStatus("extract file {0}...", new object[]
						{
							text
						});
						text += ".tmp";
						string directoryName = Path.GetDirectoryName(text);
						bool flag14 = !Directory.Exists(directoryName);
						if (flag14)
						{
							Directory.CreateDirectory(directoryName);
						}
						else
						{
							bool flag15 = this._container.ZipFile != null;
							if (flag15)
							{
								flag5 = this._container.ZipFile._inExtractAll;
							}
						}
						stream = new FileStream(text, FileMode.CreateNew);
					}
					else
					{
						this.WriteStatus("extract entry {0} to stream...", new object[]
						{
							this.FileName
						});
						stream = outstream;
					}
					bool ioOperationCanceled = this._ioOperationCanceled;
					if (!ioOperationCanceled)
					{
						int actualCrc = this.ExtractOne(stream);
						bool ioOperationCanceled2 = this._ioOperationCanceled;
						if (!ioOperationCanceled2)
						{
							this.VerifyCrcAfterExtract(actualCrc);
							bool flag16 = text != null;
							if (flag16)
							{
								stream.Close();
								stream = null;
								string text3 = text;
								string text4 = null;
								text = text3.Substring(0, text3.Length - 4);
								bool flag17 = flag4;
								if (flag17)
								{
									text4 = text + ".PendingOverwrite";
									File.Move(text, text4);
								}
								File.Move(text3, text);
								this._SetTimes(text, true);
								bool flag18 = text4 != null && File.Exists(text4);
								if (flag18)
								{
									ZipEntry.ReallyDelete(text4);
								}
								bool flag19 = flag5;
								if (flag19)
								{
									bool flag20 = this.FileName.IndexOf('/') != -1;
									if (flag20)
									{
										string directoryName2 = Path.GetDirectoryName(this.FileName);
										bool flag21 = this._container.ZipFile[directoryName2] == null;
										if (flag21)
										{
											this._SetTimes(Path.GetDirectoryName(text), false);
										}
									}
								}
								bool flag22 = ((int)this._VersionMadeBy & 65280) == 2560 || ((int)this._VersionMadeBy & 65280) == 0;
								if (flag22)
								{
									File.SetAttributes(text, (FileAttributes)this._ExternalFileAttrs);
								}
							}
							this.OnAfterExtract(baseDir);
						}
					}
					IL_33F:;
				}
			}
			catch (Exception)
			{
				this._ioOperationCanceled = true;
				throw;
			}
			finally
			{
				bool ioOperationCanceled3 = this._ioOperationCanceled;
				if (ioOperationCanceled3)
				{
					bool flag23 = text != null;
					if (flag23)
					{
						try
						{
							bool flag24 = stream != null;
							if (flag24)
							{
								stream.Close();
							}
							bool flag25 = File.Exists(text) && !flag4;
							if (flag25)
							{
								File.Delete(text);
							}
						}
						finally
						{
						}
					}
				}
			}
		}

		internal void VerifyCrcAfterExtract(int actualCrc32)
		{
			bool flag = actualCrc32 != this._Crc32;
			if (flag)
			{
				throw new BadCrcException("CRC error: the file being extracted appears to be corrupted. " + string.Format("Expected 0x{0:X8}, Actual 0x{1:X8}", this._Crc32, actualCrc32));
			}
		}

		private int CheckExtractExistingFile(string baseDir, string targetFileName)
		{
			int num = 0;
			for (;;)
			{
				switch (this.ExtractExistingFile)
				{
				case ExtractExistingFileAction.OverwriteSilently:
					goto IL_23;
				case ExtractExistingFileAction.DoNotOverwrite:
					goto IL_3D;
				case ExtractExistingFileAction.InvokeExtractProgressEvent:
				{
					bool flag = num > 0;
					if (flag)
					{
						goto Block_2;
					}
					this.OnExtractExisting(baseDir);
					bool ioOperationCanceled = this._ioOperationCanceled;
					if (ioOperationCanceled)
					{
						goto Block_3;
					}
					num++;
					continue;
				}
				}
				break;
			}
			goto IL_97;
			IL_23:
			this.WriteStatus("the file {0} exists; will overwrite it...", new object[]
			{
				targetFileName
			});
			return 0;
			IL_3D:
			this.WriteStatus("the file {0} exists; not extracting entry...", new object[]
			{
				this.FileName
			});
			this.OnAfterExtract(baseDir);
			return 1;
			Block_2:
			throw new ZipException(string.Format("The file {0} already exists.", targetFileName));
			Block_3:
			return 2;
			IL_97:
			throw new ZipException(string.Format("The file {0} already exists.", targetFileName));
		}

		private void _CheckRead(int nbytes)
		{
			bool flag = nbytes == 0;
			if (flag)
			{
				throw new BadReadException(string.Format("bad read of entry {0} from compressed archive.", this.FileName));
			}
		}

		private int ExtractOne(Stream output)
		{
			int result = 0;
			Stream archiveStream = this.ArchiveStream;
			try
			{
				archiveStream.Seek(this.FileDataPosition, SeekOrigin.Begin);
				byte[] array = new byte[this.BufferSize];
				long num = (this._CompressionMethod_FromZipFile != 0) ? this.UncompressedSize : this._CompressedFileDataSize;
				this._inputDecryptorStream = this.GetExtractDecryptor(archiveStream);
				Stream extractDecompressor = this.GetExtractDecompressor(this._inputDecryptorStream);
				long num2 = 0L;
				using (CrcCalculatorStream crcCalculatorStream = new CrcCalculatorStream(extractDecompressor))
				{
					while (num > 0L)
					{
						int count = (num > (long)array.Length) ? array.Length : ((int)num);
						int num3 = crcCalculatorStream.Read(array, 0, count);
						this._CheckRead(num3);
						output.Write(array, 0, num3);
						num -= (long)num3;
						num2 += (long)num3;
						this.OnExtractProgress(num2, this.UncompressedSize);
						bool ioOperationCanceled = this._ioOperationCanceled;
						if (ioOperationCanceled)
						{
							break;
						}
					}
					result = crcCalculatorStream.Crc;
				}
			}
			finally
			{
				ZipSegmentedStream zipSegmentedStream = archiveStream as ZipSegmentedStream;
				bool flag = zipSegmentedStream != null;
				if (flag)
				{
					zipSegmentedStream.Dispose();
					this._archiveStream = null;
				}
			}
			return result;
		}

		internal Stream GetExtractDecompressor(Stream input2)
		{
			short compressionMethod_FromZipFile = this._CompressionMethod_FromZipFile;
			Stream result;
			if (compressionMethod_FromZipFile != 0)
			{
				if (compressionMethod_FromZipFile != 8)
				{
					result = null;
				}
				else
				{
					result = new DeflateStream(input2, CompressionMode.Decompress, true);
				}
			}
			else
			{
				result = input2;
			}
			return result;
		}

		internal Stream GetExtractDecryptor(Stream input)
		{
			bool flag = this._Encryption_FromZipFile == EncryptionAlgorithm.PkzipWeak;
			Stream result;
			if (flag)
			{
				result = new ZipCipherStream(input, this._zipCrypto_forExtract, CryptoMode.Decrypt);
			}
			else
			{
				result = input;
			}
			return result;
		}

		internal void _SetTimes(string fileOrDirectory, bool isFile)
		{
			try
			{
				bool ntfsTimesAreSet = this._ntfsTimesAreSet;
				if (ntfsTimesAreSet)
				{
					if (isFile)
					{
						bool flag = File.Exists(fileOrDirectory);
						if (flag)
						{
							File.SetCreationTimeUtc(fileOrDirectory, this._Ctime);
							File.SetLastAccessTimeUtc(fileOrDirectory, this._Atime);
							File.SetLastWriteTimeUtc(fileOrDirectory, this._Mtime);
						}
					}
					else
					{
						bool flag2 = Directory.Exists(fileOrDirectory);
						if (flag2)
						{
							Directory.SetCreationTimeUtc(fileOrDirectory, this._Ctime);
							Directory.SetLastAccessTimeUtc(fileOrDirectory, this._Atime);
							Directory.SetLastWriteTimeUtc(fileOrDirectory, this._Mtime);
						}
					}
				}
				else
				{
					DateTime lastWriteTime = SharedUtilities.AdjustTime_Reverse(this.LastModified);
					if (isFile)
					{
						File.SetLastWriteTime(fileOrDirectory, lastWriteTime);
					}
					else
					{
						Directory.SetLastWriteTime(fileOrDirectory, lastWriteTime);
					}
				}
			}
			catch (IOException ex)
			{
				this.WriteStatus("failed to set time on {0}: {1}", new object[]
				{
					fileOrDirectory,
					ex.Message
				});
			}
		}

		private string UnsupportedAlgorithm
		{
			get
			{
				string empty = string.Empty;
				uint unsupportedAlgorithmId = this._UnsupportedAlgorithmId;
				if (unsupportedAlgorithmId <= 26128U)
				{
					if (unsupportedAlgorithmId <= 26115U)
					{
						if (unsupportedAlgorithmId == 0U)
						{
							return "--";
						}
						switch (unsupportedAlgorithmId)
						{
						case 26113U:
							return "DES";
						case 26114U:
							return "RC2";
						case 26115U:
							return "3DES-168";
						}
					}
					else
					{
						if (unsupportedAlgorithmId == 26121U)
						{
							return "3DES-112";
						}
						switch (unsupportedAlgorithmId)
						{
						case 26126U:
							return "PKWare AES128";
						case 26127U:
							return "PKWare AES192";
						case 26128U:
							return "PKWare AES256";
						}
					}
				}
				else if (unsupportedAlgorithmId <= 26400U)
				{
					if (unsupportedAlgorithmId == 26370U)
					{
						return "RC2";
					}
					if (unsupportedAlgorithmId == 26400U)
					{
						return "Blowfish";
					}
				}
				else
				{
					if (unsupportedAlgorithmId == 26401U)
					{
						return "Twofish";
					}
					if (unsupportedAlgorithmId == 26625U)
					{
						return "RC4";
					}
					if (unsupportedAlgorithmId != 65535U)
					{
					}
				}
				return string.Format("Unknown (0x{0:X4})", this._UnsupportedAlgorithmId);
			}
		}

		private string UnsupportedCompressionMethod
		{
			get
			{
				string empty = string.Empty;
				int compressionMethod = (int)this._CompressionMethod;
				if (compressionMethod <= 1)
				{
					if (compressionMethod == 0)
					{
						return "Store";
					}
					if (compressionMethod == 1)
					{
						return "Shrink";
					}
				}
				else
				{
					switch (compressionMethod)
					{
					case 8:
						return "DEFLATE";
					case 9:
						return "Deflate64";
					case 10:
					case 11:
					case 13:
						break;
					case 12:
						return "BZIP2";
					case 14:
						return "LZMA";
					default:
						if (compressionMethod == 19)
						{
							return "LZ77";
						}
						if (compressionMethod == 98)
						{
							return "PPMd";
						}
						break;
					}
				}
				return string.Format("Unknown (0x{0:X4})", this._CompressionMethod);
			}
		}

		internal void ValidateEncryption()
		{
			bool flag = this.Encryption != EncryptionAlgorithm.PkzipWeak && this.Encryption > EncryptionAlgorithm.None;
			if (!flag)
			{
				return;
			}
			bool flag2 = this._UnsupportedAlgorithmId > 0U;
			if (flag2)
			{
				throw new ZipException(string.Format("Cannot extract: Entry {0} is encrypted with an algorithm not supported by DotNetZip: {1}", this.FileName, this.UnsupportedAlgorithm));
			}
			throw new ZipException(string.Format("Cannot extract: Entry {0} uses an unsupported encryption algorithm ({1:X2})", this.FileName, (int)this.Encryption));
		}

		private void ValidateCompression()
		{
			bool flag = this._CompressionMethod_FromZipFile != 0 && this._CompressionMethod_FromZipFile != 8;
			if (flag)
			{
				throw new ZipException(string.Format("Entry {0} uses an unsupported compression method (0x{1:X2}, {2})", this.FileName, this._CompressionMethod_FromZipFile, this.UnsupportedCompressionMethod));
			}
		}

		private void SetupCryptoForExtract(string password)
		{
			bool flag = this._Encryption_FromZipFile == EncryptionAlgorithm.None;
			if (!flag)
			{
				bool flag2 = this._Encryption_FromZipFile == EncryptionAlgorithm.PkzipWeak;
				if (flag2)
				{
					bool flag3 = password == null;
					if (flag3)
					{
						throw new ZipException("Missing password.");
					}
					this.ArchiveStream.Seek(this.FileDataPosition - 12L, SeekOrigin.Begin);
					this._zipCrypto_forExtract = ZipCrypto.ForRead(password, this);
				}
			}
		}

		private bool ValidateOutput(string basedir, Stream outstream, out string outFileName)
		{
			bool flag = basedir != null;
			bool result;
			if (flag)
			{
				string text = this.FileName.Replace("\\", "/");
				bool flag2 = text.IndexOf(':') == 1;
				if (flag2)
				{
					text = text.Substring(2);
				}
				bool flag3 = text.StartsWith("/");
				if (flag3)
				{
					text = text.Substring(1);
				}
				bool flattenFoldersOnExtract = this._container.ZipFile.FlattenFoldersOnExtract;
				if (flattenFoldersOnExtract)
				{
					outFileName = Path.Combine(basedir, (text.IndexOf('/') != -1) ? Path.GetFileName(text) : text);
				}
				else
				{
					outFileName = Path.Combine(basedir, text);
				}
				outFileName = outFileName.Replace("/", "\\");
				bool flag4 = this.IsDirectory || this.FileName.EndsWith("/");
				if (flag4)
				{
					bool flag5 = !Directory.Exists(outFileName);
					if (flag5)
					{
						Directory.CreateDirectory(outFileName);
						this._SetTimes(outFileName, false);
					}
					else
					{
						bool flag6 = this.ExtractExistingFile == ExtractExistingFileAction.OverwriteSilently;
						if (flag6)
						{
							this._SetTimes(outFileName, false);
						}
					}
					result = true;
				}
				else
				{
					result = false;
				}
			}
			else
			{
				bool flag7 = outstream != null;
				if (!flag7)
				{
					throw new ArgumentNullException("outstream");
				}
				outFileName = null;
				bool flag8 = this.IsDirectory || this.FileName.EndsWith("/");
				result = flag8;
			}
			return result;
		}

		private void ReadExtraField()
		{
			this._readExtraDepth++;
			long position = this.ArchiveStream.Position;
			this.ArchiveStream.Seek(this._RelativeOffsetOfLocalHeader, SeekOrigin.Begin);
			byte[] array = new byte[30];
			this.ArchiveStream.Read(array, 0, array.Length);
			int num = 26;
			short num2 = (short)((int)array[num++] + (int)array[num++] * 256);
			short extraFieldLength = (short)((int)array[num++] + (int)array[num++] * 256);
			this.ArchiveStream.Seek((long)num2, SeekOrigin.Current);
			this.ProcessExtraField(this.ArchiveStream, extraFieldLength);
			this.ArchiveStream.Seek(position, SeekOrigin.Begin);
			this._readExtraDepth--;
		}

		private static bool ReadHeader(ZipEntry ze, Encoding defaultEncoding)
		{
			int num = 0;
			ze._RelativeOffsetOfLocalHeader = ze.ArchiveStream.Position;
			int num2 = SharedUtilities.ReadEntrySignature(ze.ArchiveStream);
			num += 4;
			bool flag = ZipEntry.IsNotValidSig(num2);
			bool result;
			if (flag)
			{
				ze.ArchiveStream.Seek(-4L, SeekOrigin.Current);
				bool flag2 = ZipEntry.IsNotValidZipDirEntrySig(num2) && (long)num2 != 101010256L;
				if (flag2)
				{
					throw new BadReadException(string.Format("  Bad signature (0x{0:X8}) at position  0x{1:X8}", num2, ze.ArchiveStream.Position));
				}
				result = false;
			}
			else
			{
				byte[] array = new byte[26];
				int num3 = ze.ArchiveStream.Read(array, 0, array.Length);
				bool flag3 = num3 != array.Length;
				if (flag3)
				{
					result = false;
				}
				else
				{
					num += num3;
					int num4 = 0;
					ze._VersionNeeded = (short)((int)array[num4++] + (int)array[num4++] * 256);
					ze._BitField = (short)((int)array[num4++] + (int)array[num4++] * 256);
					ze._CompressionMethod_FromZipFile = (ze._CompressionMethod = (short)((int)array[num4++] + (int)array[num4++] * 256));
					ze._TimeBlob = (int)array[num4++] + (int)array[num4++] * 256 + (int)array[num4++] * 256 * 256 + (int)array[num4++] * 256 * 256 * 256;
					ze._LastModified = SharedUtilities.PackedToDateTime(ze._TimeBlob);
					ze._timestamp |= ZipEntryTimestamp.DOS;
					bool flag4 = (ze._BitField & 1) == 1;
					if (flag4)
					{
						ze._Encryption_FromZipFile = (ze._Encryption = EncryptionAlgorithm.PkzipWeak);
						ze._sourceIsEncrypted = true;
					}
					ze._Crc32 = (int)array[num4++] + (int)array[num4++] * 256 + (int)array[num4++] * 256 * 256 + (int)array[num4++] * 256 * 256 * 256;
					ze._CompressedSize = (long)((ulong)((int)array[num4++] + (int)array[num4++] * 256 + (int)array[num4++] * 256 * 256 + (int)array[num4++] * 256 * 256 * 256));
					ze._UncompressedSize = (long)((ulong)((int)array[num4++] + (int)array[num4++] * 256 + (int)array[num4++] * 256 * 256 + (int)array[num4++] * 256 * 256 * 256));
					bool flag5 = (uint)ze._CompressedSize == uint.MaxValue || (uint)ze._UncompressedSize == uint.MaxValue;
					if (flag5)
					{
						ze._InputUsesZip64 = true;
					}
					short num5 = (short)((int)array[num4++] + (int)array[num4++] * 256);
					short extraFieldLength = (short)((int)array[num4++] + (int)array[num4++] * 256);
					array = new byte[(int)num5];
					num3 = ze.ArchiveStream.Read(array, 0, array.Length);
					num += num3;
					bool flag6 = (ze._BitField & 2048) == 2048;
					if (flag6)
					{
						ze.AlternateEncoding = Encoding.UTF8;
						ze.AlternateEncodingUsage = ZipOption.Always;
					}
					ze._FileNameInArchive = ze.AlternateEncoding.GetString(array, 0, array.Length);
					bool flag7 = ze._FileNameInArchive.EndsWith("/");
					if (flag7)
					{
						ze.MarkAsDirectory();
					}
					num += ze.ProcessExtraField(ze.ArchiveStream, extraFieldLength);
					ze._LengthOfTrailer = 0;
					bool flag8 = !ze._FileNameInArchive.EndsWith("/") && (ze._BitField & 8) == 8;
					if (flag8)
					{
						long position = ze.ArchiveStream.Position;
						bool flag9 = true;
						long num6 = 0L;
						int num7 = 0;
						while (flag9)
						{
							num7++;
							bool flag10 = ze._container.ZipFile != null;
							if (flag10)
							{
								ze._container.ZipFile.OnReadBytes(ze);
							}
							long num8 = SharedUtilities.FindSignature(ze.ArchiveStream, 134695760);
							bool flag11 = num8 == -1L;
							if (flag11)
							{
								return false;
							}
							num6 += num8;
							bool inputUsesZip = ze._InputUsesZip64;
							if (inputUsesZip)
							{
								array = new byte[20];
								num3 = ze.ArchiveStream.Read(array, 0, array.Length);
								bool flag12 = num3 != 20;
								if (flag12)
								{
									return false;
								}
								num4 = 0;
								ze._Crc32 = (int)array[num4++] + (int)array[num4++] * 256 + (int)array[num4++] * 256 * 256 + (int)array[num4++] * 256 * 256 * 256;
								ze._CompressedSize = BitConverter.ToInt64(array, num4);
								num4 += 8;
								ze._UncompressedSize = BitConverter.ToInt64(array, num4);
								num4 += 8;
								ze._LengthOfTrailer += 24;
							}
							else
							{
								array = new byte[12];
								num3 = ze.ArchiveStream.Read(array, 0, array.Length);
								bool flag13 = num3 != 12;
								if (flag13)
								{
									return false;
								}
								num4 = 0;
								ze._Crc32 = (int)array[num4++] + (int)array[num4++] * 256 + (int)array[num4++] * 256 * 256 + (int)array[num4++] * 256 * 256 * 256;
								ze._CompressedSize = (long)((ulong)((int)array[num4++] + (int)array[num4++] * 256 + (int)array[num4++] * 256 * 256 + (int)array[num4++] * 256 * 256 * 256));
								ze._UncompressedSize = (long)((ulong)((int)array[num4++] + (int)array[num4++] * 256 + (int)array[num4++] * 256 * 256 + (int)array[num4++] * 256 * 256 * 256));
								ze._LengthOfTrailer += 16;
							}
							flag9 = (num6 != ze._CompressedSize);
							bool flag14 = flag9;
							if (flag14)
							{
								ze.ArchiveStream.Seek(-12L, SeekOrigin.Current);
								num6 += 4L;
							}
						}
						ze.ArchiveStream.Seek(position, SeekOrigin.Begin);
					}
					ze._CompressedFileDataSize = ze._CompressedSize;
					bool flag15 = (ze._BitField & 1) == 1;
					if (flag15)
					{
						ze._WeakEncryptionHeader = new byte[12];
						num += ZipEntry.ReadWeakEncryptionHeader(ze._archiveStream, ze._WeakEncryptionHeader);
						ze._CompressedFileDataSize -= 12L;
					}
					ze._LengthOfHeader = num;
					ze._TotalEntrySize = (long)ze._LengthOfHeader + ze._CompressedFileDataSize + (long)ze._LengthOfTrailer;
					result = true;
				}
			}
			return result;
		}

		internal static int ReadWeakEncryptionHeader(Stream s, byte[] buffer)
		{
			int num = s.Read(buffer, 0, 12);
			bool flag = num != 12;
			if (flag)
			{
				throw new ZipException(string.Format("Unexpected end of data at position 0x{0:X8}", s.Position));
			}
			return num;
		}

		private static bool IsNotValidSig(int signature)
		{
			return signature != 67324752;
		}

		internal static ZipEntry ReadEntry(ZipContainer zc, bool first)
		{
			ZipFile zipFile = zc.ZipFile;
			Stream readStream = zc.ReadStream;
			Encoding alternateEncoding = zc.AlternateEncoding;
			ZipEntry zipEntry = new ZipEntry();
			zipEntry._Source = ZipEntrySource.ZipFile;
			zipEntry._container = zc;
			zipEntry._archiveStream = readStream;
			bool flag = zipFile != null;
			if (flag)
			{
				zipFile.OnReadEntry(true, null);
			}
			if (first)
			{
				ZipEntry.HandlePK00Prefix(readStream);
			}
			bool flag2 = !ZipEntry.ReadHeader(zipEntry, alternateEncoding);
			ZipEntry result;
			if (flag2)
			{
				result = null;
			}
			else
			{
				zipEntry.__FileDataPosition = zipEntry.ArchiveStream.Position;
				readStream.Seek(zipEntry._CompressedFileDataSize + (long)zipEntry._LengthOfTrailer, SeekOrigin.Current);
				ZipEntry.HandleUnexpectedDataDescriptor(zipEntry);
				bool flag3 = zipFile != null;
				if (flag3)
				{
					zipFile.OnReadBytes(zipEntry);
					zipFile.OnReadEntry(false, zipEntry);
				}
				result = zipEntry;
			}
			return result;
		}

		internal static void HandlePK00Prefix(Stream s)
		{
			uint num = (uint)SharedUtilities.ReadInt(s);
			bool flag = num != 808471376U;
			if (flag)
			{
				s.Seek(-4L, SeekOrigin.Current);
			}
		}

		private static void HandleUnexpectedDataDescriptor(ZipEntry entry)
		{
			Stream archiveStream = entry.ArchiveStream;
			uint num = (uint)SharedUtilities.ReadInt(archiveStream);
			bool flag = (ulong)num == (ulong)((long)entry._Crc32);
			if (flag)
			{
				int num2 = SharedUtilities.ReadInt(archiveStream);
				bool flag2 = (long)num2 == entry._CompressedSize;
				if (flag2)
				{
					num2 = SharedUtilities.ReadInt(archiveStream);
					bool flag3 = (long)num2 == entry._UncompressedSize;
					if (!flag3)
					{
						archiveStream.Seek(-12L, SeekOrigin.Current);
					}
				}
				else
				{
					archiveStream.Seek(-8L, SeekOrigin.Current);
				}
			}
			else
			{
				archiveStream.Seek(-4L, SeekOrigin.Current);
			}
		}

		internal static int FindExtraFieldSegment(byte[] extra, int offx, ushort targetHeaderId)
		{
			int num = offx;
			while (num + 3 < extra.Length)
			{
				ushort num2 = (ushort)((int)extra[num++] + (int)extra[num++] * 256);
				bool flag = num2 == targetHeaderId;
				if (flag)
				{
					return num - 2;
				}
				short num3 = (short)((int)extra[num++] + (int)extra[num++] * 256);
				num += (int)num3;
			}
			return -1;
		}

		internal int ProcessExtraField(Stream s, short extraFieldLength)
		{
			int num = 0;
			bool flag = extraFieldLength > 0;
			if (flag)
			{
				byte[] array = this._Extra = new byte[(int)extraFieldLength];
				num = s.Read(array, 0, array.Length);
				long posn = s.Position - (long)num;
				int num2 = 0;
				while (num2 + 3 < array.Length)
				{
					int num3 = num2;
					ushort num4 = (ushort)((int)array[num2++] + (int)array[num2++] * 256);
					short num5 = (short)((int)array[num2++] + (int)array[num2++] * 256);
					ushort num6 = num4;
					if (num6 <= 23)
					{
						if (num6 != 1)
						{
							if (num6 != 10)
							{
								if (num6 == 23)
								{
									num2 = this.ProcessExtraFieldPkwareStrongEncryption(array, num2);
								}
							}
							else
							{
								num2 = this.ProcessExtraFieldWindowsTimes(array, num2, num5, posn);
							}
						}
						else
						{
							num2 = this.ProcessExtraFieldZip64(array, num2, num5, posn);
						}
					}
					else if (num6 <= 22613)
					{
						if (num6 != 21589)
						{
							if (num6 == 22613)
							{
								num2 = this.ProcessExtraFieldInfoZipTimes(array, num2, num5, posn);
							}
						}
						else
						{
							num2 = this.ProcessExtraFieldUnixTimes(array, num2, num5, posn);
						}
					}
					else if (num6 != 30805)
					{
						if (num6 != 30837)
						{
						}
					}
					num2 = num3 + (int)num5 + 4;
				}
			}
			return num;
		}

		private int ProcessExtraFieldPkwareStrongEncryption(byte[] Buffer, int j)
		{
			j += 2;
			this._UnsupportedAlgorithmId = (uint)((ushort)((int)Buffer[j++] + (int)Buffer[j++] * 256));
			this._Encryption_FromZipFile = (this._Encryption = EncryptionAlgorithm.Unsupported);
			return j;
		}

		private int ProcessExtraFieldZip64(byte[] buffer, int j, short dataSize, long posn)
		{
			this._InputUsesZip64 = true;
			bool flag = dataSize > 28;
			if (flag)
			{
				throw new BadReadException(string.Format("  Inconsistent size (0x{0:X4}) for ZIP64 extra field at position 0x{1:X16}", dataSize, posn));
			}
			int remainingData = (int)dataSize;
			ZipEntry.Func<long> func = delegate()
			{
				bool flag5 = remainingData < 8;
				if (flag5)
				{
					throw new BadReadException(string.Format("  Missing data for ZIP64 extra field, position 0x{0:X16}", posn));
				}
				long result = BitConverter.ToInt64(buffer, j);
				j += 8;
				remainingData -= 8;
				return result;
			};
			bool flag2 = this._UncompressedSize == (long)((ulong)-1);
			if (flag2)
			{
				this._UncompressedSize = func();
			}
			bool flag3 = this._CompressedSize == (long)((ulong)-1);
			if (flag3)
			{
				this._CompressedSize = func();
			}
			bool flag4 = this._RelativeOffsetOfLocalHeader == (long)((ulong)-1);
			if (flag4)
			{
				this._RelativeOffsetOfLocalHeader = func();
			}
			return j;
		}

		private int ProcessExtraFieldInfoZipTimes(byte[] buffer, int j, short dataSize, long posn)
		{
			bool flag = dataSize != 12 && dataSize != 8;
			if (flag)
			{
				throw new BadReadException(string.Format("  Unexpected size (0x{0:X4}) for InfoZip v1 extra field at position 0x{1:X16}", dataSize, posn));
			}
			int num = BitConverter.ToInt32(buffer, j);
			this._Mtime = ZipEntry._unixEpoch.AddSeconds((double)num);
			j += 4;
			num = BitConverter.ToInt32(buffer, j);
			this._Atime = ZipEntry._unixEpoch.AddSeconds((double)num);
			j += 4;
			this._Ctime = DateTime.UtcNow;
			this._ntfsTimesAreSet = true;
			this._timestamp |= ZipEntryTimestamp.InfoZip1;
			return j;
		}

		private int ProcessExtraFieldUnixTimes(byte[] buffer, int j, short dataSize, long posn)
		{
			bool flag = dataSize != 13 && dataSize != 9 && dataSize != 5;
			if (flag)
			{
				throw new BadReadException(string.Format("  Unexpected size (0x{0:X4}) for Extended Timestamp extra field at position 0x{1:X16}", dataSize, posn));
			}
			int remainingData = (int)dataSize;
			ZipEntry.Func<DateTime> func = delegate()
			{
				int num2 = BitConverter.ToInt32(buffer, j);
				j += 4;
				remainingData -= 4;
				return ZipEntry._unixEpoch.AddSeconds((double)num2);
			};
			bool flag2 = dataSize == 13 || this._readExtraDepth > 0;
			if (flag2)
			{
				byte[] buffer2 = buffer;
				int num = j;
				j = num + 1;
				byte b = buffer2[num];
				num = remainingData;
				remainingData = num - 1;
				bool flag3 = (b & 1) != 0 && remainingData >= 4;
				if (flag3)
				{
					this._Mtime = func();
				}
				this._Atime = (((b & 2) != 0 && remainingData >= 4) ? func() : DateTime.UtcNow);
				this._Ctime = (((b & 4) != 0 && remainingData >= 4) ? func() : DateTime.UtcNow);
				this._timestamp |= ZipEntryTimestamp.Unix;
				this._ntfsTimesAreSet = true;
				this._emitUnixTimes = true;
			}
			else
			{
				this.ReadExtraField();
			}
			return j;
		}

		private int ProcessExtraFieldWindowsTimes(byte[] buffer, int j, short dataSize, long posn)
		{
			bool flag = dataSize != 32;
			if (flag)
			{
				throw new BadReadException(string.Format("  Unexpected size (0x{0:X4}) for NTFS times extra field at position 0x{1:X16}", dataSize, posn));
			}
			j += 4;
			short num = (short)((int)buffer[j] + (int)buffer[j + 1] * 256);
			short num2 = (short)((int)buffer[j + 2] + (int)buffer[j + 3] * 256);
			j += 4;
			bool flag2 = num == 1 && num2 == 24;
			if (flag2)
			{
				long fileTime = BitConverter.ToInt64(buffer, j);
				this._Mtime = DateTime.FromFileTimeUtc(fileTime);
				j += 8;
				fileTime = BitConverter.ToInt64(buffer, j);
				this._Atime = DateTime.FromFileTimeUtc(fileTime);
				j += 8;
				fileTime = BitConverter.ToInt64(buffer, j);
				this._Ctime = DateTime.FromFileTimeUtc(fileTime);
				j += 8;
				this._ntfsTimesAreSet = true;
				this._timestamp |= ZipEntryTimestamp.Windows;
				this._emitNtfsTimes = true;
			}
			return j;
		}

		internal void WriteCentralDirectoryEntry(Stream s)
		{
			byte[] array = new byte[4096];
			int num = 0;
			array[num++] = 80;
			array[num++] = 75;
			array[num++] = 1;
			array[num++] = 2;
			array[num++] = (byte)(this._VersionMadeBy & 255);
			array[num++] = (byte)(((int)this._VersionMadeBy & 65280) >> 8);
			short num2 = (this.VersionNeeded != 0) ? this.VersionNeeded : 20;
			bool flag = this._OutputUsesZip64 == null;
			if (flag)
			{
				this._OutputUsesZip64 = new bool?(this._container.Zip64 == Zip64Option.Always);
			}
			short num3 = this._OutputUsesZip64.Value ? 45 : num2;
			array[num++] = (byte)(num3 & 255);
			array[num++] = (byte)(((int)num3 & 65280) >> 8);
			array[num++] = (byte)(this._BitField & 255);
			array[num++] = (byte)(((int)this._BitField & 65280) >> 8);
			array[num++] = (byte)(this._CompressionMethod & 255);
			array[num++] = (byte)(((int)this._CompressionMethod & 65280) >> 8);
			array[num++] = (byte)(this._TimeBlob & 255);
			array[num++] = (byte)((this._TimeBlob & 65280) >> 8);
			array[num++] = (byte)((this._TimeBlob & 16711680) >> 16);
			array[num++] = (byte)(((long)this._TimeBlob & (long)((ulong)-16777216)) >> 24);
			array[num++] = (byte)(this._Crc32 & 255);
			array[num++] = (byte)((this._Crc32 & 65280) >> 8);
			array[num++] = (byte)((this._Crc32 & 16711680) >> 16);
			array[num++] = (byte)(((long)this._Crc32 & (long)((ulong)-16777216)) >> 24);
			bool value = this._OutputUsesZip64.Value;
			if (value)
			{
				for (int i = 0; i < 8; i++)
				{
					array[num++] = byte.MaxValue;
				}
			}
			else
			{
				array[num++] = (byte)(this._CompressedSize & 255L);
				array[num++] = (byte)((this._CompressedSize & 65280L) >> 8);
				array[num++] = (byte)((this._CompressedSize & 16711680L) >> 16);
				array[num++] = (byte)((this._CompressedSize & (long)((ulong)-16777216)) >> 24);
				array[num++] = (byte)(this._UncompressedSize & 255L);
				array[num++] = (byte)((this._UncompressedSize & 65280L) >> 8);
				array[num++] = (byte)((this._UncompressedSize & 16711680L) >> 16);
				array[num++] = (byte)((this._UncompressedSize & (long)((ulong)-16777216)) >> 24);
			}
			byte[] encodedFileNameBytes = this.GetEncodedFileNameBytes();
			short num4 = (short)encodedFileNameBytes.Length;
			array[num++] = (byte)(num4 & 255);
			array[num++] = (byte)(((int)num4 & 65280) >> 8);
			this._presumeZip64 = this._OutputUsesZip64.Value;
			this._Extra = this.ConstructExtraField(true);
			short num5 = (short)((this._Extra == null) ? 0 : this._Extra.Length);
			array[num++] = (byte)(num5 & 255);
			array[num++] = (byte)(((int)num5 & 65280) >> 8);
			int num6 = (this._CommentBytes == null) ? 0 : this._CommentBytes.Length;
			bool flag2 = num6 + num > array.Length;
			if (flag2)
			{
				num6 = array.Length - num;
			}
			array[num++] = (byte)(num6 & 255);
			array[num++] = (byte)((num6 & 65280) >> 8);
			bool flag3 = this._container.ZipFile != null && this._container.ZipFile.MaxOutputSegmentSize != 0;
			bool flag4 = flag3;
			if (flag4)
			{
				array[num++] = (byte)(this._diskNumber & 255U);
				array[num++] = (byte)((this._diskNumber & 65280U) >> 8);
			}
			else
			{
				array[num++] = 0;
				array[num++] = 0;
			}
			array[num++] = (this._IsText ? 1 : 0);
			array[num++] = 0;
			array[num++] = (byte)(this._ExternalFileAttrs & 255);
			array[num++] = (byte)((this._ExternalFileAttrs & 65280) >> 8);
			array[num++] = (byte)((this._ExternalFileAttrs & 16711680) >> 16);
			array[num++] = (byte)(((long)this._ExternalFileAttrs & (long)((ulong)-16777216)) >> 24);
			bool flag5 = this._RelativeOffsetOfLocalHeader > (long)((ulong)-1);
			if (flag5)
			{
				array[num++] = byte.MaxValue;
				array[num++] = byte.MaxValue;
				array[num++] = byte.MaxValue;
				array[num++] = byte.MaxValue;
			}
			else
			{
				array[num++] = (byte)(this._RelativeOffsetOfLocalHeader & 255L);
				array[num++] = (byte)((this._RelativeOffsetOfLocalHeader & 65280L) >> 8);
				array[num++] = (byte)((this._RelativeOffsetOfLocalHeader & 16711680L) >> 16);
				array[num++] = (byte)((this._RelativeOffsetOfLocalHeader & (long)((ulong)-16777216)) >> 24);
			}
			Buffer.BlockCopy(encodedFileNameBytes, 0, array, num, (int)num4);
			num += (int)num4;
			bool flag6 = this._Extra != null;
			if (flag6)
			{
				byte[] extra = this._Extra;
				int srcOffset = 0;
				Buffer.BlockCopy(extra, srcOffset, array, num, (int)num5);
				num += (int)num5;
			}
			bool flag7 = num6 != 0;
			if (flag7)
			{
				Buffer.BlockCopy(this._CommentBytes, 0, array, num, num6);
				num += num6;
			}
			s.Write(array, 0, num);
		}

		private byte[] ConstructExtraField(bool forCentralDirectory)
		{
			List<byte[]> list = new List<byte[]>();
			bool flag = this._container.Zip64 == Zip64Option.Always || (this._container.Zip64 == Zip64Option.AsNecessary && (!forCentralDirectory || this._entryRequiresZip64.Value));
			if (flag)
			{
				int num = 4 + (forCentralDirectory ? 28 : 16);
				byte[] array = new byte[num];
				int num2 = 0;
				bool flag2 = this._presumeZip64 || forCentralDirectory;
				if (flag2)
				{
					array[num2++] = 1;
					array[num2++] = 0;
				}
				else
				{
					array[num2++] = 153;
					array[num2++] = 153;
				}
				array[num2++] = (byte)(num - 4);
				array[num2++] = 0;
				Array.Copy(BitConverter.GetBytes(this._UncompressedSize), 0, array, num2, 8);
				num2 += 8;
				Array.Copy(BitConverter.GetBytes(this._CompressedSize), 0, array, num2, 8);
				num2 += 8;
				if (forCentralDirectory)
				{
					Array.Copy(BitConverter.GetBytes(this._RelativeOffsetOfLocalHeader), 0, array, num2, 8);
					num2 += 8;
					Array.Copy(BitConverter.GetBytes(0), 0, array, num2, 4);
				}
				list.Add(array);
			}
			bool flag3 = this._ntfsTimesAreSet && this._emitNtfsTimes;
			if (flag3)
			{
				byte[] array = new byte[36];
				int num3 = 0;
				array[num3++] = 10;
				array[num3++] = 0;
				array[num3++] = 32;
				array[num3++] = 0;
				num3 += 4;
				array[num3++] = 1;
				array[num3++] = 0;
				array[num3++] = 24;
				array[num3++] = 0;
				long value = this._Mtime.ToFileTime();
				Array.Copy(BitConverter.GetBytes(value), 0, array, num3, 8);
				num3 += 8;
				value = this._Atime.ToFileTime();
				Array.Copy(BitConverter.GetBytes(value), 0, array, num3, 8);
				num3 += 8;
				value = this._Ctime.ToFileTime();
				Array.Copy(BitConverter.GetBytes(value), 0, array, num3, 8);
				num3 += 8;
				list.Add(array);
			}
			bool flag4 = this._ntfsTimesAreSet && this._emitUnixTimes;
			if (flag4)
			{
				int num4 = 9;
				bool flag5 = !forCentralDirectory;
				if (flag5)
				{
					num4 += 8;
				}
				byte[] array = new byte[num4];
				int num5 = 0;
				array[num5++] = 85;
				array[num5++] = 84;
				array[num5++] = (byte)(num4 - 4);
				array[num5++] = 0;
				array[num5++] = 7;
				int value2 = (int)(this._Mtime - ZipEntry._unixEpoch).TotalSeconds;
				Array.Copy(BitConverter.GetBytes(value2), 0, array, num5, 4);
				num5 += 4;
				bool flag6 = !forCentralDirectory;
				if (flag6)
				{
					value2 = (int)(this._Atime - ZipEntry._unixEpoch).TotalSeconds;
					Array.Copy(BitConverter.GetBytes(value2), 0, array, num5, 4);
					num5 += 4;
					value2 = (int)(this._Ctime - ZipEntry._unixEpoch).TotalSeconds;
					Array.Copy(BitConverter.GetBytes(value2), 0, array, num5, 4);
					num5 += 4;
				}
				list.Add(array);
			}
			byte[] array2 = null;
			bool flag7 = list.Count > 0;
			if (flag7)
			{
				int num6 = 0;
				int num7 = 0;
				for (int i = 0; i < list.Count; i++)
				{
					num6 += list[i].Length;
				}
				array2 = new byte[num6];
				for (int i = 0; i < list.Count; i++)
				{
					Array.Copy(list[i], 0, array2, num7, list[i].Length);
					num7 += list[i].Length;
				}
			}
			return array2;
		}

		private string NormalizeFileName()
		{
			string text = this.FileName.Replace("\\", "/");
			bool flag = this._TrimVolumeFromFullyQualifiedPaths && this.FileName.Length >= 3 && this.FileName[1] == ':' && text[2] == '/';
			string result;
			if (flag)
			{
				result = text.Substring(3);
			}
			else
			{
				bool flag2 = this.FileName.Length >= 4 && text[0] == '/' && text[1] == '/';
				if (flag2)
				{
					int num = text.IndexOf('/', 2);
					bool flag3 = num == -1;
					if (flag3)
					{
						throw new ArgumentException("The path for that entry appears to be badly formatted");
					}
					result = text.Substring(num + 1);
				}
				else
				{
					bool flag4 = this.FileName.Length >= 3 && text[0] == '.' && text[1] == '/';
					if (flag4)
					{
						result = text.Substring(2);
					}
					else
					{
						result = text;
					}
				}
			}
			return result;
		}

		private byte[] GetEncodedFileNameBytes()
		{
			string text = this.NormalizeFileName();
			ZipOption alternateEncodingUsage = this.AlternateEncodingUsage;
			byte[] result;
			if (alternateEncodingUsage != ZipOption.Default)
			{
				if (alternateEncodingUsage != ZipOption.Always)
				{
					byte[] bytes = ZipEntry.ibm437.GetBytes(text);
					string @string = ZipEntry.ibm437.GetString(bytes, 0, bytes.Length);
					this._CommentBytes = null;
					bool flag = @string != text;
					if (flag)
					{
						bytes = this.AlternateEncoding.GetBytes(text);
						bool flag2 = this._Comment != null && this._Comment.Length != 0;
						if (flag2)
						{
							this._CommentBytes = this.AlternateEncoding.GetBytes(this._Comment);
						}
						this._actualEncoding = this.AlternateEncoding;
						result = bytes;
					}
					else
					{
						this._actualEncoding = ZipEntry.ibm437;
						bool flag3 = this._Comment == null || this._Comment.Length == 0;
						if (flag3)
						{
							result = bytes;
						}
						else
						{
							byte[] bytes2 = ZipEntry.ibm437.GetBytes(this._Comment);
							string string2 = ZipEntry.ibm437.GetString(bytes2, 0, bytes2.Length);
							bool flag4 = string2 != this.Comment;
							if (flag4)
							{
								bytes = this.AlternateEncoding.GetBytes(text);
								this._CommentBytes = this.AlternateEncoding.GetBytes(this._Comment);
								this._actualEncoding = this.AlternateEncoding;
								result = bytes;
							}
							else
							{
								this._CommentBytes = bytes2;
								result = bytes;
							}
						}
					}
				}
				else
				{
					bool flag5 = this._Comment != null && this._Comment.Length != 0;
					if (flag5)
					{
						this._CommentBytes = this.AlternateEncoding.GetBytes(this._Comment);
					}
					this._actualEncoding = this.AlternateEncoding;
					result = this.AlternateEncoding.GetBytes(text);
				}
			}
			else
			{
				bool flag6 = this._Comment != null && this._Comment.Length != 0;
				if (flag6)
				{
					this._CommentBytes = ZipEntry.ibm437.GetBytes(this._Comment);
				}
				this._actualEncoding = ZipEntry.ibm437;
				result = ZipEntry.ibm437.GetBytes(text);
			}
			return result;
		}

		private bool WantReadAgain()
		{
			bool flag = this._UncompressedSize < 16L;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = this._CompressionMethod == 0;
				if (flag2)
				{
					result = false;
				}
				else
				{
					bool flag3 = this.CompressionLevel == CompressionLevel.None;
					if (flag3)
					{
						result = false;
					}
					else
					{
						bool flag4 = this._CompressedSize < this._UncompressedSize;
						if (flag4)
						{
							result = false;
						}
						else
						{
							bool flag5 = this._Source == ZipEntrySource.Stream && !this._sourceStream.CanSeek;
							if (flag5)
							{
								result = false;
							}
							else
							{
								bool flag6 = this._zipCrypto_forWrite != null && this.CompressedSize - 12L <= this.UncompressedSize;
								result = !flag6;
							}
						}
					}
				}
			}
			return result;
		}

		private void MaybeUnsetCompressionMethodForWriting(int cycle)
		{
			bool flag = cycle > 1;
			if (flag)
			{
				this._CompressionMethod = 0;
			}
			else
			{
				bool isDirectory = this.IsDirectory;
				if (isDirectory)
				{
					this._CompressionMethod = 0;
				}
				else
				{
					bool flag2 = this._Source == ZipEntrySource.ZipFile;
					if (!flag2)
					{
						bool flag3 = this._Source == ZipEntrySource.Stream;
						if (flag3)
						{
							bool flag4 = this._sourceStream != null && this._sourceStream.CanSeek;
							if (flag4)
							{
								long length = this._sourceStream.Length;
								bool flag5 = length == 0L;
								if (flag5)
								{
									this._CompressionMethod = 0;
									return;
								}
							}
						}
						else
						{
							bool flag6 = this._Source == ZipEntrySource.FileSystem && SharedUtilities.GetFileLength(this.LocalFileName) == 0L;
							if (flag6)
							{
								this._CompressionMethod = 0;
								return;
							}
						}
						bool flag7 = this.SetCompression != null;
						if (flag7)
						{
							this.CompressionLevel = this.SetCompression(this.LocalFileName, this._FileNameInArchive);
						}
						bool flag8 = this.CompressionLevel == CompressionLevel.None && this.CompressionMethod == CompressionMethod.Deflate;
						if (flag8)
						{
							this._CompressionMethod = 0;
						}
					}
				}
			}
		}

		internal void WriteHeader(Stream s, int cycle)
		{
			CountingStream countingStream = s as CountingStream;
			this._future_ROLH = ((countingStream != null) ? countingStream.ComputedPosition : s.Position);
			int num = 0;
			byte[] array = new byte[30];
			array[num++] = 80;
			array[num++] = 75;
			array[num++] = 3;
			array[num++] = 4;
			this._presumeZip64 = (this._container.Zip64 == Zip64Option.Always || (this._container.Zip64 == Zip64Option.AsNecessary && !s.CanSeek));
			short num2 = this._presumeZip64 ? 45 : 20;
			array[num++] = (byte)(num2 & 255);
			array[num++] = (byte)(((int)num2 & 65280) >> 8);
			byte[] encodedFileNameBytes = this.GetEncodedFileNameBytes();
			short num3 = (short)encodedFileNameBytes.Length;
			bool flag = this._Encryption == EncryptionAlgorithm.None;
			if (flag)
			{
				this._BitField &= -2;
			}
			else
			{
				this._BitField |= 1;
			}
			bool flag2 = this._actualEncoding.CodePage == Encoding.UTF8.CodePage;
			if (flag2)
			{
				this._BitField |= 2048;
			}
			bool flag3 = this.IsDirectory || cycle == 99;
			if (flag3)
			{
				this._BitField &= -9;
				this._BitField &= -2;
				this.Encryption = EncryptionAlgorithm.None;
				this.Password = null;
			}
			else
			{
				bool flag4 = !s.CanSeek;
				if (flag4)
				{
					this._BitField |= 8;
				}
			}
			array[num++] = (byte)(this._BitField & 255);
			array[num++] = (byte)(((int)this._BitField & 65280) >> 8);
			bool flag5 = this.__FileDataPosition == -1L;
			if (flag5)
			{
				this._CompressedSize = 0L;
				this._crcCalculated = false;
			}
			this.MaybeUnsetCompressionMethodForWriting(cycle);
			array[num++] = (byte)(this._CompressionMethod & 255);
			array[num++] = (byte)(((int)this._CompressionMethod & 65280) >> 8);
			bool flag6 = cycle == 99;
			if (flag6)
			{
				this.SetZip64Flags();
			}
			this._TimeBlob = SharedUtilities.DateTimeToPacked(this.LastModified);
			array[num++] = (byte)(this._TimeBlob & 255);
			array[num++] = (byte)((this._TimeBlob & 65280) >> 8);
			array[num++] = (byte)((this._TimeBlob & 16711680) >> 16);
			array[num++] = (byte)(((long)this._TimeBlob & (long)((ulong)-16777216)) >> 24);
			array[num++] = (byte)(this._Crc32 & 255);
			array[num++] = (byte)((this._Crc32 & 65280) >> 8);
			array[num++] = (byte)((this._Crc32 & 16711680) >> 16);
			array[num++] = (byte)(((long)this._Crc32 & (long)((ulong)-16777216)) >> 24);
			bool presumeZip = this._presumeZip64;
			if (presumeZip)
			{
				for (int i = 0; i < 8; i++)
				{
					array[num++] = byte.MaxValue;
				}
			}
			else
			{
				array[num++] = (byte)(this._CompressedSize & 255L);
				array[num++] = (byte)((this._CompressedSize & 65280L) >> 8);
				array[num++] = (byte)((this._CompressedSize & 16711680L) >> 16);
				array[num++] = (byte)((this._CompressedSize & (long)((ulong)-16777216)) >> 24);
				array[num++] = (byte)(this._UncompressedSize & 255L);
				array[num++] = (byte)((this._UncompressedSize & 65280L) >> 8);
				array[num++] = (byte)((this._UncompressedSize & 16711680L) >> 16);
				array[num++] = (byte)((this._UncompressedSize & (long)((ulong)-16777216)) >> 24);
			}
			array[num++] = (byte)(num3 & 255);
			array[num++] = (byte)(((int)num3 & 65280) >> 8);
			this._Extra = this.ConstructExtraField(false);
			short num4 = (short)((this._Extra == null) ? 0 : this._Extra.Length);
			array[num++] = (byte)(num4 & 255);
			array[num++] = (byte)(((int)num4 & 65280) >> 8);
			byte[] array2 = new byte[num + (int)num3 + (int)num4];
			Buffer.BlockCopy(array, 0, array2, 0, num);
			Buffer.BlockCopy(encodedFileNameBytes, 0, array2, num, encodedFileNameBytes.Length);
			num += encodedFileNameBytes.Length;
			bool flag7 = this._Extra != null;
			if (flag7)
			{
				Buffer.BlockCopy(this._Extra, 0, array2, num, this._Extra.Length);
				num += this._Extra.Length;
			}
			this._LengthOfHeader = num;
			ZipSegmentedStream zipSegmentedStream = s as ZipSegmentedStream;
			bool flag8 = zipSegmentedStream != null;
			if (flag8)
			{
				zipSegmentedStream.ContiguousWrite = true;
				uint num5 = zipSegmentedStream.ComputeSegment(num);
				bool flag9 = num5 != zipSegmentedStream.CurrentSegment;
				if (flag9)
				{
					this._future_ROLH = 0L;
				}
				else
				{
					this._future_ROLH = zipSegmentedStream.Position;
				}
				this._diskNumber = num5;
			}
			bool flag10 = this._container.Zip64 == Zip64Option.Default && (uint)this._RelativeOffsetOfLocalHeader >= uint.MaxValue;
			if (flag10)
			{
				throw new ZipException("Offset within the zip archive exceeds 0xFFFFFFFF. Consider setting the UseZip64WhenSaving property on the ZipFile instance.");
			}
			s.Write(array2, 0, num);
			bool flag11 = zipSegmentedStream != null;
			if (flag11)
			{
				zipSegmentedStream.ContiguousWrite = false;
			}
			this._EntryHeader = array2;
		}

		private int FigureCrc32()
		{
			bool flag = !this._crcCalculated;
			if (flag)
			{
				Stream stream = null;
				bool flag2 = this._Source == ZipEntrySource.WriteDelegate;
				if (flag2)
				{
					CrcCalculatorStream crcCalculatorStream = new CrcCalculatorStream(Stream.Null);
					this._WriteDelegate(this.FileName, crcCalculatorStream);
					this._Crc32 = crcCalculatorStream.Crc;
				}
				else
				{
					bool flag3 = this._Source == ZipEntrySource.ZipFile;
					if (!flag3)
					{
						bool flag4 = this._Source == ZipEntrySource.Stream;
						if (flag4)
						{
							this.PrepSourceStream();
							stream = this._sourceStream;
						}
						else
						{
							bool flag5 = this._Source == ZipEntrySource.JitStream;
							if (flag5)
							{
								bool flag6 = this._sourceStream == null;
								if (flag6)
								{
									this._sourceStream = this._OpenDelegate(this.FileName);
								}
								this.PrepSourceStream();
								stream = this._sourceStream;
							}
							else
							{
								bool flag7 = this._Source == ZipEntrySource.ZipOutputStream;
								if (!flag7)
								{
									stream = File.Open(this.LocalFileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
								}
							}
						}
						CRC32 crc = new CRC32();
						this._Crc32 = crc.GetCrc32(stream);
						bool flag8 = this._sourceStream == null;
						if (flag8)
						{
							stream.Dispose();
						}
					}
				}
				this._crcCalculated = true;
			}
			return this._Crc32;
		}

		private void PrepSourceStream()
		{
			bool flag = this._sourceStream == null;
			if (flag)
			{
				throw new ZipException(string.Format("The input stream is null for entry '{0}'.", this.FileName));
			}
			bool flag2 = this._sourceStreamOriginalPosition != null;
			if (flag2)
			{
				this._sourceStream.Position = this._sourceStreamOriginalPosition.Value;
			}
			else
			{
				bool canSeek = this._sourceStream.CanSeek;
				if (canSeek)
				{
					this._sourceStreamOriginalPosition = new long?(this._sourceStream.Position);
				}
				else
				{
					bool flag3 = this.Encryption == EncryptionAlgorithm.PkzipWeak;
					if (flag3)
					{
						bool flag4 = this._Source != ZipEntrySource.ZipFile && (this._BitField & 8) != 8;
						if (flag4)
						{
							throw new ZipException("It is not possible to use PKZIP encryption on a non-seekable input stream");
						}
					}
				}
			}
		}

		internal void CopyMetaData(ZipEntry source)
		{
			this.__FileDataPosition = source.__FileDataPosition;
			this.CompressionMethod = source.CompressionMethod;
			this._CompressionMethod_FromZipFile = source._CompressionMethod_FromZipFile;
			this._CompressedFileDataSize = source._CompressedFileDataSize;
			this._UncompressedSize = source._UncompressedSize;
			this._BitField = source._BitField;
			this._Source = source._Source;
			this._LastModified = source._LastModified;
			this._Mtime = source._Mtime;
			this._Atime = source._Atime;
			this._Ctime = source._Ctime;
			this._ntfsTimesAreSet = source._ntfsTimesAreSet;
			this._emitUnixTimes = source._emitUnixTimes;
			this._emitNtfsTimes = source._emitNtfsTimes;
		}

		private void OnWriteBlock(long bytesXferred, long totalBytesToXfer)
		{
			bool flag = this._container.ZipFile != null;
			if (flag)
			{
				this._ioOperationCanceled = this._container.ZipFile.OnSaveBlock(this, bytesXferred, totalBytesToXfer);
			}
		}

		private void _WriteEntryData(Stream s)
		{
			Stream stream = null;
			long _FileDataPosition = -1L;
			try
			{
				_FileDataPosition = s.Position;
			}
			catch (Exception)
			{
			}
			try
			{
				long num = this.SetInputAndFigureFileLength(ref stream);
				CountingStream countingStream = new CountingStream(s);
				bool flag = num != 0L;
				Stream stream2;
				Stream stream3;
				if (flag)
				{
					stream2 = this.MaybeApplyEncryption(countingStream);
					stream3 = this.MaybeApplyCompression(stream2, num);
				}
				else
				{
					stream3 = (stream2 = countingStream);
				}
				CrcCalculatorStream crcCalculatorStream = new CrcCalculatorStream(stream3, true);
				bool flag2 = this._Source == ZipEntrySource.WriteDelegate;
				if (flag2)
				{
					this._WriteDelegate(this.FileName, crcCalculatorStream);
				}
				else
				{
					byte[] array = new byte[this.BufferSize];
					int count;
					while ((count = SharedUtilities.ReadWithRetry(stream, array, 0, array.Length, this.FileName)) != 0)
					{
						crcCalculatorStream.Write(array, 0, count);
						this.OnWriteBlock(crcCalculatorStream.TotalBytesSlurped, num);
						bool ioOperationCanceled = this._ioOperationCanceled;
						if (ioOperationCanceled)
						{
							break;
						}
					}
				}
				this.FinishOutputStream(s, countingStream, stream2, stream3, crcCalculatorStream);
			}
			finally
			{
				bool flag3 = this._Source == ZipEntrySource.JitStream;
				if (flag3)
				{
					bool flag4 = this._CloseDelegate != null;
					if (flag4)
					{
						this._CloseDelegate(this.FileName, stream);
					}
				}
				else
				{
					bool flag5 = stream is FileStream;
					if (flag5)
					{
						stream.Dispose();
					}
				}
			}
			bool ioOperationCanceled2 = this._ioOperationCanceled;
			if (!ioOperationCanceled2)
			{
				this.__FileDataPosition = _FileDataPosition;
				this.PostProcessOutput(s);
			}
		}

		private long SetInputAndFigureFileLength(ref Stream input)
		{
			long result = -1L;
			bool flag = this._Source == ZipEntrySource.Stream;
			if (flag)
			{
				this.PrepSourceStream();
				input = this._sourceStream;
				try
				{
					result = this._sourceStream.Length;
				}
				catch (NotSupportedException)
				{
				}
			}
			else
			{
				bool flag2 = this._Source == ZipEntrySource.ZipFile;
				if (flag2)
				{
					string password = (this._Encryption_FromZipFile == EncryptionAlgorithm.None) ? null : (this._Password ?? this._container.Password);
					this._sourceStream = this.InternalOpenReader(password);
					this.PrepSourceStream();
					input = this._sourceStream;
					result = this._sourceStream.Length;
				}
				else
				{
					bool flag3 = this._Source == ZipEntrySource.JitStream;
					if (flag3)
					{
						bool flag4 = this._sourceStream == null;
						if (flag4)
						{
							this._sourceStream = this._OpenDelegate(this.FileName);
						}
						this.PrepSourceStream();
						input = this._sourceStream;
						try
						{
							result = this._sourceStream.Length;
						}
						catch (NotSupportedException)
						{
						}
					}
					else
					{
						bool flag5 = this._Source == ZipEntrySource.FileSystem;
						if (flag5)
						{
							FileShare fileShare = FileShare.ReadWrite;
							fileShare |= FileShare.Delete;
							input = File.Open(this.LocalFileName, FileMode.Open, FileAccess.Read, fileShare);
							result = input.Length;
						}
					}
				}
			}
			return result;
		}

		internal void FinishOutputStream(Stream s, CountingStream entryCounter, Stream encryptor, Stream compressor, CrcCalculatorStream output)
		{
			bool flag = output == null;
			if (!flag)
			{
				output.Close();
				bool flag2 = compressor is DeflateStream;
				if (flag2)
				{
					compressor.Close();
				}
				else
				{
					bool flag3 = compressor is ParallelDeflateOutputStream;
					if (flag3)
					{
						compressor.Close();
					}
				}
				encryptor.Flush();
				encryptor.Close();
				this._LengthOfTrailer = 0;
				this._UncompressedSize = output.TotalBytesSlurped;
				this._CompressedFileDataSize = entryCounter.BytesWritten;
				this._CompressedSize = this._CompressedFileDataSize;
				this._Crc32 = output.Crc;
				this.StoreRelativeOffset();
			}
		}

		internal void PostProcessOutput(Stream s)
		{
			CountingStream countingStream = s as CountingStream;
			bool flag = this._UncompressedSize == 0L && this._CompressedSize == 0L;
			if (flag)
			{
				bool flag2 = this._Source == ZipEntrySource.ZipOutputStream;
				if (flag2)
				{
					return;
				}
				bool flag3 = this._Password != null;
				if (flag3)
				{
					int num = 0;
					bool flag4 = this.Encryption == EncryptionAlgorithm.PkzipWeak;
					if (flag4)
					{
						num = 12;
					}
					bool flag5 = this._Source == ZipEntrySource.ZipOutputStream && !s.CanSeek;
					if (flag5)
					{
						throw new ZipException("Zero bytes written, encryption in use, and non-seekable output.");
					}
					bool flag6 = this.Encryption > EncryptionAlgorithm.None;
					if (flag6)
					{
						s.Seek((long)(-1 * num), SeekOrigin.Current);
						s.SetLength(s.Position);
						bool flag7 = countingStream != null;
						if (flag7)
						{
							countingStream.Adjust((long)num);
						}
						this._LengthOfHeader -= num;
						this.__FileDataPosition -= (long)num;
					}
					this._Password = null;
					this._BitField &= -2;
					int num2 = 6;
					this._EntryHeader[num2++] = (byte)(this._BitField & 255);
					this._EntryHeader[num2++] = (byte)(((int)this._BitField & 65280) >> 8);
				}
				this.CompressionMethod = CompressionMethod.None;
				this.Encryption = EncryptionAlgorithm.None;
			}
			else
			{
				bool flag8 = this._zipCrypto_forWrite != null;
				if (flag8)
				{
					bool flag9 = this.Encryption == EncryptionAlgorithm.PkzipWeak;
					if (flag9)
					{
						this._CompressedSize += 12L;
					}
				}
			}
			int num3 = 8;
			this._EntryHeader[num3++] = (byte)(this._CompressionMethod & 255);
			this._EntryHeader[num3++] = (byte)(((int)this._CompressionMethod & 65280) >> 8);
			num3 = 14;
			this._EntryHeader[num3++] = (byte)(this._Crc32 & 255);
			this._EntryHeader[num3++] = (byte)((this._Crc32 & 65280) >> 8);
			this._EntryHeader[num3++] = (byte)((this._Crc32 & 16711680) >> 16);
			this._EntryHeader[num3++] = (byte)(((long)this._Crc32 & (long)((ulong)-16777216)) >> 24);
			this.SetZip64Flags();
			short num4 = (short)((int)this._EntryHeader[26] + (int)this._EntryHeader[27] * 256);
			short num5 = (short)((int)this._EntryHeader[28] + (int)this._EntryHeader[29] * 256);
			bool value = this._OutputUsesZip64.Value;
			if (value)
			{
				this._EntryHeader[4] = 45;
				this._EntryHeader[5] = 0;
				for (int i = 0; i < 8; i++)
				{
					this._EntryHeader[num3++] = byte.MaxValue;
				}
				num3 = (int)(30 + num4);
				this._EntryHeader[num3++] = 1;
				this._EntryHeader[num3++] = 0;
				num3 += 2;
				Array.Copy(BitConverter.GetBytes(this._UncompressedSize), 0, this._EntryHeader, num3, 8);
				num3 += 8;
				Array.Copy(BitConverter.GetBytes(this._CompressedSize), 0, this._EntryHeader, num3, 8);
			}
			else
			{
				this._EntryHeader[4] = 20;
				this._EntryHeader[5] = 0;
				num3 = 18;
				this._EntryHeader[num3++] = (byte)(this._CompressedSize & 255L);
				this._EntryHeader[num3++] = (byte)((this._CompressedSize & 65280L) >> 8);
				this._EntryHeader[num3++] = (byte)((this._CompressedSize & 16711680L) >> 16);
				this._EntryHeader[num3++] = (byte)((this._CompressedSize & (long)((ulong)-16777216)) >> 24);
				this._EntryHeader[num3++] = (byte)(this._UncompressedSize & 255L);
				this._EntryHeader[num3++] = (byte)((this._UncompressedSize & 65280L) >> 8);
				this._EntryHeader[num3++] = (byte)((this._UncompressedSize & 16711680L) >> 16);
				this._EntryHeader[num3++] = (byte)((this._UncompressedSize & (long)((ulong)-16777216)) >> 24);
				bool flag10 = num5 != 0;
				if (flag10)
				{
					num3 = (int)(30 + num4);
					short num6 = (short)((int)this._EntryHeader[num3 + 2] + (int)this._EntryHeader[num3 + 3] * 256);
					bool flag11 = num6 == 16;
					if (flag11)
					{
						this._EntryHeader[num3++] = 153;
						this._EntryHeader[num3++] = 153;
					}
				}
			}
			bool flag12 = (this._BitField & 8) != 8 || (this._Source == ZipEntrySource.ZipOutputStream && s.CanSeek);
			if (flag12)
			{
				ZipSegmentedStream zipSegmentedStream = s as ZipSegmentedStream;
				bool flag13 = zipSegmentedStream != null && this._diskNumber != zipSegmentedStream.CurrentSegment;
				if (flag13)
				{
					using (Stream stream = ZipSegmentedStream.ForUpdate(this._container.ZipFile.Name, this._diskNumber))
					{
						stream.Seek(this._RelativeOffsetOfLocalHeader, SeekOrigin.Begin);
						stream.Write(this._EntryHeader, 0, this._EntryHeader.Length);
					}
				}
				else
				{
					s.Seek(this._RelativeOffsetOfLocalHeader, SeekOrigin.Begin);
					s.Write(this._EntryHeader, 0, this._EntryHeader.Length);
					bool flag14 = countingStream != null;
					if (flag14)
					{
						countingStream.Adjust((long)this._EntryHeader.Length);
					}
					s.Seek(this._CompressedSize, SeekOrigin.Current);
				}
			}
			bool flag15 = (this._BitField & 8) == 8 && !this.IsDirectory;
			if (flag15)
			{
				byte[] array = new byte[16 + (this._OutputUsesZip64.Value ? 8 : 0)];
				num3 = 0;
				Array.Copy(BitConverter.GetBytes(134695760), 0, array, num3, 4);
				num3 += 4;
				Array.Copy(BitConverter.GetBytes(this._Crc32), 0, array, num3, 4);
				num3 += 4;
				bool value2 = this._OutputUsesZip64.Value;
				if (value2)
				{
					Array.Copy(BitConverter.GetBytes(this._CompressedSize), 0, array, num3, 8);
					num3 += 8;
					Array.Copy(BitConverter.GetBytes(this._UncompressedSize), 0, array, num3, 8);
					num3 += 8;
				}
				else
				{
					array[num3++] = (byte)(this._CompressedSize & 255L);
					array[num3++] = (byte)((this._CompressedSize & 65280L) >> 8);
					array[num3++] = (byte)((this._CompressedSize & 16711680L) >> 16);
					array[num3++] = (byte)((this._CompressedSize & (long)((ulong)-16777216)) >> 24);
					array[num3++] = (byte)(this._UncompressedSize & 255L);
					array[num3++] = (byte)((this._UncompressedSize & 65280L) >> 8);
					array[num3++] = (byte)((this._UncompressedSize & 16711680L) >> 16);
					array[num3++] = (byte)((this._UncompressedSize & (long)((ulong)-16777216)) >> 24);
				}
				s.Write(array, 0, array.Length);
				this._LengthOfTrailer += array.Length;
			}
		}

		private void SetZip64Flags()
		{
			this._entryRequiresZip64 = new bool?(this._CompressedSize >= (long)((ulong)-1) || this._UncompressedSize >= (long)((ulong)-1) || this._RelativeOffsetOfLocalHeader >= (long)((ulong)-1));
			bool flag = this._container.Zip64 == Zip64Option.Default && this._entryRequiresZip64.Value;
			if (flag)
			{
				throw new ZipException("Compressed or Uncompressed size, or offset exceeds the maximum value. Consider setting the UseZip64WhenSaving property on the ZipFile instance.");
			}
			this._OutputUsesZip64 = new bool?(this._container.Zip64 == Zip64Option.Always || this._entryRequiresZip64.Value);
		}

		internal void PrepOutputStream(Stream s, long streamLength, out CountingStream outputCounter, out Stream encryptor, out Stream compressor, out CrcCalculatorStream output)
		{
			outputCounter = new CountingStream(s);
			bool flag = streamLength != 0L;
			if (flag)
			{
				encryptor = this.MaybeApplyEncryption(outputCounter);
				compressor = this.MaybeApplyCompression(encryptor, streamLength);
			}
			else
			{
				Stream stream;
				compressor = (stream = outputCounter);
				encryptor = stream;
			}
			output = new CrcCalculatorStream(compressor, true);
		}

		private Stream MaybeApplyCompression(Stream s, long streamLength)
		{
			bool flag = this._CompressionMethod == 8 && this.CompressionLevel > CompressionLevel.None;
			Stream result;
			if (flag)
			{
				bool flag2 = this._container.ParallelDeflateThreshold == 0L || (streamLength > this._container.ParallelDeflateThreshold && this._container.ParallelDeflateThreshold > 0L);
				if (flag2)
				{
					bool flag3 = this._container.ParallelDeflater == null;
					if (flag3)
					{
						this._container.ParallelDeflater = new ParallelDeflateOutputStream(s, this.CompressionLevel, this._container.Strategy, true);
						bool flag4 = this._container.CodecBufferSize > 0;
						if (flag4)
						{
							this._container.ParallelDeflater.BufferSize = this._container.CodecBufferSize;
						}
						bool flag5 = this._container.ParallelDeflateMaxBufferPairs > 0;
						if (flag5)
						{
							this._container.ParallelDeflater.MaxBufferPairs = this._container.ParallelDeflateMaxBufferPairs;
						}
					}
					ParallelDeflateOutputStream parallelDeflater = this._container.ParallelDeflater;
					parallelDeflater.Reset(s);
					result = parallelDeflater;
				}
				else
				{
					DeflateStream deflateStream = new DeflateStream(s, CompressionMode.Compress, this.CompressionLevel, true);
					bool flag6 = this._container.CodecBufferSize > 0;
					if (flag6)
					{
						deflateStream.BufferSize = this._container.CodecBufferSize;
					}
					deflateStream.Strategy = this._container.Strategy;
					result = deflateStream;
				}
			}
			else
			{
				result = s;
			}
			return result;
		}

		private Stream MaybeApplyEncryption(Stream s)
		{
			bool flag = this.Encryption == EncryptionAlgorithm.PkzipWeak;
			Stream result;
			if (flag)
			{
				result = new ZipCipherStream(s, this._zipCrypto_forWrite, CryptoMode.Encrypt);
			}
			else
			{
				result = s;
			}
			return result;
		}

		private void OnZipErrorWhileSaving(Exception e)
		{
			bool flag = this._container.ZipFile != null;
			if (flag)
			{
				this._ioOperationCanceled = this._container.ZipFile.OnZipErrorSaving(this, e);
			}
		}

		internal void Write(Stream s)
		{
			CountingStream countingStream = s as CountingStream;
			ZipSegmentedStream zipSegmentedStream = s as ZipSegmentedStream;
			bool flag = false;
			do
			{
				try
				{
					bool flag2 = this._Source == ZipEntrySource.ZipFile && !this._restreamRequiredOnSave;
					if (flag2)
					{
						this.CopyThroughOneEntry(s);
						break;
					}
					bool isDirectory = this.IsDirectory;
					if (isDirectory)
					{
						this.WriteHeader(s, 1);
						this.StoreRelativeOffset();
						this._entryRequiresZip64 = new bool?(this._RelativeOffsetOfLocalHeader >= (long)((ulong)-1));
						this._OutputUsesZip64 = new bool?(this._container.Zip64 == Zip64Option.Always || this._entryRequiresZip64.Value);
						bool flag3 = zipSegmentedStream != null;
						if (flag3)
						{
							this._diskNumber = zipSegmentedStream.CurrentSegment;
						}
						break;
					}
					int num = 0;
					bool flag5;
					do
					{
						num++;
						this.WriteHeader(s, num);
						this.WriteSecurityMetadata(s);
						this._WriteEntryData(s);
						this._TotalEntrySize = (long)this._LengthOfHeader + this._CompressedFileDataSize + (long)this._LengthOfTrailer;
						bool flag4 = num > 1;
						if (flag4)
						{
							flag5 = false;
						}
						else
						{
							bool flag6 = !s.CanSeek;
							flag5 = (!flag6 && this.WantReadAgain());
						}
						bool flag7 = flag5;
						if (flag7)
						{
							bool flag8 = zipSegmentedStream != null;
							if (flag8)
							{
								zipSegmentedStream.TruncateBackward(this._diskNumber, this._RelativeOffsetOfLocalHeader);
							}
							else
							{
								s.Seek(this._RelativeOffsetOfLocalHeader, SeekOrigin.Begin);
							}
							s.SetLength(s.Position);
							bool flag9 = countingStream != null;
							if (flag9)
							{
								countingStream.Adjust(this._TotalEntrySize);
							}
						}
					}
					while (flag5);
					this._skippedDuringSave = false;
					flag = true;
				}
				catch (Exception ex)
				{
					ZipErrorAction zipErrorAction = this.ZipErrorAction;
					int num2 = 0;
					for (;;)
					{
						bool flag10 = this.ZipErrorAction == ZipErrorAction.Throw;
						if (flag10)
						{
							break;
						}
						bool flag11 = this.ZipErrorAction == ZipErrorAction.Skip || this.ZipErrorAction == ZipErrorAction.Retry;
						if (flag11)
						{
							goto Block_17;
						}
						bool flag12 = num2 > 0;
						if (flag12)
						{
							goto Block_22;
						}
						bool flag13 = this.ZipErrorAction == ZipErrorAction.InvokeErrorEvent;
						if (flag13)
						{
							this.OnZipErrorWhileSaving(ex);
							bool ioOperationCanceled = this._ioOperationCanceled;
							if (ioOperationCanceled)
							{
								goto Block_24;
							}
						}
						num2++;
					}
					throw;
					Block_17:
					long num3 = (countingStream != null) ? countingStream.ComputedPosition : s.Position;
					long num4 = num3 - this._future_ROLH;
					bool flag14 = num4 > 0L;
					if (flag14)
					{
						s.Seek(num4, SeekOrigin.Current);
						long position = s.Position;
						s.SetLength(s.Position);
						bool flag15 = countingStream != null;
						if (flag15)
						{
							countingStream.Adjust(num3 - position);
						}
					}
					bool flag16 = this.ZipErrorAction == ZipErrorAction.Skip;
					if (flag16)
					{
						this.WriteStatus("Skipping file {0} (exception: {1})", new object[]
						{
							this.LocalFileName,
							ex.ToString()
						});
						this._skippedDuringSave = true;
						flag = true;
					}
					else
					{
						this.ZipErrorAction = zipErrorAction;
					}
					goto IL_2C7;
					Block_22:
					throw;
					Block_24:
					flag = true;
					IL_2C7:;
				}
			}
			while (!flag);
		}

		internal void StoreRelativeOffset()
		{
			this._RelativeOffsetOfLocalHeader = this._future_ROLH;
		}

		internal void NotifySaveComplete()
		{
			this._Encryption_FromZipFile = this._Encryption;
			this._CompressionMethod_FromZipFile = this._CompressionMethod;
			this._restreamRequiredOnSave = false;
			this._metadataChanged = false;
			this._Source = ZipEntrySource.ZipFile;
		}

		internal void WriteSecurityMetadata(Stream outstream)
		{
			bool flag = this.Encryption == EncryptionAlgorithm.None;
			if (!flag)
			{
				string password = this._Password;
				bool flag2 = this._Source == ZipEntrySource.ZipFile && password == null;
				if (flag2)
				{
					password = this._container.Password;
				}
				bool flag3 = password == null;
				if (flag3)
				{
					this._zipCrypto_forWrite = null;
				}
				else
				{
					bool flag4 = this.Encryption == EncryptionAlgorithm.PkzipWeak;
					if (flag4)
					{
						this._zipCrypto_forWrite = ZipCrypto.ForWrite(password);
						Random random = new Random();
						byte[] array = new byte[12];
						random.NextBytes(array);
						bool flag5 = (this._BitField & 8) == 8;
						if (flag5)
						{
							this._TimeBlob = SharedUtilities.DateTimeToPacked(this.LastModified);
							array[11] = (byte)(this._TimeBlob >> 8 & 255);
						}
						else
						{
							this.FigureCrc32();
							array[11] = (byte)(this._Crc32 >> 24 & 255);
						}
						byte[] array2 = this._zipCrypto_forWrite.EncryptMessage(array, array.Length);
						outstream.Write(array2, 0, array2.Length);
						this._LengthOfHeader += array2.Length;
					}
				}
			}
		}

		private void CopyThroughOneEntry(Stream outStream)
		{
			bool flag = this.LengthOfHeader == 0;
			if (flag)
			{
				throw new BadStateException("Bad header length.");
			}
			bool flag2 = this._metadataChanged || this.ArchiveStream is ZipSegmentedStream || outStream is ZipSegmentedStream || (this._InputUsesZip64 && this._container.UseZip64WhenSaving == Zip64Option.Default) || (!this._InputUsesZip64 && this._container.UseZip64WhenSaving == Zip64Option.Always);
			bool flag3 = flag2;
			if (flag3)
			{
				this.CopyThroughWithRecompute(outStream);
			}
			else
			{
				this.CopyThroughWithNoChange(outStream);
			}
			this._entryRequiresZip64 = new bool?(this._CompressedSize >= (long)((ulong)-1) || this._UncompressedSize >= (long)((ulong)-1) || this._RelativeOffsetOfLocalHeader >= (long)((ulong)-1));
			this._OutputUsesZip64 = new bool?(this._container.Zip64 == Zip64Option.Always || this._entryRequiresZip64.Value);
		}

		private void CopyThroughWithRecompute(Stream outstream)
		{
			byte[] array = new byte[this.BufferSize];
			CountingStream countingStream = new CountingStream(this.ArchiveStream);
			long relativeOffsetOfLocalHeader = this._RelativeOffsetOfLocalHeader;
			int lengthOfHeader = this.LengthOfHeader;
			this.WriteHeader(outstream, 0);
			this.StoreRelativeOffset();
			bool flag = !this.FileName.EndsWith("/");
			if (flag)
			{
				long num = relativeOffsetOfLocalHeader + (long)lengthOfHeader;
				int num2 = ZipEntry.GetLengthOfCryptoHeaderBytes(this._Encryption_FromZipFile);
				num -= (long)num2;
				this._LengthOfHeader += num2;
				countingStream.Seek(num, SeekOrigin.Begin);
				long num3 = this._CompressedSize;
				while (num3 > 0L)
				{
					num2 = ((num3 > (long)array.Length) ? array.Length : ((int)num3));
					int num4 = countingStream.Read(array, 0, num2);
					outstream.Write(array, 0, num4);
					num3 -= (long)num4;
					this.OnWriteBlock(countingStream.BytesRead, this._CompressedSize);
					bool ioOperationCanceled = this._ioOperationCanceled;
					if (ioOperationCanceled)
					{
						break;
					}
				}
				bool flag2 = (this._BitField & 8) == 8;
				if (flag2)
				{
					int num5 = 16;
					bool inputUsesZip = this._InputUsesZip64;
					if (inputUsesZip)
					{
						num5 += 8;
					}
					byte[] buffer = new byte[num5];
					countingStream.Read(buffer, 0, num5);
					bool flag3 = this._InputUsesZip64 && this._container.UseZip64WhenSaving == Zip64Option.Default;
					if (flag3)
					{
						outstream.Write(buffer, 0, 8);
						bool flag4 = this._CompressedSize > (long)((ulong)-1);
						if (flag4)
						{
							throw new InvalidOperationException("ZIP64 is required");
						}
						outstream.Write(buffer, 8, 4);
						bool flag5 = this._UncompressedSize > (long)((ulong)-1);
						if (flag5)
						{
							throw new InvalidOperationException("ZIP64 is required");
						}
						outstream.Write(buffer, 16, 4);
						this._LengthOfTrailer -= 8;
					}
					else
					{
						bool flag6 = !this._InputUsesZip64 && this._container.UseZip64WhenSaving == Zip64Option.Always;
						if (flag6)
						{
							byte[] buffer2 = new byte[4];
							outstream.Write(buffer, 0, 8);
							outstream.Write(buffer, 8, 4);
							outstream.Write(buffer2, 0, 4);
							outstream.Write(buffer, 12, 4);
							outstream.Write(buffer2, 0, 4);
							this._LengthOfTrailer += 8;
						}
						else
						{
							outstream.Write(buffer, 0, num5);
						}
					}
				}
			}
			this._TotalEntrySize = (long)this._LengthOfHeader + this._CompressedFileDataSize + (long)this._LengthOfTrailer;
		}

		private void CopyThroughWithNoChange(Stream outstream)
		{
			byte[] array = new byte[this.BufferSize];
			CountingStream countingStream = new CountingStream(this.ArchiveStream);
			countingStream.Seek(this._RelativeOffsetOfLocalHeader, SeekOrigin.Begin);
			bool flag = this._TotalEntrySize == 0L;
			if (flag)
			{
				this._TotalEntrySize = (long)this._LengthOfHeader + this._CompressedFileDataSize + (long)this._LengthOfTrailer;
			}
			CountingStream countingStream2 = outstream as CountingStream;
			this._RelativeOffsetOfLocalHeader = ((countingStream2 != null) ? countingStream2.ComputedPosition : outstream.Position);
			long num = this._TotalEntrySize;
			while (num > 0L)
			{
				int count = (num > (long)array.Length) ? array.Length : ((int)num);
				int num2 = countingStream.Read(array, 0, count);
				outstream.Write(array, 0, num2);
				num -= (long)num2;
				this.OnWriteBlock(countingStream.BytesRead, this._TotalEntrySize);
				bool ioOperationCanceled = this._ioOperationCanceled;
				if (ioOperationCanceled)
				{
					break;
				}
			}
		}

		[Conditional("Trace")]
		private void TraceWriteLine(string format, params object[] varParams)
		{
			object outputLock = this._outputLock;
			lock (outputLock)
			{
				int hashCode = Thread.CurrentThread.GetHashCode();
				Console.ForegroundColor = hashCode % 8 + ConsoleColor.DarkGray;
				Console.Write("{0:000} ZipEntry.Write ", hashCode);
				Console.WriteLine(format, varParams);
				Console.ResetColor();
			}
		}

		private short _VersionMadeBy;

		private short _InternalFileAttrs;

		private int _ExternalFileAttrs;

		private short _filenameLength;

		private short _extraFieldLength;

		private short _commentLength;

		private ZipCrypto _zipCrypto_forExtract;

		private ZipCrypto _zipCrypto_forWrite;

		internal DateTime _LastModified;

		private DateTime _Mtime;

		private DateTime _Atime;

		private DateTime _Ctime;

		private bool _ntfsTimesAreSet;

		private bool _emitNtfsTimes = true;

		private bool _emitUnixTimes;

		private bool _TrimVolumeFromFullyQualifiedPaths = true;

		internal string _LocalFileName;

		private string _FileNameInArchive;

		internal short _VersionNeeded;

		internal short _BitField;

		internal short _CompressionMethod;

		private short _CompressionMethod_FromZipFile;

		private CompressionLevel _CompressionLevel;

		internal string _Comment;

		private bool _IsDirectory;

		private byte[] _CommentBytes;

		internal long _CompressedSize;

		internal long _CompressedFileDataSize;

		internal long _UncompressedSize;

		internal int _TimeBlob;

		private bool _crcCalculated;

		internal int _Crc32;

		internal byte[] _Extra;

		private bool _metadataChanged;

		private bool _restreamRequiredOnSave;

		private bool _sourceIsEncrypted;

		private bool _skippedDuringSave;

		private uint _diskNumber;

		private static Encoding ibm437 = Encoding.GetEncoding("IBM437");

		private Encoding _actualEncoding;

		internal ZipContainer _container;

		private long __FileDataPosition = -1L;

		private byte[] _EntryHeader;

		internal long _RelativeOffsetOfLocalHeader;

		private long _future_ROLH;

		private long _TotalEntrySize;

		private int _LengthOfHeader;

		private int _LengthOfTrailer;

		internal bool _InputUsesZip64;

		private uint _UnsupportedAlgorithmId;

		internal string _Password;

		internal ZipEntrySource _Source;

		internal EncryptionAlgorithm _Encryption;

		internal EncryptionAlgorithm _Encryption_FromZipFile;

		internal byte[] _WeakEncryptionHeader;

		internal Stream _archiveStream;

		private Stream _sourceStream;

		private long? _sourceStreamOriginalPosition;

		private bool _sourceWasJitProvided;

		private bool _ioOperationCanceled;

		private bool _presumeZip64;

		private bool? _entryRequiresZip64;

		private bool? _OutputUsesZip64;

		private bool _IsText;

		private ZipEntryTimestamp _timestamp;

		private static DateTime _unixEpoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

		private static DateTime _win32Epoch = DateTime.FromFileTimeUtc(0L);

		private static DateTime _zeroHour = new DateTime(1, 1, 1, 0, 0, 0, DateTimeKind.Utc);

		private WriteDelegate _WriteDelegate;

		private OpenDelegate _OpenDelegate;

		private CloseDelegate _CloseDelegate;

		private Stream _inputDecryptorStream;

		private int _readExtraDepth;

		private object _outputLock = new object();

		private class CopyHelper
		{
			internal static string AppendCopyToFileName(string f)
			{
				ZipEntry.CopyHelper.callCount++;
				bool flag = ZipEntry.CopyHelper.callCount > 25;
				if (flag)
				{
					throw new OverflowException("overflow while creating filename");
				}
				int num = 1;
				int num2 = f.LastIndexOf(".");
				bool flag2 = num2 == -1;
				if (flag2)
				{
					Match match = ZipEntry.CopyHelper.re.Match(f);
					bool success = match.Success;
					if (success)
					{
						num = int.Parse(match.Groups[1].Value) + 1;
						string str = string.Format(" (copy {0})", num);
						f = f.Substring(0, match.Index) + str;
					}
					else
					{
						string str2 = string.Format(" (copy {0})", num);
						f += str2;
					}
				}
				else
				{
					Match match2 = ZipEntry.CopyHelper.re.Match(f.Substring(0, num2));
					bool success2 = match2.Success;
					if (success2)
					{
						num = int.Parse(match2.Groups[1].Value) + 1;
						string str3 = string.Format(" (copy {0})", num);
						f = f.Substring(0, match2.Index) + str3 + f.Substring(num2);
					}
					else
					{
						string str4 = string.Format(" (copy {0})", num);
						f = f.Substring(0, num2) + str4 + f.Substring(num2);
					}
				}
				return f;
			}

			private static Regex re = new Regex(" \\(copy (\\d+)\\)$");

			private static int callCount = 0;
		}

		private delegate T Func<T>();
	}
}
