﻿using System;

namespace Ionic.Zip
{
	public enum Zip64Option
	{
		Default,
		Never = 0,
		AsNecessary,
		Always
	}
}
