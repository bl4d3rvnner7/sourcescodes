﻿using System;
using System.IO;
using System.Text;
using Ionic.Crc;

namespace Ionic.Zip
{
	public class ZipInputStream : Stream
	{
		public ZipInputStream(Stream stream) : this(stream, false)
		{
		}

		public ZipInputStream(string fileName)
		{
			Stream stream = File.Open(fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
			this._Init(stream, false, fileName);
		}

		public ZipInputStream(Stream stream, bool leaveOpen)
		{
			this._Init(stream, leaveOpen, null);
		}

		private void _Init(Stream stream, bool leaveOpen, string name)
		{
			this._inputStream = stream;
			bool flag = !this._inputStream.CanRead;
			if (flag)
			{
				throw new ZipException("The stream must be readable.");
			}
			this._container = new ZipContainer(this);
			this._provisionalAlternateEncoding = Encoding.GetEncoding("IBM437");
			this._leaveUnderlyingStreamOpen = leaveOpen;
			this._findRequired = true;
			this._name = (name ?? "(stream)");
		}

		public override string ToString()
		{
			return string.Format("ZipInputStream::{0}(leaveOpen({1})))", this._name, this._leaveUnderlyingStreamOpen);
		}

		public Encoding ProvisionalAlternateEncoding
		{
			get
			{
				return this._provisionalAlternateEncoding;
			}
			set
			{
				this._provisionalAlternateEncoding = value;
			}
		}

		public int CodecBufferSize { get; set; }

		public string Password
		{
			set
			{
				bool closed = this._closed;
				if (closed)
				{
					this._exceptionPending = true;
					throw new InvalidOperationException("The stream has been closed.");
				}
				this._Password = value;
			}
		}

		private void SetupStream()
		{
			this._crcStream = this._currentEntry.InternalOpenReader(this._Password);
			this._LeftToRead = this._crcStream.Length;
			this._needSetup = false;
		}

		internal Stream ReadStream
		{
			get
			{
				return this._inputStream;
			}
		}

		public override int Read(byte[] buffer, int offset, int count)
		{
			bool closed = this._closed;
			if (closed)
			{
				this._exceptionPending = true;
				throw new InvalidOperationException("The stream has been closed.");
			}
			bool needSetup = this._needSetup;
			if (needSetup)
			{
				this.SetupStream();
			}
			bool flag = this._LeftToRead == 0L;
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				int count2 = (this._LeftToRead > (long)count) ? count : ((int)this._LeftToRead);
				int num = this._crcStream.Read(buffer, offset, count2);
				this._LeftToRead -= (long)num;
				bool flag2 = this._LeftToRead == 0L;
				if (flag2)
				{
					int crc = this._crcStream.Crc;
					this._currentEntry.VerifyCrcAfterExtract(crc);
					this._inputStream.Seek(this._endOfEntry, SeekOrigin.Begin);
				}
				result = num;
			}
			return result;
		}

		public ZipEntry GetNextEntry()
		{
			bool findRequired = this._findRequired;
			if (findRequired)
			{
				long num = SharedUtilities.FindSignature(this._inputStream, 67324752);
				bool flag = num == -1L;
				if (flag)
				{
					return null;
				}
				this._inputStream.Seek(-4L, SeekOrigin.Current);
			}
			else
			{
				bool firstEntry = this._firstEntry;
				if (firstEntry)
				{
					this._inputStream.Seek(this._endOfEntry, SeekOrigin.Begin);
				}
			}
			this._currentEntry = ZipEntry.ReadEntry(this._container, !this._firstEntry);
			this._endOfEntry = this._inputStream.Position;
			this._firstEntry = true;
			this._needSetup = true;
			this._findRequired = false;
			return this._currentEntry;
		}

		protected override void Dispose(bool disposing)
		{
			bool closed = this._closed;
			if (!closed)
			{
				if (disposing)
				{
					bool exceptionPending = this._exceptionPending;
					if (exceptionPending)
					{
						return;
					}
					bool flag = !this._leaveUnderlyingStreamOpen;
					if (flag)
					{
						this._inputStream.Dispose();
					}
				}
				this._closed = true;
			}
		}

		public override bool CanRead
		{
			get
			{
				return true;
			}
		}

		public override bool CanSeek
		{
			get
			{
				return this._inputStream.CanSeek;
			}
		}

		public override bool CanWrite
		{
			get
			{
				return false;
			}
		}

		public override long Length
		{
			get
			{
				return this._inputStream.Length;
			}
		}

		public override long Position
		{
			get
			{
				return this._inputStream.Position;
			}
			set
			{
				this.Seek(value, SeekOrigin.Begin);
			}
		}

		public override void Flush()
		{
			throw new NotSupportedException("Flush");
		}

		public override void Write(byte[] buffer, int offset, int count)
		{
			throw new NotSupportedException("Write");
		}

		public override long Seek(long offset, SeekOrigin origin)
		{
			this._findRequired = true;
			return this._inputStream.Seek(offset, origin);
		}

		public override void SetLength(long value)
		{
			throw new NotSupportedException();
		}

		private Stream _inputStream;

		private Encoding _provisionalAlternateEncoding;

		private ZipEntry _currentEntry;

		private bool _firstEntry;

		private bool _needSetup;

		private ZipContainer _container;

		private CrcCalculatorStream _crcStream;

		private long _LeftToRead;

		internal string _Password;

		private long _endOfEntry;

		private string _name;

		private bool _leaveUnderlyingStreamOpen;

		private bool _closed;

		private bool _findRequired;

		private bool _exceptionPending;
	}
}
