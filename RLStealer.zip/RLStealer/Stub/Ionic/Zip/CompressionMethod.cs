﻿using System;

namespace Ionic.Zip
{
	public enum CompressionMethod
	{
		None,
		Deflate = 8
	}
}
