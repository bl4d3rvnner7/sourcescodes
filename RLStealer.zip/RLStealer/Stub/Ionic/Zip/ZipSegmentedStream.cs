﻿using System;
using System.IO;

namespace Ionic.Zip
{
	internal class ZipSegmentedStream : Stream
	{
		private ZipSegmentedStream()
		{
			this._exceptionPending = false;
		}

		public static ZipSegmentedStream ForReading(string name, uint initialDiskNumber, uint maxDiskNumber)
		{
			ZipSegmentedStream zipSegmentedStream = new ZipSegmentedStream
			{
				rwMode = ZipSegmentedStream.RwMode.ReadOnly,
				CurrentSegment = initialDiskNumber,
				_maxDiskNumber = maxDiskNumber,
				_baseName = name
			};
			zipSegmentedStream._SetReadStream();
			return zipSegmentedStream;
		}

		public static ZipSegmentedStream ForWriting(string name, int maxSegmentSize)
		{
			ZipSegmentedStream zipSegmentedStream = new ZipSegmentedStream
			{
				rwMode = ZipSegmentedStream.RwMode.Write,
				CurrentSegment = 0U,
				_baseName = name,
				_maxSegmentSize = maxSegmentSize,
				_baseDir = Path.GetDirectoryName(name)
			};
			bool flag = zipSegmentedStream._baseDir == "";
			if (flag)
			{
				zipSegmentedStream._baseDir = ".";
			}
			zipSegmentedStream._SetWriteStream(0U);
			return zipSegmentedStream;
		}

		public static Stream ForUpdate(string name, uint diskNumber)
		{
			bool flag = diskNumber >= 99U;
			if (flag)
			{
				throw new ArgumentOutOfRangeException("diskNumber");
			}
			string path = string.Format("{0}.z{1:D2}", Path.Combine(Path.GetDirectoryName(name), Path.GetFileNameWithoutExtension(name)), diskNumber + 1U);
			return File.Open(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
		}

		public bool ContiguousWrite { get; set; }

		public uint CurrentSegment
		{
			get
			{
				return this._currentDiskNumber;
			}
			private set
			{
				this._currentDiskNumber = value;
				this._currentName = null;
			}
		}

		public string CurrentName
		{
			get
			{
				bool flag = this._currentName == null;
				if (flag)
				{
					this._currentName = this._NameForSegment(this.CurrentSegment);
				}
				return this._currentName;
			}
		}

		public string CurrentTempName
		{
			get
			{
				return this._currentTempName;
			}
		}

		private string _NameForSegment(uint diskNumber)
		{
			bool flag = diskNumber >= 99U;
			if (flag)
			{
				this._exceptionPending = true;
				throw new OverflowException("The number of zip segments would exceed 99.");
			}
			return string.Format("{0}.z{1:D2}", Path.Combine(Path.GetDirectoryName(this._baseName), Path.GetFileNameWithoutExtension(this._baseName)), diskNumber + 1U);
		}

		public uint ComputeSegment(int length)
		{
			bool flag = this._innerStream.Position + (long)length > (long)this._maxSegmentSize;
			uint result;
			if (flag)
			{
				result = this.CurrentSegment + 1U;
			}
			else
			{
				result = this.CurrentSegment;
			}
			return result;
		}

		public override string ToString()
		{
			return string.Format("{0}[{1}][{2}], pos=0x{3:X})", new object[]
			{
				"ZipSegmentedStream",
				this.CurrentName,
				this.rwMode.ToString(),
				this.Position
			});
		}

		private void _SetReadStream()
		{
			bool flag = this._innerStream != null;
			if (flag)
			{
				this._innerStream.Dispose();
			}
			bool flag2 = this.CurrentSegment + 1U == this._maxDiskNumber;
			if (flag2)
			{
				this._currentName = this._baseName;
			}
			this._innerStream = File.OpenRead(this.CurrentName);
		}

		public override int Read(byte[] buffer, int offset, int count)
		{
			bool flag = this.rwMode != ZipSegmentedStream.RwMode.ReadOnly;
			if (flag)
			{
				this._exceptionPending = true;
				throw new InvalidOperationException("Stream Error: Cannot Read.");
			}
			int num = this._innerStream.Read(buffer, offset, count);
			int num2 = num;
			while (num2 != count)
			{
				bool flag2 = this._innerStream.Position != this._innerStream.Length;
				if (flag2)
				{
					this._exceptionPending = true;
					throw new ZipException(string.Format("Read error in file {0}", this.CurrentName));
				}
				bool flag3 = this.CurrentSegment + 1U == this._maxDiskNumber;
				if (flag3)
				{
					return num;
				}
				uint currentSegment = this.CurrentSegment;
				this.CurrentSegment = currentSegment + 1U;
				this._SetReadStream();
				offset += num2;
				count -= num2;
				num2 = this._innerStream.Read(buffer, offset, count);
				num += num2;
			}
			return num;
		}

		private void _SetWriteStream(uint increment)
		{
			bool flag = this._innerStream != null;
			if (flag)
			{
				this._innerStream.Dispose();
				bool flag2 = File.Exists(this.CurrentName);
				if (flag2)
				{
					File.Delete(this.CurrentName);
				}
				File.Move(this._currentTempName, this.CurrentName);
			}
			bool flag3 = increment > 0U;
			if (flag3)
			{
				this.CurrentSegment += increment;
			}
			SharedUtilities.CreateAndOpenUniqueTempFile(this._baseDir, out this._innerStream, out this._currentTempName);
			bool flag4 = this.CurrentSegment == 0U;
			if (flag4)
			{
				this._innerStream.Write(BitConverter.GetBytes(134695760), 0, 4);
			}
		}

		public override void Write(byte[] buffer, int offset, int count)
		{
			bool flag = this.rwMode != ZipSegmentedStream.RwMode.Write;
			if (flag)
			{
				this._exceptionPending = true;
				throw new InvalidOperationException("Stream Error: Cannot Write.");
			}
			bool contiguousWrite = this.ContiguousWrite;
			if (contiguousWrite)
			{
				bool flag2 = this._innerStream.Position + (long)count > (long)this._maxSegmentSize;
				if (flag2)
				{
					this._SetWriteStream(1U);
				}
			}
			else
			{
				while (this._innerStream.Position + (long)count > (long)this._maxSegmentSize)
				{
					int num = this._maxSegmentSize - (int)this._innerStream.Position;
					this._innerStream.Write(buffer, offset, num);
					this._SetWriteStream(1U);
					count -= num;
					offset += num;
				}
			}
			this._innerStream.Write(buffer, offset, count);
		}

		public long TruncateBackward(uint diskNumber, long offset)
		{
			bool flag = diskNumber >= 99U;
			if (flag)
			{
				throw new ArgumentOutOfRangeException("diskNumber");
			}
			bool flag2 = this.rwMode != ZipSegmentedStream.RwMode.Write;
			if (flag2)
			{
				this._exceptionPending = true;
				throw new ZipException("bad state.");
			}
			bool flag3 = diskNumber == this.CurrentSegment;
			long result;
			if (flag3)
			{
				long num = this._innerStream.Seek(offset, SeekOrigin.Begin);
				result = num;
			}
			else
			{
				bool flag4 = this._innerStream != null;
				if (flag4)
				{
					this._innerStream.Dispose();
					bool flag5 = File.Exists(this._currentTempName);
					if (flag5)
					{
						File.Delete(this._currentTempName);
					}
				}
				for (uint num2 = this.CurrentSegment - 1U; num2 > diskNumber; num2 -= 1U)
				{
					string path = this._NameForSegment(num2);
					bool flag6 = File.Exists(path);
					if (flag6)
					{
						File.Delete(path);
					}
				}
				this.CurrentSegment = diskNumber;
				for (int i = 0; i < 3; i++)
				{
					try
					{
						this._currentTempName = SharedUtilities.InternalGetTempFileName();
						File.Move(this.CurrentName, this._currentTempName);
						break;
					}
					catch (IOException)
					{
						bool flag7 = i == 2;
						if (flag7)
						{
							throw;
						}
					}
				}
				this._innerStream = new FileStream(this._currentTempName, FileMode.Open);
				long num3 = this._innerStream.Seek(offset, SeekOrigin.Begin);
				result = num3;
			}
			return result;
		}

		public override bool CanRead
		{
			get
			{
				return this.rwMode == ZipSegmentedStream.RwMode.ReadOnly && this._innerStream != null && this._innerStream.CanRead;
			}
		}

		public override bool CanSeek
		{
			get
			{
				return this._innerStream != null && this._innerStream.CanSeek;
			}
		}

		public override bool CanWrite
		{
			get
			{
				return this.rwMode == ZipSegmentedStream.RwMode.Write && this._innerStream != null && this._innerStream.CanWrite;
			}
		}

		public override void Flush()
		{
			this._innerStream.Flush();
		}

		public override long Length
		{
			get
			{
				return this._innerStream.Length;
			}
		}

		public override long Position
		{
			get
			{
				return this._innerStream.Position;
			}
			set
			{
				this._innerStream.Position = value;
			}
		}

		public override long Seek(long offset, SeekOrigin origin)
		{
			return this._innerStream.Seek(offset, origin);
		}

		public override void SetLength(long value)
		{
			bool flag = this.rwMode != ZipSegmentedStream.RwMode.Write;
			if (flag)
			{
				this._exceptionPending = true;
				throw new InvalidOperationException();
			}
			this._innerStream.SetLength(value);
		}

		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = this._innerStream != null;
				if (flag)
				{
					this._innerStream.Dispose();
					bool flag2 = this.rwMode == ZipSegmentedStream.RwMode.Write;
					if (flag2)
					{
						bool exceptionPending = this._exceptionPending;
						if (exceptionPending)
						{
						}
					}
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		private ZipSegmentedStream.RwMode rwMode;

		private bool _exceptionPending;

		private string _baseName;

		private string _baseDir;

		private string _currentName;

		private string _currentTempName;

		private uint _currentDiskNumber;

		private uint _maxDiskNumber;

		private int _maxSegmentSize;

		private Stream _innerStream;

		private enum RwMode
		{
			None,
			ReadOnly,
			Write
		}
	}
}
