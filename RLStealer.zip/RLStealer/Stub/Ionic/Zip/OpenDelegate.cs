﻿using System;
using System.IO;

namespace Ionic.Zip
{
	public delegate Stream OpenDelegate(string entryName);
}
