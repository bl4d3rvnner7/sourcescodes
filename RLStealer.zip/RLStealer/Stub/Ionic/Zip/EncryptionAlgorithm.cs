﻿using System;

namespace Ionic.Zip
{
	public enum EncryptionAlgorithm
	{
		None,
		PkzipWeak,
		Unsupported = 4
	}
}
