﻿using System;
using System.IO;
using System.Text;
using Ionic.Zlib;

namespace Ionic.Zip
{
	internal class ZipContainer
	{
		public ZipContainer(object o)
		{
			this._zf = (o as ZipFile);
			this._zos = (o as ZipOutputStream);
			this._zis = (o as ZipInputStream);
		}

		public ZipFile ZipFile
		{
			get
			{
				return this._zf;
			}
		}

		public ZipOutputStream ZipOutputStream
		{
			get
			{
				return this._zos;
			}
		}

		public string Name
		{
			get
			{
				bool flag = this._zf != null;
				string name;
				if (flag)
				{
					name = this._zf.Name;
				}
				else
				{
					bool flag2 = this._zis != null;
					if (flag2)
					{
						throw new NotSupportedException();
					}
					name = this._zos.Name;
				}
				return name;
			}
		}

		public string Password
		{
			get
			{
				bool flag = this._zf != null;
				string password;
				if (flag)
				{
					password = this._zf._Password;
				}
				else
				{
					bool flag2 = this._zis != null;
					if (flag2)
					{
						password = this._zis._Password;
					}
					else
					{
						password = this._zos._password;
					}
				}
				return password;
			}
		}

		public Zip64Option Zip64
		{
			get
			{
				bool flag = this._zf != null;
				Zip64Option zip;
				if (flag)
				{
					zip = this._zf._zip64;
				}
				else
				{
					bool flag2 = this._zis != null;
					if (flag2)
					{
						throw new NotSupportedException();
					}
					zip = this._zos._zip64;
				}
				return zip;
			}
		}

		public int BufferSize
		{
			get
			{
				bool flag = this._zf != null;
				int result;
				if (flag)
				{
					result = this._zf.BufferSize;
				}
				else
				{
					bool flag2 = this._zis != null;
					if (flag2)
					{
						throw new NotSupportedException();
					}
					result = 0;
				}
				return result;
			}
		}

		public ParallelDeflateOutputStream ParallelDeflater
		{
			get
			{
				bool flag = this._zf != null;
				ParallelDeflateOutputStream result;
				if (flag)
				{
					result = this._zf.ParallelDeflater;
				}
				else
				{
					bool flag2 = this._zis != null;
					if (flag2)
					{
						result = null;
					}
					else
					{
						result = this._zos.ParallelDeflater;
					}
				}
				return result;
			}
			set
			{
				bool flag = this._zf != null;
				if (flag)
				{
					this._zf.ParallelDeflater = value;
				}
				else
				{
					bool flag2 = this._zos != null;
					if (flag2)
					{
						this._zos.ParallelDeflater = value;
					}
				}
			}
		}

		public long ParallelDeflateThreshold
		{
			get
			{
				bool flag = this._zf != null;
				long parallelDeflateThreshold;
				if (flag)
				{
					parallelDeflateThreshold = this._zf.ParallelDeflateThreshold;
				}
				else
				{
					parallelDeflateThreshold = this._zos.ParallelDeflateThreshold;
				}
				return parallelDeflateThreshold;
			}
		}

		public int ParallelDeflateMaxBufferPairs
		{
			get
			{
				bool flag = this._zf != null;
				int parallelDeflateMaxBufferPairs;
				if (flag)
				{
					parallelDeflateMaxBufferPairs = this._zf.ParallelDeflateMaxBufferPairs;
				}
				else
				{
					parallelDeflateMaxBufferPairs = this._zos.ParallelDeflateMaxBufferPairs;
				}
				return parallelDeflateMaxBufferPairs;
			}
		}

		public int CodecBufferSize
		{
			get
			{
				bool flag = this._zf != null;
				int codecBufferSize;
				if (flag)
				{
					codecBufferSize = this._zf.CodecBufferSize;
				}
				else
				{
					bool flag2 = this._zis != null;
					if (flag2)
					{
						codecBufferSize = this._zis.CodecBufferSize;
					}
					else
					{
						codecBufferSize = this._zos.CodecBufferSize;
					}
				}
				return codecBufferSize;
			}
		}

		public CompressionStrategy Strategy
		{
			get
			{
				bool flag = this._zf != null;
				CompressionStrategy strategy;
				if (flag)
				{
					strategy = this._zf.Strategy;
				}
				else
				{
					strategy = this._zos.Strategy;
				}
				return strategy;
			}
		}

		public Zip64Option UseZip64WhenSaving
		{
			get
			{
				bool flag = this._zf != null;
				Zip64Option result;
				if (flag)
				{
					result = this._zf.UseZip64WhenSaving;
				}
				else
				{
					result = this._zos.EnableZip64;
				}
				return result;
			}
		}

		public Encoding AlternateEncoding
		{
			get
			{
				bool flag = this._zf != null;
				Encoding result;
				if (flag)
				{
					result = this._zf.AlternateEncoding;
				}
				else
				{
					bool flag2 = this._zos != null;
					if (flag2)
					{
						result = this._zos.AlternateEncoding;
					}
					else
					{
						result = null;
					}
				}
				return result;
			}
		}

		public Encoding DefaultEncoding
		{
			get
			{
				bool flag = this._zf != null;
				Encoding result;
				if (flag)
				{
					result = ZipFile.DefaultEncoding;
				}
				else
				{
					bool flag2 = this._zos != null;
					if (flag2)
					{
						result = ZipOutputStream.DefaultEncoding;
					}
					else
					{
						result = null;
					}
				}
				return result;
			}
		}

		public ZipOption AlternateEncodingUsage
		{
			get
			{
				bool flag = this._zf != null;
				ZipOption result;
				if (flag)
				{
					result = this._zf.AlternateEncodingUsage;
				}
				else
				{
					bool flag2 = this._zos != null;
					if (flag2)
					{
						result = this._zos.AlternateEncodingUsage;
					}
					else
					{
						result = ZipOption.Default;
					}
				}
				return result;
			}
		}

		public Stream ReadStream
		{
			get
			{
				bool flag = this._zf != null;
				Stream readStream;
				if (flag)
				{
					readStream = this._zf.ReadStream;
				}
				else
				{
					readStream = this._zis.ReadStream;
				}
				return readStream;
			}
		}

		private ZipFile _zf;

		private ZipOutputStream _zos;

		private ZipInputStream _zis;
	}
}
