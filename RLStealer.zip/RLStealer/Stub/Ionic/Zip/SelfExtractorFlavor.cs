﻿using System;

namespace Ionic.Zip
{
	public enum SelfExtractorFlavor
	{
		ConsoleApplication,
		WinFormsApplication
	}
}
