try:
  import os, ctypes, random, time, sys
  from collections import Counter
  from colorama import init, Fore, Back, Style
  init()
  white = Fore.WHITE
  purple = Fore.LIGHTMAGENTA_EX
  if sys.platform == "win32":
    ctypes.windll.kernel32.SetConsoleTitleW('Editify - Created by cracked.io/Zentred')
  else:
    sys.stdout.write("\x1b]2;Editify - Created by cracked.io/Zentred\x07")

  def cls():
      os.system('cls' if os.name == 'nt' else 'clear')


  def suffix():
      combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
      print(f"    {white}>> {purple}Enter Suffix{white}:")
      suffix = input('    ')
      output = [x + suffix for x in combo]
      with open('output.txt', 'w', errors='ignore') as p:
          p.writelines('\n'.join(output))


  def prefix():
      combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
      print(f"    {white}>> {purple}Enter Prefix{white}:")
      prefix = input('    ')
      output = [prefix + x for x in combo]
      with open('output.txt', 'w', errors='ignore') as p:
          p.writelines('\n'.join(output))

  def strip():
    combo = open("combo.txt", "r",errors="ignore").read().splitlines()
    print('    '+white+'>>'+purple+'Enter characters(s)'+white+':')
    characters = list(input('   '))
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        for char in characters:
          second = second.replace(char, "")
          output.append(first+":"+second)
      except:
        continue
    with open("output.txt", "w", errogs="ignore") as p:
      p.writelines("\n".join(output))

  def domain_s():
    combo = open("combo.txt", "r",errors="ignore").read().splitlines()
    print('    '+white+'>>'+purple+'Enter domain'+white+':')
    domain = input('    ')
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        before = first.split("@")[0]
        output.append(before+"@"+domain+":"+second)
      except:
        continue
    with open("output.txt", "w", errogs="ignore") as p:
      p.writelines("\n".join(output))

  def case_s():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        if not second.isdigit():
          swapped = second.swapcase()
          output.append(first+":"+swapped)
      except:
        continue
    with open('output.txt', 'w', errors='ignore') as p:
          p.writelines('\n'.join(combo))
  
  def shuffle():
      combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
      random.shuffle(combo)
      with open('output.txt', 'w', errors='ignore') as p:
          p.writelines('\n'.join(combo))

  def dupes():
      combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
      output = list(set(combo))
      with open('output.txt', 'w', errors='ignore') as p:
          p.writelines('\n'.join(output))

  def sorter():
      combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
      combo.sort()
      with open('output.txt', 'w', errors='ignore') as p:
          p.writelines('\n'.join(combo))

  def passwordlen():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    print('    '+white+'>>'+purple+'Enter minimum password length'+white+':')
    min = int(input('    '))
    output = []
    print('\n    '+white+'>> '+purple+'Enter maximum password length'+white+':')
    max = int(input('    '))
    for x in combo:
      try:
        first,second = x.split(":")
        if min >= len(first) and len(first) <= max:
          output.append(x) 
      except:
        continue
    with open("output.txt", "w", errogs="ignore") as p:
      p.writelines("\n".join(output))

  def firstlen():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    print('    '+white+'>>'+purple+'Enter minimum email/username length'+white+':')
    min = int(input('    '))
    output = []
    print('\n    '+white+'>> '+purple+'Enter maximum email/username length'+white+':')
    max = int(input('    '))
    for x in combo:
      try:
        first,second = x.split(":")
        if min >= len(second) and len(second) <= max:
          output.append(x) 
      except:
        continue
    with open("output.txt", "w", errogs="ignore") as p:
      p.writelines("\n".join(output))

  def combine_fs():
      emails = open('emails.txt', 'r', errors='ignore').read().splitlines()
      passwords = open('passwords.txt', 'r', errors='ignore').read().splitlines()
      while True:
        if '' in emails:
          emails.remove('')
      while True:
        if '' in passwords:
          passwords.remove('')

      output = [x + ':' + p for x in emails for p in iter(passwords)]
      with open('output.txt', 'w', errors='ignore') as p:
          p.writelines('\n'.join(output))

  def domain_f():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    print('    '+white+'>>'+purple+'Enter domain(s)'+white+':')
    domains = input('    ')
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        if "," in domains:
          domains = domains.split(",")
        if first.split("@")[1] in domains:
          output.append(x)
      except:
        continue
    with open("output.txt", "w", errogs="ignore") as p:
      p.writelines("\n".join(output))

  def country_f():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    print('    '+white+'>>'+purple+'Enter domain(s)'+white+':')
    domains = input('    ')
    output = []
    if "," in domains:
      domains = domains.split(",")
      for x in combo:
        try:
          first,second = x.split(":")
          for dom in domains:
            if dom in first.split("@")[1]:
              output.append(x)
        except:
          continue
    with open("output.txt", "w", errogs="ignore") as p:
      p.writelines("\n".join(output))

  def parse_f():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        output.append(first)
      except:
        continue
    with open("emails.txt", "w", errogs="ignore") as p:
      p.writelines("\n".join(output))         

  def parse_s():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        output.append(second)
      except:
        continue
    with open("passwords.txt", "w", errogs="ignore") as p:
      p.writelines("\n".join(output))

  def seperate():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    output = []
    if not os.path.exists("files"+os.sep+"16 - Seperate By Doamin"):
      os.mkdir("files"+os.sep+"16 - Seperate By Doamin")
    for x in combo:
      try:
        first,second = x.split("@")
        each = first.split("@")
        with open("files"+os.sep+"16 - Seperate By Doamin"+each+'.txt', 'a', errors="ignore") as p:
          p.writelines(x+"\n")
      except:
        continue
    print('    '+white+'>> '+purple+"Your domain seperation files were saved in the 'files/16 - Seperate By Domain' folder.")
    time.sleep(5)

  def combo_c():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    output = []
    print('    '+white+'1 >> '+purple+'Email:Password')
    print('    '+white+'2 >> '+purple+'Username:Password')
    option = input('    ')
    if option == "1":            
      for x in combo:
        try:
          x = x.replace(' ', '')
          first,second = x.split(":")
          calculation = x.split(":")
          if len(calculation) == 2:
            if not first == "" or not second == "" or not "@" in first or not "." in first or not "!" in first or not '"' in first or not "\xc2\xa3" in first or not "$" in first or not "%" in first or not "&" in first or not "*" in first or not len(second) >= 100:
              output.append(x)
        except:
          continue
    elif option == "2":
      for x in combo:
        try:
          x = x.replace(' ', '')
          first,second = x.split(":")
          calculation = x.split(":")
          if len(calculation) == 2:
            if not first == "" or not second == "" or not "@" in first or not "." in first or not "!" in first or not '"' in first or not "\xc2\xa3" in first or not "$" in first or not "%" in first or not "&" in first or not "*" in first or not len(second) >= 100:
              output.append(x)
        except:
          continue
    with open("output.txt", "w", errogs="ignore") as p:
      p.writelines("\n".join(output))

  def word_filter():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    print('    '+white+'>> '+purple+'Word to filter combo by'+white+':')
    words = input("    ")
    words = words.split()
    output = []
    for x in combo:
      for word in words:
        if word in x:
          output.append(x)
    with open("output.txt", "w", errogs="ignore") as p:
      p.writelines("\n".join(output)) 

  def ep_to_up():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        first = first.split("@")[0]
        output.append(first+':'+second)
      except:
        continue
    with open("output.txt", "w", errogs="ignore") as p:
      p.writelines("\n".join(output)) 

  def up_to_ep():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    print('    '+white+'>> '+purple+'Enter Domain'+white+':')
    domain = input('    ')
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        first = first.split("@")[0]
        output.append(first+'@'+domain+":"+second)
      except:
        continue
    with open("output.txt", "w", errogs="ignore") as p:
      p.writelines("\n".join(output)) 

  def edit_ex():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    symbols = ["!","$", ".", "*", "#", "@"]
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        if not second.isdigit():
          swapped = second.swapcase()
          swapped += ''.join(symbols)
          output.append(first+':'+swapped)
        output2 = combo + output
        for prefix in symbols:
          x += prefix
      except:
        continue
      for output3 in output2:
        output3 += output
      output = list(set(output))
    with open("output.txt", "w", errogs="ignore") as p:
      p.writelines("\n".join(output3))   

  def edit_si():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        if not second.isdigit():
          swapped = second.swapcase()
          swapped += ''.join("!")
          output.append(first+':'+swapped)
        output2 = combo + output
      except:
        continue

      for output3 in output2:
        output3 += output
      output2 = list(set(output2))
    with open("output.txt", "w", errogs="ignore") as p:
      p.writelines("\n".join(output)) 

  def extract_lines():
      combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
      print(f"    {white}>> {purple}Amount of lines to extract{white}:")
      amount = int(input('    '))
      with open('output.txt', 'w', errors='ignore') as p:
          p.writelines('\n'.join(combo[0:amount]))

  def combine_files():
    output = []
    if not os.path.exists("files"+os.sep+"24 - Files To Combine"):
      os.mkdir("files"+os.sep+"24 - Files To Combine")
    input("\n    Folder was created. Put your textfiles in the '24 - Files To Combine' folder and re-run this edit.")
    for root,dirs,files in os.walk("files"+os.sep+"24 - Files To Combine"):
      for filename in files:
        if ".txt" in filename:
          combo = open("files"+os.sep+"24 - Files To Combine"+os.sep+filename, "r", errors="ignore").read().splitlines()
          output += combo
    with open('output.txt', 'w', errors='ignore') as p:
      p.writelines('\n'.join(output))
         
  def filesplit_parts():
      combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
      try:
          os.mkdir('files/25 - File Splits (Parts)')
      except:
          pass
      else:
          print(f"    {white}>> {purple}Amount of parts to split by{white}:")
          parts = int(input('    '))
          each_file = len(combo) / parts
          for i in range(parts):
              if not i + 1 == parts:
                  with open(f"files/25 - File Splits (Parts)/{i}.txt", 'w', errors='ignore') as p:
                      p.writelines('\n'.join(combo[int(i * each_file):int((i + 1) * each_file)]))
              else:
                  if i + 1 == parts:
                      with open(f"files/25 - File Splits (Parts)/{i}.txt", 'w', errors='ignore') as p:
                          p.writelines('\n'.join(combo[int(i * each_file):len(combo)]))
          else:
              print(f"\n    {white}>> {purple}Your splits were saved in the 'files/25 - File Splits (Parts)' folder.")
              time.sleep(5)

  def filesplit_lines():
      combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
      try:
          os.mkdir('files/26 - File Splits (Lines)')
      except:
          pass
      else:
          print(f"    {white}>> {purple}Amount of lines in each split{white}:")
          lines_per = int(input('    '))
          i = 0
          while True:
              first = i * lines_per
              second = (i + 1) * lines_per
              if not second >= len(combo):
                  with open(f"files/26 - File Splits (Lines)/{i}.txt", 'w', errors='ignore') as p:
                      p.writelines('\n'.join(combo[first:second]))
              else:
                  if second >= len(combo):
                      with open(f"files/26 - File Splits (Lines)/{i}.txt", 'w', errors='ignore') as p:
                          p.writelines('\n'.join(combo[first:len(combo)]))
                      print(f"\n    {white}>> {purple}Your splits were saved in the 'files/26 - File Splits (Lines)' folder.")
                      time.sleep(5)
                      return
              i += 1

  def password_symbol():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        symbols = '!"\xc2\xa3$%^&*()_-=+~@/\\#.'
        for symbol in symbols:
          if symbol in second:
            second.replace(symbol, '')
          output.append(first+":"+second)
      except:
        continue
    with open("output.txt", "w", errors="ignore") as p:
      p.writelines('\n'.join(output))

  def up_from_combo():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        if "." not in first or "@" not in first:
          output.append(x)
      except:
        continue
    with open("output.txt", "w", errors="ignore") as p:
      p.writelines('\n'.join(output))

  def ep_from_combo():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        if "@" in first and "." in first:
          output.append(x)
      except:
        continue
    with open("output.txt", "w", errors="ignore") as p:
      p.writelines('\n'.join(output))

  def get_word(w):
      first, second = w.split(':')[2]
      return first.split('@')[-1]

  def domain_sort():
      combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
      with open('output.txt', 'w', errors='ignore') as p:
          p.writelines('\n'.join(sorted(combo, key=get_word)))

  def number_edit():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        checking = second[-1]
        numbers = "1234567890"
        to_replace = ""
        for char in checking:
          if char in numbers:
            to_replace += char
        if to_replace != "":
          if to_replace[-1] == "123":
            second = second.replace(to_replace, "123")
            letters_amount = 0
            for ltr in second:
              if ltr.isalpha():
                letters_amount += 1
            if letters_amount >= 3:
              output.append(first+":"+second)
      except:
        continue
    with open("output.txt", "w", errors="ignore") as p:
      p.writelines('\n'.join(output))

  def common_passwords():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    output = []
    common = ['123456','123456789','12345','qwerty','password','12345678','111111','123123','password123','abc123','qwertyuiop','1qaz2wsx','1234567890','1234567','asdfghjkl','zxcvbnm','1q2w3e4r','1q2w3e4r5t','pokemon']
    for x in common:
      try:
        first,second = x.split(":")
        if second not in common:
          output.append(x)
      except:
        continue
    with open("output.txt", "w", errors="ignore") as p:
      p.writelines('\n'.join(output))

  def remove_numbers():
    combo = open('combo.txt', 'r', errors='ignore').read().splitlines()
    output = []
    for x in combo:
      try:
        first,second = x.split(":")
        if second.isdecimal() == False:
          output.append(x)
      except:
        continue
    with open("output.txt", "w", errors="ignore") as p:
      p.writelines('\n'.join(output))

  def choosing():
    cls()
    print(f"""\t\t\t\t\t{purple}██████╗ ██████╗ ██╗████████╗██╗███████╗██╗   ██╗\n\t\t\t\t\t██╔════╝██╔══██╗██║╚══██╔══╝██║██╔════╝╚██╗ ██╔╝\n\t\t\t\t\t█████╗  ██║  ██║██║   ██║   ██║█████╗   ╚████╔╝ \n\t\t\t\t\t██╔══╝  ██║  ██║██║   ██║   ██║██╔══╝    ╚██╔╝  \n\t\t\t\t\t███████╗██████╔╝██║   ██║   ██║██║        ██║   \n\t\t\t\t\t╚══════╝╚═════╝ ╚═╝   ╚═╝   ╚═╝╚═╝        ╚═╝   \n\t\t\t\t\t\t{white}Created By Zentred {purple}[CRACKED.IO]    \n\n    {white} 1 >> {purple}Suffix                         {white}12 >> {purple}Filter By Domain              {white}23 >> {purple}Extract Amount Of Lines\n    {white} 2 >> {purple}Prefix                         {white}13 >> {purple}Filter By Country             {white}24 >> {purple}Combine Textfiles\n    {white} 3 >> {purple}Password Strip                 {white}14 >> {purple}Parse Users/Emails            {white}25 >> {purple}Split Textfile By Parts\n    {white} 4 >> {purple}Domain Swap                    {white}15 >> {purple}Parse Passwords               {white}26 >> {purple}Split Textfile By Lines\n    {white} 5 >> {purple}Case Swap                      {white}16 >> {purple}Seperate By Domain            {white}27 >> {purple}Remove Password Symbols\n    {white} 6 >> {purple}Shuffle                        {white}17 >> {purple}Cleaner                       {white}28 >> {purple}Filter U:P From Combo\n    {white} 7 >> {purple}Remove Duplicates              {white}18 >> {purple}Filter By Word                {white}29 >> {purple}Filter E:P From Combo\n    {white} 8 >> {purple}Alphabetical Sort              {white}19 >> {purple}Convert E:P to U:P            {white}30 >> {purple}Alphabetical Domain Sort\n    {white} 9 >> {purple}Password Length Filter         {white}20 >> {purple}Convert U:P to E:P            {white}31 >> {purple}Number Edit\n    {white}10 >> {purple}User/Email Length Filter       {white}21 >> {purple}Simple Edits                  {white}32 >> {purple}Filter Out Common Passwords\n    {white}11 >> {purple}Combine User/Email + Password  {white}22 >> {purple}Extreme Edits                 {white}33 >> {purple}Remove Number Passwords\n    \n\t\t\t\t\t {white}99 >> {purple}Exit tool""")
    choice = int(input('    Choice: '))
    if choice == 1:
      suffix()
    elif choice == 2:
      prefix()
    elif choice == 3:
      strip()
    elif choice == 4:
      domain_s()
    elif choice == 5:
      case_s()
    elif choice == 6:
      shuffle()
    elif choice == 7:
      dupes()
    elif choice == 8:
      sorter()
    elif choice == 9:
      passwordlen()
    elif choice == 10:
      firstlen()
    elif choice == 11:
      combine_fs()
    elif choice == 12:
      domain_f()
    elif choice == 13:
      country_f()
    elif choice == 14:
      parse_f()
    elif choice == 15:
      parse_s()
    elif choice == 16:
      seperate()
    elif choice == 17:
      combo_c()
    elif choice == 18:
      word_filter()
    elif choice == 19:
      ep_to_up()
    elif choice == 20:
      up_to_ep()
    elif choice == 21:
      edit_si()
    elif choice == 22:
      edit_ex()
    elif choice == 23:
      extract_lines()
    elif choice == 24:
      combine_files()
    elif choice == 25:
      filesplit_parts()
    elif choice == 26:
      filesplit_lines()
    elif choice == 27:
      password_symbol()
    elif choice == 28:
      up_from_combo()
    elif choice == 29:
      ep_from_combo()
    elif choice == 30:
      domain_sort()
    elif choice == 31:
      number_edit()
    elif choice == 32:
      common_passwords()
    choosing()
  choosing()
except Exception as err:
  try:
    print(err)
    input('\nPress Enter to exit.')
  finally:
    err = None
    del err